﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initPropertySearchGrid();
    initPrTowerGrid();
    initPrTaxGrid();
    initPrChargesGrid();
    formatFields();
    showModal();
}

function initPropertySearchGrid() {
    var dtOptions = {
        tableId: "propertySearchGrid",
        pageLength: 10,
        isViewOnly: false,
        customBtnGrpId: "#propertySearchBtnDiv",
        hideSearch: false
    };
    var dtTable = applyResponsiveDataTable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitHdnId");
}
function initPrTowerGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "propertyTowerGrid",
        pageLength: 5,
        responsiveModalTitle: "Tower Details",
        isViewOnly: isViewOnly,
        customBtnGrpId: "#prTowerSearchBtnDiv",
        hideSearch: true
    };
    var dtTable = applyActionDataTable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitUploadHdnId");
}
function initPrTaxGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "taxDetailGrid",
        pageLength: 5,
        responsiveModalTitle: "Tax Details",
        isViewOnly: isViewOnly,
        customBtnGrpId: "#taxDetailGridBtnGrp",
        hideSearch: true
    };
    var dtTable = applyActionDataTable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitUploadHdnId");
}
function initPrChargesGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "propertyChargesGrid",
        pageLength: 5,
        responsiveModalTitle: "Property Charge Details",
        isViewOnly: isViewOnly,
        customBtnGrpId: "#chargesDetailGridBtnGrp",
        hideSearch: true
    };
    var dtTable = applyActionDataTable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitUploadHdnId");
}




