﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using ConstroSoft.Logic.BO;

public partial class LeadAssignment : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    DropdownBO drpBO = new DropdownBO();
    EnquiryBO enquiryBO = new EnquiryBO();

    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                LeadAssignmentNavDTO navDto = (LeadAssignmentNavDTO)Session[Constants.Session.NAV_DTO];
                Session.Remove(Constants.Session.NAV_DTO);
                Session.Remove(Constants.Session.PAGE_DATA);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(Constants.URL.DEFAULT_HOME_PAGE, false);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        drpBO.drpDataBase(drpNewAssignee, DrpDataType.ACTIVE_USERS, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
    }
    private void preRenderInitFormElements()
    {
        renderPageLayout();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpNewAssignee, DrpDataType.ACTIVE_USERS, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(LeadAssignmentNavDTO navDto)
    {
        LeadAssignmentPageDTO PageDTO = new LeadAssignmentPageDTO();
        PageDTO.NewLeads = new List<UserLeadHistoryUIDTO>();
        PageDTO.AssignedLeads = new List<UserLeadHistoryUIDTO>();
        Session[Constants.Session.PAGE_DATA] = PageDTO;
        initDropdowns();
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(LeadAssignmentNavDTO navDto)
    {
        try
        {
            loadandInitPage();
            enableTab(true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageLayout()
    {
    }
    private LeadAssignmentPageDTO getSessionPageData()
    {
        return (LeadAssignmentPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<AllEnquiryLeadUIDTO> getSearchList()
    {
        return getSessionPageData().SearchResult;
    }
    private AllEnquiryLeadUIDTO getSearchEnquiryLeadDTO(long Id)
    {
        List<AllEnquiryLeadUIDTO> searchList = getSearchList();
        AllEnquiryLeadUIDTO selectedDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            selectedDTO = searchList.Find(c => c.FirmMemberId == Id);
        }
        return selectedDTO;
    }
    private void loadandInitPage()
    {
        LeadAssignmentPageDTO PageDTO = getSessionPageData();
        List<AllEnquiryLeadUIDTO> allEnqLeadList = enquiryBO.fetchAllEnquiryLeadData(getUserDefinitionDTO().FirmNumber);
        PageDTO.SearchResult = (allEnqLeadList != null) ? allEnqLeadList : new List<AllEnquiryLeadUIDTO>();
        allEnquiryLeadSearchGrid.DataSource = PageDTO.SearchResult;
        allEnquiryLeadSearchGrid.DataBind();

        List<UserLeadHistoryUIDTO> unassignedLeadList = enquiryBO.fetchUnAssignedLeads(getUserDefinitionDTO().FirmNumber);
        PageDTO.NewLeads = (unassignedLeadList != null) ? unassignedLeadList : new List<UserLeadHistoryUIDTO>();
        newLeadsGrid.DataSource = PageDTO.NewLeads;
        newLeadsGrid.DataBind();

    }
    private void loadAssignedLeadsForUser() {
    	LeadAssignmentPageDTO PageDTO = getSessionPageData();
        AllEnquiryLeadUIDTO selectedUserDTO = getUserSelected();
        List<UserLeadHistoryUIDTO> assignedLeadList = null;
        if (selectedUserDTO != null)
        {
            assignedLeadList = enquiryBO.fetchLeadsForUser(selectedUserDTO.FirmMemberId, LeadStatus.Open);
        }
        PageDTO.AssignedLeads = (assignedLeadList != null) ? assignedLeadList : new List<UserLeadHistoryUIDTO>();
        assignedLeadsGrid.DataSource = PageDTO.AssignedLeads;
        assignedLeadsGrid.DataBind();
    }
    private AllEnquiryLeadUIDTO getUserSelected()
    {
        return getSearchList().Find(x => x.isUISelected);
    }
    private void setUserSelected(long FirmMemberId)
    {
        List<AllEnquiryLeadUIDTO> userList = getSearchList();
        userList.ForEach(x => x.isUISelected = false);
        txtAssignee.Text = null;
        if (FirmMemberId > 0)
        {
            AllEnquiryLeadUIDTO selectedUserDTO = userList.Find(x => x.FirmMemberId == FirmMemberId);
            selectedUserDTO.isUISelected = true;
            txtAssignee.Text = CommonUIConverter.getCustomerFullName(selectedUserDTO.FirstName, selectedUserDTO.LastName);
        }
    }
    private void enableTab(bool isNewLeads)
    {
        LeadAssignmentPageDTO PageDTO = getSessionPageData();
        liNewLeads.Attributes["class"] = (isNewLeads) ? "active" : "";
        liReassignLeads.Attributes["class"] = (isNewLeads) ? "" : "active";
        pnlNewLeadsEmpty.Visible = (isNewLeads && PageDTO.NewLeads.Count == 0);
        pnlNewLeads.Visible = (isNewLeads && PageDTO.NewLeads.Count > 0);
        pnlAssignedLeadsEmpty.Visible = (!isNewLeads && PageDTO.AssignedLeads.Count == 0);
        pnlAssignedLeads.Visible = (!isNewLeads && PageDTO.AssignedLeads.Count > 0);
        
        loadAssignedLeadsForUser();
    }
    protected void onSelectUser(object sender, EventArgs e)
    {
        try
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            if (rd.Checked)
            {
                string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnUserRowIdentifier"))).Attributes["row-identifier"];
                setUserSelected(long.Parse(strId));
            }
            loadAssignedLeadsForUser();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickNewLeads(object sender, EventArgs e)
    {
        try
        {
            enableTab(true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickReassignLeads(object sender, EventArgs e)
    {
        try
        {
            AllEnquiryLeadUIDTO selectedUserDTO = getUserSelected();
            if (selectedUserDTO != null)
            {
                enableTab(false);
            }
            else
            {
                setNotyMsg(CommonUtil.getNotyErrorMsg("Please select User."));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void assignNewLeads(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelNewLeadAssignment(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void reAssignLeads(object sender, EventArgs e)
    {
        try
        {
            //TODO - Also validate whether new Assignee is active
            if (!string.IsNullOrWhiteSpace(drpNewAssignee.Text))
            {
                //TODO - Assign selected leads to new assignee.
            }
            else
            {
                setNotyMsg(CommonUtil.getNotyErrorMsg("Please select new Assignee."));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelLeadReassignment(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
}
