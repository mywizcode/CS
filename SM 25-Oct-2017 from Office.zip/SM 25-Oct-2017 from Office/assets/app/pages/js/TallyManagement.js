﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
	initVoucherSearchGrid();
    formatFields();
}

function initVoucherSearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        pageLength: 10,
        hideSearch: true
    };

    $("[id$='voucherSearchGrid']").CSBasicDatatable(dtOptions);
}




