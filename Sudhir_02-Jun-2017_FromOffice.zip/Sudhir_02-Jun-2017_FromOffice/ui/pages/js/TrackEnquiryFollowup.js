﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initEnquiryGrid();
    initFollowUpGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    makeReadOnlySection("pnlEnquiryInfo");
    enableTab(false);
    //This script will enable tabs which was last active even after postback call.
    if ($("[id$='activeTabHdn']").val() != "") {
        $('a[id$="' + $("[id$='activeTabHdn']").val() + '"]').tab('show');
    }
}

function initFollowUpGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "followUpGrid",
        pageLength: 5,
        isViewOnly: isViewOnly,
        responsiveModalTitle: "Follow-Up Details",
        customBtnGrpId: "#followUpHistoryGridBtnGrp",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToFollowUpHdnId");
}

function initEnquiryGrid() {
    var dtOptions = {
        tableId: "enquiryGrid",
        pageLength: 10,
        isViewOnly: false,
        customBtnGrpId: "#enqSearchBtnDiv",
        hideSearch: false
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToEnquiryHdnId");
}