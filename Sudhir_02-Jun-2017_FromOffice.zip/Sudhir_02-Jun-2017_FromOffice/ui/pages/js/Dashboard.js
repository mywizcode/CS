$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initEnquiryGrid();
    initEventGrid();
    initPdcGrid();
    makeDropdownVisible();
    $('#EventModal, #EnquiryModal').on('show.bs.modal', function (e) {
        formatFields();
    });
    $('.modal-backdrop').remove();
    if ($("[id$='showEventModalHdnBtn']").val() == "true") {
        $('.EventModal').click();
        $("[id$='showEventModalHdnBtn']").val('false');
    } else if ($("[id$='showEnquiryFollowupModalHdn']").val() == "true") {
        $('.EnquiryModal').click();
        $("[id$='showEnquiryFollowupModalHdn']").val('false');
    }
    initNotification();
}
function initEventGrid() {
    var dtOptions = {
        tableId: "eventGrid",
        pageLength: 3,
        isViewOnly: false,
        hideSearch: false
    };
    var dtTable = applyDataTable(dtOptions);
}
function initEnquiryGrid() {
    var dtOptions = {
        tableId: "enquiryGrid",
        pageLength: 5,
        isViewOnly: false,
        hideSearch: false
    };
    var dtTable = applyDataTable(dtOptions);
}
function initPdcGrid() {
    var dtOptions = {
        tableId: "pdcInGrid",
        pageLength: 5,
        isViewOnly: false,
        hideSearch: false
    };
    $("[id$='pdcInGrid']").find('.chqStatus').each(function () {
        $this = $(this);
        if ($this.html() == 'Deposited') {
            $this.removeClass('bg-green');
            $this.addClass('bg-maroon');
        }
    });
    var dtTable = applyDataTable(dtOptions);
    var dtOptions1 = {
        tableId: "pdcOutGrid",
        pageLength: 5,
        isViewOnly: false,
        hideSearch: false
    };
    var dtTable1 = applyDataTable(dtOptions1);
    $("[id$='pdcOutGrid']").find('.chqStatus').each(function () {
        $this = $(this);
        if ($this.html() == 'Deposited') {
            $this.removeClass('bg-green');
            $this.addClass('bg-lime');
        }
    });
}
function initNotification() {
    var msg = $("[id$='successMessageHdn']").val();
    $('.noty-runner').click(function () {
        var self = $(this);
        noty({
            width: 200,
            text: self.data('message'),
            type: self.data('type'),
            dismissQueue: true,
            timeout: 6000,
            layout: self.data('layout')
        });
        return false;
    });
    $('.successMessage').attr('data-message', $("[id$='successMessageHdn']").val());
    $('.errorMessage').attr('data-message', $("[id$='errorMessageHdn']").val());
    $("[id$='successMessageHdn']").val('');
    $("[id$='errorMessageHdn']").val('');
    if ($('.successMessage').attr('data-message') != "") {
        $('.successMessage').click();
    }
    if ($('.errorMessage').attr('data-message') != "") {
        $('.errorMessage').click();
    }
    $('.successMessage').attr('data-message', '');
    $('.errorMessage').attr('data-message', '');
}