$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initAvailableUnitsGrid();
    initTaxGrid();
    initCMTaxGrid();
    initCoCustomerGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("tab2Content");
    //This script will enable tabs which was last active even after postback call.
    enableTab(true);
    makeReadOnlySection("pnlTab3UnitInfo");
    initParking();
}

function initAvailableUnitsGrid() {
    var dtOptions = {
        tableId: "availableUnitsGrid",
        pageLength: 10,
        isViewOnly: false,
        customBtnGrpId: "#availUnitsSearchBtnDiv",
        hideSearch: false
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToAvailableUnitsHdnId");
}
function initTaxGrid() {
    var dtOptions = {
        tableId: "taxDetailGrid",
        pageLength: 5,
        isViewOnly: false,
        responsiveModalTitle: "Tax Details",
        customBtnGrpId: "#taxDetailGridBtnGrp",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToTaxDetailHdnId");
}
function initCMTaxGrid() {
    var dtOptions = {
        tableId: "cmTaxDetailGrid",
        pageLength: 5,
        isViewOnly: false,
        responsiveModalTitle: "Tax Details",
        customBtnGrpId: "#cmTaxDetailGridBtnGrp",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToCMTaxDetailHdnId");
}
function initCoCustomerGrid() {
    var dtOptions = {
        tableId: "coCustomerGrid",
        pageLength: 5,
        isViewOnly: false,
        responsiveModalTitle: "Co Customer Details",
        customBtnGrpId: "#cocustomerGridBtnGrp",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToCoCustHdnId");
}