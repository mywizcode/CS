﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initEnquiryGrid();
    initAddressGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("tab2Content");
    enableTab(true);
    //This script will enable tabs which was last active even after postback call.
    if ($("[id$='activeTabHdn']").val() != "") {
        $('a[id$="' + $("[id$='activeTabHdn']").val() + '"]').tab('show');
    }
}

function initAddressGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "addressGrid",
        pageLength: 5,
        isViewOnly: isViewOnly,
        responsiveModalTitle: "Address Details",
        customBtnGrpId: "#addressGridBtnGrp",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToAddressHdnId");
}

function initEnquiryGrid() {
    var dtOptions = {
        tableId: "enquiryGrid",
        pageLength: 10,
        isViewOnly: false,
        customBtnGrpId: "#enqSearchBtnDiv",
        hideSearch: false
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToEnquiryHdnId");
}