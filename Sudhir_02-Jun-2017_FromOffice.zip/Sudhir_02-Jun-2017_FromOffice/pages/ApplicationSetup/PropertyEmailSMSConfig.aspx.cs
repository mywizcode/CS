﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft.Logic.BO;
using NHibernate;
using Vladsm.Web.UI.WebControls;

namespace ConstroSoft.pages.ApplicationSetup
{
    public partial class PropertyEmailSMSConfig : System.Web.UI.Page
    {
        private static readonly log4net.ILog log =
              log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string tab1ValidationGrp = "tab1Error";
        string VS_PROPERTYALERT_LIST = "PROPERTYALERT_LIST";
        DropdownBO drpBO = new DropdownBO();
        PropertyAlertBO propertyAlertBO = new PropertyAlertBO();
        public enum PrAlertPageMode { NONE }

        protected void Page_Load(object sender, EventArgs e)
        {
            clearMessages();
            if (!IsPostBack)
            {
                if (CommonUtil.isSessionActive(Session))
                {
                    resetTabInfo(PrAlertPageMode.NONE);
                    initDropdowns();
                    Page.MaintainScrollPositionOnPostBack = false;
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
        }
        private void initDropdowns()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            drpBO.drpDataBase(drpSearchProperty, DrpDataType.PROPERTY_NAME, userDefDto.Id.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
        }
        /**
         * This method is called just before the page is rendered. So any change in state of the element is applied.
         **/
        protected void Page_PreRender(object sender, EventArgs e)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                applyEntitlement();
                preRenderInitFormElements();
                initBootstrapComponantsFromServer();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        private void applyEntitlement()
        {
            
        }
        private void preRenderInitFormElements()
        {
            jumpToPropertyAlertHdnId.Value = null;
        }
        public void setErrorMessage(string message, string group)
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }

        public void setSuccessMessage(string msg, string tabId)
        {
            activeTabHdn.Value = tabId;
            if (tabId.Equals(tab1Anchor.ID))
            {
                lbTab1Success.Text = msg;
                tab1SuccessPanel.Visible = true;
            }
        }
        public void initBootstrapComponantsFromServer()
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
        }
        private void clearMessages()
        {
            tab1SuccessPanel.Visible = false;
            lbTab1Success.Text = "";
        }
        private UserDefinitionDTO getUserDefinitionDTO()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }

        private void resetTabInfo(PrAlertPageMode pageMode)
        {
            pageModeHdn.Value = pageMode.ToString();
            initFormFields();
            activeTabHdn.Value = tab1Anchor.ID;
        }
        private void initFormFields()
        {
            bool visible = (PrAlertPageMode.NONE.ToString().Equals(pageModeHdn.Value));
            //Buttons
            btnAddSubmit.Visible = visible;
        }
        protected void onSearchByProperty(object sender, EventArgs e)
        {
            try
            {
                resetTabInfo(PrAlertPageMode.NONE);
                pnlAlertGrid.Visible = false;
                if (!string.IsNullOrWhiteSpace(drpSearchProperty.Text))
                {
                    UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                    pnlAlertGrid.Visible = true;
                    loadSearchGridAndReSelect(0);
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        protected void onSearchByValue(object sender, EventArgs e)
        {
            loadSearchGridAndReSelect(0);
            resetTabInfo(PrAlertPageMode.NONE);
        }
        private void loadSearchGridAndReSelect(long Id)
        {
            try
            {
                IList<PropertyAlertConfigDTO> results = propertyAlertBO.fetchEmailSmsAlertGridData(getUserDefinitionDTO().FirmNumber, Convert.ToInt64(drpSearchProperty.Text));
                ViewState[VS_PROPERTYALERT_LIST] = results;
                propertyAlertGrid.DataSource = results;
                propertyAlertGrid.DataBind();
                foreach (GridViewRow row in propertyAlertGrid.Rows)
                {
                    DropDownList drpEmail = (DropDownList)row.FindControl("drpEmail");
                    CheckBox chkEmailBtn = (CheckBox)row.FindControl("selectEmail");
                    CheckBox chkSmsBtn = (CheckBox)row.FindControl("selectSms");
                    string strId = ((Button)(((GridViewRow)chkEmailBtn.NamingContainer).FindControl("btnPropAlertRowIdentifier"))).Attributes["row-identifier"];
                    PropertyAlertConfigDTO propertyAlertConfigDTO = getCurrentPropertyAlertList().Find(u => u.Id == Convert.ToInt64((strId)));
                    chkEmailBtn.Checked = propertyAlertConfigDTO.Email.Equals("Y") ? true : false;
                    chkSmsBtn.Checked = propertyAlertConfigDTO.Sms.Equals("Y") ? true : false;
                    drpEmail.Text = propertyAlertConfigDTO.EmailConfigDTO.Id.ToString();
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        private List<PropertyAlertConfigDTO> getCurrentPropertyAlertList()
        {
            return (List<PropertyAlertConfigDTO>)ViewState[VS_PROPERTYALERT_LIST];
        }
        protected void savePropertyAlertToDB(object sender, EventArgs e)
        {
            try
            {
                updateSelectedAlerts();
                propertyAlertBO.updatePropertyAssignedAlerts(new HashSet<PropertyAlertConfigDTO>(getCurrentPropertyAlertList()));
                setSuccessMessage(string.Format(Resources.Messages.success_record_update, "Property Alerts "), tab1Anchor.ID);
                loadSearchGridAndReSelect(0);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        protected void updateSelectedAlerts()
        {
            try
            {
                if (propertyAlertGrid.Rows.Count > 0)
                {
                    foreach (GridViewRow row in propertyAlertGrid.Rows)
                    {
                        DropDownList Emaildropdown = (DropDownList)row.FindControl("drpEmail");
                        CheckBox chkEmailBtn = (CheckBox)row.FindControl("selectEmail");
                        CheckBox chkSmsBtn = (CheckBox)row.FindControl("selectSms");
                        string strId = ((Button)(((GridViewRow)chkEmailBtn.NamingContainer).FindControl("btnPropAlertRowIdentifier"))).Attributes["row-identifier"];
                        PropertyAlertConfigDTO propertyAlertConfigDTO = getCurrentPropertyAlertList().Find(u => u.Id == Convert.ToInt64((strId)));
                        propertyAlertConfigDTO.Email = chkEmailBtn.Checked ? "Y" : "N";
                        propertyAlertConfigDTO.EmailConfigDTO = new EmailConfigDTO();
                        propertyAlertConfigDTO.EmailConfigDTO.Id = long.Parse(Emaildropdown.Text);
                        propertyAlertConfigDTO.Sms = chkSmsBtn.Checked ? "Y" : "N";
                        propertyAlertConfigDTO.UpdateDate = DateTime.Now;
                        propertyAlertConfigDTO.UpdateUser = getUserDefinitionDTO().Username;
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
       
        protected void propertyAlertGrid_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
                DropDownList drpEmail = (e.Row.FindControl("drpEmail") as DropDownList);
                drpBO.drpDataBase(drpEmail, DrpDataType.FROM_EMAIL_ID, null, null, userDefDto.FirmNumber);
                //drpBO.drpDataBase(drpEmail, DrpDataType.PROPERTY_NAME, userDefDto.Id.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
        }
    }
}