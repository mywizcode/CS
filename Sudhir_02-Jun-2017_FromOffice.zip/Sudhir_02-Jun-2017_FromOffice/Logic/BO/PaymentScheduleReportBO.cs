﻿using NHibernate;
using NHibernate.Criterion;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace ConstroSoft.Logic.BO
{
    public class PaymentScheduleReportBO
    {
         private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
         string VS_PR_PYMT_SCHED_LIST = "PR_PYMT_SCHED_LIST";
         public PaymentScheduleReportBO() { }
         
         private static DataTable populatePropertyDetailsColumns()
         {
             DataTable PropertyDetails = new DataTable();
             PropertyDetails.Columns.Add("PropertyName", typeof(string));
             PropertyDetails.Columns.Add("TowerName", typeof(string));
             PropertyDetails.Columns.Add("CustomerName", typeof(string));
             PropertyDetails.Columns.Add("UnitNumber", typeof(string));
             
             return PropertyDetails;
         }
         private static DataTable populatePaymentForeCastReportColumns()
         {

             DataTable PaymentForecastReport = new DataTable();
             PaymentForecastReport.Columns.Add("PropertyScheduleStage", typeof(string));
             PaymentForecastReport.Columns.Add("SchedulePercentage", typeof(double));
             PaymentForecastReport.Columns.Add("Amount", typeof(double));
             PaymentForecastReport.Columns.Add("Status", typeof(string));
             PaymentForecastReport.Columns.Add("TotalAmount", typeof(decimal));
             return PaymentForecastReport;
         }
         public BusinessOutputTO processPaymentScheduleLetter(string firmNumber, PrUnitSaleDetailDTO selectedPrUnitSaleDetailDto,IList<PropertyScheduleDTO> listPrUnitSaleDetailDto, long propertyId)
         {
             BusinessOutputTO businessOutputTO = new BusinessOutputTO();
             businessOutputTO.resultList = new List<object>();
             try
             {
                 DataTable PropertyDetail = populatePropertyDetailsColumns();
                 DataTable ProperyScheduleDetails = populatePaymentForeCastReportColumns();
                 FirmBO firmBO = new FirmBO();
                 PropertyBO propertyBO = new PropertyBO();
                 FirmDTO firmDto = firmBO.fetchFirmDetails(firmNumber);
                 PropertyDTO propertyDTO = propertyBO.fetchProperty(propertyId); 
                 
                 DataRow PropertyDetailsRow = populatePropertyReportRows(PropertyDetail,propertyDTO,selectedPrUnitSaleDetailDto, firmDto, firmNumber); 
                 PropertyDetail.Rows.Add(PropertyDetailsRow);

                 
                     List<PropertyScheduleDTO> propertyScheduleList = propertyBO.fetchPropertySchedule(firmNumber,
                         selectedPrUnitSaleDetailDto.PropertyUnit.PropertyTower.Id);

                     List<PropertyScheduleDTO> tmpStageList = propertyScheduleList;
                     string errorMessage = validateStageSetup(tmpStageList);
                     if (!string.IsNullOrWhiteSpace(errorMessage))
                     {
                         businessOutputTO.status = BusinessOutputTO.Status.FAILURE;
                         businessOutputTO.errorMessage = errorMessage;
                     }
                     else
                     {
                         decimal totalAmount = 0,percenatageAmount=0;
                         SoldPropertyUnitBO soldUnitBO = new SoldPropertyUnitBO();
                         PrUnitSaleDetailDTO prUnitSaleDetailDto = soldUnitBO.fetchPrUnitSaleDetailforLetter(firmNumber, selectedPrUnitSaleDetailDto.Id,
                        selectedPrUnitSaleDetailDto.PropertyUnit.PropertyTower.Property.Id);
                         totalAmount = prUnitSaleDetailDto.AgreementAmt;
                        
                         foreach (PropertyScheduleDTO selectedPropertySchedule in tmpStageList)
                         {
                             DataRow PropertyScheduleReportRow = ProperyScheduleDetails.NewRow();
                             PropertyScheduleReportRow["TotalAmount"] = totalAmount; 
                             PropertyScheduleReportRow["PropertyScheduleStage"] = selectedPropertySchedule.Stage;
                             PropertyScheduleReportRow["SchedulePercentage"] = selectedPropertySchedule.Percentage;
                             PropertyScheduleReportRow["Status"] = selectedPropertySchedule.Status;
                             PropertyScheduleReportRow["Amount"] = ((Convert.ToDecimal(totalAmount)) * (Convert.ToDecimal(selectedPropertySchedule.Percentage) / 100));
                             
                             if (selectedPropertySchedule.Status.ToString() == "Completed")
                             {

                             }
                             ProperyScheduleDetails.Rows.Add(PropertyScheduleReportRow);
                         }

                         
                         businessOutputTO.status = BusinessOutputTO.Status.SUCCESS;
                     }
                 

                 businessOutputTO.resultList.Add(PropertyDetail);
                 businessOutputTO.resultList.Add(ProperyScheduleDetails);
             }
             catch (Exception e)
             {
                 log.Error("Exception while generating Payment Due Report", e);
                 throw new Exception(Resources.Messages.system_error);
             }
             return businessOutputTO;
         }        
         
         private DataRow populatePropertyReportRows(DataTable PaymentDueReport,PropertyDTO propertyDTO, PrUnitSaleDetailDTO selectedPrUnitSaleDetailDto, FirmDTO firmDto, string firmNumber)
         {
             string BLANK_STRING = "";
             DataRow PaymentReportRow = PaymentDueReport.NewRow();
             PaymentReportRow["PropertyName"]=propertyDTO.Name;
             PaymentReportRow["CustomerName"] = selectedPrUnitSaleDetailDto.Customer.FirstName;
             PaymentReportRow["UnitNumber"] = selectedPrUnitSaleDetailDto.PropertyUnit;                      
             PaymentReportRow["TowerName"] = selectedPrUnitSaleDetailDto.PropertyUnit.PropertyTower.Name;             
             return PaymentReportRow;
         }
         private bool isSalePayment(string paymentType)
         {
             return Constants.MCD_SALE_PAYMENT.Equals(paymentType);
         }
         public static string validateStageSetup(List<PropertyScheduleDTO> tmpStageList)
         {
             string errorMessage = "";
             if (tmpStageList == null && tmpStageList.Count == 0)
             {
                 errorMessage = "Property Schedule is not set. Please set Property Schedule";
             }
             return errorMessage;
         }

         public PrUnitSaleDetailDTO fetchSoldPropertyUnits(string firmNumber, long unitId)
         {
             ISession session = null;
             PrUnitSaleDetailDTO result = new PrUnitSaleDetailDTO();
             try
             {
                 session = NHibertnateSession.OpenSession();
                 using (ITransaction tx = session.BeginTransaction())
                 {
                     try
                     {
                         Property p = null;
                         PropertyUnit pu = null;
                         PrUnitSaleDetail pus = null;
                         Customer c = null;                        
                         PropertyTower pt = null;
                        
                         FirmMember fm = null;

                         PrUnitSaleDetailDTO pusdto = null;

                         var proj = Projections.ProjectionList()
                                     .Add(Projections.Property(() => pus.Id).WithAlias(() => pusdto.Id))
                                     .Add(Projections.SqlFunction("concat",
                                                 NHibernateUtil.String,
                                                 Projections.Property(() => c.FirstName),
                                                 Projections.Constant(" "),
                                                 Projections.Property(() => c.LastName)), "Customer.FirstName")
                                     .Add(Projections.Property(() => c.Id), "Customer.Id")
                                     .Add(Projections.SqlFunction("concat",
                                                 NHibernateUtil.String,
                                                 Projections.Property(() => fm.FirstName),
                                                 Projections.Constant(" "),
                                                 Projections.Property(() => fm.LastName)), "FirmMember.FirstName")

                                     .Add(Projections.Property(() => fm.Id), "FirmMember.Id")
                                     .Add(Projections.Property(() => p.Id), "PropertyUnit.PropertyTower.Property.Id")
                                     .Add(Projections.Property(() => p.Name), "PropertyUnit.PropertyTower.Property.Name")
                                     .Add(Projections.Property(() => pt.Id), "PropertyUnit.PropertyTower.Id")
                                     .Add(Projections.Property(() => pt.Name), "PropertyUnit.PropertyTower.Name")
                                     .Add(Projections.Property(() => pu.Id), "PropertyUnit.Id");
                                     


                         var query = session.QueryOver<PrUnitSaleDetail>(() => pus)
                             .Left.JoinAlias(() => pus.PropertyUnit, () => pu)                             
                             .Left.JoinAlias(() => pus.PropertyUnit.PropertyTower, () => pt)
                             .Left.JoinAlias(() => pus.PropertyUnit.PropertyTower.Property, () => p)
                             .Left.JoinAlias(() => pus.Customer, () => c)                             
                             .Left.JoinAlias(() => pus.FirmMember, () => fm);
                         result = query.Where(() => p.FirmNumber == firmNumber && pu.Id == unitId && pus.Status == PRUnitSaleStatus.Sold)
                             .Select(proj).TransformUsing(new DeepTransformer<PrUnitSaleDetailDTO>()).SingleOrDefault<PrUnitSaleDetailDTO>();
                         //result.ToList().ForEach(x => x.PropertyUnit.PropertyTower.Id
                         //        = CommonUIConverter.getPropertyUnitFormattedNo(x.PropertyUnit.PropertyTower.Id));
                     }
                     catch (Exception e)
                     {
                         tx.Rollback();
                         log.Error("Exception while fetching sold property units :", e);
                         throw new Exception(Resources.Messages.system_error);
                     }
                 }
             }
             finally
             {
                 NHibertnateSession.closeSession(session);
             }
             return result;
         }

    }
}