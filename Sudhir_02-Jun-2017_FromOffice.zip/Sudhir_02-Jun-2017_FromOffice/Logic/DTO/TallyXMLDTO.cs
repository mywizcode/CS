﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ConstroSoft;
using System.Xml.Serialization;

/// <summary>
/// Summary description for PaymentLedger
/// </summary>
namespace ConstroSoft
{
    [Serializable]
    public class PaymentLedger
    {
        public PaymentLedger() { }
        [XmlAttribute("Number")]
        public int HouseNo { get; set; }
        [XmlElement("Name")]
        public string Name { get; set; }
        [XmlElement("GroupName")]
        public string GroupName { get; set; }
    }
    //[Serializable, XmlRoot("Voucher")]
    //public class Voucher
    //{
    //    public Voucher() { }
    //    [XmlElement("VOUCHERNAME")]
    //    public string VOUCHERNAME { get; set; }
    //    [XmlElement("DATE")]
    //    public string DATE { get; set; }
    //}

    [Serializable, XmlRoot("ENVELOPE")]
    public class ENVELOPE
    {
        public ENVELOPE() { }
        [XmlElement("HEADER")]
        public HEADER HEADER { get; set; }
        [XmlElement("BODY")]
        public BODY BODY { get; set; }

    }
    [Serializable, XmlRoot("HEADER")]
    public class HEADER
    {
        public HEADER() { }
        [XmlElement("VERSION")]
        public string VERSION { get; set; }
        [XmlElement("TALLYREQUEST")]
        public string TALLYREQUEST { get; set; }
        [XmlElement("TYPE")]
        public string TYPE { get; set; }
        [XmlElement("SUBTYPE")]
        public string SUBTYPE { get; set; }
        [XmlElement("ID")]
        public string ID { get; set; }
    }

    [Serializable, XmlRoot("BODY")]
    public class BODY
    {
        public BODY() { }
        [XmlElement("DATA")]
        public DATA DATA { get; set; }

    }
    [Serializable, XmlRoot("DATA")]
    public class DATA
    {
        public DATA() { }
        [XmlElement("TALLYMESSAGE")]
        public TALLYMESSAGE TALLYMESSAGE { get; set; }

    }
    [Serializable, XmlRoot("TALLYMESSAGE")]
    public class TALLYMESSAGE
    {
        public TALLYMESSAGE() { }
        [XmlElement("LEDGER")]
        public LEDGER LEDGER { get; set; }
        [XmlElement("VOUCHER")]
        public VOUCHER VOUCHER { get; set; }

    }

    [Serializable]
    public class LEDGER
    {
        public LEDGER() { }
        [XmlAttribute("NAME")]
        public string NAME { get; set; }
        [XmlAttribute("RESERVEDNAME")]
        public string RESERVEDNAME { get; set; }
        [XmlElement("ADDRESS.LIST")]
        public List<ADDRESS> ADDRESS { get; set; }
        [XmlElement("MAILINGNAME.LIST")]
        public List<MAILINGNAME> MAILINGNAME { get; set; }
        [XmlElement("EMAIL")]
        public string EMAIL { get; set; }
        [XmlElement("STATENAME")]
        public string STATENAME { get; set; }
        [XmlElement("PINCODE")]
        public string PINCODE { get; set; }
        [XmlElement("INCOMETAXNUMBER")]
        public string INCOMETAXNUMBER { get; set; }
        [XmlElement("SALESTAXNUMBER")]
        public string SALESTAXNUMBER { get; set; }
        [XmlElement("INTERSTATESTNUMBER")]
        public string INTERSTATESTNUMBER { get; set; }
        [XmlElement("PARENT")]
        public string PARENT { get; set; }
        [XmlElement("TAXCLASSIFICATIONNAME")]
        public string TAXCLASSIFICATIONNAME { get; set; }
        [XmlElement("TAXTYPE")]
        public string TAXTYPE { get; set; }
        [XmlElement("EMAILCC")]
        public string EMAILCC { get; set; }
        [XmlElement("LEDGERPHONE")]
        public string LEDGERPHONE { get; set; }
        [XmlElement("LEDGERCONTACT")]
        public string LEDGERCONTACT { get; set; }
        [XmlElement("LEDGERMOBILE")]
        public string LEDGERMOBILE { get; set; }
        [XmlElement("ISBILLWISEON")]
        public string ISBILLWISEON { get; set; }
    }
    [Serializable]
    public class ADDRESS
    {
        [XmlElement("ADDRESS")]
        public string ADDRESSES { get; set; }
    }

    [Serializable]
    public class MAILINGNAME
    {
        [XmlElement("MAILINGNAME")]
        public string MAILINGNAMES { get; set; }
    }

    //VOUCHER XML DTOs
    [Serializable]
    public class VOUCHER
    {
        [XmlAttribute("VCHTYPE")]
        public string VCHTYPE { get; set; }
        [XmlAttribute("ACTION")]
        public string ACTION { get; set; }
        [XmlAttribute("OBJVIEW")]
        public string OBJVIEW { get; set; }

        [XmlElement("DATE")]
        public string VCHDATE { get; set; }
        [XmlElement("NARRATION")]
        public string NARRATION { get; set; }
        [XmlElement("VOUCHERTYPENAME")]
        public string VOUCHERTYPENAME { get; set; }
        [XmlElement("VOUCHERNUMBER")]
        public string VOUCHERNUMBER { get; set; }
        [XmlElement("PARTYLEDGERNAME")]
        public string PARTYLEDGERNAME { get; set; }
        [XmlElement("CSTFORMISSUETYPE")]
        public string CSTFORMISSUETYPE { get; set; }
        [XmlElement("CSTFORMRECVTYPE")]
        public string CSTFORMRECVTYPE { get; set; }
        [XmlElement("FBTPAYMENTTYPE")]
        public string FBTPAYMENTTYPE { get; set; }
        [XmlElement("PERSISTEDVIEW")]
        public string PERSISTEDVIEW { get; set; }
        [XmlElement("VCHGSTCLASS")]
        public string VCHGSTCLASS { get; set; }
        [XmlElement("VOUCHERTYPEORIGNAME")]
        public string VOUCHERTYPEORIGNAME { get; set; }
        [XmlElement("EFFECTIVEDATE")]
        public string EFFECTIVEDATE { get; set; }
        [XmlElement("HASCASHFLOW")]
        public string HASCASHFLOW { get; set; }

        [XmlElement("ALLLEDGERENTRIES.LIST")]
        public List<VLEDGERENTRY> BILLVLEDGERENTRIES { get; set; }
        
        [XmlElement("ALLLEDGERENTRIES.LIST")]
        public List<VLEDGERENTRY> BANKVLEDGERENTRIES { get; set; }
    }

    [Serializable]
    public class VLEDGERENTRY
    {
        [XmlElement("LEDGERNAME")]
        public string LEDGERNAME { get; set; }
        [XmlElement("GSTCLASS")]
        public string GSTCLASS { get; set; }
        [XmlElement("ISDEEMEDPOSITIVE")]
        public string ISDEEMEDPOSITIVE { get; set; }
        [XmlElement("LEDGERFROMITEM")]
        public string LEDGERFROMITEM { get; set; }
        [XmlElement("REMOVEZEROENTRIES")]
        public string REMOVEZEROENTRIES { get; set; }
        [XmlElement("ISPARTYLEDGER")]
        public string ISPARTYLEDGER { get; set; }
        [XmlElement("ISLASTDEEMEDPOSITIVE")]
        public string ISLASTDEEMEDPOSITIVE { get; set; }
        [XmlElement("AMOUNT")]
        public string AMOUNT { get; set; }
        [XmlElement("VATEXPAMOUNT")]
        public string VATEXPAMOUNT { get; set; }

        [XmlElement("BILLALLOCATIONS.LIST")]
        public List<BILLALLOCATION> BILLALLOCATIONS { get; set; }

        [XmlElement("BANKALLOCATIONS.LIST")]
        public List<BANKALLOCATION> BANKALLOCATIONS { get; set; }

    }

    [Serializable]
    public class BILLALLOCATION
    {
        [XmlElement("NAME")]
        public string NAME { get; set; }
        [XmlElement("BILLTYPE")]
        public string BILLTYPE { get; set; }
        [XmlElement("TDSDEDUCTEEISSPECIALRATE")]
        public string TDSDEDUCTEEISSPECIALRATE { get; set; }
        [XmlElement("AMOUNT")]
        public string AMOUNT { get; set; }
    }

    [Serializable]
    public class BANKALLOCATION
    {
        [XmlElement("DATE")]
        public string DATE { get; set; }
        [XmlElement("INSTRUMENTDATE")]
        public string INSTRUMENTDATE { get; set; }
        [XmlElement("NAME")]
        public string NAME { get; set; }
        [XmlElement("TRANSACTIONTYPE")]
        public string TRANSACTIONTYPE { get; set; }
        [XmlElement("PAYMENTFAVOURING")]
        public string PAYMENTFAVOURING { get; set; }
        [XmlElement("CHEQUECROSSCOMMENT")]
        public string CHEQUECROSSCOMMENT { get; set; }
        [XmlElement("INSTRUMENTNUMBER")]
        public string INSTRUMENTNUMBER { get; set; }
        [XmlElement("STATUS")]
        public string STATUS { get; set; }
        [XmlElement("PAYMENTMODE")]
        public string PAYMENTMODE { get; set; }
        [XmlElement("SECONDARYSTATUS")]
        public string SECONDARYSTATUS { get; set; }
        [XmlElement("BANKPARTYNAME")]
        public string BANKPARTYNAME { get; set; }
        [XmlElement("ISCONNECTEDPAYMENT")]
        public string ISCONNECTEDPAYMENT { get; set; }
        [XmlElement("ISSPLIT")]
        public string ISSPLIT { get; set; }
        [XmlElement("ISCONTRACTUSED")]
        public string ISCONTRACTUSED { get; set; }
        [XmlElement("AMOUNT")]
        public string AMOUNT { get; set; }
    }

}