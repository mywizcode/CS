using System;
using System.Text;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Iesi.Collections.Generic;


namespace ConstroSoft {
    
    public class MPTBook {
        public MPTBook()
        {
            this.MasterPymtTransactions = new HashSet<MasterPymtTransaction>();
        }
        public virtual long Id { get; set; }
        public virtual string Description { get; set; }
        public virtual PrUnitSaleDetail PrUnitSaleDetail { get; set; }
        public virtual Agency Agency { get; set; }
        public virtual ISet<MasterPymtTransaction> MasterPymtTransactions { get; set; }
    }
}
