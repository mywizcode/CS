﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.BO;
using CrystalDecisions.CrystalReports.Engine;

public partial class PaymentDueReport : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    DropdownBO drpBO = new DropdownBO();
    ReportConfigBO reportConfigBO = new ReportConfigBO();
    PaymentDueReportBO paymentDueReportBO = new PaymentDueReportBO();
    
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                PaymentDueReportNavDTO navDto = (PaymentDueReportNavDTO)Session[Constants.Session.NAV_DTO];
                Session.Remove(Constants.Session.NAV_DTO);
                Session.Remove(Constants.Session.PAGE_DATA);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
    }
    private void preRenderInitFormElements()
    {
        renderPageLayout();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpSelectTower, DrpDataType.PROPERTY_TOWER, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(), null, userDefDto.FirmNumber);      
    }
    
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(PaymentDueReportNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(PaymentDueReportNavDTO navDto)
    {
        try
        {
            PaymentDueReportPageDTO PaymentDueReportPageDTO = new PaymentDueReportPageDTO();
            Session[Constants.Session.PAGE_DATA] = PaymentDueReportPageDTO;
            PaymentDueReportPageDTO.PrevNavDTO = navDto.PrevNavDto;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    
    private void renderPageLayout()
    {
        setPageTitle();
    }
    private void setPageTitle()
    {
        
    }
    
    private PaymentDueReportPageDTO getSessionPageData()
    {
        return (PaymentDueReportPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private bool validateMandatoryFields()
    {
        bool isValid = true;
        Page.Validate(commonError);
        isValid = Page.IsValid;
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
   
    }
    public void onClickGenerateReport(object sender, EventArgs e)
    {
        try
        {
            if (validateMandatoryFields())
            {
                    UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
                    BusinessOutputTO businessOutputTO = null;
                    ReportConfigDTO reportConfigDTO = null;
                    long propertyId = 0, towerId = 0;
                    propertyId = CommonUtil.getCurrentPropertyDTO(userDefDto).Id;
                    towerId = long.Parse(drpSelectTower.Text);
                    IList<PrUnitSaleDetailDTO> results = new List<PrUnitSaleDetailDTO>();
                    results = paymentDueReportBO.fetchSoldPropertyUnits(userDefDto.FirmNumber, propertyId, towerId);
                    ReportDocument letterReportDocument = new ReportDocument();
                    businessOutputTO = paymentDueReportBO.processPaymentDueLetter(userDefDto.FirmNumber, results, propertyId);
                    reportConfigDTO = reportConfigBO.fetchReportConfiguration(userDefDto.FirmNumber, "Payment Due Report");
                    if (businessOutputTO.status == BusinessOutputTO.Status.SUCCESS)
                    {
                        if(results.Count > 0)
                        {
                            string reportPath = Server.MapPath(reportConfigDTO.ReportPath);                    
                            letterReportDocument.Load(reportPath);
                            letterReportDocument.Database.Tables["PropertyDetails"].SetDataSource(businessOutputTO.resultList[0]);
                            letterReportDocument.Database.Tables["PaymentDueReport"].SetDataSource(businessOutputTO.resultList[1]);
                            try
                            {
                                
                                letterReportDocument.ExportToHttpResponse
                                (CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, true, businessOutputTO.successMessage);
                            }
                            catch (Exception exp)
                            {
    
                            }
                        }else{
                            setErrorMessage(Resources.Messages.SOLD_UNIT_NOT_PRESENT, commonError);
                        }
                    }else{
                         setErrorMessage(businessOutputTO.errorMessage, commonError);  
                    }
             }
        }
        catch (Exception exp) {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
       }
    }

}