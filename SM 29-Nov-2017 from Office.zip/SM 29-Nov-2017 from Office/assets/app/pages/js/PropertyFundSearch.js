﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initPropertyFundSearchGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initPropertyFundSearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#propertyFundSearchBtnDiv",
        pageLength: 10
    };

    $("[id$='propertyFundSearchGrid']").CSBasicDatatable(dtOptions);
}




