//Common Icons used 
var ICON_ADD = "<i class=\"icon-googleplus5 position-left\"></i>";
var ICON_VIEW_DTL = "<i class=\"icon-grid position-left\"></i>";
var ICON_DELETE = "<i class=\"icon-bin position-left\"></i>";
var ICON_CONFIRM = "<i class=\"icon-question4 position-left\"></i>";
var CONFIRM = "CONFIRM";
var DELETE = "DELETE";
var SEP1 = "~~";
var SEP2 = "~";
//Modal should not close when clicked on backdrop(outside modal)
$.fn.modal.prototype.constructor.Constructor.DEFAULTS.backdrop = 'static';

function initFabMenu() {
    var $fabMenu = $("[id$='fabMenuRight']");
    if ($fabMenu.length) {
        $fabMenu.affix({
            offset: {
                top: $fabMenu.offset().top - 20
            }
        });
    }
}

//Block UI -> This method blocks panel when any element (having class 'block-ui-click') is clicked.
function bindBlockUI(controlToFormat) {
    var blockUiContent = $("<div class=\"blockui-animation-container\"><span class=\"text-semibold\"><i class=\"icon-spinner10 spinner position-left\"></i>&nbsp; Please Wait...</span></div>");
    $(controlToFormat).find('.block-ui-click').on('click', function () {
        var block = $('.' + $(this).attr('data-panel'));
        $(block).block({
            message: blockUiContent,
            overlayCSS: {
                backgroundColor: '#fff',
                opacity: 0.8,
                cursor: 'wait'
            },
            css: {
                border: 0,
                padding: '10px 15px',
                color: '#fff',
                width: 'auto',
                '-webkit-border-radius': 2,
                '-moz-border-radius': 2,
                backgroundColor: 'transparent'
            }
        });
        blockUiContent.addClass("animated fadeInDown").one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function () {
            $(this).removeClass("animated fadeInDown");
        });
    });
    $(controlToFormat).find('.block-ui-change').on('change', function () {
        var block = $('.' + $(this).attr('data-panel'));
        $(block).block({
            message: blockUiContent,
            overlayCSS: {
                backgroundColor: '#fff',
                opacity: 0.8,
                cursor: 'wait'
            },
            css: {
                border: 0,
                padding: '10px 15px',
                color: '#fff',
                width: 'auto',
                '-webkit-border-radius': 2,
                '-moz-border-radius': 2,
                backgroundColor: 'transparent'
            }
        });
        blockUiContent.addClass("animated fadeInDown").one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function () {
            $(this).removeClass("animated fadeInDown");
        });
    });
}
function initNotyMsg() {
    var msgValue = $("[id$='NotyMsg']").val();
    if (msgValue && msgValue != "") {
        var arrMsgValue = msgValue.split(SEP1);
        var isKiller = true;
        $.each(arrMsgValue, function (index, value) {
        	var recs = value.split(SEP2);
        	noty({
                width: 200,
                text: recs[1],
                type: recs[0],
                dismissQueue: true,
                timeout: 6000,
                layout: 'top',
                killer: isKiller
        	});
        	isKiller = false;
        });
    }
    $("[id$='NotyMsg']").val('');
}

function initNotifications(controlToFormat) {
    $(controlToFormat).find('li.alert-notification').each(function () {
        $this = $(this);
        var unformattedMsg = $(this).find('div.message').html();
        if (unformattedMsg != 'undefined' && unformattedMsg != "") {
            var arrMsgValue = unformattedMsg.split(SEP1);
            var tmpMsg = arrMsgValue[0];
            if (arrMsgValue[1] != "") {
                var params = arrMsgValue[1].split(SEP2);
                $.each(params, function (i, n) {
                    tmpMsg = tmpMsg.replace(new RegExp("\\{" + i + "\\}", "g"), getNotificationMsgPlaceHolder(n));
                });
            }
            $this.find('div.message').html(tmpMsg);
        }
    });
}
function getNotificationMsgPlaceHolder(param) {
    if (param.startsWith("LINK:")) {
        return "<a href=\"javascript:void(0)\" onclick=\"clickNotificationAlert(this);\">"+param.replace("LINK:", "")+"</a>"
    } else if (param.startsWith("BOLD:")) {
        return "<span class=\"text-semibold\">" + param.replace("BOLD:", "") + "</span>"
    }
    return "";
}
function clickNotificationAlert(element) {
    $(element).closest('div.media-body').find('.notificationAction').click();
}

function ValidateNumberOnly(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 46 || charCode > 57)) {
        event.returnValue = false;
    }
}