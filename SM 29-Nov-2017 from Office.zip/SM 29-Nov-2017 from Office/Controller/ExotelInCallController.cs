﻿using Newtonsoft.Json;
using System;
using System.Web.Http;

namespace ConstroSoft.Controller
{
    public class ExotelInCallController : ApiController
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        CallHistoryBO callHistoryBO = new CallHistoryBO();

        [HttpGet]
        [ActionName("GetInCallDetails")]
        public string GetInCallDetails([FromBody]InOutBoundCallResDTO inOutBoundCallResDTO)
        {
            var response = JsonConvert.SerializeObject("Failure");
            try
            {
                //Validate the InOutBoundCallResDTO Mandatory Fields.
                if (inOutBoundCallResDTO != null && inOutBoundCallResDTO.Call != null && !string.IsNullOrEmpty(inOutBoundCallResDTO.Call.Sid))
                {
                    inOutBoundCallResDTO.Call.FirmNumber = Constants.EXOTEL.EXOTEL_FIRMNUMBER;
                    inOutBoundCallResDTO.Call.InsertUser = Constants.EXOTEL.EXOTEL_SID;
                    inOutBoundCallResDTO.Call.UpdateUser = Constants.EXOTEL.EXOTEL_SID;
                    callHistoryBO.addCallHistory(inOutBoundCallResDTO.Call);
                }else{
                    log.Error("ExotelOutCallController: CallSid is Missing");
                }
                //Add Notificatoion to user about incoming call.
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while placing outbound call");
                log.Error(exp.Message, exp);
            }
            finally
            {
            }
            return response;
        }
    }
}