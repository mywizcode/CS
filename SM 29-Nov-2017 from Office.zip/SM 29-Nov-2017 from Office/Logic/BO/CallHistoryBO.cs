﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;


/// <summary>
/// Summary description for CallHistoryBO
/// </summary>
namespace ConstroSoft
{
    public class CallHistoryBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public CallHistoryBO() { }
        
        public IList<Call> fetchCallHistory(string firmNumber)
        {
            ISession session = null;
            IList<Call> results = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                CallHistory ch = null;
                var query = session.QueryOver<CallHistory>(() => ch);
                results = query.Where(() => ch.FirmNumber == firmNumber && ch.Direction == CallDirection.inbound 
                    && ch.Status == CallStatus.inprogress).TransformUsing(new DeepTransformer<Call>()).List<Call>();
                results.ToList();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating call details:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }
        
        public void addCallHistory(Call call)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        CallHistory callHistory = DTOToDomainUtil.populateCallHistoryAddFields(call);
                        session.Save(callHistory);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while adding Call History:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void updateCallHistory(Call call)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        CallHistory callHistory = null;
                        var query = session.QueryOver<CallHistory>(() => callHistory);
                        callHistory = query.Where(x => x.Sid == call.Sid).SingleOrDefault();
                        DTOToDomainUtil.populateCallHistoryUpdateFields(callHistory, call);
                        session.Update(callHistory);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating Call History details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }

    }
}