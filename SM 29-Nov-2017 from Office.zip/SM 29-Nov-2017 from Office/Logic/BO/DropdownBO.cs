﻿using System;
using System.Web.UI.WebControls;
using NHibernate;
using System.Collections;
using System.Collections.Generic;
using NHibernate.Criterion;
using System.Linq;

/// <summary>
/// Summary description for DropdownBO
/// </summary>
namespace ConstroSoft
{
    public class DropdownBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public DropdownBO() { }
        public void populateDrpEnqActivity(DropDownList drp)
        {
            drp.Items.Clear();
            drp.Items.Add(new ListItem(Constants.SELECT_ITEM[0], Constants.SELECT_ITEM[1]));
            drp.Items.Add(new ListItem(EnqActivityType.SITE_VISIT.GetDescription(), EnqActivityType.SITE_VISIT.ToString()));
            drp.Items.Add(new ListItem(EnqActivityType.MEETING.GetDescription(), EnqActivityType.MEETING.ToString()));
            drp.Items.Add(new ListItem(EnqActivityType.FOLLOW_UP.GetDescription(), EnqActivityType.FOLLOW_UP.ToString()));
        }
        public void populateDrpEnqEventActivity(DropDownList drp)
        {
            drp.Items.Clear();
            drp.Items.Add(new ListItem(Constants.SELECT_ITEM[0], Constants.SELECT_ITEM[1]));
            drp.Items.Add(new ListItem(EnqActivityType.SITE_VISIT.GetDescription(), EnqActivityType.SITE_VISIT.ToString()));
            drp.Items.Add(new ListItem(EnqActivityType.MEETING.GetDescription(), EnqActivityType.MEETING.ToString()));
            drp.Items.Add(new ListItem(EnqActivityType.FOLLOW_UP.GetDescription(), EnqActivityType.FOLLOW_UP.ToString()));
            drp.Items.Add(new ListItem(EnqActivityType.TASK.GetDescription(), EnqActivityType.TASK.ToString()));
        }
        public void populateDrpPRStageNo(DropDownList drp)
        {
            drp.Items.Clear();
            for (int i = 1; i <= 30; i++)
            {
                drp.Items.Add(new ListItem(i + "", i + ""));
            }
        }
        public void drpEnum<T>(DropDownList drp, string[] firstItem)
        {
            drp.Items.Clear();
            string[] arr = Enum.GetNames(typeof(T));
            foreach (string x in arr)
            {
                string description = EnumHelper.GetEnumDescription<T>(x);
                drp.Items.Add(new ListItem(description, x));
            }
            if (firstItem != null) drp.Items.Insert(0, new ListItem(firstItem[0], firstItem[1]));
        }
        public void drpEnum<T>(DropDownList drp, string[] firstItem, List<string> removeItems)
        {
            drp.Items.Clear();
            string[] arr = Enum.GetNames(typeof(T));
            foreach (string x in arr)
            {
                if (!removeItems.Contains(x))
                {
                    string description = EnumHelper.GetEnumDescription<T>(x);
                    drp.Items.Add(new ListItem(description, x));
                }
            }
            if (firstItem != null) drp.Items.Insert(0, new ListItem(firstItem[0], firstItem[1]));
        }
        public void drpInit(DropDownList drp, string[] firstItem)
        {
            drp.Items.Clear();
            if (firstItem != null) drp.Items.Insert(0, new ListItem(firstItem[0], firstItem[1]));
        }
        public void drpDataBase(DropDownList drp, DrpDataType drpDataType, string additionalInfo, string[] firstItem, string firmNumber)
        {
            ISession session = null;
            try
            {
                drp.Items.Clear();
                if (firstItem != null) drp.Items.Add(new ListItem(firstItem[0], firstItem[1]));
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        IList<object[]> result = getDrpItems(session, drpDataType, additionalInfo, firmNumber);
                        addItemsToDropDown(drp, result);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Unexpected error populating dropdown:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }

        private IList<object[]> getDrpItems(ISession session, DrpDataType drpDataType, string additionalInfo, string firmNumber)
        {
            IList<object[]> result = null;
            if (DrpDataType.MASTER_CONTROL_DATA == drpDataType)
            {
                result = session.QueryOver<MasterControlData>().Select(c => c.Name,
                            c => c.Id).Where(c => c.FirmNumber == firmNumber && c.Type == additionalInfo).List<object[]>();
            }
            else if (DrpDataType.MASTER_CONTROL_DATA_N == drpDataType)
            {
                result = session.QueryOver<MasterControlData>().Select(c => c.Name,
                            c => c.Id).Where(c => c.FirmNumber == firmNumber && c.Type == additionalInfo && c.SystemDefined == SystemDefined.No).List<object[]>();
            }
            else if (DrpDataType.COUNTRY == drpDataType)
            {
                result = session.QueryOver<Country>().Select(p => p.Name, p => p.Id).List<object[]>();
            }
            else if (DrpDataType.SECURITY_QUESTION == drpDataType)
            {
                result = session.QueryOver<SecurityQuestion>().Select(p => p.Question, p => p.Id).List<object[]>();
            }
            else if (DrpDataType.STATE == drpDataType && !string.IsNullOrWhiteSpace(additionalInfo))
            {
                State s = null;
                Country c = null;
                result = session.QueryOver<State>(() => s).JoinAlias(() => s.Country, () => c).Where(() => c.Id == long.Parse(additionalInfo))
                        .Select(p => p.Name, p => p.Id).List<object[]>();
            }
            else if (DrpDataType.CITY == drpDataType && !string.IsNullOrWhiteSpace(additionalInfo))
            {
                City s = null;
                State c = null;
                result = session.QueryOver<City>(() => s).JoinAlias(() => s.State, () => c).Where(() => c.Id == long.Parse(additionalInfo))
                        .Select(p => p.Name, p => p.Id).List<object[]>();
            }
            else if (DrpDataType.ENQUIRY_REFERENCE_NUMBER == drpDataType)
            {
                EnquiryDetail eq = null;
                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => eq.EnquiryRefNo))
                            .Add(Projections.Property(() => eq.Id));
                result = session.QueryOver<EnquiryDetail>(() => eq).Select(proj)
                        .Where(() => eq.FirmNumber == firmNumber && eq.Status == EnquiryStatus.Open).List<object[]>();
            }
            else if (DrpDataType.PROPERTY_NAME == drpDataType)
            {

                Property p = null;
                PropertyFMAccess pfa = null;
                FirmMember fm = null;
                result = session.QueryOver<Property>(() => p).JoinAlias(() => p.PropertyFMAccess, () => pfa).JoinAlias(() => pfa.FirmMember, () => fm)
                    .Where(() => p.FirmNumber == firmNumber && fm.Id == long.Parse(additionalInfo) && pfa.HasAccess == PrFMAccess.Yes)
                   .Select(s => s.Name, s => s.Id).List<object[]>();
            }
            else if (DrpDataType.PROPERTY_TOWER == drpDataType && !string.IsNullOrWhiteSpace(additionalInfo))
            {
                PropertyTower pt = null;
                Property p = null;
                result = session.QueryOver<PropertyTower>(() => pt).JoinAlias(() => pt.Property, () => p).Where(() => p.FirmNumber == firmNumber
                    && p.Id == long.Parse(additionalInfo))
                    .Select(s => s.Name, s => s.Id).List<object[]>();
            }
           
            else if (DrpDataType.FIRM_ACCOUNT == drpDataType)
            {
                result = session.QueryOver<FirmAccount>().Select(p => p.Name, p => p.Id)
                        .Where(p => p.FirmNumber == firmNumber).List<object[]>();
            }
            else if (DrpDataType.ACTIVE_USERS_WITH_PR_ACCESS == drpDataType && !string.IsNullOrWhiteSpace(additionalInfo))
            {
                FirmMember fm = null;
                UserDefinition ud = null;
                PropertyFMAccess pfa = null;
                Property p = null;
                var proj = Projections.ProjectionList()
                           .Add(Projections.SqlFunction("concat",
                                       NHibernateUtil.String,
                                       Projections.Property(() => fm.FirstName),
                                       Projections.Constant(" "),
                                       Projections.Property(() => fm.LastName)))
                           .Add(Projections.Property(() => fm.Id));
                result = session.QueryOver<FirmMember>(() => fm)
                		.Inner.JoinAlias(() => fm.User, () => ud)
                        .Inner.JoinAlias(() => fm.PropertyFMAccess, () => pfa)
                        .Inner.JoinAlias(() => pfa.Property, () => p)
                		.Select(proj)
                        .Where(() => p.Id == long.Parse(additionalInfo) && ud.Status == UserStatus.Active && pfa.HasAccess == PrFMAccess.Yes).List<object[]>();
            }
            else if (DrpDataType.PR_AVAILABLE_PARKING == drpDataType && !string.IsNullOrWhiteSpace(additionalInfo))
            {
                PropertyParking parking = null;
                PropertyTower pt = null;
                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => parking.ParkingNo))
                            .Add(Projections.Property(() => parking.Id));
                result = session.QueryOver<PropertyParking>(() => parking)
                        .Left.JoinAlias(() => parking.PropertyTower, () => pt)
                        .Select(proj)
                        .Where(p => p.FirmNumber == firmNumber && pt.Id == long.Parse(additionalInfo) && parking.Status == ParkingStatus.Available).List<object[]>();
            }
            else if (DrpDataType.CUSTOMER_SEARCH_BY_NAME_REF == drpDataType)
            {
                Customer cm = null;
                var proj = Projections.ProjectionList()
                            .Add(Projections.SqlFunction("concat",
                                        NHibernateUtil.String,
                                        Projections.Property(() => cm.FirstName),
                                        Projections.Constant(" "),
                                        Projections.Property(() => cm.LastName),
                                        Projections.Constant(" - "),
                                        Projections.Property(() => cm.CustRefNo)))
                            .Add(Projections.Property(() => cm.Id));
                result = session.QueryOver<Customer>(() => cm).Select(proj)
                        .Where(p => p.FirmNumber == firmNumber).List<object[]>();
            }
            else if (DrpDataType.CUSTOMER_SEARCH_BY_NAME == drpDataType)
            {
                Customer cm = null;
                var proj = Projections.ProjectionList()
                            .Add(Projections.SqlFunction("concat",
                                        NHibernateUtil.String,
                                        Projections.Property(() => cm.FirstName),
                                        Projections.Constant(" "),
                                        Projections.Property(() => cm.LastName)))
                            .Add(Projections.Property(() => cm.Id));
                result = session.QueryOver<Customer>(() => cm).Select(proj)
                        .Where(p => p.FirmNumber == firmNumber).List<object[]>();
            }
            else if (DrpDataType.PR_AVAILABLE_UNIT == drpDataType && !string.IsNullOrWhiteSpace(additionalInfo))
            {
                PropertyUnit p = null;
                PropertyTower pt = null;
                var proj = Projections.ProjectionList()
                            .Add(Projections.SqlFunction("concat",
                                        NHibernateUtil.String,
                                        Projections.Property(() => p.Wing),
                                        Projections.Constant("-"),
                                        Projections.Property(() => p.UnitNo)))
                            .Add(Projections.Property(() => p.Id));
                result = session.QueryOver<PropertyUnit>(() => p)
                        .Left.JoinAlias(() => p.PropertyTower, () => pt)
                        .Select(proj)
                        .Where(() => p.FirmNumber == firmNumber && pt.Id == long.Parse(additionalInfo) && p.Status == PRUnitStatus.Available).List<object[]>();
            }
            else if (DrpDataType.PR_TOWER_UNITS == drpDataType && !string.IsNullOrWhiteSpace(additionalInfo))
            {
                PropertyUnit pu = null;
                PropertyTower pt = null;
                var proj = Projections.ProjectionList()
                            .Add(Projections.Distinct(Projections.SqlFunction("concat",
                                        NHibernateUtil.String,
                                        Projections.Property(() => pu.Wing),
                                        Projections.Constant("-"),
                                        Projections.Property(() => pu.UnitNo))))
                            .Add(Projections.Property(() => pu.Id));
                var query = session.QueryOver<PropertyUnit>(() => pu)
                    .Left.JoinAlias(() => pu.PropertyTower, () => pt);
                result = query.Where(() => pu.FirmNumber == firmNumber && pt.Id == long.Parse(additionalInfo))
                    .Select(proj).List<object[]>();
            }
            else if (DrpDataType.PR_TOWER_SOLD_UNITS == drpDataType && !string.IsNullOrWhiteSpace(additionalInfo))
            {
                PropertyUnit pu = null;
                PropertyTower pt = null;
                var proj = Projections.ProjectionList()
                            .Add(Projections.Distinct(Projections.SqlFunction("concat",
                                        NHibernateUtil.String,
                                        Projections.Property(() => pu.Wing),
                                        Projections.Constant("-"),
                                        Projections.Property(() => pu.UnitNo))))
                            .Add(Projections.Property(() => pu.Id));
                var query = session.QueryOver<PropertyUnit>(() => pu)
                    .Left.JoinAlias(() => pu.PropertyTower, () => pt);
                result = query.Where(() => pu.FirmNumber == firmNumber && pt.Id == long.Parse(additionalInfo) && pu.Status == PRUnitStatus.Sold)
                    .Select(proj).List<object[]>();
            }
            else if (DrpDataType.PR_PARKING_SEARCH_BY_PARKINGNO == drpDataType && !string.IsNullOrWhiteSpace(additionalInfo))
            {
                PropertyParking pp = null;
                PropertyTower pt = null;
                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => pp.ParkingNo))
                            .Add(Projections.Property(() => pp.Id));
                var query = session.QueryOver<PropertyParking>(() => pp)
                    .Left.JoinAlias(() => pp.PropertyTower, () => pt);
                result = query.Where(() => pp.FirmNumber == firmNumber && pt.Id == long.Parse(additionalInfo))
                    .Select(proj).List<object[]>();
            }
            else if (DrpDataType.COMPLETED_SCHEDULE_STAGE == drpDataType && !string.IsNullOrWhiteSpace(additionalInfo))
            {
                PropertySchedule ps = null;
                PropertyTower pt = null;
                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => ps.StageAbbr))
                            .Add(Projections.Property(() => ps.Id));
                var query = session.QueryOver<PropertySchedule>(() => ps)
                    .Left.JoinAlias(() => ps.PropertyTower, () => pt);
                result = query.Where(() => pt.Id == long.Parse(additionalInfo) && ps.Status == PRScheduleStageStatus.Completed)
                    .Select(proj).List<object[]>();
            }
            return result;
        }
        private void addItemsToDropDown(DropDownList drp, IList<object[]> result)
        {
            if (result != null)
            {
                foreach (object[] obj in result)
                {
                    drp.Items.Add(new ListItem((string)obj[0], obj[1] + ""));
                }
            }
        }
    }
}