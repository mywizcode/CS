﻿using ConstroSoft.Logic.CachingProvider;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web;
using System.Web.Http;

namespace ConstroSoft.Controller
{
    public class ExotelInCallIntimationController : ApiController
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        CallHistoryBO callHistoryBO = new CallHistoryBO();
        NotificationBO notificationBO = new NotificationBO();

        [HttpGet]
        [ActionName("GetInCallIntimation")]
        public void GetInCallIntimation()
        {
            try
            {
                //Fetch CALL_HISTORY record from DB for CALLSID
                string CallSid = HttpContext.Current.Request.Params["CallSid"];
                string DialWhomNumber = HttpContext.Current.Request.Params["DialWhomNumber"];
                string Status = HttpContext.Current.Request.Params["Status"];
                CallHistoryDTO callHistoryDTO = callHistoryBO.fetchCallHistoryforCallSID(CallSid);
                FirmMemberDTO firmMemberDTO = null;
                firmMemberDTO = callHistoryBO.fetchAgent(DialWhomNumber.TrimStart('0'));
                if(callHistoryDTO != null){
                    //Check Agent number in CALL_HISTORY is same as agent number in intimation request.
                    if(callHistoryDTO.CalleeNumber.Equals(DialWhomNumber))
                    {
                        if(Status.Equals("free"))
                        {
                            notificationBO.removeUserNotificationsForInCall(firmMemberDTO.UserDefinition, callHistoryDTO);
                        }
                    }
                    else
                    {
                        if(Status.Equals("busy"))
                        {
                            //Find new agent for new call number and update agent and new call history info into CALL_HISTORY table.
                            callHistoryDTO = populateCallHistoryDTOFromCall(HttpContext.Current.Request.Params);
                            callHistoryDTO.FirmMember = firmMemberDTO;
                            long callHistoryId = callHistoryBO.updateCallHistoryForIntimation(callHistoryDTO);
                            callHistoryDTO.Id = callHistoryId;
                            notificationBO.createUserNotificationsForInCall(firmMemberDTO.UserDefinition, callHistoryDTO);
                        }
                    }
                }
                else
                {
                    callHistoryDTO = populateCallHistoryDTOFromCall(HttpContext.Current.Request.Params);
                    callHistoryDTO.FirmMember = firmMemberDTO;
                    long callHistoryId = callHistoryBO.addCallHistory(callHistoryDTO);
                    callHistoryDTO.Id = callHistoryId;
                    notificationBO.createUserNotificationsForInCall(firmMemberDTO.UserDefinition, callHistoryDTO);
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while getting inbound call details.");
                log.Error(exp.Message, exp);
            }
            finally
            {
            }
        }

        public static CallHistoryDTO populateCallHistoryDTOFromCall(NameValueCollection parameters)
        {
            CallHistoryDTO callHistoryDTO = new CallHistoryDTO();
            callHistoryDTO.CallSid = parameters["CallSid"];
            callHistoryDTO.CallerNumber = parameters["CallFrom"];
            callHistoryDTO.PhoneNumberSid = parameters["CallTo"];
            callHistoryDTO.Direction = CallDirection.Incoming;
            callHistoryDTO.DateCreated = Convert.ToDateTime(parameters["Created"]);
            callHistoryDTO.DateUpdated = Convert.ToDateTime(parameters["Created"]);
            callHistoryDTO.StartTime = Convert.ToDateTime(parameters["Created"]);
            callHistoryDTO.CalleeNumber = parameters["DialWhomNumber"];
            callHistoryDTO.CallStatus = CommonUtil.getCallStatus(parameters["Status"].ToString());
            callHistoryDTO.FirmNumber = Constants.EXOTEL.EXOTEL_FIRMNUMBER;
            callHistoryDTO.AccountSid = Constants.EXOTEL.EXOTEL_SID;
            callHistoryDTO.InsertUser = Constants.EXOTEL.EXOTEL_SID;
            callHistoryDTO.UpdateUser = Constants.EXOTEL.EXOTEL_SID;
            callHistoryDTO.InsertDate = DateTime.Now;
            callHistoryDTO.UpdateDate = DateTime.Now;
            callHistoryDTO.CallHistoryStatus = CallHistoryStatus.Unresolved;
            return callHistoryDTO;
        }
    }
}