﻿using ConstroSoft.Logic.CachingProvider;
using Newtonsoft.Json;
using System;
using System.Collections.Specialized;
using System.Web;
using System.Web.Http;

namespace ConstroSoft.Controller
{
    public class ExotelInCallController : ApiController
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        CallHistoryBO callHistoryBO = new CallHistoryBO();
        NotificationBO notificationBO = new NotificationBO();

        [HttpGet]
        [ActionName("GetInCallDetails")]
        public void GetInCallDetails()
        {
            FirmMemberDTO firmMemberDTO = null;
            CallHistoryDTO callHistoryDTO = null;
            try
            {
                //Update CALL_HISTORY record
                string CallSid = HttpContext.Current.Request.Params["CallSid"];
                string DialWhomNumber = HttpContext.Current.Request.Params["DialWhomNumber"];
                firmMemberDTO = callHistoryBO.fetchAgent(DialWhomNumber.TrimStart('0'));
                callHistoryDTO = callHistoryBO.fetchCallHistoryforCallSID(CallSid);
                callHistoryDTO.FirmMember = firmMemberDTO;
                populateCallHistoryDTOFromCall(HttpContext.Current.Request.Params, callHistoryDTO);
                callHistoryBO.updateCallHistory(callHistoryDTO);
                notificationBO.removeAllUserNotificationsForPassthrough(firmMemberDTO.UserDefinition, callHistoryDTO);
                if (callHistoryDTO.CallHistoryStatus.Equals(CallHistoryStatus.Unresolved))
                {
                    NotificationCacheProvider.Instance.markUnResolvedFlag();
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while getting inbound call details.");
                log.Error(exp.Message, exp);
            }
            
            finally
            {
            }
        }
        public static CallHistoryDTO populateCallHistoryDTOFromCall(NameValueCollection parameters, CallHistoryDTO callHistoryDTO)
        {
            callHistoryDTO.CallSid = parameters["CallSid"];
            callHistoryDTO.CallerNumber = parameters["CallFrom"];
            callHistoryDTO.PhoneNumberSid = parameters["CallTo"];
            callHistoryDTO.Direction = CallDirection.Incoming;
            callHistoryDTO.DateCreated = Convert.ToDateTime(parameters["Created"]);
            callHistoryDTO.Duration = Convert.ToInt64(parameters["DialCallDuration"]);
            callHistoryDTO.RecordingUrl = parameters["RecordingUrl"];
            callHistoryDTO.StartTime = Convert.ToDateTime(parameters["StartTime"]);
            callHistoryDTO.EndTime = Convert.ToDateTime(parameters["EndTime"]);
            callHistoryDTO.CallStatus = CommonUtil.getCallStatus(parameters["DialCallStatus"].ToString());
            callHistoryDTO.DateUpdated = Convert.ToDateTime(parameters["Created"]);
            callHistoryDTO.CalleeNumber = parameters["DialWhomNumber"];
            callHistoryDTO.FirmNumber = Constants.EXOTEL.EXOTEL_FIRMNUMBER;
            callHistoryDTO.AccountSid = Constants.EXOTEL.EXOTEL_SID;
            callHistoryDTO.UpdateUser = Constants.EXOTEL.EXOTEL_SID;
            callHistoryDTO.UpdateDate = DateTime.Now;
            callHistoryDTO.CallHistoryStatus = CallHistoryStatus.Unresolved;
            return callHistoryDTO;
        }
    }
}