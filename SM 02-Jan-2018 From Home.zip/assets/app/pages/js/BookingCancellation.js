﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initPymtGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}
function initPymtGrid() {
    var dtOptions = {
        hasActionColumn: false,
        hideSearch: true,
        pagination: false,
        sorting: false
    };

    $("[id$='PymtDetailGrid']").CSBasicDatatable(dtOptions);
}