﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.BO;

public partial class UnitBookingSuccess : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";

    SoldPropertyUnitBO soldUnitBO = new SoldPropertyUnitBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                BookingSuccessNavDTO navDto = CommonUtil.getPageNavDTO<BookingSuccessNavDTO>(Session);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
    	ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {

    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
    }
    private void renderPageFieldsWithEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        lnkBookingDetailsBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_SOLD_PR_UNIT);
        lnkAddPaymentBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PAYMENT_ADD);
    }
    private void doInit(BookingSuccessNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new BookingSuccessPageDTO();
        if (navDto != null)
        {
            initPageAfterRedirect(navDto);
        }
        else
        {
            Response.Redirect(Constants.URL.AVAILABLE_UNIT_SEARCH, true);
        }
    }
    private void initPageAfterRedirect(BookingSuccessNavDTO navDto)
    {
        try
        {
            PrUnitSaleDetailDTO saleDetailDTO = soldUnitBO.fetchBookingSuccessDetails(navDto.PrUnitSaleDetailId);
            lbCustomerName.Text = CommonUIConverter.getCustomerFullName(saleDetailDTO.Customer.Salutation.Name, saleDetailDTO.Customer.FirstName,
                "", saleDetailDTO.Customer.LastName);
            PropertyUnitDTO unitDto = saleDetailDTO.PropertyUnit;
            getSessionPageData().UnitSaleDetailDTO = saleDetailDTO;
            btnBookUnitInfoHdn.Attributes["row-info"] = CommonUIConverter.getGridViewRowInfo(unitDto);
            lbBookProperty.Text = CommonUIConverter.getPropertyDTO(CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()).Id.ToString(), null).Name;
            lbBookTower.Text = unitDto.PropertyTower.Name;
            lbBookWing.Text = unitDto.Wing;
            lbBookUnitNo.Text = unitDto.UnitNo;
            lbBookUnitType.Text = unitDto.UnitType.Name;
            lbBookingRefNo.Text = saleDetailDTO.BookingRefNo;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private BookingSuccessPageDTO getSessionPageData()
    {
        return (BookingSuccessPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private void initPageInfo()
    {

    }
    protected void goToSoldUnitPage(object sender, EventArgs e)
    {
        try
        {
            PrUnitSaleDetailDTO saleDetailDTO = getSessionPageData().UnitSaleDetailDTO;
            SoldUnitDetailNavDTO navDTO = new SoldUnitDetailNavDTO();
            navDTO.Mode = PageMode.VIEW;
            navDTO.PrUnitSaleDetailId = saleDetailDTO.Id;
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.SOLD_UNIT_DETAILS, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void goToAddPaymentPage(object sender, EventArgs e)
    {
        try
        {
            CustomerPaymentNavDTO navDTO = new CustomerPaymentNavDTO();
            navDTO.IsPdcPayment = false;
            navDTO.Mode = PageMode.ADD;
            navDTO.PymtMode = PaymentMode.Receivable;
            navDTO.PrUnitSaleDetailId = getSessionPageData().UnitSaleDetailDTO.Id;
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.CUSTOMER_PYMT_ADD, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
}