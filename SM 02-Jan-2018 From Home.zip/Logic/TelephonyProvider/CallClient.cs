﻿
using ConstroSoft.TelephonyProvider.ExotelProvider;
using RestSharp;
using System;


/// <summary>
/// Summary description for FBIntegrationBO
/// </summary>
namespace ConstroSoft.TelephonyProvider
{
    public class CallClient
    {

        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        
        public CallClient()
        {

        }

        public CallHistoryDTO placeOutBoundCall(string agentPhoneNumber, string customerNumber, UserDefinitionDTO userDefDTO)
        {
            CallHistoryDTO callHistoryDTO = null;
            try
            {
               if(Constants.EXOTEL.CALL_PROVIDER.Equals("EXOTEL")){
                   ExotelClient exotelClient = new ExotelClient();
                   callHistoryDTO = exotelClient.placeOutBoundCall(agentPhoneNumber, customerNumber, userDefDTO);
               }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while placing outbound call");
                log.Error(exp.Message, exp);
                throw new CustomException("Unable to place a call. Please contact system administrator.");
            }
            finally
            {
            }
            return callHistoryDTO;
        }
    }
}