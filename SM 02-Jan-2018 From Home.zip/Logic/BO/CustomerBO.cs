﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq.Expressions;
using NHibernate.Impl;
using System.Linq;

/// <summary>
/// Summary description for CustomerBO
/// </summary>
namespace ConstroSoft
{
    public class CustomerBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public CustomerBO() { }

        public IList<CustomerDTO> fetchCustomerGridData(string firmNumber, CustomerFilterDTO filterDTO)
        {
            ISession session = null;
            IList<CustomerDTO> result = new List<CustomerDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                Customer cm = null;
                ContactInfo c = null;
                CustomerDTO cmDto = null;
                var proj = Projections.ProjectionList()
                           .Add(Projections.Property(() => cm.Id).WithAlias(() => cmDto.Id))
                           .Add(Projections.SqlFunction("concat",
                                       NHibernateUtil.String,
                                       Projections.Property(() => cm.FirstName),
                                       Projections.Constant(" "),
                                       Projections.Property(() => cm.LastName)
                                   ).WithAlias(() => cm.FirstName))
                            .Add(Projections.Property(() => cm.CustRefNo).WithAlias(() => cmDto.CustRefNo))
                           .Add(Projections.Property(() => cm.Pan).WithAlias(() => cmDto.Pan))
                           .Add(Projections.Property(() => c.Contact), "ContactInfo.Contact")
                           .Add(Projections.Property(() => c.AltContact), "ContactInfo.AltContact")
                           .Add(Projections.Property(() => c.Email), "ContactInfo.Email")
                           .Add(Projections.Property(() => c.Gender), "ContactInfo.Gender")
                           .Add(Projections.Property(() => c.Dob), "ContactInfo.Dob")
                           .Add(Projections.Property(() => c.AltEmail), "ContactInfo.AltEmail");
                var query = session.QueryOver<Customer>(() => cm)
                    .Inner.JoinAlias(() => cm.ContactInfo, () => c);
                if (filterDTO != null)
                {
                    ICriteria criteria = query.RootCriteria;
                    if (!string.IsNullOrWhiteSpace(filterDTO.FirstName))
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<Customer>(() => cm, x => x.FirstName), filterDTO.FirstName));
                    }
                    if (!string.IsNullOrWhiteSpace(filterDTO.LastName))
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<Customer>(() => cm, x => x.LastName), filterDTO.LastName));
                    }
                    if (filterDTO.Dob != null)
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<ContactInfo>(() => c, x => x.Dob), filterDTO.Dob));
                    }
                    if (!string.IsNullOrWhiteSpace(filterDTO.Contact))
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<ContactInfo>(() => c, x => x.Contact), filterDTO.Contact));
                    }
                    if (!string.IsNullOrWhiteSpace(filterDTO.CustRefNo))
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<Customer>(() => cm, x => x.CustRefNo), filterDTO.CustRefNo));
                    }
                }
                result = query.Where(() => cm.FirmNumber == firmNumber)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<CustomerDTO>()).List<CustomerDTO>();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating dropdown:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public IList<VwCustomer> fetchMatchingCustomersForUnresolvedCall(string contact)
        {
            ISession session = null;
            IList<VwCustomer> allCustomerList = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	VwCustomer vw = null;
                    	
                    	allCustomerList = session.QueryOver<VwCustomer>(() => vw)
                    		 .Where(() => vw.Contact == contact || vw.AltContact == contact)
                             .List<VwCustomer>();
                    	if(allCustomerList != null) {
                    		foreach(VwCustomer tmpCust in allCustomerList){
                    			tmpCust.FullName = CommonUIConverter.getCustomerFullName(tmpCust.Salutation, tmpCust.FirstName, tmpCust.LastName);
                    			tmpCust.UIUnitNo = CommonUIConverter.getPropertyUnitFormattedNo(tmpCust.Wing, tmpCust.UnitNo);
                                
                                VwCustomerEntityType tmpType = CommonUtil.getVwCustomerType(tmpCust.EntityType);

                                if (VwCustomerEntityType.Enquiry == tmpType) tmpCust.UIStatus = (new EnquiryStatusStringType()).GetInstance(tmpCust.Status).ToString();
                                else if (VwCustomerEntityType.Lead == tmpType) tmpCust.UIStatus = (new LeadStatusStringType()).GetInstance(tmpCust.Status).ToString();
                                else if (VwCustomerEntityType.UnitOwner == tmpType || VwCustomerEntityType.UnitCoOwner == tmpType)
                                    tmpCust.UIStatus = (new PRUnitSaleStatusStringType()).GetInstance(tmpCust.Status).ToString();
                    		}
                    	}
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Customer details from view:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return allCustomerList;
        }
        public CustomerDTO fetchCustomer(long Id)
        {
            ISession session = null;
            CustomerDTO customerDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Customer customer = session.Get<Customer>(Id);
                        customerDto = DomainToDTOUtil.convertToCustomerDTO(customer, true);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Customer details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return customerDto;
        }
        public CustomerDTO fetchCustomerWithUnits(long Id)
        {
            ISession session = null;
            CustomerDTO customerDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Customer customer = session.Get<Customer>(Id);
                        customerDto = DomainToDTOUtil.convertToCustomerDTO(customer, true);
                        
                        Property p = null;
                        PropertyUnit pu = null;
                        PrUnitSaleDetail pus = null;
                        Customer c = null;
                        PropertyTower pt = null;
                        MasterControlData putype = null;

                        PrUnitSaleDetailDTO pusdto = null;
                        IList<PrUnitSaleDetailDTO> result = new List<PrUnitSaleDetailDTO>();

                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => pus.Id).WithAlias(() => pusdto.Id))
                                    .Add(Projections.SqlFunction("concat",
                                                NHibernateUtil.String,
                                                Projections.Property(() => c.FirstName),
                                                Projections.Constant(" "),
                                                Projections.Property(() => c.LastName)), "Customer.FirstName")
                                    .Add(Projections.Property(() => c.Id), "Customer.Id")
                                    .Add(Projections.Property(() => pus.IsAgreementDone).WithAlias(() => pusdto.IsAgreementDone))
                                    .Add(Projections.Property(() => pus.IsPossessionDone).WithAlias(() => pusdto.IsPossessionDone))
                                    .Add(Projections.Property(() => p.Id), "PropertyUnit.PropertyTower.Property.Id")
                                    .Add(Projections.Property(() => p.Name), "PropertyUnit.PropertyTower.Property.Name")
                                    .Add(Projections.Property(() => pt.Id), "PropertyUnit.PropertyTower.Id")
                                    .Add(Projections.Property(() => pt.Name), "PropertyUnit.PropertyTower.Name")
                                    .Add(Projections.Property(() => pu.Id), "PropertyUnit.Id")
                                    .Add(Projections.Property(() => pu.Wing), "PropertyUnit.Wing")
                                    .Add(Projections.Property(() => pu.UnitNo), "PropertyUnit.UnitNo")
                                    .Add(Projections.Property(() => pu.BuildupArea), "PropertyUnit.BuildupArea")
                                    .Add(Projections.Property(() => pu.CarpetArea), "PropertyUnit.CarpetArea")
                                    .Add(Projections.Property(() => putype.Id), "PropertyUnit.UnitType.Id")
                                    .Add(Projections.Property(() => putype.Name), "PropertyUnit.UnitType.Name")
                                    .Add(Projections.Property(() => pus.BookingDate), "BookingDate")
                                    .Add(Projections.Property(() => pus.PossessionDate), "PossessionDate")
                                    .Add(Projections.Property(() => pus.AgreementDate), "AgreementDate")
                        			.Add(Projections.Property(() => pus.Status), "Status");
                        var query = session.QueryOver<PrUnitSaleDetail>(() => pus)
                            .Left.JoinAlias(() => pus.PropertyUnit, () => pu)
                            .Left.JoinAlias(() => pus.PropertyUnit.UnitType, () => putype)
                            .Left.JoinAlias(() => pus.PropertyUnit.PropertyTower, () => pt)
                            .Left.JoinAlias(() => pus.PropertyUnit.PropertyTower.Property, () => p)
                            .Left.JoinAlias(() => pus.Customer, () => c);
                        result = query.Where(() => p.FirmNumber == customerDto.FirmNumber && c.Id == Id)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<PrUnitSaleDetailDTO>()).List<PrUnitSaleDetailDTO>();
                        result.ToList().ForEach(x => x.PropertyUnit.UnitNo
                                = CommonUIConverter.getPropertyUnitFormattedNo(x.PropertyUnit.Wing, x.PropertyUnit.UnitNo));
                        customerDto.PrUnitSaleDetails = new HashSet<PrUnitSaleDetailDTO>(result);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Customer details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return customerDto;
        }
        public long saveCustomer(CustomerDTO customerDto)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Customer customer = DTOToDomainUtil.populateCustomerAddFields(customerDto);
                        Random rd = new Random();
                        customer.CustRefNo = CommonUtil.getRandomRefNo();
                        session.Save(customer);
                        Id = customer.Id;
                        customer.CustRefNo = CommonUtil.getCustomerRefNo(customer.Id);
                        session.Update(customer);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Customer details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        public void updateCustomer(CustomerDTO customerDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Customer customer = session.Get<Customer>(customerDto.Id);
                        DTOToDomainUtil.populateCustomerUpdateFields(customer, customerDto);
                        session.Update(customer);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating Customer details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void deleteCustomer(long Id)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Customer customer = session.Get<Customer>(Id);
                        session.Delete(customer);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while deleting Customer details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public CustomerDTO GetByProperty(string value)
       {
            ISession session = null;
            CustomerDTO customerDTO = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                Customer result = session.CreateCriteria<Customer>().Add(Restrictions.Like(Projections.SqlFunction("concat",
                            NHibernateUtil.String, Projections.Property("FirstName"), Projections.Constant(" "), Projections.Property("MiddleName"), Projections.Constant(" "),
                            Projections.Property("LastName")), value, MatchMode.Anywhere)).SetMaxResults(1).List<Customer>().FirstOrDefault();
                 customerDTO = DomainToDTOUtil.convertToCustomerDTO(result, true);
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating Cusromer:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return customerDTO;
        }
    }
}