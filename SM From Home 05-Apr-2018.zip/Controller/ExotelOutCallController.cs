﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace ConstroSoft.Controller
{
    public class ExotelOutCallController : ApiController
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        CallHistoryBO callHistoryBO = new CallHistoryBO();

        /**
         * This service is called when outgoing call is completed.
         */
        [HttpPost]
        [ActionName("PostOutCallDetails")]
        public string PostOutCallDetails()
        {
            var response = JsonConvert.SerializeObject("Failure");
            try
            {
                CallHistoryDTO callHistoryDTO = populateCallHistoryDTOFromCall(HttpContext.Current.Request.Params);
                //Validate the Mandatory Fields.
                if (!string.IsNullOrEmpty(callHistoryDTO.CallSid))
                {
                    callHistoryBO.updateOutgoingCallOnFinish(callHistoryDTO);
                    response = JsonConvert.SerializeObject("Out Call Details Recieved Successfully.");
                }else{
                    log.Error("ExotelOutCallController: CallSid is Missing");
                    response = JsonConvert.SerializeObject("CallSid is Missing");
                }
                
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while placing outbound call");
                log.Error(exp.Message, exp);
            }
            finally
            {
            }
            return response;
        }
        public static CallHistoryDTO populateCallHistoryDTOFromCall(NameValueCollection parameters)
        {
            CallHistoryDTO callHistoryDTO = new CallHistoryDTO();
            callHistoryDTO.CallSid = parameters["CallSid"];
            callHistoryDTO.CallStatus = CommonUtil.getCallStatus(parameters["Status"].ToString());
            callHistoryDTO.RecordingUrl = parameters["RecordingUrl"];
            callHistoryDTO.DateUpdated = Convert.ToDateTime(parameters["DateUpdated"]);
            callHistoryDTO.EndTime = Convert.ToDateTime(parameters["DateUpdated"]);
            callHistoryDTO.Duration = Convert.ToInt64(parameters["Duration"]);
            callHistoryDTO.UpdateUser = Constants.SYSADMIN_USER;
            return callHistoryDTO;
        }
    }
}