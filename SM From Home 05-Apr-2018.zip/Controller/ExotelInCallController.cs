﻿using ConstroSoft.Logic.CachingProvider;
using Newtonsoft.Json;
using System;
using System.Collections.Specialized;
using System.Web;
using System.Web.Http;

namespace ConstroSoft.Controller
{
    public class ExotelInCallController : ApiController
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        CallHistoryBO callHistoryBO = new CallHistoryBO();
        NotificationBO notificationBO = new NotificationBO();
        /**
         * This service is called by exotel when incoming call is completed.
         */
        [HttpGet]
        [ActionName("GetInCallDetails")]
        public void GetInCallDetails()
        {
            FirmMemberDTO firmMemberDTO = null;
            CallHistoryDTO callHistoryDTO = null;
            try
            {
                //Update CALL_HISTORY record
                string CallSid = HttpContext.Current.Request.Params["CallSid"];
                string DialWhomNumber = HttpContext.Current.Request.Params["DialWhomNumber"];
                firmMemberDTO = callHistoryBO.fetchAgentForCall(DialWhomNumber);
                callHistoryDTO = callHistoryBO.fetchCallHistoryforCallSID(CallSid);
                callHistoryDTO.FirmMember = firmMemberDTO;
                populateCallHistoryDTOFromCall(HttpContext.Current.Request.Params, callHistoryDTO);
                callHistoryBO.updateIncomingCallOnFinish(callHistoryDTO);
                notificationBO.removeAllUserNotificationsForPassthrough(firmMemberDTO.UserDefinition, callHistoryDTO);
                //If call is unresolved then raise UnresolvedFlag which will be read by 'TaskNotificationJob' and will update unresolved call count for each user.
                if (callHistoryDTO.CallHistoryStatus.Equals(CallHistoryStatus.Unresolved))
                {
                    NotificationCacheProvider.Instance.markUnResolvedFlag();
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while getting inbound call details.");
                log.Error(exp.Message, exp);
            }
            
            finally
            {
            }
        }
        public static CallHistoryDTO populateCallHistoryDTOFromCall(NameValueCollection parameters, CallHistoryDTO callHistoryDTO)
        {
            callHistoryDTO.CallerNumber = parameters["CallFrom"];
            callHistoryDTO.PhoneNumberSid = parameters["CallTo"];
            callHistoryDTO.DateCreated = Convert.ToDateTime(parameters["Created"]);
            callHistoryDTO.Duration = Convert.ToInt64(parameters["DialCallDuration"]);
            callHistoryDTO.RecordingUrl = parameters["RecordingUrl"];
            callHistoryDTO.StartTime = Convert.ToDateTime(parameters["StartTime"]);
            callHistoryDTO.EndTime = Convert.ToDateTime(parameters["EndTime"]);
            callHistoryDTO.CallStatus = CommonUtil.getCallStatus(parameters["DialCallStatus"].ToString());
            callHistoryDTO.DateUpdated = Convert.ToDateTime(parameters["Created"]);
            callHistoryDTO.CalleeNumber = parameters["DialWhomNumber"];
            callHistoryDTO.UpdateUser = Constants.SYSADMIN_USER;
            callHistoryDTO.UpdateDate = DateUtil.getUserLocalDateTime();
            return callHistoryDTO;
        }
    }
}