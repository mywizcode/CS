﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.Scheduler;

public partial class SMSCampaignDetails : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
            log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string testSMSModal = "testSMSModal";
    string testSMSModalError = "testSMSModalError";
    string addRecipientModal = "addRecipientModal";
    string addRecipientModalError = "addRecipientModalError";
    string campaignScheduleModal = "campaignScheduleModal";
    string campaignScheduleModalError = "campaignScheduleModalError";
    string selectTemplateModal = "selectTemplateModal";
    string selectTemplateModalError = "selectTemplateModalError";
    string selectProviderModal = "selectProviderModal";
    string selectProviderModalError = "selectProviderModalError";
    DropdownBO drpBO = new DropdownBO();
    MarketingCampaignBO marketingCampaignBO = new MarketingCampaignBO();
    DocumentBO documentBO = new DocumentBO();
    EmailAndSMSProviderBO emailSmsProviderBO = new EmailAndSMSProviderBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                SMSCampaignNavDTO navDto = ApplicationUtil.getPageNavDTO<SMSCampaignNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.SMS_CAMPAIGN_ADD, Constants.Entitlement.SMS_CAMPAIGN_MODIFY)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
        * This method is called just before the page is rendered. So any change in state of the element is applied.
        **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
        setPageTitle();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpRecipientProperty, DrpDataType.PROPERTY_NAME, userDefDto.FirmMember.Id.ToString(), Constants.SELECT_ALL, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpProvider, DrpDataType.SMS_PROVIDER, null, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
    }
    public void setErrorMessage(string message, string group)
    {
        string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }
    }
    private void doInit(SMSCampaignNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(SMSCampaignNavDTO navDto)
    {
        try
        {
            SMSCampaignPageDTO PageDTO = new SMSCampaignPageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            pageModeHdn.Value = navDto.Mode.ToString();
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            loadSMSCampaign(navDto.CampaignId);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageFieldsWithEntitlement()
    {
        initFormFields();
    }
    private void setPageTitle()
    {
        if (isAddMode()) lbPageTitle.Text = Constants.ICON.ADD + Resources.Labels.ADD_SMS_CAMPAIGN;
        else if (isModifyMode()) lbPageTitle.Text = Constants.ICON.MODIFY + Resources.Labels.MODIFY_SMS_CAMPAIGN;
        else if (isViewMode()) lbPageTitle.Text = Constants.ICON.VIEW_DTL + Resources.Labels.SMS_CAMPAIGN_DETAILS;
    }
    private void initFormFields()
    {
        bool viewMode = isViewMode();
        EmailSmsCampaignDTO campaignDTO = getSMSCampaign();
        //SMS top bar
        btnTestSMS.Visible = !viewMode;
        btnStartCampaign.Visible = !viewMode;
        btnSave.Visible = !viewMode;
        btnCancel.Visible = !viewMode;
        btnStopCampaign.Visible = viewMode && campaignDTO.Stage == EmailSmsCampaignStage.Scheduled;
        SMSToolbar.Visible = campaignDTO.Stage != EmailSmsCampaignStage.Completed;
        //Campaign Message
        CampaignMessageRow.Visible = viewMode && campaignDTO.Stage == EmailSmsCampaignStage.Completed;
        lbCampaignSuccessMessage.Text = (viewMode && campaignDTO.Status == EmailSmsCampaignStatus.Success) ? campaignDTO.Message : "";
        lbCampaignFailureMessage.Text = (viewMode && campaignDTO.Status == EmailSmsCampaignStatus.Failed) ? campaignDTO.Message : "";
        /*In case of campaign is failed then agent can edit campaign and reschedule*/
        lnkEditCampaign.Visible = viewMode && campaignDTO.Status == EmailSmsCampaignStatus.Failed;
        //SMS Campaign name
        txtCampaignName.ReadOnly = viewMode;
        lnkSMSProvider.Visible = !viewMode;
        lbSMSProvider.Visible = viewMode;
        //Recipient row
        lnkSMSRecipient.Visible = !viewMode;
        lbSMSRecipient.Visible = viewMode;
        txtRecipient.ReadOnly = viewMode;
        //Schedule row
        lnkSMSScheduleDate.Visible = !viewMode;
        lbSMSScheduledDate.Visible = viewMode;
        lnkLoadTemplate.Visible = !viewMode;
        ulSMSActions.Visible = !viewMode;
        txtSMSContent.ReadOnly = viewMode;
    }
    private bool isModifyMode()
    {
        return PageMode.MODIFY.ToString().Equals(pageModeHdn.Value);
    }
    private bool isViewMode()
    {
        return PageMode.VIEW.ToString().Equals(pageModeHdn.Value);
    }
    private bool isAddMode()
    {
        return PageMode.ADD.ToString().Equals(pageModeHdn.Value);
    }
    private void navigateToPreviousPage()
    {
        SMSCampaignPageDTO PageDTO = getSessionPageData();
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is EmailSMSCampaignSearchNavDTO)
            {
                EmailSMSCampaignSearchNavDTO navDTO = (EmailSMSCampaignSearchNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.EMAIL_SMS_CAMPAIGN_SEARCH, true);
            }
        }
        Response.Redirect(Constants.URL.EMAIL_SMS_CAMPAIGN_SEARCH, true);
    }
    private SMSCampaignPageDTO getSessionPageData()
    {
        return (SMSCampaignPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private EmailSmsCampaignDTO getSMSCampaign()
    {
        return getSessionPageData().SMSCampaign;
    }
    private void loadSMSCampaign(long CampaignId)
    {
        EmailSmsCampaignDTO tmpDTO = null;
        if (isAddMode()) tmpDTO = createEmailSmsCampaignDTO();
        else tmpDTO = marketingCampaignBO.fetchEmailSmsCampaign(CampaignId);
        getSessionPageData().SMSCampaign = tmpDTO;

        populateUIFromTemplateDTO(tmpDTO);
    }
    private void populateUIFromTemplateDTO(EmailSmsCampaignDTO tmpDTO)
    {
        txtCampaignName.Text = tmpDTO.Name;
        txtSMSProvider.Text = (tmpDTO.SmsConfig != null) ? tmpDTO.SmsConfig.Name : "";
        setRecipients(tmpDTO);
        setUIScheduleDate(tmpDTO);
        txtSMSContent.Text = tmpDTO.SmsContent;
    }
    private EmailSmsCampaignDTO createEmailSmsCampaignDTO()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        EmailSmsCampaignDTO tmpDTO = new EmailSmsCampaignDTO();
        tmpDTO.RecordType = EmailSmsType.SMS;
        tmpDTO.CreatedBy = CommonUIConverter.getFirmMemberDTO(userDefDto.FirmMember.Id.ToString(), null);
        tmpDTO.CreateDate = DateUtil.getUserLocalDate();
        tmpDTO.Stage = EmailSmsCampaignStage.Draft;
        tmpDTO.Status = EmailSmsCampaignStatus.NotStarted;
        tmpDTO.Recipients = new List<EmailSmsCampaignRecipientDTO>();

        tmpDTO.FirmNumber = userDefDto.FirmNumber;
        tmpDTO.InsertUser = userDefDto.Username;
        tmpDTO.UpdateUser = userDefDto.Username;

        return tmpDTO;
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void populateEmailSmsCampaignDTOFromUI(EmailSmsCampaignDTO campaignDTO, bool isStartCampaign)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        if (isAddMode())
        {
            campaignDTO.Name = txtCampaignName.Text.TrimNullable();
        }
        campaignDTO.SmsContent = txtSMSContent.Text;
        campaignDTO.UpdatedBy = CommonUIConverter.getFirmMemberDTO(userDefDto.FirmMember.Id.ToString(), null);
        campaignDTO.LastUpdateDate = DateUtil.getUserLocalDate();
        if (isStartCampaign)
        {
            if (campaignDTO.ScheduleOption == EmailSmsScheduleOption.Now) campaignDTO.ScheduledDate = DateUtil.getUserLocalDateTime();
            campaignDTO.Stage = EmailSmsCampaignStage.Scheduled;
        }

        campaignDTO.UpdateUser = userDefDto.Username;
    }
    private void doSaveOrStartCampaign(bool isStartCampaign)
    {
        if (validateSMSDetailsOnSave(isStartCampaign))
        {
            EmailSmsCampaignDTO tmpDTO = getSMSCampaign();
            populateEmailSmsCampaignDTOFromUI(tmpDTO, isStartCampaign);

            long Id = marketingCampaignBO.addOrModifyEmailSmsCampaign(tmpDTO);
            //If campaign is started then register campaign as job in Quartz.
            if(isStartCampaign) {
            	JobScheduler.AddEmailSMSCampaignJob(Id, tmpDTO.ScheduledDate.Value);
            }
            string msg = (isStartCampaign) ? "SMS Campaign is started successfully." : "SMS Campaign is saved successfully.";
            Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg(msg));
            navigateToCurrentPage(isStartCampaign, Id);
        }
    }
    private void navigateToCurrentPage(bool isStartCampaign, long Id)
    {
        SMSCampaignNavDTO navDTO = new SMSCampaignNavDTO();
        navDTO.Mode = (isStartCampaign) ? PageMode.VIEW : PageMode.MODIFY;
        navDTO.CampaignId = Id;
        navDTO.PrevNavDto = getSessionPageData().PrevNavDTO;
        Session[Constants.Session.NAV_DTO] = navDTO;
        Response.Redirect(Constants.URL.SMS_CAMPAIGN_DETAILS, true);
    }
    protected void onClickRescheduleCampaign(object sender, EventArgs e)
    {
        try
        {
            EmailSmsCampaignDTO tmpDTO = getSMSCampaign();
            JobScheduler.DeleteEmailSMSCampaignJob(tmpDTO.Id);
            marketingCampaignBO.stopCampaign(tmpDTO.Id, getUserDefinitionDTO());
            Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg("SMS campaign is available to modify."));
            navigateToCurrentPage(false, tmpDTO.Id);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickStartCampaign(object sender, EventArgs e)
    {
        try
        {
            doSaveOrStartCampaign(true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickStopCampaign(object sender, EventArgs e)
    {
        try
        {
            EmailSmsCampaignDTO tmpDTO = getSMSCampaign();
            JobScheduler.DeleteEmailSMSCampaignJob(tmpDTO.Id);
            marketingCampaignBO.stopCampaign(tmpDTO.Id, getUserDefinitionDTO());
            Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg("SMS campaign is stopped successfully."));
            navigateToCurrentPage(false, tmpDTO.Id);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickSaveSMSChanges(object sender, EventArgs e)
    {
        try
        {
            doSaveOrStartCampaign(false);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickCancelChanges(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateSMSDetailsOnSave(bool isCampaignStart)
    {
        bool isValid = true;

        EmailSmsCampaignDTO campaignDTO = getSMSCampaign();
        if (string.IsNullOrWhiteSpace(txtCampaignName.Text.TrimNullable()))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please enter Campaign Name."));
            isValid = false;
        }
        if (isCampaignStart)
        {
            if (campaignDTO.SmsConfig == null || campaignDTO.SmsConfig.Id == 0)
            {
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please select Provider."));
                isValid = false;
            }
            if (string.IsNullOrWhiteSpace(txtSMSContent.Text.TrimNullable()))
            {
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please enter SMS content."));
                isValid = false;
            }
            if (campaignDTO.ScheduleOption == null || (campaignDTO.ScheduleOption == EmailSmsScheduleOption.Scheduled && campaignDTO.ScheduledDate == null))
            {
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please select Schedule Date."));
                isValid = false;
            }
            if (campaignDTO.Recipients.Count == 0)
            {
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please select Recipients."));
                isValid = false;
            }
        }
        return isValid;
    }
    //Test SMS logic - start
    protected void onClickTestSMS(object sender, EventArgs e)
    {
        try
        {
            txtTestSMSMobileNo.Text = "";
            activeModalHdn.Value = testSMSModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void sendTestSMS(object sender, EventArgs e)
    {
        try
        {
            if (validateTestSMSModal())
            {
                EmailSmsCampaignDTO campaignDTO = getSMSCampaign();
                SmsConfigDTO configDTO = emailSmsProviderBO.fetchSmsProvider(campaignDTO.SmsConfig.Id);

                SmsDTO smsDTO = new SmsDTO();
                smsDTO.UserId = configDTO.UserId;
                smsDTO.Password = configDTO.Password;
                smsDTO.URL = configDTO.Url;
                smsDTO.SenderId = configDTO.SenderId;
                smsDTO.Content = txtSMSContent.Text.TrimNullable();
                smsDTO.RecipientList = new List<string>();
                smsDTO.RecipientList.Add(txtTestSMSMobileNo.Text.TrimNullable());

                EmailSMSUtil.SendSMS(smsDTO);
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format("SMS is sent to {0}", txtTestSMSMobileNo.Text.TrimNullable())));
            }
            else
            {
                activeModalHdn.Value = testSMSModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelTestSMSModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateTestSMSModal()
    {
        Page.Validate(testSMSModalError);
        bool isValid = Page.IsValid;
        if (isValid)
        {
            isValid = validateSMSDetailsOnSave(true);
        }
        return isValid;
    }
    //Test SMS Selection logic - end
    //Add Recipient Modal - Start
    private void resetRecipientModalFields()
    {
    	divRecipientTower.Visible = false;
    	drpRecipientProperty.ClearSelection();
    	drpRecipientCustomerType.ClearSelection();
    	drpRecipientTower.ClearSelection();
    }
    private void initRecipientModalAction()
    {
        resetRecipientModalFields();
        activeModalHdn.Value = addRecipientModal;
    }
    protected void onClickAddRecipients(object sender, EventArgs e)
    {
        try
        {
        	initRecipientModalAction();
        	drpRecipientProperty.ClearSelection();
            drpBO.drpEnum<EmailSmsRcpntType>(drpRecipientCustomerType, Constants.SELECT_ITEM, EmailSmsRcpntType.ONLY_SOLD_UNIT_CUSTOMERS.ToString());
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onChangeRecipientProperty(object sender, EventArgs e)
    {
        try
        {
        	divRecipientTower.Visible = false;
        	if(String.IsNullOrEmpty(drpRecipientProperty.Text)) {
        		drpBO.drpEnum<EmailSmsRcpntType>(drpRecipientCustomerType, Constants.SELECT_ITEM, EmailSmsRcpntType.ONLY_SOLD_UNIT_CUSTOMERS.ToString());
        	} else {
        		drpBO.drpEnum<EmailSmsRcpntType>(drpRecipientCustomerType, Constants.SELECT_ITEM);
        	}
            activeModalHdn.Value = addRecipientModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onChangeRecipientCustoemrType(object sender, EventArgs e)
    {
        try
        {
        	divRecipientTower.Visible = false;
        	if(drpRecipientCustomerType.Text.Equals(EmailSmsRcpntType.ONLY_SOLD_UNIT_CUSTOMERS.ToString())) {
        		divRecipientTower.Visible = true;
        		long propertyId = long.Parse(drpRecipientProperty.Text);
        		drpBO.drpDataBase(drpRecipientTower, DrpDataType.PROPERTY_TOWER, propertyId.ToString(), Constants.SELECT_ALL, getUserDefinitionDTO().FirmNumber);
        	}
            activeModalHdn.Value = addRecipientModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void addRecipients(object sender, EventArgs e)
    {
        try
        {
            if (validateAddRecipient())
            {
                if (!isDuplicateRecipient())
                {
                    EmailSmsCampaignDTO campaignDTO = getSMSCampaign();
                    campaignDTO.Recipients.Add(createEmailSmsCampaignRecipientDTO(getSMSCampaign()));
                    setRecipients(campaignDTO);
                }
            }
            else
            {
                activeModalHdn.Value = addRecipientModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeRecipientToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            EmailSmsCampaignDTO campaignDTO = getSMSCampaign();
            EmailSmsCampaignRecipientDTO tmpDTO = campaignDTO.Recipients.Find(x => x.Name.Equals(token));
            if(tmpDTO != null) {
            	campaignDTO.Recipients.Remove(tmpDTO);
            }
            setRecipients(campaignDTO);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setRecipients(EmailSmsCampaignDTO campaignDTO)
    {
        string recipientText = null;
        foreach (EmailSmsCampaignRecipientDTO tmpDTO in campaignDTO.Recipients)
        {
        	recipientText = CommonUtil.addFilterToken(recipientText, tmpDTO.Name);
        }
        txtRecipient.Text = recipientText;
    }
    private EmailSmsCampaignRecipientDTO createEmailSmsCampaignRecipientDTO(EmailSmsCampaignDTO campaignDTO)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        EmailSmsCampaignRecipientDTO tmpDTO = new EmailSmsCampaignRecipientDTO();
        tmpDTO.Name = getRecipientName();
        tmpDTO.PropertyId = String.IsNullOrEmpty(drpRecipientProperty.Text) ? 0 : long.Parse(drpRecipientProperty.Text);
        tmpDTO.RecipientType = EnumHelper.ToEnum<EmailSmsRcpntType>(drpRecipientCustomerType.Text);
        tmpDTO.TowerId = (String.IsNullOrEmpty(drpRecipientTower.Text)) ? 0 : long.Parse(drpRecipientTower.Text);
        tmpDTO.EmailSmsCampaign = campaignDTO;

        tmpDTO.FirmNumber = userDefDto.FirmNumber;
        tmpDTO.InsertUser = userDefDto.Username;
        tmpDTO.UpdateUser = userDefDto.Username;
        return tmpDTO;
    }
    public string getRecipientName()
    {
    	EmailSmsRcpntType type = EnumHelper.ToEnum<EmailSmsRcpntType>(drpRecipientCustomerType.Text);
    	string tower = (type == EmailSmsRcpntType.ONLY_SOLD_UNIT_CUSTOMERS && !String.IsNullOrEmpty(drpRecipientTower.Text)) ? " of " + drpRecipientTower.SelectedItem.Text : "";
    	string peroperty = (String.IsNullOrEmpty(drpRecipientProperty.Text)) ? " in All Properties" : " in " + drpRecipientProperty.SelectedItem.Text;
        return type.GetDescription() + tower + peroperty;
    }
    protected void cancelRecipientModal(object sender, EventArgs e)
    {
        try
        {
            
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateAddRecipient()
    {
    	Page.Validate(addRecipientModalError);
    	bool isValid = Page.IsValid;
    	
        return isValid;
    }
    private bool isDuplicateRecipient()
    {
        EmailSmsCampaignDTO campaignDTO = getSMSCampaign();
        if (campaignDTO.Recipients != null)
        {
            EmailSmsRcpntType type = EnumHelper.ToEnum<EmailSmsRcpntType>(drpRecipientCustomerType.Text);
            long PropertyId = String.IsNullOrEmpty(drpRecipientProperty.Text) ? 0 : long.Parse(drpRecipientProperty.Text);
            long TowerId = String.IsNullOrEmpty(drpRecipientTower.Text) ? 0 : long.Parse(drpRecipientTower.Text);
            foreach (EmailSmsCampaignRecipientDTO tmpDTO in campaignDTO.Recipients)
            {
                if (tmpDTO.RecipientType == type && tmpDTO.PropertyId == PropertyId && tmpDTO.TowerId == TowerId)
                {
                    (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Selected recipient criteria is already added."));
                    return true;
                }
            }
        }
        return false;
    }
    //Add Recipient Modal - End
    //Schedule SMS Campaign Modal - Start
    private void setUIScheduleDate(EmailSmsCampaignDTO campaignDTO) {
    	string scheduleDateValue = "";
    	if(campaignDTO.ScheduleOption != null) {
    		if(campaignDTO.ScheduleOption == EmailSmsScheduleOption.Now && campaignDTO.Stage == EmailSmsCampaignStage.Draft) {
    			scheduleDateValue = "Send SMS immediately";
    		} else {
    			scheduleDateValue = DateUtil.getCSDateTime(campaignDTO.ScheduledDate);
    		}
    	}
    	lbScheduledDateValue.Text = scheduleDateValue;
    }
    private void resetCampaignScheduleModalFields(EmailSmsCampaignDTO campaignDTO)
    {
        rdSendSMSNow.Checked = (campaignDTO.ScheduleOption == EmailSmsScheduleOption.Now);
        rdScheduleSMS.Checked = (campaignDTO.ScheduleOption == EmailSmsScheduleOption.Scheduled);
    	txtScheduleDate.Text = (rdScheduleSMS.Checked && campaignDTO.ScheduledDate != null) ? DateUtil.getCSDateTime(campaignDTO.ScheduledDate) : null;
    }
    private void initCampaignScheduleModalAction(EmailSmsCampaignDTO campaignDTO)
    {
    	resetCampaignScheduleModalFields(campaignDTO);
        activeModalHdn.Value = campaignScheduleModal;
    }
    protected void onClickScheduleCampaign(object sender, EventArgs e)
    {
        try
        {
        	initCampaignScheduleModalAction(getSMSCampaign());
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void saveCampaignSchedule(object sender, EventArgs e)
    {
        try
        {
            if (validateCampaignSchedule())
            {
            	EmailSmsCampaignDTO campaignDTO = getSMSCampaign();
            	campaignDTO.ScheduleOption = (rdSendSMSNow.Checked) ? EmailSmsScheduleOption.Now : EmailSmsScheduleOption.Scheduled;
            	campaignDTO.ScheduledDate = (campaignDTO.ScheduleOption == EmailSmsScheduleOption.Scheduled && !String.IsNullOrEmpty(txtScheduleDate.Text)) 
                        ? DateUtil.getCSDateTime(txtScheduleDate.Text) : null;
            	setUIScheduleDate(campaignDTO);
            }
            else
            {
                activeModalHdn.Value = campaignScheduleModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void clearCampaignSchedule(object sender, EventArgs e)
    {
        try
        {
        	EmailSmsCampaignDTO campaignDTO = getSMSCampaign();
        	campaignDTO.ScheduleOption = null;
        	campaignDTO.ScheduledDate = null;
        	setUIScheduleDate(campaignDTO);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelCampaignScheduleModal(object sender, EventArgs e)
    {
        try
        {
            
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateCampaignSchedule()
    {
    	if(!rdSendSMSNow.Checked && !rdScheduleSMS.Checked) {
            setErrorMessage("Please select campaign schedule date.", campaignScheduleModalError);
    		return false;
    	}
    	if(rdScheduleSMS.Checked && String.IsNullOrEmpty(txtScheduleDate.Text)) {
            setErrorMessage("Please enter schedule date.", campaignScheduleModalError);
    		return false;
    	}
    	if(rdScheduleSMS.Checked) {
    		DateTime scheduleDate = DateUtil.getCSDateTime(txtScheduleDate.Text).Value;
            if (scheduleDate.CompareTo(DateUtil.getUserLocalDateTime()) <= 0)
            {
                setErrorMessage("Schedule Date should be in future.", campaignScheduleModalError);
        		return false;
        	}
    	}
        return true;
    }
    //Schedule SMS Campaign Modal - End
    //Template Selection logic - start
    protected void onClickLoadTemplate(object sender, EventArgs e)
    {
    	try
    	{
    		drpBO.drpDataBase(drpTemplate, DrpDataType.SMS_STORE_TEMPLATE, null, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
    		activeModalHdn.Value = selectTemplateModal;
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    protected void LoadTemplate(object sender, EventArgs e)
    {
    	try
    	{
    		Page.Validate(selectTemplateModalError);
    		bool isValid = Page.IsValid;
    		if (isValid)
    		{
    			long TemplateId = long.Parse(drpTemplate.Text);
    			EmailSmsStoreDTO templateDTO = marketingCampaignBO.fetchEmailSmsTemplate(TemplateId);
    			
				txtSMSContent.Text = templateDTO.SmsContent;
    		}
    		else
    		{
    			activeModalHdn.Value = selectTemplateModal;
    		}
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    protected void cancelTemplateModal(object sender, EventArgs e)
    {
    	try
    	{
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    //Template Selection logic - end
    //Provider Selection logic - start
    protected void onClickProvider(object sender, EventArgs e)
    {
        try
        {
            EmailSmsCampaignDTO campaignDTO = getSMSCampaign();
            if (campaignDTO.SmsConfig != null) drpProvider.Text = campaignDTO.SmsConfig.Id.ToString();
            activeModalHdn.Value = selectProviderModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void AssignProvider(object sender, EventArgs e)
    {
        try
        {
            EmailSmsCampaignDTO campaignDTO = getSMSCampaign();
            if (!string.IsNullOrWhiteSpace(drpProvider.Text))
            {
                long Provider = long.Parse(drpProvider.Text);
                txtSMSProvider.Text = drpProvider.SelectedItem.Text;
                campaignDTO.SmsConfig = CommonUIConverter.getSmsConfigDTO(drpProvider.Text, drpProvider.SelectedItem.Text);
            }
            else
            {
                txtSMSProvider.Text = null;
                campaignDTO.SmsConfig = null;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelProviderModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Provider Selection logic - end
}