﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using ConstroSoft;
using ConstroSoft.Logic.BO;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Drawing;
using System.Web.UI.HtmlControls;

public partial class CustomerSearch : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string SearchFilterModal = "SearchFilterModal";
    DropdownBO drpBO = new DropdownBO();
    CustomerBO customerBO = new CustomerBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Form.Attributes.Add("enctype", "multipart/form-data");
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                CustomerSearchNavDTO navDto = ApplicationUtil.getPageNavDTO<CustomerSearchNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_CUSTOMER)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
    	ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];

    }
    public void setErrorMessage(string message, string group)
    {
    	string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
	        CustomValidator val = new CustomValidator();
	        val.IsValid = false;
	        val.ErrorMessage = message;
	        val.ValidationGroup = group;
	        this.Page.Validators.Add(val);
        }
    }
    private void doInit(CustomerSearchNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new CustomerSearchPageDTO();
        initDropdowns();
        setSearchFilter(null);
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(CustomerSearchNavDTO navDto)
    {
        try
        {
            if (navDto != null)
            {
                setSearchFilter(navDto.filterDTO);
            }
            loadCustomerSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageFieldsWithEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        lnkAddCustomerBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.CUSTOMER_ADD);
        if (customerSearchGrid.Rows.Count > 0)
        {
            for (var i = 0; i < customerSearchGrid.Rows.Count; i++)
            {
                HtmlGenericControl tmpBtn = (HtmlGenericControl)customerSearchGrid.Rows[i].FindControl("liModifyCustomerBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.CUSTOMER_MODIFY);
                tmpBtn = (HtmlGenericControl)customerSearchGrid.Rows[i].FindControl("liDeleteCustomerBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.CUSTOMER_DELETE);
                tmpBtn = (HtmlGenericControl)customerSearchGrid.Rows[i].FindControl("liManageDocumentsBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MANAGE_CUSTOMER_DOCUMENTS);
            }
        }
    }
    private void setSearchGrid(IList<CustomerDTO> tmpList)
    {
        getSessionPageData().SearchResult = (tmpList != null) ? tmpList.ToList<CustomerDTO>() : new List<CustomerDTO>();
        customerSearchGrid.DataSource = getSearchCustomerList();
        customerSearchGrid.DataBind();
    }
    private CustomerSearchPageDTO getSessionPageData()
    {
        return (CustomerSearchPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<CustomerDTO> getSearchCustomerList()
    {
        return getSessionPageData().SearchResult;
    }
    private CustomerDTO getSearchCustomerDTO(long Id)
    {
        List<CustomerDTO> searchList = getSearchCustomerList();
        CustomerDTO selectedCustomerDTO = null;
        if (Id > 0 && searchList != null && searchList.Count > 0)
        {
            selectedCustomerDTO = searchList.Find(c => c.Id == Id);
        }
        return selectedCustomerDTO;
    }
    private void loadCustomerSearchGrid()
    {
        IList<CustomerDTO> results = customerBO.fetchCustomerGridData(getUserDefinitionDTO().FirmNumber, getSearchFilter());
        setSearchGrid(results);
    }
    private CustomerSearchNavDTO getCurrentPageNavigation()
    {
        CustomerSearchPageDTO PageDTO = getSessionPageData();
        CustomerSearchNavDTO navDTO = new CustomerSearchNavDTO();
        navDTO.filterDTO = getSearchFilter();
        return navDTO;
    }
    private void navigateToCustomerDetails(long selectedId, PageMode mode)
    {
        CustomerDTO customerDTO = getSearchCustomerDTO(selectedId);
        CustomerDetailNavDTO navDTO = new CustomerDetailNavDTO();
        navDTO.Mode = mode;
        if (customerDTO != null) navDTO.CustomerId = customerDTO.Id;
        navDTO.PrevNavDto = getCurrentPageNavigation();
        Session[Constants.Session.NAV_DTO] = navDTO;
        Response.Redirect(Constants.URL.CUSTOMER_DETAILS, true);
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    protected void onClickAddCustomerBtn(object sender, EventArgs e)
    {
        try
        {
            navigateToCustomerDetails(0, PageMode.ADD);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickViewCustomerBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            navigateToCustomerDetails(selectedId, PageMode.VIEW);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyCustomerBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            navigateToCustomerDetails(selectedId, PageMode.MODIFY);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void deleteCustomer(object sender, EventArgs e)
    {
        try
        {
            long selectedId = getDeleteRecordHdnId();
            customerBO.deleteCustomer(selectedId);
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(CommonUtil.getRecordDeleteSuccessMsg("Customer")));
            loadCustomerSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickManageDocumentsBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            ManageCustomerDocsNavDTO navDTO = new ManageCustomerDocsNavDTO();
            navDTO.CustomerId = selectedId;
            navDTO.PrevNavDto = getCurrentPageNavigation();
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.CUSTOMER_MANAGE_DOCUMENTS, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Filter Criteria - Property Search - Start
    private CustomerFilterDTO getSearchFilter()
    {
        return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            CustomerFilterDTO filterDTO = getSearchFilter();
            if (!string.IsNullOrWhiteSpace(filterDTO.FirstName)) txtFirstNameFilter.Text = filterDTO.FirstName; else txtFirstNameFilter.Text = null;
            if (!string.IsNullOrWhiteSpace(filterDTO.LastName)) txtLastNameFilter.Text = filterDTO.LastName; else txtLastNameFilter.Text = null;
            if (filterDTO.Dob != null) txtDOBFilter.Text = DateUtil.getCSDate(filterDTO.Dob); else txtDOBFilter.Text = null;
            if (!string.IsNullOrWhiteSpace(filterDTO.Contact)) txtContactFilter.Text = filterDTO.Contact; else txtContactFilter.Text = null;
            if (!string.IsNullOrWhiteSpace(filterDTO.CustRefNo)) txtCustRefNoFilter.Text = filterDTO.CustRefNo; else txtCustRefNoFilter.Text = null;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            CustomerFilterDTO filterDTO = new CustomerFilterDTO();
            if (!string.IsNullOrWhiteSpace(txtFirstNameFilter.Text))
            {
                filterDTO.FirstName = txtFirstNameFilter.Text.TrimNullable();
            }
            if (!string.IsNullOrWhiteSpace(txtLastNameFilter.Text))
            {
                filterDTO.LastName = txtLastNameFilter.Text.TrimNullable();
            }
            if (!string.IsNullOrWhiteSpace(txtDOBFilter.Text))
            {
                filterDTO.Dob = DateUtil.getCSDate(txtDOBFilter.Text);
            }
            if (!string.IsNullOrWhiteSpace(txtContactFilter.Text))
            {
                filterDTO.Contact = txtContactFilter.Text.TrimNullable();
            }
            if (!string.IsNullOrWhiteSpace(txtCustRefNoFilter.Text))
            {
                filterDTO.CustRefNo = txtCustRefNoFilter.Text.TrimNullable();
            }
            setSearchFilter(filterDTO);
            loadCustomerSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            loadCustomerSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(CustomerFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new CustomerFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            CustomerFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.FIRST_NAME)) filterDTO.FirstName = null;
            else if (token.StartsWith(Constants.FILTER.LAST_NAME)) filterDTO.LastName = null;
            else if (token.StartsWith(Constants.FILTER.DOB)) filterDTO.Dob = null;
            else if (token.StartsWith(Constants.FILTER.CONTACT)) filterDTO.Contact = null;
            else if (token.StartsWith(Constants.FILTER.CUST_REF_NO)) filterDTO.CustRefNo = null;

            setSearchFilterTokens();
            loadCustomerSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        CustomerFilterDTO filterDTO = getSearchFilter();
        string filter = "";
        if (!string.IsNullOrWhiteSpace(filterDTO.FirstName)) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.FIRST_NAME + filterDTO.FirstName);
        if (!string.IsNullOrWhiteSpace(filterDTO.LastName)) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.LAST_NAME + filterDTO.LastName);
        if (filterDTO.Dob != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.DOB + DateUtil.getCSDate(filterDTO.Dob));
        if (!string.IsNullOrWhiteSpace(filterDTO.Contact)) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.CONTACT + filterDTO.Contact);
        if (!string.IsNullOrWhiteSpace(filterDTO.CustRefNo)) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.CUST_REF_NO + filterDTO.CustRefNo);
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - Customer Search - End
}