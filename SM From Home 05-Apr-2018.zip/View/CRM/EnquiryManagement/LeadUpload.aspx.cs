﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.BO;
using ConstroSoft.Logic.Util;
using OfficeOpenXml;
using ConstroSoft.Logic.CachingProvider;

public partial class LeadUpload : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifyStep1Error = "addModifyStep1Error";
    string addMasterDataError = "addMasterDataError";
    string addMasterDataModal = "addMasterDataModal";
    DropdownBO drpBO = new DropdownBO();
    EnquiryBO enquiryBO = new EnquiryBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                LeadUploadNavDTO navDto = ApplicationUtil.getPageNavDTO<LeadUploadNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.LEAD_ADD)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
    }
    public void setErrorMessage(string message, string group)
    {
        string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else CommonUtil.getCustomValidator(Page, message, group);
    }
    private void renderPageFieldsWithEntitlement()
    {

    }
    private void doInit(LeadUploadNavDTO navDto)
    {
        initDropdowns();
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(LeadUploadNavDTO navDto)
    {
        if (navDto != null)
        {
            LeadUploadPageDTO PageDTO = new LeadUploadPageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            //Reset page details
            txtUploadLeadProperty.Text = CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()).Name;
            pnlUploadLeadDetail.Visible = false;
            PageDTO.UploadFailedResult = new List<LeadMapperDTO>();
            PageDTO.UploadSuccessResult = new List<LeadMapperDTO>();
            DropDownList drpLeadSalutation = new DropDownList();
            DropDownList drpLeadSource = new DropDownList();
            drpBO.drpDataBase(drpLeadSalutation, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.SALUTATION.ToString(), null, getUserDefinitionDTO().FirmNumber);
            drpBO.drpDataBase(drpLeadSource, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.ENQUIRY_SOURCE.ToString(), null, getUserDefinitionDTO().FirmNumber);
            PageDTO.drpLeadSalutation = drpLeadSalutation;
            PageDTO.drpLeadSource = drpLeadSource;
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void navigateToPreviousPage()
    {
        LeadUploadPageDTO PageDTO = getSessionPageData();
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is MyLeadsNavDTO)
            {
                MyLeadsNavDTO navDTO = (MyLeadsNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.MY_LEADS, true);
            }
        }
        Response.Redirect(Constants.URL.MY_LEADS, true);
    }
    private LeadUploadPageDTO getSessionPageData()
    {
        return (LeadUploadPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<LeadMapperDTO> getUploadFailedList()
    {
        return getSessionPageData().UploadFailedResult;
    }
    private List<LeadMapperDTO> getUploadSuccessList()
    {
        return getSessionPageData().UploadSuccessResult;
    }
    private bool isUploadSubmitToEnabled()
    {
        return getUploadSuccessList().Count > 0 && Constants.UPLOAD_VALIDATED.Equals(lbSuccessUploadLeadsText.Text);
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelLeads(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    public void validateLeads(object sender, EventArgs e)
    {
        try
        {
            pnlUploadLeadDetail.Visible = false;
            HttpFileCollection uploadedFiles = Request.Files;
            List<LeadMapperDTO> validationFailedList = new List<LeadMapperDTO>();
            List<LeadMapperDTO> validationSuccessList = new List<LeadMapperDTO>();
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();

            for (int i = 0; i < uploadedFiles.Count; i++)
            {
                HttpPostedFile userPostedFile = uploadedFiles[i];
                if (userPostedFile.ContentLength > 0)
                {
                    string filename = Path.GetFileName(userPostedFile.FileName);
                    string extension = Path.GetExtension(filename);
                    HttpPostedFile file = fileUploadLeads.PostedFile;
                    if (validateFileType(extension))
                    {
                        using (file.InputStream)
                        {
                            ExcelPackage excel = new ExcelPackage(file.InputStream);
                            var workSheet = excel.Workbook.Worksheets[1];
                            IEnumerable<LeadMapperDTO> newcollection = workSheet.ConvertSheetToObjects<LeadMapperDTO>();
                            int RowNumber = 2;
                            foreach (LeadMapperDTO leadMapperDTO in newcollection)
                            {
                                leadMapperDTO.RowNumber = RowNumber++;
                                leadMapperDTO.FullName = CommonUIConverter.getCustomerFullName(leadMapperDTO.Salutation, leadMapperDTO.MiddleName, leadMapperDTO.LastName);
                                validateInputDTO(leadMapperDTO, validationSuccessList);
                                if (leadMapperDTO.IsError) validationFailedList.Add(leadMapperDTO);
                                else validationSuccessList.Add(leadMapperDTO);
                            }
                        }
                        pnlUploadLeadDetail.Visible = true;
                        getSessionPageData().UploadFailedResult = validationFailedList;
                        getSessionPageData().UploadSuccessResult = validationSuccessList;

                        lbTotalUploadLeadsCount.Text = (validationFailedList.Count + validationSuccessList.Count) + "";
                        lbSuccessUploadLeadsCount.Text = validationSuccessList.Count + "";
                        lbSuccessUploadLeadsText.Text = Constants.UPLOAD_VALIDATED;
                        lbFailedUploadLeadsCount.Text = validationFailedList.Count + "";
                        btnUploadLeadSubmit.Visible = isUploadSubmitToEnabled();
                        populateLeadUploadGrid(validationSuccessList, "SUCCESS");
                    }
                }
                else
                {
                    setErrorMessage("Please Select valid file to upload.", commonError);
                }
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    public void showUploadLeads(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            string mode = rd.Attributes["data-show"];
            btnUploadLeadSubmit.Visible = false;
            if ("ALL".Equals(mode))
            {
                List<LeadMapperDTO> allLeads = new List<LeadMapperDTO>();
                allLeads.AddRange(getUploadFailedList());
                allLeads.AddRange(getUploadSuccessList());
                btnUploadLeadSubmit.Visible = isUploadSubmitToEnabled();
                populateLeadUploadGrid(allLeads, mode);
            }
            else if ("SUCCESS".Equals(mode))
            {
                btnUploadLeadSubmit.Visible = isUploadSubmitToEnabled();
                populateLeadUploadGrid(getUploadSuccessList(), mode);
            }
            else if ("ERROR".Equals(mode))
            {
                populateLeadUploadGrid(getUploadFailedList(), mode);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    public void addLeads(object sender, EventArgs e)
    {
        try
        {
            List<LeadMapperDTO> uploadList = getUploadSuccessList();
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            if (uploadList != null && uploadList.Count > 0)
            {
                List<LeadMapperDTO> successList = new List<LeadMapperDTO>();
                List<LeadMapperDTO> failureList = new List<LeadMapperDTO>();
                foreach (LeadMapperDTO inputDTO in uploadList)
                {
                    if (!inputDTO.IsError)
                    {
                        try
                        {
                            string leadRefNo = enquiryBO.addLeadDetails(populateLeadDTO(inputDTO), userDefDto, "");
                            successList.Add(inputDTO);
                        }
                        catch (Exception exp)
                        {
                            inputDTO.IsError = true;
                        	inputDTO.AllErrorMessage.Add("Failed to upload, Unexpected error has occurred.");
                            failureList.Add(inputDTO);
                        }
                    }
                }
                NotificationCacheProvider.Instance.markNewLeadFlag();
                btnUploadLeadSubmit.Visible = false;
                string msg = (uploadList.Count == successList.Count) ? "Upload process is completed. All Leads are uploaded successfully." :
                    "Upload process is completed. Some of the Leads are not uploaded, Please check Failure records.";
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(msg));

                failureList.AddRange(getUploadFailedList());
                getSessionPageData().UploadFailedResult = failureList;
                getSessionPageData().UploadSuccessResult = successList;
                populateLeadUploadGrid(successList, "SUCCESS");

                lbSuccessUploadLeadsCount.Text = successList.Count + "";
                lbSuccessUploadLeadsText.Text = Constants.UPLOAD_SUCCESS;
                lbFailedUploadLeadsCount.Text = failureList.Count + "";
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    private void populateLeadUploadGrid(IList<LeadMapperDTO> results, string mode)
    {
        leadUploadGrid.Columns[4].Visible = "ALL".Equals(mode) && Constants.UPLOAD_SUCCESS.Equals(lbSuccessUploadLeadsText.Text);
        leadUploadGrid.Columns[5].Visible = !"SUCCESS".Equals(mode);
        assignUiIndexToLeadDetail(results);
        leadUploadGrid.DataSource = results;
        leadUploadGrid.DataBind();
    }

    private void assignUiIndexToLeadDetail(IList<LeadMapperDTO> results)
    {
        if (results != null && results.Count > 0)
        {
            foreach (LeadMapperDTO leadMapperDTO in results)
            {
                leadMapperDTO.LeadDate = DateUtil.getUserLocalDateTime();
                leadMapperDTO.RowInfo = CommonUIConverter.getGridViewRowInfo(leadMapperDTO);
                if (leadMapperDTO.IsError)
                {
                    leadMapperDTO.ErrorMessage = (leadMapperDTO.AllErrorMessage.Count > 1) ? "Multiple errors occurred." : leadMapperDTO.AllErrorMessage[0];
                }
            }
        }
    }
    private LeadDetailDTO populateLeadDTO(LeadMapperDTO leadMapperDTO)
    {
        LeadDetailDTO leadDetailDTO = new LeadDetailDTO();
        try
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            leadDetailDTO.Property = new PropertyDTO();
            leadDetailDTO.Property.Id = CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()).Id;
            if (!string.IsNullOrWhiteSpace(leadMapperDTO.Salutation))
                leadDetailDTO.Salutation = CommonUIConverter.getMasterControlDTO(drpBO.getListItem(getSessionPageData().drpLeadSalutation, leadMapperDTO.Salutation).Value, "");
            leadDetailDTO.FirstName = leadMapperDTO.FirstName.TrimNullable();
            leadDetailDTO.MiddleName = leadMapperDTO.MiddleName.TrimNullable();
            leadDetailDTO.LastName = leadMapperDTO.LastName.TrimNullable();
            leadDetailDTO.LeadDate = DateUtil.getUserLocalDateTime();
            leadDetailDTO.ContactInfo = new ContactInfoDTO();
            leadDetailDTO.ContactInfo.Contact = leadMapperDTO.Contact;
            leadDetailDTO.ContactInfo.AltContact = leadMapperDTO.AltContact;
            leadDetailDTO.ContactInfo.Email = leadMapperDTO.Email;
            leadDetailDTO.Budget = CommonUtil.getDecimalWithoutExt(leadMapperDTO.Budget);
            if (!string.IsNullOrWhiteSpace(leadMapperDTO.LeadSource))
                leadDetailDTO.Source = CommonUIConverter.getMasterControlDTO(drpBO.getListItem(getSessionPageData().drpLeadSource, leadMapperDTO.LeadSource).Value, "");
            leadDetailDTO.FirmNumber = userDefDto.FirmNumber;
            leadDetailDTO.InsertUser = userDefDto.Username;
            leadDetailDTO.UpdateUser = userDefDto.Username;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw new CustomException("Unexpected error while parsing record. Row:" + leadMapperDTO.RowNumber);
        }
        return leadDetailDTO;
    }
    private void validateInputDTO(LeadMapperDTO inputDTO, List<LeadMapperDTO> inputList)
    {
        List<string> errorList = new List<string>();
        try
        {
            //1. Mandatory Validations
            //2. Format validations (Date/Amount)
            //3. Valid values
            //4. Length validations
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            //Property
            if (string.IsNullOrWhiteSpace(inputDTO.PropertyName)) errorList.Add("Property Name is required.");
            else if (!inputDTO.PropertyName.Equals(txtUploadLeadProperty.Text)) errorList.Add("Property name does not match with selected Property.");
            //Salutation
            if (string.IsNullOrWhiteSpace(inputDTO.Salutation)) errorList.Add("Salutation is required.");
            else if (!drpBO.containsItem(getSessionPageData().drpLeadSalutation, inputDTO.Salutation)) errorList.Add("Salutation is invalid.");
            //FirstName
            if (string.IsNullOrWhiteSpace(inputDTO.FirstName)) errorList.Add("FirstName is required.");
            else if (!StringUtil.isValidLength(inputDTO.FirstName, 100)) errorList.Add("Length of First Name must be less than 100 characters.");
            //Contact
            if (string.IsNullOrWhiteSpace(inputDTO.Contact)) errorList.Add("Contact is required.");
            else if (!StringUtil.isValidLength(inputDTO.Contact, 15)) errorList.Add("Length of Contact must be less than 15 characters.");
            //Alt Contact
            if (!StringUtil.isValidLength(inputDTO.AltContact, 15)) errorList.Add("Length of Alt Contact must be less than 15 characters.");
            //Email
            if (!StringUtil.isValidLength(inputDTO.Email, 100)) errorList.Add("Length of Email must be less than 100 characters.");
            //Budget
            if (!StringUtil.isValidDecimalNullable(inputDTO.Budget)) errorList.Add("Budget is not valid.");

            if (errorList.Count == 0)
            {
                IList<VwEnquiryLead> dupLeadEnquiry = enquiryBO.fetchDuplicateEnquiryOrLead(CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()).Id, inputDTO.Contact, inputDTO.AltContact);
                if (dupLeadEnquiry != null && dupLeadEnquiry.Count > 0)
                {
                    errorList.Add(string.Format("Lead already exits with contact Number {0}.", inputDTO.Contact));
                }
                else
                {
                    foreach (LeadMapperDTO leadDetailDTO in inputList)
                    {
                        if (string.IsNullOrWhiteSpace(inputDTO.Contact) && string.IsNullOrWhiteSpace(leadDetailDTO.Contact))
                        {
                            errorList.Add(string.Format("Duplicate contact Number {0}.", leadDetailDTO.Contact));
                        }
                    }
                }
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            errorList.Add("Unexpected error while parsing record.");
        }
        inputDTO.IsError = (errorList.Count > 0);
        inputDTO.AllErrorMessage = errorList;
    }

    private bool validateFileType(string extension)
    {
        bool isValid = true;
        if (extension != ".xlsx" && extension != ".xls")
        {
            isValid = false;
            setErrorMessage("Please Select Lead Excel with extension xlsx or xls.", commonError);
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;

    }
}