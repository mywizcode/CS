﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initAccountSummarySearchGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initAccountSummarySearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        customBtnGrpId: "#accountSearchBtnDiv",
        rowInfoModalTitle: "Account Details",
        pageLength: 10
    };

    $("[id$='AccountSummarySearchGrid']").CSBasicDatatable(dtOptions);
}





