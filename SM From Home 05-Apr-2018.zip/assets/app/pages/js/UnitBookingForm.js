﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
	initTaxGrid();
	initCMTaxGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initTaxGrid() {
    var dtOptions = {
        hasActionColumn: false,
        hideSearch: true,
        pagination: false,
        sorting: false
    };

    $("[id$='taxDetailGrid']").CSBasicDatatable(dtOptions);
}
function initCMTaxGrid() {
    var dtOptions = {
        hasActionColumn: false,
        hideSearch: true,
        pagination: false,
        sorting: false
    };

    $("[id$='cmTaxDetailGrid']").CSBasicDatatable(dtOptions);
}



