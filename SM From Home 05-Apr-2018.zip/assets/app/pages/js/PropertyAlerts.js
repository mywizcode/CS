﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initPropertyAlertGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}
function initPropertyAlertGrid() {
    var dtOptions = {
        hasActionColumn: false,
        isViewOnly: false,
        pageLength: 10,
        hideSearch: true,
        sorting: false
    };

    $("[id$='propertyAlertGrid']").CSBasicDatatable(dtOptions);
}