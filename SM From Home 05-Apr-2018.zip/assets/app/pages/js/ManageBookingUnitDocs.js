﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initFolderContentGrid();
	formatFields(controlToFormat);
    showModal(controlToFormat);
}
function initFolderContentGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#folderContentGridBtnDiv",
        pagination: false,
        sortColumn: 3,
        sortOrder: 'desc',
        hideSearch: true
    };

    $("[id$='folderContentGrid']").CSBasicDatatable(dtOptions);
}