﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initSoldUnitGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}
function initSoldUnitGrid() {
    var dtOptions = {
        pageLength: 5,
        hideSearch: true
    };

    $("[id$='soldUnitsGrid']").CSBasicDatatable(dtOptions);
}




