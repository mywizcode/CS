﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NHibernate;
using NHibernate.Criterion;

namespace ConstroSoft.Logic.BO
{

    public class PropertyUnitManagementBO
    {
        private static readonly log4net.ILog log =
             log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public PropertyUnitManagementBO() { }


        public IList<PropertyUnitDTO> fetchPropertyUnitGridData(string firmNumber, PropertyUnitFilterDTO filterDTO, long propertyTowerId)
        {
            ISession session = null;
            IList<PropertyUnitDTO> results = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                PropertyUnitDTO puDto = null;
                PropertyUnit pu = null;
                PropertyTower pt = null;
                MasterControlData dg = null;
                MasterControlData dgd = null;
                MasterControlData dgf = null;
                Property pr = null;

                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => pu.Id).WithAlias(() => puDto.Id))
                            .Add(Projections.Property(() => dg.Name), "UnitType.Name")
                            .Add(Projections.Property(() => pu.Wing).WithAlias(() => puDto.Wing))
                            .Add(Projections.Property(() => pu.UnitNo).WithAlias(() => puDto.UnitNo))
                            .Add(Projections.Property(() => pu.FloorNo).WithAlias(() => puDto.FloorNo))
                            .Add(Projections.Property(() => pu.BuildupArea).WithAlias(() => puDto.BuildupArea))
                            .Add(Projections.Property(() => pu.CarpetArea).WithAlias(() => puDto.CarpetArea))
                            .Add(Projections.Property(() => dgd.Name), "Direction.Name")
                            .Add(Projections.Property(() => pu.Status).WithAlias(() => puDto.Status))
                            .Add(Projections.Property(() => dgf.Name), "Facing.Name");
                var query = session.QueryOver<PropertyUnit>(() => pu)
                                  .Left.JoinAlias(() => pu.UnitType, () => dg)
                                  .Left.JoinAlias(() => pu.Direction, () => dgd)
                                  .Left.JoinAlias(() => pu.Facing, () => dgf)
                                  .Left.JoinAlias(() => pu.PropertyTower, () => pt);

                if (filterDTO != null)
                {
                    ICriteria criteria = query.RootCriteria;
                    if (filterDTO.UnitId > 0)
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<PropertyUnit>(() => pu, x => x.Id), filterDTO.UnitId));
                    }
                    if (filterDTO.UnitType != null)
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<MasterControlData>(() => dg, x => x.Id), filterDTO.UnitType.Id));
                    }
                    if (!string.IsNullOrWhiteSpace(filterDTO.Wing))
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<PropertyUnit>(() => pu, x => x.Wing), filterDTO.Wing));
                    }
                    if (!string.IsNullOrWhiteSpace(filterDTO.FloorNo))
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<PropertyUnit>(() => pu, x => x.FloorNo), filterDTO.FloorNo));
                    }
                    if (filterDTO.Status != null)
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<PropertyUnit>(() => pu, x => x.Status), filterDTO.Status));
                    }
                }
                results = query.Where(() => pu.FirmNumber == firmNumber && pt.Id == propertyTowerId)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<PropertyUnitDTO>()).List<PropertyUnitDTO>();
                results.ToList().ForEach(x => x.UnitNo
                       = CommonUIConverter.getPropertyUnitFormattedNo(x.Wing, x.UnitNo));
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating enquiry grid:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }


        public List<PropertyUnitDTO> fetchPropertyUnits(string firmNumber, long propertyTowerId)
        {
            ISession session = null;
            List<PropertyUnitDTO> propertyUnitList = new List<PropertyUnitDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit pu = null;
                        Property p = null;
                        IList<PropertyUnit> result = session.QueryOver<PropertyUnit>(() => pu).JoinAlias(() => pu.PropertyTower, () => p)
                            .Where(() => pu.FirmNumber == firmNumber && p.Id == propertyTowerId).List<PropertyUnit>();
                        foreach (PropertyUnit propertyUnit in result)
                        {
                            propertyUnitList.Add(DomainToDTOUtil.convertToPropertyUnitDTO(propertyUnit, true));
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching property unit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return propertyUnitList;
        }

        public PropertyUnitDTO fetchPropertyUnitDetails(long Id)
        {
            ISession session = null;
            PropertyUnitDTO propertyUnitDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit propertyunit = session.Get<PropertyUnit>(Id);
                        propertyUnitDto = DomainToDTOUtil.convertToPropertyUnitDTO(propertyunit, true);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Property Unit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return propertyUnitDto;
        }
        public long savePropertyUnitDetails(PropertyUnitDTO propertyUnitDTO)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit propertyUnit = DTOToDomainUtil.populatePropertyUnitAddFields(propertyUnitDTO);
                        session.Save(propertyUnit);
                        Id = propertyUnit.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Property Unit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        public bool validateUnitExist(string firmNumber, long towerId, string wing, string floorNo, string unitNo)
        {
            ISession session = null;
            bool exist = false;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit pu = null;
                        PropertyTower pt = null;
                        exist = session.QueryOver<PropertyUnit>(() => pu)
                            .Left.JoinAlias(() => pu.PropertyTower, () => pt)
                            .Where(() => pu.FirmNumber == firmNumber && pt.Id == towerId
                                && pu.Wing == wing && pu.FloorNo == floorNo && pu.UnitNo == unitNo)
                            .RowCount() > 0;
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while validating unique Property Unit:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return exist;
        }
        public void updatePropertyUnitDetails(PropertyUnitDTO propertyUnitDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit propertyUnit = session.Get<PropertyUnit>(propertyUnitDto.Id);
                        DTOToDomainUtil.populatePropertyUnitDetailUpdateFields(propertyUnit, propertyUnitDto);
                        session.Update(propertyUnit);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating Property Unit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public BusinessOutputTO deletePropertyUnitDetails(long Id)
        {
            ISession session = null;
            BusinessOutputTO businessOutputTO = new BusinessOutputTO();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit propertyUnit = session.Get<PropertyUnit>(Id);
                        session.Delete(propertyUnit);
                        businessOutputTO.status = BusinessOutputTO.Status.SUCCESS;
                        tx.Commit();
                    }
                    catch (NHibernate.Exceptions.GenericADOException e)
                    {
                        string message = Resources.Messages.system_error;
                        if (e.Message.IndexOf("REFERENCE constraint") > 0)
                        {
                            message = Resources.Messages.system_error;
                        }
                        businessOutputTO.status = BusinessOutputTO.Status.FAILURE;
                        tx.Rollback();
                        log.Error("Exception while deleting Property Unit details:", e);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while deleting Property Unit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return businessOutputTO;
        }
        public void updateUnitAsDeleted(long Id)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit propertyUnit = session.Get<PropertyUnit>(Id);
                        propertyUnit.Status = PRUnitStatus.Deleted;
                        session.Update(propertyUnit);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while validating updating Unit as deleted:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public bool isAlreadyExist(string firmNumber, long towerId, string wing, string unitNo)
        {
            ISession session = null;
            bool isExist = false;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit pu = null;
                        Property p = null;
                        IList<PropertyUnit> result = session.QueryOver<PropertyUnit>(() => pu).JoinAlias(() => pu.PropertyTower, () => p)
                            .Where(() => pu.FirmNumber == firmNumber && p.Id == towerId && pu.Wing == wing && pu.UnitNo == unitNo).List<PropertyUnit>();
                        if (result != null && result.Count() > 0)
                        {
                            isExist = true;
                        }

                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while validating duplicate Unit No:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return isExist;
        }

    }
}