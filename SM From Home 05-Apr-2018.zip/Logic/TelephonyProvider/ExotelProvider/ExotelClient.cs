﻿
using RestSharp;
using System;


/// <summary>
/// Summary description for FBIntegrationBO
/// </summary>
namespace ConstroSoft.TelephonyProvider.ExotelProvider
{
    public class ExotelClient
    {

        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        
        CallHistoryBO callHistoryBO = new CallHistoryBO();
        FirmBO firmBO = new FirmBO();
        public ExotelClient()
        {

        }

        /**
         * This API will connect two numbers, Outgoing call to connect two numbers.
         * It connects From Number first. Once the person at the From end picks up the phone, it will connect to the number provided as To.
         * You can choose which number should be connected first by adding that number in the From field. An HTTP POST request is made to
         * https://<your_sid>:<your_token>@api.exotel.com/v1/Accounts/<your_sid>/Calls/connect
         * agentPhoneNumber - User/Sales Agent Phone number configured in Exotel
         * customerNumber - Enquiry/Lead/Customer phone number. If landline number, prefix it with STD code; 
         * callerId- This is your ExoPhone/Exotel Virtual Number
         * StatusCallback - When the call completes, an HTTP POST will be made to the provided URL with the following four parameters:
         * CallSid - an alpha-numeric unique identifier
         * Status - one of: completed, failed, busy, no-answer
         * RecordingUrl - link to the call recording (if it exists)
         * DateUpdated - time when the call state was updated last
         */
        public CallHistoryDTO placeOutBoundCall(OutboundCallDialDTO callDialDTO, UserDefinitionDTO userDefDTO)
        {

            InOutBoundCallResDTO outBoundCallResDTO = new InOutBoundCallResDTO();
            ExotelExceptionDTO exotelExceptionDTO = new ExotelExceptionDTO();
            CallHistoryDTO callHistoryDTO = new CallHistoryDTO();
            try
            {
            	ExotelDTO exotelDto = firmBO.fetchExotelDetails(userDefDTO.FirmNumber);
                //Exotel Outbound Call Client using RestSharp Client.
                var client = new RestClient(exotelDto.OutCallURL);
                client.Authenticator = new HttpBasicAuthenticator(exotelDto.Sid, exotelDto.Token);
                var request = new RestRequest(Method.POST);
                request.AddHeader("cache-control", "no-cache");
                request.AddHeader("content-type", "application/x-www-form-urlencoded");
                request.AddParameter("application/x-www-form-urlencoded", "From=" + callDialDTO.AgentNumber + "&To="
                    + callDialDTO.CustomerNumber + "&CallerId=" + callDialDTO.VirtualPhone + "&CallType=" + exotelDto.CallType +
                    "&StatusCallback=" + exotelDto.OutCallBackURL, ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);
                if (response.StatusCode.GetDescription().Equals("OK"))
                {
                    outBoundCallResDTO = (InOutBoundCallResDTO)Newtonsoft.Json.JsonConvert.DeserializeObject(response.Content, typeof(InOutBoundCallResDTO));
                    DTOToDomainUtil.populateCallHistoryDTOFromExotelCall(outBoundCallResDTO.Call, callHistoryDTO, false);
                    callHistoryDTO.CallHistoryStatus = CallHistoryStatus.Unresolved;
                    callHistoryDTO.FirmMember = new FirmMemberDTO();
                    callHistoryDTO.FirmMember.Id = userDefDTO.FirmMember.Id;
                    callHistoryDTO.Property = new PropertyDTO();
                    callHistoryDTO.Property.Id = callDialDTO.PropertyId;
                    if (callDialDTO.PrUnitSaleId > 0)
                    {
                        callHistoryDTO.PrUnitSaleDetail = new PrUnitSaleDetailDTO();
                        callHistoryDTO.PrUnitSaleDetail.Id = callDialDTO.PrUnitSaleId;
                    }

                    callHistoryDTO.FirmNumber = userDefDTO.FirmNumber;
                    callHistoryDTO.InsertUser = userDefDTO.Username;
                    callHistoryDTO.UpdateUser = userDefDTO.Username;
                    long Id = callHistoryBO.addCallHistory(callHistoryDTO);
                    callHistoryDTO.Id = Id;
                }
                else {
                    exotelExceptionDTO = (ExotelExceptionDTO)Newtonsoft.Json.JsonConvert.DeserializeObject(response.Content, typeof(ExotelExceptionDTO));
                    log.Debug("Error while placing outbound call : "+exotelExceptionDTO.RestException.Message);
                    throw new CustomException("Unable to place a call. Please contact system administrator.");
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while placing outbound call");
                log.Error(exp.Message, exp);
                throw new CustomException("Unable to place a call. Please contact system administrator.");
            }
            finally
            {
            }
            return callHistoryDTO;
        }
        /**
         * To get details of a call (including Status, Price, etc.), you will need to make a HTTP GET request to
         * https://<your_sid>:<your_token>@api.exotel.com/v1/Accounts/<your_sid>/Calls/<CallSid>
         * 
         */
        public InOutBoundCallResDTO getCallDetails(string callSid, string FirmNumber)
        {

            InOutBoundCallResDTO outBoundCallResDTO = null;
            try
            {
            	ExotelDTO exotelDto = firmBO.fetchExotelDetails(FirmNumber);
                var client = new RestClient(exotelDto.CallDetailsURL + callSid+".json");
                client.Authenticator = new HttpBasicAuthenticator(exotelDto.Sid, exotelDto.Token);
                var request = new RestRequest(Method.GET);
                request.AddHeader("cache-control", "no-cache");
                IRestResponse response = client.Execute(request);
                outBoundCallResDTO = (InOutBoundCallResDTO)Newtonsoft.Json.JsonConvert.DeserializeObject(response.Content, typeof(InOutBoundCallResDTO));
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while retreiving call details for :" + callSid);
                log.Error(exp.Message, exp);
            }
            finally
            {
            }
            return outBoundCallResDTO;
        }
    }
}