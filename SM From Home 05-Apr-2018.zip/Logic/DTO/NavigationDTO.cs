﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ConstroSoft;

/// <summary>
/// </summary>
namespace ConstroSoft
{
	[Serializable]
    public class ResetPasswordNavDTO
    {
        public ResetPasswordNavDTO() { }
        public ResetPasswordStep Step { get; set; }
    }
	[Serializable]
    public class CRMDashboardNavDTO
    {
        public CRMDashboardNavDTO() { }
        public int NoOfMonths { get; set; }
        public long TowerId { get; set; }
    }
	[Serializable]
    public class CallHistoryNavDTO
    {
        public CallHistoryNavDTO() { }
        public CallHistoryFilterDTO filterDTO { get; set; }
        public object PrevNavDto { get; set; }
    }
	[Serializable]
    public class UnresolvedCallsNavDTO
    {
        public UnresolvedCallsNavDTO() { }
        public UnresolvedCallsFilterDTO filterDTO { get; set; }
        public object PrevNavDto { get; set; }
    }
	[Serializable]
    public class ResolveCallNavDTO
    {
        public ResolveCallNavDTO() { }
        public string CustomerNumber { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class AllEnquiryLeadHistoryNavDTO
    {
        public AllEnquiryLeadHistoryNavDTO() { }
    }
    [Serializable]
    public class UserEnquiryHistoryNavDTO
    {
        public UserEnquiryHistoryNavDTO() { }
        public long FirmMemberId { get; set; }
        public EnquiryFilterDTO FilterDTO { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class UserLeadHistoryNavDTO
    {
        public UserLeadHistoryNavDTO() { }
        public long FirmMemberId { get; set; }
        public LeadFilterDTO FilterDTO { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class EnquiryActivityHistoryNavDTO
    {
        public EnquiryActivityHistoryNavDTO() { }
        public long EnquiryId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class LeadActivityHistoryNavDTO
    {
        public LeadActivityHistoryNavDTO() { }
        public long LeadId { get; set; }
        public object PrevNavDto { get; set; }
    }
	[Serializable]
    public class EnquiryAddActivityNavDTO
    {
        public EnquiryAddActivityNavDTO() { }
        public long EnquiryId { get; set; }
    }
	[Serializable]
    public class EnquirySearchNavDTO
    {
        public EnquirySearchNavDTO() { }
        public bool AllUserLeads { get; set; }
        public EnquiryFilterDTO filterDTO { get; set; }
    }
    [Serializable]
    public class EnquiryDetailNavDTO
    {
        public EnquiryDetailNavDTO() { }
        public PageMode Mode { get; set; }
        public long EnquiryId { get; set; }
        public long ConvertedLeadId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class LeadAssignmentNavDTO
    {
        public LeadAssignmentNavDTO() { }
    }
    [Serializable]
    public class MyLeadsNavDTO
    {
        public MyLeadsNavDTO() { }
        public LeadFilterDTO filterDTO { get; set; }
        public bool AllUserLeads { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class EmailSMSTemplateStoreNavDTO
    {
        public EmailSMSTemplateStoreNavDTO() { }

        public EmailSmsStoreFilterDTO filterDTO { get; set; }
    }
    [Serializable]
    public class EmailTemplateNavDTO
    {
        public EmailTemplateNavDTO() { }
        public PageMode Mode { get; set; }
        public long TemplateId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class SMSTemplateNavDTO
    {
        public SMSTemplateNavDTO() { }
        public PageMode Mode { get; set; }
        public long TemplateId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class EmailSMSCampaignSearchNavDTO
    {
        public EmailSMSCampaignSearchNavDTO() { }

        public EmailSMSCampaignFilterDTO filterDTO { get; set; }
    }
    [Serializable]
    public class EmailCampaignNavDTO
    {
        public EmailCampaignNavDTO() { }
        public PageMode Mode { get; set; }
        public long CampaignId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class SMSCampaignNavDTO
    {
        public SMSCampaignNavDTO() { }
        public PageMode Mode { get; set; }
        public long CampaignId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class BookingFormNavDTO
    {
        public BookingFormNavDTO() { }
        public long PrUnitId { get; set; }
        public long EnquiryId { get; set; }
        public bool copyCustomerDtls { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class BookingSuccessNavDTO
    {
        public BookingSuccessNavDTO() { }
        public long PrUnitSaleDetailId { get; set; }
    }
    [Serializable]
    public class BookingCancellationNavDTO
    {
        public BookingCancellationNavDTO() { }
        public long PrUnitSaleDetailId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class BookingCancelSuccessNavDTO
    {
        public BookingCancelSuccessNavDTO() { }
        public long PrUnitSaleDetailId { get; set; }
    }
    [Serializable]
    public class AvailableUnitNavDTO
    {
        public AvailableUnitNavDTO() { }
        public PropertyUnitFilterDTO filterDTO { get; set; }
    }
    [Serializable]
    public class PropertySearchNavDTO
    {
        public PropertySearchNavDTO() { }
        public PropertyFilterDTO filterDTO { get; set; }
    }
    [Serializable]
    public class PropertyDetailNavDTO
    {
        public PropertyDetailNavDTO() { }
        public PageMode Mode { get; set; }
        public long PropertyId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class PropertyConfigurationNavDTO
    {
        public PropertyConfigurationNavDTO() { }
        public long PropertyId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class PropertyAlertsNavDTO
    {
        public PropertyAlertsNavDTO() { }
        public long PropertyId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class PropertyAlertDetailsNavDTO
    {
        public PropertyAlertDetailsNavDTO() { }
        public long PropertyId { get; set; }
        public long AlertId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class VirtualPhoneUserAccessNavDTO
    {
        public VirtualPhoneUserAccessNavDTO() { }
        public long PropertyId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class ReportLetterTemplateNavDTO
    {
        public ReportLetterTemplateNavDTO() { }
        public long PropertyId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class PropertyUnitSearchNavDTO
    {
        public PropertyUnitSearchNavDTO() { }
        public PropertyUnitFilterDTO filterDTO { get; set; }
    }
    [Serializable]
    public class PropertyUnitDetailNavDTO
    {
        public PropertyUnitDetailNavDTO() { }
        public PageMode Mode { get; set; }
        public long PrUnitId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class PropertyUnitUploadNavDTO
    {
        public PropertyUnitUploadNavDTO() { }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class PropertyParkingSearchNavDTO
    {
        public PropertyParkingSearchNavDTO() { }
        public PropertyParkingFilterDTO filterDTO { get; set; }
    }
    [Serializable]
    public class PropertyParkingDetailNavDTO
    {
        public PropertyParkingDetailNavDTO() { }
        public PageMode Mode { get; set; }
        public long ParkingId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class PropertyParkingUploadNavDTO
    {
        public PropertyParkingUploadNavDTO() { }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class PrPymtScheduleNavDTO
    {
        public PrPymtScheduleNavDTO() { }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class SoldUnitSearchNavDTO
    {
        public SoldUnitSearchNavDTO() { }
        public SoldUnitFilterDTO filterDTO { get; set; }
    }
    [Serializable]
    public class SoldUnitDetailNavDTO
    {
        public SoldUnitDetailNavDTO() { }
        public PageMode Mode { get; set; }
        public long PrUnitSaleDetailId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class CancelledUnitSearchNavDTO
    {
        public CancelledUnitSearchNavDTO() { }
        public SoldUnitFilterDTO filterDTO { get; set; }
    }
    [Serializable]
    public class CancelledUnitDetailNavDTO
    {
        public CancelledUnitDetailNavDTO() { }
        public PageMode Mode { get; set; }
        public long PrUnitSaleDetailId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class LetterGenerationNavDTO
    {
        public LetterGenerationNavDTO() { }
        public long PrUnitSaleDetailId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class CustomerCallHistoryNavDTO
    {
        public CustomerCallHistoryNavDTO() { }
        public long PrUnitSaleDetailId { get; set; }
        public CallHistoryFilterDTO filterDTO { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class ManageBookingUnitDocsNavDTO
    {
        public ManageBookingUnitDocsNavDTO() { }
        public long PrUnitSaleDetailId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class CustomerPymtSearchNavDTO
    {
        public CustomerPymtSearchNavDTO() { }
        public CustomerPymtSearchFilterDTO filterDTO { get; set; }
    }
    [Serializable]
    public class CustomerPaymentNavDTO
    {
        public CustomerPaymentNavDTO() { }
        public bool IsPdcPayment { get; set; }
        public PageMode Mode { get; set; }
        public PaymentMode? PymtMode { get; set; }
        public long PrUnitSaleDetailId { get; set; }
        public long MPTId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class CustomerPymtHistoryNavDTO
    {
        public CustomerPymtHistoryNavDTO() { }
        public long PrUnitSaleDetailId { get; set; }
        public PaymentMode? PymtMode { get; set; }
        public bool isPdc { get; set; }
        public object PrevNavDto { get; set; }
        public CustomerPymtTxHistoryFilterDTO FilterDTO { get; set; }
    }
    [Serializable]
    public class PropertyFundSearchNavDTO
    {
        public PropertyFundSearchNavDTO() { }
        public PropertyFundFilterDTO filterDTO { get; set; }
    }
    [Serializable]
    public class PropertyFundDetailNavDTO
    {
        public PropertyFundDetailNavDTO() { }
        public PageMode Mode { get; set; }
        public long propertyFundId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class MasterDataSetupNavDTO
    {
        public MasterDataSetupNavDTO() { }
    }
    [Serializable]
    public class EmailSMSProviderNavDTO
    {
        public EmailSMSProviderNavDTO() { }
    }
	[Serializable]
    public class FirmAccountNavDTO
    {
        public FirmAccountNavDTO() { }
        public long ID { get; set; }
        public long FirmID { get; set; }
        public object PrevNavDto { get; set; }
        public PageMode Mode { get; set; }
    }
 [Serializable]
    public class FirmAccountStatementsNavDTO
    {
        public FirmAccountStatementsNavDTO() { }
        public long AcntID { get; set; }
        public long FirmID { get; set; }
        public object PrevNavDto { get; set; }
        public PageMode Mode { get; set; }
    }
	[Serializable]
	public class ManageCustomerDocsNavDTO
	{
	    public ManageCustomerDocsNavDTO() { }
	    public long CustomerId { get; set; }
	    public object PrevNavDto { get; set; }
    }
	[Serializable]
	public class CustomerSearchNavDTO
	{
	    public CustomerSearchNavDTO() { }
        public CustomerFilterDTO filterDTO { get; set; }
	}
	[Serializable]
    public class CustomerDetailNavDTO
    {
        public CustomerDetailNavDTO() { }
        public PageMode Mode { get; set; }
        public long CustomerId { get; set; }
        public object PrevNavDto { get; set; }
    }
	[Serializable]
	public class ManagePropertyDocsNavDTO
	{
	    public ManagePropertyDocsNavDTO() { }
	    public long PropertyId { get; set; }
	    public object PrevNavDto { get; set; }
	}
    [Serializable]
    public class VoucherSearchNavDTO
    {
        public VoucherSearchNavDTO() { }
        public VoucherFilterDTO filterDTO { get; set; }
    }
    [Serializable]
    public class PaymentDueReportNavDTO
    {
        public PaymentDueReportNavDTO() { }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class LeadEnquiryReportNavDTO
    {
        public LeadEnquiryReportNavDTO() { }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class PropertyUserAccessNavDTO
    {
        public PropertyUserAccessNavDTO() { }
        public long PropertyId { get; set; }
        public object PrevNavDto { get; set; }

    }
    [Serializable]
    public class LeadUploadNavDTO
    {
        public LeadUploadNavDTO() { }
        public object PrevNavDto { get; set; }
    }
}