﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using ConstroSoft;

public partial class EnquirySearch : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
            log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string SearchFilterModal = "SearchFilterModal";
    DropdownBO drpBO = new DropdownBO();
    EnquiryBO enquiryBO = new EnquiryBO();
    protected void Page_Load(object sender, EventArgs e)
    {
    	if (ApplicationUtil.isSubPageRendered(Page)) clearMessages();
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                EnquirySearchNavDTO navDto = CommonUtil.getPageNavDTO<EnquirySearchNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_MY_ENQUIRIES)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
        * This method is called just before the page is rendered. So any change in state of the element is applied.
        **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
        addCheckBoxAttributes();
    }
    public void initBootstrapComponantsFromServer()
    {
    	ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpEnum<EnquiryStatus>(drpStatusFilter, Constants.SELECT_ITEM);
        drpBO.drpDataBase(drpSourceFilter, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ENQUIRY_SOURCE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
    }
    private void addCheckBoxAttributes()
    {
        cbShowAllLeads.InputAttributes.Add("class", "styled block-ui-change");
        cbShowAllLeads.InputAttributes.Add("data-panel", "blockui-panel-1");
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(EnquirySearchNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new EnquirySearchPageDTO();
        initDropdowns();
        EnquiryFilterDTO FilterDTO = new EnquiryFilterDTO();
        //Default Open Enquiries will be shown when page is loaded
        FilterDTO.Status = EnquiryStatus.Open;
        setSearchFilter(FilterDTO);
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(EnquirySearchNavDTO navDto)
    {
        try
        {
            if (navDto != null)
            {
                setSearchFilter(navDto.filterDTO);
            }
            loadEnquirySearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageFieldsWithEntitlement()
    {
    	UserDefinitionDTO userDefDto = getUserDefinitionDTO();
    	lnkAddEnquiryUnitBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.ENQUIRY_ADD);
    	if (enquirySearchGrid.Rows.Count > 0)
        {
            for (var i = 0; i < enquirySearchGrid.Rows.Count; i++)
            {
                HtmlGenericControl tmpBtn = (HtmlGenericControl)enquirySearchGrid.Rows[i].FindControl("liModifyEnquiryBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.ENQUIRY_MODIFY);
            }
        }
    }
    private EnquirySearchPageDTO getSessionPageData()
    {
        return (EnquirySearchPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<EnquiryDetailDTO> getSearchEnquiryDetailList()
    {
        return getSessionPageData().SearchResult;
    }
    private EnquiryDetailDTO getSearchEnquiryDetailDTO(long Id)
    {
        List<EnquiryDetailDTO> searchList = getSearchEnquiryDetailList();
        EnquiryDetailDTO selectedUnitDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            selectedUnitDTO = searchList.Find(c => c.Id == Id);
        }
        return selectedUnitDTO;
    }
    private void populateEnquirySearchGrid(List<EnquiryDetailDTO> tmpList)
    {
        enquirySearchGrid.DataSource = new List<EnquiryDetailDTO>();
        if (tmpList != null)
        {
            assignUiIndexToEnquirys(tmpList);
            enquirySearchGrid.DataSource = tmpList;
        }
        enquirySearchGrid.DataBind();
    }
    private void assignUiIndexToEnquirys(List<EnquiryDetailDTO> tmpList)
    {
        if (tmpList != null && tmpList.Count > 0)
        {
            long uiIndex = 1;
            foreach (EnquiryDetailDTO tmpDTO in tmpList)
            {
                tmpDTO.UiIndex = uiIndex++;
                tmpDTO.RowInfo = CommonUIConverter.getGridViewRowInfo(tmpDTO);
                tmpDTO.FullName = CommonUIConverter.getCustomerFullName(tmpDTO.Salutation.Name, tmpDTO.FirstName, tmpDTO.MiddleName, tmpDTO.LastName);
                tmpDTO.NoOfDaysAssgined = (DateTime.Today - tmpDTO.AssignedDate.Value).Days;
            }
        }
    }
    private void loadEnquirySearchGrid()
    {
        EnquirySearchPageDTO PageDTO = getSessionPageData();
        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        PropertyDTO property = CommonUtil.getCurrentPropertyDTO(userDefDTO);
        IList<EnquiryDetailDTO> results = enquiryBO.fetchEnquiryGridData(property.Id, userDefDTO.FirmMember.Id, getSearchFilter());
        PageDTO.SearchResult = (results != null) ? results.ToList<EnquiryDetailDTO>() : new List<EnquiryDetailDTO>();
        populateEnquirySearchGrid(PageDTO.SearchResult);
    }
    protected void onClickViewEnquiryBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            navigateToEnquiryDetails(selectedId, PageMode.VIEW);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickAddEnquiryBtn(object sender, EventArgs e)
    {
        try
        {
            navigateToEnquiryDetails(0, PageMode.ADD);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyEnquiryBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            navigateToEnquiryDetails(selectedId, PageMode.MODIFY);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickActiveHistoryBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            EnquiryActivityHistoryNavDTO navDTO = new EnquiryActivityHistoryNavDTO();
            navDTO.EnquiryId = selectedId;
            navDTO.PrevNavDto = getCurrentPageNavigation();
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.ENQUIRY_ACTIVITY_HISTORY, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onChangeShowAllLeads(object sender, EventArgs e)
    {
        try
        {
            CheckBox cb = (CheckBox)sender;
            EnquiryFilterDTO FilterDTO = getSearchFilter();
            FilterDTO.Status = EnquiryStatus.Open;
            if (cb.Checked) FilterDTO.Status = null;
            setSearchFilter(FilterDTO);
            loadEnquirySearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private EnquirySearchNavDTO getCurrentPageNavigation()
    {
        EnquirySearchNavDTO searchNavDTO = new EnquirySearchNavDTO();
        searchNavDTO.filterDTO = getSearchFilter();
        return searchNavDTO;
    }
    private void navigateToEnquiryDetails(long selectedId, PageMode mode)
    {
        EnquiryDetailNavDTO navDTO = new EnquiryDetailNavDTO();
        navDTO.Mode = mode;
        if (mode != PageMode.ADD)
        {
            EnquiryDetailDTO enquiryDetailDTO = getSearchEnquiryDetailDTO(selectedId);
            navDTO.EnquiryId = enquiryDetailDTO.Id;  
        }
                  
        navDTO.PrevNavDto = getCurrentPageNavigation();
        Session[Constants.Session.NAV_DTO] = navDTO;
        Response.Redirect(Constants.URL.ENQUIRY_DETAILS, true);
    }        
    //Filter Criteria - Enquiry Search - Start
    private EnquiryFilterDTO getSearchFilter()
    {
        return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            EnquiryFilterDTO filterDTO = getSearchFilter();
            if (filterDTO.EnquiryRefNo != null) txtEnquiryRefNoFilter.Text = filterDTO.EnquiryRefNo; else txtEnquiryRefNoFilter.Text = null;
            if (filterDTO.LeadRefNo != null) txtLeadRefNoFilter.Text = filterDTO.LeadRefNo; else txtLeadRefNoFilter.Text = null;
            if (filterDTO.FirstName != null) txtFirstNameFilter.Text = filterDTO.FirstName; else txtFirstNameFilter.Text = null;
            if (filterDTO.LastName != null) txtLastNameFilter.Text = filterDTO.LastName; else txtLastNameFilter.Text = null;
            if (filterDTO.Contact != null) txtContactFilter.Text = filterDTO.Contact; else txtContactFilter.Text = null;
            if (filterDTO.Status != null) drpStatusFilter.Text = filterDTO.Status.ToString(); else drpStatusFilter.ClearSelection();
            if (filterDTO.SourceId > 0) drpSourceFilter.Text = filterDTO.SourceId.ToString(); else drpSourceFilter.ClearSelection();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            EnquiryFilterDTO filterDTO = new EnquiryFilterDTO();
            if (!string.IsNullOrWhiteSpace(txtEnquiryRefNoFilter.Text))
            {
                filterDTO.EnquiryRefNo = txtEnquiryRefNoFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(txtFirstNameFilter.Text))
            {
                filterDTO.FirstName = txtFirstNameFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(txtLastNameFilter.Text))
            {
                filterDTO.LastName = txtLastNameFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(txtContactFilter.Text))
            {
                filterDTO.Contact = txtContactFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(txtLeadRefNoFilter.Text))
            {
                filterDTO.LeadRefNo = txtLeadRefNoFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(drpSourceFilter.Text))
            {
                filterDTO.SourceId = long.Parse(drpSourceFilter.Text);
                filterDTO.Source = drpSourceFilter.SelectedItem.Text;
            }
            if (!string.IsNullOrWhiteSpace(drpStatusFilter.Text))
            {
                filterDTO.Status = EnumHelper.ToEnum<EnquiryStatus>(drpStatusFilter.SelectedItem.Text);
            }
            setSearchFilter(filterDTO);
            loadEnquirySearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }

    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            loadEnquirySearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(EnquiryFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new EnquiryFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            EnquiryFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.ENQUIRY_REF_NO))
            {
                filterDTO.EnquiryRefNo = null;
            }
            else if (token.StartsWith(Constants.FILTER.LEAD_REF_NO)) filterDTO.LeadRefNo = null;
            else if (token.StartsWith(Constants.FILTER.CONTACT))
            {
                filterDTO.Contact = null;
            }
            else if (token.StartsWith(Constants.FILTER.FIRST_NAME))
            {
                filterDTO.FirstName = null;
            }
            else if (token.StartsWith(Constants.FILTER.LAST_NAME))
            {
                filterDTO.LastName = null;
            }
            else if (token.StartsWith(Constants.FILTER.ENQUIRY_SOURCE))
            {
            	filterDTO.SourceId = 0;
                filterDTO.Source = null;
            }
            else if (token.StartsWith(Constants.FILTER.ENQUIRY_STATUS))
            {
                filterDTO.Status = null;
            }

            setSearchFilterTokens();
            loadEnquirySearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        EnquiryFilterDTO filterDTO = getSearchFilter();
        string filter = null;
        if (filterDTO != null)
        {
            if (filterDTO.EnquiryRefNo != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.ENQUIRY_REF_NO + filterDTO.EnquiryRefNo);
            if (filterDTO.LeadRefNo != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.LEAD_REF_NO + filterDTO.LeadRefNo);
            if (filterDTO.FirstName != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.FIRST_NAME + filterDTO.FirstName);
            if (filterDTO.LastName != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.LAST_NAME + filterDTO.LastName);
            if (filterDTO.Contact != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.CONTACT + filterDTO.Contact);
            if (filterDTO.Source != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.ENQUIRY_SOURCE + filterDTO.Source);
            if (filterDTO.Status != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.ENQUIRY_STATUS + filterDTO.Status);
        }
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - Enquiry Search - End
}