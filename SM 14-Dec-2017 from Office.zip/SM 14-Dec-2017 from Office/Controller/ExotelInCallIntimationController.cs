﻿using Newtonsoft.Json;
using System;
using System.Web;
using System.Web.Http;

namespace ConstroSoft.Controller
{
    public class ExotelInCallIntimationController : ApiController
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        CallHistoryBO callHistoryBO = new CallHistoryBO();
        NotificationBO notificationBO = new NotificationBO();

        [HttpGet]
        [ActionName("GetInCallIntimation")]
        public void GetInCallIntimation()
        {
            try
            {
                //Fetch CALL_HISTORY record from DB for CALLSID
                string CallSid = HttpContext.Current.Request.Params["CallSid"];
                string DialWhomNumber = HttpContext.Current.Request.Params["DialWhomNumber"];
                string Status = HttpContext.Current.Request.Params["Status"];
                CallHistoryDTO callHistoryDTO = callHistoryBO.fetchCallHistoryforCallSID(CallSid)
                string key = null;
                FirmMemberDTO firmMemberDTO = null;
                if(callHistoryDTO != null){
                    //Check Agent number in CALL_HISTORY is same as agent number in intimation request.
                    if(callHistoryDTO.CalleeNumber.Equals(DialWhomNumber))
                    {
                        if(Status.Equals("free"))
                        {
                            //Fetch all notifications for username & NotificationSubType = INCOMING_CALL_INTIMATION
                            List<NotificationDTO> allNotificationList = notificationBO.fetchUserNotificationsForInCall(firmMemberDTO.UserDefinitionDTO.Username);
                            key = NotificationUtil.getNotificationUserKey(notification.UserName, 0);
                            //Find Notification where RefEntityInfo = CALL_HISTORY.ID and mark as closed and update to DB
                            //Remove notification from Cache for key NotificationUtil.getNotificationUserKey() and UIUniqueKey = Notification.Id
                            foreach (Notification tmpObj in allNotificationList)
                            {
                                if(tmpObj.RefEntityInfo.Equals(callHistoryDTO.Id))
                                {
                                    notificationBO.markNotificationClosed(tmpObj.Id);
                                    NotificationCacheProvider.Instance.removeNotification(key, tmpObj.Id);
                                }
                            }
                        }
                    }
                    else
                    {
                        if(Status.Equals("busy"))
                        {
                            //Find new agent for new call number and update agent and new call history info into CALL_HISTORY table.
                            firmMemberDTO = callHistoryBO.fetchAgent(DialWhomNumber);
                            CallHistoryDTO callHistoryDTO = populateCallHistoryDTOFromCall(HttpContext.Current.Request.Params);
                            callHistoryDTO.FirmMemberDTO = firmMemberDTO;
                            long callHistoryId = callHistoryBO.updateCallHistory(callHistoryDTO);
                            //Fetch All existing INCOMING_CALL_INTIMATION notifications for current user and mark them as closed.
                            List<NotificationDTO> allNotificationList = notificationBO.fetchUserNotificationsForInCall(firmMemberDTO.UserDefinitionDTO.Username);
                            foreach (Notification tmpObj in allNotificationList)
                            {
                                notificationBO.markNotificationClosed(tmpObj.Id);
                            }
                            //Add new INCOMING_CALL_INTIMATION notification in DB.
                            Notification notification = NotificationUtil.getAlertNotification(firmMemberDTO.UserDefinitionDTO,
                                    "Incoming call from "+callHistoryDTO.CallerNumber, DateTime.Now,
                                    NotificationSubType.INCOMING_CALL_INTIMATION,callHistoryId, firmMemberDTO.UserDefinitionDTO.Username);
                            NotificationDTO notificationDTO = convertToNotificationDTO(notification, true);
                            long Id = notificationBO.addNotification(notificationDTO);
                            notificationDTO.Id = Id;
                            //Convert new INCOMING_CALL_INTIMATION record to DTO and add to notification cache
                            key = NotificationUtil.getNotificationUserKey(notification.UserName, 0);
                            NotificationCacheProvider.Instance.addCallIntimationForUser(key, notificationDTO);
                        }
                    }
                }
                else
                {
                    //Find agent and bind with CALL_HISTORY and Add new entry in CALL_HISTORY table
                    firmMemberDTO = callHistoryBO.fetchAgent(DialWhomNumber);
                    CallHistoryDTO callHistoryDTO = populateCallHistoryDTOFromCall(HttpContext.Current.Request.Params);
                    callHistoryDTO.FirmMemberDTO = firmMemberDTO;
                    long callHistoryId = callHistoryBO.addCallHistory(callHistoryDTO);
                    
                    //Fetch All existing INCOMING_CALL_INTIMATION notifications for current user and mark them as closed.
                    List<NotificationDTO> allNotificationList = notificationBO.fetchUserNotificationsForInCall(firmMemberDTO.UserDefinitionDTO.Username);
                    foreach (Notification tmpObj in allNotificationList)
                    {
                        notificationBO.markNotificationClosed(tmpObj.Id);
                    }
                    //Add new INCOMING_CALL_INTIMATION notification in DB.
                    Notification notification = NotificationUtil.getAlertNotification(firmMemberDTO.UserDefinitionDTO,
                            "Incoming call from "+callHistoryDTO.CallerNumber, DateTime.Now,
                            NotificationSubType.INCOMING_CALL_INTIMATION,callHistoryId, firmMemberDTO.UserDefinitionDTO.Username);
                    NotificationDTO notificationDTO = DomainToDTOUtil.convertToNotificationDTO(notification, true);
                    long Id = notificationBO.addNotification(notificationDTO);
                    notificationDTO.Id = Id;
                    //Convert new INCOMING_CALL_INTIMATION record to DTO and add to notification cache
                    key = NotificationUtil.getNotificationUserKey(notification.UserName, 0);
                    NotificationCacheProvider.Instance.addCallIntimationForUser(key, notificationDTO);
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while getting inbound call details.");
                log.Error(exp.Message, exp);
            }
            finally
            {
            }
        }
        public static CallHistoryDTO populateCallHistoryDTOFromCall(NameValueCollection parameters)
        {
            CallHistoryDTO callHistoryDTO = new CallHistoryDTO();
            callHistoryDTO.CallSid = parameters["CallSid"];
            callHistoryDTO.CallerNumber = parameters["CallFrom"];
            callHistoryDTO.PhoneNumberSid = parameters["CallTo"];
            callHistoryDTO.Direction = EnumHelper.ToEnum<CallStatus>(parameters["Direction"].ToString().Replace("-", ""));
            callHistoryDTO.DateCreated = Convert.ToDateTime(parameters["Created"]);
            callHistoryDTO.CalleeNumber = parameters["DialWhomNumber"];
            callHistoryDTO.InsertUser = Constants.EXOTEL.EXOTEL_SID;
            callHistoryDTO.UpdateUser = Constants.EXOTEL.EXOTEL_SID;
            callHistory.InsertDate = DateTime.Now;
            callHistory.UpdateDate = DateTime.Now;
            callHistoryDTO.CallHistoryStatus = CallHistoryStatus.Unresolved;
            return callHistoryDTO;
        }
    }
}