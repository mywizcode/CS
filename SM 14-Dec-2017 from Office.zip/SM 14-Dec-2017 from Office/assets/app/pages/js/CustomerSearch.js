﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initCustomerSearchGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initCustomerSearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        customBtnGrpId: "#customerSearchBtnDiv",
        pageLength: 10
    };

    $("[id$='customerSearchGrid']").CSBasicDatatable(dtOptions);
}
