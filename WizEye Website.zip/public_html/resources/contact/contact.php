<?php
/*
Credits: Bit Repository
URL: http://www.bitrepository.com/
*/

include 'config.php';

error_reporting (E_ALL ^ E_NOTICE);

$post = (!empty($_POST)) ? true : false;

if($post)
{

$name = stripslashes($_POST['name']);
$email = trim($_POST['email']);
$mobileNo = trim($_POST['mobileNo']);
$subject = stripslashes($_POST['subject']);
$message = stripslashes($_POST['message']);
$message .= "\r\nMobile No:".$mobileNo; 
$headers  = "From: ".$name." <".$email.">\r\n"."Reply-To: ".$email."\r\n";
$headers .= "X-Mailer: PHP/".phpversion()."\r\n" ;
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

$error = '';



if(!$error)
{
$mail = mail(TO_EMAIL, $subject, $message,$headers);


if($mail)
{
echo 'OK';
}

}


}
?>