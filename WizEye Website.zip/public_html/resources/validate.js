/*global jQuery:false */
function getQueryVariable(variable) {
    var query = window.location.search.substring(1);
    var vars = query.split('&');
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split('=');
        if (decodeURIComponent(pair[0]) == variable) {
            return decodeURIComponent(pair[1]);
        }
    }
}
jQuery(document).ready(function($) {
"use strict";

	var index = getQueryVariable("product");
	if (index != 'undefined' && index != "") {
		var productName = $("#products option[value = '"+index+"']").text();
		if (productName != "") {
			$("#pro-head-name").html(productName +" : Demo Request");
		} else {
			$("#products").removeClass("hide");
			$("#pro-head-name").html("Demo Request");
		}
	}
	
	$('#name,#email,#subject,#message,#mobileNo').focusout(function(){
	   $(this).next('div.validation').html('');
	});
	
	//Validate Contact, Request Demo forms.
	$('form.validateform').submit(function(){
		$("#successmessage").removeClass("show hide");
		$("#errormsg").removeClass("show hide");
		$("#successmessage").addClass("hide");
		$("#errormsg").addClass("hide");
		var f = $(this).find('.field'), 
		ferror = false, 
		emailExp = /^[^\s()<>@,;:\/]+@\w[\w\.-]+\.[a-z]{2,}$/i;
		if ($("#products").val()) {
			var subMessage = "";
			if (!$("#products").hasClass("hide")) {
				subMessage = $("#products option:selected").text()+" : "+$("#pro-head-name").html()+" | "+$("#name").val();
			} else {
				subMessage = $("#pro-head-name").html()+" | "+$("#name").val();
			}
			$("#subject").val(subMessage);
		}
		
		f.children("input[type='text']").each(function(){ // run all inputs

		    var i = $(this); // current input
		    var rule = i.attr('data-rule');
		    if( rule != undefined ){
			var ierror=false; // error flag for current input
			var pos = rule.indexOf( ':', 0 );
			if( pos >= 0 ){
			    var exp = rule.substr( pos+1, rule.length );
			    rule = rule.substr(0, pos);
			}else{
			    rule = rule.substr( pos+1, rule.length );
			}
			
			switch( rule ){
			    case 'required':
				if( i.val()=='' ){ ferror=ierror=true; }
				break;

			    case 'maxlen':
				if( i.val().length<parseInt(exp) ){ ferror=ierror=true; }
				break;

			    case 'email':
				if( !emailExp.test(i.val()) ){ ferror=ierror=true; }
				break;

			    case 'checked':
				if( !i.attr('checked') ){ ferror=ierror=true; }
				break;
				
			    case 'regexp':
				exp = new RegExp(exp);
				if( !exp.test(i.val()) ){ ferror=ierror=true; }
				break;
			  }
			  i.next('.validation').html( ( ierror ? (i.attr('data-msg') != undefined ? i.attr('data-msg') : 'wrong Input') : '' ) ).show('blind');
		    }
		});
		f.children('textarea').each(function(){ // run all inputs

		    var i = $(this); // current input
		    var rule = i.attr('data-rule');

		    if( rule != undefined ){
			var ierror=false; // error flag for current input
			var pos = rule.indexOf( ':', 0 );
			if( pos >= 0 ){
			    var exp = rule.substr( pos+1, rule.length );
			    rule = rule.substr(0, pos);
			}else{
			    rule = rule.substr( pos+1, rule.length );
			}
			
			switch( rule ){
			    case 'required':
				if( i.val()=='' ){ ferror=ierror=true; }
				break;

			    case 'maxlen':
				if( i.val().length<parseInt(exp) ){ ferror=ierror=true; }
				break;
			  }
			  i.next('.validation').html( ( ierror ? (i.attr('data-msg') != undefined ? i.attr('data-msg') : 'wrong Input') : '' ) ).show('blind');
		    }
		});
		if( ferror ) {
			return false;
		}else {
		   var str = $(this).serialize();
		   $.ajax({
			   type: "POST",
			   url: "resources/contact/contact.php",
			   data: str,
			   success: function(msg){
				   if(msg == 'OK')
					{
						$("#successmessage").addClass("show");
						$("#name").val("");
						$("#email").val("");
						$("#subject").val("");
						$("#message").val("");
					}
					else
					{
						$("#successmessage").removeClass("show");
						$("#errormsg").addClass("show");
						$("#name").val("");
						$("#email").val("");
						$("#subject").val("");
						$("#message").val("");
					}
		   }});
		}
		return false;
	});

});