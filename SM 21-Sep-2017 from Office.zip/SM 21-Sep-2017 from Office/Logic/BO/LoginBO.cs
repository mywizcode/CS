﻿using System;
using NHibernate;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using NHibernate.Criterion;

/// <summary>
/// Summary description for SupplierBO
/// </summary>
namespace ConstroSoft
{
    public class LoginBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public LoginBO()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        public BusinessOutputTO validateUser(string userName, string password)
        {
            BusinessOutputTO businessTO = new BusinessOutputTO();
            ISession session = null;
            UserDefinition ud = null;
            log.Debug("Validating user login");
            try
            {
                bool result = false;
                session = NHibertnateSession.OpenSession();
                UserDefinition userDef = session.QueryOver<UserDefinition>().Where(x => x.Username == userName).SingleOrDefault(); ;
                if (userDef != null)
                {
                    if (userDef.Status == UserStatus.InActive)
                    {
                        businessTO.setErrorMessage(Resources.Messages.ERROR_LOGIN_USER_DEACTIVE);
                        result = true;
                    } else if (password.Equals(Decrypt(userDef.Password)))
                    {
                        log.Debug("Login Successful for user:" + userName);
                        UserDefinitionDTO userDTO = getUserDefinitionDTO(userDef, true);
                        businessTO.result = userDTO;
                        result = true;
                    }
                }
                if (!result)
                {
                    log.Debug("Login Failed for user:" + userName);
                    businessTO.setErrorMessage(Resources.Messages.ERROR_LOGIN_FAILED);
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while login:" + userName);
                log.Error(exp.Message, exp);
                businessTO.setErrorMessage(Resources.Messages.system_error);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return businessTO;
        }
        public List<PropertyDTO> getAssignedProperties(long Id)
        {
            ISession session = null;
            List<PropertyDTO> result = new List<PropertyDTO>();
            try
            {
                PropertyDTO pDto = null;
                Property p = null;
                MasterControlData pl = null;

                UserDefinition ud = null;
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => p.Id).WithAlias(() => pDto.Id))
                            .Add(Projections.Property(() => p.Name).WithAlias(() => pDto.Name))
                            .Add(Projections.Property(() => pl.Name), "PropertyLocation.Name");
                        var query = session.QueryOver<UserDefinition>(() => ud)
                                    .Left.JoinAlias(() => ud.AssignedProperties, () => p)
                                    .Inner.JoinAlias(() => p.PropertyLocation, () => pl);
                        IList<PropertyDTO> assignedProperties = query.Where(() => ud.Id == Id)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<PropertyDTO>()).List<PropertyDTO>();
                        result.AddRange(assignedProperties);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching assigned properties to user:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        private UserDefinitionDTO getUserDefinitionDTO(UserDefinition userDef, bool fetchEntitlement)
        {
            UserDefinitionDTO userDefDTO = new UserDefinitionDTO();
            userDefDTO.Id = userDef.Id;
            userDefDTO.Username = userDef.Username;
            userDefDTO.Status = userDef.Status;
            userDefDTO.SecurityQuestion = new SecurityQuestionDTO();
            userDefDTO.SecurityQuestion.Id = userDef.SecurityQuestion.Id;
            userDefDTO.SecurityQuestion.Question = userDef.SecurityQuestion.Question;
            userDefDTO.SecurityAnswer = userDef.SecurityAnswer;
            userDefDTO.UserRole = new UserRoleDTO();
            userDefDTO.UserRole.Name = userDef.UserRole.Name;
            userDefDTO.FirmMember = DomainToDTOUtil.convertToFirmMemberDTO(userDef.FirmMember, true);
            userDefDTO.FirmNumber = userDef.FirmNumber;
            userDefDTO.ProfileImg = userDef.ProfileImg;
            if (fetchEntitlement)
            {
                ISet<UserEntitlement> entitlements = userDef.UserRole.UserEntitlements;
                userDefDTO.UserRole.entitlements = new List<string>();
                foreach (UserEntitlement tmpEntitlement in entitlements)
                {
                    userDefDTO.UserRole.entitlements.Add(tmpEntitlement.Name);
                }
            }

            return userDefDTO;
        }
        private string Encrypt(string clearText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    clearText = Convert.ToBase64String(ms.ToArray());
                }
            }
            return clearText;
        }
        private string Decrypt(string cipherText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }
        public void UpdateFirstLoginInfo(string userName, string password, long secQuestionId, string secAnswer, DateTime dob)
        {
            ISession session = null;
            log.Debug("Updating first login info of user");
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        UserDefinition userDef = session.QueryOver<UserDefinition>().Where(x => x.Username == userName).SingleOrDefault();
                        if (userDef != null)
                        {
                            userDef.Password = Encrypt(password);
                            userDef.SecurityQuestion = new SecurityQuestion();
                            userDef.SecurityQuestion.Id = secQuestionId;
                            userDef.SecurityAnswer = secAnswer;
                            FirmMember firmMember = userDef.FirmMember;
                            firmMember.ContactInfo.Dob = dob;
                            session.Update(firmMember);
                            session.Update(userDef);
                            tx.Commit();
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Updating first login info of user:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while Updating first login info of user:" + userName);
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void resetPassword(string userName, string password)
        {
            ISession session = null;
            log.Debug("Resetting password"+userName);
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        UserDefinition userDef = session.QueryOver<UserDefinition>().Where(x => x.Username == userName).SingleOrDefault();
                        if (userDef != null)
                        {
                            userDef.Password = Encrypt(password);
                            session.Update(userDef);
                            tx.Commit();
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while resetting password:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while resetting password:" + userName);
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public BusinessOutputTO getUserDefinition(string userName)
        {
            UserDefinitionDTO userDefDto = null;
            BusinessOutputTO businessTO = new BusinessOutputTO();
            ISession session = null;
            try
            {
                bool result = false;
                session = NHibertnateSession.OpenSession();
                UserDefinition userDef = session.QueryOver<UserDefinition>().Where(x => x.Username == userName).SingleOrDefault();
                if (userDef != null)
                {
                    userDefDto = getUserDefinitionDTO(userDef, false);
                    if (userDef.Status == UserStatus.InActive)
                    {
                        businessTO.setErrorMessage(Resources.Messages.ERROR_LOGIN_USER_DEACTIVE);
                        result = true;
                    }
                    else if (userDef.Status == UserStatus.Setup)
                    {
                        businessTO.setErrorMessage(Resources.Messages.ERROR_LOGIN_USER_SETUP);
                        result = true;
                    }
                    else if (userDef.Status == UserStatus.Active)
                    {
                        businessTO.result = getUserDefinitionDTO(userDef, false);
                        result = true;
                    }
                }
                if (!result)
                {
                    log.Debug("Login Failed for user:" + userName);
                    businessTO.setErrorMessage("Username does not exist.");
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while fetching user on forgot password:" + userName);
                log.Error(exp.Message, exp);
                businessTO.setErrorMessage(Resources.Messages.system_error);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return businessTO;
        }
    }
}