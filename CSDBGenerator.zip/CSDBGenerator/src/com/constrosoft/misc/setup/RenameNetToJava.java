package com.constrosoft.misc.setup;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

public class RenameNetToJava {
    
    public static void main(String[] argv) throws IOException {

        String sourcePath = "C:\\Sunil\\Other\\WizEye\\ConstroSoft\\Project\\Net_11Nov2016_FromHome";
        String destPath = "C:\\Sunil\\Other\\WizEye\\ConstroSoft\\Project\\java";
        File folder = new File(sourcePath);
        renameAllFiles(folder, sourcePath, destPath);
        System.out.println("conversion is done");
    }
    private static void renameAllFiles(File srcFolder, String srcPath, String destPath) throws IOException {
        File[] listOfFiles = srcFolder.listFiles();
        for (int i = 0; i < listOfFiles.length; i++) {
            File tmpFile = listOfFiles[i];
            if(tmpFile.isDirectory()) {
                renameAllFiles(tmpFile, srcPath, destPath);
            } else if (tmpFile.isFile() && !tmpFile.getName().endsWith(".aspx.designer.cs")) {
                File destFile = new File(getFileName(tmpFile, srcPath, destPath));
                FileUtils.copyFile(tmpFile, destFile);
            }
        }
    }
    private static String getFileName(File tmpFile, String srcPath, String destPath) {
        String name = tmpFile.getAbsolutePath();
        name = name.replace(srcPath, destPath);
        String newName = name;
        if(name.endsWith(".cs")) {
            newName = newName.replace(".cs", ".java");
        } else if(name.endsWith(".aspx")) {
            newName = newName.replace(".aspx", ".html");
        }
        return newName;
    }
}
