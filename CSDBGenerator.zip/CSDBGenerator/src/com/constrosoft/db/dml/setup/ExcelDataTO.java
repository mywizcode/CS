package com.constrosoft.db.dml.setup;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class ExcelDataTO {

    private FirmTO firmTO;
    private LinkedList<EntitlementTO> entitlements;
    private Map<UserRoleTO, List<EntitlementTO>> userRoleEntitlements;
    private List<UserTO> users;
    private List<MasterDataTO> masterDataList;
    private List<ReportConfigTO> reportConfigs;
    private List<SecurityQuestionTO> securityQuestionList;
    private List<EmailConfigTO> emailConfigList;
    private List<SMSConfigTO> smsConfigList;
    private List<EmailAndSMSAlertConfigTO> emailAndSMSAlertConfigList;
    private Map<StateTO, List<CityTO>> stateCityMap;
    /**
     * @return the firmTO
     */
    public FirmTO getFirmTO() {
        return firmTO;
    }
    /**
     * @param firmTO the firmTO to set
     */
    public void setFirmTO(FirmTO firmTO) {
        this.firmTO = firmTO;
    }
    /**
     * @return the entitlements
     */
    public LinkedList<EntitlementTO> getEntitlements() {
        return entitlements;
    }
    /**
     * @param entitlements the entitlements to set
     */
    public void setEntitlements(LinkedList<EntitlementTO> entitlements) {
        this.entitlements = entitlements;
    }
    /**
     * @return the userRoleEntitlements
     */
    public Map<UserRoleTO, List<EntitlementTO>> getUserRoleEntitlements() {
        return userRoleEntitlements;
    }
    /**
     * @param userRoleEntitlements the userRoleEntitlements to set
     */
    public void setUserRoleEntitlements(Map<UserRoleTO, List<EntitlementTO>> userRoleEntitlements) {
        this.userRoleEntitlements = userRoleEntitlements;
    }
    /**
     * @return the users
     */
    public List<UserTO> getUsers() {
        return users;
    }
    /**
     * @param users the users to set
     */
    public void setUsers(List<UserTO> users) {
        this.users = users;
    }
    /**
     * @return the masterDataList
     */
    public List<MasterDataTO> getMasterDataList() {
        return masterDataList;
    }
    /**
     * @param masterDataList the masterDataList to set
     */
    public void setMasterDataList(List<MasterDataTO> masterDataList) {
        this.masterDataList = masterDataList;
    }
    /**
     * @return the reportConfigs
     */
    public List<ReportConfigTO> getReportConfigs() {
        return reportConfigs;
    }
    /**
     * @param reportConfigs the reportConfigs to set
     */
    public void setReportConfigs(List<ReportConfigTO> reportConfigs) {
        this.reportConfigs = reportConfigs;
    }
    /**
     * @return the securityQuestionList
     */
    public List<SecurityQuestionTO> getSecurityQuestionList() {
        return securityQuestionList;
    }
    /**
     * @param securityQuestionList the securityQuestionList to set
     */
    public void setSecurityQuestionList(List<SecurityQuestionTO> securityQuestionList) {
        this.securityQuestionList = securityQuestionList;
    }
	/**
	 * @return the emailConfigList
	 */
	public List<EmailConfigTO> getEmailConfigList() {
		return emailConfigList;
	}
	/**
	 * @param emailConfigList the emailConfigList to set
	 */
	public void setEmailConfigList(List<EmailConfigTO> emailConfigList) {
		this.emailConfigList = emailConfigList;
	}
	/**
	 * @return the smsConfigList
	 */
	public List<SMSConfigTO> getSmsConfigList() {
		return smsConfigList;
	}
	/**
	 * @param smsConfigList the smsConfigList to set
	 */
	public void setSmsConfigList(List<SMSConfigTO> smsConfigList) {
		this.smsConfigList = smsConfigList;
	}
	/**
	 * @return the emailAndSMSAlertConfigList
	 */
	public List<EmailAndSMSAlertConfigTO> getEmailAndSMSAlertConfigList() {
		return emailAndSMSAlertConfigList;
	}
	/**
	 * @param emailAndSMSAlertConfigList the emailAndSMSAlertConfigList to set
	 */
	public void setEmailAndSMSAlertConfigList(List<EmailAndSMSAlertConfigTO> emailAndSMSAlertConfigList) {
		this.emailAndSMSAlertConfigList = emailAndSMSAlertConfigList;
	}
	/**
	 * @return the stateCityMap
	 */
	public Map<StateTO, List<CityTO>> getStateCityMap() {
		return stateCityMap;
	}
	/**
	 * @param stateCityMap the stateCityMap to set
	 */
	public void setStateCityMap(Map<StateTO, List<CityTO>> stateCityMap) {
		this.stateCityMap = stateCityMap;
	}
}
