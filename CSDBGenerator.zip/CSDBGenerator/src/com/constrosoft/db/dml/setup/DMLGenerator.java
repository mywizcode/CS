package com.constrosoft.db.dml.setup;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class DMLGenerator {

	static String SECURITY_QUESTION_QUERY = "INSERT INTO SECURITY_QUESTION(QUESTION) VALUES ('{QUESTION}');";
	static String USER_ROLE_QUERY = "INSERT INTO USER_ROLES(NAME,DESCRIPTION,FIRM_NUMBER) VALUES ('{NAME}','{DESCRIPTION}','{FIRM_NUMBER}');";
	static String ENTITLEMENT_QUERY = "INSERT INTO USER_ENTITLEMENT(NAME,LEVEL,PARENT_ID,DESCRIPTION) VALUES ('{NAME}',{LEVEL},{PARENT_ID},'{DESCRIPTION}');";
	static String ENTITLEMENT_WITH_PARENT_QUERY = "INSERT INTO USER_ENTITLEMENT(NAME,LEVEL,PARENT_ID,DESCRIPTION) SELECT '{NAME}',{LEVEL},ID,'{DESCRIPTION}' FROM USER_ENTITLEMENT WHERE NAME = '{PARENT_ENTITLEMENT}';";
	static String USER_ROLE_ENTITLEMENT_QUERY = "INSERT INTO USER_ROLE_ENTITLEMENT(USER_ROLE_ID,ENTITLEMENT_ID) SELECT ID, (SELECT ID FROM USER_ENTITLEMENT WHERE NAME = '{ENTITLEMENT}') FROM USER_ROLES WHERE NAME = '{USER_ROLE}';";
	static String MCD_QUERY = "INSERT INTO MASTER_CONTROL_DATA(TYPE,NAME,DESCRIPTION,SYSTEM_DEFINED,FIRM_NUMBER,INSERT_USER,UPDATE_USER) VALUES ('{TYPE}','{NAME}','{DESCRIPTION}','{SYSTEM_DEFINED}','{FIRM_NUMBER}','CSADMIN','CSADMIN');";
	static String REPORT_CONFIG_QUERY = "INSERT INTO REPORT_CONFIG (FIRM_NUMBER, REPORT_NAME, REPORT_PATH, REPORT_DESCRIPTION, INSERT_DATE, UPDATE_DATE, VERSION, INSERT_USER, UPDATE_USER) VALUES ('{FIRM_NUMBER}', '{REPORT_NAME}', '{REPORT_PATH}', '{REPORT_DESCRIPTION}', GETDATE(),GETDATE(),0,'CSADMIN','CSADMIN');";
	static String CONTACT_QUERY = "INSERT INTO CONTACT_INFO(CONTACT,EMAIL) VALUES ('{CONTACT}', '{EMAIL}');";
	static String PDC_IN_BOOK_QUERY = "INSERT INTO PDC_BOOK(DESCRIPTION) VALUES ('FIRM {FIRM_NUMBER} PDC IN BOOK');";
	static String PDC_OUT_BOOK_QUERY = "INSERT INTO PDC_BOOK(DESCRIPTION) VALUES ('FIRM {FIRM_NUMBER} PDC OUT BOOK');";
	static String FIRM_QUERY = "INSERT INTO FIRM(NAME,FIRM_NUMBER,CONTACT_INFO_ID,REGISTRATION_NO,WEB_SITE,DESCRIPTION,PDC_IN_BOOK,PDC_OUT_BOOK,INSERT_USER,UPDATE_USER)"
			+ " SELECT '{NAME}','{FIRM_NUMBER}',ID,'{REGISTRATION_NO}','{WEB_SITE}','{DESCRIPTION}',(SELECT ID FROM PDC_BOOK WHERE DESCRIPTION = 'FIRM {FIRM_NUMBER} PDC IN BOOK'),"
			+ " (SELECT ID FROM PDC_BOOK WHERE DESCRIPTION = 'FIRM {FIRM_NUMBER} PDC OUT BOOK'),'CSADMIN','CSADMIN' FROM CONTACT_INFO WHERE"
			+ " CONTACT = '{CONTACT}' AND EMAIL = '{EMAIL}';";
	static String FIRM_MEMBER_QUERY = "INSERT INTO FIRM_MEMBER(EMPLOYEE_ID,SALUTATION_ID,FIRST_NAME,MIDDLE_NAME,LAST_NAME,CONTACT_INFO_ID,JOINING_DATE,QUALIFICATION,DESCRIPTION,FIRM_NUMBER,VERSION,INSERT_USER,UPDATE_USER)"
			+ " SELECT '{EMPLOYEE_ID}', ID , '{FIRST_NAME}', '{MIDDLE_NAME}', '{LAST_NAME}', (SELECT ID FROM CONTACT_INFO WHERE CONTACT = '{CONTACT}' AND EMAIL = '{EMAIL}'),null,null,null,'{FIRM_NUMBER}',0,'CSADMIN','CSADMIN'"
			+ " FROM MASTER_CONTROL_DATA WHERE TYPE = 'SALUTATION' AND NAME = '{SALUTATION}';";
	static String USER_QUERY = "INSERT INTO USER_DEFINITION(USERNAME,PASSWORD,ROLE_ID,SECURITY_QUESTION,SECURITY_ANSWER,ACTIVATION_DATE,EXPIRATION_DATE,STATUS,FIRM_MEMBER_ID,FIRM_NUMBER,VERSION,INSERT_USER,UPDATE_USER)"
			+ " SELECT '{USERNAME}','pIbvhgmpVHahDBTYUgQvew==',ID, 1,'',GETDATE(),GETDATE(),'A',(SELECT ID FROM FIRM_MEMBER WHERE EMPLOYEE_ID = '{EMPLOYEE_ID}'),"
			+ " '{FIRM_NUMBER}',0,'CSADMIN','CSADMIN' FROM USER_ROLES WHERE NAME = '{USER_ROLE}';";
	static String EMAIL_CONFIG_QUERY = "INSERT INTO EMAIL_CONFIG (FIRM_NUMBER, SMTP_HOST, SMTP_PORT, EMAIL, PASSWORD, ENABLE_SSL, INSERT_DATE, UPDATE_DATE, VERSION, INSERT_USER, UPDATE_USER) "
			+ " VALUES ('{FIRM_NUMBER}', '{SMTP_HOST}', '{SMTP_PORT}', '{EMAIL}', '{PASSWORD}', '{ENABLE_SSL}', GETDATE(),GETDATE(),0,'CSADMIN','CSADMIN');";
	static String SMS_CONFIG_QUERY = "INSERT INTO SMS_CONFIG (FIRM_NUMBER, URL, USERID, PASSWORD, SENDERID, INSERT_DATE, UPDATE_DATE, VERSION, INSERT_USER, UPDATE_USER) "
			+ " VALUES('{FIRM_NUMBER}', '{URL}', '{USERID}', '{PASSWORD}', '{SENDERID}', GETDATE(),GETDATE(),0,'CSADMIN','CSADMIN');";
	static String EMAIL_SMS_ALERT_CONFIG_QUERY = "INSERT INTO EMAIL_SMS_ALERT_CONFIG(FIRM_NUMBER, FUNCTION_NAME, EMAIL_SMS_TYPE, EMAIL, SMS, SUBJECT, SMS_CONTENT,  EMAIL_TEMPLATE_PATH, INSERT_DATE, UPDATE_DATE "
			+ ",VERSION, INSERT_USER, UPDATE_USER) VALUES ('{FIRM_NUMBER}', '{FUNCTION_NAME}', '{EMAIL_SMS_TYPE}', '{EMAIL}', '{SMS}', '{SUBJECT}', '{SMS_CONTENT}', '{EMAIL_TEMPLATE_PATH}', GETDATE(),GETDATE(),0,'CSADMIN','CSADMIN');";
	static String COUNTRY_QUERY = "INSERT INTO COUNTRY (NAME,ABBREVIATION) VALUES ('India', 'IND');";
	static String STATE_QUERY = "INSERT INTO STATE (NAME,ABBREVIATION,COUNTRY_ID) SELECT '{NAME}','{ABBREVIATION}',ID FROM COUNTRY WHERE NAME = 'India';";
	static String CITY_QUERY = "INSERT INTO CITY (NAME,ABBREVIATION,STATE_ID) SELECT '{NAME}','',ID FROM STATE WHERE NAME = '{STATE_NAME}';";

	public void generateCommonDML(ExcelDataTO excelDataTO, String filePath) {
		StringBuilder sb = new StringBuilder();
		createCountryStateAndCityDML(excelDataTO, sb);
		sb.append("\n");
		createSecurityQuestionDML(excelDataTO, sb);
		sb.append("\n");
		createEntitlementDML(excelDataTO, sb);
		writeToFile(sb, filePath);
		System.out.println("Common DML file created:" + filePath);
	}

	private String replaceAll(String dml, String exp, String value) {
		if (dml.indexOf(exp) == -1) {
			return dml;
		}
		return replaceAll(dml.replace(exp, value), exp, value);
	}

	private void createEntitlementDML(ExcelDataTO excelDataTO, StringBuilder sb) {
		sb.append("------------------------------------------------------------------------------------------------------------------------------");
		sb.append("\n-------------------------------------------------------USER_ENTITLEMENT-------------------------------------------------------");
		sb.append("\n------------------------------------------------------------------------------------------------------------------------------");
		for (EntitlementTO entitlement : excelDataTO.getEntitlements()) {
			String dml = "";
			if (entitlement.getLevel() == 0) {
				sb.append("\n-------------------------------------" + entitlement.getDescription()
						+ "-------------------------------------------------------");
				dml = replaceAll(ENTITLEMENT_QUERY, "{NAME}", entitlement.getName());
				dml = replaceAll(dml, "{LEVEL}", entitlement.getLevel() + "");
				dml = replaceAll(dml, "{PARENT_ID}", "NULL");
				dml = replaceAll(dml, "{DESCRIPTION}", entitlement.getDescription());
			} else {
				dml = replaceAll(ENTITLEMENT_WITH_PARENT_QUERY, "{NAME}", entitlement.getName());
				dml = replaceAll(dml, "{LEVEL}", entitlement.getLevel() + "");
				dml = replaceAll(dml, "{DESCRIPTION}", entitlement.getDescription());
				dml = replaceAll(dml, "{PARENT_ENTITLEMENT}", entitlement.getParent().getName());
			}
			sb.append("\n");
			sb.append(dml);
		}
	}

	private void createSecurityQuestionDML(ExcelDataTO excelDataTO, StringBuilder sb) {
		sb.append("------------------------------------------------------------------------------------------------------------------------------");
		sb.append("\n-------------------------------------------------------SECURITY_QUESTION------------------------------------------------------");
		sb.append("\n------------------------------------------------------------------------------------------------------------------------------");
		List<SecurityQuestionTO> securityQuestionList = excelDataTO.getSecurityQuestionList();
		for (SecurityQuestionTO securityQuestionTO : securityQuestionList) {
			String dml = replaceAll(SECURITY_QUESTION_QUERY, "{QUESTION}", securityQuestionTO.getQuestion());
			sb.append("\n");
			sb.append(dml);
		}
	}

	private void createCountryStateAndCityDML(ExcelDataTO excelDataTO, StringBuilder sb) {
		sb.append("------------------------------------------------------------------------------------------------------------------------------");
		sb.append("\n-------------------------------------------------------COUNTRY------------------------------------------------------");
		sb.append("\n------------------------------------------------------------------------------------------------------------------------------");
		sb.append("\n");
		sb.append(COUNTRY_QUERY);
		Iterator<Map.Entry<StateTO, List<CityTO>>> stateCityIterator = excelDataTO.getStateCityMap().entrySet().iterator();
		while (stateCityIterator.hasNext()) {
			Map.Entry<StateTO, List<CityTO>> entry = stateCityIterator.next();
			StateTO stateTO = entry.getKey();
			List<CityTO> CityList = entry.getValue();
			sb.append("\n------------------------------------------------------------------------------------------------------------------------------");
			sb.append("\n------------------------------------------STATE and CITY : " + stateTO.getName() + "-----------------------------------------");
			sb.append("\n------------------------------------------------------------------------------------------------------------------------------");
			String stateDml = replaceAll(STATE_QUERY, "{NAME}", stateTO.getName());
			stateDml = replaceAll(stateDml, "{ABBREVIATION}", stateTO.getAbbreviation());
			sb.append("\n");
			sb.append(stateDml);
			for (CityTO city : CityList) {
				String cityDml = replaceAll(CITY_QUERY, "{NAME}", city.getName());
				cityDml = replaceAll(cityDml, "{STATE_NAME}", stateTO.getName());
				sb.append("\n");
				sb.append(cityDml);
			}
		}
	}

	public void generateCustomerDML(ExcelDataTO excelDataTO, String filePath) {
		StringBuilder sb = new StringBuilder();
		createUserRoleDML(excelDataTO, sb);
		sb.append("\n");
		createUserRoleEntitlementDML(excelDataTO, sb);
		sb.append("\n");
		createMasterDataDML(excelDataTO, sb);
		sb.append("\n");
		createFirmDML(excelDataTO, sb);
		sb.append("\n");
		createReprtConfigDML(excelDataTO, sb);
		sb.append("\n");
		createUserAndFirmMemberDML(excelDataTO, sb);
		sb.append("\n");
		createEmailConfigDML(excelDataTO, sb);
		sb.append("\n");
		createSMSConfigDML(excelDataTO, sb);
		sb.append("\n");
		createEmailAndSMSAlertConfigDML(excelDataTO, sb);

		writeToFile(sb, filePath);
		System.out.println("Customer DML file created:" + filePath);
	}

	private void createUserRoleDML(ExcelDataTO excelDataTO, StringBuilder sb) {
		sb.append("------------------------------------------------------------------------------------------------------------------------------");
		sb.append("\n-------------------------------------------------------USER_ROLE--------------------------------------------------------------");
		sb.append("\n------------------------------------------------------------------------------------------------------------------------------");
		Iterator<UserRoleTO> userRoles = excelDataTO.getUserRoleEntitlements().keySet().iterator();
		while (userRoles.hasNext()) {
			UserRoleTO userRole = userRoles.next();
			String dml = replaceAll(USER_ROLE_QUERY, "{NAME}", userRole.getName());
			dml = replaceAll(dml, "{DESCRIPTION}", userRole.getDescription());
			dml = replaceAll(dml, "{FIRM_NUMBER}", excelDataTO.getFirmTO().getFirmNumber());
			sb.append("\n");
			sb.append(dml);
		}
	}

	private void createUserRoleEntitlementDML(ExcelDataTO excelDataTO, StringBuilder sb) {
		sb.append("------------------------------------------------------------------------------------------------------------------------------");
		sb.append("\n-------------------------------------------------------USER_ROLE_ENTITLEMENT--------------------------------------------------");
		sb.append("\n------------------------------------------------------------------------------------------------------------------------------");
		Iterator<UserRoleTO> userRoles = excelDataTO.getUserRoleEntitlements().keySet().iterator();
		while (userRoles.hasNext()) {
			UserRoleTO userRole = userRoles.next();
			sb.append("\n-------------------------------------------------------" + userRole.getName()
					+ "--------------------------------------------------");
			List<EntitlementTO> entitlements = excelDataTO.getUserRoleEntitlements().get(userRole);
			for (EntitlementTO entitlement : entitlements) {
				String dml = replaceAll(USER_ROLE_ENTITLEMENT_QUERY, "{ENTITLEMENT}", entitlement.getName());
				dml = replaceAll(dml, "{USER_ROLE}", userRole.getName());
				sb.append("\n");
				sb.append(dml);
			}
		}
	}

	private void createMasterDataDML(ExcelDataTO excelDataTO, StringBuilder sb) {
		sb.append("------------------------------------------------------------------------------------------------------------------------------");
		sb.append("\n-------------------------------------------------------MASTER_CONTROL_DATA----------------------------------------------------");
		sb.append("\n------------------------------------------------------------------------------------------------------------------------------");
		List<MasterDataTO> masterDataList = excelDataTO.getMasterDataList();
		for (MasterDataTO masterDataTO : masterDataList) {
			String dml = replaceAll(MCD_QUERY, "{TYPE}", masterDataTO.getType());
			dml = replaceAll(dml, "{NAME}", masterDataTO.getName());
			dml = replaceAll(dml, "{DESCRIPTION}", masterDataTO.getDescription());
			dml = replaceAll(dml, "{SYSTEM_DEFINED}", masterDataTO.getSystemDefined());
			dml = replaceAll(dml, "{FIRM_NUMBER}", excelDataTO.getFirmTO().getFirmNumber());
			sb.append("\n");
			sb.append(dml);
		}
	}

	private void createFirmDML(ExcelDataTO excelDataTO, StringBuilder sb) {
		sb.append("------------------------------------------------------------------------------------------------------------------------------");
		sb.append("\n-------------------------------------------------------FIRM------------------------------------------------------------------");
		sb.append("\n------------------------------------------------------------------------------------------------------------------------------");
		FirmTO firmTO = excelDataTO.getFirmTO();
		sb.append("\n");
		sb.append(getContactDML(firmTO.getContact(), firmTO.getEmail()));
		sb.append("\n");
		sb.append(getPdcInDML(firmTO.getFirmNumber()));
		sb.append("\n");
		sb.append(getPdcOutDML(firmTO.getFirmNumber()));
		sb.append("\n");
		sb.append(getFirmDML(firmTO));
	}

	private void createReprtConfigDML(ExcelDataTO excelDataTO, StringBuilder sb) {
		sb.append("------------------------------------------------------------------------------------------------------------------------------");
		sb.append("\n-------------------------------------------------------REPORT_CONFIG----------------------------------------------------------");
		sb.append("\n------------------------------------------------------------------------------------------------------------------------------");
		List<ReportConfigTO> reportConfigList = excelDataTO.getReportConfigs();
		for (ReportConfigTO reportConfigTO : reportConfigList) {
			String dml = replaceAll(REPORT_CONFIG_QUERY, "{FIRM_NUMBER}", excelDataTO.getFirmTO().getFirmNumber());
			dml = replaceAll(dml, "{REPORT_NAME}", reportConfigTO.getReportName());
			dml = replaceAll(dml, "{REPORT_PATH}", reportConfigTO.getReportPath());
			dml = replaceAll(dml, "{REPORT_DESCRIPTION}", reportConfigTO.getDescription());
			sb.append("\n");
			sb.append(dml);
		}
	}

	private void createUserAndFirmMemberDML(ExcelDataTO excelDataTO, StringBuilder sb) {
		sb.append("------------------------------------------------------------------------------------------------------------------------------");
		sb.append("\n--------------------------------------------USER_DEFINITION AND FIRM_MEMBER---------------------------------------------------");
		sb.append("\n------------------------------------------------------------------------------------------------------------------------------");
		List<UserTO> userList = excelDataTO.getUsers();
		for (UserTO userTO : userList) {
			sb.append("\n-----------------------------------------------------" + userTO.getUserName()
					+ "------------------------------------------------");
			sb.append("\n");
			sb.append(getContactDML(userTO.getContact(), userTO.getEmail()));
			sb.append("\n");
			sb.append(getFirmMemberDML(userTO, excelDataTO.getFirmTO().getFirmNumber()));
			sb.append("\n");
			sb.append(getUserDefinitionDML(userTO, excelDataTO.getFirmTO().getFirmNumber()));
		}
	}

	private void createEmailConfigDML(ExcelDataTO excelDataTO, StringBuilder sb) {
		sb.append("------------------------------------------------------------------------------------------------------------------------------");
		sb.append("\n-------------------------------------------------------EMAIL_CONFIG----------------------------------------------------");
		sb.append("\n------------------------------------------------------------------------------------------------------------------------------");
		List<EmailConfigTO> emailConfigList = excelDataTO.getEmailConfigList();
		for (EmailConfigTO emailConfigTO : emailConfigList) {
			String dml = replaceAll(EMAIL_CONFIG_QUERY, "{FIRM_NUMBER}", excelDataTO.getFirmTO().getFirmNumber());
			dml = replaceAll(dml, "{SMTP_HOST}", emailConfigTO.getSmtpHost());
			dml = replaceAll(dml, "{SMTP_PORT}", emailConfigTO.getSmtpPort());
			dml = replaceAll(dml, "{EMAIL}", emailConfigTO.getEmail());
			dml = replaceAll(dml, "{PASSWORD}", emailConfigTO.getPassword());
			dml = replaceAll(dml, "{ENABLE_SSL}", emailConfigTO.getEnableSSL());
			sb.append("\n");
			sb.append(dml);
		}
	}

	private void createSMSConfigDML(ExcelDataTO excelDataTO, StringBuilder sb) {
		sb.append("------------------------------------------------------------------------------------------------------------------------------");
		sb.append("\n-------------------------------------------------------SMS_CONFIG----------------------------------------------------");
		sb.append("\n------------------------------------------------------------------------------------------------------------------------------");
		List<SMSConfigTO> smsConfigList = excelDataTO.getSmsConfigList();
		for (SMSConfigTO smsConfigTO : smsConfigList) {
			String dml = replaceAll(SMS_CONFIG_QUERY, "{FIRM_NUMBER}", excelDataTO.getFirmTO().getFirmNumber());
			dml = replaceAll(dml, "{URL}", smsConfigTO.getUrl());
			dml = replaceAll(dml, "{USERID}", smsConfigTO.getUserId());
			dml = replaceAll(dml, "{PASSWORD}", smsConfigTO.getPassword());
			dml = replaceAll(dml, "{SENDERID}", smsConfigTO.getSenderId());
			sb.append("\n");
			sb.append(dml);
		}
	}

	private void createEmailAndSMSAlertConfigDML(ExcelDataTO excelDataTO, StringBuilder sb) {
		sb.append("------------------------------------------------------------------------------------------------------------------------------");
		sb.append("\n-------------------------------------------------------EMAIL_SMS_ALERT_CONFIG----------------------------------------------------");
		sb.append("\n------------------------------------------------------------------------------------------------------------------------------");
		List<EmailAndSMSAlertConfigTO> emailAndSMSConfigList = excelDataTO.getEmailAndSMSAlertConfigList();
		for (EmailAndSMSAlertConfigTO configTO : emailAndSMSConfigList) {
			String dml = replaceAll(EMAIL_SMS_ALERT_CONFIG_QUERY, "{FIRM_NUMBER}", excelDataTO.getFirmTO().getFirmNumber());
			dml = replaceAll(dml, "{FUNCTION_NAME}", configTO.getFunctionName());
			dml = replaceAll(dml, "{EMAIL_SMS_TYPE}", configTO.getEmailSMSType());
			dml = replaceAll(dml, "{EMAIL}", configTO.getEmail());
			dml = replaceAll(dml, "{SMS}", configTO.getSms());
			dml = replaceAll(dml, "{SUBJECT}", configTO.getSubject());
			dml = replaceAll(dml, "{SMS_CONTENT}", configTO.getSmsContent());
			dml = replaceAll(dml, "{EMAIL_TEMPLATE_PATH}", configTO.getEmailTemplatePath());
			sb.append("\n");
			sb.append(dml);
		}
	}

	private String getContactDML(String contact, String email) {
		String dml = replaceAll(CONTACT_QUERY, "{CONTACT}", contact);
		dml = replaceAll(dml, "{EMAIL}", email);
		return dml;
	}

	private String getPdcInDML(String firmNumber) {
		return replaceAll(PDC_IN_BOOK_QUERY, "{FIRM_NUMBER}", firmNumber);
	}

	private String getPdcOutDML(String firmNumber) {
		return replaceAll(PDC_OUT_BOOK_QUERY, "{FIRM_NUMBER}", firmNumber);
	}

	private String getFirmMemberDML(UserTO userTO, String firmNumber) {
		String dml = replaceAll(FIRM_MEMBER_QUERY, "{EMPLOYEE_ID}", userTO.getEmployeeId());
		dml = replaceAll(dml, "{FIRST_NAME}", userTO.getFirstName());
		dml = replaceAll(dml, "{MIDDLE_NAME}", userTO.getMiddleName());
		dml = replaceAll(dml, "{LAST_NAME}", userTO.getLastName());
		dml = replaceAll(dml, "{CONTACT}", userTO.getContact());
		dml = replaceAll(dml, "{EMAIL}", userTO.getEmail());
		dml = replaceAll(dml, "{FIRM_NUMBER}", firmNumber);
		dml = replaceAll(dml, "{SALUTATION}", userTO.getSalutation());
		return dml;
	}

	private String getUserDefinitionDML(UserTO userTO, String firmNumber) {
		String dml = replaceAll(USER_QUERY, "{USERNAME}", userTO.getUserName());
		dml = replaceAll(dml, "{EMPLOYEE_ID}", userTO.getEmployeeId());
		dml = replaceAll(dml, "{FIRM_NUMBER}", firmNumber);
		dml = replaceAll(dml, "{USER_ROLE}", userTO.getRole());
		return dml;
	}

	private String getFirmDML(FirmTO firmTO) {
		String dml = replaceAll(FIRM_QUERY, "{NAME}", firmTO.getName());
		dml = replaceAll(dml, "{FIRM_NUMBER}", firmTO.getFirmNumber());
		dml = replaceAll(dml, "{REGISTRATION_NO}", firmTO.getRegistrationNo());
		dml = replaceAll(dml, "{WEB_SITE}", firmTO.getWebsite());
		dml = replaceAll(dml, "{DESCRIPTION}", firmTO.getDescription());
		dml = replaceAll(dml, "{CONTACT}", firmTO.getContact());
		dml = replaceAll(dml, "{EMAIL}", firmTO.getEmail());
		return dml;
	}

	private void writeToFile(StringBuilder dml, String filePath) {
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
			bw.write(dml.toString());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
