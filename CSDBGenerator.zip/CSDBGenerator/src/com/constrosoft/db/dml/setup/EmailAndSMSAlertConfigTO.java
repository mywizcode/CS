package com.constrosoft.db.dml.setup;

import org.apache.poi.ss.usermodel.Row;

public class EmailAndSMSAlertConfigTO {

    public EmailAndSMSAlertConfigTO() {
    }
    public EmailAndSMSAlertConfigTO(Row row) {
        this.functionName = CommonUtil.getStringValue(row.getCell(0));
        this.emailSMSType = CommonUtil.getStringValue(row.getCell(1));
        this.email = CommonUtil.getStringValue(row.getCell(2));
        this.sms = CommonUtil.getStringValue(row.getCell(3));
        this.subject = CommonUtil.getStringValue(row.getCell(4));
        this.smsContent = CommonUtil.getStringValue(row.getCell(5));
        this.emailTemplatePath = CommonUtil.getStringValue(row.getCell(6));
    }
    private String functionName;
    private String emailSMSType;
    private String email;
    private String sms;
    private String subject;
    private String smsContent;
    private String emailTemplatePath;
	/**
	 * @return the functionName
	 */
	public String getFunctionName() {
		return functionName;
	}
	/**
	 * @param functionName the functionName to set
	 */
	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}
	/**
	 * @return the emailSMSType
	 */
	public String getEmailSMSType() {
		return emailSMSType;
	}
	/**
	 * @param emailSMSType the emailSMSType to set
	 */
	public void setEmailSMSType(String emailSMSType) {
		this.emailSMSType = emailSMSType;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the sms
	 */
	public String getSms() {
		return sms;
	}
	/**
	 * @param sms the sms to set
	 */
	public void setSms(String sms) {
		this.sms = sms;
	}
	/**
	 * @return the subject
	 */
	public String getSubject() {
		return subject;
	}
	/**
	 * @param subject the subject to set
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}
	/**
	 * @return the smsContent
	 */
	public String getSmsContent() {
		return smsContent;
	}
	/**
	 * @param smsContent the smsContent to set
	 */
	public void setSmsContent(String smsContent) {
		this.smsContent = smsContent;
	}
	/**
	 * @return the emailTemplatePath
	 */
	public String getEmailTemplatePath() {
		return emailTemplatePath;
	}
	/**
	 * @param emailTemplatePath the emailTemplatePath to set
	 */
	public void setEmailTemplatePath(String emailTemplatePath) {
		this.emailTemplatePath = emailTemplatePath;
	}
}
