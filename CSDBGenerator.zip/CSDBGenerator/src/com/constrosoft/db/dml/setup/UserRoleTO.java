package com.constrosoft.db.dml.setup;

import org.apache.poi.ss.usermodel.Row;

public class UserRoleTO {

    public UserRoleTO() {
        // TODO Auto-generated constructor stub
    }
    public UserRoleTO(Row row) {
        this.name = CommonUtil.getStringValue(row.getCell(0));
        this.description = CommonUtil.getStringValue(row.getCell(1));
        this.columnIndex = Integer.parseInt(CommonUtil.getStringValue(row.getCell(2)));
    }
    private String name;
    private String description;
    private int columnIndex;
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }
    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }
    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }
    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }
    /**
     * @return the columnIndex
     */
    public int getColumnIndex() {
        return columnIndex;
    }
    /**
     * @param columnIndex the columnIndex to set
     */
    public void setColumnIndex(int columnIndex) {
        this.columnIndex = columnIndex;
    }
    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + columnIndex;
        return result;
    }
    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        UserRoleTO other = (UserRoleTO) obj;
        if (columnIndex != other.columnIndex)
            return false;
        return true;
    }
}
