package com.constrosoft.db.dml.setup;

import org.apache.poi.ss.usermodel.Row;

public class MasterDataTO {

    public MasterDataTO() {
    }
    public MasterDataTO(Row row) {
        this.type = CommonUtil.getStringValue(row.getCell(0));
        this.name = CommonUtil.getStringValue(row.getCell(1));
        this.systemDefined = CommonUtil.getStringValue(row.getCell(2));
        this.description = CommonUtil.getStringValue(row.getCell(3));
    }
    private String type;
    private String name;
    private String systemDefined;
    private String description;
    /**
     * @return the type
     */
    public String getType() {
        return type;
    }
    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }
    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }
    /**
     * @return the systemDefined
     */
    public String getSystemDefined() {
        return systemDefined;
    }
    /**
     * @param systemDefined the systemDefined to set
     */
    public void setSystemDefined(String systemDefined) {
        this.systemDefined = systemDefined;
    }
    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }
    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }
}
