package com.constrosoft.db.dml.setup;

import org.apache.poi.ss.usermodel.Row;

public class ReportConfigTO {

    public ReportConfigTO() {
    }
    public ReportConfigTO(Row row) {
        this.reportName = CommonUtil.getStringValue(row.getCell(0));
        this.description = CommonUtil.getStringValue(row.getCell(1));
        this.reportPath = CommonUtil.getStringValue(row.getCell(2));
        this.codeSelector = CommonUtil.getStringValue(row.getCell(3));
    }
    private String reportName;
    private String description;
    private String reportPath;
    private String codeSelector;
    /**
     * @return the reportName
     */
    public String getReportName() {
        return reportName;
    }
    /**
     * @param reportName the reportName to set
     */
    public void setReportName(String reportName) {
        this.reportName = reportName;
    }
    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }
    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }
    /**
     * @return the reportPath
     */
    public String getReportPath() {
        return reportPath;
    }
    /**
     * @param reportPath the reportPath to set
     */
    public void setReportPath(String reportPath) {
        this.reportPath = reportPath;
    }
    /**
     * @return the codeSelector
     */
    public String getCodeSelector() {
        return codeSelector;
    }
    /**
     * @param codeSelector the codeSelector to set
     */
    public void setCodeSelector(String codeSelector) {
        this.codeSelector = codeSelector;
    }
}
