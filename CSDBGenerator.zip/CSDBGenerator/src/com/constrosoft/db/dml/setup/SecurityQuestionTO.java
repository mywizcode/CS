package com.constrosoft.db.dml.setup;

import org.apache.poi.ss.usermodel.Row;

public class SecurityQuestionTO {

    public SecurityQuestionTO() {
    }
    public SecurityQuestionTO(Row row) {
        this.question = CommonUtil.getStringValue(row.getCell(0));
    }
    private String question;
    /**
     * @return the question
     */
    public String getQuestion() {
        return question;
    }
    /**
     * @param question the question to set
     */
    public void setQuestion(String question) {
        this.question = question;
    }
}
