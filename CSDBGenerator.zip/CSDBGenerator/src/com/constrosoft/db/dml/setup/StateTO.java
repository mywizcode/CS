package com.constrosoft.db.dml.setup;

import org.apache.poi.ss.usermodel.Row;

public class StateTO {

    public StateTO() {
        // TODO Auto-generated constructor stub
    }
    public StateTO(Row row) {
    	this.id = Integer.parseInt(CommonUtil.getStringValue(row.getCell(0)));
        this.name = CommonUtil.getStringValue(row.getCell(1));
        this.abbreviation = CommonUtil.getStringValue(row.getCell(2));
    }
    private int id;
    private String name;
    private String abbreviation;
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the abbreviation
	 */
	public String getAbbreviation() {
		return abbreviation;
	}
	/**
	 * @param abbreviation the abbreviation to set
	 */
	public void setAbbreviation(String abbreviation) {
		this.abbreviation = abbreviation;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StateTO other = (StateTO) obj;
		if (id != other.id)
			return false;
		return true;
	}
}
