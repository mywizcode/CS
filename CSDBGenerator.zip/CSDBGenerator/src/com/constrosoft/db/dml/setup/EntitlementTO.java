package com.constrosoft.db.dml.setup;

import org.apache.poi.ss.usermodel.Row;

public class EntitlementTO {

    public EntitlementTO() {
        // TODO Auto-generated constructor stub
    }
    public EntitlementTO(Row row) {
        this.level = Integer.parseInt(CommonUtil.getStringValue(row.getCell(0)));
        this.name = CommonUtil.getStringValue(row.getCell(1));
        this.description = CommonUtil.getStringValue(row.getCell(2));        
    }
    private int level;
    private String name;
    private String description;
    private EntitlementTO parent;
    /**
     * @return the level
     */
    public int getLevel() {
        return level;
    }
    /**
     * @param level the level to set
     */
    public void setLevel(int level) {
        this.level = level;
    }
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }
    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }
    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }
    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }
    /**
     * @return the parent
     */
    public EntitlementTO getParent() {
        return parent;
    }
    /**
     * @param parent the parent to set
     */
    public void setParent(EntitlementTO parent) {
        this.parent = parent;
    }
    
}
