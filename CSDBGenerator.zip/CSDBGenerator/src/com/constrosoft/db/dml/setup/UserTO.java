package com.constrosoft.db.dml.setup;

import org.apache.poi.ss.usermodel.Row;

public class UserTO {

    public UserTO() {
        // TODO Auto-generated constructor stub
    }
    public UserTO(Row row) {
        this.salutation = CommonUtil.getStringValue(row.getCell(0));
        this.firstName = CommonUtil.getStringValue(row.getCell(1));
        this.middleName = CommonUtil.getStringValue(row.getCell(2));
        this.lastName = CommonUtil.getStringValue(row.getCell(3));
        this.employeeId = CommonUtil.getStringValue(row.getCell(4));
        this.contact = CommonUtil.getStringValue(row.getCell(5));
        this.email = CommonUtil.getStringValue(row.getCell(6));
        this.userName = CommonUtil.getStringValue(row.getCell(7));
        this.role = CommonUtil.getStringValue(row.getCell(8));
    }
    private String salutation;
    private String firstName;
    private String middleName;
    private String lastName;
    private String employeeId;
    private String contact;
    private String email;
    private String userName;
    private String role;
    /**
     * @return the salutation
     */
    public String getSalutation() {
        return salutation;
    }
    /**
     * @param salutation the salutation to set
     */
    public void setSalutation(String salutation) {
        this.salutation = salutation;
    }
    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }
    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    /**
     * @return the middleName
     */
    public String getMiddleName() {
        return middleName;
    }
    /**
     * @param middleName the middleName to set
     */
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }
    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }
    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    /**
     * @return the employeeId
     */
    public String getEmployeeId() {
        return employeeId;
    }
    /**
     * @param employeeId the employeeId to set
     */
    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }
    /**
     * @return the contact
     */
    public String getContact() {
        return contact;
    }
    /**
     * @param contact the contact to set
     */
    public void setContact(String contact) {
        this.contact = contact;
    }
    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }
    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }
    /**
     * @return the userName
     */
    public String getUserName() {
        return userName;
    }
    /**
     * @param userName the userName to set
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }
    /**
     * @return the role
     */
    public String getRole() {
        return role;
    }
    /**
     * @param role the role to set
     */
    public void setRole(String role) {
        this.role = role;
    }    
}
