package com.constrosoft.db.dml.setup;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {

    public ExcelDataTO loadInitialData(XSSFWorkbook workbook) {
        ExcelDataTO excelDataTO = new ExcelDataTO();
        excelDataTO.setFirmTO(new FirmTO(workbook.getSheet("FIRM")));
        loadUserRoleAndEntitlementData(workbook, excelDataTO);
        loadUserData(workbook, excelDataTO);
        loadMasterData(workbook, excelDataTO);
        loadReportConfig(workbook, excelDataTO);
        loadSecurityQuestion(workbook, excelDataTO);
        loadEmailAndSMSConfig(workbook, excelDataTO);
        loadStateAndCity(workbook, excelDataTO);
        
        return excelDataTO;
    }

    private void loadUserRoleAndEntitlementData(XSSFWorkbook workbook, ExcelDataTO excelDataTO) {
        XSSFSheet sheet = workbook.getSheet("ENTITLEMENT");
        loadUserRoleData(sheet, excelDataTO);
        Map<UserRoleTO, List<EntitlementTO>> userRoleEntitlements = excelDataTO.getUserRoleEntitlements();
        excelDataTO.setEntitlements(new LinkedList<EntitlementTO>());
        Iterator<Row> rowIterator = sheet.iterator();
        boolean isStart = false;
        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            if (!isStart) {
                isStart = CommonUtil.isEntitlementStartRow(row);
                if (isStart && CommonUtil.isEntitlementEndRow(rowIterator.next()))// Skip one Row
                    break;
                continue;
            } else if (CommonUtil.isEntitlementEndRow(row)) {
                break;
            }
            EntitlementTO entitlement = new EntitlementTO(row);
            if (entitlement.getLevel() > 0) {
                Iterator<EntitlementTO> enIt = excelDataTO.getEntitlements().descendingIterator();
                while (enIt.hasNext()) {
                    EntitlementTO parent = enIt.next();
                    if (parent.getLevel() < entitlement.getLevel()) {
                        entitlement.setParent(parent);
                        break;
                    }
                }
            }
            excelDataTO.getEntitlements().add(entitlement);
            Iterator<Map.Entry<UserRoleTO, List<EntitlementTO>>> it = userRoleEntitlements.entrySet().iterator();
            while (it.hasNext()) {
                Entry<UserRoleTO, List<EntitlementTO>> entry = it.next();
                UserRoleTO tmpUserRole = entry.getKey();
                String isYes = CommonUtil.getStringValue(row.getCell(tmpUserRole.getColumnIndex()));
                if ("Y".equalsIgnoreCase(isYes)) {
                    entry.getValue().add(entitlement);
                }
            }
        }
    }

    private void loadUserRoleData(XSSFSheet sheet, ExcelDataTO excelDataTO) {
        Map<UserRoleTO, List<EntitlementTO>> userRoleEntitlements = new HashMap<UserRoleTO, List<EntitlementTO>>();
        Iterator<Row> rowIterator = sheet.iterator();
        boolean isStart = false;
        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            if (!isStart) {
                isStart = CommonUtil.isUserRoleStartRow(row);
                if (isStart && CommonUtil.isUserRoleEndRow(rowIterator.next()))// Skip one Row
                    break;
                continue;
            } else if (CommonUtil.isUserRoleEndRow(row)) {
                break;
            }
            UserRoleTO userRoleTO = new UserRoleTO(row);
            userRoleEntitlements.put(userRoleTO, new ArrayList<EntitlementTO>());
        }
        excelDataTO.setUserRoleEntitlements(userRoleEntitlements);
    }

    private void loadUserData(XSSFWorkbook workbook, ExcelDataTO excelDataTO) {
        excelDataTO.setUsers(new ArrayList<UserTO>());
        XSSFSheet sheet = workbook.getSheet("USERS");
        Iterator<Row> rowIterator = sheet.iterator();
        boolean isStart = false;
        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            if (!isStart) {
                isStart = CommonUtil.isUserStartRow(row);
                if (isStart && CommonUtil.isUserEndRow(rowIterator.next()))// Skip one Row
                    break;
                continue;
            } else if (CommonUtil.isUserEndRow(row)) {
                break;
            }
            UserTO userTO = new UserTO(row);
            excelDataTO.getUsers().add(userTO);
        }
    }

    private void loadMasterData(XSSFWorkbook workbook, ExcelDataTO excelDataTO) {
        excelDataTO.setMasterDataList(new ArrayList<MasterDataTO>());
        XSSFSheet sheet = workbook.getSheet("MASTER_DATA");
        Iterator<Row> rowIterator = sheet.iterator();
        boolean isStart = false;
        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            if (!isStart) {
                isStart = CommonUtil.isMCDStartRow(row);
                if (isStart && CommonUtil.isMCDEndRow(rowIterator.next()))// Skip one Row
                    break;
                continue;
            } else if (CommonUtil.isMCDEndRow(row)) {
                break;
            }
            MasterDataTO masterDataTO = new MasterDataTO(row);
            excelDataTO.getMasterDataList().add(masterDataTO);
        }
    }

    private void loadReportConfig(XSSFWorkbook workbook, ExcelDataTO excelDataTO) {
        excelDataTO.setReportConfigs(new ArrayList<ReportConfigTO>());
        XSSFSheet sheet = workbook.getSheet("REPORTS");
        Iterator<Row> rowIterator = sheet.iterator();
        boolean isStart = false;
        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            if (!isStart) {
                isStart = CommonUtil.isReportStartRow(row);
                if (isStart && CommonUtil.isReportEndRow(rowIterator.next()))// Skip one Row
                    break;
                continue;
            } else if (CommonUtil.isReportEndRow(row)) {
                break;
            }
            ReportConfigTO reportTO = new ReportConfigTO(row);
            excelDataTO.getReportConfigs().add(reportTO);
        }
    }
    
    private void loadSecurityQuestion(XSSFWorkbook workbook, ExcelDataTO excelDataTO) {
        excelDataTO.setSecurityQuestionList(new ArrayList<SecurityQuestionTO>());
        XSSFSheet sheet = workbook.getSheet("SEQURITY_QUESTION");
        Iterator<Row> rowIterator = sheet.iterator();
        boolean isStart = false;
        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            if (!isStart) {
                isStart = CommonUtil.isSecurityQuestionStartRow(row);
                if (isStart && CommonUtil.isSecurityQuestionEndRow(rowIterator.next()))// Skip one Row
                    break;
                continue;
            } else if (CommonUtil.isSecurityQuestionEndRow(row)) {
                break;
            }
            SecurityQuestionTO securityQuestionTO = new SecurityQuestionTO(row);
            excelDataTO.getSecurityQuestionList().add(securityQuestionTO);
        }
    }
    private void loadEmailAndSMSConfig(XSSFWorkbook workbook, ExcelDataTO excelDataTO) {
        XSSFSheet sheet = workbook.getSheet("SMS_EMAIL_CONFIG");
        boolean isStart = false;
        excelDataTO.setEmailConfigList(new ArrayList<EmailConfigTO>());
        Iterator<Row> emailRowIterator = sheet.iterator();
        while (emailRowIterator.hasNext()) {
            Row row = emailRowIterator.next();
            if (!isStart) {
                isStart = CommonUtil.isEmailConfigStartRow(row);
                if (isStart && CommonUtil.isEmailConfigEndRow(emailRowIterator.next()))// Skip one Row
                    break;
                continue;
            } else if (CommonUtil.isEmailConfigEndRow(row)) {
                break;
            }
            EmailConfigTO emailConfigTO = new EmailConfigTO(row);
            excelDataTO.getEmailConfigList().add(emailConfigTO);
        }
        
        isStart = false;
        excelDataTO.setSmsConfigList(new ArrayList<SMSConfigTO>());
        Iterator<Row> smsRowIterator = sheet.iterator();
        while (smsRowIterator.hasNext()) {
            Row row = smsRowIterator.next();
            if (!isStart) {
                isStart = CommonUtil.isSMSConfigStartRow(row);
                if (isStart && CommonUtil.isSMSConfigEndRow(smsRowIterator.next()))// Skip one Row
                    break;
                continue;
            } else if (CommonUtil.isSMSConfigEndRow(row)) {
                break;
            }
            SMSConfigTO smsConfigTO = new SMSConfigTO(row);
            excelDataTO.getSmsConfigList().add(smsConfigTO);
        }
        
        isStart = false;
        excelDataTO.setEmailAndSMSAlertConfigList(new ArrayList<EmailAndSMSAlertConfigTO>());
        Iterator<Row> emailAndSmsAlertRowIterator = sheet.iterator();
        while (emailAndSmsAlertRowIterator.hasNext()) {
            Row row = emailAndSmsAlertRowIterator.next();
            if (!isStart) {
                isStart = CommonUtil.isEmailAndSMSConfigAlertStartRow(row);
                if (isStart && CommonUtil.isEmailAndSMSConfigAlertEndRow(emailAndSmsAlertRowIterator.next()))// Skip one Row
                    break;
                continue;
            } else if (CommonUtil.isEmailAndSMSConfigAlertEndRow(row)) {
                break;
            }
            EmailAndSMSAlertConfigTO emailAndSmsConfigTO = new EmailAndSMSAlertConfigTO(row);
            excelDataTO.getEmailAndSMSAlertConfigList().add(emailAndSmsConfigTO);
        }
    }
    private void loadStateAndCity(XSSFWorkbook workbook, ExcelDataTO excelDataTO) {
        XSSFSheet sheet = workbook.getSheet("STATE_CITY");
        boolean isStart = false;
        excelDataTO.setStateCityMap(new LinkedHashMap<StateTO, List<CityTO>>()	);
        Iterator<Row> stateRowIterator = sheet.iterator();
        while (stateRowIterator.hasNext()) {
            Row row = stateRowIterator.next();
            if (!isStart) {
                isStart = CommonUtil.isStateStartRow(row);
                if (isStart && CommonUtil.isStateEndRow(stateRowIterator.next()))// Skip one Row
                    break;
                continue;
            } else if (CommonUtil.isStateEndRow(row)) {
                break;
            }
            StateTO stateTO = new StateTO(row);
            excelDataTO.getStateCityMap().put(stateTO, new ArrayList<CityTO>());
        }
        
        isStart = false;
        Iterator<Row> cityRowIterator = sheet.iterator();
        while (cityRowIterator.hasNext()) {
            Row row = cityRowIterator.next();
            if (!isStart) {
                isStart = CommonUtil.isCityStartRow(row);
                if (isStart && CommonUtil.isCityEndRow(cityRowIterator.next()))// Skip one Row
                    break;
                continue;
            } else if (CommonUtil.isCityEndRow(row)) {
                break;
            }
            CityTO cityTO = new CityTO(row);
            StateTO tmpState = new StateTO();
            tmpState.setId(cityTO.getStateId());
            excelDataTO.getStateCityMap().get(tmpState).add(cityTO);
        }
    }
}
