package com.constrosoft.db.dml.setup;

import org.apache.poi.xssf.usermodel.XSSFSheet;

public class FirmTO {

    public FirmTO() {
        // TODO Auto-generated constructor stub
    }
    public FirmTO(XSSFSheet sheet) {
        this.name = CommonUtil.getStringValue(sheet.getRow(0).getCell(1));
        this.firmNumber = CommonUtil.getStringValue(sheet.getRow(1).getCell(1));
        this.registrationNo = CommonUtil.getStringValue(sheet.getRow(2).getCell(1));
        this.website = CommonUtil.getStringValue(sheet.getRow(3).getCell(1));
        this.contact = CommonUtil.getStringValue(sheet.getRow(4).getCell(1));
        this.email = CommonUtil.getStringValue(sheet.getRow(5).getCell(1));
        this.addressLine1 = CommonUtil.getStringValue(sheet.getRow(6).getCell(1));
        this.addressLine2 = CommonUtil.getStringValue(sheet.getRow(7).getCell(1));
        this.town = CommonUtil.getStringValue(sheet.getRow(8).getCell(1));
        this.city = CommonUtil.getStringValue(sheet.getRow(9).getCell(1));
        this.state = CommonUtil.getStringValue(sheet.getRow(10).getCell(1));
        this.Country = CommonUtil.getStringValue(sheet.getRow(11).getCell(1));
        this.pin = CommonUtil.getStringValue(sheet.getRow(12).getCell(1));
        this.description = CommonUtil.getStringValue(sheet.getRow(13).getCell(1));
    }
    private String firmNumber;
    private String name;
    private String registrationNo;
    private String website;
    private String contact;
    private String email;
    private String addressLine1;
    private String addressLine2;
    private String town;
    private String city;
    private String state;
    private String Country;
    private String pin;
    private String description;
    /**
     * @return the firmNumber
     */
    public String getFirmNumber() {
        return firmNumber;
    }
    /**
     * @param firmNumber the firmNumber to set
     */
    public void setFirmNumber(String firmNumber) {
        this.firmNumber = firmNumber;
    }
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }
    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }
    /**
     * @return the registrationNo
     */
    public String getRegistrationNo() {
        return registrationNo;
    }
    /**
     * @param registrationNo the registrationNo to set
     */
    public void setRegistrationNo(String registrationNo) {
        this.registrationNo = registrationNo;
    }
    /**
     * @return the website
     */
    public String getWebsite() {
        return website;
    }
    /**
     * @param website the website to set
     */
    public void setWebsite(String website) {
        this.website = website;
    }
    /**
     * @return the contact
     */
    public String getContact() {
        return contact;
    }
    /**
     * @param contact the contact to set
     */
    public void setContact(String contact) {
        this.contact = contact;
    }
    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }
    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }
    /**
     * @return the addressLine1
     */
    public String getAddressLine1() {
        return addressLine1;
    }
    /**
     * @param addressLine1 the addressLine1 to set
     */
    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }
    /**
     * @return the addressLine2
     */
    public String getAddressLine2() {
        return addressLine2;
    }
    /**
     * @param addressLine2 the addressLine2 to set
     */
    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }
    /**
     * @return the town
     */
    public String getTown() {
        return town;
    }
    /**
     * @param town the town to set
     */
    public void setTown(String town) {
        this.town = town;
    }
    /**
     * @return the city
     */
    public String getCity() {
        return city;
    }
    /**
     * @param city the city to set
     */
    public void setCity(String city) {
        this.city = city;
    }
    /**
     * @return the state
     */
    public String getState() {
        return state;
    }
    /**
     * @param state the state to set
     */
    public void setState(String state) {
        this.state = state;
    }
    /**
     * @return the country
     */
    public String getCountry() {
        return Country;
    }
    /**
     * @param country the country to set
     */
    public void setCountry(String country) {
        Country = country;
    }
    /**
     * @return the pin
     */
    public String getPin() {
        return pin;
    }
    /**
     * @param pin the pin to set
     */
    public void setPin(String pin) {
        this.pin = pin;
    }
    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }
    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }
}
