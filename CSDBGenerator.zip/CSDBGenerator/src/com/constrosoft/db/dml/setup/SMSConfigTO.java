package com.constrosoft.db.dml.setup;

import org.apache.poi.ss.usermodel.Row;

public class SMSConfigTO {

    public SMSConfigTO() {
    }
    public SMSConfigTO(Row row) {
        this.url = CommonUtil.getStringValue(row.getCell(0));
        this.userId = CommonUtil.getStringValue(row.getCell(1));
        this.password = CommonUtil.getStringValue(row.getCell(2));
        this.senderId = CommonUtil.getStringValue(row.getCell(3));
    }
    private String url;
    private String userId;
    private String password;
    private String senderId;
	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}
	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return the senderId
	 */
	public String getSenderId() {
		return senderId;
	}
	/**
	 * @param senderId the senderId to set
	 */
	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}
}
