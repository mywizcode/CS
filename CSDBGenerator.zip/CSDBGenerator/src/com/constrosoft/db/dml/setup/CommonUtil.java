package com.constrosoft.db.dml.setup;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

public class CommonUtil {

    public static boolean isFirmStartRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "FIRM_START".equalsIgnoreCase(value);
    }
    public static boolean isFirmEndRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "FIRM_END".equalsIgnoreCase(value);
    }    
    public static boolean isUserRoleStartRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "USER_ROLES_START".equalsIgnoreCase(value);
    }
    public static boolean isUserRoleEndRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "USER_ROLES_END".equalsIgnoreCase(value);
    }
    public static boolean isEntitlementStartRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "ENTITLEMENT_START".equalsIgnoreCase(value);
    }
    public static boolean isEntitlementEndRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "ENTITLEMENT_END".equalsIgnoreCase(value);
    }
    public static boolean isUserStartRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "USER_START".equalsIgnoreCase(value);
    }
    public static boolean isUserEndRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "USER_END".equalsIgnoreCase(value);
    }
    public static boolean isReportStartRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "REPORTS_START".equalsIgnoreCase(value);
    }
    public static boolean isReportEndRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "REPORTS_END".equalsIgnoreCase(value);
    }    
    public static boolean isMCDStartRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "MCD_START".equalsIgnoreCase(value);
    }
    public static boolean isMCDEndRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "MCD_END".equalsIgnoreCase(value);
    }
    public static boolean isSecurityQuestionStartRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "SECURITY_QUESTION_START".equalsIgnoreCase(value);
    }
    public static boolean isSecurityQuestionEndRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "SECURITY_QUESTION_END".equalsIgnoreCase(value);
    }
    public static boolean isEmailConfigStartRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "EMAIL_CONFIG_START".equalsIgnoreCase(value);
    }
    public static boolean isEmailConfigEndRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "EMAIL_CONFIG_END".equalsIgnoreCase(value);
    }
    public static boolean isSMSConfigStartRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "SMS_CONFIG_START".equalsIgnoreCase(value);
    }
    public static boolean isSMSConfigEndRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "SMS_CONFIG_END".equalsIgnoreCase(value);
    }
    public static boolean isEmailAndSMSConfigAlertStartRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "EMAIL_SMS_ALERT_CONFIG_START".equalsIgnoreCase(value);
    }
    public static boolean isEmailAndSMSConfigAlertEndRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "EMAIL_SMS_ALERT_CONFIG_END".equalsIgnoreCase(value);
    }
    public static boolean isStateStartRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "STATE_START".equalsIgnoreCase(value);
    }
    public static boolean isStateEndRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "STATE_END".equalsIgnoreCase(value);
    }
    public static boolean isCityStartRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "CITY_START".equalsIgnoreCase(value);
    }
    public static boolean isCityEndRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "CITY_END".equalsIgnoreCase(value);
    }
    public static String getStringValue(Cell cell) {
        String result = "";
        switch (cell.getCellType()) {
        case Cell.CELL_TYPE_NUMERIC:
            result = cell.getNumericCellValue() + "";
            result = result.substring(0, result.indexOf("."));
            break;
        default:
            result = cell.getStringCellValue();
        }
        return result;
    }
}
