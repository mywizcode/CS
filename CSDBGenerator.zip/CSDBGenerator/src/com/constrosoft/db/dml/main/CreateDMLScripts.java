package com.constrosoft.db.dml.main;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.constrosoft.db.dml.setup.DMLGenerator;
import com.constrosoft.db.dml.setup.ExcelDataTO;
import com.constrosoft.db.dml.setup.ExcelReader;

public class CreateDMLScripts {

    public static void main(String[] args) {
        try {
            FileInputStream file = new FileInputStream(new File("C:\\MyData\\Sunil\\WizEye\\ConstroSoft\\CSDBGenerator\\CustomerData.xlsx"));
            String commonDMLFile = "C:\\MyData\\Sunil\\WizEye\\ConstroSoft\\CSDBGenerator\\DML\\CommonDML.sql";
            String customerDMLFile = "C:\\MyData\\Sunil\\WizEye\\ConstroSoft\\CSDBGenerator\\DML\\VeddantRealtyDML.sql";

            // Create Workbook instance holding reference to .xlsx file
            XSSFWorkbook workbook = new XSSFWorkbook(file);
            ExcelReader excelReader = new ExcelReader();
            ExcelDataTO excelDataTO = excelReader.loadInitialData(workbook);
            DMLGenerator dmlGenerator = new DMLGenerator();
            dmlGenerator.generateCommonDML(excelDataTO, commonDMLFile);
            dmlGenerator.generateCustomerDML(excelDataTO, customerDMLFile);
           
            file.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
