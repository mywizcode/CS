﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initPymtGrid();
    formatFields();
    showModal();
}
function initPymtGrid() {
    var dtOptions = {
        tableId: "PymtDetailGrid",
        isViewOnly: true
    };
    var dtTable = applySimpleDataTable(dtOptions);
}