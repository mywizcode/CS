﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initEnquirySearchGrid();
    formatFields();
    showModal();
}

function initEnquirySearchGrid() {
    var dtOptions = {
        tableId: "enquirySearchGrid",
        pageLength: 10,
        isViewOnly: false,
        customBtnGrpId: "#enquirySearchBtnDiv",
        hideSearch: false
    };
    var dtTable = applyActionDataTable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitHdnId");
}