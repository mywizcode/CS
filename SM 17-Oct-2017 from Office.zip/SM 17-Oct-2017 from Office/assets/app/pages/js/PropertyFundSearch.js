﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initPropertyFundSearchGrid();
    formatFields();
    showModal();
}

function initPropertyFundSearchGrid() {
    var dtOptions = {
        tableId: "propertyFundSearchGrid",
        pageLength: 10,
        isViewOnly: false,
        customBtnGrpId: "#propertyFundSearchBtnDiv",
        hideSearch: false
    };
    var dtTable = applyActionDataTable(dtOptions);
}




