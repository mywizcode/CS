﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;


/// <summary>
/// Summary description for EmployeeBO
/// </summary>
namespace ConstroSoft
{
    public class PropertyUserBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public PropertyUserBO() { }

        public IList<UserDefinitionDTO> fetchUserGridData(string firmNumber, long propertyId)
        {
            //TODO - Create new UI DTO for PropertyUserAccess do not use UserDefinitionDTO.
            ISession session = null;
            IList<UserDefinitionDTO> result = new List<UserDefinitionDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                UserDefinition ud = null;
                UserDefinitionDTO udt = null;
                PropertyFMAccess pfa = null;
                Property p = null;
                FirmMember fm = null;
                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => ud.Id).WithAlias(() => udt.Id))
                            .Add(Projections.Property(() => ud.Username).WithAlias(() => udt.Username))
                            .Add(Projections.Property(() => fm.FirstName), "FirmMember.FirstName")
                            .Add(Projections.Property(() => fm.LastName), "FirmMember.LastName")
                            .Add(Projections.Property(() => ud.ActivationDate).WithAlias(() => udt.ActivationDate))
                            .Add(Projections.Property(() => ud.ExpirationDate).WithAlias(() => udt.ExpirationDate))
                            .Add(Projections.Property(() => ud.Status).WithAlias(() => udt.Status));
                var query = session.QueryOver<UserDefinition>(() => ud)
                            .Inner.JoinAlias(() => ud.FirmMember, () => fm);
                result = query.Where(() => ud.FirmNumber == firmNumber && ud.Status == UserStatus.Active)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<UserDefinitionDTO>()).List<UserDefinitionDTO>();
                var proj1 = Projections.ProjectionList()
                            .Add(Projections.Property(() => ud.Id).WithAlias(() => udt.Id))
                            .Add(Projections.Property(() => ud.Username).WithAlias(() => udt.Username));
                var query1 = session.QueryOver<UserDefinition>(() => ud)
                            .Inner.JoinAlias(() => ud.FirmMember, () => fm)
                            .Left.JoinAlias(() => fm.PropertyFMAccess, () => pfa)
                            .Left.JoinAlias(() => pfa.Property, () => p);
                IList<UserDefinitionDTO> assignedUsers = query1.Where(() => ud.FirmNumber == firmNumber && ud.Status == UserStatus.Active && p.Id == propertyId)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<UserDefinitionDTO>()).List<UserDefinitionDTO>();
                result.ToList<UserDefinitionDTO>().ForEach(x => x.isUISelected = assignedUsers.Any(y => y.Id == x.Id));
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating property user access:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        
        
    }
}