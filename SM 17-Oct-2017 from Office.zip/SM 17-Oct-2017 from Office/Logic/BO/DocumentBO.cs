﻿using System;
using NHibernate;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using ConstroSoft;
using System.Collections.Generic;
using NHibernate.Criterion;
using NHibernate.Transform;
using System.Web.Hosting;
using System.Net;

/// <summary>
/// Summary description for DocumentBO
/// </summary>
namespace ConstroSoft
{
    public class DocumentBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public DocumentBO() { }
        public IList<FileUIDTO> fetchFileList(string sourcePath)
        {
            IList<FileUIDTO> results = new List<FileUIDTO>();
            try
            {
                DirectoryInfo hdDirectoryInWhichToSearch = new DirectoryInfo(@sourcePath);
                FileSystemInfo[] filesAndDirs = hdDirectoryInWhichToSearch.GetFileSystemInfos("*");
                foreach (FileSystemInfo foundFile in filesAndDirs)
                {
                    FileUIDTO FileUIDTO = new FileUIDTO();
                    FileInfo fileInfo = null;
                    DirectoryInfo directoryInfo = null;
                    if (foundFile.GetType() == typeof(FileInfo))
                    {
                        fileInfo = (FileInfo)foundFile;
                        FileUIDTO.AbsolutePath = fileInfo.FullName;
                        FileUIDTO.Name = fileInfo.Name;
                        FileUIDTO.size = fileInfo.Length;
                        FileUIDTO.CreateDate = fileInfo.CreationTime;
                        FileUIDTO.FileType = FileType.Document;
                    }
                    if (foundFile.GetType() == typeof(DirectoryInfo))
                    {
                        directoryInfo = (DirectoryInfo)foundFile;
                        FileUIDTO.AbsolutePath = directoryInfo.FullName;
                        FileUIDTO.Name = directoryInfo.Name;
                        FileUIDTO.CreateDate = directoryInfo.CreationTime;
                        FileUIDTO.FileType = FileType.Folder;
                    }
                    results.Add(FileUIDTO);
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error retriving file list:");
                log.Error(exp.Message, exp);
            }
            finally
            {

            }
            return results;
        }
        public void saveFileorFolder(FileUIDTO FileUIDTO)
        {
            try
            {
                if (FileUIDTO.FileType.Equals(FileType.Document))
                {

                    FileUIDTO.userPostedFile.SaveAs(HostingEnvironment.MapPath(FileUIDTO.AbsolutePath) + "\\"
                        + Path.GetFileName(FileUIDTO.userPostedFile.FileName));
                }
                else
                {
                    Directory.CreateDirectory(HostingEnvironment.MapPath(FileUIDTO.AbsolutePath) + "\\"
                        + Path.GetFileName(FileUIDTO.userPostedFile.FileName));

                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error creating file or folder:");
                log.Error(exp.Message, exp);
            }
            finally
            {

            }
        }
        public byte[] downloadFile(FileUIDTO FileUIDTO)
        {
            byte[] data = null;
            try
            {
                WebClient req = new WebClient();
                data = req.DownloadData(HostingEnvironment.MapPath(FileUIDTO.AbsolutePath));

            }
            catch (Exception exp)
            {
                log.Error("Unexpected error creating dowloading file:");
                log.Error(exp.Message, exp);
            }
            finally
            {

            }
            return data;
        }
        public void deleteFile(FileUIDTO FileUIDTO)
        {
            try
            {
                System.IO.File.Delete(HostingEnvironment.MapPath(FileUIDTO.AbsolutePath));
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error deleting file:");
                log.Error(exp.Message, exp);
            }
            finally
            {

            }
        }
    }
}