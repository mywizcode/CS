﻿
/// <summary>
/// Summary description for CommonUIConverter
/// </summary>
using ConstroSoft;
using System.Collections.Generic;
using NHibernate.Criterion;
using System.Linq.Expressions;
using NHibernate.Impl;
using System;
namespace ConstroSoft
{
    public class PaymentUtil
    {
        public PaymentUtil() { }
        public static PaymentTransaction createReversalPymtTransactionDTO(PaymentTransaction pymtTrans, MasterPymtTransactionDTO mptTxDTO)
        {
            PaymentTransaction reversalPymtTx = new PaymentTransaction();
            reversalPymtTx.TxDate = pymtTrans.TxDate;
            reversalPymtTx.Status = PymtTransStatus.Reversal;
            reversalPymtTx.Comments = "Reversal Entry for Tx Ref No - " + mptTxDTO.TxRefNo;
            reversalPymtTx.Amount = pymtTrans.Amount;
            reversalPymtTx.FirmAccount = pymtTrans.FirmAccount;
            reversalPymtTx.AccountTransaction = createReversalAccountTransaction(pymtTrans, mptTxDTO);

            reversalPymtTx.PaymentMaster = pymtTrans.PaymentMaster;
            reversalPymtTx.MasterPymtTransaction = pymtTrans.MasterPymtTransaction;
            reversalPymtTx.FirmNumber = pymtTrans.FirmNumber;
            reversalPymtTx.InsertUser = mptTxDTO.UpdateUser;
            reversalPymtTx.UpdateUser = mptTxDTO.UpdateUser;
            return reversalPymtTx;
        }
        public static AccountTransaction createReversalAccountTransaction(PaymentTransaction pymtTrans, MasterPymtTransactionDTO mptTxDTO)
        {
            AccountTransaction acntTrans = new AccountTransaction();
            acntTrans.FirmAccount = pymtTrans.FirmAccount;
            acntTrans.TxType = (pymtTrans.AccountTransaction.TxType == AcntTransStatus.Credit) ? AcntTransStatus.Debit : AcntTransStatus.Credit;
            acntTrans.Comments = getAccountTransactionComments(pymtTrans, mptTxDTO);
            acntTrans.TxDate = pymtTrans.TxDate;
            acntTrans.Amount = pymtTrans.Amount;
            acntTrans.FirmNumber = pymtTrans.FirmNumber;
            acntTrans.InsertUser = mptTxDTO.UpdateUser;
            acntTrans.UpdateUser = mptTxDTO.UpdateUser;
            return acntTrans;
        }
        public static string getAccountTransactionComments(PaymentTransaction pymtTrans, MasterPymtTransactionDTO masterPymtTransDTO)
        {
            string comments = "";
            string pymtModeComment = CommonUtil.getAcntTransCommentPymtMethod(masterPymtTransDTO.PymtMethod, masterPymtTransDTO.MediaNo);
            string customerName = CommonUIConverter.getCustomerFullName(masterPymtTransDTO.MPTBook.PrUnitSaleDetail.Customer.FirstName,
                masterPymtTransDTO.MPTBook.PrUnitSaleDetail.Customer.LastName);
            string pymtType = pymtTrans.AccountTransaction.Comments.Substring(pymtTrans.AccountTransaction.Comments.IndexOf(Constants.UNIT_SALE_TYPE));
            if (masterPymtTransDTO.PymtMode == PaymentMode.Receivable)
            {
                comments = string.Format(Constants.REV_PYMT_FROM, customerName) + "," + pymtModeComment
                        + "," + Constants.TX_REF + "," + string.Format(Constants.REV_TX_REF, pymtTrans.Id) + "," + pymtType;
            }
            else
            {
                comments = string.Format(Constants.REV_PYMT_TO, customerName) + "," + pymtModeComment
                        + "," + Constants.TX_REF + "," + string.Format(Constants.REV_TX_REF, pymtTrans.Id) + "," + pymtType;
            }
            return comments;
        }
        public static PrUnitSalePymtDTO createCancellationPayment(DateTime PymtDate, UserDefinitionDTO userDefDto, decimal pymtAmt)
        {
            MasterDataBO masterDataBO = new MasterDataBO();
            PrUnitSalePymtDTO prUnitSalePymtDto = new PrUnitSalePymtDTO();
            prUnitSalePymtDto.PymtType = masterDataBO.fetchMasterData(userDefDto.FirmNumber, Constants.MCDType.PR_UNIT_PYMT_TYPE, Constants.MCD_CANCELLATION_PAYMENT);
            prUnitSalePymtDto.PymtDate = PymtDate;
            prUnitSalePymtDto.PymtMode = PaymentMode.Payable;
            prUnitSalePymtDto.PymtAmt = pymtAmt;
            prUnitSalePymtDto.Description = "Unit Cancellation Payment.";
            prUnitSalePymtDto.UpdateUser = userDefDto.Username;
            
            prUnitSalePymtDto.FirmNumber = userDefDto.FirmNumber;
            prUnitSalePymtDto.InsertUser = userDefDto.Username;
            addNewPymtMaster(prUnitSalePymtDto, userDefDto);
            return prUnitSalePymtDto;
        }
        private static void addNewPymtMaster(PrUnitSalePymtDTO prUnitSalePymtDto, UserDefinitionDTO userDefDto)
        {
            PaymentMasterDTO paymentMasterDto = new PaymentMasterDTO();
            paymentMasterDto.TotalAmt = Decimal.Zero;
            paymentMasterDto.TotalPaid = Decimal.Zero;
            paymentMasterDto.TotalPending = Decimal.Zero;
            paymentMasterDto.TotalPdcAmt = Decimal.Zero;
            paymentMasterDto.FirmNumber = userDefDto.FirmNumber;
            paymentMasterDto.InsertUser = userDefDto.Username;
            prUnitSalePymtDto.PaymentMaster = paymentMasterDto;
            updatePymtMaster(prUnitSalePymtDto, userDefDto);
        }
        private static void updatePymtMaster(PrUnitSalePymtDTO prUnitSalePymtDto, UserDefinitionDTO userDefDto)
        {
            PaymentMasterDTO paymentMasterDto = prUnitSalePymtDto.PaymentMaster;
            decimal diffAmt = Decimal.Subtract(prUnitSalePymtDto.PymtAmt, paymentMasterDto.TotalAmt);
            paymentMasterDto.TotalAmt = Decimal.Add(paymentMasterDto.TotalAmt, diffAmt);
            paymentMasterDto.TotalPending = Decimal.Subtract(paymentMasterDto.TotalAmt, paymentMasterDto.TotalPaid);
            paymentMasterDto.UpdateUser = userDefDto.Username;
            if (paymentMasterDto.TotalPending > 0) paymentMasterDto.Status = PymtMasterStatus.Pending;
            else paymentMasterDto.Status = PymtMasterStatus.Paid;
        }
    }
}