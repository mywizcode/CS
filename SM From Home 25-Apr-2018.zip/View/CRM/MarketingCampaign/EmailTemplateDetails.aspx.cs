﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using ConstroSoft;

public partial class EmailTemplateDetails : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
            log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string testEmailModal = "testEmailModal";
    string testEmailModalError = "testEmailModalError";
    string selectTemplateModal = "selectTemplateModal";
    string selectTemplateModalError = "selectTemplateModalError";
    DropdownBO drpBO = new DropdownBO();
    MarketingCampaignBO marketingCampaignBO = new MarketingCampaignBO();
    DocumentBO documentBO = new DocumentBO();
    EmailAndSMSProviderBO emailSmsProviderBO = new EmailAndSMSProviderBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                EmailTemplateNavDTO navDto = ApplicationUtil.getPageNavDTO<EmailTemplateNavDTO>(Session);
                bool isSysAdmin = CommonUtil.IsSystemAdminRole(getUserDefinitionDTO());
                if (!isSysAdmin)
                {
                    if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.EMAIL_TEMPLATE_ADD, Constants.Entitlement.EMAIL_TEMPLATE_MODIFY)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                    if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) == null) Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
                }
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    protected void Page_PreInit(object sender, EventArgs e)
    {
        if (CommonUtil.IsSystemAdminRole(getUserDefinitionDTO()))
        {
            this.MasterPageFile = "~/CSAdminMaster.master";
        }
    }
    private void setNotyMsgInMaster(string msg)
    {
        if (CommonUtil.IsSystemAdminRole(getUserDefinitionDTO())) (this.Master as CSAdminMaster).setNotyMsg(msg);
        else (this.Master as CSMaster).setNotyMsg(msg);
    }
    /**
    * This method is called just before the page is rendered. So any change in state of the element is applied.
    **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                setNotyMsgInMaster(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
            RegisterPostBackControl();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
        setPageTitle();
        addCheckBoxAttributes();
    }
    public void initBootstrapComponantsFromServer()
    {
    	ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void addCheckBoxAttributes()
    {
        cbSystemOnlyTemplate.InputAttributes.Add("class", "styled");
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpEmailProvider, DrpDataType.EMAIL_PROVIDER, null, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
    }
    public void setErrorMessage(string message, string group)
    {
    	string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            setNotyMsgInMaster(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
	        CustomValidator val = new CustomValidator();
	        val.IsValid = false;
	        val.ErrorMessage = message;
	        val.ValidationGroup = group;
	        this.Page.Validators.Add(val);
        }
    }
    private void doInit(EmailTemplateNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(EmailTemplateNavDTO navDto)
    {
        try
        {
            EmailTemplatePageDTO PageDTO = new EmailTemplatePageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            pageModeHdn.Value = navDto.Mode.ToString();
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            loadEmailTemplate(navDto.TemplateId);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageFieldsWithEntitlement()
    {
        initFormFields();
    }
    private void RegisterPostBackControl() 
    {
    	if (attachmentGrid.Items.Count > 0)
        {
            foreach(System.Web.UI.WebControls.ListViewItem itemRow in attachmentGrid.Items)
            {
            	LinkButton tmpBtn = (LinkButton)itemRow.FindControl("lnkDownloadAttachmentBtn");
            	if (tmpBtn != null)
                {
                    ScriptManager mgr = ScriptManager.GetCurrent(this.Page);
                    mgr.RegisterPostBackControl(tmpBtn);
                }
            }

        }
    }
    private void setPageTitle()
    {
        if (isAddMode()) lbPageTitle.Text = Constants.ICON.ADD + Resources.Labels.ADD_EMAIL_TEMPLATE;
        else if (isModifyMode()) lbPageTitle.Text = Constants.ICON.MODIFY + Resources.Labels.MODIFY_EMAIL_TEMPLATE;
        else if (isViewMode()) lbPageTitle.Text = Constants.ICON.VIEW_DTL + Resources.Labels.EMAIL_TEMPLATE_DETAILS;
    }
    private void initFormFields()
    {
        bool viewMode = isViewMode();
        bool addMode = isAddMode();
        EmailSmsStoreDTO templateDTO = getEmailTemplate();
        bool isSysAdmin = CommonUtil.IsSystemAdminRole(getUserDefinitionDTO());
        
        //Toolbar
        btnTestEmail.Visible = !viewMode;
        btnPublish.Visible = !viewMode;
        btnSave.Visible = !viewMode;
        btnCancel.Visible = !viewMode;
        btnUnpublish.Visible = viewMode;
        divEmailToolbar.Visible = isSysAdmin || templateDTO.SystemDefined == SystemDefined.No;
        //Template name
        txtEmailTemplateName.ReadOnly = !isAddMode();
        //Subject Row
        txtEmailSubject.ReadOnly = viewMode;
        liSystemOnly.Visible = isSysAdmin && templateDTO.SystemDefined == SystemDefined.Yes;
        cbSystemOnlyTemplate.Enabled = addMode;
        lnkLoadTemplate.Visible = !viewMode;
        txtEmailBody.ReadOnly = viewMode;
        if (viewMode)
        {
            if (tblEmailHeader.Rows.Count > 0)
            {
                for (var i = 0; i < tblEmailHeader.Rows.Count; i++)
                {
                    if (tblEmailHeader.Rows[i].ID != null && tblEmailHeader.Rows[i].ID.Equals("trEmailActions")) tblEmailHeader.Rows[i].Visible = false;
                }
            }
        }
    }
    private bool isModifyMode()
    {
        return PageMode.MODIFY.ToString().Equals(pageModeHdn.Value);
    }
    private bool isViewMode()
    {
        return PageMode.VIEW.ToString().Equals(pageModeHdn.Value);
    }
    private bool isAddMode()
    {
        return PageMode.ADD.ToString().Equals(pageModeHdn.Value);
    }
    private void navigateToPreviousPage()
    {
        EmailTemplatePageDTO PageDTO = getSessionPageData();
        bool IsSysAdmin = CommonUtil.IsSystemAdminRole(getUserDefinitionDTO());
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is EmailSMSTemplateStoreNavDTO)
            {
                EmailSMSTemplateStoreNavDTO navDTO = (EmailSMSTemplateStoreNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(IsSysAdmin ? Constants.URL.ADMIN_EMAIL_SMS_TEMPLATE_STORE : Constants.URL.EMAIL_SMS_TEMPLATE_STORE, true);
            }
        }
        Response.Redirect(IsSysAdmin ? Constants.URL.ADMIN_EMAIL_SMS_TEMPLATE_STORE : Constants.URL.EMAIL_SMS_TEMPLATE_STORE, true);
    }
    private EmailTemplatePageDTO getSessionPageData()
    {
        return (EmailTemplatePageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private EmailSmsStoreDTO getEmailTemplate()
    {
        return getSessionPageData().EmailTemplate;
    }
    private void loadEmailTemplate(long TemplateId)
    {
        clearTempUploadFields();

    	EmailSmsStoreDTO tmpDTO = null;
    	if(isAddMode()) tmpDTO = createEmailSmsStoreDTO();
    	else tmpDTO = marketingCampaignBO.fetchEmailSmsTemplate(TemplateId);
    	getSessionPageData().EmailTemplate = tmpDTO;
    	
    	populateUIFromTemplateDTO(tmpDTO);

        loadPersonalization();
    }
    private void populateUIFromTemplateDTO(EmailSmsStoreDTO tmpDTO) {
    	txtEmailTemplateName.Text = tmpDTO.Name;
        cbSystemOnlyTemplate.Checked = (tmpDTO.FirmNumber.Equals(Constants.SYSDEFAULT.SYSTEM_ONLY_FIRM));
    	txtEmailSubject.Text = tmpDTO.Subject;
        txtEmailBody.Text = (tmpDTO.EmailContent != null) ? StringUtil.getBytesAsString(tmpDTO.EmailContent) : "";
        
    	loadEmailAttachments(tmpDTO.Attachments);
    }
    private void loadEmailAttachments(List<EmailSmsStoreAttachmentDTO> attachments) {
    	if (attachments != null && attachments.Count > 0)
        {
            long uiIndex = 1;
            foreach (EmailSmsStoreAttachmentDTO tmpDTO in attachments)
            {
                tmpDTO.UiIndex = uiIndex++;
            	tmpDTO.Icon = IconUtil.GetFileIcon2x(tmpDTO.FileName);
                tmpDTO.IsReadOnly = isViewMode();
            }
        }
        lbEmailNoOfAttachments.Text = (attachments != null) ? attachments.Count + "" : "";
        divAttachmentDetails.Visible = (attachments != null && attachments.Count > 0);
    	attachmentGrid.DataSource = (attachments != null) ? attachments : new List<EmailSmsStoreAttachmentDTO>();
    	attachmentGrid.DataBind();
    }
    private void loadPersonalization()
    {
        List<EmailPersonalizationDTO> tmpList = null;
        if (CommonUtil.IsSystemAdminRole(getUserDefinitionDTO())) tmpList = CommonUIConverter.getSystemEmailPersonalization();
        else tmpList = CommonUIConverter.getCustomerEmailPersonalization();

        personalizationGrid.DataSource = tmpList;
        personalizationGrid.DataBind();
    }
    private EmailSmsStoreDTO createEmailSmsStoreDTO() {
    	UserDefinitionDTO userDefDto = getUserDefinitionDTO();
    	EmailSmsStoreDTO tmpDTO = new EmailSmsStoreDTO();
    	tmpDTO.RecordType = EmailSmsType.Email;
        tmpDTO.SystemDefined = CommonUtil.IsSystemAdminRole(userDefDto) ? SystemDefined.Yes : SystemDefined.No;
    	tmpDTO.CreatedBy = CommonUIConverter.getFirmMemberDTO(userDefDto.FirmMember.Id.ToString(), null);
    	tmpDTO.CreateDate = DateUtil.getUserLocalDate();
    	tmpDTO.Status = EmailSmsStoreStatus.Draft;
    	tmpDTO.Attachments = new List<EmailSmsStoreAttachmentDTO>();
        
    	//If system defiend template then update either SYSTEM ONLY FIRM or DEFAULT FIRM
        tmpDTO.FirmNumber = userDefDto.FirmNumber;
        tmpDTO.InsertUser = userDefDto.Username;
        tmpDTO.UpdateUser = userDefDto.Username;
    	
    	return tmpDTO;
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private EmailSmsStoreAttachmentDTO createAttachmentDTO(FileUIDTO fileDTO) {
    	UserDefinitionDTO userDefDto = getUserDefinitionDTO();
    	EmailSmsStoreAttachmentDTO tmpDTO = new EmailSmsStoreAttachmentDTO();
    	tmpDTO.FileName = fileDTO.Name;
    	tmpDTO.Content = fileDTO.Content;
        tmpDTO.EmailSmsStore = new EmailSmsStoreDTO();
        tmpDTO.EmailSmsStore.Id = getEmailTemplate().Id;

    	tmpDTO.FirmNumber = userDefDto.FirmNumber;
    	tmpDTO.InsertUser = userDefDto.Username;
    	tmpDTO.UpdateUser = userDefDto.Username;
    	tmpDTO.InsertDate = DateUtil.getUserLocalDateTime();
    	tmpDTO.UpdateDate = DateUtil.getUserLocalDateTime();
    	
    	tmpDTO.Size = fileDTO.Content.Length.ToSize(SizeUnits.KB);
    			
    	return tmpDTO;
    }
    private void clearTempUploadFields()
    {
        documentBO.clearTempFileUploadDirectory(getUserDefinitionDTO().Username);
    }
    protected void onClickUploadAttachmentBtn(object sender, EventArgs e)
    {
        try
        {
        	UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        	EmailSmsStoreDTO templateDTO = getEmailTemplate();
            List<FileUIDTO> tmpList = documentBO.downloadTempUploadedFiles(string.Format(Constants.DOCUMENT_MANAGEMENT.TMP_FILE_UPLOAD_PATH, userDefDto.Username));
            if (tmpList != null && tmpList.Count > 0)
            {
                foreach (FileUIDTO tmpUIDTO in tmpList)
                {
                	templateDTO.Attachments.Add(createAttachmentDTO(tmpUIDTO));
                }
                loadEmailAttachments(templateDTO.Attachments);
            }
            clearTempUploadFields();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    protected void onClickDownloadAttachment(object sender, EventArgs e)
    {
        try
        {
        	LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            EmailSmsStoreDTO templateDTO = getEmailTemplate();
            EmailSmsStoreAttachmentDTO tmpDTO = templateDTO.Attachments.Find(x => x.UiIndex == selectedId);
            Response.Buffer = true;
            Response.Charset = "";
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + tmpDTO.FileName);
            Response.BinaryWrite(tmpDTO.Content);
            Response.Flush();
            UpdatePanel1.Update();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickRemoveAttachment(object sender, EventArgs e)
    {
        try
        {
        	LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            EmailSmsStoreDTO templateDTO = getEmailTemplate();
            EmailSmsStoreAttachmentDTO tmpDTO = templateDTO.Attachments.Find(x => x.UiIndex == selectedId);
            if(tmpDTO != null) {
            	templateDTO.Attachments.Remove(tmpDTO);
            	loadEmailAttachments(templateDTO.Attachments);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void populateEmailSmsStoreDTOFromUI(EmailSmsStoreDTO templateDTO, bool isPublish)
    {
    	UserDefinitionDTO userDefDto = getUserDefinitionDTO();
    	if(isAddMode()) {
    		templateDTO.Name = txtEmailTemplateName.Text.TrimNullable();
            if (templateDTO.SystemDefined == SystemDefined.Yes && cbSystemOnlyTemplate.Checked)
                templateDTO.FirmNumber = Constants.SYSDEFAULT.SYSTEM_ONLY_FIRM;
    	}
        templateDTO.Subject = txtEmailSubject.Text.TrimNullable();
        templateDTO.EmailContent = StringUtil.getStringAsBytes(txtEmailBody.Text);
        templateDTO.UpdatedBy = CommonUIConverter.getFirmMemberDTO(userDefDto.FirmMember.Id.ToString(), null);
        templateDTO.LastUpdateDate = DateUtil.getUserLocalDate();
        if (isPublish) templateDTO.Status = EmailSmsStoreStatus.Published;

    	templateDTO.UpdateUser = userDefDto.Username;
    }
    private void doSaveOrPublish(bool isPublish)
    {
        if (validateEmailDetailsOnSave(isPublish))
        {
            EmailSmsStoreDTO tmpDTO = getEmailTemplate();
            populateEmailSmsStoreDTOFromUI(tmpDTO, isPublish);

            long Id = marketingCampaignBO.addOrModifyEmailSmsStoreTemplate(tmpDTO);
            string msg = (isPublish) ? "Email Template is published successfully." : "Email Template is saved successfully.";
            Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg(msg));
            navigateToCurrentPage(isPublish, Id);
        }
    }
    private void navigateToCurrentPage(bool isPublish, long Id)
    {
        EmailTemplateNavDTO navDTO = new EmailTemplateNavDTO();
        navDTO.Mode = (isPublish) ? PageMode.VIEW : PageMode.MODIFY;
        navDTO.TemplateId = Id;
        navDTO.PrevNavDto = getSessionPageData().PrevNavDTO;
        Session[Constants.Session.NAV_DTO] = navDTO;
        Response.Redirect(CommonUtil.IsSystemAdminRole(getUserDefinitionDTO()) ? Constants.URL.ADMIN_EMAIL_TEMPLATE_DETAILS : Constants.URL.EMAIL_TEMPLATE_DETAILS, true);
    }
    protected void onClickPublishEmailTemplate(object sender, EventArgs e)
    {
        try
        {
            doSaveOrPublish(true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickUnPublishEmailTemplate(object sender, EventArgs e)
    {
        try
        {
            EmailSmsStoreDTO tmpDTO = getEmailTemplate();
            marketingCampaignBO.unPublishEmailSmsStoreTemplate(tmpDTO.Id, getUserDefinitionDTO());
            navigateToCurrentPage(false, tmpDTO.Id);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickSaveEmailChanges(object sender, EventArgs e)
    {
        try
        {
            doSaveOrPublish(false);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickCancelChanges(object sender, EventArgs e)
    {
        try
        {
        	navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateEmailDetailsOnSave(bool isPublish) {
    	bool isValid = true;
    	
    	EmailSmsStoreDTO templateDTO = getEmailTemplate();
    	if(string.IsNullOrWhiteSpace(txtEmailTemplateName.Text.TrimNullable())) {
			setNotyMsgInMaster(CommonUtil.getNotyErrorMsg("Please enter Template Name."));
			isValid = false;
		}
        if (isPublish)
        {
            if (string.IsNullOrWhiteSpace(txtEmailSubject.Text.TrimNullable()))
            {
                setNotyMsgInMaster(CommonUtil.getNotyErrorMsg("Please enter Subject."));
                isValid = false;
            }
            if (string.IsNullOrWhiteSpace(txtEmailBody.Text.TrimNullable()))
            {
                setNotyMsgInMaster(CommonUtil.getNotyErrorMsg("Please enter email content."));
                isValid = false;
            }
        }
		
    	long totalSize = 0; 
		foreach(EmailSmsStoreAttachmentDTO tmpDTO in templateDTO.Attachments) {
			totalSize += tmpDTO.Content.Length;
		}
		if(totalSize > Constants.EMAIL_ATTACHMENT_SIZE) {
			setNotyMsgInMaster(CommonUtil.getNotyErrorMsg(string.Format("Total attachment size should not exceed {0}MB.",
                (Constants.EMAIL_ATTACHMENT_SIZE / 1000000))));
			isValid = false;
		}
        return isValid;
    }
    //Test Email logic - start
    protected void onClickTestEmail(object sender, EventArgs e)
    {
        try
        {
        	txtTestEmail.Text = "";
            activeModalHdn.Value = testEmailModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void sendTestEmail(object sender, EventArgs e)
    {
        try
        {
            if (validateTestEmailModal())
            {
                EmailSmsStoreDTO templateDTO = getEmailTemplate();
                EmailConfigDTO configDTO = emailSmsProviderBO.fetchEmailProvider(long.Parse(drpEmailProvider.Text));

                EmailDTO emailDTO = EmailSMSUtil.populateEmailDTO(configDTO);
                emailDTO.Subject = txtEmailSubject.Text.TrimNullable();
                emailDTO.EmailContent = StringUtil.getUnEscapedEmailContent(txtEmailBody.Text.TrimNullable());
                emailDTO.Attachments = new List<AttachmentDTO>();
                if (templateDTO.Attachments != null)
                {
                    foreach (EmailSmsStoreAttachmentDTO tmpDTO in templateDTO.Attachments)
                    {
                        emailDTO.Attachments.Add(new AttachmentDTO(tmpDTO.FileName, tmpDTO.Content));
                    }
                }
                emailDTO.RecipientList = new List<string>();
                emailDTO.RecipientList.Add(txtTestEmail.Text.TrimNullable());

                EmailSMSUtil.SendEmail(emailDTO);
                setNotyMsgInMaster(CommonUtil.getNotySuccessMsg(string.Format("Email is sent to {0}", txtTestEmail.Text.TrimNullable())));
            }
            else
            {
                activeModalHdn.Value = testEmailModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelTestEmailModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateTestEmailModal() {
    	Page.Validate(testEmailModalError);
    	bool isValid = Page.IsValid;
    	if(isValid) {
    		isValid = validateEmailDetailsOnSave(true);
    	}
    	return isValid;
    }
    //Test Email Selection logic - end
    //Template Selection logic - start
    protected void onClickLoadTemplate(object sender, EventArgs e)
    {
    	try
    	{
    		drpBO.drpDataBase(drpTemplate, DrpDataType.EMAIL_STORE_TEMPLATE, null, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
    		activeModalHdn.Value = selectTemplateModal;
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    protected void LoadTemplate(object sender, EventArgs e)
    {
    	try
    	{
    		Page.Validate(selectTemplateModalError);
    		bool isValid = Page.IsValid;
    		if (isValid)
    		{
    			long TemplateId = long.Parse(drpTemplate.Text);
    			EmailSmsStoreDTO templateDTO = marketingCampaignBO.fetchEmailSmsTemplate(TemplateId);
    			
    			txtEmailSubject.Text = templateDTO.Subject;
				txtEmailBody.Text = StringUtil.getBytesAsString(templateDTO.EmailContent);
				
				EmailSmsStoreDTO CurrentTemplateDTO = getEmailTemplate();
                CurrentTemplateDTO.Attachments.Clear();
                CurrentTemplateDTO.Attachments.AddRange(copyAllAttachmentDTOs(templateDTO.Attachments));
                loadEmailAttachments(CurrentTemplateDTO.Attachments);
    		}
    		else
    		{
    			activeModalHdn.Value = selectTemplateModal;
    		}
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    protected void cancelTemplateModal(object sender, EventArgs e)
    {
    	try
    	{
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    private List<EmailSmsStoreAttachmentDTO> copyAllAttachmentDTOs(List<EmailSmsStoreAttachmentDTO> tmpSrcDTOList) {
    	List<EmailSmsStoreAttachmentDTO> tmpList = new List<EmailSmsStoreAttachmentDTO>();
    	UserDefinitionDTO userDefDto = getUserDefinitionDTO();
    	if(tmpSrcDTOList != null) {
    		foreach(EmailSmsStoreAttachmentDTO tmpSrcDTO in tmpSrcDTOList) {
    			EmailSmsStoreAttachmentDTO tmpDTO = new EmailSmsStoreAttachmentDTO();
    			tmpDTO.FileName = tmpSrcDTO.FileName;
    			tmpDTO.Content = tmpSrcDTO.Content;
    			tmpDTO.Size = tmpSrcDTO.Content.Length.ToSize(SizeUnits.KB);
    			tmpDTO.EmailSmsStore = getEmailTemplate();
    			
    			tmpDTO.FirmNumber = userDefDto.FirmNumber;
    			tmpDTO.InsertUser = userDefDto.Username;
    			tmpDTO.UpdateUser = userDefDto.Username;
    			tmpDTO.InsertDate = DateUtil.getUserLocalDateTime();
    			tmpDTO.UpdateDate = DateUtil.getUserLocalDateTime();
    			
    			tmpList.Add(tmpDTO);
    		}
    	}
    	return tmpList;
    }
    //Template Selection logic - end
}