﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.Scheduler;

public partial class EmailCampaignDetails : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
            log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string testEmailModal = "testEmailModal";
    string testEmailModalError = "testEmailModalError";
    string addRecipientModal = "addRecipientModal";
    string addRecipientModalError = "addRecipientModalError";
    string campaignScheduleModal = "campaignScheduleModal";
    string campaignScheduleModalError = "campaignScheduleModalError";
    string selectTemplateModal = "selectTemplateModal";
    string selectTemplateModalError = "selectTemplateModalError";
    string selectProviderModal = "selectProviderModal";
    string selectProviderModalError = "selectProviderModalError";
    DropdownBO drpBO = new DropdownBO();
    MarketingCampaignBO marketingCampaignBO = new MarketingCampaignBO();
    DocumentBO documentBO = new DocumentBO();
    EmailAndSMSProviderBO emailSmsProviderBO = new EmailAndSMSProviderBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                EmailCampaignNavDTO navDto = ApplicationUtil.getPageNavDTO<EmailCampaignNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.EMAIL_CAMPAIGN_ADD, Constants.Entitlement.EMAIL_CAMPAIGN_MODIFY)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
        * This method is called just before the page is rendered. So any change in state of the element is applied.
        **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
            RegisterPostBackControl();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
        setPageTitle();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpRecipientProperty, DrpDataType.PROPERTY_NAME, userDefDto.FirmMember.Id.ToString(), Constants.SELECT_ALL, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpProvider, DrpDataType.EMAIL_PROVIDER, null, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
    }
    public void setErrorMessage(string message, string group)
    {
        string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }
    }
    private void doInit(EmailCampaignNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(EmailCampaignNavDTO navDto)
    {
        try
        {
            EmailCampaignPageDTO PageDTO = new EmailCampaignPageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            pageModeHdn.Value = navDto.Mode.ToString();
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            loadEmailCampaign(navDto.CampaignId);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageFieldsWithEntitlement()
    {
        initFormFields();
    }
    private void RegisterPostBackControl()
    {
        if (attachmentGrid.Items.Count > 0)
        {
            foreach (System.Web.UI.WebControls.ListViewItem itemRow in attachmentGrid.Items)
            {
                LinkButton tmpBtn = (LinkButton)itemRow.FindControl("lnkDownloadAttachmentBtn");
                if (tmpBtn != null)
                {
                    ScriptManager mgr = ScriptManager.GetCurrent(this.Page);
                    mgr.RegisterPostBackControl(tmpBtn);
                }
            }

        }
    }
    private void setPageTitle()
    {
        if (isAddMode()) lbPageTitle.Text = Constants.ICON.ADD + Resources.Labels.ADD_EMAIL_CAMPAIGN;
        else if (isModifyMode()) lbPageTitle.Text = Constants.ICON.MODIFY + Resources.Labels.MODIFY_EMAIL_CAMPAIGN;
        else if (isViewMode()) lbPageTitle.Text = Constants.ICON.VIEW_DTL + Resources.Labels.EMAIL_CAMPAIGN_DETAILS;
    }
    private void initFormFields()
    {
        bool viewMode = isViewMode();
        EmailSmsCampaignDTO campaignDTO = getEmailCampaign();
        //Email top bar
        btnTestEmail.Visible = !viewMode;
        btnStartCampaign.Visible = !viewMode;
        btnSave.Visible = !viewMode;
        btnCancel.Visible = !viewMode;
        btnStopCampaign.Visible = viewMode && campaignDTO.Stage == EmailSmsCampaignStage.Scheduled;
        divEmailToolbar.Visible = campaignDTO.Stage != EmailSmsCampaignStage.Completed;
        //Campaign Message
        CampaignMessageRow.Visible = viewMode && campaignDTO.Stage == EmailSmsCampaignStage.Completed;
        lbCampaignSuccessMessage.Text = (viewMode && campaignDTO.Status == EmailSmsCampaignStatus.Success) ? campaignDTO.Message : "";
        lbCampaignFailureMessage.Text = (viewMode && campaignDTO.Status == EmailSmsCampaignStatus.Failed) ? campaignDTO.Message : "";
        /*In case of campaign is failed then agent can edit campaign and reschedule*/
        lnkEditCampaign.Visible = viewMode && campaignDTO.Status == EmailSmsCampaignStatus.Failed;
        //Email Campaign name
        txtCampaignName.ReadOnly = viewMode;
        lnkEmailProvider.Visible = !viewMode;
        lbEmailProvider.Visible = viewMode;
        //Recipient row
        lnkEmailRecipient.Visible = !viewMode;
        lbEmailRecipient.Visible = viewMode;
        txtRecipient.ReadOnly = viewMode;
        //Email Subject row
        txtEmailSubject.ReadOnly = viewMode;
        //Schedule row
        lnkEmailScheduleDate.Visible = !viewMode;
        lbEmailScheduledDate.Visible = viewMode;
        lnkLoadTemplate.Visible = !viewMode;
        ulEmailActions.Visible = !viewMode;
        txtEmailBody.ReadOnly = viewMode;
        if (viewMode)
        {
            if (tblEmailHeader.Rows.Count > 0)
            {
                for (var i = 0; i < tblEmailHeader.Rows.Count; i++)
                {
                    HtmlControl tmpCntrl = (HtmlControl)tblEmailHeader.Rows[i].FindControl("trEmailActions");
                    if (tmpCntrl != null) tmpCntrl.Visible = false;
                }
            }
        }
    }
    private bool isModifyMode()
    {
        return PageMode.MODIFY.ToString().Equals(pageModeHdn.Value);
    }
    private bool isViewMode()
    {
        return PageMode.VIEW.ToString().Equals(pageModeHdn.Value);
    }
    private bool isAddMode()
    {
        return PageMode.ADD.ToString().Equals(pageModeHdn.Value);
    }
    private void navigateToPreviousPage()
    {
        EmailCampaignPageDTO PageDTO = getSessionPageData();
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is EmailSMSCampaignSearchNavDTO)
            {
                EmailSMSCampaignSearchNavDTO navDTO = (EmailSMSCampaignSearchNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.EMAIL_SMS_CAMPAIGN_SEARCH, true);
            }
        }
        Response.Redirect(Constants.URL.EMAIL_SMS_CAMPAIGN_SEARCH, true);
    }
    private EmailCampaignPageDTO getSessionPageData()
    {
        return (EmailCampaignPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private EmailSmsCampaignDTO getEmailCampaign()
    {
        return getSessionPageData().EmailCampaign;
    }
    private void loadEmailCampaign(long CampaignId)
    {
        clearTempUploadFields();

        EmailSmsCampaignDTO tmpDTO = null;
        if (isAddMode()) tmpDTO = createEmailSmsCampaignDTO();
        else tmpDTO = marketingCampaignBO.fetchEmailSmsCampaign(CampaignId);
        getSessionPageData().EmailCampaign = tmpDTO;

        populateUIFromTemplateDTO(tmpDTO);

        loadPersonalization();
    }
    private void populateUIFromTemplateDTO(EmailSmsCampaignDTO tmpDTO)
    {
        txtCampaignName.Text = tmpDTO.Name;
        txtEmailProvider.Text = (tmpDTO.EmailConfig != null) ? tmpDTO.EmailConfig.Name : "";
        setRecipients(tmpDTO);
        txtEmailSubject.Text = tmpDTO.Subject;
        setUIScheduleDate(tmpDTO);
        txtEmailBody.Text = (tmpDTO.EmailContent != null) ? StringUtil.getBytesAsString(tmpDTO.EmailContent) : "";

        loadEmailAttachments(tmpDTO.Attachments);
    }
    private void loadEmailAttachments(List<EmailSmsCampaignAttachmentDTO> attachments)
    {
        if (attachments != null && attachments.Count > 0)
        {
            long uiIndex = 1;
            foreach (EmailSmsCampaignAttachmentDTO tmpDTO in attachments)
            {
                tmpDTO.UiIndex = uiIndex++;
                tmpDTO.Icon = IconUtil.GetFileIcon2x(tmpDTO.FileName);
                tmpDTO.IsReadOnly = isViewMode();
            }
        }
        lbEmailNoOfAttachments.Text = (attachments != null) ? attachments.Count + "" : "";
        divAttachmentDetails.Visible = (attachments != null && attachments.Count > 0);
        attachmentGrid.DataSource = (attachments != null) ? attachments : new List<EmailSmsCampaignAttachmentDTO>();
        attachmentGrid.DataBind();
    }
    private void loadPersonalization()
    {
        personalizationGrid.DataSource = CommonUIConverter.getCustomerEmailPersonalization();
        personalizationGrid.DataBind();
    }
    private EmailSmsCampaignDTO createEmailSmsCampaignDTO()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        EmailSmsCampaignDTO tmpDTO = new EmailSmsCampaignDTO();
        tmpDTO.RecordType = EmailSmsType.Email;
        tmpDTO.CreatedBy = CommonUIConverter.getFirmMemberDTO(userDefDto.FirmMember.Id.ToString(), null);
        tmpDTO.CreateDate = DateUtil.getUserLocalDate();
        tmpDTO.Stage = EmailSmsCampaignStage.Draft;
        tmpDTO.Status = EmailSmsCampaignStatus.NotStarted;
        tmpDTO.Attachments = new List<EmailSmsCampaignAttachmentDTO>();
        tmpDTO.Recipients = new List<EmailSmsCampaignRecipientDTO>();

        tmpDTO.FirmNumber = userDefDto.FirmNumber;
        tmpDTO.InsertUser = userDefDto.Username;
        tmpDTO.UpdateUser = userDefDto.Username;

        return tmpDTO;
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private EmailSmsCampaignAttachmentDTO createAttachmentDTO(FileUIDTO fileDTO)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        EmailSmsCampaignAttachmentDTO tmpDTO = new EmailSmsCampaignAttachmentDTO();
        tmpDTO.FileName = fileDTO.Name;
        tmpDTO.Content = fileDTO.Content;
        tmpDTO.EmailSmsCampaign = new EmailSmsCampaignDTO();
        tmpDTO.EmailSmsCampaign.Id = getEmailCampaign().Id;

        tmpDTO.FirmNumber = userDefDto.FirmNumber;
        tmpDTO.InsertUser = userDefDto.Username;
        tmpDTO.UpdateUser = userDefDto.Username;
        tmpDTO.InsertDate = DateUtil.getUserLocalDateTime();
        tmpDTO.UpdateDate = DateUtil.getUserLocalDateTime();

        tmpDTO.Size = fileDTO.Content.Length.ToSize(SizeUnits.KB);

        return tmpDTO;
    }
    private void clearTempUploadFields()
    {
        documentBO.clearTempFileUploadDirectory(getUserDefinitionDTO().Username);
    }
    protected void onClickUploadAttachmentBtn(object sender, EventArgs e)
    {
        try
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            EmailSmsCampaignDTO campaignDTO = getEmailCampaign();
            List<FileUIDTO> tmpList = documentBO.downloadTempUploadedFiles(string.Format(Constants.DOCUMENT_MANAGEMENT.TMP_FILE_UPLOAD_PATH, userDefDto.Username));
            if (tmpList != null && tmpList.Count > 0)
            {
                foreach (FileUIDTO tmpUIDTO in tmpList)
                {
                    campaignDTO.Attachments.Add(createAttachmentDTO(tmpUIDTO));
                }
                loadEmailAttachments(campaignDTO.Attachments);
            }
            clearTempUploadFields();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    protected void onClickDownloadAttachment(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            EmailSmsCampaignDTO campaignDTO = getEmailCampaign();
            EmailSmsCampaignAttachmentDTO tmpDTO = campaignDTO.Attachments.Find(x => x.UiIndex == selectedId);
            Response.Buffer = true;
            Response.Charset = "";
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + tmpDTO.FileName);
            Response.BinaryWrite(tmpDTO.Content);
            Response.Flush();
            UpdatePanel1.Update();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickRemoveAttachment(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            EmailSmsCampaignDTO campaignDTO = getEmailCampaign();
            EmailSmsCampaignAttachmentDTO tmpDTO = campaignDTO.Attachments.Find(x => x.UiIndex == selectedId);
            if (tmpDTO != null)
            {
                campaignDTO.Attachments.Remove(tmpDTO);
                loadEmailAttachments(campaignDTO.Attachments);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void populateEmailSmsCampaignDTOFromUI(EmailSmsCampaignDTO campaignDTO, bool isStartCampaign)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        if (isAddMode())
        {
            campaignDTO.Name = txtCampaignName.Text.TrimNullable();
        }
        campaignDTO.Subject = txtEmailSubject.Text.TrimNullable();
        campaignDTO.EmailContent = StringUtil.getStringAsBytes(txtEmailBody.Text);
        campaignDTO.UpdatedBy = CommonUIConverter.getFirmMemberDTO(userDefDto.FirmMember.Id.ToString(), null);
        campaignDTO.LastUpdateDate = DateUtil.getUserLocalDate();
        if (isStartCampaign)
        {
            if (campaignDTO.ScheduleOption == EmailSmsScheduleOption.Now) campaignDTO.ScheduledDate = DateUtil.getUserLocalDateTime();
            campaignDTO.Stage = EmailSmsCampaignStage.Scheduled;
        }

        campaignDTO.UpdateUser = userDefDto.Username;
    }
    private void doSaveOrStartCampaign(bool isStartCampaign)
    {
        if (validateEmailDetailsOnSave(isStartCampaign))
        {
            EmailSmsCampaignDTO tmpDTO = getEmailCampaign();
            populateEmailSmsCampaignDTOFromUI(tmpDTO, isStartCampaign);

            long Id = marketingCampaignBO.addOrModifyEmailSmsCampaign(tmpDTO);
            //If campaign is started then register campaign as job in Quartz.
            if(isStartCampaign) {
            	JobScheduler.AddEmailSMSCampaignJob(Id, tmpDTO.ScheduledDate.Value);
            }
            string msg = (isStartCampaign) ? "Email Campaign is started successfully." : "Email Campaign is saved successfully.";
            Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg(msg));
            navigateToCurrentPage(isStartCampaign, Id);
        }
    }
    private void navigateToCurrentPage(bool isStartCampaign, long Id)
    {
        EmailCampaignNavDTO navDTO = new EmailCampaignNavDTO();
        navDTO.Mode = (isStartCampaign) ? PageMode.VIEW : PageMode.MODIFY;
        navDTO.CampaignId = Id;
        navDTO.PrevNavDto = getSessionPageData().PrevNavDTO;
        Session[Constants.Session.NAV_DTO] = navDTO;
        Response.Redirect(Constants.URL.EMAIL_CAMPAIGN_DETAILS, true);
    }
    protected void onClickRescheduleCampaign(object sender, EventArgs e)
    {
        try
        {
            EmailSmsCampaignDTO tmpDTO = getEmailCampaign();
            JobScheduler.DeleteEmailSMSCampaignJob(tmpDTO.Id);
            marketingCampaignBO.stopCampaign(tmpDTO.Id, getUserDefinitionDTO());
            Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg("Email campaign is available to modify."));
            navigateToCurrentPage(false, tmpDTO.Id);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickStartCampaign(object sender, EventArgs e)
    {
        try
        {
            doSaveOrStartCampaign(true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickStopCampaign(object sender, EventArgs e)
    {
        try
        {
            EmailSmsCampaignDTO tmpDTO = getEmailCampaign();
            JobScheduler.DeleteEmailSMSCampaignJob(tmpDTO.Id);
            marketingCampaignBO.stopCampaign(tmpDTO.Id, getUserDefinitionDTO());
            Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg("Email campaign is stopped successfully."));
            navigateToCurrentPage(false, tmpDTO.Id);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickSaveEmailChanges(object sender, EventArgs e)
    {
        try
        {
            doSaveOrStartCampaign(false);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickCancelChanges(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateEmailDetailsOnSave(bool isCampaignStart)
    {
        bool isValid = true;

        EmailSmsCampaignDTO campaignDTO = getEmailCampaign();
        if (string.IsNullOrWhiteSpace(txtCampaignName.Text.TrimNullable()))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please enter Campaign Name."));
            isValid = false;
        }
        if (isCampaignStart)
        {
            if (campaignDTO.EmailConfig == null || campaignDTO.EmailConfig.Id == 0)
            {
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please select Provider."));
                isValid = false;
            }
            if (string.IsNullOrWhiteSpace(txtEmailSubject.Text.TrimNullable()))
            {
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please enter Subject."));
                isValid = false;
            }
            if (string.IsNullOrWhiteSpace(txtEmailBody.Text.TrimNullable()))
            {
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please enter email content."));
                isValid = false;
            }
            if (campaignDTO.ScheduleOption == null || (campaignDTO.ScheduleOption == EmailSmsScheduleOption.Scheduled && campaignDTO.ScheduledDate == null))
            {
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please select Schedule Date."));
                isValid = false;
            }
            if (campaignDTO.Recipients.Count == 0)
            {
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please select Recipients."));
                isValid = false;
            }
        }

        long totalSize = 0;
        foreach (EmailSmsCampaignAttachmentDTO tmpDTO in campaignDTO.Attachments)
        {
            totalSize += tmpDTO.Content.Length;
        }
        if (totalSize > Constants.EMAIL_ATTACHMENT_SIZE)
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(string.Format("Total attachment size should not exceed {0}MB.",
                (Constants.EMAIL_ATTACHMENT_SIZE / 1000000))));
            isValid = false;
        }
        return isValid;
    }
    //Test Email logic - start
    protected void onClickTestEmail(object sender, EventArgs e)
    {
        try
        {
            txtTestEmail.Text = "";
            activeModalHdn.Value = testEmailModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void sendTestEmail(object sender, EventArgs e)
    {
        try
        {
            if (validateTestEmailModal())
            {
                EmailSmsCampaignDTO campaignDTO = getEmailCampaign();
                EmailConfigDTO configDTO = emailSmsProviderBO.fetchEmailProvider(campaignDTO.EmailConfig.Id);

                EmailDTO emailDTO = EmailSMSUtil.populateEmailDTO(configDTO);
                emailDTO.Subject = txtEmailSubject.Text.TrimNullable();
                emailDTO.EmailContent = StringUtil.getUnEscapedEmailContent(txtEmailBody.Text.TrimNullable());
                emailDTO.Attachments = new List<AttachmentDTO>();
                if (campaignDTO.Attachments != null)
                {
                    foreach (EmailSmsCampaignAttachmentDTO tmpDTO in campaignDTO.Attachments)
                    {
                        emailDTO.Attachments.Add(new AttachmentDTO(tmpDTO.FileName, tmpDTO.Content));
                    }
                }
                emailDTO.RecipientList = new List<string>();
                emailDTO.RecipientList.Add(txtTestEmail.Text.TrimNullable());

                EmailSMSUtil.SendEmail(emailDTO);
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format("Email is sent to {0}", txtTestEmail.Text.TrimNullable())));
            }
            else
            {
                activeModalHdn.Value = testEmailModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelTestEmailModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateTestEmailModal()
    {
        Page.Validate(testEmailModalError);
        bool isValid = Page.IsValid;
        if (isValid)
        {
            isValid = validateEmailDetailsOnSave(true);
        }
        return isValid;
    }
    //Test Email Selection logic - end
    //Add Recipient Modal - Start
    private void resetRecipientModalFields()
    {
    	divRecipientTower.Visible = false;
    	drpRecipientProperty.ClearSelection();
    	drpRecipientCustomerType.ClearSelection();
    	drpRecipientTower.ClearSelection();
    }
    private void initRecipientModalAction()
    {
        resetRecipientModalFields();
        activeModalHdn.Value = addRecipientModal;
    }
    protected void onClickAddRecipients(object sender, EventArgs e)
    {
        try
        {
        	initRecipientModalAction();
        	drpRecipientProperty.ClearSelection();
            drpBO.drpEnum<EmailSmsRcpntType>(drpRecipientCustomerType, Constants.SELECT_ITEM, EmailSmsRcpntType.ONLY_SOLD_UNIT_CUSTOMERS.ToString());
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onChangeRecipientProperty(object sender, EventArgs e)
    {
        try
        {
        	divRecipientTower.Visible = false;
        	if(String.IsNullOrEmpty(drpRecipientProperty.Text)) {
        		drpBO.drpEnum<EmailSmsRcpntType>(drpRecipientCustomerType, Constants.SELECT_ITEM, EmailSmsRcpntType.ONLY_SOLD_UNIT_CUSTOMERS.ToString());
        	} else {
        		drpBO.drpEnum<EmailSmsRcpntType>(drpRecipientCustomerType, Constants.SELECT_ITEM);
        	}
            activeModalHdn.Value = addRecipientModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onChangeRecipientCustoemrType(object sender, EventArgs e)
    {
        try
        {
        	divRecipientTower.Visible = false;
        	if(drpRecipientCustomerType.Text.Equals(EmailSmsRcpntType.ONLY_SOLD_UNIT_CUSTOMERS.ToString())) {
        		divRecipientTower.Visible = true;
        		long propertyId = long.Parse(drpRecipientProperty.Text);
        		drpBO.drpDataBase(drpRecipientTower, DrpDataType.PROPERTY_TOWER, propertyId.ToString(), Constants.SELECT_ALL, getUserDefinitionDTO().FirmNumber);
        	}
            activeModalHdn.Value = addRecipientModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void addRecipients(object sender, EventArgs e)
    {
        try
        {
            if (validateAddRecipient())
            {
                if (!isDuplicateRecipient())
                {
                    EmailSmsCampaignDTO campaignDTO = getEmailCampaign();
                    campaignDTO.Recipients.Add(createEmailSmsCampaignRecipientDTO(getEmailCampaign()));
                    setRecipients(campaignDTO);
                }
            }
            else
            {
                activeModalHdn.Value = addRecipientModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeRecipientToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            EmailSmsCampaignDTO campaignDTO = getEmailCampaign();
            EmailSmsCampaignRecipientDTO tmpDTO = campaignDTO.Recipients.Find(x => x.Name.Equals(token));
            if(tmpDTO != null) {
            	campaignDTO.Recipients.Remove(tmpDTO);
            }
            setRecipients(campaignDTO);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setRecipients(EmailSmsCampaignDTO campaignDTO)
    {
        string recipientText = null;
        foreach (EmailSmsCampaignRecipientDTO tmpDTO in campaignDTO.Recipients)
        {
        	recipientText = CommonUtil.addFilterToken(recipientText, tmpDTO.Name);
        }
        txtRecipient.Text = recipientText;
    }
    private EmailSmsCampaignRecipientDTO createEmailSmsCampaignRecipientDTO(EmailSmsCampaignDTO campaignDTO)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        EmailSmsCampaignRecipientDTO tmpDTO = new EmailSmsCampaignRecipientDTO();
        tmpDTO.Name = getRecipientName();
        tmpDTO.PropertyId = String.IsNullOrEmpty(drpRecipientProperty.Text) ? 0 : long.Parse(drpRecipientProperty.Text);
        tmpDTO.RecipientType = EnumHelper.ToEnum<EmailSmsRcpntType>(drpRecipientCustomerType.Text);
        tmpDTO.TowerId = (String.IsNullOrEmpty(drpRecipientTower.Text)) ? 0 : long.Parse(drpRecipientTower.Text);
        tmpDTO.EmailSmsCampaign = campaignDTO;

        tmpDTO.FirmNumber = userDefDto.FirmNumber;
        tmpDTO.InsertUser = userDefDto.Username;
        tmpDTO.UpdateUser = userDefDto.Username;
        return tmpDTO;
    }
    public string getRecipientName()
    {
    	EmailSmsRcpntType type = EnumHelper.ToEnum<EmailSmsRcpntType>(drpRecipientCustomerType.Text);
    	string tower = (type == EmailSmsRcpntType.ONLY_SOLD_UNIT_CUSTOMERS && !String.IsNullOrEmpty(drpRecipientTower.Text)) ? " of " + drpRecipientTower.SelectedItem.Text : "";
    	string peroperty = (String.IsNullOrEmpty(drpRecipientProperty.Text)) ? " in All Properties" : " in " + drpRecipientProperty.SelectedItem.Text;
        return type.GetDescription() + tower + peroperty;
    }
    protected void cancelRecipientModal(object sender, EventArgs e)
    {
        try
        {
            
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateAddRecipient()
    {
    	Page.Validate(addRecipientModalError);
    	bool isValid = Page.IsValid;
    	
        return isValid;
    }
    private bool isDuplicateRecipient()
    {
        EmailSmsCampaignDTO campaignDTO = getEmailCampaign();
        if (campaignDTO.Recipients != null)
        {
            EmailSmsRcpntType type = EnumHelper.ToEnum<EmailSmsRcpntType>(drpRecipientCustomerType.Text);
            long PropertyId = String.IsNullOrEmpty(drpRecipientProperty.Text) ? 0 : long.Parse(drpRecipientProperty.Text);
            long TowerId = String.IsNullOrEmpty(drpRecipientTower.Text) ? 0 : long.Parse(drpRecipientTower.Text);
            foreach (EmailSmsCampaignRecipientDTO tmpDTO in campaignDTO.Recipients)
            {
                if (tmpDTO.RecipientType == type && tmpDTO.PropertyId == PropertyId && tmpDTO.TowerId == TowerId)
                {
                    (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Selected recipient criteria is already added."));
                    return true;
                }
            }
        }
        return false;
    }
    //Add Recipient Modal - End
    //Schedule Email Campaign Modal - Start
    private void setUIScheduleDate(EmailSmsCampaignDTO campaignDTO) {
    	string scheduleDateValue = "";
    	if(campaignDTO.ScheduleOption != null) {
    		if(campaignDTO.ScheduleOption == EmailSmsScheduleOption.Now && campaignDTO.Stage == EmailSmsCampaignStage.Draft) {
    			scheduleDateValue = "Send Email immediately";
    		} else {
    			scheduleDateValue = DateUtil.getCSDateTime(campaignDTO.ScheduledDate);
    		}
    	}
    	lbScheduledDateValue.Text = scheduleDateValue;
    }
    private void resetCampaignScheduleModalFields(EmailSmsCampaignDTO campaignDTO)
    {
        rdSendEmailNow.Checked = (campaignDTO.ScheduleOption == EmailSmsScheduleOption.Now);
        rdScheduleEmail.Checked = (campaignDTO.ScheduleOption == EmailSmsScheduleOption.Scheduled);
    	txtScheduleDate.Text = (rdScheduleEmail.Checked && campaignDTO.ScheduledDate != null) ? DateUtil.getCSDateTime(campaignDTO.ScheduledDate) : null;
    }
    private void initCampaignScheduleModalAction(EmailSmsCampaignDTO campaignDTO)
    {
    	resetCampaignScheduleModalFields(campaignDTO);
        activeModalHdn.Value = campaignScheduleModal;
    }
    protected void onClickScheduleCampaign(object sender, EventArgs e)
    {
        try
        {
        	initCampaignScheduleModalAction(getEmailCampaign());
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void saveCampaignSchedule(object sender, EventArgs e)
    {
        try
        {
            if (validateCampaignSchedule())
            {
            	EmailSmsCampaignDTO campaignDTO = getEmailCampaign();
            	campaignDTO.ScheduleOption = (rdSendEmailNow.Checked) ? EmailSmsScheduleOption.Now : EmailSmsScheduleOption.Scheduled;
            	campaignDTO.ScheduledDate = (campaignDTO.ScheduleOption == EmailSmsScheduleOption.Scheduled && !String.IsNullOrEmpty(txtScheduleDate.Text)) 
                        ? DateUtil.getCSDateTime(txtScheduleDate.Text) : null;
            	setUIScheduleDate(campaignDTO);
            }
            else
            {
                activeModalHdn.Value = campaignScheduleModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void clearCampaignSchedule(object sender, EventArgs e)
    {
        try
        {
        	EmailSmsCampaignDTO campaignDTO = getEmailCampaign();
        	campaignDTO.ScheduleOption = null;
        	campaignDTO.ScheduledDate = null;
        	setUIScheduleDate(campaignDTO);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelCampaignScheduleModal(object sender, EventArgs e)
    {
        try
        {
            
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateCampaignSchedule()
    {
    	if(!rdSendEmailNow.Checked && !rdScheduleEmail.Checked) {
            setErrorMessage("Please select campaign schedule date.", campaignScheduleModalError);
    		return false;
    	}
    	if(rdScheduleEmail.Checked && String.IsNullOrEmpty(txtScheduleDate.Text)) {
            setErrorMessage("Please enter schedule date.", campaignScheduleModalError);
    		return false;
    	}
    	if(rdScheduleEmail.Checked) {
    		DateTime scheduleDate = DateUtil.getCSDateTime(txtScheduleDate.Text).Value;
            if (scheduleDate.CompareTo(DateUtil.getUserLocalDateTime()) <= 0)
            {
                setErrorMessage("Schedule Date should be in future.", campaignScheduleModalError);
        		return false;
        	}
    	}
        return true;
    }
    //Schedule Email Campaign Modal - End
    //Template Selection logic - start
    protected void onClickLoadTemplate(object sender, EventArgs e)
    {
    	try
    	{
    		drpBO.drpDataBase(drpTemplate, DrpDataType.EMAIL_STORE_TEMPLATE, null, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
    		activeModalHdn.Value = selectTemplateModal;
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    protected void LoadTemplate(object sender, EventArgs e)
    {
    	try
    	{
    		Page.Validate(selectTemplateModalError);
    		bool isValid = Page.IsValid;
    		if (isValid)
    		{
    			long TemplateId = long.Parse(drpTemplate.Text);
    			EmailSmsStoreDTO templateDTO = marketingCampaignBO.fetchEmailSmsTemplate(TemplateId);
    			
    			txtEmailSubject.Text = templateDTO.Subject;
				txtEmailBody.Text = StringUtil.getBytesAsString(templateDTO.EmailContent);
				
				EmailSmsCampaignDTO campaignDTO = getEmailCampaign();
				campaignDTO.Attachments.Clear();
                campaignDTO.Attachments.AddRange(copyAllAttachmentDTOs(templateDTO.Attachments));
				loadEmailAttachments(campaignDTO.Attachments);
    		}
    		else
    		{
    			activeModalHdn.Value = selectTemplateModal;
    		}
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    protected void cancelTemplateModal(object sender, EventArgs e)
    {
    	try
    	{
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    private List<EmailSmsCampaignAttachmentDTO> copyAllAttachmentDTOs(List<EmailSmsStoreAttachmentDTO> tmpSrcDTOList) {
    	List<EmailSmsCampaignAttachmentDTO> tmpList = new List<EmailSmsCampaignAttachmentDTO>();
    	UserDefinitionDTO userDefDto = getUserDefinitionDTO();
    	if(tmpSrcDTOList != null) {
    		foreach(EmailSmsStoreAttachmentDTO tmpSrcDTO in tmpSrcDTOList) {
    			EmailSmsCampaignAttachmentDTO tmpDTO = new EmailSmsCampaignAttachmentDTO();
    			tmpDTO.FileName = tmpSrcDTO.FileName;
    			tmpDTO.Content = tmpSrcDTO.Content;
    			tmpDTO.Size = tmpSrcDTO.Content.Length.ToSize(SizeUnits.KB);
    			tmpDTO.EmailSmsCampaign = getEmailCampaign();
    			
    			tmpDTO.FirmNumber = userDefDto.FirmNumber;
    			tmpDTO.InsertUser = userDefDto.Username;
    			tmpDTO.UpdateUser = userDefDto.Username;
    			tmpDTO.InsertDate = DateUtil.getUserLocalDateTime();
    			tmpDTO.UpdateDate = DateUtil.getUserLocalDateTime();
    			
    			tmpList.Add(tmpDTO);
    		}
    	}
    	return tmpList;
    }
    //Template Selection logic - end
    //Provider Selection logic - start
    protected void onClickProvider(object sender, EventArgs e)
    {
        try
        {
            EmailSmsCampaignDTO campaignDTO = getEmailCampaign();
            if (campaignDTO.EmailConfig != null) drpProvider.Text = campaignDTO.EmailConfig.Id.ToString();
            activeModalHdn.Value = selectProviderModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void AssignProvider(object sender, EventArgs e)
    {
        try
        {
            EmailSmsCampaignDTO campaignDTO = getEmailCampaign();
            if (!string.IsNullOrWhiteSpace(drpProvider.Text))
            {
                long Provider = long.Parse(drpProvider.Text);
                txtEmailProvider.Text = drpProvider.SelectedItem.Text;
                campaignDTO.EmailConfig = CommonUIConverter.getEmailConfigDTO(drpProvider.Text, drpProvider.SelectedItem.Text);
            }
            else
            {
                txtEmailProvider.Text = null;
                campaignDTO.EmailConfig = null;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelProviderModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Provider Selection logic - end
}