﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using ConstroSoft;

public partial class SMSTemplateDetails : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
            log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string testSMSModal = "testSMSModal";
    string testSMSModalError = "testSMSModalError";
    string selectTemplateModal = "selectTemplateModal";
    string selectTemplateModalError = "selectTemplateModalError";
    DropdownBO drpBO = new DropdownBO();
    MarketingCampaignBO marketingCampaignBO = new MarketingCampaignBO();
    DocumentBO documentBO = new DocumentBO();
    EmailAndSMSProviderBO emailSmsProviderBO = new EmailAndSMSProviderBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                SMSTemplateNavDTO navDto = ApplicationUtil.getPageNavDTO<SMSTemplateNavDTO>(Session);
                bool isSysAdmin = CommonUtil.IsSystemAdminRole(getUserDefinitionDTO());
                if (!isSysAdmin)
                {
                    if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.SMS_TEMPLATE_ADD, Constants.Entitlement.SMS_TEMPLATE_MODIFY)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                    if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) == null) Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
                }
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    protected void Page_PreInit(object sender, EventArgs e)
    {
        if (CommonUtil.IsSystemAdminRole(getUserDefinitionDTO()))
        {
            this.MasterPageFile = "~/CSAdminMaster.master";
        }
    }
    private void setNotyMsgInMaster(string msg)
    {
        if (CommonUtil.IsSystemAdminRole(getUserDefinitionDTO())) (this.Master as CSAdminMaster).setNotyMsg(msg);
        else (this.Master as CSMaster).setNotyMsg(msg);
    }
    /**
    * This method is called just before the page is rendered. So any change in state of the element is applied.
    **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                setNotyMsgInMaster(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
        setPageTitle();
    }
    public void initBootstrapComponantsFromServer()
    {
    	ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpSMSProvider, DrpDataType.SMS_PROVIDER, null, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
    }
    public void setErrorMessage(string message, string group)
    {
    	string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            setNotyMsgInMaster(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
	        CustomValidator val = new CustomValidator();
	        val.IsValid = false;
	        val.ErrorMessage = message;
	        val.ValidationGroup = group;
	        this.Page.Validators.Add(val);
        }
    }
    private void doInit(SMSTemplateNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(SMSTemplateNavDTO navDto)
    {
        try
        {
            SMSTemplatePageDTO PageDTO = new SMSTemplatePageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            pageModeHdn.Value = navDto.Mode.ToString();
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            loadSMSTemplate(navDto.TemplateId);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageFieldsWithEntitlement()
    {
        initFormFields();
    }
    private void setPageTitle()
    {
        if (isAddMode()) lbPageTitle.Text = Constants.ICON.ADD + Resources.Labels.ADD_SMS_TEMPLATE;
        else if (isModifyMode()) lbPageTitle.Text = Constants.ICON.MODIFY + Resources.Labels.MODIFY_SMS_TEMPLATE;
        else if (isViewMode()) lbPageTitle.Text = Constants.ICON.VIEW_DTL + Resources.Labels.EMAIL_TEMPLATE_DETAILS;
    }
    private void initFormFields()
    {
        bool viewMode = isViewMode();
        EmailSmsStoreDTO templateDTO = getSMSTemplate();
        bool IsSysAdmin = CommonUtil.IsSystemAdminRole(getUserDefinitionDTO());
        
        //Toolbar
        btnTestSMS.Visible = !viewMode;
        btnPublish.Visible = !viewMode;
        btnSave.Visible = !viewMode;
        btnCancel.Visible = !viewMode;
        btnUnpublish.Visible = viewMode;
        divSMSToolbar.Visible = IsSysAdmin || templateDTO.SystemDefined == SystemDefined.No;
        //Template name
        txtSMSTemplateName.ReadOnly = !isAddMode();
        lnkLoadTemplate.Visible = !viewMode;
        txtSMSContent.ReadOnly = viewMode;
    }
    private bool isModifyMode()
    {
        return PageMode.MODIFY.ToString().Equals(pageModeHdn.Value);
    }
    private bool isViewMode()
    {
        return PageMode.VIEW.ToString().Equals(pageModeHdn.Value);
    }
    private bool isAddMode()
    {
        return PageMode.ADD.ToString().Equals(pageModeHdn.Value);
    }
    private void navigateToPreviousPage()
    {
        SMSTemplatePageDTO PageDTO = getSessionPageData();
        bool IsSysAdmin = CommonUtil.IsSystemAdminRole(getUserDefinitionDTO());
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is EmailSMSTemplateStoreNavDTO)
            {
                EmailSMSTemplateStoreNavDTO navDTO = (EmailSMSTemplateStoreNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(IsSysAdmin ? Constants.URL.ADMIN_EMAIL_SMS_TEMPLATE_STORE : Constants.URL.EMAIL_SMS_TEMPLATE_STORE, true);
            }
        }
        Response.Redirect(IsSysAdmin ? Constants.URL.ADMIN_EMAIL_SMS_TEMPLATE_STORE : Constants.URL.EMAIL_SMS_TEMPLATE_STORE, true);
    }
    private SMSTemplatePageDTO getSessionPageData()
    {
        return (SMSTemplatePageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private EmailSmsStoreDTO getSMSTemplate()
    {
        return getSessionPageData().SMSTemplate;
    }
    private void loadSMSTemplate(long TemplateId)
    {
    	EmailSmsStoreDTO tmpDTO = null;
    	if(isAddMode()) tmpDTO = createEmailSmsStoreDTO();
    	else tmpDTO = marketingCampaignBO.fetchEmailSmsTemplate(TemplateId);
    	getSessionPageData().SMSTemplate = tmpDTO;
    	
    	populateUIFromTemplateDTO(tmpDTO);
    }
    private void populateUIFromTemplateDTO(EmailSmsStoreDTO tmpDTO) {
    	txtSMSTemplateName.Text = tmpDTO.Name;
    	txtSMSContent.Text = tmpDTO.SmsContent;
    }
    private EmailSmsStoreDTO createEmailSmsStoreDTO() {
    	UserDefinitionDTO userDefDto = getUserDefinitionDTO();
    	EmailSmsStoreDTO tmpDTO = new EmailSmsStoreDTO();
    	tmpDTO.RecordType = EmailSmsType.SMS;
        tmpDTO.SystemDefined = (CommonUtil.IsSystemAdminRole(userDefDto)) ? SystemDefined.Yes : SystemDefined.No;
    	tmpDTO.CreatedBy = CommonUIConverter.getFirmMemberDTO(userDefDto.FirmMember.Id.ToString(), null);
    	tmpDTO.CreateDate = DateUtil.getUserLocalDate();
    	tmpDTO.Status = EmailSmsStoreStatus.Draft;
    	tmpDTO.Attachments = new List<EmailSmsStoreAttachmentDTO>();
        
        tmpDTO.FirmNumber = userDefDto.FirmNumber;
        tmpDTO.InsertUser = userDefDto.Username;
        tmpDTO.UpdateUser = userDefDto.Username;
    	
    	return tmpDTO;
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void populateEmailSmsStoreDTOFromUI(EmailSmsStoreDTO templateDTO, bool isPublish)
    {
    	UserDefinitionDTO userDefDto = getUserDefinitionDTO();
    	if(isAddMode()) {
    		templateDTO.Name = txtSMSTemplateName.Text.TrimNullable();
    	}
        templateDTO.SmsContent = txtSMSContent.Text;
        templateDTO.UpdatedBy = CommonUIConverter.getFirmMemberDTO(userDefDto.FirmMember.Id.ToString(), null);
        templateDTO.LastUpdateDate = DateUtil.getUserLocalDate();
        if (isPublish) templateDTO.Status = EmailSmsStoreStatus.Published;

    	templateDTO.UpdateUser = userDefDto.Username;
    }
    private void doSaveOrPublish(bool isPublish)
    {
        if (validateSMSDetailsOnSave(isPublish))
        {
            EmailSmsStoreDTO tmpDTO = getSMSTemplate();
            populateEmailSmsStoreDTOFromUI(tmpDTO, isPublish);

            long Id = marketingCampaignBO.addOrModifyEmailSmsStoreTemplate(tmpDTO);
            string msg = (isPublish) ? "SMS Template is published successfully." : "SMS Template is saved successfully.";
            Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg(msg));
            navigateToCurrentPage(isPublish, Id);
        }
    }
    private void navigateToCurrentPage(bool isPublish, long Id)
    {
        SMSTemplateNavDTO navDTO = new SMSTemplateNavDTO();
        navDTO.Mode = (isPublish) ? PageMode.VIEW : PageMode.MODIFY;
        navDTO.TemplateId = Id;
        navDTO.PrevNavDto = getSessionPageData().PrevNavDTO;
        Session[Constants.Session.NAV_DTO] = navDTO;
        Response.Redirect(CommonUtil.IsSystemAdminRole(getUserDefinitionDTO()) ? Constants.URL.ADMIN_SMS_TEMPLATE_DETAILS : Constants.URL.SMS_TEMPLATE_DETAILS, true);
    }
    protected void onClickPublishSMSTemplate(object sender, EventArgs e)
    {
        try
        {
            doSaveOrPublish(true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickUnPublishSMSTemplate(object sender, EventArgs e)
    {
        try
        {
            EmailSmsStoreDTO tmpDTO = getSMSTemplate();
            marketingCampaignBO.unPublishEmailSmsStoreTemplate(tmpDTO.Id, getUserDefinitionDTO());
            navigateToCurrentPage(false, tmpDTO.Id);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickSaveSMSChanges(object sender, EventArgs e)
    {
        try
        {
            doSaveOrPublish(false);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickCancelChanges(object sender, EventArgs e)
    {
        try
        {
        	navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateSMSDetailsOnSave(bool isPublish) {
    	bool isValid = true;
    	
    	EmailSmsStoreDTO templateDTO = getSMSTemplate();
    	if(string.IsNullOrWhiteSpace(txtSMSTemplateName.Text.TrimNullable())) {
			setNotyMsgInMaster(CommonUtil.getNotyErrorMsg("Please enter Template Name."));
			isValid = false;
		}
        if (isPublish)
        {
            if (string.IsNullOrWhiteSpace(txtSMSContent.Text.TrimNullable()))
            {
                setNotyMsgInMaster(CommonUtil.getNotyErrorMsg("Please enter SMS content."));
                isValid = false;
            }
        }
        return isValid;
    }
    //Test SMS logic - start
    protected void onClickTestSMS(object sender, EventArgs e)
    {
        try
        {
        	txtTestSMSMobileNo.Text = "";
            activeModalHdn.Value = testSMSModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void sendTestSMS(object sender, EventArgs e)
    {
        try
        {
            if (validateTestSMSModal())
            {
                EmailSmsStoreDTO templateDTO = getSMSTemplate();
                SmsConfigDTO configDTO = emailSmsProviderBO.fetchSmsProvider(long.Parse(drpSMSProvider.Text));

                SmsDTO smsDTO = new SmsDTO();
                smsDTO.UserId = configDTO.UserId;
                smsDTO.Password = configDTO.Password;
                smsDTO.URL = configDTO.Url;
                smsDTO.SenderId = configDTO.SenderId;
                smsDTO.Content = txtSMSContent.Text.TrimNullable();
                smsDTO.RecipientList = new List<string>();
                smsDTO.RecipientList.Add(txtTestSMSMobileNo.Text.TrimNullable());

                EmailSMSUtil.SendSMS(smsDTO);
                setNotyMsgInMaster(CommonUtil.getNotySuccessMsg(string.Format("SMS is sent to {0}", txtTestSMSMobileNo.Text.TrimNullable())));
            }
            else
            {
                activeModalHdn.Value = testSMSModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelTestSMSModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateTestSMSModal() {
    	Page.Validate(testSMSModalError);
    	bool isValid = Page.IsValid;
    	if(isValid) {
    		isValid = validateSMSDetailsOnSave(true);
    	}
    	return isValid;
    }
    //Test SMS Selection logic - end
    //Template Selection logic - start
    protected void onClickLoadTemplate(object sender, EventArgs e)
    {
    	try
    	{
    		drpBO.drpDataBase(drpTemplate, DrpDataType.SMS_STORE_TEMPLATE, null, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
    		activeModalHdn.Value = selectTemplateModal;
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    protected void LoadTemplate(object sender, EventArgs e)
    {
    	try
    	{
    		Page.Validate(selectTemplateModalError);
    		bool isValid = Page.IsValid;
    		if (isValid)
    		{
    			long TemplateId = long.Parse(drpTemplate.Text);
    			EmailSmsStoreDTO templateDTO = marketingCampaignBO.fetchEmailSmsTemplate(TemplateId);
    			
				txtSMSContent.Text = templateDTO.SmsContent;
    		}
    		else
    		{
    			activeModalHdn.Value = selectTemplateModal;
    		}
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    protected void cancelTemplateModal(object sender, EventArgs e)
    {
    	try
    	{
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    //Template Selection logic - end
}