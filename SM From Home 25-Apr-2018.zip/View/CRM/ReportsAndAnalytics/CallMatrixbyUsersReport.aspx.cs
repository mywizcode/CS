﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft.Logic.BO;
using CrystalDecisions.CrystalReports.Engine;

namespace ConstroSoft.View.CRM.ReportsAndAnalytics
{
    public partial class CallMatrixbyUsersReport : System.Web.UI.Page
    {

        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string commonError = "commonError";
        ReportConfigBO reportConfigBO = new ReportConfigBO();
        LeadEnquiryReportBO leadEnquiryReportBO = new LeadEnquiryReportBO();
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                if (ApplicationUtil.isSessionActive(Session))
                {
                    LeadEnquiryReportNavDTO navDto = ApplicationUtil.getPageNavDTO<LeadEnquiryReportNavDTO>(Session);
                    if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.LEAD_ENQUIRY_ANALYTICS_REPORT)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                    if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, true);
                }
            }
        }
        protected void Page_PreRender(object sender, EventArgs e)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                if (ApplicationUtil.isSubPageRendered(Page))
                {
                    (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                    preRenderInitFormElements();
                }
                if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        private void preRenderInitFormElements()
        {
            renderPageLayout();
        }
        public void initBootstrapComponantsFromServer()
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
        }
        private UserDefinitionDTO getUserDefinitionDTO()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }
        private void initDropdowns()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }

        public void setErrorMessage(string message, string group)
        {
            string[] pageErrorGrp = { commonError };
            if (pageErrorGrp.Contains(group))
            {
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            else
            {
                CustomValidator val = new CustomValidator();
                val.IsValid = false;
                val.ErrorMessage = message;
                val.ValidationGroup = group;
                this.Page.Validators.Add(val);
            }
        }
        private void doInit(LeadEnquiryReportNavDTO navDto)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        private void initPageAfterRedirect(LeadEnquiryReportNavDTO navDto)
        {
            try
            {
                LeadEnquiryReportNavDTO leadEnquiryReportNavDTO = new LeadEnquiryReportNavDTO();
                Session[Constants.Session.PAGE_DATA] = leadEnquiryReportNavDTO;
                if (navDto != null) leadEnquiryReportNavDTO.PrevNavDto = navDto.PrevNavDto;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                throw exp;
            }
        }
        private void renderPageLayout()
        {
            setPageTitle();
        }
        private void setPageTitle()
        {

        }
        private CallMatrixbyUsersReportPageDTO getSessionPageData()
        {
            return (CallMatrixbyUsersReportPageDTO)Session[Constants.Session.PAGE_DATA];
        }
        private bool validateMandatoryFields()
        {
            Page.Validate(commonError);
            bool isValid = Page.IsValid;
            if (!isValid)
            {
                (this.Master as CSMaster).setPageErrorInNotyMsg(Page.Validators);
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;

        }
        public void onClickGenerateReport(object sender, EventArgs e)
        {
            try
            {
                if (validateMandatoryFields())
                {
                    UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
                    ReportTemplateMasterDTO reportConfigDTO = null;
                    long propertyId = 0;
                    propertyId = CommonUtil.getCurrentPropertyDTO(userDefDto).Id;
                    ReportDocument letterReportDocument = new ReportDocument();
                    DataTable leadDataTable = populateCallMatixDataTable();
                    object[] enquiryDataTables = populateHeaderTable();
                    reportConfigDTO = reportConfigBO.fetchPropertyReportTemplate(propertyId, ReportTemplateType.ENQ_LEAD_REPORT.GetDescription());
                    string reportPath = Server.MapPath(reportConfigDTO.Path);
                    letterReportDocument.Load(reportPath);
                    letterReportDocument.Database.Tables["EnquiryReport"].SetDataSource((DataTable)enquiryDataTables[0]);
                    letterReportDocument.Database.Tables["LeadReport"].SetDataSource(leadDataTable);
                    letterReportDocument.Database.Tables["EnquirySource"].SetDataSource((DataTable)enquiryDataTables[1]);
                    try
                    {
                        letterReportDocument.ExportToHttpResponse
                        (CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, true, "Lead Enquiry Statistic Report");
                    }
                    catch (Exception exp)
                    {

                    }
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, commonError);
            }
        }
        private DataTable populateCallMatixDataTable()
        {
            DataTable callDataTable = new DataTable();
            callDataTable.Columns.Add("UserName", typeof(String));
            callDataTable.Columns.Add("TotalofOutgoingCalls", typeof(Int32));
            callDataTable.Columns.Add("TotalofIncomingCalls", typeof(Int32));
            callDataTable.Columns.Add("TotalofCalls", typeof(Int32));
            

            PropertyDTO propertyDTO = CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO());
            object[] leadStats = leadEnquiryReportBO.fetchLeadStatsForReport(propertyDTO.Id, Convert.ToDateTime(txtFromDate.Text), Convert.ToDateTime(txtToDate.Text));
            LeadsOpenedGadgetDTO leadsOpenedGadgetDTO = (LeadsOpenedGadgetDTO)leadStats[0];
            LeadsProcessedCountDTO leadsProcessedDto = (LeadsProcessedCountDTO)leadStats[2];

            DataRow leadRow = callDataTable.NewRow();
            leadRow["UserName"] = leadsOpenedGadgetDTO.TotalCount;
            leadRow["TotalofOutgoingCalls"] = leadsOpenedGadgetDTO.AverageOpened;
            leadRow["TotalofIncomingCalls"] = leadsProcessedDto.TotalLost;
            leadRow["TotalofCalls"] = leadsProcessedDto.TotalConverted;            
            callDataTable.Rows.Add(leadRow);
            return callDataTable;
        }

        private object[] populateHeaderTable()
        {
            object[] result = new Object[2];
            //Populate Enquiry Data
            DataTable enquiryDataTable = new DataTable();
            enquiryDataTable.Columns.Add("PropertyName", typeof(Int32));
            enquiryDataTable.Columns.Add("StartDate", typeof(DateTime));
            enquiryDataTable.Columns.Add("EndDate", typeof(DateTime));            

            PropertyDTO propertyDTO = CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO());
            object[] enquiryStats = leadEnquiryReportBO.fetchEnquiryStatsForReport(propertyDTO.Id, Convert.ToDateTime(txtFromDate.Text), Convert.ToDateTime(txtToDate.Text));
            EnquiryCountStatsDTO enqCountStatsDTO = (EnquiryCountStatsDTO)enquiryStats[3];

            DataRow enquiryRow = enquiryDataTable.NewRow();            
            enquiryRow["PropertyName"] = propertyDTO.Name;
            enquiryRow["FromDate"] = Convert.ToDateTime(txtFromDate.Text);
            enquiryRow["ToDate"] = Convert.ToDateTime(txtToDate.Text);
            enquiryDataTable.Rows.Add(enquiryRow);            
            return result;
        }
    }
}
