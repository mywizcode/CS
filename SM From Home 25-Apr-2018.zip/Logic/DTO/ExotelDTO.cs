﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ConstroSoft;

/// <summary>
/// Summary description for UserDefinitionDTO
/// </summary>
namespace ConstroSoft
{
    [Serializable]
    public class InOutBoundCallResDTO
    {
        public Call Call { get; set; }       
    }
    [Serializable]
    public class Call
    {
        public long Id { get; set; }
        //An alpha-numeric unique identifier of the call
        public string Sid { get; set; }
        public string CallSid { get; set; }
        //Link to the call recording
        public string RecordingUrl { get; set; }
        //Time in format YYYY-MM-DD HH:mm:ss; Date and time at which the status of the call was last updated in our system
        public System.DateTime? DateUpdated { get; set; }
        /*
       * When the call completes, an HTTP POST will be made to the URL mentioned with the following parameters:
       * queued - The call is ready and waiting in line before going out
       * in-progress - The call was answered and is currently in progress
       * completed - The call was answered and has ended normally
       * failed - The call could not be completed as dialled, most likely because the phone number was non-existent
       * busy - The caller received a busy signal no-answer - The call ended without being answered
       */
        public string Status { get; set; }
        //
        public string ParentCallSid { get; set; }
        //Time in format YYYY-MM-DD HH:mm:ss; Date and time at which the user initiated the API
        public System.DateTime? DateCreated { get; set; }
        //Time in format YYYY-MM-DD HH:mm:ss; Date and time at which the status of the call was last updated in our system
       // public System.DateTime? DateUpdated { get; set; }
        //Exotel account SID
        public string AccountSid { get; set; }
        //Customer's phone number
        public string To { get; set; }
        //User Phone Number, The phone number that will be called first
        public string From { get; set; }
        //This is your ExoPhone/Exotel Virtual Number
        public string PhoneNumberSid { get; set; }
       
        //Time in format YYYY-MM-DD HH:mm:ss; Date and time when the call request was initiated to the operator
        public System.DateTime? StartTime { get; set; }
        //Time in format YYYY-MM-DD HH:mm:ss; Date and time when the call was completed
        public System.DateTime? EndTime { get; set; }
        //Current server time (format : yyyy-mm-dd hh:mm:ss)
        public System.DateTime? CurrentTime { get; set; }
        //Call duration in seconds
        public long? Duration { get; set; }
        //Double; If present, this will be the amount (in INR or USD) you have been charged for the call
        public decimal? Price { get; set; }
        /**
        * inbound - Incoming call
        * outbound-dial - Outbound calls from Exotel dashboard
        * outbound-api - All other Outbound calls (API, campaign etc.)
        */
        public string Direction { get; set; }
        //The duration of the call (when the call was connected to an agent)
        public string DialCallDuration { get; set; } 
        //human
        public string AnsweredBy { get; set; }
        public string ForwardedFrom { get; set; }
        public string CallerName { get; set; }
        //Uri is the path of the CallSid
        public string Uri { get; set; }
        
        public byte[] RecordingFile{ get; set; }
        /**
        * When the call completes, an HTTP POST will be made to the URL mentioned with the following four parameters:
        * IVR only, no connect applet - call-attempt
        * Call conversation happened - completed
        * Client hung up during connect applet - client-hangup
        * Connect applet, no agent picked up - incomplete
        * Went to voicemail applet - voicemail
        */
        public string CallType { get; set; }
        /*
        * If there was a 'Gather' applet before this pass-through applet, the numbers that were gathered. 
        * NOTE: This parameter comes with a double quote (") before and after the number. 
        * You'll have to trim() this parameter for double quotes (") to get the actual digits.
        */
        public string digits { get; set; }
        //If the call was initiated via API , the value that was passed in CustomField in the API call.
        public string CustomField { get; set; }
        //Shows the number of the agent who was dialed to last.
        public string DialWhomNumber { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
   }
    [Serializable]
    public class ExotelExceptionDTO
    {
        public RestException RestException { get; set; }
    }
    [Serializable]
    public class RestException
    {
        public int Status { get; set; }
        public string Message { get; set; }
    }
}    
