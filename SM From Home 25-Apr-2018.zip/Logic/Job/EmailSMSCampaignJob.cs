﻿using ConstroSoft.Logic.CachingProvider;
using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Caching;

namespace ConstroSoft.Logic.Job
{
    public class EmailSMSCampaignJob : IJob
    {
        private static readonly log4net.ILog log =
                log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public void Execute(IJobExecutionContext context)
        {
            MarketingCampaignBO campaignBO = new MarketingCampaignBO();
            bool isSuccess = true;
            bool isStarted = false;
            string message = "";
            long CampaignId = 0;
            string jobName = context.JobDetail.Key.Name;
            try{
                log.Info("Email and SMS Campaign job Started. Job Name:" + jobName);
                JobDataMap dataMap = context.JobDetail.JobDataMap;
                CampaignId = dataMap.GetLong(Constants.JOBS.PARAM_CAMPAIGN_ID);
                EmailSmsCampaignDTO tmpCampaignDTO = campaignBO.fetchEmailSMSCampaignSelective(CampaignId);
                if (isValidExecution(tmpCampaignDTO, jobName))
                {
                	isStarted = true;
                	//Update Campaign Status as Inprogress
                	campaignBO.updateCampaignStatus(CampaignId, EmailSmsCampaignStatus.Inprogress, "");
                    //Fetch Campaign and Customers Details in recipients
                    object[] result = campaignBO.fetchDataForEmailSMSCampaignJob(CampaignId);
                    EmailSmsCampaignDTO campaignDTO = (EmailSmsCampaignDTO)result[0];
                    IList<VwCustomer> customerList = (IList<VwCustomer>)result[1];
                    
                    if(customerList != null && customerList.Count > 0) {
            			if(campaignDTO.RecordType == EmailSmsType.Email) {
            				List<string> SentEmailList = new List<string>();
            				EmailDTO emailDTO = EmailSMSUtil.populateEmailDTO(campaignDTO.EmailConfig);
                    		emailDTO.Subject = campaignDTO.Subject;
                            emailDTO.Attachments = new List<AttachmentDTO>();
                    		if(campaignDTO.Attachments != null) {
                    			foreach(EmailSmsCampaignAttachmentDTO tmpDTO in campaignDTO.Attachments) {
                    				emailDTO.Attachments.Add(new AttachmentDTO(tmpDTO.FileName, tmpDTO.Content));
                    			}
                    		}
                    		emailDTO.RecipientList = new List<string>();
                            foreach(VwCustomer tmpCustomer in customerList) {
                            	emailDTO.RecipientList.Clear();
                            	if(!string.IsNullOrWhiteSpace(tmpCustomer.Email) && !SentEmailList.Contains(tmpCustomer.Email)) 
                                    emailDTO.RecipientList.Add(tmpCustomer.Email);
                            	if(!string.IsNullOrWhiteSpace(tmpCustomer.AltEmail) && !SentEmailList.Contains(tmpCustomer.AltEmail)) 
                                    emailDTO.RecipientList.Add(tmpCustomer.AltEmail);
                            	if(emailDTO.RecipientList.Count > 0) {
                            		emailDTO.EmailContent = EmailSMSUtil.ReplacePlaceholders(StringUtil.getBytesAsEmailContentString(campaignDTO.EmailContent), tmpCustomer);
                            		EmailSMSUtil.SendEmail(emailDTO);
                            		SentEmailList.AddRange(emailDTO.RecipientList);
                            	}
                            }
                            message = "Campaign is completed successfully. Total Recipients: "+ SentEmailList.Count;
            			} else {
                            List<string> SentSMSList = new List<string>();
                            SmsDTO smsDTO = new SmsDTO();
                            smsDTO.UserId = campaignDTO.SmsConfig.UserId;
                            smsDTO.Password = campaignDTO.SmsConfig.Password;
                            smsDTO.URL = campaignDTO.SmsConfig.Url;
                            smsDTO.SenderId = campaignDTO.SmsConfig.SenderId;
                            smsDTO.RecipientList = new List<string>();
                            foreach (VwCustomer tmpCustomer in customerList)
                            {
                                smsDTO.RecipientList.Clear();
                                if (!string.IsNullOrWhiteSpace(tmpCustomer.Contact) && !SentSMSList.Contains(tmpCustomer.Contact))
                                    smsDTO.RecipientList.Add(tmpCustomer.Contact);
                                if (!string.IsNullOrWhiteSpace(tmpCustomer.AltContact) && !SentSMSList.Contains(tmpCustomer.AltContact))
                                    smsDTO.RecipientList.Add(tmpCustomer.AltContact);
                                if (smsDTO.RecipientList.Count > 0)
                                {
                                    smsDTO.Content = campaignDTO.SmsContent;
                                    EmailSMSUtil.SendSMS(smsDTO);
                                    SentSMSList.AddRange(smsDTO.RecipientList);
                                }
                            }
                            message = "Campaign is completed successfully. Total Recipients: " + SentSMSList.Count;
            			}
            		} else {
            			message = "No recipients are qualified for campaign.";
            		}
                }                
            }catch (Exception exp)
            {
            	isSuccess = false;
                message = Resources.Messages.system_error;
                log.Error(exp.Message, exp);
                //Send exception email to system administrator.
                SysExpEmailAddDetailsDTO tmpDTO = new SysExpEmailAddDetailsDTO();
                tmpDTO.CampaignId = CampaignId;
                EmailSMSUtil.SendSystemErrorEmail("Email and SMS Campaign Job", exp, null, tmpDTO);
            } finally {
            	if(isStarted) {
            		try{
            			campaignBO.updateCampaignStatus(CampaignId, (isSuccess) ? EmailSmsCampaignStatus.Success : EmailSmsCampaignStatus.Failed, message);
    	            } catch (Exception exp)
    	            {
    	            	log.Error("Email and SMS Campaign Job - Exception while updating execution status. Job Name:" + jobName, exp);
    	            	//Send exception email to system administrator.
    	                SysExpEmailAddDetailsDTO tmpDTO = new SysExpEmailAddDetailsDTO();
    	                tmpDTO.CampaignId = CampaignId;
    	                EmailSMSUtil.SendSystemErrorEmail("Email and SMS Campaign Job", exp, null, tmpDTO);
    	            }
            	}
                log.Info("Email and SMS Campaign job Completed. Job Name:" + jobName);
            }
        }
        private bool isValidExecution(EmailSmsCampaignDTO tmpCampaignDTO, string jobName)
        {
            if (!(tmpCampaignDTO.Stage == EmailSmsCampaignStage.Scheduled && tmpCampaignDTO.Status == EmailSmsCampaignStatus.NotStarted))
            {
                log.Error(string.Format("Email and SMS Campaign job: Invalid campaign Stage/Status. Current Job Name:{0}, Campaign Name:{1}, Stage:{2}, Status:{3}",
                        jobName, tmpCampaignDTO.Name, tmpCampaignDTO.Stage.ToString(), tmpCampaignDTO.Status.ToString()));
                return false;
            }
            DateTime ScheduledDate = tmpCampaignDTO.ScheduledDate.Value;
            DateTime currentDate = DateUtil.getUserLocalDateTime();
            int diffMinutes = (currentDate - ScheduledDate).Minutes;
            if (diffMinutes < 0) diffMinutes = diffMinutes * -1;
            if (diffMinutes > 10)
            {
                log.Error(string.Format("Email and SMS Campaign job: Invalid Trigger. Current Job Name:{0}, Campaign Name:{1}, Scheduled Date:{2}, Current Date:{3}",
                        jobName, tmpCampaignDTO.Name, DateUtil.getFormattedDate(tmpCampaignDTO.ScheduledDate.Value, Constants.DATETIME_FORMAT_LONG),
                        DateUtil.getFormattedDate(currentDate, Constants.DATETIME_FORMAT_LONG)));
                return false;
            }
            return true;
        }
    }
}