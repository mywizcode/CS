﻿using ConstroSoft.Logic.CachingProvider;
using ConstroSoft.TelephonyProvider.ExotelProvider;
using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Caching;

namespace ConstroSoft.Logic.Job
{
    public class SubscriptionPlanJob : IJob
    {
        private static readonly log4net.ILog log =
                log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        
        public void Execute(IJobExecutionContext context)
        {
        	JobBO jobBO = new JobBO();
            LoginBO loginBO = new LoginBO();
            CallHistoryBO callHistoryBO = new CallHistoryBO();
            ExotelClient exotelClient = new ExotelClient();
            
            string message = "Job execution is completed successfully.";
            var schedulerContext = context.Scheduler.Context;
            JobDTO tmpJobDTO = (JobDTO)schedulerContext.Get(SystemJobs.SUBSCRIPTION_PLAN_JOB.ToString());
            DateTime StartTime = DateUtil.getUserLocalDateTime();
            FirmBO firmBO = new FirmBO();
            bool isError = false;
            bool isJobStarted = false;
            try{
                JobDTO jobDTO = jobBO.fetchJobDetails(tmpJobDTO.Id);
                if (jobDTO.JobExecutionStatus != JobExecutionStatus.Inprogress && jobDTO.JobStatus == JobStatus.Active)
                {
                    jobBO.updateJobExecutionStatus(jobDTO.Id, StartTime, "", JobExecutionStatus.Inprogress);
                    isJobStarted = true;
                    UserDefinitionDTO sysUserDTO = loginBO.fetchSystemUser(Constants.SYSDEFAULT.SYSADMIN_USER);
            		//Fetch Current Active subscription Plan
                    IList<FirmDTO> firmList = firmBO.fetchAllFirmsSelective();
                    if(firmList != null && firmList.Count > 0) {
                    	foreach(FirmDTO tmpFirmDTO in firmList) {
                    		long SendPlanExpiryOrReminderEmail = 0;
                    		long SendPlanActivationEmail = 0;
                    		//Activate/Deactivate plan as per the current dates
                    		SubscriptionPlanDTO planDTO = firmBO.fetchActiveSubscriptionPlan(tmpFirmDTO.FirmNumber, true);
                    		bool isNoPlanActive = (planDTO == null);
                    		if (planDTO != null) {
                    			int NoOfDaysExpiry = DateUtil.getDateDiffInDays(DateUtil.getUserLocalDate(), planDTO.EndDate, 2);
                    			if(NoOfDaysExpiry <= 0) {
                    				firmBO.MarkSubscriptionPlanAsConsumed(planDTO.Id, sysUserDTO);
                    				isNoPlanActive = true;
                    				SendPlanExpiryOrReminderEmail = planDTO.Id;
                    			} else if(NoOfDaysExpiry < 10) {
                    				SendPlanExpiryOrReminderEmail = planDTO.Id;
                    			}
                    		}
                    		if (isNoPlanActive) {
                    			SendPlanActivationEmail = firmBO.ActivateUpcomingSubscriptionPlan(tmpFirmDTO.FirmNumber, sysUserDTO);
                    		}
                    		//Send Email to Customer and System administrator
                    		if(SendPlanExpiryOrReminderEmail > 0) {
                    			SubscriptionPlanDTO emailPlanDTO = firmBO.fetchSubscriptionPlanDetails(SendPlanExpiryOrReminderEmail, true);
                    			
                    			EmailDTO emailDTO = new EmailDTO();
                    			emailDTO.PlaceHolderDict = EmailSMSUtil.populateEmailPlaceHolderDTO(emailPlanDTO, tmpFirmDTO);
                    			emailDTO.RecipientList = new List<string>();
                	            if (!string.IsNullOrWhiteSpace(tmpFirmDTO.ContactInfo.Email)) emailDTO.RecipientList.Add(tmpFirmDTO.ContactInfo.Email);
                	            if (!string.IsNullOrWhiteSpace(tmpFirmDTO.ContactInfo.AltEmail)) emailDTO.RecipientList.Add(tmpFirmDTO.ContactInfo.AltEmail);
                	            EmailSMSUtil.SendSystemEmail((emailPlanDTO.Status == SubscriptionPlanStatus.Consumed) ? Constants.SYSDEFAULT_EMAIL_SMS_TEMPLATE.SUBPLAN_DEACTIVATION_CUST_EMAIL
                	            		: Constants.SYSDEFAULT_EMAIL_SMS_TEMPLATE.SUBPLAN_EXPIRY_CUST_REMINDER, emailDTO);
                    			
                	            emailDTO.RecipientList.Clear();
                                if (!string.IsNullOrWhiteSpace(sysUserDTO.FirmMember.ContactInfo.Email)) emailDTO.RecipientList.Add(sysUserDTO.FirmMember.ContactInfo.Email);
                                if (!string.IsNullOrWhiteSpace(sysUserDTO.FirmMember.ContactInfo.AltEmail)) emailDTO.RecipientList.Add(sysUserDTO.FirmMember.ContactInfo.AltEmail);
                	            EmailSMSUtil.SendSystemEmail((emailPlanDTO.Status == SubscriptionPlanStatus.Consumed) ? Constants.SYSDEFAULT_EMAIL_SMS_TEMPLATE.SUBPLAN_DEACTIVATION_SYSADMIN_EMAIL
                	            		: Constants.SYSDEFAULT_EMAIL_SMS_TEMPLATE.SUBPLAN_EXPIRY_SYSADMIN_REMINDER, emailDTO);
                            }
                    		if(SendPlanActivationEmail > 0) {
                    			SubscriptionPlanDTO emailPlanDTO = firmBO.fetchSubscriptionPlanDetails(SendPlanActivationEmail, true);
                    			
                    			EmailDTO emailDTO = new EmailDTO();
                    			emailDTO.PlaceHolderDict = EmailSMSUtil.populateEmailPlaceHolderDTO(emailPlanDTO, tmpFirmDTO);
                    			emailDTO.RecipientList = new List<string>();
                	            if (!string.IsNullOrWhiteSpace(tmpFirmDTO.ContactInfo.Email)) emailDTO.RecipientList.Add(tmpFirmDTO.ContactInfo.Email);
                	            if (!string.IsNullOrWhiteSpace(tmpFirmDTO.ContactInfo.AltEmail)) emailDTO.RecipientList.Add(tmpFirmDTO.ContactInfo.AltEmail);
                	            EmailSMSUtil.SendSystemEmail(Constants.SYSDEFAULT_EMAIL_SMS_TEMPLATE.SUBPLAN_ACTIVATION_CUST_EMAIL, emailDTO);
                    			
                	            emailDTO.RecipientList.Clear();
                                if (!string.IsNullOrWhiteSpace(sysUserDTO.FirmMember.ContactInfo.Email)) emailDTO.RecipientList.Add(sysUserDTO.FirmMember.ContactInfo.Email);
                                if (!string.IsNullOrWhiteSpace(sysUserDTO.FirmMember.ContactInfo.AltEmail)) emailDTO.RecipientList.Add(sysUserDTO.FirmMember.ContactInfo.AltEmail);
                	            EmailSMSUtil.SendSystemEmail(Constants.SYSDEFAULT_EMAIL_SMS_TEMPLATE.SUBPLAN_ACTIVATION_SYSADMIN_EMAIL, emailDTO);
                            }
                    	}
                    }
            	} else {
                	message = "Job is already in progress.";
                }
            }catch (Exception exp)
            {
            	isError = true;
                message = exp.Message;
                log.Error("Exception in Subscription Plan job.", exp);
                //Send exception email to system administrator.
                EmailSMSUtil.SendSystemErrorEmail(SystemJobs.SUBSCRIPTION_PLAN_JOB.GetDescription(), exp, null, null);
            } finally {
	            try{
	            	JobExecutionStatus status = (isError) ? JobExecutionStatus.Failed : JobExecutionStatus.Completed;
	            	if(isError) {
	            		JobHistoryDTO jobHistoryDTO = CommonUtil.populateJobHistoryAddDTO(tmpJobDTO, message);
	            		jobBO.saveJobHistory(jobHistoryDTO);
	            	}
	            	if(isJobStarted) {
	            		jobBO.updateJobExecutionStatus(tmpJobDTO.Id, StartTime, message, status);
	            	}
	            } catch (Exception exp)
	            {
	            	log.Error("Subscription Plan - Exception while updating job execution status", exp);
	            	//Send exception email to system administrator.
	                EmailSMSUtil.SendSystemErrorEmail(SystemJobs.SUBSCRIPTION_PLAN_JOB.GetDescription(), exp, null, null);
	            }
            }
        }
    }
}