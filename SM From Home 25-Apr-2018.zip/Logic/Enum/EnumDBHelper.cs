﻿
/// <summary>
/// Summary description for MyENUM
/// </summary>

using System;
namespace ConstroSoft
{
    public class UserStatusStringType : NHibernate.Type.EnumStringType
    {
        public UserStatusStringType(): base(typeof(UserStatus), 1){}
        public override object GetValue(object enm)
        {
            if (null == enm)return String.Empty;
            switch ((UserStatus)enm)
            {
                case UserStatus.Active: return "A";
                case UserStatus.InActive: return "I";
                case UserStatus.Setup: return "S";
                case UserStatus.Suspended: return "X";
                default: throw new ArgumentException("Invalid UserStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("A".Equals(code)) return UserStatus.Active;
            else if ("I".Equals(code)) return UserStatus.InActive;
            else if ("S".Equals(code)) return UserStatus.Setup;
            else if ("X".Equals(code)) return UserStatus.Suspended;
            throw new ArgumentException("Cannot convert value '" + code + "' to UserStatus.");
        }
    }
    public class PreferredAddressStringType : NHibernate.Type.EnumStringType
    {
        public PreferredAddressStringType(): base(typeof(PreferredAddress), 1){}
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PreferredAddress)enm)
            {
                case PreferredAddress.Yes: return "Y";
                case PreferredAddress.No: return "N";
                default: return null;
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return PreferredAddress.Yes;
            else if ("N".Equals(code)) return PreferredAddress.No;
            return null;
        }
    }
    public class IsTempPasswordStringType : NHibernate.Type.EnumStringType
    {
	    public IsTempPasswordStringType(): base(typeof(IsTempPassword), 1){}
	    public override object GetValue(object enm)
	    {
	    	if (null == enm) return String.Empty;
	    	switch ((IsTempPassword)enm)
	    	{
	    		case IsTempPassword.Yes: return "Y";
	    		case IsTempPassword.No: return "N";
	    		default: return null;
	    	}
	    }
	    public override object GetInstance(object code)
	    {
	    	if ("Y".Equals(code)) return IsTempPassword.Yes;
	    	else if ("N".Equals(code)) return IsTempPassword.No;
	    	return null;
	    }
    }
    public class PrFMAccessStringType : NHibernate.Type.EnumStringType
    {
        public PrFMAccessStringType() : base(typeof(PrFMAccess), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PrFMAccess)enm)
            {
                case PrFMAccess.Yes: return "Y";
                case PrFMAccess.No: return "N";
                default: return null;
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return PrFMAccess.Yes;
            else if ("N".Equals(code)) return PrFMAccess.No;
            return null;
        }
    }
    public class CallProviderStringType : NHibernate.Type.EnumStringType
    {
    	public CallProviderStringType() : base(typeof(CallProvider), 1) { }
    	public override object GetValue(object enm)
    	{
    		if (null == enm) return String.Empty;
    		switch ((CallProvider)enm)
    		{
                case CallProvider.NONE: return "N";
    			case CallProvider.EXOTEL: return "E";
    			default: throw new ArgumentException("Invalid CallProvider.");
    		}
    	}
    	public override object GetInstance(object code)
    	{
            if ("N".Equals(code)) return CallProvider.NONE;
            else if ("E".Equals(code)) return CallProvider.EXOTEL;
    		return new ArgumentException("Cannot convert value '" + code + "' to CallProvider.");
    	}
    }
    public class EmailEnableSSLStringType : NHibernate.Type.EnumStringType
    {
        public EmailEnableSSLStringType() : base(typeof(EmailEnableSSL), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((EmailEnableSSL)enm)
            {
                case EmailEnableSSL.Yes: return "Y";
                case EmailEnableSSL.No: return "N";
                default: return null;
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return EmailEnableSSL.Yes;
            else if ("N".Equals(code)) return EmailEnableSSL.No;
            return null;
        }
    }
    public class IsEnabledStringType : NHibernate.Type.EnumStringType
    {
	    public IsEnabledStringType() : base(typeof(IsEnabled), 1) { }
	    public override object GetValue(object enm)
	    {
	    	if (null == enm) return String.Empty;
	    	switch ((IsEnabled)enm)
	    	{
	    		case IsEnabled.Yes: return "Y";
	    		case IsEnabled.No: return "N";
	    		default: return null;
	    	}
	    }
	    public override object GetInstance(object code)
	    {
	    	if ("Y".Equals(code)) return IsEnabled.Yes;
	    	else if ("N".Equals(code)) return IsEnabled.No;
	    	return null;
	    }
    }
    public class IsDefaultStringType : NHibernate.Type.EnumStringType
    {
        public IsDefaultStringType() : base(typeof(IsDefault), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((IsDefault)enm)
            {
                case IsDefault.Yes: return "Y";
                case IsDefault.No: return "N";
                default: return null;
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return IsDefault.Yes;
            else if ("N".Equals(code)) return IsDefault.No;
            return null;
        }
    }
    public class GenderStringType : NHibernate.Type.EnumStringType
    {
        public GenderStringType() : base(typeof(Gender), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((Gender)enm)
            {
                case Gender.Male: return "M";
                case Gender.Female: return "F";
                default: return null;
            }
        }
        public override object GetInstance(object code)
        {
            if ("M".Equals(code)) return Gender.Male;
            else if ("F".Equals(code)) return Gender.Female;
            return null;
        }
    }
    public class MaritalStatusStringType : NHibernate.Type.EnumStringType
    {
        public MaritalStatusStringType() : base(typeof(MaritalStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((MaritalStatus)enm)
            {
                case MaritalStatus.Single: return "S";
                case MaritalStatus.Married: return "M";
                default: return null;
            }
        }
        public override object GetInstance(object code)
        {
            if ("S".Equals(code)) return MaritalStatus.Single;
            else if ("M".Equals(code)) return MaritalStatus.Married;
            return null;
        }
    }
    public class SubscriptionPlanStatusStringType : NHibernate.Type.EnumStringType
    {
        public SubscriptionPlanStatusStringType() : base(typeof(SubscriptionPlanStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((SubscriptionPlanStatus)enm)
            {
                case SubscriptionPlanStatus.Active: return "A";
                case SubscriptionPlanStatus.Consumed: return "C";
                case SubscriptionPlanStatus.Upcoming: return "U";
                default: throw new ArgumentException("Invalid SubscriptionPlanStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("A".Equals(code)) return SubscriptionPlanStatus.Active;
            else if ("C".Equals(code)) return SubscriptionPlanStatus.Consumed;
            else if ("U".Equals(code)) return SubscriptionPlanStatus.Upcoming;
            throw new ArgumentException("Cannot convert value '" + code + "' to SubscriptionPlanStatus.");
        }
    }
    public class SubPlanPurchaseTypeStringType : NHibernate.Type.EnumStringType
    {
        public SubPlanPurchaseTypeStringType() : base(typeof(SubPlanPurchaseType), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((SubPlanPurchaseType)enm)
            {
                case SubPlanPurchaseType.New: return "N";
                case SubPlanPurchaseType.Renew: return "R";
                default: throw new ArgumentException("Invalid SubPlanPurchaseType.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("N".Equals(code)) return SubPlanPurchaseType.New;
            else if ("R".Equals(code)) return SubPlanPurchaseType.Renew;
            throw new ArgumentException("Cannot convert value '" + code + "' to SubPlanPurchaseType.");
        }
    }
    public class SystemDefinedStringType : NHibernate.Type.EnumStringType
    {
        public SystemDefinedStringType() : base(typeof(SystemDefined), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((SystemDefined)enm)
            {
                case SystemDefined.Yes: return "Y";
                case SystemDefined.No: return "N";
                default: return null;
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return SystemDefined.Yes;
            else if ("N".Equals(code)) return SystemDefined.No;
            return null;
        }
    }
    public class EnquiryStatusStringType : NHibernate.Type.EnumStringType
    {
        public EnquiryStatusStringType() : base(typeof(EnquiryStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((EnquiryStatus)enm)
            {
                case EnquiryStatus.Open: return "O";
                case EnquiryStatus.Won: return "W";
                case EnquiryStatus.Lost: return "L";
                default: throw new ArgumentException("Invalid EnquiryStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("O".Equals(code)) return EnquiryStatus.Open;
            else if ("W".Equals(code)) return EnquiryStatus.Won;
            else if ("L".Equals(code)) return EnquiryStatus.Lost;
            throw new ArgumentException("Cannot convert value '" + code + "' to EnquiryStatus.");
        }
    }
    public class EnqActivityRecordTypeStringType : NHibernate.Type.EnumStringType
    {
        public EnqActivityRecordTypeStringType() : base(typeof(EnqActivityRecordType), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((EnqActivityRecordType)enm)
            {
                case EnqActivityRecordType.Activity: return "A";
                case EnqActivityRecordType.Task: return "T";
                case EnqActivityRecordType.Note: return "N";
                case EnqActivityRecordType.Action: return "S";
                case EnqActivityRecordType.Call: return "C";
                default: throw new ArgumentException("Invalid EnqActivityRecordType.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("A".Equals(code)) return EnqActivityRecordType.Activity;
            else if ("T".Equals(code)) return EnqActivityRecordType.Task;
            else if ("N".Equals(code)) return EnqActivityRecordType.Note;
            else if ("S".Equals(code)) return EnqActivityRecordType.Action;
            else if ("C".Equals(code)) return EnqActivityRecordType.Call;
            throw new ArgumentException("Cannot convert value '" + code + "' to EnqActivityRecordType.");
        }
    }
    public class ReminderModeStringType : NHibernate.Type.EnumStringType
    {
        public ReminderModeStringType() : base(typeof(ReminderMode), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((ReminderMode)enm)
            {
                case ReminderMode.Scheduled: return "S";
                case ReminderMode.Rescheduled: return "R";
                case ReminderMode.Cancelled: return "C";
                case ReminderMode.None: return "N";
                default: throw new ArgumentException("Invalid ReminderMode.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("S".Equals(code)) return ReminderMode.Scheduled;
            else if ("R".Equals(code)) return ReminderMode.Rescheduled;
            else if ("C".Equals(code)) return ReminderMode.Cancelled;
            else if ("N".Equals(code)) return ReminderMode.None;
            throw new ArgumentException("Cannot convert value '" + code + "' to ReminderMode.");
        }
    }
    public class EnqActivityTypeStringType : NHibernate.Type.EnumStringType
    {
        public EnqActivityTypeStringType() : base(typeof(EnqActivityType), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((EnqActivityType)enm)
            {
                case EnqActivityType.SITE_VISIT: return "V";
                case EnqActivityType.MEETING: return "M";
                case EnqActivityType.FOLLOW_UP: return "F";
                case EnqActivityType.ASSIGNMENT: return "A";
                case EnqActivityType.RE_ASSIGNMENT: return "R";
                case EnqActivityType.CONVERTED: return "Z";
                case EnqActivityType.CREATE: return "C";
                case EnqActivityType.LOST: return "L";
                case EnqActivityType.WON: return "W";
                case EnqActivityType.BOOKING_CANCELLED: return "X";
                case EnqActivityType.RE_OPENED: return "O";
                case EnqActivityType.TASK: return "T";
                case EnqActivityType.NOTE: return "N";
                case EnqActivityType.CALL: return "C";
                default: throw new ArgumentException("Invalid EnqActivityType.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("V".Equals(code)) return EnqActivityType.SITE_VISIT;
            else if ("M".Equals(code)) return EnqActivityType.MEETING;
            else if ("F".Equals(code)) return EnqActivityType.FOLLOW_UP;
            else if ("A".Equals(code)) return EnqActivityType.ASSIGNMENT;
            else if ("R".Equals(code)) return EnqActivityType.RE_ASSIGNMENT;
            else if ("Z".Equals(code)) return EnqActivityType.CONVERTED;
            else if ("C".Equals(code)) return EnqActivityType.CREATE;
            else if ("L".Equals(code)) return EnqActivityType.LOST;
            else if ("W".Equals(code)) return EnqActivityType.WON;
            else if ("X".Equals(code)) return EnqActivityType.BOOKING_CANCELLED;
            else if ("O".Equals(code)) return EnqActivityType.RE_OPENED;
            else if ("T".Equals(code)) return EnqActivityType.TASK;
            else if ("N".Equals(code)) return EnqActivityType.NOTE;
            else if ("C".Equals(code)) return EnqActivityType.CALL;
            throw new ArgumentException("Cannot convert value '" + code + "' to EnqActivityType.");
        }
    }
    public class EnqLeadActivityStatusStringType : NHibernate.Type.EnumStringType
    {
        public EnqLeadActivityStatusStringType() : base(typeof(EnqLeadActivityStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((EnqLeadActivityStatus)enm)
            {
                case EnqLeadActivityStatus.Open: return "O";
                case EnqLeadActivityStatus.Deferred: return "X";
                case EnqLeadActivityStatus.Completed: return "C";
                default: throw new ArgumentException("Invalid EnqLeadActivityStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("O".Equals(code)) return EnqLeadActivityStatus.Open;
            else if ("X".Equals(code)) return EnqLeadActivityStatus.Deferred;
            else if ("C".Equals(code)) return EnqLeadActivityStatus.Completed;
            throw new ArgumentException("Cannot convert value '" + code + "' to EnqLeadActivityStatus.");
        }
    }
    public class LeadStatusStringType : NHibernate.Type.EnumStringType
    {
        public LeadStatusStringType() : base(typeof(LeadStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((LeadStatus)enm)
            {
                case LeadStatus.Open: return "O";
                case LeadStatus.Converted: return "C";
                case LeadStatus.Lost: return "L";
                default: throw new ArgumentException("Invalid LeadStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("O".Equals(code)) return LeadStatus.Open;
            else if ("C".Equals(code)) return LeadStatus.Converted;
            else if ("L".Equals(code)) return LeadStatus.Lost;
            throw new ArgumentException("Cannot convert value '" + code + "' to LeadStatus.");
        }
    }
    public class CommonParkingStringType : NHibernate.Type.EnumStringType
    {
        public CommonParkingStringType() : base(typeof(CommonParking), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((CommonParking)enm)
            {
                case CommonParking.Yes: return "Y";
                case CommonParking.No: return "N";
                default: throw new ArgumentException("Invalid CommonParking.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return CommonParking.Yes;
            else if ("N".Equals(code)) return CommonParking.No;
            throw new ArgumentException("Cannot convert value '" + code + "' to CommonParking.");
        }
    }
   
    public class ParkingStatusStringType : NHibernate.Type.EnumStringType
    {
        public ParkingStatusStringType() : base(typeof(ParkingStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((ParkingStatus)enm)
            {
                case ParkingStatus.Available: return "A";
                case ParkingStatus.Reserved: return "R";
                case ParkingStatus.Allotted: return "X";
                default: throw new ArgumentException("Invalid ParkingStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("A".Equals(code)) return ParkingStatus.Available;
            else if ("R".Equals(code)) return ParkingStatus.Reserved;
            else if ("X".Equals(code)) return ParkingStatus.Allotted;
            throw new ArgumentException("Cannot convert value '" + code + "' to ParkingStatus.");
        }
    }
    public class PRScheduleStageStatusStringType : NHibernate.Type.EnumStringType
    {
        public PRScheduleStageStatusStringType() : base(typeof(PRScheduleStageStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PRScheduleStageStatus)enm)
            {
                case PRScheduleStageStatus.Pending: return "P";
                case PRScheduleStageStatus.Completed: return "C";
                default: throw new ArgumentException("Invalid PRScheduleStageStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("P".Equals(code)) return PRScheduleStageStatus.Pending;
            else if ("C".Equals(code)) return PRScheduleStageStatus.Completed;
            throw new ArgumentException("Cannot convert value '" + code + "' to PRScheduleStageStatus.");
        }
    }
    public class IncludeInPymtTotalStringType : NHibernate.Type.EnumStringType
    {
        public IncludeInPymtTotalStringType() : base(typeof(IncludeInPymtTotal), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((IncludeInPymtTotal)enm)
            {
                case IncludeInPymtTotal.Yes: return "Y";
                case IncludeInPymtTotal.No: return "N";
                default: throw new ArgumentException("Invalid IncludeInPymtTotal.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return IncludeInPymtTotal.Yes;
            else if ("N".Equals(code)) return IncludeInPymtTotal.No;
            throw new ArgumentException("Cannot convert value '" + code + "' to IncludeInPymtTotal.");
        }
    }
    public class PRUnitStatusStringType : NHibernate.Type.EnumStringType
    {
        public PRUnitStatusStringType() : base(typeof(PRUnitStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PRUnitStatus)enm)
            {
                case PRUnitStatus.Available: return "A";
                case PRUnitStatus.Reserved: return "R";
                case PRUnitStatus.Sold: return "S";
                case PRUnitStatus.Deleted: return "D";
                default: throw new ArgumentException("Invalid PRUnitStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("A".Equals(code)) return PRUnitStatus.Available;
            else if ("R".Equals(code)) return PRUnitStatus.Reserved;
            else if ("S".Equals(code)) return PRUnitStatus.Sold;
            else if ("D".Equals(code)) return PRUnitStatus.Deleted;
            throw new ArgumentException("Cannot convert value '" + code + "' to PRUnitStatus.");
        }
    }
    public class IsPoaStringType : NHibernate.Type.EnumStringType
    {
        public IsPoaStringType() : base(typeof(PowerOfAtorny), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PowerOfAtorny)enm)
            {
                case PowerOfAtorny.Yes: return "Y";
                case PowerOfAtorny.No: return "N";
                default: return null;
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return PowerOfAtorny.Yes;
            else if ("N".Equals(code)) return PowerOfAtorny.No;
            return null;
        }
    }
    public class FamilyRelationshipStringType : NHibernate.Type.EnumStringType
    {
    	public FamilyRelationshipStringType() : base(typeof(FamilyRelation), 1) { }
    	public override object GetValue(object enm)
    	{
    		if (null == enm) return String.Empty;
    		switch ((FamilyRelation)enm)
    		{
    			case FamilyRelation.SON_OF: return "S";
    			case FamilyRelation.DAUGHTER_OF: return "D";
    			case FamilyRelation.WIFE_OF: return "W";
    			default: throw new ArgumentException("Invalid FamilyRelationship.");
    		}
    	}
    	public override object GetInstance(object code)
    	{
    		if ("S".Equals(code)) return FamilyRelation.SON_OF;
    		else if ("D".Equals(code)) return FamilyRelation.DAUGHTER_OF;
    		else if ("W".Equals(code)) return FamilyRelation.WIFE_OF;
    		throw new ArgumentException("Cannot convert value '" + code + "' to FamilyRelationship.");
    	}
    }
    public class PRUnitSaleStatusStringType : NHibernate.Type.EnumStringType
    {
        public PRUnitSaleStatusStringType() : base(typeof(PRUnitSaleStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PRUnitSaleStatus)enm)
            {
                case PRUnitSaleStatus.Sold: return "S";
                case PRUnitSaleStatus.Cancelled: return "C";
                default: throw new ArgumentException("Invalid PRUnitSaleStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("S".Equals(code)) return PRUnitSaleStatus.Sold;
            else if ("C".Equals(code)) return PRUnitSaleStatus.Cancelled;
            throw new ArgumentException("Cannot convert value '" + code + "' to PRUnitSaleStatus.");
        }
    }
    public class IsPossessionDoneStringType : NHibernate.Type.EnumStringType
    {
        public IsPossessionDoneStringType() : base(typeof(IsPossessionDone), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((IsPossessionDone)enm)
            {
                case IsPossessionDone.Yes: return "Y";
                case IsPossessionDone.No: return "N";
                default: throw new ArgumentException("Invalid IsPossessionDone.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return IsPossessionDone.Yes;
            else if ("N".Equals(code)) return IsPossessionDone.No;
            throw new ArgumentException("Cannot convert value '" + code + "' to IsPossessionDone.");
        }
    }
    public class IsAgreementDoneStringType : NHibernate.Type.EnumStringType
    {
        public IsAgreementDoneStringType() : base(typeof(IsAgreementDone), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((IsAgreementDone)enm)
            {
                case IsAgreementDone.Yes: return "Y";
                case IsAgreementDone.No: return "N";
                default: throw new ArgumentException("Invalid IsAgreementDone.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return IsAgreementDone.Yes;
            else if ("N".Equals(code)) return IsAgreementDone.No;
            throw new ArgumentException("Cannot convert value '" + code + "' to IsAgreementDone.");
        }
    }
    public class PymtMasterStatusStringType : NHibernate.Type.EnumStringType
    {
        public PymtMasterStatusStringType() : base(typeof(PymtMasterStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PymtMasterStatus)enm)
            {
                case PymtMasterStatus.Paid: return "P";
                case PymtMasterStatus.Pending: return "X";
                case PymtMasterStatus.Deleted: return "D";
                case PymtMasterStatus.Suspended: return "S";
                default: throw new ArgumentException("Invalid PymtMasterStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("P".Equals(code)) return PymtMasterStatus.Paid;
            else if ("X".Equals(code)) return PymtMasterStatus.Pending;
            else if ("D".Equals(code)) return PymtMasterStatus.Deleted;
            else if ("S".Equals(code)) return PymtMasterStatus.Suspended;
            throw new ArgumentException("Cannot convert value '" + code + "' to PymtMasterStatus.");
        }
    }
    public class PymtTransRcptDeliveredStringType : NHibernate.Type.EnumStringType
    {
    	public PymtTransRcptDeliveredStringType(): base(typeof(PymtTransRcptDelivered), 1){}
    	public override object GetValue(object enm)
    	{
    		if (null == enm) return String.Empty;
    		switch ((PymtTransRcptDelivered)enm)
    		{
    			case PymtTransRcptDelivered.Yes: return "Y";
    			case PymtTransRcptDelivered.No: return "N";
    			default: return null;
    		}
    	}
    	public override object GetInstance(object code)
    	{
    		if ("Y".Equals(code)) return PymtTransRcptDelivered.Yes;
    		else if ("N".Equals(code)) return PymtTransRcptDelivered.No;
    		return null;
    	}
    }
    public class PaymentMethodStringType : NHibernate.Type.EnumStringType
    {
        public PaymentMethodStringType() : base(typeof(PaymentMethod), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PaymentMethod)enm)
            {
                case PaymentMethod.CASH: return "CASH";
                case PaymentMethod.CHEQUE: return "CHQ";
                case PaymentMethod.DD: return "DD";
                case PaymentMethod.NEFT: return "NEFT";
                case PaymentMethod.RTGS: return "RTGS";
                default: throw new ArgumentException("Invalid PaymentMode.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("CASH".Equals(code)) return PaymentMethod.CASH;
            else if ("CHQ".Equals(code)) return PaymentMethod.CHEQUE;
            else if ("DD".Equals(code)) return PaymentMethod.DD;
            else if ("NEFT".Equals(code)) return PaymentMethod.NEFT;
            else if ("RTGS".Equals(code)) return PaymentMethod.RTGS;
            throw new ArgumentException("Cannot convert value '" + code + "' to PaymentMethod.");
        }
    }
    public class PymtTransStatusStringType : NHibernate.Type.EnumStringType
    {
        public PymtTransStatusStringType() : base(typeof(PymtTransStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PymtTransStatus)enm)
            {
                case PymtTransStatus.Pending: return "X";
                case PymtTransStatus.Paid: return "P";
                case PymtTransStatus.Deleted: return "D";
                case PymtTransStatus.Reversal: return "R";
                default: throw new ArgumentException("Invalid PymtTransStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("X".Equals(code)) return PymtTransStatus.Pending;
            else if ("P".Equals(code)) return PymtTransStatus.Paid;
            else if ("D".Equals(code)) return PymtTransStatus.Deleted;
            else if ("R".Equals(code)) return PymtTransStatus.Reversal;
            throw new ArgumentException("Cannot convert value '" + code + "' to PymtTransStatus.");
        }
    }
    public class ChequeStatusStringType : NHibernate.Type.EnumStringType
    {
        public ChequeStatusStringType() : base(typeof(ChequeStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((ChequeStatus)enm)
            {
                case ChequeStatus.Collected: return "C";
                case ChequeStatus.Deposited: return "D";
                case ChequeStatus.Cleared: return "P";
                case ChequeStatus.Bounced: return "B";
                case ChequeStatus.Returned: return "R";
                default: return null;
            }
        }
        public override object GetInstance(object code)
        {
            if ("C".Equals(code)) return ChequeStatus.Collected;
            else if ("D".Equals(code)) return ChequeStatus.Deposited;
            else if ("P".Equals(code)) return ChequeStatus.Cleared;
            else if ("B".Equals(code)) return ChequeStatus.Bounced;
            else if ("R".Equals(code)) return ChequeStatus.Returned;
            return null;
        }
    }
    public class PaymentModeStringType : NHibernate.Type.EnumStringType
    {
        public PaymentModeStringType() : base(typeof(PaymentMode), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PaymentMode)enm)
            {
                case PaymentMode.Receivable: return "R";
                case PaymentMode.Payable: return "P";
                default: throw new ArgumentException("Invalid PaymentMode.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("R".Equals(code)) return PaymentMode.Receivable;
            else if ("P".Equals(code)) return PaymentMode.Payable;
            throw new ArgumentException("Cannot convert value '" + code + "' to PaymentMode.");
        }
    }
    public class MPTPymtStatusStringType : NHibernate.Type.EnumStringType
    {
        public MPTPymtStatusStringType() : base(typeof(MPTPymtStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((MPTPymtStatus)enm)
            {
                case MPTPymtStatus.Pending: return "X";
                case MPTPymtStatus.Paid: return "P";
                case MPTPymtStatus.Deleted: return "D";
                default: throw new ArgumentException("Invalid MPTPymtStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("X".Equals(code)) return MPTPymtStatus.Pending;
            else if ("P".Equals(code)) return MPTPymtStatus.Paid;
            else if ("D".Equals(code)) return MPTPymtStatus.Deleted;
            throw new ArgumentException("Cannot convert value '" + code + "' to MPTPymtStatus.");
        }
    }
    public class AcntTransStatusStringType : NHibernate.Type.EnumStringType
    {
        public AcntTransStatusStringType() : base(typeof(AcntTransStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((AcntTransStatus)enm)
            {
                case AcntTransStatus.Credit: return "C";
                case AcntTransStatus.Debit: return "D";
                default: throw new ArgumentException("Invalid AcntTransStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("C".Equals(code)) return AcntTransStatus.Credit;
            else if ("D".Equals(code)) return AcntTransStatus.Debit;
            throw new ArgumentException("Cannot convert value '" + code + "' to AcntTransStatus.");
        }
    }
    public class PropertyFundStatusStringType : NHibernate.Type.EnumStringType
    {
        public PropertyFundStatusStringType() : base(typeof(PropertyFundStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PropertyFundStatus)enm)
            {
                case PropertyFundStatus.Deposited: return "C";
                case PropertyFundStatus.Reversed: return "D";
                default: throw new ArgumentException("Invalid AcntDepositStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("C".Equals(code)) return PropertyFundStatus.Deposited;
            else if ("D".Equals(code)) return PropertyFundStatus.Reversed;
            throw new ArgumentException("Cannot convert value '" + code + "' to AcntDepositStatus.");
        }
    }
    public class ReportTemplateTypeStringType : NHibernate.Type.EnumStringType
    {
    	public ReportTemplateTypeStringType() : base(typeof(ReportTemplateType), 1) { }
    	public override object GetValue(object enm)
    	{
    		if (null == enm) return String.Empty;
    		switch ((ReportTemplateType)enm)
    		{
    			case ReportTemplateType.DEMAND_LETTER: return "DEMAND_LETTER";
    			case ReportTemplateType.POSSESSION_LETTER: return "POSSESSION_LETTER";
    			case ReportTemplateType.MORTGAGE_LETTER: return "MORTGAGE_LETTER";
    			case ReportTemplateType.PAYMENT_RCPT: return "PAYMENT_RCPT";
    			case ReportTemplateType.UNIT_QUOTATION: return "UNIT_QUOTATION";
                case ReportTemplateType.ACNT_STATEMENT: return "ACNT_STATEMENT";
    			case ReportTemplateType.PAYMENT_DUE_REPORT: return "PAYMENT_DUE_REPORT";
    			case ReportTemplateType.PAYMENT_FORECAST_REPORT: return "PAYMENT_FORECAST_REPORT";
                case ReportTemplateType.ENQ_LEAD_REPORT: return "ENQ_LEAD_REPORT";
                case ReportTemplateType.LEAD_ENQ_USER_REPORT: return "LEAD_ENQ_USER_REPORT";   
    			default: throw new ArgumentException("Invalid ReportTemplateType.");
    		}
    	}
    	public override object GetInstance(object code)
    	{
    		if ("DEMAND_LETTER".Equals(code)) return ReportTemplateType.DEMAND_LETTER;
    		else if ("POSSESSION_LETTER".Equals(code)) return ReportTemplateType.POSSESSION_LETTER;
    		else if ("MORTGAGE_LETTER".Equals(code)) return ReportTemplateType.MORTGAGE_LETTER;
    		else if ("PAYMENT_RCPT".Equals(code)) return ReportTemplateType.PAYMENT_RCPT;
    		else if ("UNIT_QUOTATION".Equals(code)) return ReportTemplateType.UNIT_QUOTATION;
            else if ("ACNT_STATEMENT".Equals(code)) return ReportTemplateType.ACNT_STATEMENT;
    		else if ("PAYMENT_DUE_REPORT".Equals(code)) return ReportTemplateType.PAYMENT_DUE_REPORT;
    		else if ("PAYMENT_FORECAST_REPORT".Equals(code)) return ReportTemplateType.PAYMENT_FORECAST_REPORT;
            else if ("ENQ_LEAD_REPORT".Equals(code)) return ReportTemplateType.ENQ_LEAD_REPORT;
            else if ("LEAD_ENQ_USER_REPORT".Equals(code)) return ReportTemplateType.LEAD_ENQ_USER_REPORT;
    		throw new ArgumentException("Cannot convert value '" + code + "' to ReportTemplateType.");
    	}
    }
    public class IsCustomReportStringType : NHibernate.Type.EnumStringType
    {
    	public IsCustomReportStringType() : base(typeof(IsCustomReport), 1) { }
    	public override object GetValue(object enm)
    	{
    		if (null == enm) return String.Empty;
    		switch ((IsCustomReport)enm)
    		{
    			case IsCustomReport.Yes: return "Y";
    			case IsCustomReport.No: return "N";
    			default: return null;
    		}
    	}
    	public override object GetInstance(object code)
    	{
    		if ("Y".Equals(code)) return IsCustomReport.Yes;
    		else if ("N".Equals(code)) return IsCustomReport.No;
    		return null;
    	}
    }
    public class PrAlertFunctionNameStringType : NHibernate.Type.EnumStringType
    {
        public PrAlertFunctionNameStringType() : base(typeof(PrAlertFunctionName), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PrAlertFunctionName)enm)
            {
                case PrAlertFunctionName.ENQ_ADD_CUSTOMER: return "ENQ_ADD_CUSTOMER";
                case PrAlertFunctionName.LD_ADD_CUSTOMER: return "LD_ADD_CUSTOMER";
                case PrAlertFunctionName.UNIT_BOOKING_CUSTOMER: return "UNIT_BOOKING_CUSTOMER";
                case PrAlertFunctionName.UNIT_CANCELLATION_CUSTOMER: return "UNIT_CANCELLATION_CUSTOMER";
                default: throw new ArgumentException("Invalid PrAlertFunctionName.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("ENQ_ADD_CUSTOMER".Equals(code)) return PrAlertFunctionName.ENQ_ADD_CUSTOMER;
            if ("LD_ADD_CUSTOMER".Equals(code)) return PrAlertFunctionName.LD_ADD_CUSTOMER;
            else if ("UNIT_BOOKING_CUSTOMER".Equals(code)) return PrAlertFunctionName.UNIT_BOOKING_CUSTOMER;
            else if ("UNIT_CANCELLATION_CUSTOMER".Equals(code)) return PrAlertFunctionName.UNIT_CANCELLATION_CUSTOMER;
            throw new ArgumentException("Cannot convert value '" + code + "' to PrAlertFunctionName.");
        }
    }
    public class EmailSmsTypeStringType : NHibernate.Type.EnumStringType
    {
        public EmailSmsTypeStringType() : base(typeof(EmailSmsType), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((EmailSmsType)enm)
            {
                case EmailSmsType.Email: return "E";
                case EmailSmsType.SMS: return "S";
                default: throw new ArgumentException("Invalid EmailSmsType.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("E".Equals(code)) return EmailSmsType.Email;
            else if ("S".Equals(code)) return EmailSmsType.SMS;
            throw new ArgumentException("Cannot convert value '" + code + "' to EmailSmsType.");
        }
    }
    public class EmailSmsStoreStatusStringType : NHibernate.Type.EnumStringType
    {
        public EmailSmsStoreStatusStringType() : base(typeof(EmailSmsStoreStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((EmailSmsStoreStatus)enm)
            {
                case EmailSmsStoreStatus.Draft: return "D";
                case EmailSmsStoreStatus.Published: return "P";
                default: throw new ArgumentException("Invalid EmailSmsStoreStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("D".Equals(code)) return EmailSmsStoreStatus.Draft;
            else if ("P".Equals(code)) return EmailSmsStoreStatus.Published;
            throw new ArgumentException("Cannot convert value '" + code + "' to EmailSmsStoreStatus.");
        }
    }
    public class EmailSmsCampaignStageStringType : NHibernate.Type.EnumStringType
    {
    	public EmailSmsCampaignStageStringType() : base(typeof(EmailSmsCampaignStage), 1) { }
    	public override object GetValue(object enm)
    	{
    		if (null == enm) return String.Empty;
    		switch ((EmailSmsCampaignStage)enm)
    		{
    			case EmailSmsCampaignStage.Draft: return "D";
    			case EmailSmsCampaignStage.Scheduled: return "S";
    			case EmailSmsCampaignStage.Completed: return "C";
    			default: throw new ArgumentException("Invalid EmailSmsCampaignStage.");
    		}
    	}
    	public override object GetInstance(object code)
    	{
    		if ("D".Equals(code)) return EmailSmsCampaignStage.Draft;
    		else if ("S".Equals(code)) return EmailSmsCampaignStage.Scheduled;
    		else if ("C".Equals(code)) return EmailSmsCampaignStage.Completed;
    		throw new ArgumentException("Cannot convert value '" + code + "' to EmailSmsCampaignStage.");
    	}
    }
    public class EmailSmsScheduleOptionStringType : NHibernate.Type.EnumStringType
    {
    	public EmailSmsScheduleOptionStringType() : base(typeof(EmailSmsScheduleOption), 1) { }
    	public override object GetValue(object enm)
    	{
    		if (null == enm) return String.Empty;
    		switch ((EmailSmsScheduleOption)enm)
    		{
    			case EmailSmsScheduleOption.Now: return "N";
    			case EmailSmsScheduleOption.Scheduled: return "S";
    			default: return null;
    		}
    	}
    	public override object GetInstance(object code)
    	{
    		if ("N".Equals(code)) return EmailSmsScheduleOption.Now;
    		else if ("S".Equals(code)) return EmailSmsScheduleOption.Scheduled;
    		return null;
    	}
    }
    public class EmailSmsCampaignStatusStringType : NHibernate.Type.EnumStringType
    {
    	public EmailSmsCampaignStatusStringType() : base(typeof(EmailSmsCampaignStatus), 1) { }
    	public override object GetValue(object enm)
    	{
    		if (null == enm) return String.Empty;
    		switch ((EmailSmsCampaignStatus)enm)
    		{
    			case EmailSmsCampaignStatus.NotStarted: return "N";
    			case EmailSmsCampaignStatus.Success: return "S";
    			case EmailSmsCampaignStatus.Failed: return "F";
    			case EmailSmsCampaignStatus.Inprogress: return "I";
    			default: throw new ArgumentException("Invalid EmailSmsCampaignStatus.");
    		}
    	}
    	public override object GetInstance(object code)
    	{
    		if ("N".Equals(code)) return EmailSmsCampaignStatus.NotStarted;
    		else if ("S".Equals(code)) return EmailSmsCampaignStatus.Success;
    		else if ("F".Equals(code)) return EmailSmsCampaignStatus.Failed;
    		else if ("I".Equals(code)) return EmailSmsCampaignStatus.Inprogress;
    		throw new ArgumentException("Cannot convert value '" + code + "' to EmailSmsCampaignStatus.");
    	}
    }
    public class EmailSmsRcpntTypeStringType : NHibernate.Type.EnumStringType
    {
    	public EmailSmsRcpntTypeStringType() : base(typeof(EmailSmsRcpntType), 1) { }
    	public override object GetValue(object enm)
    	{
    		if (null == enm) return String.Empty;
    		switch ((EmailSmsRcpntType)enm)
    		{
    			case EmailSmsRcpntType.ALL_LD_CUSTOMER: return "0";
    			case EmailSmsRcpntType.ALL_LEADS: return "1";
    			case EmailSmsRcpntType.ALL_CUSTOMERS: return "2";
    			case EmailSmsRcpntType.ONLY_SOLD_UNIT_CUSTOMERS: return "3";
    			default: throw new ArgumentException("Invalid EmailSmsRcpntType.");
    		}
    	}
    	public override object GetInstance(object code)
    	{
    		if ("0".Equals(code)) return EmailSmsRcpntType.ALL_LD_CUSTOMER;
    		else if ("1".Equals(code)) return EmailSmsRcpntType.ALL_LEADS;
    		else if ("2".Equals(code)) return EmailSmsRcpntType.ALL_CUSTOMERS;
    		else if ("3".Equals(code)) return EmailSmsRcpntType.ONLY_SOLD_UNIT_CUSTOMERS;
    		throw new ArgumentException("Cannot convert value '" + code + "' to EmailSmsRcpntType.");
    	}
    }
    public class EmailSmsEnabledStringType : NHibernate.Type.EnumStringType
    {
    	public EmailSmsEnabledStringType() : base(typeof(EmailSmsEnabled), 1) { }
    	public override object GetValue(object enm)
    	{
    		if (null == enm) return String.Empty;
    		switch ((EmailSmsEnabled)enm)
    		{
    			case EmailSmsEnabled.Yes: return "Y";
    			case EmailSmsEnabled.No: return "N";
    			default: throw new ArgumentException("Invalid EmailSmsEnabled.");
    		}
    	}
    	public override object GetInstance(object code)
    	{
    		if ("Y".Equals(code)) return EmailSmsEnabled.Yes;
    		else if ("N".Equals(code)) return EmailSmsEnabled.No;
    		throw new ArgumentException("Cannot convert value '" + code + "' to EmailSmsEnabled.");
    	}
    }
    public class NotificationTypeStringType : NHibernate.Type.EnumStringType
    {
        public NotificationTypeStringType() : base(typeof(NotificationType), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((NotificationType)enm)
            {
                case NotificationType.ALERT: return "A";
                case NotificationType.TASK: return "T";
                default: throw new ArgumentException("Invalid NotificationType.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("A".Equals(code)) return NotificationType.ALERT;
            else if ("T".Equals(code)) return NotificationType.TASK;
            throw new ArgumentException("Cannot convert value '" + code + "' to NotificationType.");
        }
    }
    public class NotificationSubTypeStringType : NHibernate.Type.EnumStringType
    {
    	public NotificationSubTypeStringType() : base(typeof(NotificationSubType), 1) { }
    	public override object GetValue(object enm)
    	{
    		if (null == enm) return String.Empty;
    		switch ((NotificationSubType)enm)
    		{
    			case NotificationSubType.NEW_LEAD_ASSIGNED: return "NLA";
    			case NotificationSubType.LEAD_REASSIGNED_SELF: return "LRS";
                case NotificationSubType.LEAD_REASSIGNED_USER: return "LRU";
                case NotificationSubType.LEAD_CLOSED_USER: return "LCU";
                case NotificationSubType.LEAD_CONVERTED_BY_USER: return "LXU";
                case NotificationSubType.LEAD_ACTIVITY_LOGGED_BY_USER: return "LAL";
                case NotificationSubType.LEAD_ACTIVITY_LOGGED_BY_FACEBOOK: return "LAF";
    			case NotificationSubType.ENQUIRY_REASSIGNED_SELF: return "ERS";
                case NotificationSubType.ENQUIRY_REASSIGNED_USER: return "ERU";
                case NotificationSubType.ENQUIRY_CLOSED_USER: return "ECU";
                case NotificationSubType.ENQUIRY_REOPEN_USER: return "ERO";
                case NotificationSubType.ENQUIRY_ACTIVITY_LOGGED_BY_USER: return "EAL";
                case NotificationSubType.ENQUIRY_ACTIVITY_LOGGED_BY_FACEBOOK: return "EAF";
                case NotificationSubType.ENQUIRY_USED_FOR_BOOKING: return "EUB";
                case NotificationSubType.INCOMING_CALL_INTIMATION: return "ICI";
    			default: throw new ArgumentException("Invalid NotificationSubType.");
    		}
    	}
    	public override object GetInstance(object code)
    	{
            if ("NLA".Equals(code)) return NotificationSubType.NEW_LEAD_ASSIGNED;
            else if ("LRS".Equals(code)) return NotificationSubType.LEAD_REASSIGNED_SELF;
            else if ("LRU".Equals(code)) return NotificationSubType.LEAD_REASSIGNED_USER;
            else if ("LCU".Equals(code)) return NotificationSubType.LEAD_CLOSED_USER;
            else if ("LXU".Equals(code)) return NotificationSubType.LEAD_CONVERTED_BY_USER;
            else if ("LAL".Equals(code)) return NotificationSubType.LEAD_ACTIVITY_LOGGED_BY_USER;
            else if ("LAF".Equals(code)) return NotificationSubType.LEAD_ACTIVITY_LOGGED_BY_FACEBOOK;
            else if ("ERS".Equals(code)) return NotificationSubType.ENQUIRY_REASSIGNED_SELF;
            else if ("ERU".Equals(code)) return NotificationSubType.ENQUIRY_REASSIGNED_USER;
            else if ("ECU".Equals(code)) return NotificationSubType.ENQUIRY_CLOSED_USER;
            else if ("ERO".Equals(code)) return NotificationSubType.ENQUIRY_REOPEN_USER;
            else if ("EAL".Equals(code)) return NotificationSubType.ENQUIRY_ACTIVITY_LOGGED_BY_USER;
            else if ("EAF".Equals(code)) return NotificationSubType.ENQUIRY_ACTIVITY_LOGGED_BY_FACEBOOK;
            else if ("EUB".Equals(code)) return NotificationSubType.ENQUIRY_USED_FOR_BOOKING;
            else if ("ICI".Equals(code)) return NotificationSubType.INCOMING_CALL_INTIMATION;
    		throw new ArgumentException("Cannot convert value '" + code + "' to NotificationSubType.");
    	}
    }
    public class NotificationStatusStringType : NHibernate.Type.EnumStringType
    {
        public NotificationStatusStringType() : base(typeof(NotificationStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((NotificationStatus)enm)
            {
                case NotificationStatus.OPEN: return "O";
                case NotificationStatus.CLOSED: return "C";
                default: throw new ArgumentException("Invalid NotificationStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("O".Equals(code)) return NotificationStatus.OPEN;
            else if ("C".Equals(code)) return NotificationStatus.CLOSED;
            throw new ArgumentException("Cannot convert value '" + code + "' to NotificationStatus.");
        }
    }
    public class JobStatusStringType : NHibernate.Type.EnumStringType
    {
        public JobStatusStringType() : base(typeof(JobStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((JobStatus)enm)
            {
                case JobStatus.Active: return "A";
                case JobStatus.InActive: return "I";
                default: throw new ArgumentException("Invalid JobStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("A".Equals(code)) return JobStatus.Active;
            else if ("I".Equals(code)) return JobStatus.InActive;
            throw new ArgumentException("Cannot convert value '" + code + "' to JobStatus.");
        }
    }
    public class SystemJobsStringType : NHibernate.Type.EnumStringType
    {
    	public SystemJobsStringType() : base(typeof(SystemJobs), 1) { }
    	public override object GetValue(object enm)
    	{
    		if (null == enm) return String.Empty;
    		switch ((SystemJobs)enm)
    		{
    			case SystemJobs.TASK_NOTIFICATION_JOB: return "TASK_NOTIFICATION_JOB";
    			case SystemJobs.EXOTEL_CALL_JOB: return "EXOTEL_CALL_JOB";
    			case SystemJobs.SUBSCRIPTION_PLAN_JOB: return "SUBSCRIPTION_PLAN_JOB";
    			default: throw new ArgumentException("Invalid SystemJobs.");
    		}
    	}
    	public override object GetInstance(object code)
    	{
    		if ("TASK_NOTIFICATION_JOB".Equals(code)) return SystemJobs.TASK_NOTIFICATION_JOB;
    		else if ("EXOTEL_CALL_JOB".Equals(code)) return SystemJobs.EXOTEL_CALL_JOB;
    		else if ("SUBSCRIPTION_PLAN_JOB".Equals(code)) return SystemJobs.SUBSCRIPTION_PLAN_JOB;
    		throw new ArgumentException("Cannot convert value '" + code + "' to SystemJobs.");
    	}
    }
    public class JobIntervalTypeStringType : NHibernate.Type.EnumStringType
    {
        public JobIntervalTypeStringType() : base(typeof(JobIntervalType), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((JobIntervalType)enm)
            {
                case JobIntervalType.WithCalendarIntervalSchedule: return "C";
                case JobIntervalType.WithCronSchedule: return "R";
                case JobIntervalType.WithDailyTimeIntervalSchedule: return "D";
                case JobIntervalType.WithSimpleSchedule: return "S";
                default: throw new ArgumentException("Invalid JobIntervalType.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("C".Equals(code)) return JobIntervalType.WithCalendarIntervalSchedule;
            else if ("R".Equals(code)) return JobIntervalType.WithCronSchedule;
            else if ("D".Equals(code)) return JobIntervalType.WithDailyTimeIntervalSchedule;
            else if ("S".Equals(code)) return JobIntervalType.WithSimpleSchedule;
            throw new ArgumentException("Cannot convert value '" + code + "' to JobIntervalType.");
        }
    }
    public class JobExecutionStatusStringType : NHibernate.Type.EnumStringType
    {
        public JobExecutionStatusStringType() : base(typeof(JobExecutionStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((JobExecutionStatus)enm)
            {
            	case JobExecutionStatus.Not_Started: return "N";
                case JobExecutionStatus.Completed: return "C";
                case JobExecutionStatus.Inprogress: return "I";
                case JobExecutionStatus.Failed: return "F";
                default: throw new ArgumentException("Invalid JobExecutionStatus.");
            }
        }
        public override object GetInstance(object code)
        {
        	if ("N".Equals(code)) return JobExecutionStatus.Not_Started;
        	else if ("C".Equals(code)) return JobExecutionStatus.Completed;
            else if ("I".Equals(code)) return JobExecutionStatus.Inprogress;
            else if ("F".Equals(code)) return JobExecutionStatus.Failed;
            throw new ArgumentException("Cannot convert value '" + code + "' to JobExecutionStatus.");
        }
    }
   
    public class CallStatusStringType : NHibernate.Type.EnumStringType
    {
        public CallStatusStringType() : base(typeof(CallStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((CallStatus)enm)
            {
                case CallStatus.Queued: return "Q";
                case CallStatus.Inprogress: return "I";
                case CallStatus.Completed: return "C";
                case CallStatus.Failed: return "F";
                case CallStatus.Busy: return "B";
                case CallStatus.Free: return "R";
                case CallStatus.Noanswer: return "N";
                default: throw new ArgumentException("Invalid CallStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("Q".Equals(code)) return CallStatus.Queued;
            else if ("I".Equals(code)) return CallStatus.Inprogress;
            else if ("C".Equals(code)) return CallStatus.Completed;
            else if ("F".Equals(code)) return CallStatus.Failed;
            else if ("B".Equals(code)) return CallStatus.Busy;
            else if ("R".Equals(code)) return CallStatus.Free;
            else if ("N".Equals(code)) return CallStatus.Noanswer;
            throw new ArgumentException("Cannot convert value '" + code + "' to CallStatus.");
        }
    }
    public class CallDirectionStringType : NHibernate.Type.EnumStringType
    {
        public CallDirectionStringType() : base(typeof(CallDirection), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((CallDirection)enm)
            {
                case CallDirection.Outgoing: return "O";
                case CallDirection.Incoming: return "I";
                default: throw new ArgumentException("Invalid CallDirection.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("O".Equals(code)) return CallDirection.Outgoing;
            else if ("I".Equals(code)) return CallDirection.Incoming;
            throw new ArgumentException("Cannot convert value '" + code + "' to CallDirection.");
        }
    }
    public class CallHistoryStatusStringType : NHibernate.Type.EnumStringType
    {
        public CallHistoryStatusStringType() : base(typeof(CallHistoryStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((CallHistoryStatus)enm)
            {
                case CallHistoryStatus.Unresolved: return "U";
                case CallHistoryStatus.Resolved: return "R";
                default: throw new ArgumentException("Invalid CallHistoryStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("U".Equals(code)) return CallHistoryStatus.Unresolved;
            else if ("R".Equals(code)) return CallHistoryStatus.Resolved;
            throw new ArgumentException("Cannot convert value '" + code + "' to CallHistoryStatus.");
        }
    }
    public class IsSyncStringType : NHibernate.Type.EnumStringType
    {
    	public IsSyncStringType(): base(typeof(IsSync), 1){}
    	public override object GetValue(object enm)
    	{
    		if (null == enm) return String.Empty;
    		switch ((IsSync)enm)
    		{
    			case IsSync.Yes: return "Y";
    			case IsSync.No: return "N";
    			default: return null;
    		}
    	}
    	public override object GetInstance(object code)
    	{
    		if ("Y".Equals(code)) return IsSync.Yes;
    		else if ("N".Equals(code)) return IsSync.No;
    		return null;
    	}
    }
    public class PhoneTypeStringType : NHibernate.Type.EnumStringType
    {
    	public PhoneTypeStringType() : base(typeof(PhoneType), 1) { }
    	public override object GetValue(object enm)
    	{
    		if (null == enm) return String.Empty;
    		switch ((PhoneType)enm)
    		{
    			case PhoneType.Outgoing: return "O";
    			case PhoneType.Incoming: return "I";
    			case PhoneType.Both: return "B";
    			default: throw new ArgumentException("Invalid PhoneType.");
    		}
    	}
    	public override object GetInstance(object code)
    	{
    		if ("O".Equals(code)) return PhoneType.Outgoing;
    		else if ("I".Equals(code)) return PhoneType.Incoming;
    		else if ("B".Equals(code)) return PhoneType.Both;
    		throw new ArgumentException("Cannot convert value '" + code + "' to PhoneType.");
    	}
    }
}