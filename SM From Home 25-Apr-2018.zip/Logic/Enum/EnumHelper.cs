﻿
/// <summary>
/// Summary description for MyENUM
/// </summary>

using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
namespace ConstroSoft
{
    public static class EnumHelper
    {
        public static string GetEnumDescription<T>(string value)
        {
            Type type = typeof(T);
            var field = type.GetField(value);
            var customAttribute = field.GetCustomAttributes(typeof(DescriptionAttribute), false);
            return customAttribute.Length > 0 ? ((DescriptionAttribute)customAttribute[0]).Description : value;
        }
        public static List<string> GetEnumValues<T>()
        {
        	return Enum.GetNames(typeof(T)).ToList();
        }
        public static T ToEnum<T>(this string value, bool ignoreCase = true)
        {
            return (T)Enum.Parse(typeof(T), value, ignoreCase);
        }
        public static TEnum? ToEnumNullable<TEnum>(string value) where TEnum : struct
        {
            return (string.IsNullOrWhiteSpace(value)) ? (TEnum?)null : (TEnum)Enum.Parse(typeof(TEnum), value);
        }
        public static UserStatus getUserStatus(string dbVal)
        {
            return (UserStatus)((new UserStatusStringType()).GetInstance(dbVal));
        }
        public static PrFMAccess getPrFMAccess(string dbVal)
        {
            return (!string.IsNullOrWhiteSpace(dbVal) && dbVal.Equals("Y")) ? PrFMAccess.Yes : PrFMAccess.No;
        }
        public static bool isValidEnum<T>(this string value, bool ignoreCase = true)
        {
        	try{
        		T tmpVal = (T)Enum.Parse(typeof(T), value, ignoreCase);
        	} catch (Exception e){
        		return false;
        	}
        	return true;
        }
    }
}