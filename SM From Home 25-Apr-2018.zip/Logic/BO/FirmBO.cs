﻿using System;
using System.Linq;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Criterion;

/// <summary>
/// Summary description for FirmBO
/// </summary>
namespace ConstroSoft
{
    public class FirmBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public FirmBO() { }
        public FirmDTO fetchFirmDetails(string firmNumber)
        {
            ISession session = null;
            FirmDTO firmDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Firm firm = session.QueryOver<Firm>().Where(f => f.FirmNumber == firmNumber).SingleOrDefault<Firm>();
                        firmDto = populateFirmDTO(firm);
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while Loading Firm details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return firmDto;
        }
        public ExotelDTO fetchActiveExotelDetails(string firmNumber)
        {
            ISession session = null;
            ExotelDTO exotelDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Exotel e = null;
                        Firm f = null;
                    	Exotel exotel = session.QueryOver<Exotel>(() => e)
                            .Inner.JoinAlias(() => e.Firm, () => f)
                            .Where(() => f.FirmNumber == firmNumber && e.IsEnabled == IsEnabled.Yes).SingleOrDefault<Exotel>();
                    	exotelDto = DomainToDTOUtil.convertToExotelDTO(exotel, true);
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while Loading Exotel details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return exotelDto;
        }
        public IList<ExotelDTO> fetchExotelConfigs(string FirmNumber)
        {
        	ISession session = null;
        	IList<ExotelDTO> result = new List<ExotelDTO>();
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				Exotel x = null;
                        Firm f = null;
        				
        				IList<Exotel> tmpResult = session.QueryOver<Exotel>(() => x)
                            .Inner.JoinAlias(() => x.Firm, () => f).Where(() => f. FirmNumber == FirmNumber).List<Exotel>();
        				if(tmpResult != null) {
        					foreach(Exotel tmpObj in tmpResult) {
        						ExotelDTO tmpDTO = DomainToDTOUtil.convertToExotelDTO(tmpObj, true);
        						result.Add(tmpDTO);
        					}
        				}
        			} catch (Exception e)
        			{
        				log.Error("Exception while fetching Exotel Configurations:", e);
        				throw new CustomException(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        	return result;
        }
        public void saveOrUpdateExotelConfig(ExotelDTO tmpDTO)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				Exotel tmpObj = null;
        				if(tmpDTO.Id > 0) {
        					tmpObj = session.Get<Exotel>(tmpDTO.Id);
        					DTOToDomainUtil.populateExotelUpdateFields(tmpObj, tmpDTO);
        					session.Update(tmpObj);
        				} else {
        					tmpObj = DTOToDomainUtil.populateExotelAddFields(tmpDTO);
        					session.Save(tmpObj);
        					tmpDTO.Id = tmpObj.Id;
        				}
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while adding or updating Exotel Configurations:", e);
        				throw new CustomException(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
        public void deleteExotelConfig(long Id)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				Exotel tmpObj = session.Get<Exotel>(Id);
        				session.Delete(tmpObj);
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while deleting Exotel Configuration:", e);
        				throw new CustomException(CommonUtil.getActualErrorMsg(e, "Exotel Configuration"));
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
        public CallProvider fetchCallProvider(string firmNumber)
        {
            ISession session = null;
            CallProvider callProvider = CallProvider.EXOTEL;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Firm firm = session.QueryOver<Firm>().Where(f => f.FirmNumber == firmNumber).SingleOrDefault<Firm>();
                        callProvider = firm.CallProvider;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Call Provider:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return callProvider;
        }
        public List<FirmAccountDTO> fetchAccounts(string firmNumber)
        {
            ISession session = null;
            List<FirmAccountDTO> result = new List<FirmAccountDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	IList<FirmAccount> dbResult = session.QueryOver<FirmAccount>().Where(f => f.FirmNumber == firmNumber).List<FirmAccount>();
                    	if(dbResult != null) {
                    		foreach(FirmAccount tmpAcnt in dbResult) {
                    			result.Add(DomainToDTOUtil.convertToFirmAccountDTO(tmpAcnt, true));
                    		}
                    	}
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching accounts:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public IList<FirmDTO> fetchAllFirmsSelective()
        {
            ISession session = null;
            IList<FirmDTO> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Firm f = null;

                        FirmDTO aDto = null;
                        var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => f.Id).WithAlias(() => aDto.Id))
                                .Add(Projections.Property(() => f.Name).WithAlias(() => aDto.Name))
                                .Add(Projections.Property(() => f.FirmNumber).WithAlias(() => aDto.FirmNumber));
	                    var query = session.QueryOver<Firm>(() => f);
	                    result = query.Select(proj)
	                                .TransformUsing(new DeepTransformer<FirmDTO>()).List<FirmDTO>();
	                    if (result != null && result.Count > 0) result[0].isUISelected = true;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading all Firms selective:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return (result != null) ? result : new List<FirmDTO>();
        }
        public List<FirmDTO> fetchAllFirms()
        {
            ISession session = null;
            List<FirmDTO> firmDTOList = new List<FirmDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        IList<Firm> firmList = session.QueryOver<Firm>().List<Firm>();
                        foreach (Firm firm in firmList)
                        {
                        	firmDTOList.Add(populateFirmDTO(firm));
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading all Firms:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return firmDTOList;
        }
        public void updateFirm(FirmDTO firmDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Firm firm = session.Get<Firm>(firmDto.Id);
                        populateFirm(firm, firmDto);
                        session.Update(firm);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Updating Firm:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public bool validateAccountExist(string firmNumber, string AccountName, string AccountNumber)
        {
            ISession session = null;
            bool exist = false;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	FirmAccount p = null;
                        exist = session.QueryOver<FirmAccount>(() => p)
                            .Where(() => p.FirmNumber == firmNumber && (p.Name.IsInsensitiveLike(AccountName) || p.AccountNo.IsInsensitiveLike(AccountNumber)))
                            .RowCount() > 0;
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while validating unique Account:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return exist;
        }
        public void saveFirmAccount(FirmAccountDTO firmAccountDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        FirmAccount firmAccount = DTOToDomainUtil.populateFirmAccountAddFields(firmAccountDto);
                        Firm firm = session.QueryOver<Firm>().Where(f => f.FirmNumber == firmAccountDto.FirmNumber).SingleOrDefault<Firm>();
                        firmAccount.Firm = firm;
                        session.Save(firmAccount);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Updating Account:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void updateFirmAccount(FirmAccountDTO firmAccountDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        FirmAccount firmAccount = session.Get<FirmAccount>(firmAccountDto.Id);
                        DTOToDomainUtil.populateFirmAccountUpdateFields(firmAccount, firmAccountDto);
                        session.Update(firmAccount);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Updating Account:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void deleteFirmAccount(long accountId)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        //TODO - need to validate whether account cannot be deleted is account balance is not 0
                        FirmAccount firmAccount = session.Get<FirmAccount>(accountId);
                        session.Delete(firmAccount);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Deleting Account:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        private void populateFirm(Firm firm, FirmDTO firmDto)
        {
            firm.RegistrationNo = firmDto.RegistrationNo;
            firm.WebSite = firmDto.WebSite;
            firm.Description = firmDto.Description;
            DTOToDomainUtil.copyToContactInfo(firm.ContactInfo, firmDto.ContactInfo);
            firm.UpdateDate = DateUtil.getUserLocalDateTime();
            firm.UpdateUser = firmDto.UpdateUser;
        }
        public FirmDTO populateFirmDTO(Firm firm)
        {
            FirmDTO firmDto = DomainToDTOUtil.convertToFirmDTO(firm, true);
            firmDto.FirmAccounts = new HashSet<FirmAccountDTO>();
            foreach (FirmAccount firmAcnt in firm.FirmAccounts)
            {
                firmDto.FirmAccounts.Add(DomainToDTOUtil.convertToFirmAccountDTO(firmAcnt, true));
            }
            return firmDto;
        }
        public FirmAccountDTO fetchFirmAccount(long Id)
        {
            ISession session = null;
            FirmAccountDTO firmAccountDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        FirmAccount firmAccount = session.Get<FirmAccount>(Id);
                        firmAccountDto = DomainToDTOUtil.convertToFirmAccountDTO(firmAccount, true);
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while fetching Account:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return firmAccountDto;
        }
        public IList<AccountTransactionDTO> fetchAccountTransactions(string firmNumber, long Id, DateTime startDate)
        {
            ISession session = null;
            IList<AccountTransactionDTO> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        FirmAccount fa = null;
                        AccountTransaction a = null;

                        AccountTransactionDTO aDto = null;
                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => a.Id).WithAlias(() => aDto.Id))
                                    .Add(Projections.Property(() => a.TxDate).WithAlias(() => aDto.TxDate))
                                    .Add(Projections.Property(() => a.Amount).WithAlias(() => aDto.Amount))
                                    .Add(Projections.Property(() => a.TxType).WithAlias(() => aDto.TxType))
                                    .Add(Projections.Property(() => a.Comments).WithAlias(() => aDto.Comments));
                        var query = session.QueryOver<AccountTransaction>(() => a)
                            .Left.JoinAlias(() => a.FirmAccount, () => fa);
                        result = query.Where(() => a.FirmNumber == firmNumber && fa.Id == Id && a.TxDate >= startDate)
                                    .OrderBy(() => a.TxDate).Desc().ThenBy(() => a.InsertDate).Desc()
                                    .Select(proj)
                                    .TransformUsing(new DeepTransformer<AccountTransactionDTO>()).List<AccountTransactionDTO>();
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while fetching Account transactions:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public IList<TallyConfigDTO> fetchTallyConfigs(string FirmNumber)
        {
        	ISession session = null;
        	IList<TallyConfigDTO> result = new List<TallyConfigDTO>();
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				IList<TallyConfig> tmpResult = session.QueryOver<TallyConfig>().Where(x => x.FirmNumber == FirmNumber).List<TallyConfig>();
        				if(tmpResult != null) {
        					foreach(TallyConfig tmpObj in tmpResult) {
        						TallyConfigDTO tmpDTO = DomainToDTOUtil.convertToTallyConfigDTO(tmpObj);
        						result.Add(tmpDTO);
        					}
        				}
        			} catch (Exception e)
        			{
        				log.Error("Exception while fetching Tally Configurations:", e);
        				throw new CustomException(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        	return result;
        }
        public void saveOrUpdateTallyConfig(TallyConfigDTO tmpDTO)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				TallyConfig tmpObj = null;
        				if(tmpDTO.Id > 0) {
        					tmpObj = session.Get<TallyConfig>(tmpDTO.Id);
        					DTOToDomainUtil.populateTallyConfigUpdateFields(tmpObj, tmpDTO);
        					session.Update(tmpObj);
        				} else {
        					tmpObj = DTOToDomainUtil.populateTallyConfigAddFields(tmpDTO);
        					session.Save(tmpObj);
        					tmpDTO.Id = tmpObj.Id;
        				}
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while adding or updating Tally Configurations:", e);
        				throw new CustomException(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
        public void deleteTallyConfig(long Id)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				TallyConfig tmpObj = session.Get<TallyConfig>(Id);
        				session.Delete(tmpObj);
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while deleting Tally Configuration:", e);
        				throw new CustomException(CommonUtil.getActualErrorMsg(e, "Tally Configuration"));
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
        public IList<SubscriptionPlanDTO> fetchSubscriptionPlans(string FirmNumber)
        {
            ISession session = null;
            IList<SubscriptionPlanDTO> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	SubscriptionPlan p = null;
                    	Firm f = null;
                         
                        SubscriptionPlanDTO pDto = null;
                        var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => p.Id).WithAlias(() => pDto.Id))
                                .Add(Projections.Property(() => p.Name).WithAlias(() => pDto.Name))
                                .Add(Projections.Property(() => p.PurchaseDate).WithAlias(() => pDto.PurchaseDate))
                                .Add(Projections.Property(() => p.StartDate).WithAlias(() => pDto.StartDate))
                                .Add(Projections.Property(() => p.EndDate).WithAlias(() => pDto.EndDate))
                                .Add(Projections.Property(() => p.NoOfUsers).WithAlias(() => pDto.NoOfUsers))
                                .Add(Projections.Property(() => p.PurchaseType).WithAlias(() => pDto.PurchaseType))
                                .Add(Projections.Property(() => p.Status).WithAlias(() => pDto.Status));
                        var query = session.QueryOver<SubscriptionPlan>(() => p)
	                    		.Inner.JoinAlias(() => p.Firm, () => f);
	                    result = query.Where(() => f.FirmNumber == FirmNumber).Select(proj)
	                    			.OrderBy(() => p.StartDate).Desc()
	                                .TransformUsing(new DeepTransformer<SubscriptionPlanDTO>()).List<SubscriptionPlanDTO>();
	                   
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading all Subscription plans for given Firm:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public IList<SubscriptionPlanDTO> fetchUserSubscriptionPlans(string FirmNumber, long FirmMemberId)
        {
            ISession session = null;
            IList<SubscriptionPlanDTO> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	SubscriptionPlan p = null;
                    	Firm f = null;
                    	FirmMember fm = null;
                         
                        SubscriptionPlanDTO pDto = null;
                        var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => p.Id).WithAlias(() => pDto.Id))
                                .Add(Projections.Property(() => p.Name).WithAlias(() => pDto.Name))
                                .Add(Projections.Property(() => p.PurchaseDate).WithAlias(() => pDto.PurchaseDate))
                                .Add(Projections.Property(() => p.StartDate).WithAlias(() => pDto.StartDate))
                                .Add(Projections.Property(() => p.EndDate).WithAlias(() => pDto.EndDate))
                                .Add(Projections.Property(() => p.NoOfUsers).WithAlias(() => pDto.NoOfUsers))
                                .Add(Projections.Property(() => p.PurchaseType).WithAlias(() => pDto.PurchaseType))
                                .Add(Projections.Property(() => p.Status).WithAlias(() => pDto.Status));
                        var query = session.QueryOver<SubscriptionPlan>(() => p)
	                    		.Inner.JoinAlias(() => p.Firm, () => f)
	                    		.Inner.JoinAlias(() => p.Users, () => fm);
	                    result = query.Where(() => f.FirmNumber == FirmNumber && fm.Id == FirmMemberId).Select(proj)
	                    			.OrderBy(() => p.StartDate).Desc()
	                                .TransformUsing(new DeepTransformer<SubscriptionPlanDTO>()).List<SubscriptionPlanDTO>();
	                   
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading all Subscription plans for given Firm and user:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public SubscriptionPlanDTO fetchSubscriptionPlanDetails(long Id, bool FetchUsersInPlan)
        {
            ISession session = null;
            SubscriptionPlanDTO tmpDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	SubscriptionPlan tmpObj = session.Get<SubscriptionPlan>(Id);
                    	tmpDto = DomainToDTOUtil.convertToSubscriptionPlanDTO(tmpObj, true);
                    	tmpDto.Users = new List<FirmMemberDTO>();
                    	if(FetchUsersInPlan) {
                        	UserDefinition ud = null;
                            ContactInfo ci = null;
                            FirmMember fm = null;
                            SubscriptionPlan sp = null;

                            FirmMember fmDto = null;                        	
                        	var proj = Projections.ProjectionList()
                                	.Add(Projections.Property(() => fm.Id).WithAlias(() => fmDto.Id))
	                                .Add(Projections.Property(() => fm.FirstName).WithAlias(() => fmDto.FirstName))
	                                .Add(Projections.Property(() => fm.LastName).WithAlias(() => fmDto.LastName))
	                                .Add(Projections.Property(() => ci.Contact), "ContactInfo.Contact")
	                                .Add(Projections.Property(() => ud.Username), "User.Username")
	                                .Add(Projections.Property(() => ud.Status), "User.Status");
    	                    var query = session.QueryOver<SubscriptionPlan>(() => sp)
    	                                .Inner.JoinQueryOver(() => sp.Users, () => fm)
    	                                .Inner.JoinQueryOver(() => fm.User, () => ud)
    	                                .Inner.JoinQueryOver(() => fm.ContactInfo, () => ci);
                            IList<FirmMemberDTO> result = query.Where(() => sp.Id == tmpObj.Id)
    	                        .Select(proj)
    	                        .TransformUsing(new DeepTransformer<FirmMemberDTO>()).List<FirmMemberDTO>();
    	                    foreach(FirmMemberDTO tmpFMDTO in result) {
    	                    	tmpFMDTO.FullName = CommonUIConverter.getCustomerFullName(tmpFMDTO.FirstName, tmpFMDTO.LastName);
    	                    	tmpDto.Users.Add(tmpFMDTO);
    	                    }
                        }
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while Loading Subscription plan details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return tmpDto;
        }
        public void saveOrUpdateSubscriptionPlan(SubscriptionPlanDTO tmpDTO, bool UpdateUsers)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				SubscriptionPlan tmpObj = null;
        				if(tmpDTO.Id > 0) {
        					tmpObj = session.Get<SubscriptionPlan>(tmpDTO.Id);
        					DTOToDomainUtil.populateSubscriptionPlanUpdateFields(tmpObj, tmpDTO);
        					session.Update(tmpObj);
        				} else {
        					tmpObj = DTOToDomainUtil.populateSubscriptionPlanAddFields(tmpDTO);
        					session.Save(tmpObj);
        					tmpDTO.Id = tmpObj.Id;
        				}
        				if (UpdateUsers) {
        					tmpObj.Users.Clear();
            				foreach (FirmMemberDTO tmpFMDTO in tmpDTO.Users)
                    		{
                    			FirmMember newFirmMember = new FirmMember();
                				newFirmMember.Id = tmpFMDTO.Id;
                				tmpObj.Users.Add(newFirmMember);
                    		}
            				session.Update(tmpObj);
        				}
        				
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while adding or updating Subscription Plan:", e);
        				throw new CustomException(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
        public SubscriptionPlanDTO fetchActiveSubscriptionPlan(string FirmNumber, bool fetchAllFields)
        {
            ISession session = null;
            SubscriptionPlanDTO tmpDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	SubscriptionPlan p = null;
                    	Firm f = null;

                        SubscriptionPlan tmpObj = session.QueryOver<SubscriptionPlan>(() => p)
	                    		.Inner.JoinAlias(() => p.Firm, () => f).Where(() => f.FirmNumber == FirmNumber && p.Status == SubscriptionPlanStatus.Active)
	                    		.SingleOrDefault<SubscriptionPlan>();
                        if (tmpObj != null)
                        {
                            tmpDto = DomainToDTOUtil.convertToSubscriptionPlanDTO(tmpObj, fetchAllFields);
                        }
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while Loading active Subscription plan details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return tmpDto;
        }
        public void MarkSubscriptionPlanAsConsumed(long PlanId, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        SubscriptionPlan tmpObj = session.Get<SubscriptionPlan>(PlanId);
                        tmpObj.Status = SubscriptionPlanStatus.Consumed;
                        tmpObj.UpdateDate = DateUtil.getUserLocalDateTime();
                        tmpObj.UpdateUser = userDefDTO.Username;
                        if (tmpObj.Users.Count > 0)
                        {
                    		//When plan is consumed then deactivate users which are active. NOTE: Suspended will not be made inactive
                            foreach (FirmMember fm in tmpObj.Users)
                            {
                        		if (fm.User.Status == UserStatus.Active) {
                                    fm.User.Status = UserStatus.InActive;
                                    fm.User.UpdateDate = DateUtil.getUserLocalDateTime();
                                    fm.User.UpdateUser = userDefDTO.Username;
                                    session.Update(fm.User);
                        		}
                        	}
                        }
                        session.Update(tmpObj);
                        tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
                        log.Error("Exception while marking Subscription plan as consumed:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public long ActivateUpcomingSubscriptionPlan(string FirmNumber, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            List<EmailDTO> tmpEmailList = new List<EmailDTO>();
            long ActivePlanId = 0;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	SubscriptionPlan p = null;
                    	Firm f = null;
                    	DateTime Today = DateUtil.getUserLocalDate();
                    	
                    	var query = session.QueryOver<SubscriptionPlan>(() => p)
	                    		.Inner.JoinAlias(() => p.Firm, () => f);
	                    IList<SubscriptionPlan> result = query.Where(() => f.FirmNumber == FirmNumber && p.Status == SubscriptionPlanStatus.Upcoming
	                    		&& p.StartDate <= Today && p.EndDate >= Today).List<SubscriptionPlan>();
	                    if (result != null && result.Count > 0) {
	                    	SubscriptionPlan tmpPlanObj = result[0];
                            if (tmpPlanObj.Users.Count > 0)
                            {
	                    		//When plan is activated then activate users which are inactive. NOTE: Suspended will not be made active
                                foreach (FirmMember fm in tmpPlanObj.Users)
                                {
                                	UserDefinition User = fm.User;
	                        		if (User.Status == UserStatus.InActive) {
                                        if (string.IsNullOrWhiteSpace(User.SecurityAnswer))
                                        {
                                            User.Password = CommonUtil.Encrypt(ApplicationUtil.GenerateRandomPassword());
                                            User.IsTempPassword = IsTempPassword.Yes;
                                            User.Status = UserStatus.Setup;

                                            tmpEmailList.Add(EmailSMSUtil.populateEmailForUser(User));
	                            		} else {
                                            User.Status = UserStatus.Active;
	                            		}
                                        User.UpdateDate = DateUtil.getUserLocalDateTime();
                                        User.UpdateUser = userDefDTO.Username;
                                        session.Update(User);
	                        		}
	                        	}
	                        }
	                    	tmpPlanObj.Status = SubscriptionPlanStatus.Active;
                    		tmpPlanObj.UpdateDate = DateUtil.getUserLocalDateTime();
                    		tmpPlanObj.UpdateUser = userDefDTO.Username;
                    		session.Update(tmpPlanObj);
	                        tx.Commit();
	                        
	                        ActivePlanId = tmpPlanObj.Id;
	                    }
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				tmpEmailList.Clear();
                        log.Error("Exception while Activating Subscription plan:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            EmailSMSUtil.SendSystemEmail(Constants.SYSDEFAULT_EMAIL_SMS_TEMPLATE.USER_ACNT_SETUP, tmpEmailList.ToArray());
            return ActivePlanId;
        }
        public IList<FirmMemberDTO> fetchUsersForSubscriptionPlan(long PlanId, string FirmNumber)
        {
            ISession session = null;
            IList<FirmMemberDTO> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        UserDefinition ud = null;
                        ContactInfo ci = null;
                        FirmMember fm = null;
                        SubscriptionPlan sp = null;

                        FirmMemberDTO fmDto = null;
                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => fm.Id).WithAlias(() => fmDto.Id))
                                    .Add(Projections.Property(() => fm.FirstName).WithAlias(() => fmDto.FirstName))
                                    .Add(Projections.Property(() => fm.LastName).WithAlias(() => fmDto.LastName))
                                    .Add(Projections.Property(() => ci.Contact), "ContactInfo.Contact")
                                    .Add(Projections.Property(() => ud.Username), "User.Username")
                                    .Add(Projections.Property(() => ud.Status), "User.Status");
                        var query = session.QueryOver<UserDefinition>(() => ud)
                                    .Inner.JoinQueryOver(() => ud.FirmMember, () => fm)
                                    .Inner.JoinQueryOver(() => fm.ContactInfo, () => ci);
                        result = query.Where(() => ud.FirmNumber == FirmNumber)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<FirmMemberDTO>()).List<FirmMemberDTO>();

                        var proj1 = Projections.ProjectionList()
                                	.Add(Projections.Property(() => fm.Id).WithAlias(() => fmDto.Id))
	                                .Add(Projections.Property(() => fm.FirstName).WithAlias(() => fmDto.FirstName))
	                                .Add(Projections.Property(() => fm.LastName).WithAlias(() => fmDto.LastName))
	                                .Add(Projections.Property(() => ci.Contact), "ContactInfo.Contact")
	                                .Add(Projections.Property(() => ud.Username), "User.Username")
	                                .Add(Projections.Property(() => ud.Status), "User.Status");
	                    var query1 = session.QueryOver<SubscriptionPlan>(() => sp)
	                                .Inner.JoinQueryOver(() => sp.Users, () => fm)
	                                .Inner.JoinQueryOver(() => fm.User, () => ud)
	                                .Inner.JoinQueryOver(() => fm.ContactInfo, () => ci);
	                    IList<FirmMemberDTO> result1 = query1.Where(() => sp.Id == PlanId)
	                        .Select(proj1)
	                        .TransformUsing(new DeepTransformer<FirmMemberDTO>()).List<FirmMemberDTO>();
	                    List<FirmMemberDTO> tmpAccessList = result1.ToList<FirmMemberDTO>();
	                    foreach(FirmMemberDTO tmpDTO in result) {
	                    	tmpDTO.IsSelectedForPlan = tmpAccessList.Any(x => x.Id == tmpDTO.Id);
                            tmpDTO.FullName = CommonUIConverter.getCustomerFullName(tmpDTO.FirstName, tmpDTO.LastName);
                            tmpDTO.User.ProfileImagePath = CommonUtil.getUIUserProfilePathRelative(tmpDTO.User.Username);
	                    }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching users for Subscription Plan:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }

                }
                return result;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public IList<UserEntitlementDTO> fetchEntitlements()
        {
            ISession session = null;
            IList<UserEntitlementDTO> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        UserEntitlement e = null;
                        UserEntitlement e1 = null;
                        Firm f = null;

                        UserEntitlementDTO eDto = null;
                        var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => e.Id).WithAlias(() => eDto.Id))
                                .Add(Projections.Property(() => e.Name).WithAlias(() => eDto.Name))
                                .Add(Projections.Property(() => e.Description).WithAlias(() => eDto.Description))
                                .Add(Projections.Property(() => e.Level).WithAlias(() => eDto.Level))
                                .Add(Projections.Property(() => e1.Id), "Parent.Id")
                                .Add(Projections.Property(() => e1.Name), "Parent.Name");
                        var query = session.QueryOver<UserEntitlement>(() => e)
                                .Left.JoinAlias(() => e.Parent, () => e1);
                        result = query.Select(proj)
                                    .OrderBy(() => e.Level).Asc()
                                    .TransformUsing(new DeepTransformer<UserEntitlementDTO>()).List<UserEntitlementDTO>();

                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading all Entitlements:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public void saveOrUpdateUserEntitlement(UserEntitlementDTO tmpDTO)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				UserEntitlement tmpObj = null;
        				if(tmpDTO.Id > 0) {
        					tmpObj = session.Get<UserEntitlement>(tmpDTO.Id);
        					DTOToDomainUtil.populateUserEntitlementUpdateFields(tmpObj, tmpDTO);
        					session.Update(tmpObj);
        				} else {
        					tmpObj = DTOToDomainUtil.populateUserEntitlementAddFields(tmpDTO);
        					session.Save(tmpObj);
        					tmpDTO.Id = tmpObj.Id;
        				}
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while adding or updating User Entitlement:", e);
        				throw new CustomException(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
        public void deleteUserEntitlement(long Id)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				UserEntitlement tmpObj = session.Get<UserEntitlement>(Id);

        				session.Delete(tmpObj);
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while deleting UserEntitlement Configuration:", e);
        				throw new CustomException(CommonUtil.getActualErrorMsg(e, "User Entitlement"));
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
        public void deleteUserEntitlements(List<UserEntitlementDTO> tmpList)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        foreach (UserEntitlementDTO tmpDTO in tmpList)
                        {
                            UserEntitlement tmpObj = session.Get<UserEntitlement>(tmpDTO.Id);
                            session.Delete(tmpObj);
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while deleting User Entitlement:", e);
                        throw new CustomException(CommonUtil.getActualErrorMsg(e, "User Entitlement"));
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
    }
}