﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using NHibernate;
using NHibernate.Criterion;

namespace ConstroSoft.Logic.BO
{
    public class LeadEnquiryReportBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        
        public LeadEnquiryReportBO() { }
        
        public object[] fetchLeadStatsForReport(long PropertyId, DateTime startDate, DateTime toDate)
        {
            ISession session = null;
            object[] result = new Object[3];
            LeadsOpenedGadgetDTO leadsOpenedGadgetDTO = new LeadsOpenedGadgetDTO();
            leadsOpenedGadgetDTO.LeadsOpenedList = new List<LeadsOpenedCountDTO>();
            List<EnquiryLeadSourceWiseCountDTO> LeadSrcDistList = new List<EnquiryLeadSourceWiseCountDTO>();
            LeadsProcessedCountDTO leadsProcessedDto = new LeadsProcessedCountDTO();
            IList<LeadDetailDTO> tmpResultList = new List<LeadDetailDTO>();

            result[0] = leadsOpenedGadgetDTO;
            result[1] = LeadSrcDistList;
            result[2] = leadsProcessedDto;

            DateTime EndDate = toDate;
            DateTime StartDate = startDate;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        LeadDetail ld = null;
                        MasterControlData es = null;
                        Property p = null;

                        LeadDetailDTO ldDTO = null;

                        var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => ld.LeadDate).WithAlias(() => ldDTO.LeadDate))
                                .Add(Projections.Property(() => ld.DateClosed).WithAlias(() => ldDTO.DateClosed))
                                .Add(Projections.Property(() => ld.Status).WithAlias(() => ldDTO.Status))
                                .Add(Projections.Property(() => es.Name), "Source.Name");

                        var query = session.QueryOver<LeadDetail>(() => ld)
                                .Left.JoinAlias(() => ld.Property, () => p)
                                .Left.JoinAlias(() => ld.Source, () => es)
                                .Select(proj);
                        tmpResultList = query.Where(() => p.Id == PropertyId
                                     && ((ld.LeadDate >= StartDate && ld.LeadDate <= EndDate)
                                             || (ld.DateClosed >= StartDate && ld.DateClosed <= EndDate)))
                                 .TransformUsing(new DeepTransformer<LeadDetailDTO>())
                                 .List<LeadDetailDTO>();

                        foreach (LeadDetailDTO tmpDTO in tmpResultList)
                        {
                            //Create stats for new Leads Opened gadget -> New leads and Source wise distrubtion
                            if (tmpDTO.LeadDate.CompareTo(StartDate) >= 0 && tmpDTO.LeadDate.CompareTo(EndDate) <= 0)
                            {
                                leadsOpenedGadgetDTO.TotalCount++;
                                //Daily new opened leads
                                //Source wise distribution.
                                EnquiryLeadSourceWiseCountDTO srcCountDTO = LeadSrcDistList.Find(x => x.SourceName == tmpDTO.Source.Name);
                                if (srcCountDTO == null)
                                {
                                    srcCountDTO = new EnquiryLeadSourceWiseCountDTO();
                                    srcCountDTO.SourceName = tmpDTO.Source.Name;
                                    LeadSrcDistList.Add(srcCountDTO);
                                }
                                srcCountDTO.Count++;
                            }
                            if (tmpDTO.Status != LeadStatus.Open && tmpDTO.DateClosed.Value.CompareTo(StartDate) >= 0 && tmpDTO.DateClosed.Value.CompareTo(EndDate) <= 0)
                            {
                                leadsProcessedDto.TotalProcessed++;
                                if (tmpDTO.Status == LeadStatus.Converted) leadsProcessedDto.TotalConverted++;
                                else leadsProcessedDto.TotalLost++;
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching Lead Stats:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }

        public object[] fetchEnquiryStatsForReport(long PropertyId, DateTime startDate, DateTime toDate)
        {
            ISession session = null;
            object[] result = new Object[4];
            List<EnquiryLeadSourceWiseCountDTO> enqSrcDistList = new List<EnquiryLeadSourceWiseCountDTO>();
            List<EnquiryNewOpenAndCloseCountDTO> enqOpenClosedCountList = new List<EnquiryNewOpenAndCloseCountDTO>();
            List<EnquiryCurrentOpenCountDTO> enqCurrentOpenList = new List<EnquiryCurrentOpenCountDTO>();
            EnquiryCountStatsDTO enqCountStatsDTO = new EnquiryCountStatsDTO();

            result[0] = enqSrcDistList;
            result[1] = enqOpenClosedCountList;
            result[2] = enqCurrentOpenList;
            result[3] = enqCountStatsDTO;

            IList<EnquiryDetailDTO> tmpResultList = new List<EnquiryDetailDTO>();
            Dictionary<DateTime, int> statsForDailyOpen = new Dictionary<DateTime, int>();

            DateTime StartDate = startDate;
            DateTime EndDate = toDate;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EnquiryDetail ed = null;
                        MasterControlData es = null;
                        Property p = null;

                        EnquiryDetailDTO edDTO = null;

                        var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => ed.EnquiryDate).WithAlias(() => edDTO.EnquiryDate))
                                .Add(Projections.Property(() => ed.DateClosed).WithAlias(() => edDTO.DateClosed))
                                .Add(Projections.Property(() => ed.Status).WithAlias(() => edDTO.Status))
                                .Add(Projections.Property(() => es.Name), "EnquirySource.Name");

                        var query = session.QueryOver<EnquiryDetail>(() => ed)
                                .Left.JoinAlias(() => ed.Property, () => p)
                                .Left.JoinAlias(() => ed.EnquirySource, () => es)
                                .Select(proj);
                        tmpResultList = query.Where(() => p.Id == PropertyId
                                     && ((ed.EnquiryDate >= StartDate && ed.EnquiryDate <= EndDate)
                                             || (ed.DateClosed >= StartDate && ed.DateClosed <= EndDate)))
                                 .TransformUsing(new DeepTransformer<EnquiryDetailDTO>())
                                 .List<EnquiryDetailDTO>();

                        foreach (EnquiryDetailDTO tmpDTO in tmpResultList)
                        {
                            //Create stats for new Enquiry Opened and Closed gadget
                            if (tmpDTO.EnquiryDate.CompareTo(StartDate) >= 0 && tmpDTO.EnquiryDate.CompareTo(EndDate) <= 0)
                            {
                                enqCountStatsDTO.TotalLogged++;

                                //Enquiry opened in week.


                                //Source wise distribution.
                                EnquiryLeadSourceWiseCountDTO srcCountDTO = enqSrcDistList.Find(x => x.SourceName == tmpDTO.EnquirySource.Name);
                                if (srcCountDTO == null)
                                {
                                    srcCountDTO = new EnquiryLeadSourceWiseCountDTO();
                                    srcCountDTO.SourceName = tmpDTO.EnquirySource.Name;
                                    enqSrcDistList.Add(srcCountDTO);
                                }
                                srcCountDTO.Count++;

                                //Stats for Daily Open Enquiry
                                if (statsForDailyOpen.ContainsKey(tmpDTO.EnquiryDate))
                                {
                                    statsForDailyOpen[tmpDTO.EnquiryDate] += 1;
                                }
                                else
                                {
                                    statsForDailyOpen.Add(tmpDTO.EnquiryDate, 1);
                                }
                            }
                            if (tmpDTO.Status != EnquiryStatus.Open && tmpDTO.DateClosed.Value.CompareTo(StartDate) >= 0 && tmpDTO.DateClosed.Value.CompareTo(EndDate) <= 0)
                            {
                                enqCountStatsDTO.TotalClosed++;
                                //Enquiry Closed in week.

                                //Stats for Daily Open Enquiry
                                if (statsForDailyOpen.ContainsKey(tmpDTO.DateClosed.Value))
                                {
                                    statsForDailyOpen[tmpDTO.DateClosed.Value] -= 1;
                                }
                                else
                                {
                                    statsForDailyOpen.Add(tmpDTO.DateClosed.Value, -1);
                                }
                            }
                        }

                        //Create Stats for Daily Open Enquiry
                        int OpenEnquiry = session.QueryOver<EnquiryDetail>(() => ed)
                                .Left.JoinAlias(() => ed.Property, () => p)
                                .Left.JoinAlias(() => ed.EnquirySource, () => es)
                                .Where(() => p.Id == PropertyId && ed.EnquiryDate < StartDate && (ed.DateClosed == null || ed.DateClosed > StartDate)).RowCount();
                        DateTime tmpEnqDate = StartDate;
                        int openCount = OpenEnquiry;
                        do
                        {
                            if (statsForDailyOpen.ContainsKey(tmpEnqDate))
                            {
                                openCount = openCount + statsForDailyOpen[tmpEnqDate];
                            }
                            EnquiryCurrentOpenCountDTO tmpDto = new EnquiryCurrentOpenCountDTO();
                            tmpDto.Date = DateUtil.getCSDate(tmpEnqDate);
                            tmpDto.OpenCount = openCount;
                            enqCurrentOpenList.Add(tmpDto);
                            tmpEnqDate = tmpEnqDate.AddDays(1);
                        } while (tmpEnqDate.CompareTo(EndDate) <= 0);

                        //Total Open on period end date.
                        enqCountStatsDTO.TotalOpen = openCount;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching Enquiry Count Stats:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        
    }
}