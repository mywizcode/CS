﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;
using System.IO;


/// <summary>
/// Summary description for EmployeeBO
/// </summary>
namespace ConstroSoft
{
    public class PropertyUserBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public PropertyUserBO() { }

        public IList<FirmMemberDTO> fetchPropertyAccessUsers(string firmNumber, long propertyId)
        {
            ISession session = null;
            IList<FirmMemberDTO> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	UserDefinition ud = null;
                        PropertyFMAccess pfa = null;
                        Property p = null;
                        FirmMember fm = null;
                        ContactInfo ci = null;

                        FirmMemberDTO fmDTO = null;
                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => fm.Id).WithAlias(() => fmDTO.Id))
                                    .Add(Projections.Property(() => fm.FirstName).WithAlias(() => fmDTO.FirstName))
                                    .Add(Projections.Property(() => fm.LastName).WithAlias(() => fmDTO.LastName))
                                    .Add(Projections.Property(() => ci.Contact), "ContactInfo.Contact")
                                    .Add(Projections.Property(() => ud.Id), "User.Id")
                                    .Add(Projections.Property(() => ud.Username), "User.Username")
                                    .Add(Projections.Property(() => ud.Status), "User.Status");
                        IList<FirmMemberDTO> allUsers = session.QueryOver<FirmMember>(() => fm)
                                    .Inner.JoinQueryOver(() => fm.User, () => ud)
                                    .Inner.JoinQueryOver(() => fm.ContactInfo, () => ci)
                                    .Where(() => fm.FirmNumber == firmNumber)
                                    .Select(proj)
                                    .TransformUsing(new DeepTransformer<FirmMemberDTO>()).List<FirmMemberDTO>();

                        
                        var proj1 = Projections.ProjectionList()
                                    .Add(Projections.Property(() => fm.Id).WithAlias(() => fmDTO.Id))
                                    .Add(Projections.Property(() => pfa.HasAccess).WithAlias(() => fmDTO.hasPropertyAccess));   
                        var query = session.QueryOver<FirmMember>(() => fm)
                                     .Inner.JoinQueryOver(() => fm.User, () => ud)
                                    .Left.JoinQueryOver(() => fm.PropertyFMAccess, () => pfa)
                                    .Left.JoinQueryOver(() => pfa.Property, () => p);
                        IList<FirmMemberDTO> assignedUsers = query.Where(() => ud.FirmNumber == firmNumber && p.Id == propertyId)
                            .Select(proj1)
                            .TransformUsing(new DeepTransformer<FirmMemberDTO>()).List<FirmMemberDTO>();
                        List<FirmMemberDTO> assignedUsersList = assignedUsers.ToList<FirmMemberDTO>();
                        foreach (FirmMemberDTO tmpDTO in allUsers)
                        {
                            tmpDTO.FullName = CommonUIConverter.getCustomerFullName(tmpDTO.FirstName, tmpDTO.LastName);
							if (assignedUsersList.Exists(x => x.Id == tmpDTO.Id)) {
	                            tmpDTO.hasPropertyAccess = assignedUsersList.Find(x => x.Id == tmpDTO.Id).hasPropertyAccess;
	                        }else {
                        		tmpDTO.hasPropertyAccess = PrFMAccess.No;
						    }
                            tmpDTO.User.ProfileImagePath = CommonUtil.getUIUserProfilePathRelative(tmpDTO.User.Username);
                        }
                        result = allUsers;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Unexpected error fetching property user access:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public long updatePropertyAccess(long propertyId, List<FirmMemberDTO> firmMemberList, PrFMAccess hasAccess)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        foreach (FirmMemberDTO tmpDTO in firmMemberList)
                        {
                            PropertyFMAccess userAccess = new PropertyFMAccess();
                            userAccess.Property = new Property();
                            userAccess.Property.Id = propertyId;
                            userAccess.FirmMember = new FirmMember();
                            userAccess.FirmMember.Id = tmpDTO.Id;
                            userAccess.HasAccess = hasAccess;
                            session.SaveOrUpdate(userAccess);
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while assigning or unassigning property to user:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }

                }
                return Id;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public PropertyDTO fetchPropertyVirtualPhones(long propertyId)
        {
            ISession session = null;
            PropertyDTO propertyDTO = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	Property property = session.Get<Property>(propertyId);
                    	propertyDTO = new PropertyDTO();
                    	propertyDTO.Id = property.Id;
                    	propertyDTO.Name = property.Name;
                    	propertyDTO.PropertyLocation = new MasterControlDataDTO();
                    	propertyDTO.PropertyLocation.Name = property.PropertyLocation.Name;
                    	propertyDTO.PropertyType = new MasterControlDataDTO();
                    	propertyDTO.PropertyType.Name = property.PropertyType.Name;
                    	propertyDTO.ReraRegNo = property.ReraRegNo;
                    	propertyDTO.VirtualPhones = new HashSet<VirtualPhoneDTO>();
                    	foreach(VirtualPhone virtualPhone in property.VirtualPhones) {
                    		VirtualPhoneDTO tmpDTO = new VirtualPhoneDTO();
                    		tmpDTO.Id = virtualPhone.Id;
                    		tmpDTO.PhoneNumber = virtualPhone.PhoneNumber;
                    		tmpDTO.PhoneType = virtualPhone.PhoneType;
                            tmpDTO.NoOfAssignedUsers = virtualPhone.Users.Count;
                            propertyDTO.VirtualPhones.Add(tmpDTO);
                    	}                    	
                    }

                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching virtualPhone for property:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }

                }
                return propertyDTO;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public IList<FirmMemberDTO> fetchUsersForVitualPhone(long vPhoneId, long propertyId)
        {
            ISession session = null;
            IList<FirmMemberDTO> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        UserDefinition ud = null;
                        PropertyFMAccess pfa = null;
                        Property p = null;
                        ContactInfo ci = null;
                        FirmMember fm = null;
                        VirtualPhone vp = null;

                        FirmMemberDTO fmDto = null;
                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => fm.Id).WithAlias(() => fmDto.Id))
                                    .Add(Projections.Property(() => fm.FirstName).WithAlias(() => fmDto.FirstName))
                                    .Add(Projections.Property(() => fm.LastName).WithAlias(() => fmDto.LastName))
                                    .Add(Projections.Property(() => ci.Contact), "ContactInfo.Contact")
                                    .Add(Projections.Property(() => ud.Username), "User.Username")
                                    .Add(Projections.Property(() => ud.Status), "User.Status");
                        var query = session.QueryOver<UserDefinition>(() => ud)
                                    .Inner.JoinQueryOver(() => ud.FirmMember, () => fm)
                                    .Inner.JoinQueryOver(() => fm.ContactInfo, () => ci)
                                    .Left.JoinQueryOver(() => fm.PropertyFMAccess, () => pfa)
                                    .Left.JoinQueryOver(() => pfa.Property, () => p);
                        result = query.Where(() => p.Id == propertyId && pfa.HasAccess == PrFMAccess.Yes)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<FirmMemberDTO>()).List<FirmMemberDTO>();

                        var proj1 = Projections.ProjectionList()
                                	.Add(Projections.Property(() => fm.Id).WithAlias(() => fmDto.Id))
	                                .Add(Projections.Property(() => fm.FirstName).WithAlias(() => fmDto.FirstName))
	                                .Add(Projections.Property(() => fm.LastName).WithAlias(() => fmDto.LastName))
	                                .Add(Projections.Property(() => ci.Contact), "ContactInfo.Contact")
	                                .Add(Projections.Property(() => ud.Username), "User.Username")
	                                .Add(Projections.Property(() => ud.Status), "User.Status");
	                    var query1 = session.QueryOver<VirtualPhone>(() => vp)
	                                .Inner.JoinQueryOver(() => vp.Users, () => fm)
	                                .Inner.JoinQueryOver(() => fm.User, () => ud)
	                                .Inner.JoinQueryOver(() => fm.ContactInfo, () => ci);
	                    IList<FirmMemberDTO> result1 = query1.Where(() => vp.Id == vPhoneId)
	                        .Select(proj1)
	                        .TransformUsing(new DeepTransformer<FirmMemberDTO>()).List<FirmMemberDTO>();
	                    List<FirmMemberDTO> tmpAccessList = result1.ToList<FirmMemberDTO>();
	                    foreach(FirmMemberDTO tmpDTO in result) {
	                    	tmpDTO.hasAccessToVirtualPhone = tmpAccessList.Any(x => x.Id == tmpDTO.Id);
                            tmpDTO.FullName = CommonUIConverter.getCustomerFullName(tmpDTO.FirstName, tmpDTO.LastName);
                            tmpDTO.User.ProfileImagePath = CommonUtil.getUIUserProfilePathRelative(tmpDTO.User.Username);
	                    }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching users for selected virtual phone:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }

                }
                return result;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public long deletePropertyVirtualPhone(long virtualPhoneId)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        VirtualPhone virtualPhone = session.Get<VirtualPhone>(virtualPhoneId);
                        session.Delete(virtualPhone);
                        tx.Commit();
                    }

                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while deleting virtualPhone for property:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }

                }
                return Id;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void addOrUpdateVirtualPhone(VirtualPhoneDTO virtualPhoneDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        if (virtualPhoneDTO.Id > 0)
                        {
                            VirtualPhone virtualPhone = session.Get<VirtualPhone>(virtualPhoneDTO.Id);
                            virtualPhone.PhoneNumber = virtualPhoneDTO.PhoneNumber;
                            virtualPhone.PhoneType = virtualPhoneDTO.PhoneType;
                            virtualPhone.UpdateUser = virtualPhoneDTO.UpdateUser;
                            virtualPhone.UpdateDate = DateUtil.getUserLocalDateTime();
                            session.Update(virtualPhone);
                        }
                        else
                        {
                            VirtualPhone virtualPhone = new VirtualPhone();
                            virtualPhone.PhoneNumber = virtualPhoneDTO.PhoneNumber;
                            virtualPhone.PhoneType = virtualPhoneDTO.PhoneType;
                            virtualPhone.Property = new Property();
                            virtualPhone.Property.Id = virtualPhoneDTO.Property.Id;
                            virtualPhone.FirmNumber = virtualPhoneDTO.FirmNumber;
                            virtualPhone.InsertUser = virtualPhoneDTO.InsertUser;
                            virtualPhone.UpdateUser = virtualPhoneDTO.UpdateUser;
                            virtualPhone.InsertDate = DateUtil.getUserLocalDateTime();
                            virtualPhone.UpdateDate = DateUtil.getUserLocalDateTime();
                            session.Save(virtualPhone);
                        }
                        tx.Commit();
                    }

                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while adding or updating virtualPhone of property:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void addOrRemoveUsersForVirtualPhone(long virtualPhoneId, List<FirmMemberDTO> userList, bool isAssign)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        VirtualPhone virtualPhone = session.Get<VirtualPhone>(virtualPhoneId);
                        ISet<FirmMember> dbUsers = virtualPhone.Users;
                        List<FirmMember> dbUsersList = virtualPhone.Users.ToList<FirmMember>();
                        foreach(FirmMemberDTO userDTO in userList) {
                        	FirmMember firmMember = dbUsersList.Find(x => x.Id == userDTO.Id);
                        	if(!isAssign && firmMember != null) dbUsers.Remove(firmMember);
                        	else if (isAssign && firmMember == null){
                        		FirmMember tmpFirmMember = new FirmMember();
                        		tmpFirmMember.Id = userDTO.Id;
                        		dbUsers.Add(tmpFirmMember);
                        	}
                        }
                        session.Update(virtualPhone);
                        tx.Commit();
                    }

                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while assign and unassign of users for virtualPhone of property:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public IList<VirtualPhoneDTO> fetchOutgoingVitualPhonesAllocattedToUser(long firmMemberId, long propertyId)
        {
            ISession session = null;
            IList<VirtualPhoneDTO> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Property p = null;
                        FirmMember fm = null;
                        VirtualPhone vp = null;

                        VirtualPhoneDTO vpDto = null;
                        var proj = Projections.ProjectionList()
                                	.Add(Projections.Property(() => vp.Id).WithAlias(() => vpDto.Id))
	                                .Add(Projections.Property(() => vp.PhoneNumber).WithAlias(() => vpDto.PhoneNumber))
	                                .Add(Projections.Property(() => vp.PhoneType).WithAlias(() => vpDto.PhoneType));
	                    var query = session.QueryOver<VirtualPhone>(() => vp)
	                    			.Inner.JoinQueryOver(() => vp.Property, () => p)
	                                .Inner.JoinQueryOver(() => vp.Users, () => fm);
	                    result = query.Where(() => vp.PhoneType != PhoneType.Incoming && p.Id == propertyId && fm.Id == firmMemberId)
	                        .Select(proj)
	                        .TransformUsing(new DeepTransformer<VirtualPhoneDTO>()).List<VirtualPhoneDTO>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching outgoing virtual phone for given user and property:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }

                }
                return result;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
    }
}