﻿using System;
using NHibernate;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using NHibernate.Criterion;
using System.Web.Hosting;

/// <summary>
/// Summary description for SupplierBO
/// </summary>
namespace ConstroSoft
{
    public class LoginBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public LoginBO(){}

        public BusinessOutputTO validateUserOnLogin(string userName, string password)
        {
            BusinessOutputTO businessTO = new BusinessOutputTO();
            ISession session = null;
            log.Debug("Validating user login");
            bool result = false;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        UserDefinition userDef = session.QueryOver<UserDefinition>().Where(x => x.Username == userName).SingleOrDefault();
                        if (userDef != null)
                        {
                            string msg = IsValidUser(userDef);
                            if (!string.IsNullOrWhiteSpace(msg))
                            {
                                businessTO.setErrorMessage(msg);
                                result = true;
                            }
                            else if (password.Equals(CommonUtil.Decrypt(userDef.Password)))
                            {
                                log.Debug("Login Successful for user:" + userName);
                                UserDefinitionDTO userDTO = getUserDefinitionDTO(userDef, true);
                                userDTO.ProfileImagePath = CommonUtil.getUIUserProfilePathRelative(userDef.Username);
                                businessTO.result = userDTO;
                                result = true;
                            }
                        }
                        if (!result)
                        {
                            log.Debug("Login Failed for user:" + userName);
                            businessTO.setErrorMessage(Resources.Messages.ERROR_LOGIN_FAILED);
                        }
                    }
                    catch (Exception e)
                    {
                        log.Error("Unexpected error while login:" + userName, e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return businessTO;
        }
        private string IsValidUser(UserDefinition userDef)
        {
            UserStatus tmpStatus = userDef.Status;
            string errorMsg = "";
            if (!userDef.UserRole.Name.Equals(Constants.SYSDEFAULT.SYSADMIN_ROLE))
            {
                bool isPlanActive = false;
                ISet<SubscriptionPlan> planList = userDef.FirmMember.Plans;
                if (planList != null)
                {
                    foreach (SubscriptionPlan plan in planList)
                    {
                        if (plan.Status == SubscriptionPlanStatus.Active)
                        {
                            isPlanActive = true;
                            break;
                        }
                    }
                }
                if (!isPlanActive)
                {
                    errorMsg = "Subscription plan is not active. Please contact system administrator.";
                }
            }
            else if (tmpStatus == UserStatus.InActive)
            {
                errorMsg = Resources.Messages.ERROR_LOGIN_USER_DEACTIVE;
            }
            else if (tmpStatus == UserStatus.Suspended)
            {
                errorMsg = "User account has been suspended. Please contact system administrator.";
            }
            return errorMsg;
        }
        public bool validatePassword(string userName, string password)
        {
            ISession session = null;
            bool result = false;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        UserDefinition userDef = session.QueryOver<UserDefinition>().Where(x => x.Username == userName).SingleOrDefault(); ;
                        if (userDef != null && password.Equals(CommonUtil.Decrypt(userDef.Password)))
                        {
                            result = true;
                        }
                    }
                    catch (Exception e)
                    {
                        log.Error("Unexpected error while validating password:" + userName, e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public List<PropertyDTO> getAssignedProperties(long FirmMemberId)
        {
            ISession session = null;
            List<PropertyDTO> result = new List<PropertyDTO>();
            try
            {
                PropertyDTO pDto = null;
                Property p = null;
                MasterControlData pl = null;
                PropertyFMAccess pfa = null;
                FirmMember fm = null;

                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => p.Id).WithAlias(() => pDto.Id))
                            .Add(Projections.Property(() => p.Name).WithAlias(() => pDto.Name))
                            .Add(Projections.Property(() => pl.Name), "PropertyLocation.Name");
                        var query = session.QueryOver<Property>(() => p)
                                    .Inner.JoinAlias(() => p.PropertyLocation, () => pl)
                                    .Inner.JoinAlias(() => p.PropertyFMAccess, () => pfa)
                                    .Inner.JoinAlias(() => pfa.FirmMember, () => fm);
                        IList<PropertyDTO> assignedProperties = query.Where(() => fm.Id == FirmMemberId && pfa.HasAccess == PrFMAccess.Yes)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<PropertyDTO>()).List<PropertyDTO>();
                        result.AddRange(assignedProperties);
                        if (result.Count > 0) result[0].isUISelected = true;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching assigned properties to user:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public BusinessOutputTO getUserDefinition(string userName)
        {
            UserDefinitionDTO userDefDto = null;
            BusinessOutputTO businessTO = new BusinessOutputTO();
            ISession session = null;
            bool result = false;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        UserDefinition userDef = session.QueryOver<UserDefinition>().Where(x => x.Username == userName).SingleOrDefault();
                        if (userDef != null)
                        {
                            string msg = IsValidUser(userDef);
                            if (!string.IsNullOrWhiteSpace(msg))
                            {
                                businessTO.setErrorMessage(msg);
                                result = true;
                            }
                            else if (userDef.Status == UserStatus.Setup)
                            {
                                businessTO.setErrorMessage(Resources.Messages.ERROR_LOGIN_USER_SETUP);
                                result = true;
                            }
                            else if (userDef.Status == UserStatus.Active)
                            {
                                businessTO.result = getUserDefinitionDTO(userDef, false);
                                result = true;
                            }
                        }
                        if (!result)
                        {
                            log.Debug("Login Failed for user:" + userName);
                            businessTO.setErrorMessage("Username does not exist.");
                        }
                    }
                    catch (Exception e)
                    {
                        log.Error("Unexpected error while fetching user on forgot password:" + userName, e);
                        businessTO.setErrorMessage(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return businessTO;
        }
        private UserDefinitionDTO getUserDefinitionDTO(UserDefinition userDef, bool fetchEntitlement)
        {
            UserDefinitionDTO userDefDTO = new UserDefinitionDTO();
            userDefDTO.Id = userDef.Id;
            userDefDTO.Username = userDef.Username;
            userDefDTO.Status = userDef.Status;
            userDefDTO.SecurityQuestion = new SecurityQuestionDTO();
            userDefDTO.SecurityQuestion.Id = userDef.SecurityQuestion.Id;
            userDefDTO.SecurityQuestion.Question = userDef.SecurityQuestion.Question;
            userDefDTO.SecurityAnswer = userDef.SecurityAnswer;
            userDefDTO.UserRole = new UserRoleDTO();
            userDefDTO.UserRole.Name = userDef.UserRole.Name;
            userDefDTO.FirmMember = DomainToDTOUtil.convertToFirmMemberDTO(userDef.FirmMember, true);
            userDefDTO.FirmNumber = userDef.FirmNumber;
            userDefDTO.UserRole.EntitlementAssigned = new List<string>();
            if (fetchEntitlement)
            {
                ISet<UserEntitlement> entitlements = userDef.UserRole.UserEntitlements;
                foreach (UserEntitlement tmpEntitlement in entitlements)
                {
                    userDefDTO.UserRole.EntitlementAssigned.Add(tmpEntitlement.Name);
                }
            }

            return userDefDTO;
        }
        
        public void UpdateFirstLoginInfo(string userName, string password, long secQuestionId, string secAnswer, DateTime dob)
        {
            ISession session = null;
            log.Debug("Updating first login info of user");
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        UserDefinition userDef = session.QueryOver<UserDefinition>().Where(x => x.Username == userName).SingleOrDefault();
                        if (userDef != null)
                        {
                            userDef.Password = CommonUtil.Encrypt(password);
                            userDef.IsTempPassword = IsTempPassword.No;
                            userDef.SecurityQuestion = new SecurityQuestion();
                            userDef.SecurityQuestion.Id = secQuestionId;
                            userDef.SecurityAnswer = secAnswer;
                            userDef.Status = UserStatus.Active;
                            userDef.UpdateDate = DateUtil.getUserLocalDateTime();
                            userDef.UpdateUser = userName;
                            FirmMember firmMember = userDef.FirmMember;
                            firmMember.ContactInfo.Dob = dob;
                            session.Update(firmMember);
                            session.Update(userDef);
                            tx.Commit();
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Updating first login info of user:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while Updating first login info of user:" + userName);
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public UserDefinitionDTO fetchSystemUser(string userName)
        {
            ISession session = null;
            UserDefinitionDTO userDefDTO = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        UserDefinition userDef = session.QueryOver<UserDefinition>().Where(x => x.Username == userName).SingleOrDefault();
                        userDefDTO = new UserDefinitionDTO();
                        userDefDTO.Id = userDef.Id;
                        userDefDTO.Username = userDef.Username;
                        userDefDTO.FirmMember = DomainToDTOUtil.convertToFirmMemberDTO(userDef.FirmMember, true);
                        userDefDTO.FirmNumber = userDef.FirmNumber;
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while fetching system user:" + userName, e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
                return userDefDTO;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public FirmMemberDTO fetchAgentWithDuplicateContact(long userId, string contact)
        {
            ISession session = null;
            FirmMemberDTO fmDuplicateContactDTO = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	string tmpContact = CommonUtil.getActualContact(contact);
                    	UserDefinition ud = null;
                        FirmMember fm = null;
                        ContactInfo ci = null;

                        FirmMemberDTO fmDTO = null;
                        
                    	var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => fm.Id).WithAlias(() => fmDTO.Id))
                                .Add(Projections.Property(() => fm.FirstName).WithAlias(() => fmDTO.FirstName))
                                .Add(Projections.Property(() => fm.LastName).WithAlias(() => fmDTO.LastName))
                                .Add(Projections.Property(() => ci.Contact), "ContactInfo.Contact")
                                .Add(Projections.Property(() => ud.Id), "User.Id")
                                .Add(Projections.Property(() => ud.Username), "User.Username")
                                .Add(Projections.Property(() => ud.Status), "User.Status");
                    	IList<FirmMemberDTO> allUsers = session.QueryOver<FirmMember>(() => fm)
                                .Inner.JoinQueryOver(() => fm.User, () => ud)
                                .Inner.JoinQueryOver(() => fm.ContactInfo, () => ci)
                                .Where(() => ud.Id != userId && (ci.Contact.IsLike(tmpContact, MatchMode.End) || ci.AltContact.IsLike(tmpContact, MatchMode.End)))
                                .Select(proj)
                                .TransformUsing(new DeepTransformer<FirmMemberDTO>()).List<FirmMemberDTO>();
                    	if(allUsers != null && allUsers.Count > 0) {
                    		fmDuplicateContactDTO = allUsers[0];
                    	}
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Fetching duplicate contact agent:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return fmDuplicateContactDTO;
        }
        public void updateUserProfile(long FirmMemberId, string contact, string altContact)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	FirmMember firmMember = session.Get<FirmMember>(FirmMemberId);
                        firmMember.ContactInfo.Contact = contact;
                        firmMember.ContactInfo.AltContact = altContact;
                        session.Update(firmMember);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating User Profile:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void updateUserProfilePicture(long Id, byte[] image)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        UserDefinition user = session.Get<UserDefinition>(Id);
                        user.ProfileImg = image;
                        session.Update(user);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating User Profile Picture:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
    }
    
}