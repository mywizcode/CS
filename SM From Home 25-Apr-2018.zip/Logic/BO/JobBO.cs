﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;



/// <summary>
/// Summary description for PropertyAlertBO
/// </summary>
namespace ConstroSoft
{
    public class JobBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public JobBO() { }

        public IList<JobDTO> fetchJobs(string firmNumber, bool OnlyActive)
        {
            ISession session = null;
            IList<JobDTO> result = new List<JobDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                Job job = null;
                JobDTO jobDto = null;
                var proj = Projections.ProjectionList()
                             .Add(Projections.Property(() => job.Id).WithAlias(() => jobDto.Id))
                             .Add(Projections.Property(() => job.JobName).WithAlias(() => jobDto.JobName))
                             .Add(Projections.Property(() => job.Description).WithAlias(() => jobDto.Description))
                             .Add(Projections.Property(() => job.JobIntervalType).WithAlias(() => jobDto.JobIntervalType))
                             .Add(Projections.Property(() => job.JobExecutionStatus).WithAlias(() => jobDto.JobExecutionStatus))
                             .Add(Projections.Property(() => job.JobStatus).WithAlias(() => jobDto.JobStatus))
                             .Add(Projections.Property(() => job.FirmNumber).WithAlias(() => jobDto.FirmNumber))
                             .Add(Projections.Property(() => job.InsertUser).WithAlias(() => jobDto.InsertUser))
                             .Add(Projections.Property(() => job.UpdateUser).WithAlias(() => jobDto.UpdateUser));
                var query = session.QueryOver<Job>(() => job).Where(() => job.FirmNumber == firmNumber);
                if (OnlyActive) query = query.Where(() => job.JobStatus == JobStatus.Active);
                result = query.Select(proj).TransformUsing(new DeepTransformer<JobDTO>()).List<JobDTO>();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating Job Details:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public JobDTO fetchJobDetails(long jobId)
        {
            ISession session = null;
            JobDTO result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                Job job = null;
                JobDTO jobDto = null;
                var proj = Projections.ProjectionList()
                             .Add(Projections.Property(() => job.Id).WithAlias(() => jobDto.Id))
                             .Add(Projections.Property(() => job.JobName).WithAlias(() => jobDto.JobName))
                             .Add(Projections.Property(() => job.Description).WithAlias(() => jobDto.Description))
                             .Add(Projections.Property(() => job.JobIntervalType).WithAlias(() => jobDto.JobIntervalType))
                             .Add(Projections.Property(() => job.StartTime).WithAlias(() => jobDto.StartTime))
                             .Add(Projections.Property(() => job.EndTime).WithAlias(() => jobDto.EndTime))
                             .Add(Projections.Property(() => job.JobExecutionStatus).WithAlias(() => jobDto.JobExecutionStatus))
                             .Add(Projections.Property(() => job.JobStatus).WithAlias(() => jobDto.JobStatus))
                             .Add(Projections.Property(() => job.FirmNumber).WithAlias(() => jobDto.FirmNumber));
                result = session.QueryOver<Job>(() => job).Where(() => job.Id == jobId)
			                    .Select(proj)
			                    .TransformUsing(new DeepTransformer<JobDTO>()).SingleOrDefault<JobDTO>();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error fetching Job Details by name:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public void updateJobExecutionStatus(long jobId, DateTime StartTime, string message, JobExecutionStatus jobExecutionStatus)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	Job job = session.Get<Job>(jobId);
                        job.StartTime = StartTime;
                        if (job.JobExecutionStatus != JobExecutionStatus.Inprogress) job.EndTime = DateUtil.getUserLocalDateTime();
                        job.Message = message;
                        job.JobExecutionStatus = jobExecutionStatus;
                        session.Update(job);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating job execution status:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public long saveJobHistory(JobHistoryDTO jobHistoryDTO)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        JobHistory jobHistory = DTOToDomainUtil.populateJobHistoryAddFields(jobHistoryDTO);
                        session.Save(jobHistory);
                        Id = jobHistory.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Job History details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        
        public void updatejobHistoryDetails(JobHistoryDTO jobHistoryDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        JobHistory jobHistory = session.Get<JobHistory>(jobHistoryDTO.Id);
                        DTOToDomainUtil.populateJobHistoryUpdateFields(jobHistory, jobHistoryDTO);
                        session.Update(jobHistory);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating Job History details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void saveOrUpdateJob(JobDTO tmpDTO)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				Job tmpObj = null;
        				if(tmpDTO.Id > 0) {
        					tmpObj = session.Get<Job>(tmpDTO.Id);
        					DTOToDomainUtil.populateJobUpdateFields(tmpObj, tmpDTO);
        					session.Update(tmpObj);
        				} else {
        					tmpObj = DTOToDomainUtil.populateJobAddFields(tmpDTO);
        					session.Save(tmpObj);
        					tmpDTO.Id = tmpObj.Id;
        				}
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while adding or updating Job:", e);
        				throw new CustomException(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
    }
}