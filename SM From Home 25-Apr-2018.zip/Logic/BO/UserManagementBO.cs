﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;
using System.Data.SqlClient;


/// <summary>
/// Summary description for PropertyAlertBO
/// </summary>
namespace ConstroSoft
{
    public class UserManagementBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public UserManagementBO() { }
        
        public IList<UserRoleDTO> fetchUserRoles(string FirmNumber)
        {
        	ISession session = null;
        	IList<UserRoleDTO> result = new List<UserRoleDTO>();
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				IList<UserRole> tmpResult = session.QueryOver<UserRole>().Where(x => x.FirmNumber == FirmNumber).List<UserRole>();
        				if(tmpResult != null) {
        					foreach(UserRole tmpObj in tmpResult) {
        						UserRoleDTO tmpDTO = DomainToDTOUtil.convertToUserRoleDTO(tmpObj, true);
        						result.Add(tmpDTO);
        					}
        				}
        			} catch (Exception e)
        			{
        				log.Error("Exception while fetching User Roles:", e);
        				throw new CustomException(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        	return result;
        }
        public void saveOrUpdateUserRole(UserRoleDTO tmpDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        UserRole tmpObj = null;
                        if (tmpDTO.Id > 0)
                        {
                            tmpObj = session.Get<UserRole>(tmpDTO.Id);
                            DTOToDomainUtil.populateUserRoleUpdateFields(tmpObj, tmpDTO);
                            session.Update(tmpObj);
                        }
                        else
                        {
                            tmpObj = DTOToDomainUtil.populateUserRoleAddFields(tmpDTO);
                            session.Save(tmpObj);
                            tmpDTO.Id = tmpObj.Id;
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while adding or updating UserRole:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void deleteUserRole(long Id)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				UserRole tmpObj = session.Get<UserRole>(Id);
        				session.Delete(tmpObj);
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
                        tx.Rollback();
        				log.Error("Exception while deleting User Role:", e);
                        throw new CustomException(CommonUtil.getActualErrorMsg(e, "User Role"));
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
        public UserRoleDTO fetchUserRole(long Id)
        {
        	ISession session = null;
        	UserRoleDTO result = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				UserRole tmpResult = session.Get<UserRole>(Id);
                        result = DomainToDTOUtil.convertToUserRoleDTO(tmpResult, true);
        			} catch (Exception e)
        			{
        				log.Error("Exception while fetching User Role by Id:", e);
        				throw new CustomException(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        	return result;
        }
        public IList<PortalUserDTO> fetchPortalUsers(string FirmNumber)
        {
        	ISession session = null;
        	IList<PortalUserDTO> result = new List<PortalUserDTO>();
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				IList<PortalUser> tmpResult = session.QueryOver<PortalUser>().Where(x => x.FirmNumber == FirmNumber).List<PortalUser>();
        				if(tmpResult != null) {
        					foreach(PortalUser tmpObj in tmpResult) {
        						PortalUserDTO tmpDTO = DomainToDTOUtil.convertToPortalUserDTO(tmpObj);
        						result.Add(tmpDTO);
        					}
        				}
        			} catch (Exception e)
        			{
        				log.Error("Exception while fetching Portal User:", e);
        				throw new CustomException(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        	return result;
        }
        public void saveOrUpdatePortalUser(PortalUserDTO tmpDTO)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				PortalUser tmpObj = null;
        				if(tmpDTO.Id > 0) {
        					tmpObj = session.Get<PortalUser>(tmpDTO.Id);
        					DTOToDomainUtil.populatePortalUserUpdateFields(tmpObj, tmpDTO);
        					session.Update(tmpObj);
        				} else {
        					tmpObj = DTOToDomainUtil.populatePortalUserAddFields(tmpDTO);
        					session.Save(tmpObj);
        					tmpDTO.Id = tmpObj.Id;
        				}
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while adding or updating Portal User:", e);
        				throw new CustomException(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
        public void deletePortalUser(long Id)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				PortalUser tmpObj = session.Get<PortalUser>(Id);
        				session.Delete(tmpObj);
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while deleting Portal User:", e);
        				throw new CustomException(CommonUtil.getActualErrorMsg(e, "Portal User"));
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
        public IList<UserEntitlementDTO> fetchRoleEntitlements(long RoleId)
        {
            ISession session = null;
            IList<UserEntitlementDTO> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        UserEntitlement e = null;
                        UserEntitlement e1 = null;
                        UserRole r= null;
                        Firm f = null;

                        UserEntitlementDTO eDto = null;
                        var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => e.Id).WithAlias(() => eDto.Id))
                                .Add(Projections.Property(() => e.Name).WithAlias(() => eDto.Name))
                                .Add(Projections.Property(() => e.Description).WithAlias(() => eDto.Description))
                                .Add(Projections.Property(() => e.Level).WithAlias(() => eDto.Level))
                                .Add(Projections.Property(() => e1.Id), "Parent.Id")
                                .Add(Projections.Property(() => e1.Name), "Parent.Name");
                        var query = session.QueryOver<UserEntitlement>(() => e)
                                .Left.JoinAlias(() => e.Parent, () => e1);
                        result = query.Select(proj)
                                    .TransformUsing(new DeepTransformer<UserEntitlementDTO>()).List<UserEntitlementDTO>();

                        var proj1 = Projections.ProjectionList()
                                .Add(Projections.Property(() => e.Id).WithAlias(() => eDto.Id))
                                .Add(Projections.Property(() => r.Name).WithAlias(() => eDto.RoleName));
                        var query1 = session.QueryOver<UserEntitlement>(() => e)
                        		.Left.JoinAlias(() => e.UserRoles, () => r);
                        IList<UserEntitlementDTO> result1 = query1.Where(() => r.Id == RoleId).Select(proj1)
                                    .TransformUsing(new DeepTransformer<UserEntitlementDTO>()).List<UserEntitlementDTO>();
                        if(result != null) {
                            List<UserEntitlementDTO> tmpResult1 = result1.ToList<UserEntitlementDTO>();
                            foreach (UserEntitlementDTO tmpDTO in result)
                            {
                                UserEntitlementDTO assignedDTO = tmpResult1.Find(x => x.Id == tmpDTO.Id);
                                if (assignedDTO != null)
                                {
                                    tmpDTO.isUISelected = true;
                                }
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading all Entitlements and those which assigned to Role:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public void updateRoleEntitlementAssignment(long RoleId, List<UserEntitlementDTO> assignedEntitlementList)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        UserRole tmpObj = session.Get<UserRole>(RoleId);
                        if (assignedEntitlementList != null)
                        {
                            List<UserEntitlement> removedEntitlementList = new List<UserEntitlement>();
                            foreach (UserEntitlement dbEntitlement in tmpObj.UserEntitlements)
                            {
                                UserEntitlementDTO tmpDTO = assignedEntitlementList.Find(x => x.Id == dbEntitlement.Id);
                                if (tmpDTO == null) removedEntitlementList.Add(dbEntitlement);
                                else assignedEntitlementList.Remove(tmpDTO);
                            }
                            removedEntitlementList.ForEach(x => tmpObj.UserEntitlements.Remove(x));
                            foreach (UserEntitlementDTO tmpDTO in assignedEntitlementList)
                            {
                                tmpObj.UserEntitlements.Add(session.Get<UserEntitlement>(tmpDTO.Id));
                            }
                        }
                        else tmpObj.UserEntitlements.Clear();

                        session.Update(tmpObj);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while deleting UserEntitlement Configuration:", e);
                        throw new CustomException(CommonUtil.getActualErrorMsg(e, "User Entitlement"));
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public List<FirmMemberDTO> fetchFirmUsers(string FirmNumber)
        {
        	ISession session = null;
        	List<FirmMemberDTO> result = new List<FirmMemberDTO>();
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				FirmMember fm = null;
        				UserDefinition u = null;
        				MasterControlData salutation = null;
        				ContactInfo c = null;
                        UserRole ur = null;
        				
        				FirmMemberDTO fmDTO = null;
        				var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => fm.Id).WithAlias(() => fmDTO.Id))
                                .Add(Projections.Property(() => salutation.Name), "Salutation.Name")
                                .Add(Projections.Property(() => fm.FirstName).WithAlias(() => fmDTO.FirstName))
                                .Add(Projections.Property(() => fm.MiddleName).WithAlias(() => fmDTO.MiddleName))
                                .Add(Projections.Property(() => fm.LastName).WithAlias(() => fmDTO.LastName))
                                .Add(Projections.Property(() => c.Contact), "ContactInfo.Contact")
	                            .Add(Projections.Property(() => c.AltContact), "ContactInfo.AltContact")
	                            .Add(Projections.Property(() => c.Email), "ContactInfo.Email")
	                            .Add(Projections.Property(() => u.Id), "User.Id")
	                            .Add(Projections.Property(() => u.Username), "User.Username")
                                .Add(Projections.Property(() => u.ActivationDate), "User.ActivationDate")
                                .Add(Projections.Property(() => u.ExpirationDate), "User.ExpirationDate")
                                .Add(Projections.Property(() => u.Status), "User.Status")
                                .Add(Projections.Property(() => ur.DisplayName), "User.UserRole.DisplayName");
	                    var query = session.QueryOver<FirmMember>(() => fm)
	                    		.Inner.JoinAlias(() => fm.ContactInfo, () => c)
	                            .Inner.JoinAlias(() => fm.Salutation, () => salutation)
        						.Inner.JoinAlias(() => fm.User, () => u)
                                .Inner.JoinAlias(() => u.UserRole, () => ur);
	                    IList<FirmMemberDTO> tmpResult = query.Select(proj).Where(() => fm.FirmNumber == FirmNumber)
                            .TransformUsing(new DeepTransformer<FirmMemberDTO>()).List<FirmMemberDTO>();
	                    if(tmpResult != null) result.AddRange(tmpResult);
	                    
	                    SubscriptionPlan p = null;
                    	Firm f = null;

                        SubscriptionPlan tmpObj = session.QueryOver<SubscriptionPlan>(() => p)
	                    		.Inner.JoinAlias(() => p.Firm, () => f)
	                    		.Where(() => f.FirmNumber == FirmNumber && p.Status == SubscriptionPlanStatus.Active)
	                    		.SingleOrDefault<SubscriptionPlan>();
                        if(tmpObj != null && tmpObj.Users != null) {
                        	foreach(FirmMember tmpFMObj in tmpObj.Users) {
                        		FirmMemberDTO tmpFMDTO = result.Find(x => x.Id == tmpFMObj.Id);
                        		if(tmpFMDTO != null) {
                        			tmpFMDTO.ActivePlan = new SubscriptionPlanDTO();
                                    tmpFMDTO.ActivePlan.Id = tmpObj.Id;
                                    tmpFMDTO.ActivePlan.Name = tmpObj.Name;
                        		}
                        	}
                        }
        			} catch (Exception e)
        			{
        				log.Error("Exception while fetching Users for Firm:", e);
        				throw new CustomException(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        	return result;
        }
        public FirmMemberDTO fetchUserDetails(long firmMemberId)
        {
            ISession session = null;
            FirmMemberDTO firmMemberDTO = null;
            try
            {
            	session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	FirmMember firmMember = session.Get<FirmMember>(firmMemberId);
                    	firmMemberDTO = DomainToDTOUtil.convertToFirmMemberDTO(firmMember, true);
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while fetching User Details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                } 
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return firmMemberDTO;
        }
        public void SetUserPassword(long UserId, string Password, IsTempPassword tempPassword, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            List<EmailDTO> tmpEmailList = new List<EmailDTO>();
            try
            {
            	session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	UserDefinition tmpObj = session.Get<UserDefinition>(UserId);
                    	tmpObj.Password = CommonUtil.Encrypt(Password);
                    	tmpObj.IsTempPassword = tempPassword;
                    	tmpObj.UpdateDate = DateUtil.getUserLocalDateTime();
                    	tmpObj.UpdateUser = userDefDTO.Username;
                    	tx.Commit();

                    	//If Reset Password then send email to user about new password
                        if (tempPassword == IsTempPassword.Yes) tmpEmailList.Add(EmailSMSUtil.populateEmailForUser(tmpObj));
                    }
                    catch (Exception e)
                    {
                    	tx.Rollback();
                        log.Error("Exception while setting user password:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                } 
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            if (tempPassword == IsTempPassword.Yes) EmailSMSUtil.SendSystemEmail(Constants.SYSDEFAULT_EMAIL_SMS_TEMPLATE.USER_ACNT_RESET_PWD, tmpEmailList.ToArray());
        }
        public void ResetUserAccount(long UserId, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            List<EmailDTO> tmpEmailList = new List<EmailDTO>();
            try
            {
            	session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	UserDefinition tmpObj = session.Get<UserDefinition>(UserId);
                    	tmpObj.SecurityAnswer = " ";
                        tmpObj.Status = UserStatus.Setup;
                        tmpObj.Password = CommonUtil.Encrypt(ApplicationUtil.GenerateRandomPassword());
                    	tmpObj.IsTempPassword = IsTempPassword.Yes;
                    	tmpObj.UpdateDate = DateUtil.getUserLocalDateTime();
                    	tmpObj.UpdateUser = userDefDTO.Username;
                    	tx.Commit();
                    	
                    	tmpEmailList.Add(EmailSMSUtil.populateEmailForUser(tmpObj));
                    }
                    catch (Exception e)
                    {
                    	tx.Rollback();
                        log.Error("Exception while resetting user account:", e);
                        tmpEmailList.Clear();
                        throw new Exception(Resources.Messages.system_error);
                    }
                } 
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            EmailSMSUtil.SendSystemEmail(Constants.SYSDEFAULT_EMAIL_SMS_TEMPLATE.USER_ACNT_RESET, tmpEmailList.ToArray());
        }
        public void SuspendUserAccount(long UserId, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            try
            {
            	session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	UserDefinition tmpObj = session.Get<UserDefinition>(UserId);
                    	tmpObj.Status = UserStatus.Suspended;
                    	tmpObj.UpdateDate = DateUtil.getUserLocalDateTime();
                    	tmpObj.UpdateUser = userDefDTO.Username;
                    	tx.Commit();
                    }
                    catch (Exception e)
                    {
                    	tx.Rollback();
                        log.Error("Exception while suspending user account:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                } 
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void ActivateOrDeactivateUserAccount(long UserId, bool IsActivate, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            List<EmailDTO> tmpEmailList = new List<EmailDTO>();
            try
            {
            	session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	UserDefinition tmpObj = session.Get<UserDefinition>(UserId);
                    	if(IsActivate) {
                    		SubscriptionPlan p = null;
                    		Firm f = null;
                    		
                    		SubscriptionPlan tmpPlanObj = session.QueryOver<SubscriptionPlan>(() => p)
    	                    		.Inner.JoinAlias(() => p.Firm, () => f)
                                    .Where(() => f.FirmNumber == tmpObj.FirmNumber && p.Status == SubscriptionPlanStatus.Active)
    	                    		.SingleOrDefault<SubscriptionPlan>();
                    		if(tmpPlanObj == null) throw new CustomException("Please activate subscription plan in order to activate user.");
                    		if(tmpObj.Status == UserStatus.Active) throw new CustomException("User is already active.");
                    		bool isUserExistInPlan = false;
                    		foreach(FirmMember tmpFMObj in tmpPlanObj.Users) {
                    			if(tmpFMObj.User.Id == tmpObj.Id) isUserExistInPlan = true;
                    		}
                    		if (!isUserExistInPlan) throw new CustomException("User is not added in current active subscription plan.");
                    		
                    		if(string.IsNullOrWhiteSpace(tmpObj.SecurityAnswer)) {
                                tmpObj.Password = CommonUtil.Encrypt(ApplicationUtil.GenerateRandomPassword());
                            	tmpObj.IsTempPassword = IsTempPassword.Yes;
                            	tmpObj.Status = UserStatus.Setup;
                            	
                    			tmpEmailList.Add(EmailSMSUtil.populateEmailForUser(tmpObj));
                            	
                    		} else {
                    			tmpObj.Status = UserStatus.Active;
                    		}
                    	} else {
                    		tmpObj.Status = UserStatus.InActive;
                    	}
                    	tmpObj.UpdateDate = DateUtil.getUserLocalDateTime();
                    	tmpObj.UpdateUser = userDefDTO.Username;
                    	tx.Commit();
                    }
                    catch (Exception e)
                    {
                    	tx.Rollback();
                        log.Error("Exception while Activating or deactivating account:", e);
                        tmpEmailList.Clear();
                        if(e is CustomException) throw e;
                        else throw new Exception(Resources.Messages.system_error);
                    }
                } 
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            EmailSMSUtil.SendSystemEmail(Constants.SYSDEFAULT_EMAIL_SMS_TEMPLATE.USER_ACNT_SETUP, tmpEmailList.ToArray());
        }
        public void saveOrUpdateUser(FirmMemberDTO tmpDTO)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				FirmMember tmpObj = null;
        				if (tmpDTO.Id > 0)
        				{
        					tmpObj = session.Get<FirmMember>(tmpDTO.Id);
        					DTOToDomainUtil.populateFirmMemberUpdateFields(tmpObj, tmpDTO);
        				}
        				else
        				{
        					tmpObj = DTOToDomainUtil.populateFirmMemberAddFields(tmpDTO);
        					tmpObj.User = new UserDefinition();
        					tmpObj.User.SecurityAnswer = " ";
        					tmpObj.User.Password = CommonUtil.Encrypt(ApplicationUtil.GenerateRandomPassword());
        					tmpObj.User.IsTempPassword = IsTempPassword.Yes;
        					tmpObj.User.SecurityQuestion = session.Get<SecurityQuestion>(1);
        					tmpObj.User.Status = UserStatus.InActive;
        					tmpObj.User.FirmMember = tmpObj;
        					tmpObj.User.FirmNumber = tmpDTO.FirmNumber;
        					tmpObj.User.InsertUser = tmpDTO.InsertUser;
        					tmpObj.User.InsertDate = DateUtil.getUserLocalDateTime();
        				}
        				tmpObj.User.UserRole = new UserRole();
        				tmpObj.User.UserRole.Id = tmpDTO.User.UserRole.Id;
        				tmpObj.User.UpdateDate = DateUtil.getUserLocalDateTime();
        				tmpObj.User.UpdateUser = tmpDTO.UpdateUser;
        				
        				if (tmpDTO.Id > 0) session.Update(tmpObj);
        				else session.Save(tmpObj);
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while adding or updating User:", e);
        				throw new CustomException(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
        public bool IsDuplicateUserName(string UserName)
        {
        	ISession session = null;
        	bool duplicate = false;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				UserDefinition p = null;
        				duplicate = session.QueryOver<UserDefinition>(() => p).Where(() =>  p.Username.IsInsensitiveLike(UserName)).RowCount() > 0;
        			}
        			catch (Exception e)
        			{
        				log.Error("Exception while validating duplicate user name:", e);
        				throw new CustomException(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        	return duplicate;
        }
    }
}