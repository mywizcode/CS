﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using NHibernate;
using NHibernate.Criterion;
using NHibernate.Impl;
using NHibernate.Transform;

namespace ConstroSoft.Logic.BO
{

    public class ReportConfigBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public ReportConfigBO() { }

        public ReportTemplateMasterDTO fetchReportConfiguration(string firmNumber, string reportName)
        {
            ISession session = null;
            ReportTemplateMasterDTO reportConfigDTO = new ReportTemplateMasterDTO();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        ReportTemplateMaster ReportTemplateMaster = session.CreateCriteria<ReportTemplateMaster>().Add(
                            NHibernate.Criterion.Expression.Eq("FirmNumber", firmNumber)).Add(
                            NHibernate.Criterion.Expression.Eq("Name", reportName)).List<ReportTemplateMaster>().FirstOrDefault();
                        reportConfigDTO = DomainToDTOUtil.convertToReportTemplateMasterDTO(ReportTemplateMaster);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching report configuration :", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return reportConfigDTO;
        }
        public IList<ReportTemplateMasterDTO> fetchPropertyReportTemplates(long PropertyId)
        {
            ISession session = null;
            IList<ReportTemplateMasterDTO> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	ReportTemplateMaster pac = null;
                    	Property p = null;
                    	
                    	ReportTemplateMasterDTO pacDTO = null;
                    	var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => pac.Id).WithAlias(() => pacDTO.Id))
                                .Add(Projections.Property(() => pac.TemplateType).WithAlias(() => pacDTO.TemplateType))
                                .Add(Projections.Property(() => pac.Name).WithAlias(() => pacDTO.Name))
                                .Add(Projections.Property(() => pac.Decription).WithAlias(() => pacDTO.Decription))
                                .Add(Projections.Property(() => pac.IsCustomReport).WithAlias(() => pacDTO.IsCustomReport));
	                    var query = session.QueryOver<ReportTemplateMaster>(() => pac)
                            .Inner.JoinAlias(() => pac.Properties, () => p);
	                    
	                    result = query.Where(() => p.Id == PropertyId)
	                        .Select(proj)
                            .OrderBy(() => pac.TemplateType).Asc()
	                        .TransformUsing(new DeepTransformer<ReportTemplateMasterDTO>()).List<ReportTemplateMasterDTO>();
                    } catch (Exception e)
                    {
                        log.Error("Exception while fetching Property Report/Letter templates:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public ReportTemplateMasterDTO fetchPropertyReportTemplate(long PropertyId, string reportName)
        {
            ISession session = null;
            ReportTemplateMasterDTO result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        ReportTemplateMaster pac = null;
                        Property p = null;

                        ReportTemplateMasterDTO pacDTO = null;
                        var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => pac.Id).WithAlias(() => pacDTO.Id))
                                .Add(Projections.Property(() => pac.TemplateType).WithAlias(() => pacDTO.TemplateType))
                                .Add(Projections.Property(() => pac.Name).WithAlias(() => pacDTO.Name))
                                .Add(Projections.Property(() => pac.Path).WithAlias(() => pacDTO.Path))
                                .Add(Projections.Property(() => pac.Decription).WithAlias(() => pacDTO.Decription))
                                .Add(Projections.Property(() => pac.IsCustomReport).WithAlias(() => pacDTO.IsCustomReport));
                        var query = session.QueryOver<ReportTemplateMaster>(() => pac)
                            .Inner.JoinAlias(() => pac.Properties, () => p);

                        result = query.Where(() => pac.Name == reportName && p.Id == PropertyId )
                            .Select(proj)
                            .OrderBy(() => pac.TemplateType).Asc()
                            .TransformUsing(new DeepTransformer<ReportTemplateMasterDTO>()).SingleOrDefault<ReportTemplateMasterDTO>();
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while fetching Property Report/Letter templates:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        
        public IList<ReportTemplateMasterDTO> fetchReportTemplateMasters(IsCustomReport IsCustomReport)
        {
            ISession session = null;
            IList<ReportTemplateMasterDTO> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	ReportTemplateMaster pac = null;
                    	
                    	ReportTemplateMasterDTO pacDTO = null;
                    	var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => pac.Id).WithAlias(() => pacDTO.Id))
                                .Add(Projections.Property(() => pac.TemplateType).WithAlias(() => pacDTO.TemplateType))
                                .Add(Projections.Property(() => pac.Name).WithAlias(() => pacDTO.Name))
                                .Add(Projections.Property(() => pac.Path).WithAlias(() => pacDTO.Path))
                                .Add(Projections.Property(() => pac.Decription).WithAlias(() => pacDTO.Decription))
                                .Add(Projections.Property(() => pac.IsCustomReport).WithAlias(() => pacDTO.IsCustomReport))
                                .Add(Projections.Property(() => pac.FirmNumber).WithAlias(() => pacDTO.FirmNumber));
	                    var query = session.QueryOver<ReportTemplateMaster>(() => pac);
	                    
	                    result = query.Where(() => pac.IsCustomReport == IsCustomReport)
	                        .Select(proj)
                            .OrderBy(() => pac.TemplateType).Asc()
	                        .TransformUsing(new DeepTransformer<ReportTemplateMasterDTO>()).List<ReportTemplateMasterDTO>();
                    } catch (Exception e)
                    {
                        log.Error("Exception while fetching Report/Letter templates masters:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public IList<ReportTemplateMasterDTO> fetchFirmReportTemplatesByType(string FirmNumber, ReportTemplateType TemplateType)
        {
            ISession session = null;
            IList<ReportTemplateMasterDTO> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	ReportTemplateMaster pac = null;
                    	
                    	ReportTemplateMasterDTO pacDTO = null;
                    	var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => pac.Id).WithAlias(() => pacDTO.Id))
                                .Add(Projections.Property(() => pac.TemplateType).WithAlias(() => pacDTO.TemplateType))
                                .Add(Projections.Property(() => pac.Name).WithAlias(() => pacDTO.Name))
                                .Add(Projections.Property(() => pac.Decription).WithAlias(() => pacDTO.Decription))
                                .Add(Projections.Property(() => pac.IsCustomReport).WithAlias(() => pacDTO.IsCustomReport));
	                    var query = session.QueryOver<ReportTemplateMaster>(() => pac);
	                    
	                    result = query.Where(() => pac.TemplateType == TemplateType && (pac.FirmNumber == Constants.SYSDEFAULT.DEFAULT_FIRM || pac.FirmNumber == FirmNumber))
	                        .Select(proj)
	                        .TransformUsing(new DeepTransformer<ReportTemplateMasterDTO>()).List<ReportTemplateMasterDTO>();
                    } catch (Exception e)
                    {
                        log.Error("Exception while fetching Firm Report/Letter templates for given TemplateType:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public void saveOrUpdateReportTemplateMaster(ReportTemplateMasterDTO tmpDTO)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				ReportTemplateMaster tmpObj = null;
        				if(tmpDTO.Id > 0) {
        					tmpObj = session.Get<ReportTemplateMaster>(tmpDTO.Id);
        					DTOToDomainUtil.populateReportTemplateMasterUpdateFields(tmpObj, tmpDTO);
        					session.Update(tmpObj);
        				} else {
        					tmpObj = DTOToDomainUtil.populateReportTemplateMasterAddFields(tmpDTO);
        					session.Save(tmpObj);
        					tmpDTO.Id = tmpObj.Id;
        					//If new default report template added then link this template to all properties in all firms
                            IList<Property> allProperties = session.QueryOver<Property>().List<Property>();
                            foreach (Property property in allProperties)
                            {
                                property.ReportTemplates.Add(tmpObj);
                                session.Update(property);
                            }
        				}
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while adding or updating ReportTemplateMaster:", e);
        				throw new CustomException(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
        public void assignReportTemplate(long PropertyId, ReportTemplateMasterDTO tmpDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        ReportTemplateMaster tmpTemplate = null;
                        Property property = session.Get<Property>(PropertyId);
                        foreach(ReportTemplateMaster template in property.ReportTemplates) 
                        {
                            if (template.TemplateType == tmpDTO.TemplateType)
                            {
                                tmpTemplate = template;
                                break;
                            }
                        }
                        property.ReportTemplates.Remove(tmpTemplate);
                        ReportTemplateMaster newTemplate = session.Get<ReportTemplateMaster>(tmpDTO.Id);
                        property.ReportTemplates.Add(newTemplate);
                        session.Save(property);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while assigning new Report template:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void deleteReportTemplateMaster(long Id)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				ReportTemplateMaster tmpObj = session.Get<ReportTemplateMaster>(Id);
                        foreach (Property property in tmpObj.Properties)
                        {
                            property.ReportTemplates.Remove(tmpObj);
                            session.Update(property);
                        }
        				if(tmpObj.IsCustomReport == IsCustomReport.Yes) {
        					//Replace this template with default template of same type
        					ReportTemplateMaster defaultTemplateObj = session.QueryOver<ReportTemplateMaster>()
        							.Where(x => x.TemplateType == tmpObj.TemplateType && x.IsCustomReport == IsCustomReport.No).SingleOrDefault<ReportTemplateMaster>();
        					if(defaultTemplateObj != null) {
        						foreach(Property property in tmpObj.Properties) {
        							property.ReportTemplates.Add(defaultTemplateObj);
        							session.Update(property);
        						}
        					}
        				}
        				tmpObj.Properties.Clear();
        				session.Update(tmpObj);
                        session.Flush();
        				session.Delete(tmpObj);
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while deleting Report template master:", e);
        				throw new CustomException(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
    }
}