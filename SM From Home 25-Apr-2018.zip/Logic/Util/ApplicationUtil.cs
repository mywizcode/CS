﻿using System.Web;
using System.Web.UI;
using ConstroSoft.Logic.CachingProvider;
/// <summary>
/// Summary description for EmailUtil
/// </summary>

namespace ConstroSoft
{
    public static class ApplicationUtil
    {
        //Logger Instance
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        /**
         * This method checks whether Current request async call.
         */
        public static bool isAsyncPostBack(Page page)
        {
            return ScriptManager.GetCurrent(page).IsInAsyncPostBack;
        }
        /**
         * This method checks whether Current request is Post call or async call for inner page. If yes then returns true.
         */
        public static bool isSubPageRendered(Page page)
        {
            bool isAsyncCall = ScriptManager.GetCurrent(page).IsInAsyncPostBack;
            string updatePnlId = ScriptManager.GetCurrent(page).AsyncPostBackSourceElementID;
            return (!isAsyncCall || (isAsyncCall && updatePnlId.Contains("$ContentPlaceHolder1")));
        }
        /**
         * This method returns control element identifier on which bootstrap CSS will be applied. This method is called at end of the AJAX request. So when page is rendered
         * all controls inside it will be converted to bootstrap elements.
         **/
        public static string getParentToApplyCSS(Page page)
        {
            string parent = "body";
            bool isAsyncCall = ScriptManager.GetCurrent(page).IsInAsyncPostBack;
            string updatePnlId = ScriptManager.GetCurrent(page).AsyncPostBackSourceElementID;
            if (isAsyncCall)
            {
                if (updatePnlId.Contains("$ContentPlaceHolder1")) parent = "div.content-wrapper";
                else if (updatePnlId.Contains("$notificationAlertGrid") || updatePnlId.Contains("$RefreshNotificationTimer")
                		|| updatePnlId.Contains("$notificationTaskGrid")) parent = "ul.ulNotification";
            }
            return parent;
        }
        public static string getSessionNotyMsg(System.Web.SessionState.HttpSessionState Session)
        {
            string msg = "";
            if(Session[Constants.Session.NOTY_MSG] != null && (Session[Constants.Session.NOTY_MSG]).ToString().Trim() != "") {
                msg = (Session[Constants.Session.NOTY_MSG]).ToString();
                Session.Remove(Constants.Session.NOTY_MSG);
            }
            return msg;
        }
        public static bool isSessionActive(System.Web.SessionState.HttpSessionState Session)
        {
            return (Session[Constants.Session.USERNAME] != null && (Session[Constants.Session.USERNAME]).ToString().Trim() != "") ? true : false;
        }
        public static bool IsSessionKeyExistInCache(System.Web.SessionState.HttpSessionState Session)
        {
        	string userLoggedIn = Session[Constants.Session.USERNAME] == null ? string.Empty : (string)Session[Constants.Session.USERNAME];
            return UserCacheProvider.Instance.IsUserSessionValid(userLoggedIn, Session.SessionID);
        }
        public static bool IsUserLoggedInWithOtherSession(System.Web.SessionState.HttpSessionState Session)
        {
        	string userLoggedIn = Session[Constants.Session.USERNAME] == null ? string.Empty : (string)Session[Constants.Session.USERNAME];
            return UserCacheProvider.Instance.IsUserLoggedInWithOtherSession(userLoggedIn, Session.SessionID);
        }
        public static void clearSession(System.Web.SessionState.HttpSessionState Session, HttpApplicationState Application)
        {
            string userLoggedIn = Session[Constants.Session.USERNAME] == null ? string.Empty : (string)Session[Constants.Session.USERNAME];
            if (userLoggedIn.Length > 0) UserCacheProvider.Instance.RegisterUserLogout(userLoggedIn, Session.SessionID);
            //Clear Session Content.
            HttpContext.Current.Session.Clear();
            HttpContext.Current.Session.Abandon();
            HttpContext.Current.Response.Cookies.Add(new System.Web.HttpCookie("ASP.NET_SessionId", ""));
        }
        public static string getLoginMsg(string param)
        {
            string msg = "";
            if (!string.IsNullOrWhiteSpace(param))
            {
                if ("cpsuccess".Equals(param)) msg = "Password is changed successfully. Please login with your new password.";
                else if ("ussuccess".Equals(param)) msg = "User setup is completed successfully. Please login with your new password.";
                else if ("rpsuccess".Equals(param)) msg = "Password is reset successfully. Please login with your new password.";
                else if ("sysadmin1".Equals(param)) msg = "You do not have system administrator role.";
            }
            return msg;
        }
        public static T getPageNavDTO<T>(System.Web.SessionState.HttpSessionState Session)
        {
            object navObj = Session[Constants.Session.NAV_DTO];
            Session.Remove(Constants.Session.NAV_DTO);
            Session.Remove(Constants.Session.PAGE_DATA);
            if (navObj is T) return (T)navObj;
            else return default(T);
        }
        public static string[] getFunctionAndPageName(HttpRequest Request, int fnAndPageStartIndex)
        {
            string[] fnAndPageName = new string[2];
            string absPath = Request.Url.AbsolutePath;
            string appPath = Request.ApplicationPath;
            int index = absPath.IndexOf(appPath);
            string expPath = (index < 0) ? absPath : absPath.Remove(index, appPath.Length);
            string[] arrUrl = expPath.TrimStart('/').Split('/');
            fnAndPageName[0] = (arrUrl.Length > fnAndPageStartIndex) ? arrUrl[fnAndPageStartIndex] : "";
            fnAndPageName[1] = (arrUrl.Length > (fnAndPageStartIndex+ 1)) ? arrUrl[fnAndPageStartIndex+ 1] : "";
            return fnAndPageName;
        }
        public static bool IsSysAdminPage(HttpRequest Request)
        {
            string[] fnAndPageName = getFunctionAndPageName(Request, 0);
            return fnAndPageName[0].ToUpper().Equals("SYSADMIN");
        }
        public static bool IsSysAdminDefaultFirmFunction(HttpRequest Request)
        {
        	string[] fnAndPageName = ApplicationUtil.getFunctionAndPageName(HttpContext.Current.Request, 1);
            return Constants.Function.DEFAULT_FIRM.Equals(fnAndPageName[0]);
        }
        public static string GenerateRandomPassword()
        {
        	//NOTE: Refer -> System.Web.Security.Membership.GeneratePassword(int length, int numberOfNonAlphanumericCharacters).
            return System.Web.Security.Membership.GeneratePassword(8, 1);
        }
    }
}