﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Text.RegularExpressions;
/// <summary>
/// Summary description for EmailUtil
/// </summary>
using NHibernate;

namespace ConstroSoft
{
    public static class EmailSMSUtil
    {
        //Logger Instance
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        /**
         * This method check if internet connection working.
         * */
        public static bool checkInternetConnection()
        {
            try
            {
                using (var client = new WebClient())
                using (var stream = client.OpenRead("http://www.google.com"))
                {
                    return true;
                }

            }
            catch
            {
                return false;
            }
        }
        /**
         * This method will load SMS configuration & Send SMS.
         * */
        public static void SendSMS(String firmNumber, string smsContent, List<string> toList)
        {
            if (checkInternetConnection())
            {
                SmsConfig smsConfig = null;//loadSmsConfiguration(firmNumber);
                if (smsConfig != null)
                {
                    foreach (string toNumber in toList)
                    {
                        string strUrl = smsConfig.Url + smsConfig.UserId + ":" + smsConfig.Password +
                            "&senderID=" + smsConfig.SenderId + "&receipientno=" + toNumber + "&msgtxt=" + smsContent + "&state=4";
                        WebRequest request = HttpWebRequest.Create(strUrl);
                        HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                        Stream s = (Stream)response.GetResponseStream();
                        StreamReader readStream = new StreamReader(s);
                        string dataString = readStream.ReadToEnd();
                        response.Close();
                        s.Close();
                        readStream.Close();
                        if (dataString.StartsWith("Status=0"))
                        {
                            log.Info("SMS Sent Successfully to : " + toNumber);
                        }
                    }
                }
                else
                {
                    log.Error("Error in loading SMS Configuration.");
                }
            }
            else
            {
                log.Error("Please check your internet connection or try again later.");
            }
        }
        public static void SendSMS(SmsDTO smsDTO)
        {
            if (checkInternetConnection())
            {
                if (smsDTO.RecipientList != null && smsDTO.RecipientList.Count > 0)
                {
                    foreach (string toNumber in smsDTO.RecipientList)
                    {
                        string strUrl = smsDTO.URL + smsDTO.UserId + ":" + smsDTO.Password +
                            "&senderID=" + smsDTO.SenderId + "&receipientno=" + toNumber + "&msgtxt=" + smsDTO.Content + "&state=4";
                        WebRequest request = HttpWebRequest.Create(strUrl);
                        HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                        Stream s = (Stream)response.GetResponseStream();
                        StreamReader readStream = new StreamReader(s);
                        string dataString = readStream.ReadToEnd();
                        response.Close();
                        s.Close();
                        readStream.Close();
                        if (dataString.StartsWith("Status=0"))
                        {
                            log.Info("SMS Sent Successfully to : " + toNumber);
                        }
                    }
                }
            }
            else
            {
                log.Error("Please check your internet connection or try again later.");
                throw new CustomException("Please check your internet connection or try again later.");
            }
        }
        public static void SendEmail(EmailDTO emailDTO)
        {
            if (checkInternetConnection())
            {
                using (System.Net.Mail.MailMessage mailMessage = new System.Net.Mail.MailMessage())
                {
                	string tmpEmailContent = emailDTO.EmailContent;
                    mailMessage.From = new MailAddress(emailDTO.FromEmail);
                    mailMessage.Subject = emailDTO.Subject;
                    mailMessage.IsBodyHtml = true;
                    emailDTO.RecipientList.ForEach(x => mailMessage.To.Add(new MailAddress(x)));
                    //Add Attachments
                    addAttachments(emailDTO.Attachments, mailMessage);
                    //Create Email content view
                    mailMessage.AlternateViews.Add(createEmailContent(tmpEmailContent));

                    //Send Mail
                    SmtpClient smtp = new SmtpClient();
                    smtp.Host = emailDTO.SmtpHost;
                    smtp.EnableSsl = emailDTO.EnableSsl;
                    System.Net.NetworkCredential NetworkCred = new System.Net.NetworkCredential();
                    NetworkCred.UserName = emailDTO.FromEmail;
                    NetworkCred.Password = emailDTO.Password;
                    smtp.UseDefaultCredentials = true;
                    smtp.Credentials = NetworkCred;
                    smtp.Port = int.Parse(emailDTO.SmtpPort);
                    ServicePointManager.ServerCertificateValidationCallback = CertificateValidationCallBack;
                    smtp.Send(mailMessage);
                }
            }
            else
            {
                log.Error("Please check your internet connection or try again later.");
                throw new CustomException("Please check your internet connection or try again later.");
            }
        }
        private static bool CertificateValidationCallBack(
         object sender,
         System.Security.Cryptography.X509Certificates.X509Certificate certificate,
         System.Security.Cryptography.X509Certificates.X509Chain chain,
         System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            // If the certificate is a valid, signed certificate, return true.
            if (sslPolicyErrors == System.Net.Security.SslPolicyErrors.None)
            {
                return true;
            }

            // If there are errors in the certificate chain, look at each error to determine the cause.
            if ((sslPolicyErrors & System.Net.Security.SslPolicyErrors.RemoteCertificateChainErrors) != 0)
            {
                if (chain != null && chain.ChainStatus != null)
                {
                    foreach (System.Security.Cryptography.X509Certificates.X509ChainStatus status in chain.ChainStatus)
                    {
                        if ((certificate.Subject == certificate.Issuer) &&
                           (status.Status == System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.UntrustedRoot))
                        {
                            // Self-signed certificates with an untrusted root are valid. 
                            continue;
                        }
                        else
                        {
                            if (status.Status != System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.NoError)
                            {
                                // If there are any other errors in the certificate chain, the certificate is invalid,
                                // so the method returns false.
                                return false;
                            }
                        }
                    }
                }

                // When processing reaches this line, the only errors in the certificate chain are 
                // untrusted root errors for self-signed certificates. These certificates are valid
                // for default Exchange server installations, so return true.
                return true;
            }
            else
            {
                // In all other cases, return true.
                return true;
            }
        }
        private static void addAttachments(List<AttachmentDTO> attachments, System.Net.Mail.MailMessage mailMessage)
        {
            if (attachments != null && attachments.Count > 0)
            {
                foreach (AttachmentDTO tmpDTO in attachments)
                {
                    Attachment attachment = new Attachment(new MemoryStream(tmpDTO.Content), tmpDTO.FileName);
                    mailMessage.Attachments.Add(attachment);
                }
            }
        }
        private static AlternateView createEmailContent(string emailContent)
        {
            IList<LinkedResource> headerImages = new List<LinkedResource>();
            emailContent = addInlineImages(emailContent, headerImages);
            AlternateView avHtml = AlternateView.CreateAlternateViewFromString(emailContent, null, MediaTypeNames.Text.Html);
            foreach (LinkedResource linkedResource in headerImages)
            {
                avHtml.LinkedResources.Add(linkedResource);
            }
            return avHtml;
        }
        /**
         * Sample ImageControl => "<img src=\"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQIAGwAbAAD/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCABxAMgDASIAAhEBAxEB/8QAHQABAAIDAQEBAQAAAAAAAAAAAAcIBAUGAwIJAf/EAD4QAAEDBAIBAwIEAwUGBgMAAAECAwQABQYRBxIhCBMxIkEUMlFhFlJxFSNCYoEXJGNykaEJGCYzQ4KDkqL/xAAbAQEAAgMBAQAAAAAAAAAAAAAABAUCAwYBB//EADcRAAEDAwMBBQcCBgIDAAAAAAECAxEABCEFEjFBBiJRYXETFDKBkaHRUrEVFkJigpIjU3Ki4f/aAAwDAQACEQMRAD8A/VOlKUpSlKUpSlKUpSlKUpSlKUpSlKUpSlYd2vNosMFy53y6w7dDa/PIlPpabT/VSiAKjuf6gcYWv28NxfLsyPwHbHZnXY2/t/fudGyP3SoipdtYXN3llBI8eg9TwPma0uXDTPxqj9/pUoUqD7hyx6i5i/8A0x6anUtEbS5cshitqP8AVvY1/Tsa4668x sq3v8AY8AWv2U/KGu8lR/opp8j/tVsx2aunse0aB8C63P0CjUReptI/pUf8FfirQ0qnP8A56c1xe7JtfI/Di7e4nw62l52K8kfqEOoO/6bH9as7xtyTivK2LMZdiMxT0R5RbcbdSEvR3U/mbcSCeqhsH5IIIIJBBrXqnZvUtHbS9dNwg8KBCh9QT96ytdStrxRQ0rvDoQQfvXU0pSqKp9KUpSlKUpSlKUpSlKUpSlKUpSlKUpSlKUpSlKV8OutMNLffcS222kqWtZ0lKR5JJPwKgjM/U/ MujuHcD4pIz2/tno7IjoUbdFP6rdGgsfuFJR/n 1T7DTLrUllNumQOScJSPFSjgD1NR7i6athLh54HJPoOTU7vPMxmVyJDqGmm0la1rUEpSkfJJPgCoX5I9U3DGKsuQk5 5MlJ2FNWBpEp0/sHVAsp/Q7O/01XCyPTjzfzGUTeduVlQIS1Bf9hWdALTY wOtNhQ/mIcP au9x/0x nrjK2uXa5Y3BltxEe5IuGQPB9KUj/EoL00n oSKvmbHQ9PUPe31POfpaHdnw3qGf8RUBb99cD/hQEJ8VnP0HHzNV6lerJq53bfHXBzN2ubZPsTr489dpmv2HlaB/lS5r9K JnLvrjyl3va8YyC2sr ERMY9tv8A0W82pX/9Va/jblHifLrncMT42lR1KtDSHpDUa3rjMoSo6HXshIP nisnF aOO8wsF yiw3wvWzG1OpuMhbC0Jb9tHdRHYDsOo3sb3V25rTVqohvSh3Yn2u5ZG74Z3DG7oOvSoSbJboBVd8z8MJGOeOY61Sa53f1vpc96W1yNtPn/AHaE71/6NJ1XNtepn1HYpcvw8/N7q3IjnTkW5RG1H ikuI2P xq/OQ83cdYwm0pu12kiTeoiZ8WGxBffk/hinsXVtNpUpCQNklQHwf0NbS7Y7x9y3izC7vardf7Nc46Xo7rjfbbawClba/CkHRHkEEftUpvtey0lJ1HS0BtWJCQPWJTB9JHrWlWjrUSLa6VuHQn94OPpVUME9XWO8pKb489QWHWd63XMiOm4MNqDTSz4CnEKJKPOv7xCh1PnQHkS/wCnPhu5cN5vyLaGXHnMclPQHbQ46NlaerylJJ CpHdKCfvoHx8VSzl3h Xg/M8zi/HUvT/flMItYUQpxxD4SW0q1/iBV1J0Py7 K/T zQnbbZ4NuffLzsWM0ytw/wCNSUgFX pG687Y 6aXZoGlGGbpMlGYEFKkrAPwk8H/AOV7o3trp5XvYlbRgHrkEEE9R1rMpSlfLq6mlKUpSlKUpSlKUpSlKUpSlKUpSlKUpSlYl2usCx22Rdrm GY0ZHdxWio/sAkeVKJ0AkAkkgAEmsuvJ6NHkKaW ylwsr9xvsN9Va12H7 T5rJG3cN3FeGYxURXXAMu5vdDnJLkvHsNCguPjMZ/rKnAHaVz3UH6R9wyg PG1dhUmWDG8YwmyotOOWmDZ7ZFSVe0w2lptIA8qUfufGyo T8k1tqqt66uWLri PW3jexSVR3MibceuLqDpX4RJCQ0D9gtXbt yNfCjXQ6c1d9o7trS2TsQThI FIGSqOpjqSSeJquuVM6a0u6WJV49T4DyHkMVN Bcgt8pPy73jPdGLwJK4keYpOlXR5Hha29/lYSfAPytQP5UpIX5cscdXHkZeLRWrjHRa7TfY9zukF8K6TmW9kI2Ad6Oj1I6q 5GhXNekfILJe B8cj2h5HuWttyHMZCgVNPhxRPYD47BQWP2UKmSo1 pWkao4i3G32alJE5OJEnzPM9DxAArbbgXlqkuGdwBP7x6dP3qlVkus6y8283WyyKCLtfnW7PbAB8SJUhLYUP RK1Of0Qa1Ppyhf2niV44ijKWpOR5g3Gl/GxbYzfuyST9uwbQ3/APlFTti3p3ulp9Qt85iu93gv22Y45Jgwmu5cRIUgNpW5tPX6UKd1onyoV48D m 5cX37Kr9kl6izHr17rUH8EpYMVp1fZ07UkaWerXkfyV3Fzr nC0dS24CvYyRgyVpAEf4EBXzIqia0 5LyCpONywf/ABJmfnMfSuOwaW1yr6nszyXCYZnYwLMMeu8uUtUYs7ARuGpG1bPskjYT47HadpNWTttvx7AMWjWu3siDaLNGQwy2nsspbSNJSPlS1E6GvKlE/cmq 8Ren7nXiGTd8exvOcWYx26yUvLnLiOvz0AfSFIbIS2F9f5lKSD5G6mfIs/424vtUWHmmcQ4yoTKAg3CX70x3qnXuFA24tR SQn71zvaEt3d03b6ev2rYShKUp3FRCUxKhEbskCBgc djp25lpTlwnaokkkxAk8DPFcfxvxHKk8lXznbPoDbd9uyw1aIB0o2uGlAbQVkePfUhI7a2E7UAfqOpSyHI7Didpfv2S3eLbbfGT2dkSXAhCf28/JP2A8k BVf5nqryPkG5rxr078cTshkBXRd3uLamYTH ZQ2DrXn61IP6JNdRh3p nzr1GzrnLK3c0yKOr3Y0RQ62u3r/wCEzoBRH8xA x67G616hYvBQf1pfs4ACWxle0CAkJnuDzWQesKNZW76ILdkndkkqOEyeTPU Q9JFdjiOS3zkSSm/MWuXZ8Vb uEZaPbl3U/Z0tnyyx90g6W5sEhKQUr7mlK5q4dS6uW07U9B T1PifoAIAtG0FA7xk NKUpWis6UpSlKUpSlKUpSlKUpSlKUpSlKUpSlK8pMhmJHdlSF9GmUKcWrW9JA2T/ANKqHy/iDvq24zsXLHGyWnb7Z0vQ5tqLgStSewJbBUdBafzgE/Ulz53oG360JcSULSFJUNEH4Iqj ScA8 cB5tNyjgV6ZOsklRUhqMtDrqWidhl Ov8A93rsgKSFHXn6Sa7PscppD6nG3ktXCYKCv4FCCFIV4TI88Yql1kLU2EqQVNmQqORxBHpmq/2HJeVeEchW/apF5xa5kdXWX2FN 6kfZxp1PVYG/HZJ19qmrH/X3yhb4yY9 xuw3daf/nCXI7iv bqop3/RIrtR6juchbU2zlD0vSr6hJGyq1yWG1/v1cadST 48ftWZCzWz35Adc9BMoukghRsbSUH/wC64yd19Dv7lu/G/VNOQs/qS63n5kpVHka523aVbnba3CkjwKFftBFc2v8A8Q2/Fnq3xjb0vfzm5rKf/wBfbB/715xfWD6jc4SY BcXw3is6DsO1ypikf6hXQf1I1UvWWHyPOSj FvStg2JJPlD92mx9D rUZnuP9fNSJbMQ5IuKELzPkVEZGhu343AREZA/lLzvuPEfugtmuVub7QbLKLFsHzdLn2RvH1UKtW2L9/l9UeSNv3MH7Gq1MYX60 Suqs15AVh9vlK6BL0xuGtYP8AhS1FHZR/yrI3Ug4F6HON7BKTds4us/Lp2 6kv7YjKX87KEkrUd/zLIP3FT3Z8UsFieVKt9vH4txPRct9xb8lxP6KecKnFD9irVbaqC87YXy0lmx2stno2kI 4k/ 1WDOjsJO9 Vq/uJV B9qxLVaLVYoDVqslsi2 EwOrUeKylptA/QJSABWXSlcmpRWSpRkmrYAAQKUpSvK9pSlKUpSlKUpSlKUpSlKUquXKvImdZO7yZb8Pv0nHLTxxbPcfkRUJEm4TlNKcCQtQ200jr56jsr9QDXCvcz5fZvRnabyMkucjKr5MlQmbguStcpCESXVuOe4T2 lpHXe/HZNWK5ptME8S8gyWITDcmXjk4vvIbAW77cZzp3UPKteQN/G6p5gFufyb0zZLeZTKvwOIWaVboXbejMkzA/IWPttLSY6f/uqvp gizvbFtxTQCG3mhECT3YyYk7nDJB6Y4Fcvfl5h9SQokqQv5ZnHhCcevrU5Y3m Q3rh7iy0yMpuDVyyJZn3e6GUoPotsJSnpSy7vsOwS23v/iarqOG R7l/A97zXk3k7HLva03d1mBcIaCy0214CWjtCCpRKhpICledbJ8CCMJnz2/S9k/ISmnAm1Y0nEbYQnz0ef3LdH38qkNo3/wDW5xnPeMuPvSvZ40yLBv11trTd2jtbS601d3nnFx0OEHw4gdllGvCGjvW07X2jIdQ6y0jcS/s7oTIklRgkd2AUI5jBxRi9UgpWpUQ3OSekAY65CjVlcS5a47zq6yLJiWTsXKdEbLz7DTbgU0gEDauyQB5IHmq88f5By7zFAyjOLNmF2Yyi25IzAhY 1PRHhW6GlxtTipDCte6Cj3E dqJQded65eHkB4c4AyudYr6qVyVenYUvIpraVKcgJmlRbHu66FYT331O0uOH9BXccO5Pxdxb6fjl8G 26ZmF3t0mZKWh5L9ykzSlSvaKRtzSCBvxoBJWfua1DSEaSy87ZoLhU4htG5O4mBuUTgQhUiDyRngmsjeKu1oQ8rbCSpUGOcDx7w x86mxHN/FDlmueQozaAbbZ5CIs6TpfRl5ZISg/T5JIPxus2 crcd41arZer7lkKHEvLaHreVlRXJQpIUFIbAKyNEHevGxvVfn7Hn2x7gHG OLTdI71 zLL1TZrKHO7rTSAGGg4P8PZZ7AH50TUi2q5Izb1HZOqFmdhskHHLUuy2eddXgG4kRCUxy9GSSErX0U4tO1JT/edvIGqyf7D2rBWorXtTvJnkhJSkcJPxKJzB7owCa8b1x1YACRJ2/UyT16COoyeauBk2f2mzcb3Pkm1ON3WBDtbtzjKYXtEhKWypOlD7HwN/b/Sqm8v3vmKDh2A5S9y5kDOScgyGnGbbbHhEhRGFoQUoShsBSlD3WQVFR8lXz81a7jO141B49tVgxyNIcsUSL Dirltj/e2QNF3R UueVAkDsDsDRG4E5Iixst9YXHOC2 M01b8QgpnqZQgJbZUgLeSlKR4A03HAH7iqzsy4xbXjqA3Ib3rJUATsQkwmCDBKomOeOlStTS46yg7oKtqQATEkiT54mK6yDAicLZVAm8oepq8XNktOLiWieevuDqUl10IKlLQkEnagEgjZPipRyXlXjrD2IEjI8vt8NN0bDsIFZWuQ2RsLQlAKinXntrX71UHGX3uRuZeWbrk bWTGkqL1jelXR3UiNblOrbWiKlRCO/ttBBUT9PuEhJKvG34Yn4Je fc7u2Z3aNAtWP2o2KzMXV/8L7cBOo417hSpBDKPPwduqJ0TVhf9nkOy/eLUpbbYUsISkSVbdqUwkDlWT3iYJIEio9vqJRCGUgBSiBJJ4mSZM9OMfOpH5c9QkzG X8ExawZXbIONXOI1d7vOcQ2tK4alKUOq1A9QptpWteT3GvOql1fLXG6MNHIJzC3nHS4Gv7QSsqbCyrr1OhsK341rdVFtAxLJ YOS8zg2VleNcfYi/Hs8V2OVIbLMcMs/QvZH5XlDsNjYJ0Qa4eRdbe56csG4qsl3iybxleTO3CZGZdC3IyQsx2kOpB2kqPVQB QmpbnZOzu0W7CQpCk7AswJ74U4oqx8SUgCTjpWlOrvMqcWYIO4p56EJEeRM dXxxbl3jPNrsqxYpmlsudwSwJJjsO7X7ZAOwD867DY Rvzqv5cuX MrRk7eGXHNLazenHEM/hC4SpDizpCFkApQokgAKIPkfqKqtIuWJ8depfLrjal260MYJiBi2mMsJaMyYIrSG20p8e4tSnSPuTrf71zfHYhZPxBGxyFejMzzkTN2X5JYeBlNx2FpcU87 iEkLc rxtexvRqv/k 1IFxuWGilsiYkFYKiSYjahA3HHWJHNSP4y6CW4G4FX2gADPJJgfWrEXLlbNLh6qrfxHYp7DFggW38ZdkCOhbji/aU4B3IJSD3YHjX3/WpFZ5e4zk5Z/A8fNLa7e/dLH4VDhV/e6J9vuB076B ne/BGtiqbY3m6MPyrnTP0ZA5/EUVtyy2YTnwue8VPqQXQnwVFtEdK1aGkgfAArZ8bQLXeMD4pwXE7w89kU7IH8tvjlsfT IissF1IU4SCAvqEpT33534PbzJvuytuW0qXKUoQlMpESr2ZcUtRjIGB4k4kRWtjVXNxAyVEmCem4JCR59fvVtso5e4ywq7JsWU5rbLfcFN 7 Gcd24lGtgqAB6gj43rf2rG/238Ui02y fxrC/A3mSuJb3urmpLyCApCB12SCoD pqkOKZzYo3CfKeWZDempOb5ZNbtLLcl/3Jhjq6qcI7Ht06qWCfjbaR lbZEvGYGacG4HebtEiWzE4Dd5uzshwIYZlPKMxxtaj4KtJbSR qgn58UPYa3blC1LJQVAkRBCW96ikRMbilAyZz6UGuuKgpCYMR5SqADnwkmrwWvkDDb1lNwwm1X PJvlqQXJsNAV3YTtI2o618rT9/vXQ1Uj0kZFbrxnmc8gzi69NzO/Lh25tCdqS2gOSHVEHXVCUKZBP2PQfKhVt64zXtLTo94bVMmAmSfEgbo8gZHyq60 6N4z7U9SfpOPtmlKUqlqbSlKUpWPcLfCu0CTa7lGbkxJjK48hlwbS42tJSpJH3BBIP9a0kLjrBbdi7 FQMVtrFildvft7bADLnYgq7J  9D/pXR0rah91tO1CiBM4J5HB9R41gW0KMkeVaSHhOIQMYOFRMbtzdhLa2jbhHSY5QtRUoFBGjskn prmbhxVweiJa8QueH4w0ylx1y3291ttHdxQHuKQjwVq0kbPk6FZXLed3jjvFncktliZnMRkOuzJEiSGmoraG1KSSkbW4pawhtKUj5WCSkCoawy1ZDf/AFGY1IzKNFN5tGOycjnutOKX0dlkMtxyFJHQNIISlAKh9JXvspVRndaubZ0IaWrcVAnJGTiZ6mJz65q7sezzd5bLun9oQlKo4JO0TEdBO0Hr3kmIM1MzuHcPYZjcnGZVjxey2W7bRIivIZYalH5 rtruRvxvZHjWq sP4h4qw1L0rEMJs8T8c0UOPNshxTrSh5T3Vs9CD5AOjUS8gwskt3O2N263Oy75MuUqdf5EeO8lhX4FmO2iLEUVrCfZDyXVEE6JWVdSo6rRo5SzziPC73iFpXZpJ43t0ZNzmSYzjyJNxmv7biR0pcb6tNpc12IJ01rqBWpXaG6QXEOrUEkme8ckAHOYOM UelTm yDdy0yu1UkuKCSAQBAUoo9R34A/VuBHBjl8S9POT5dzTa5 ScZNY/i1lcekXBhTEduJIe7qKG46G9Fxsj2R2Xs6SrZH0oFpbtxTxfd7kxfbxgWPyJkNKUtyHoDRKEoACQTryEgADfwB41UdXXmvILPyrh MXKXaWLDJjzY9 lAfknxoQkPJSoqPRCPda STvuD WuDyXmfJsvsOXYZkdmtMp65ZHabHbLc6hwJEebt1IcLa0rUsIQNqSoDt8eKttX7bP6g4lclBQCgBJIHG4yZJ70/aOlV mdhHkASAUr2rJME7SvZIGB3YmJEDkiataAEgJSAAPAArSM4RiMfKn84Zx6Ei/wAloMu3END31thKU9Sr9NISP9KiJnni7JvMqVZ7VDXh9qyBWLNNJbJlyCxEdekSEuKcShLbYaTodVbSVEkHVY/D3OHJOZ5PjVryy24 1CyGxy72RDbeQ9FZRILTSllaynSiNaA 4O/tVM3qyEK2NqI3YxORI58iY/epLvZa9DKn1hMIAVkieCePEAGfA4mcVJ94wHiRGSxsqvuLYy3e5DwQxMlR2UvPPH40Vfnc/Q VVk3Pizje839GU3XBbHLuyCFCY9BbU4VD4UokfUR9idkfaoJ5hyu2ROYskyq/wWbnaeOMWaaRAfb7ocuM5we2B5 gqSpG1AEhKNgfpubtzfyjaJsDDHLZZHsknX61WtUhMZaYjIkxg 82Ue8XCprukdvAKSCQD4OY7QPIWQpxQ290QTxkR5AkEAeVbP5QW6y2tkJJWNxmABgH5wlSST/cInNTNZ P8IsDt3fs LW2Ku/kquhQwn/fCSon3d/m33Xvfz2NctZOOOAGLzEi49jeIC7Wh8y47UX2TIjuhQJX1SewIKU T8aH6V88gs5eOHrnLy6521mbbUOXC5i1odRHmQmHC6qOnsruj3WUBCvJ8qUBsGoNbeXYMQ4guk6V72RT7i/mk55B pq3NRnHFtpA8NM wW0BA0n6TofNZP67d268LVkAnvHPCQDnmDAnpIrDTuzNvfslZUJClJAAkSElc ndzGcg1ZyRx7g0vKEZtKxO1PX5tAQm4LioU8ABoHsR8geAfkDxvVfGO8b8f4hcZN2xbDLNapsvYefiQ22lqBOynaR4G/Oh43UIWD1K5Y3Hss/K4FrDCMPlZXekxWFpV1L6mojTRUshJX/db7b33 wrxm89cjts3Rm/tWSKy3gb2TvIjRnUOw33z0iRi4p1QUr621E9R YgDxWB7QS3t9oraQBEmI5AOeB4eRrMdjL0OEFKZBOfEzBjHPHyKc5FTmzxxx5Gv03I2cNsibtdEOIlyvwbfuvpWNOBR157A6V/Nvzvde2LcfYPhBkKw/ErTZlSzt9UKKhpTn6AkDZA w B9qq1AvP8FWWLbmoEJuVgXGjt0TcVl38TGutyIPtDSwjSvdSfqSVb3ojdbuFzNm3F KSrAt2FcP4VwmFc5b81Drj6rvNeR7bS1e59SQl7Z 56k7A8DX/MTqklLylbYE94kY4B9IVHhFSV9iVyPdSFGYEgCZPIyeQUecrjpJ53mbgXMM 5QcsGNcbt2i1y7uh RdorEdmGqH7aOzqlge4t4rU8VJPjwnSSSVGRPUZxipGLWO2cd8UxrgIbUphpduhR1SYbhSPY0XASlsuKUtahtW0jRBUVCeMffuEqxW Rd/ZFwXFaMwMghCX o9wJBJIAX2GiSRqthXbDtbdqNsSkbWRgd7vEiCVZmY nzNcAvRmUF1M5UecYg9McVD/pk4bHEnHUNi9WuKzk04LeuTqAlTiQpRKGS4PkJT12Addt6381MFKVRX989qVyu7fMqWST8 g8hwPKptuwi2aS03wBFKUpUSt1KUpSlKUpSlcxyLg8fkPG/wCG5c9yKwqbEludUBaXUsvodLS0kjaVdNfPjwfOtHJt E49bMuu2cRIrgu96ZYjy3lOqUC20NISlJOkj9dfJ81vqVrLSCveRn8T T9akpvH0s wSohGceu2Z8Z2p58BWh/gnHv42/2hKiuKvf8AZv8AZKXlOqKUxvc9zqEb6g9vO9b 1c1knAPFuWXO8Xe94 67IvvsqndJz7aHHGte26EJWEhwAa7Ab0VD/Erch0rFdu04IWkEc8da2M6jeW6gtp1SSABIJGAZA9ARMeNR6rgPix2eLhMx56apDL7LTcy4SZDbPvD  cbS44QhxfypwfUVfVvt5rxV6eeKHY6m37BJekLuLd1XPcuMkzVyWwQhRkd/d0AogDtr7/PmpIpWPudv gfQVtGs6iOH1/7H8 Oaj2HwJxdbjdfwFgdjou7Ull5pE1722hIQEPqZQVFLSlpASVIAOgBvXivm4cN4lbkwMgxiwoN xmyf2XZA9LeSwpLQK47b6QoBxId0ratnf1fIBEiUp7oxEBAHyFP4vflW5Tyj6qORxBzxGKhbA GH75as6kcwWlD7 dXND78NUhKltRWABGSpxkgBafJ g6Hj967ODw7gVvm2O4x7ZIVJx TJmxXXpjrq1yX0BLjzylqJdWQlOlLJ1oa1qu2pWLdmy2ANskdTzzP759azuNavbhalbykH lJISO6EQBP6QE mDWPcIEO6wJNruMdD8WYyth9pf5XG1pKVJP7EEioqsXprwjFcjk3LG1uR7Pc7U9aLnaZCTJEhhYI02 tRcZGiAQk6ISn4I3Uu0rY7btPEKWmSOKj2uo3dkhbdu4UpVyOh XEjoeRyDUXs mrh1pv2/wCGX1pNtNqWF3KSr3Y 9hK/7z6inx1J/L1R110Tr q9NnEC0Oodx6U5 It6bY V3SUovMp/L3259ak6T1Kt9eqQNdRqT6Vr9ytv tP0FSP47qnPvC/91fmozkenHiKUJQkY5Ic/GwkQJHe5yle62j8hVtw9lp ylbI0NaqO RvTUi ZpZIWJY8YVidchOXm5qujrjjjbCnCptaHHCpayPaCV9SRtW1DWjZClYO6dbOp2lAHoB KkWnaTU7Rz2geUowR3lKI9YnkQInGBisa32 Ja4bcCC17bLW oKiokkklRUSSpRJJJJJJJJJJrJpSpoEYFUalFRk80pSlK8pSlKUpSlKUpSlKUpSlKUpSlKUpSlKUpSlKUpSlKUpSlKUpSlKUpSlKUpSlKUpSlKUpSlKUr//Z\" data-filename=\"wizeye_logo.jpg\" style=\"width: 200px;\">"
         * */
        private static string addInlineImages(string emailContent, IList<LinkedResource> headerImages)
        {
            string INLINE_IMG_CHECKER = "src=\"data:";
            string INLINE_IMG_SRC_START = "src=\"";
            string INLINE_IMG_SRC_END = "\" data-filename";
            MatchCollection matchCollection = Regex.Matches(emailContent, "<img[^>]+>");
            int i = 1;
            foreach (Match match in matchCollection)
            {
                string ImageControl = match.Value;//Image html Control
                if (ImageControl.Contains(INLINE_IMG_CHECKER))
                {
                    string filename = "img" + i;
                    //Replace SRC attribute with new file name
                    var start = ImageControl.IndexOf(INLINE_IMG_SRC_START) + INLINE_IMG_SRC_START.Length;
                    var end = ImageControl.IndexOf(INLINE_IMG_SRC_END);
                    string ImageSrc = ImageControl.Substring(start, end - start);
                    emailContent = Regex.Replace(emailContent, ImageSrc, "cid:" + filename);

                    MemoryStream image = GetInlineImageContent(ImageSrc);
                    LinkedResource headerImage = new LinkedResource(image, GetInlineImageContentType(ImageSrc));
                    headerImage.ContentId = filename;
                    headerImages.Add(headerImage);
                    i = i + 1;
                }
            }
            return emailContent;
        }
        private static string GetInlineImageContentType(string ImageSrc)
        {
            string INLINE_IMG_CONTENT_TYPE_START = "data:";
            string INLINE_IMG_CONTENT_TYPE_END = ";base64";
            var start = ImageSrc.IndexOf(INLINE_IMG_CONTENT_TYPE_START) + INLINE_IMG_CONTENT_TYPE_START.Length;
            var end = ImageSrc.IndexOf(INLINE_IMG_CONTENT_TYPE_END);
            string contentType = ImageSrc.Substring(start, end - start);
            return (!string.IsNullOrWhiteSpace(contentType)) ? contentType : "image/jpg";
        }
        private static MemoryStream GetInlineImageContent(string ImageSrc)
        {
            string INLINE_IMG_CONTENT_START = "base64,";
            var start = ImageSrc.IndexOf(INLINE_IMG_CONTENT_START) + INLINE_IMG_CONTENT_START.Length;
            string output = ImageSrc.Substring(start, ImageSrc.Length - start);
            string converted = output.Replace(' ', '+');
            int mod4 = output.Length % 4;
            if (mod4 > 0)
            {
                converted += new string('=', 4 - mod4);
            }
            return Base64ToImage(converted);
        }
        public static MemoryStream Base64ToImage(string base64String)
        {
            // Convert base 64 string to byte[]
            byte[] imageBytes = Convert.FromBase64String(base64String);
            // Convert byte[] to Image
            MemoryStream ms = new MemoryStream(imageBytes, 0, imageBytes.Length);
            return ms;
        }
        public static EmailDTO populateEmailForUser(UserDefinition tmpObj) {
        	EmailDTO emailDTO = new EmailDTO();                                
            emailDTO.PlaceHolderDict = populateEmailPlaceHolderDTO(tmpObj);
    		emailDTO.RecipientList = new List<string>();
            if (!string.IsNullOrWhiteSpace(tmpObj.FirmMember.ContactInfo.Email)) emailDTO.RecipientList.Add(tmpObj.FirmMember.ContactInfo.Email);
            if (!string.IsNullOrWhiteSpace(tmpObj.FirmMember.ContactInfo.AltEmail)) emailDTO.RecipientList.Add(tmpObj.FirmMember.ContactInfo.AltEmail);

			return emailDTO;
        }
        /**
         * Send Email to given recipients. This email is sent using default system firm (00000) providers and given template name.
         */
        public static void SendSystemEmail(string TemplateName, params EmailDTO[] tmpDTOs) {
        	try {
        		if(tmpDTOs != null && tmpDTOs.Length > 0) {
            		EmailAndSMSProviderBO providerBO = new EmailAndSMSProviderBO();
                	EmailConfigDTO ConfigDTO = providerBO.fetchDefaultEmailProvider(Constants.SYSDEFAULT.DEFAULT_FIRM);
                	if(ConfigDTO != null) {
                		MarketingCampaignBO marketingBO = new MarketingCampaignBO();
                    	EmailSmsStoreDTO templateDTO = marketingBO.fetchEmailSmsTemplateByName(EmailSmsType.Email, TemplateName, Constants.SYSDEFAULT.SYSTEM_ONLY_FIRM);

                        if (templateDTO != null)
                        {
                            foreach (EmailDTO tmpDTO in tmpDTOs)
                            {
                                populateEmailDTO(tmpDTO, ConfigDTO);
                                tmpDTO.Subject = templateDTO.Subject;
                                tmpDTO.EmailContent = ReplacePlaceholders(StringUtil.getBytesAsEmailContentString(templateDTO.EmailContent), tmpDTO.PlaceHolderDict);
                                SendEmail(tmpDTO);
                            }
                        }
                	}
            	}
        	}
        	catch (Exception e)
			{
                log.Error("Exception while Sending System Emails. TemplateName:"+TemplateName, e);
            }
        }
        public static void SendSystemErrorEmail(string FunctionName, Exception ex, UserDefinitionDTO userDefDTO, SysExpEmailAddDetailsDTO addDtlDTO) {
        	try{
        		LoginBO loginBO = new LoginBO();
            	UserDefinitionDTO sysUserDTO = loginBO.fetchSystemUser(Constants.SYSDEFAULT.SYSADMIN_USER);
            	
            	EmailDTO emailDTO = new EmailDTO();
    			emailDTO.PlaceHolderDict = EmailSMSUtil.populateEmailPlaceHolderDTO(FunctionName, ex, userDefDTO, addDtlDTO);
    			emailDTO.RecipientList = new List<string>();
                if (!string.IsNullOrWhiteSpace(sysUserDTO.FirmMember.ContactInfo.Email)) emailDTO.RecipientList.Add(sysUserDTO.FirmMember.ContactInfo.Email);
                if (!string.IsNullOrWhiteSpace(sysUserDTO.FirmMember.ContactInfo.AltEmail)) emailDTO.RecipientList.Add(sysUserDTO.FirmMember.ContactInfo.AltEmail);
                
                SendSystemEmail(Constants.SYSDEFAULT_EMAIL_SMS_TEMPLATE.SYSTEM_EXCEPTION, emailDTO);
        	}
        	catch (Exception e)
			{
                log.Error("Exception while Sending System Emails in case of exception. Function Name:" + FunctionName, e);
            }
        }
        public static EmailDTO populateEmailDTO(object objConfig)
        {
            EmailDTO emailDTO = new EmailDTO();
            populateEmailDTO(emailDTO, objConfig);
            return emailDTO;
        }
        public static void populateEmailDTO(EmailDTO emailDTO, object objConfig) {
        	if (objConfig is EmailConfigDTO)
            {
        		EmailConfigDTO config = (EmailConfigDTO)objConfig;
        		emailDTO.FromEmail = config.Email;
        		emailDTO.Password = config.Password;
        		emailDTO.SmtpHost = config.SmtpHost;
        		emailDTO.SmtpPort = config.SmtpPort;
        		emailDTO.EnableSsl = (config.EnableSsl == EmailEnableSSL.Yes);
        	} else {
        		EmailConfig config = (EmailConfig)objConfig;
        		emailDTO.FromEmail = config.Email;
        		emailDTO.Password = config.Password;
        		emailDTO.SmtpHost = config.SmtpHost;
        		emailDTO.SmtpPort = config.SmtpPort;
        		emailDTO.EnableSsl = (config.EnableSsl == EmailEnableSSL.Yes);
        	}
        }
        public static Dictionary<string, string> populateEmailPlaceHolderDTO(string FunctionName, Exception ex, UserDefinitionDTO userDefDTO, SysExpEmailAddDetailsDTO addDtlDTO) {
        	Dictionary<string, string> PlaceHolderDict = new Dictionary<string, string>();
        	PlaceHolderDict.Add(SystemEmailPersonalization.EXP_FUNCITON_NAME.ToString(), FunctionName);
        	PlaceHolderDict.Add(SystemEmailPersonalization.EXP_MESSAGE.ToString(), ex.Message);
        	PlaceHolderDict.Add(SystemEmailPersonalization.EXP_STACKTRACE.ToString(), ex.ToString());
        	PlaceHolderDict.Add(SystemEmailPersonalization.EXP_DATETIME.ToString(), DateUtil.getCSDateTime(DateUtil.getUserLocalDateTime()));
        	if(addDtlDTO != null) {
        		if(addDtlDTO.CampaignId > 0) PlaceHolderDict.Add(SystemEmailPersonalization.EXP_CAMPAIGN_ID.ToString(), addDtlDTO.CampaignId.ToString());
        	}
        	
        	return PlaceHolderDict;
        }
        public static Dictionary<string, string> populateEmailPlaceHolderDTO(SubscriptionPlanDTO planDTO, FirmDTO tmpFirmDTO) {
        	Dictionary<string, string> PlaceHolderDict = new Dictionary<string, string>();
        	PlaceHolderDict.Add(EmailPersonalization.FIRM_NAME.ToString(), tmpFirmDTO.Name);
        	PlaceHolderDict.Add(SystemEmailPersonalization.SUB_PLAN_NAME.ToString(), planDTO.Name);
        	PlaceHolderDict.Add(SystemEmailPersonalization.SUB_PLAN_PURCHASE_DATE.ToString(), DateUtil.getCSDate(planDTO.PurchaseDate));
        	PlaceHolderDict.Add(SystemEmailPersonalization.SUB_PLAN_START_DATE.ToString(), DateUtil.getCSDate(planDTO.StartDate));
        	PlaceHolderDict.Add(SystemEmailPersonalization.SUB_PLAN_END_DATE.ToString(), DateUtil.getCSDate(planDTO.EndDate));
        	PlaceHolderDict.Add(SystemEmailPersonalization.SUB_PLAN_NO_OF_USERS.ToString(), planDTO.NoOfUsers.ToString());
        	PlaceHolderDict.Add(SystemEmailPersonalization.SUB_PLAN_PURCHASE_TYPE.ToString(), planDTO.PurchaseType.GetDescription());
        	PlaceHolderDict.Add(SystemEmailPersonalization.SUB_PLAN_STATUS.ToString(), planDTO.Status.GetDescription());
        	int NoOfDaysExpiry = DateUtil.getDateDiffInDays(DateUtil.getUserLocalDate(), planDTO.EndDate, 2);
        	PlaceHolderDict.Add(SystemEmailPersonalization.SUB_PLAN_NO_OFDAYS_EXPIRY.ToString(), NoOfDaysExpiry.ToString());
        	
        	return PlaceHolderDict;
        }
        public static Dictionary<string, string> populateEmailPlaceHolderDTO(VwCustomer customer) {
        	Dictionary<string, string> PlaceHolderDict = new Dictionary<string, string>();
        	PlaceHolderDict.Add(EmailPersonalization.CUSTOMER_SALUTATION.ToString(), customer.Salutation);
        	PlaceHolderDict.Add(EmailPersonalization.CUSTOMER_FIRST_NAME.ToString(), customer.FirstName);
        	PlaceHolderDict.Add(EmailPersonalization.CUSTOMER_MIDDLE_NAME.ToString(), customer.MiddleName);
        	PlaceHolderDict.Add(EmailPersonalization.CUSTOMER_LAST_NAME.ToString(), customer.LastName);
        	PlaceHolderDict.Add(EmailPersonalization.PROPERTY_NAME.ToString(), customer.PropertyName);
        	PlaceHolderDict.Add(EmailPersonalization.PROPERTY_TOWER_NAME.ToString(), customer.TowerName);
        	PlaceHolderDict.Add(EmailPersonalization.PROPERTY_UNIT_NO.ToString(), CommonUIConverter.getPropertyUnitFormattedNo(customer.Wing, customer.UnitNo));
        	
        	return PlaceHolderDict;
        }
        public static Dictionary<string, string> populateEmailPlaceHolderDTO(UserDefinition User) {
        	Dictionary<string, string> PlaceHolderDict = new Dictionary<string, string>();
        	PlaceHolderDict.Add(EmailPersonalization.CUSTOMER_SALUTATION.ToString(), User.FirmMember.Salutation.Name);
        	PlaceHolderDict.Add(EmailPersonalization.CUSTOMER_FIRST_NAME.ToString(), User.FirmMember.FirstName);
        	PlaceHolderDict.Add(EmailPersonalization.CUSTOMER_MIDDLE_NAME.ToString(), User.FirmMember.MiddleName);
        	PlaceHolderDict.Add(EmailPersonalization.CUSTOMER_LAST_NAME.ToString(), User.FirmMember.LastName);
        	PlaceHolderDict.Add(SystemEmailPersonalization.USERNAME.ToString(), User.Username);
        	PlaceHolderDict.Add(SystemEmailPersonalization.PASSWORD.ToString(), CommonUtil.Decrypt(User.Password));
        	PlaceHolderDict.Add(SystemEmailPersonalization.USERROLE.ToString(), User.UserRole.Name);
        	
        	return PlaceHolderDict;
        }
        public static string getEmailPersonalizationText(string placeholder) {
            return ("{" + placeholder + "}");
        }
        public static string ReplacePlaceholders(string EmailContent, VwCustomer customer) {
        	return ReplacePlaceholders(EmailContent, populateEmailPlaceHolderDTO(customer));
        }
        public static string ReplacePlaceholders(string EmailContent, Dictionary<string, string> PlaceHolderDict) {
        	List<string> tmpList = EnumHelper.GetEnumValues<EmailPersonalization>();
            tmpList.AddRange(EnumHelper.GetEnumValues<SystemEmailPersonalization>());
        	foreach(string placeholder in tmpList) {
                EmailContent = EmailContent.Replace(getEmailPersonalizationText(placeholder), getEmailPlaceholderValue(placeholder, PlaceHolderDict));
        	}
        	return EmailContent;
        }
        private static string getEmailPlaceholderValue(string placeholder, Dictionary<string, string> PlaceHolderDict) {
        	return (PlaceHolderDict.ContainsKey(placeholder)) ? PlaceHolderDict[placeholder] : "";
        }
    }
}