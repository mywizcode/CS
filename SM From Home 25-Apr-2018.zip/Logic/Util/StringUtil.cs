﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mail;
/// <summary>
/// Summary description for EmailUtil
/// </summary>
using ConstroSoft;
using NHibernate;

namespace ConstroSoft
{
    public static class StringUtil
    {
        //Logger Instance
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        //String extension methods
        public static string TrimNullable(this string text)
        {
        	return (text != null) ? text.Trim() : null;
        }
        
        //Util methods on String
        public static bool isValidLength(string str, int length)
        {
            return (str == null || str.Trim().Length <= length);
        }
        public static bool isValidDecimalNullable(string str)
        {
        	Decimal tmpVal;
            return (string.IsNullOrWhiteSpace(str) || Decimal.TryParse(str, out tmpVal));
        }
        public static bool isValidIntNullable(string str)
        {
        	int tmpVal;
            return (string.IsNullOrWhiteSpace(str) || int.TryParse(str, out tmpVal));
        }
        public static int getIntValue(string str)
        {
        	int tmpVal;
        	if(!string.IsNullOrWhiteSpace(str) && int.TryParse(str.Trim(), out tmpVal)) return tmpVal;
            return 0;
        }
        public static string getUnEscapedEmailContent(string content)
        {
            return (!string.IsNullOrWhiteSpace(content)) ? HttpUtility.UrlDecode(content, System.Text.Encoding.Default) : "";
        }
        public static string getBytesAsEmailContentString(byte[] content)
        {
            return (content != null) ? getUnEscapedEmailContent(Encoding.ASCII.GetString(content)) : null;
        }
        public static string getBytesAsString(byte[] content)
        {
            return (content != null) ? Encoding.ASCII.GetString(content) : null;
        }
        public static byte[] getStringAsBytes(string content)
        {
            return (!string.IsNullOrWhiteSpace(content)) ? Encoding.ASCII.GetBytes(content.TrimNullable()) : null;
        }
    }
}