﻿
/// <summary>
/// Summary description for MyENUM
/// </summary>

using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;
namespace ConstroSoft
{
    public static class CustomExtension
    {
        public static string ToSize(this int value, SizeUnits unit)
        {
            return ((value / (double)Math.Pow(1024, (Int64)unit)).ToString("N2")) + " " + unit.ToString();
        }
        public static string ToSize(this long value, SizeUnits unit)
        {
            return ((value / (double)Math.Pow(1024, (Int64)unit)).ToString("N2")) + " " + unit.ToString();
        }
        public static IEnumerable<T> Flatten<T>(this IEnumerable<T> e, Func<T,IEnumerable<T>> f) 
    	{
    	    return e.SelectMany(c => f(c).Flatten(f)).Concat(e);
    	}
    }
}