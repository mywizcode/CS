﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Web;
using OfficeOpenXml;
using System.Xml.Serialization;
using System.Xml;
using System.IO;

namespace ConstroSoft.Logic.Util
{
    public static class XMLToObjectConverter
    {
        private static readonly log4net.ILog log =
             log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public static T Deserialize<T>(string xmlText)
        {
            try
            {
                //var stringReader = new System.IO.StringReader(xmlText);
                //var serializer = new XmlSerializer(typeof(T));
                //return (T)serializer.Deserialize(stringReader);
                string innerStartTag = "ENVELOPE";
                using (var stringReader = new StringReader(xmlText))
                using (var xmlReader = XmlReader.Create(stringReader))
                {
                    if (innerStartTag != null)
                    {
                        xmlReader.ReadToDescendant(innerStartTag);
                        var xmlSerializer = new XmlSerializer(typeof(T), new XmlRootAttribute(innerStartTag));
                        return (T)xmlSerializer.Deserialize(xmlReader.ReadSubtree());
                    }
                    return (T)new XmlSerializer(typeof(T)).Deserialize(xmlReader);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                throw exp;
            }
        }
    }
}