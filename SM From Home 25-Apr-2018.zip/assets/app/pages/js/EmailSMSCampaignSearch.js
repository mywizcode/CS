﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initEmailSMSCampaignGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initEmailSMSCampaignGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#emailSMSCampaignGridBtnDiv",
        pageLength: 10,
        sorting: false
    };

    $("[id$='emailSMSCampaignSearchGrid']").CSBasicDatatable(dtOptions);
}