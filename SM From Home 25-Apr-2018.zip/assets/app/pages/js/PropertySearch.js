﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initPropertySearchGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initPropertySearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#propertySearchBtnDiv",
        pageLength: 10
    };
    
    $("[id$='propertySearchGrid']").CSBasicDatatable(dtOptions);
}




