﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
	initUserGrid();
	formatFields(controlToFormat);
    showModal(controlToFormat);
}
function initUserGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#UserSearchBtnDiv",
        pageLength: 10,
        hideSearch: true
    };

    $("[id$='UserGrid']").CSBasicDatatable(dtOptions);
}