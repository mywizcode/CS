﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
	initJobGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}
function initJobGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        rowInfoModalTitle: "Job Details",
        customBtnGrpId: "#templateSearchBtnDiv",
        sorting: false,
        pageLength: 5,
        hideSearch: true
    };

    $("[id$='JobGrid']").CSBasicDatatable(dtOptions);
}