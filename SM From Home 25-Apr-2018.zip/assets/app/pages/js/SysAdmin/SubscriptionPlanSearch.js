﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initSubscriptionPlanGrid();
	formatFields(controlToFormat);
    showModal(controlToFormat);
}
function initSubscriptionPlanGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#SubscriptionPlanSearchBtnDiv",
        pageLength: 5,
        hideSearch: true
    };

    $("[id$='SubscriptionPlanGrid']").CSBasicDatatable(dtOptions);
}