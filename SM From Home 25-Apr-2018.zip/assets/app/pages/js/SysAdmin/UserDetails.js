﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initSubscriptionPlanGrid();
	formatFields(controlToFormat);
    showModal(controlToFormat);
}
function initSubscriptionPlanGrid() {
    var dtOptions = {
        hasActionColumn: false,
        isViewOnly: false,
        pageLength: 5,
        hideSearch: true
    };

    $("[id$='SubscriptionPlanGrid']").CSBasicDatatable(dtOptions);
}