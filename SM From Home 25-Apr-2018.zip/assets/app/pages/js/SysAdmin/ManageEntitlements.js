﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initTreeActions(controlToFormat);
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initTreeActions(controlToFormat) {
	$(controlToFormat).find('span.cs-tree-title').on('click', function () {
	    var $this = $(this);
        $(controlToFormat).find("[id$='selectedEntitlementHdn']").val($this.html());
        $(controlToFormat).find("[id$='btnSelectEntitlementHdn']").click();
    });
}