﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initSelectTemplateGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}
function initSelectTemplateGrid() {
    var dtOptions = {
        hasActionColumn: false,
        hideSearch: true,
        pagination: false,
        sorting: false
    };
    $("[id$='SelectTemplateGrid']").CSBasicDatatable(dtOptions);
}