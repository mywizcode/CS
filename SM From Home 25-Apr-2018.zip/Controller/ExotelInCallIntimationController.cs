﻿using ConstroSoft.Logic.CachingProvider;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web;
using System.Web.Http;

namespace ConstroSoft.Controller
{
    public class ExotelInCallIntimationController : ApiController
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        CallHistoryBO callHistoryBO = new CallHistoryBO();
        NotificationBO notificationBO = new NotificationBO();
        /**
         * When customer dials virtual number of property then exotel send various intimation UNTILL call is answered by agent. All intimations are handled based on it's status.
         */
        [HttpGet]
        [ActionName("GetInCallIntimation")]
        public void GetInCallIntimation()
        {
            try
            {
                //Fetch CALL_HISTORY record from DB for CALLSID
                string CallSid = HttpContext.Current.Request.Params["CallSid"];
                string DialWhomNumber = HttpContext.Current.Request.Params["DialWhomNumber"];
                string Status = HttpContext.Current.Request.Params["Status"];
                CallHistoryDTO callHistoryDTO = callHistoryBO.fetchCallHistoryforCallSID(CallSid);
                FirmMemberDTO firmMemberDTO = callHistoryBO.fetchAgentForCall(DialWhomNumber);
                if(callHistoryDTO != null){
                    //Check Agent number in CALL_HISTORY is same as agent number in intimation request.
                    if(callHistoryDTO.CalleeNumber.Equals(DialWhomNumber))
                    {
                    	/*
                    	 * If earlier agent's number was dialed by exotel and agent did not answered the call then exotel sends intimation to the system with status as 'free'.
                    	 * In this case remove previous notification which was created for this user.
                    	 */
                        if(Status.Equals("free"))
                        {
                            notificationBO.removeUserNotificationsForInCall(firmMemberDTO.User, callHistoryDTO.Id);
                        }
                    }
                    else
                    {
                    	/*
                    	 * If agent number is not same as callee number in call hsitory record, it means previous agent has not answered the call and exotel has dialed new agent's number.
                    	 * In this case add incoming call intimation notification and update call history for new agent.
                    	 */
                        if(Status.Equals("busy"))
                        {
                            //Find new agent for new call number and update agent and new call history info into CALL_HISTORY table.
                            populateCallHistoryDTOForUpdate(HttpContext.Current.Request.Params, callHistoryDTO);
                            callHistoryDTO.FirmMember = firmMemberDTO;
                            long callHistoryId = callHistoryBO.updateIncomingCallForIntimation(callHistoryDTO);
                            notificationBO.createUserNotificationsForInCall(firmMemberDTO.User, callHistoryDTO);
                        }
                    }
                }
                else
                {
                    callHistoryDTO = new CallHistoryDTO();
                    populateCallHistoryDTOForAdd(HttpContext.Current.Request.Params, callHistoryDTO, firmMemberDTO);
                    callHistoryDTO.FirmMember = firmMemberDTO;
                    long callHistoryId = callHistoryBO.addCallHistory(callHistoryDTO);
                    callHistoryDTO.Id = callHistoryId;
                    notificationBO.createUserNotificationsForInCall(firmMemberDTO.User, callHistoryDTO);
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while getting inbound call details.");
                log.Error(exp.Message, exp);
            }
            finally
            {
            }
        }
        private void populateCallHistoryDTOForUpdate(NameValueCollection parameters, CallHistoryDTO callHistoryDTO)
        {
            callHistoryDTO.PhoneNumberSid = parameters["CallTo"];
            callHistoryDTO.DateCreated = Convert.ToDateTime(parameters["Created"]);
            callHistoryDTO.DateUpdated = Convert.ToDateTime(parameters["Created"]);
            callHistoryDTO.CalleeNumber = parameters["DialWhomNumber"];
            callHistoryDTO.CallStatus = CommonUtil.getCallStatus(parameters["Status"].ToString());
            callHistoryDTO.UpdateUser = Constants.SYSDEFAULT.SYSADMIN_USER;
            callHistoryDTO.UpdateDate = DateUtil.getUserLocalDateTime();
        }
        private void populateCallHistoryDTOForAdd(NameValueCollection parameters, CallHistoryDTO callHistoryDTO, FirmMemberDTO firmMemberDTO)
        {
        	/**
        	 * Assumption: There should be UNIQUE contact number across all agents from all Firms.
        	 */
            callHistoryDTO.CallSid = parameters["CallSid"];
            callHistoryDTO.CallerNumber = parameters["CallFrom"];
            callHistoryDTO.Direction = CallDirection.Incoming;
            callHistoryDTO.StartTime = Convert.ToDateTime(parameters["Created"]);
            callHistoryDTO.FirmNumber = firmMemberDTO.FirmNumber;
            callHistoryDTO.AccountSid = "";//It is updated during Call Sync through JOB
            callHistoryDTO.InsertUser = Constants.SYSDEFAULT.SYSADMIN_USER;
            callHistoryDTO.InsertDate = DateUtil.getUserLocalDateTime();
            callHistoryDTO.CallHistoryStatus = CallHistoryStatus.Unresolved;

            populateCallHistoryDTOForUpdate(parameters, callHistoryDTO);
        }
    }
}