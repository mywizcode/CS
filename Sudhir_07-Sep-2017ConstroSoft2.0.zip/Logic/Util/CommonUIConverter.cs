﻿
/// <summary>
/// Summary description for CommonUIConverter
/// </summary>
using ConstroSoft;
using System.Collections.Generic;
using NHibernate.Criterion;
using System.Linq.Expressions;
using NHibernate.Impl;
using System;
namespace ConstroSoft
{
    public class CommonUIConverter
    {
        public CommonUIConverter() { }
        public static string getPropertyUnitFormattedNo(string wing, string unitNo)
        {
            return (wing != null && !string.IsNullOrWhiteSpace(wing)) ? wing + " - " + unitNo : unitNo;
        }
        public static string getCustomerFullName(string FirstName, string LastName)
        {
            return FirstName + " " + LastName;
        }
        public static string getCustomerFullName(string FirstName, string middleName, string LastName)
        {
            return (FirstName + " " + middleName).Trim() + " " + LastName;
        }
        public static string getCustomerFullName(string Salutation, string FirstName, string middleName, string LastName)
        {
            return Salutation + " " + (FirstName + " " + middleName).Trim() + " " + LastName;
        }
        public static string getRowInfo(string col1Value, object col2Value)
        {
            string td = "<tr><td style=\"width:30%;\">{0}</td><td>{1}</td></tr>";
            return string.Format(td, col1Value, (col2Value != null) ? col2Value.ToString() : "");
        }
        public static string getRowInfo(string col1Value, object col2Value, string valueClass)
        {
            string td = "<tr><td style=\"width:30%;\">{0}</td><td class=\"{2}\">{1}</td></tr>";
            return string.Format(td, col1Value, (col2Value != null) ? col2Value.ToString() : "", valueClass);
        }
        public static string getUiFullAddress(AddressDTO addressDto)
        {
            return CommonUtil.appendBreakLine(CommonUtil.appendCommaIfNot(addressDto.AddressLine1)) 
                    + CommonUtil.appendBreakLine(CommonUtil.appendCommaIfNot(addressDto.AddressLine2)) 
                    + CommonUtil.appendBreakLine(CommonUtil.appendCommaIfNot(addressDto.Town) +" "+ CommonUtil.appendCommaIfNot(addressDto.City.Name))
                    + CommonUtil.appendCommaIfNot(addressDto.State.Name) +" "+ addressDto.Country.Name + " - " + addressDto.Pin;
        }
        public static string getGridViewRowInfo(AddressDTO addressDto)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.ADDRESS_LINE1, addressDto.AddressLine1)
                    + CommonUIConverter.getRowInfo(Resources.Labels.ADDRESS_LINE2, addressDto.AddressLine2)
                    + CommonUIConverter.getRowInfo(Resources.Labels.TOWN, addressDto.Town)
                    + CommonUIConverter.getRowInfo(Resources.Labels.CITY, addressDto.City.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.STATE, addressDto.State.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.COUNTRY, addressDto.Country.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.PIN, addressDto.Pin)
                    + CommonUIConverter.getRowInfo(Resources.Labels.ADDRESS_TYPE, (addressDto.AddressType != null) ? addressDto.AddressType.Name : "")
                    + CommonUIConverter.getRowInfo(Resources.Labels.PREFERRED_ADDRESS, addressDto.PreferredAddress);
        }

        public static string getGridViewRowInfo(CoCustomerDTO cocustomerDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.NAME, CommonUIConverter.getCustomerFullName(cocustomerDTO.SalutationId.Name, cocustomerDTO.FirstName, 
                                    cocustomerDTO.MiddleName, cocustomerDTO.LastName))
                    + CommonUIConverter.getRowInfo(Resources.Labels.GENDER, cocustomerDTO.ContactInfo.Gender)
                    + CommonUIConverter.getRowInfo(Resources.Labels.DOB, CommonUtil.getCSDate(cocustomerDTO.ContactInfo.Dob))
                    + CommonUIConverter.getRowInfo(Resources.Labels.MARITAL_STATUS, cocustomerDTO.ContactInfo.MaritalStatus)
                    + CommonUIConverter.getRowInfo(Resources.Labels.CONTACT, cocustomerDTO.ContactInfo.Contact)
                    + CommonUIConverter.getRowInfo(Resources.Labels.EMAIL, cocustomerDTO.ContactInfo.Email)
                    + CommonUIConverter.getRowInfo(Resources.Labels.OCCUPATION, (cocustomerDTO.Occupation != null) ? cocustomerDTO.Occupation.Name : "")
                    + CommonUIConverter.getRowInfo(Resources.Labels.PAN, cocustomerDTO.Pan)
                    + CommonUIConverter.getRowInfo(Resources.Labels.RELATION_WITH_PRIM_APPLICANT, cocustomerDTO.RelationWhPrimCust.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.POA, cocustomerDTO.IsPoa);
                    
        }


        public static string getGridViewRowInfo(FirmAccountDTO firmAcntDto)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.ACCOUNT_NAME, firmAcntDto.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.ACCOUNT_NUMBER, firmAcntDto.AccountNo)
                    + CommonUIConverter.getRowInfo(Resources.Labels.ACCOUNT_TYPE, (firmAcntDto.AccountType != null) ? firmAcntDto.AccountType.Name : "")
                    + CommonUIConverter.getRowInfo(Resources.Labels.ACCOUNT_BALANCE, firmAcntDto.AccountBalance, "csamount")
                    + CommonUIConverter.getRowInfo(Resources.Labels.IFSC_CODE, firmAcntDto.IfscCode)
                    + CommonUIConverter.getRowInfo(Resources.Labels.BANK_NAME, firmAcntDto.BankName)
                    + CommonUIConverter.getRowInfo(Resources.Labels.BRANCH, firmAcntDto.Branch)
                    + CommonUIConverter.getRowInfo(Resources.Labels.CITY, (firmAcntDto.City != null) ? firmAcntDto.City.Name : "")
                    + CommonUIConverter.getRowInfo(Resources.Labels.STATE, (firmAcntDto.State != null) ? firmAcntDto.State.Name : "")
                    +CommonUIConverter.getRowInfo(Resources.Labels.COUNTRY, (firmAcntDto.Country != null) ? firmAcntDto.Country.Name : "");
        }
        public static string getGridViewRowInfo(PropertyTowerDTO propertyTowerDto)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.TOWER_NAME, propertyTowerDto.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.LAUNCH_DATE, CommonUtil.getCSDate(propertyTowerDto.LaunchDate))
                    + CommonUIConverter.getRowInfo(Resources.Labels.PROPERTY_RATE, propertyTowerDto.Rate, "csamount")
                    + CommonUIConverter.getRowInfo(Resources.Labels.POSSESSION_DATE, CommonUtil.getCSDate(propertyTowerDto.Possession))
                    + CommonUIConverter.getRowInfo(Resources.Labels.DESCRIPTION, propertyTowerDto.Description);
        }
        public static string getGridViewRowInfo(PropertyTaxDetailDTO propertyTaxDetailDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.TAX_TYPE, propertyTaxDetailDTO.TaxType.Name)
                + CommonUIConverter.getRowInfo(Resources.Labels.TAX_RATE, propertyTaxDetailDTO.TaxPercentage, "cspercentaged3")
                + CommonUIConverter.getRowInfo(Resources.Labels.TAX_LIMIT, propertyTaxDetailDTO.TaxAmtLimit, "csamount")
                + CommonUIConverter.getRowInfo(Resources.Labels.TAX_INCLUDE_IN_PYMT, propertyTaxDetailDTO.IncludeInTotalPymt);
        }
        public static string getGridViewRowInfo(PropertyChargeDTO propertyChargesDetailDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.PROPERTY_CHARGE_TYPE, propertyChargesDetailDTO.ChargeType.Name)
                + CommonUIConverter.getRowInfo(Resources.Labels.AMOUNT, propertyChargesDetailDTO.ChargeValue, "csamount");
                
        }
        public static string getGridViewRowInfo(PropertyScheduleDTO propertyScheduleDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.STAGE_NO, propertyScheduleDTO.StageNumber)
                + CommonUIConverter.getRowInfo(Resources.Labels.STAGE, propertyScheduleDTO.Stage)
                + CommonUIConverter.getRowInfo(Resources.Labels.PERCENTAGE, propertyScheduleDTO.Percentage, "cspercentaged0")
                + CommonUIConverter.getRowInfo(Resources.Labels.STATUS, propertyScheduleDTO.Status);
        }
        public static string getGridViewRowInfo(PrUnitSaleTaxDetailDTO prUnitSaleTaxDetailDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.TAX_TYPE, prUnitSaleTaxDetailDTO.TaxType.Name)
                + CommonUIConverter.getRowInfo(Resources.Labels.TAX_RATE, prUnitSaleTaxDetailDTO.TaxPercentage, "cspercentaged3")
                + CommonUIConverter.getRowInfo(Resources.Labels.TAX_LIMIT, prUnitSaleTaxDetailDTO.TaxAmtLimit, "csamount")
                + CommonUIConverter.getRowInfo(Resources.Labels.AMOUNT, prUnitSaleTaxDetailDTO.TaxAmt, "csamount");
        }
        public static string getGridViewRowInfo(PrUnitSalePymtDTO prUnitSalePymtDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.PAYMENT_TYPE, prUnitSalePymtDTO.PymtType.Name)
                + CommonUIConverter.getRowInfo(Resources.Labels.PAYMENT_DATE, CommonUtil.getCSDate(prUnitSalePymtDTO.PymtDate))
                + CommonUIConverter.getRowInfo(Resources.Labels.PAYMENT_AMOUNT, prUnitSalePymtDTO.PymtAmt, "csamount")
                + CommonUIConverter.getRowInfo(Resources.Labels.TOTAL_PAID, prUnitSalePymtDTO.PaymentMaster.TotalPaid, "csamount")
                + CommonUIConverter.getRowInfo(Resources.Labels.PAYMENT_TO, prUnitSalePymtDTO.PymtTo)
                + CommonUIConverter.getRowInfo(Resources.Labels.STATUS, prUnitSalePymtDTO.PaymentMaster.Status)
                + CommonUIConverter.getRowInfo(Resources.Labels.DESCRIPTION, prUnitSalePymtDTO.Description);
        }
        public static string getGridViewRowInfo(EnquiryFollowupDTO enquiryFollowupDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.SALES_EXECUTIVE, enquiryFollowupDTO.FirmMember.FirstName)
                    + CommonUIConverter.getRowInfo(Resources.Labels.FOLLOWUP_DATE, CommonUtil.getCSDate(enquiryFollowupDTO.FollowupDate))
                    + CommonUIConverter.getRowInfo(Resources.Labels.COMMUNICATION_MEDIA, enquiryFollowupDTO.CommunicationMedia.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.COMMENTS, enquiryFollowupDTO.Comments);
        }
        public static string getGridViewRowInfo(PropertyUnitDTO propertyUnitDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.WING, propertyUnitDTO.Wing)
                + CommonUIConverter.getRowInfo(Resources.Labels.FLOOR_NO, propertyUnitDTO.FloorNo)
                + CommonUIConverter.getRowInfo(Resources.Labels.UNIT_NO, propertyUnitDTO.UnitNo)
                + CommonUIConverter.getRowInfo(Resources.Labels.UNIT_TYPE, (propertyUnitDTO.UnitType != null) ? propertyUnitDTO.UnitType.Name : "")
                + CommonUIConverter.getRowInfo(Resources.Labels.BUILTUP_AREA, propertyUnitDTO.BuildupArea, "cssqftarea")
                + CommonUIConverter.getRowInfo(Resources.Labels.CARPET_AREA, propertyUnitDTO.CarpetArea, "cssqftarea")
                + CommonUIConverter.getRowInfo(Resources.Labels.BALCONY_AREA, propertyUnitDTO.BalconyArea, "cssqftarea")
                + CommonUIConverter.getRowInfo(Resources.Labels.NO_OF_BALCONY, propertyUnitDTO.NoOfBalcony)
                + CommonUIConverter.getRowInfo(Resources.Labels.FACING, (propertyUnitDTO.Facing != null) ? propertyUnitDTO.Facing.Name : "")
                + CommonUIConverter.getRowInfo(Resources.Labels.DIRECTION, (propertyUnitDTO.Direction != null) ? propertyUnitDTO.Direction.Name : "")
                + CommonUIConverter.getRowInfo(Resources.Labels.STATUS, propertyUnitDTO.Status);
        }

        public static string getGridViewRowInfo(PropertyParkingDTO propertyParkingtDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.PARKING_NO, propertyParkingtDTO.ParkingNo)
                + CommonUIConverter.getRowInfo(Resources.Labels.PARKING_TYPE, propertyParkingtDTO.ParkingType!=null?propertyParkingtDTO.ParkingType.Name:null)
                + CommonUIConverter.getRowInfo(Resources.Labels.PARKING_AREA, propertyParkingtDTO.Area, "cssqftarea")
                + CommonUIConverter.getRowInfo(Resources.Labels.STATUS, propertyParkingtDTO.Status)
                + CommonUIConverter.getRowInfo(Resources.Labels.COMMON_PARKING, propertyParkingtDTO.CommonParking);
        }
        public static string getGridViewRowInfo(PaymentTransactionDTO paymentTransactionDto)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.TX_NO, paymentTransactionDto.Id)
                + CommonUIConverter.getRowInfo(Resources.Labels.TRANSACTION_DATE, CommonUtil.getCSDate(paymentTransactionDto.TxDate))
                + CommonUIConverter.getRowInfo(Resources.Labels.AMOUNT, paymentTransactionDto.Amount, "csamount")
                + CommonUIConverter.getRowInfo(Resources.Labels.INVOICE_NUMBER, paymentTransactionDto.InvoiceNumber)
                + CommonUIConverter.getRowInfo(Resources.Labels.PAYMENT_MODE, paymentTransactionDto.PymtMode)
                + CommonUIConverter.getRowInfo(Resources.Labels.CHEQUE_DATE, CommonUtil.getCSDate(paymentTransactionDto.ChequeDate))
                + CommonUIConverter.getRowInfo(Resources.Labels.CHEQUE_NO, paymentTransactionDto.ChequeNo)
                + CommonUIConverter.getRowInfo(Resources.Labels.BANK_NAME, paymentTransactionDto.BankName)
                + CommonUIConverter.getRowInfo(Resources.Labels.BRANCH, paymentTransactionDto.Branch)
                + CommonUIConverter.getRowInfo(Resources.Labels.STATUS, paymentTransactionDto.Status)
                + CommonUIConverter.getRowInfo(Resources.Labels.COMMENTS, paymentTransactionDto.Comments);
        }
        public static string getGridViewRowInfo(PdcPymtDTO pdcPymtDto, string pymtDirection)
        {
            if (pymtDirection == Constants.PYMT_DIRECTION.FIRM_AGENCY)
            {
                return CommonUIConverter.getRowInfo(Resources.Labels.AGENCY, pdcPymtDto.PymtFor)
                    + CommonUIConverter.getRowInfo(Resources.Labels.EXPENSE_DATE, CommonUtil.getCSDate(pdcPymtDto.ExpenseDate))
                    + CommonUIConverter.getRowInfo(Resources.Labels.EXPENSE_TYPE, pdcPymtDto.PymtType.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.TOTAL_AMOUNT, pdcPymtDto.TotalPymtAmt, "csamount")
                    + CommonUIConverter.getRowInfo(Resources.Labels.TOTAL_PAID, pdcPymtDto.TotalPaidAmt, "csamount")
                    + CommonUIConverter.getRowInfo(Resources.Labels.TX_AMOUNT, pdcPymtDto.PaymentTransaction.Amount, "csamount")
                    + CommonUIConverter.getRowInfo(Resources.Labels.TX_STATUS, pdcPymtDto.PaymentTransaction.Status)
                    + CommonUIConverter.getRowInfo(Resources.Labels.PYMT_STATUS, pdcPymtDto.PymtMstStatus)
                    + CommonUIConverter.getRowInfo(Resources.Labels.COMMENTS, pdcPymtDto.PaymentTransaction.Comments);
            }
            else
            {
                return CommonUIConverter.getRowInfo(Resources.Labels.UNIT_NO, pdcPymtDto.UnitNo)
                    + CommonUIConverter.getRowInfo(Resources.Labels.PAYMENT_TYPE, pdcPymtDto.PymtType.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.TOTAL_AMOUNT, pdcPymtDto.TotalPymtAmt.ToString(), "csamount")
                    + CommonUIConverter.getRowInfo(Resources.Labels.TOTAL_PAID, pdcPymtDto.TotalPaidAmt.ToString(), "csamount")
                    + CommonUIConverter.getRowInfo(Resources.Labels.TX_AMOUNT, pdcPymtDto.PaymentTransaction.Amount.ToString(), "csamount")
                    + CommonUIConverter.getRowInfo(Resources.Labels.TX_STATUS, pdcPymtDto.PaymentTransaction.Status)
                    + CommonUIConverter.getRowInfo(Resources.Labels.PYMT_STATUS, pdcPymtDto.PymtMstStatus)
                    + CommonUIConverter.getRowInfo(Resources.Labels.COMMENTS, pdcPymtDto.PaymentTransaction.Comments);
            }
        }
        public static string getGridViewRowInfo(MasterControlDataDTO masterControlDataDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.DATA_TYPE, masterControlDataDTO.Type != null ? masterControlDataDTO.Type : null)
                + CommonUIConverter.getRowInfo(Resources.Labels.NAME, masterControlDataDTO.Name.ToString(), null)
                + CommonUIConverter.getRowInfo(Resources.Labels.SYSTEM_DEFINED, masterControlDataDTO.SystemDefined)
                + CommonUIConverter.getRowInfo(Resources.Labels.DESCRIPTION, masterControlDataDTO.Description);         
        }

        public static CityDTO getCityDTO(string Id, string Name)
        {
            CityDTO dto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                dto = new CityDTO();
                dto.Id = long.Parse(Id);
                dto.Name = Name;
            }
            return dto;
        }
        public static StateDTO getStateDTO(string Id, string Name)
        {
            StateDTO dto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                dto = new StateDTO();
                dto.Id = long.Parse(Id);
                dto.Name = Name;
            }
            return dto;
        }
        public static CountryDTO getCountryDTO(string Id, string Name)
        {
            CountryDTO dto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                dto = new CountryDTO();
                dto.Id = long.Parse(Id);
                dto.Name = Name;
            }
            return dto;
        }
        public static MasterControlDataDTO getMasterControlDTO(string Id, string Name)
        {
            MasterControlDataDTO mdDto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                mdDto = new MasterControlDataDTO();
                mdDto.Id = long.Parse(Id);
                mdDto.Name = Name;
            }
            return mdDto;
        }
        public static AgencyDTO getAgencyDTO(string Id, string Name)
        {
            AgencyDTO agencyDto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                agencyDto = new AgencyDTO();
                agencyDto.Id = long.Parse(Id);
                agencyDto.AgencyName = Name;
            }
            return agencyDto;
        }
		 public static AccountTransactionDTO getAccountTransactionDTO(string Id, string accountno)
        {
            AccountTransactionDTO mdDto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                mdDto = new AccountTransactionDTO();
                mdDto.Id = long.Parse(Id);
                mdDto.FirmAccount.AccountNo = accountno;
            }
            return mdDto;
        }
        public static FirmAccountDTO getFirmAccountDTO(string Id, string Name)
        {
            FirmAccountDTO dto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                dto = new FirmAccountDTO();
                dto.Id = long.Parse(Id);
                dto.Name = Name;
            }
            return dto;
        }
        public static FirmMemberDTO getFirmMemberDTO(string Id, string Name)
        {
            FirmMemberDTO dto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                dto = new FirmMemberDTO();
                dto.Id = long.Parse(Id);
                dto.FirstName = Name;
            }
            return dto;
        }
        public static CustomerDTO getCustomerDTO(string Id, string Name)
        {
            CustomerDTO dto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                dto = new CustomerDTO();
                dto.Id = long.Parse(Id);
                dto.FirstName = Name;
            }
            return dto;
        }
        public static PropertyDTO getPropertyDTO(string Id, string Name)
        {
            PropertyDTO dto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                dto = new PropertyDTO();
                dto.Id = long.Parse(Id);
                dto.Name = Name;
            }
            return dto;
        }
        public static PropertyTowerDTO getPropertyTowerDTO(string Id, string Name)
        {
            PropertyTowerDTO dto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                dto = new PropertyTowerDTO();
                dto.Id = long.Parse(Id);
                dto.Name = Name;
            }
            return dto;
        }
        public static PropertyParkingDTO getPropertyParkingDTO(string Id, string Name)
        {
            PropertyParkingDTO dto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                dto = new PropertyParkingDTO();
                dto.Id = long.Parse(Id);
                dto.ParkingNo = Name;
            }
            return dto;
        }
        public static MasterControlDataDTO populateMasterDataDTOAdd(string type, string name, string description, UserDefinitionDTO userDefDto)
        {
            MasterControlDataDTO masterDataDto = new MasterControlDataDTO();
            masterDataDto.Name = name;
            masterDataDto.Description = description;
            masterDataDto.FirmNumber = userDefDto.FirmNumber;
            masterDataDto.InsertUser = userDefDto.Username;
            masterDataDto.UpdateUser = userDefDto.Username;
            masterDataDto.Type = type;
            masterDataDto.SystemDefined = SystemDefined.No;
            return masterDataDto;
        }
        public static string getGridViewRowInfo(DocumentDTO documentDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.DOCUMENT_NAME, documentDTO.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.DOCUMENT_TYPE, documentDTO.DocumentType.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.DESCRIPTION, documentDTO.Description);
        }
        public static string getGridViewRowInfo(FirmAcntDepositeDTO firmAcntDepositeDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.AMOUNT, firmAcntDepositeDTO.FirmAccount.Name)
                + CommonUIConverter.getRowInfo(Resources.Labels.PAYMENT_MODE, firmAcntDepositeDTO.PymtMode)
                + CommonUIConverter.getRowInfo(Resources.Labels.AMOUNT, firmAcntDepositeDTO.Amount.ToString(), "csamount")
                + CommonUIConverter.getRowInfo(Resources.Labels.TRANSACTION_DATE, CommonUtil.getCSDate(firmAcntDepositeDTO.DepositeDate))
                + CommonUIConverter.getRowInfo(Resources.Labels.CHEQUE_NO, firmAcntDepositeDTO.ChequeNo)
                + CommonUIConverter.getRowInfo(Resources.Labels.BANK_NAME, firmAcntDepositeDTO.BankName)
                + CommonUIConverter.getRowInfo(Resources.Labels.BRANCH, firmAcntDepositeDTO.Branch)
                + CommonUIConverter.getRowInfo(Resources.Labels.STATUS, firmAcntDepositeDTO.Status)
                + CommonUIConverter.getRowInfo(Resources.Labels.COMMENTS, firmAcntDepositeDTO.Description);
        }
        public static string getGridViewRowInfo(PaymentVoucherDTO paymentVoucherDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.VOUCHER_TYPE, paymentVoucherDTO.VoucherType)
                + CommonUIConverter.getRowInfo(Resources.Labels.ACTION, paymentVoucherDTO.Action)
                + CommonUIConverter.getRowInfo(Resources.Labels.VOUCHER_DATE, CommonUtil.getCSDate(paymentVoucherDTO.VoucherDate))
                + CommonUIConverter.getRowInfo(Resources.Labels.VOUCHER_NARRATION, paymentVoucherDTO.VoucherNaration)
                + CommonUIConverter.getRowInfo(Resources.Labels.VOUCHER_NUMBER, paymentVoucherDTO.VoucherNumber)
                + CommonUIConverter.getRowInfo(Resources.Labels.PARTY_LEDGER_NAME, paymentVoucherDTO.PartyLedgerName)
                + CommonUIConverter.getRowInfo(Resources.Labels.POSTING_STATUS, paymentVoucherDTO.PostingStatus);
        }
    }
}