﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Constants.
/// </summary>
namespace ConstroSoft
{
    public static class Constants
    {
        //Page Constants
        public class URL
        {
            public const string LOGIN = "/Login";
            public const string CHANGE_PASSWORD = "ChangePassword";
            public const string FORGOT_PASSWORD = "ForgotPassword";
            public const string LOGIN_SETUP = "LoginSetup";

            public const string DEFAULT_HOME_PAGE = "~/CRM/CRMDashboard";
            //CRM Menu
            public const string CRM_DASHBOARD = "~/CRM/CRMDashboard";
            public const string AVAILABLE_UNIT_SEARCH = "~/CRM/AvailableUnitSearch";
            public const string SOLD_UNIT_SEARCH = "~/CRM/SoldUnitSearch";
            public const string CANCELLED_UNIT_SEARCH = "~/CRM/CancelledUnitSearch";
            public const string BOOKING_FORM = "~/CRM/AvailableUnitSearch/BookingForm";
            public const string BOOKING_SUCCESS = "~/CRM/AvailableUnitSearch/BookingSuccess";
        }
        public class Function
        {
            public const string CRM = "CRM";
            public const string ERP = "ERP";
            public const string FIRM_PROPERTY_SETUP = "FirmPropertySetup";
            public const string ACNT_FINANCE = "AcntFinance";
            public const string ADMINISTRATION = "Administration";
            public const string PROPERTY_WITH_ACCESS = "PROPERTY_WITH_ACCESS";
        }
        public class Session
        {
            public const string USERDEFINITION = "USERDEFINITION";
            public const string USERNAME = "USERNAME";
            public const string NOTY_MSG = "NOTY_MSG";
            public const string FUNCTION_NAME = "FUNCTION";
            public const string NAV_AVAILABLE_UNIT = "NAV_AVAILABLE_UNIT";
            public const string NAV_BOOKING_FORM = "NAV_BOOKING_FORM";
            public const string NAV_BOOKING_SUCCESS = "NAV_BOOKING_SUCCESS";
            public const string NAV_SOLD_UNIT = "NAV_SOLD_UNIT";
        }
        public class Entitlement
        {
            public const string MENU_DASHBOARD = "MENU_DASHBOARD";
            public const string MENU_APPLICATION_SETUP = "MENU_APPLICATION_SETUP";
            public const string MENU_FIRM_AND_ACCOUNTS = "MENU_FIRM_AND_ACCOUNTS";
            public const string FIRM_MODIFY = "FIRM_MODIFY";
            public const string ACCOUNT_ADD = "ACCOUNT_ADD";
            public const string ACCOUNT_MODIFY = "ACCOUNT_MODIFY";
            public const string ACCOUNT_DELETE = "ACCOUNT_DELETE";
            public const string MENU_MANAGE_MASTER = "MENU_MANAGE_MASTER";
            public const string MASTER_DATA_ADD = "MASTER_DATA_ADD";
            public const string MASTER_DATA_MODIFY = "MASTER_DATA_MODIFY";
            public const string MASTER_DATA_DELETE = "MASTER_DATA_DELETE";
            public const string MENU_PROPERTY_USER_ACCESS = "MENU_PROPERTY_USER_ACCESS";
            public const string MENU_EMAIL_SMS_CONFIG = "MENU_EMAIL_SMS_CONFIG";
            public const string MENU_ACCOUNT_MANAGEMENT = "MENU_ACCOUNT_MANAGEMENT";
            public const string MENU_ACCOUNT_SUMMARY = "MENU_ACCOUNT_SUMMARY";
            public const string MENU_ACCOUNT_DEPOSIT = "MENU_ACCOUNT_DEPOSIT";
            public const string ACCOUNT_DEPOSIT_ADD = "ACCOUNT_DEPOSIT_ADD";
            public const string ACCOUNT_DEPOSIT_DELETE = "ACCOUNT_DEPOSIT_DELETE";
            public const string MENU_PROPERTY_MANAGEMENT = "MENU_PROPERTY_MANAGEMENT";
            public const string MENU_MANAGE_PROPERTY = "MENU_MANAGE_PROPERTY";
            public const string PROPERTY_ADD = "PROPERTY_ADD";
            public const string PROPERTY_MODIFY = "PROPERTY_MODIFY";
            public const string PROPERTY_DELETE = "PROPERTY_DELETE";
            public const string MENU_PROPERTY_PYMT_SCHEDULE = "MENU_PROPERTY_PYMT_SCHEDULE";
            public const string PYMT_SCHEDULE_ADD = "PYMT_SCHEDULE_ADD";
            public const string PYMT_SCHEDULE_MODIFY = "PYMT_SCHEDULE_MODIFY";
            public const string PYMT_SCHEDULE_DELETE = "PYMT_SCHEDULE_DELETE";
            public const string MENU_PROPERTY_UNIT = "MENU_PROPERTY_UNIT";
            public const string PROPERTY_UNIT_ADD = "PROPERTY_UNIT_ADD";
            public const string PROPERTY_UNIT_MODIFY = "PROPERTY_UNIT_MODIFY";
            public const string PROPERTY_UNIT_DELETE = "PROPERTY_UNIT_DELETE";
            public const string MENU_PROPERTY_PARKING = "MENU_PROPERTY_PARKING";
            public const string PROPERTY_PARKING_ADD = "PROPERTY_PARKING_ADD";
            public const string PROPERTY_PARKING_MODIFY = "PROPERTY_PARKING_MODIFY";
            public const string PROPERTY_PARKING_DELETE = "PROPERTY_PARKING_DELETE";
            public const string MENU_PROPERTY_EXPENSE = "MENU_PROPERTY_EXPENSE";
            public const string PROPERTY_EXPENSE_ADD = "PROPERTY_EXPENSE_ADD";
            public const string PROPERTY_EXPENSE_MODIFY = "PROPERTY_EXPENSE_MODIFY";
            public const string PROPERTY_EXPENSE_DELETE = "PROPERTY_EXPENSE_DELETE";
            public const string MENU_AGENCY = "MENU_AGENCY";
            public const string AGENCY_ADD = "AGENCY_ADD";
            public const string AGENCY_MODIFY = "AGENCY_MODIFY";
            public const string AGENCY_DELETE = "AGENCY_DELETE";
            public const string MENU_ENQUIRY_MANAGEMENT = "MENU_ENQUIRY_MANAGEMENT";
            public const string MENU_MANAGE_ENQUIRY = "MENU_MANAGE_ENQUIRY";
            public const string ENQUIRY_ADD = "ENQUIRY_ADD";
            public const string ENQUIRY_MODIFY = "ENQUIRY_MODIFY";
            public const string ENQUIRY_DELETE = "ENQUIRY_DELETE";
            public const string MANAGE_ENQUIRY_FOLLOWUP = "MANAGE_ENQUIRY_FOLLOWUP";
            public const string MENU_MANAGE_CUSTOMERS = "MENU_MANAGE_CUSTOMERS";
            public const string CUSTOMER_ADD = "CUSTOMER_ADD";
            public const string CUSTOMER_MODIFY = "CUSTOMER_MODIFY";
            public const string CUSTOMER_DELETE = "CUSTOMER_DELETE";
            public const string MENU_SALES_MANAGEMENT = "MENU_SALES_MANAGEMENT";
            public const string MENU_AVAILABLE_PROPERTY_UNITS = "MENU_AVAILABLE_PROPERTY_UNITS";
            public const string PROPERTY_UNIT_BOOK = "PROPERTY_UNIT_BOOK";
            public const string MENU_SOLD_PROPERTY_UNITS = "MENU_SOLD_PROPERTY_UNITS";
            public const string SOLD_UNIT_MODIFY = "SOLD_UNIT_MODIFY";
            public const string CANCEL_BOOKING = "CANCEL_BOOKING";
            public const string MENU_CANCELLED_PROPERTY_UNITS = "MENU_CANCELLED_PROPERTY_UNITS";
            public const string CANCEL_UNIT_MODIFY = "CANCEL_UNIT_MODIFY";
            public const string MENU_PAYMENT_MANAGEMENT = "MENU_PAYMENT_MANAGEMENT";
            public const string MENU_PAYMENTS = "MENU_PAYMENTS";
            public const string MAKE_PAYMENT = "MAKE_PAYMENT";
            public const string MENU_MANAGE_PDC = "MENU_MANAGE_PDC";
            public const string PDC_ADD = "PDC_ADD";
            public const string PDC_MODIFY = "PDC_MODIFY";
            public const string PDC_DELETE = "PDC_DELETE";
            public const string MENU_PROMOTION_MANAGEMENT = "MENU_PROMOTION_MANAGEMENT";
            public const string MENU_MANAGE_PROMOTIONS = "MENU_MANAGE_PROMOTIONS";
            public const string MENU_REPORTS_AND_ANALYTICS = "MENU_REPORTS_AND_ANALYTICS";
            public const string MENU_PYMT_DUE_REPORT = "MENU_PYMT_DUE_REPORT";
            public const string MENU_PYMT_SCHEDULE_REPORT = "MENU_PYMT_SCHEDULE_REPORT";
            public const string MENU_DOCUMENT_MANAGEMENT = "MENU_DOCUMENT_MANAGEMENT";
            public const string MENU_MANAGE_DOCUMENT = "MENU_MANAGE_DOCUMENT";
            public const string DOCUMENT_ADD = "DOCUMENT_ADD";
            public const string DOCUMENT_DOWNLOAD = "DOCUMENT_DOWNLOAD";
            public const string DOCUMENT_DELETE = "DOCUMENT_DELETE";

            //To delete
            
            //Sub-Menu : End
            //Firm Page
            public const string FIRM_ACCOUNT_ADD_UPDATE = "FIRM_ACCOUNT_ADD_UPDATE";
            public const string FIRM_MEMBER_ADD_UPDATE = "FIRM_MEMBER_ADD_UPDATE";
            //Customer Page
            public const string CUSTOMER_ADD_UPDATE = "CUSTOMER_ADD_UPDATE";
            //Enquiry Page
            public const string ENQUIRY_ADD_UPDATE = "ENQUIRY_ADD_UPDATE";

            public const string VOUCHER_POST = "VOUCHER_POST";
            public const string VOUCHER_POST_ALL = "VOUCHER_POST_ALL";

        }
        public class MCDType
        {
            public const string SALUTATION = "SALUTATION";
            public const string SECURITY_QUESTION = "SECURITY_QUESTION";
            public const string ACCOUNT_TYPE = "ACCOUNT_TYPE";
            public const string ADDRESS_TYPE = "ADDRESS_TYPE";
            public const string PROPERTY_TYPE = "PROPERTY_TYPE";
            public const string PROPERTY_LOCATION = "PROPERTY_LOCATION";
            public const string PR_TAX_TYPE = "PR_TAX_TYPE";
            public const string PR_EXPENSE_TYPE = "PR_EXPENSE_TYPE";
            public const string PR_UNIT_TYPE = "PR_UNIT_TYPE";
            public const string PR_UNIT_PARKING_TYPE = "PR_UNIT_PARKING_TYPE";
            public const string PR_UNIT_FACING = "PR_UNIT_FACING";
            public const string PR_UNIT_DIRECTION = "PR_UNIT_DIRECTION";
            public const string OCCUPATION = "OCCUPATION";
            public const string CUSTOMER_RELATION = "CUSTOMER_RELATION";
            public const string PR_UNIT_PYMT_TYPE = "PR_UNIT_PYMT_TYPE";
            public const string PURCHASE_ITEM_QUALITY = "PURCHASE_ITEM_QUALITY";
            public const string CONTRACTOR_TYPE = "CONTRACTOR_TYPE";
            public const string ENQUIRY_SOURCE = "ENQUIRY_SOURCE";
            public const string ENQUIRY_MEDIA_TYPE = "ENQUIRY_MEDIA_TYPE";
            public const string DOCUMENT_TYPE = "DOCUMENT_TYPE";
            public const string RELATION_WITH_CUSTOMER = "RELATION_WITH_CUSTOMER";
			public const string TOWER = "TOWER";
            public const string UNIT_TYPE = "UNIT_TYPE";
            public const string DIRECTION = "DIRECTION";
            public const string FACING = "FACING";
            public const string PROPERTY_NAME = "PROPERTY_NAME";
            public const string PR_PARKING_TYPE = "PROPERTY_PARKING_TYPE";
			public const string AGENCY = "AGENCY";
            public const string PROPERTY_CHARGES = "PROPERTY_CHARGES";
            public const string AGENCY_TYPE = "AGENCY_TYPE";
            public const string COMMUNICATION_MEDIA = "COMMUNICATION_MEDIA";
        }
        public class FUNCTIONNAME
        {
            public const string ENQUIRY = "MANAGE ENQUIRY";
            public const string SALE = "MANAGE SALES";

        }
        public class EMAILSMSTYPE
        {
            public const string ENQUIRYTHANKS = "ENQUIRY THANKS";
            public const string SALESTHANKS = "SALE THANKS";
            public const string SALESCANCEL = "SALE CANCEL";
        }
        public class PYMT_DIRECTION
        {
            public const string FIRM_CUSTOMER = "FIRM_CUSTOMER";
            public const string FIRM_CONTRACTOR = "FIRM_CONTRACTOR";
            public const string FIRM_SUPPLIER = "FIRM_SUPPLIER";
            public const string FIRM_AGENCY = "FIRM_AGENCY";
            public const string CUSTOMER_FIRM = "CUSTOMER_FIRM";
            public const string INVALID_PYMT_DIRECTION = "INVALID_PYMT_DIRECTION";
        }
        public class FILTER
        {
            public const string TOWER_NAME = "Tower: ";
            public const string PROPERTY_NAME = "Name: ";
            public const string PROPERTY_TYPE = "Type: ";
            public const string PROPERTY_LOCATION = "Location: ";
            public const string UNIT_NO = "Unit No: ";
            public const string UNIT_TYPE = "Unit Type: ";
            public const string WING = "Wing: ";
            public const string FLOOR_NO = "Floor No: ";
            public const string STATUS = "Status: ";
            public const string FIRST_NAME = "First Name: ";
            public const string LAST_NAME = "Last Name: ";
            public const string DOB = "Dob: ";
            public const string CONTACT = "Contact: ";
            public const string CUST_REF_NO = "Customer Ref #: ";
            public const string CUSTOMER = "Customer: ";
            public const string SALES_EXECUTIVE = "Executive: ";
        }
        public class ICON
        {
        	public const string ADD = "<i class=\"icon-googleplus5 position-left\"></i>";
            public const string MODIFY = "<i class=\"icon-pencil7 position-left\"></i>";
            public const string SEARCH = "<i class=\"icon-stack2 position-left\"></i>";
            public const string VIEW_DTL = "<i class=\"icon-grid position-left\"></i>";
            public const string UPLOAD = "<i class=\"icon-upload7 position-left\"></i>";
            public const string CRM_FN_MENU = "<i class=\"icon-people\"></i>";
            public const string ERP_FN_MENU = "<i class=\"icon-construction\"></i>";
            public const string ACNTFINANCE_FN_MENU = "<i class=\"icon-calculator\"></i>";
            public const string PR_SETUP_FN_MENU = "<i class=\"icon-sphere\"></i>";
            public const string ADMIN_FN_MENU = "<i class=\"icon-gear\"></i>";
        }
        public class NOTY_TYPE
        {
            public const string SUCCESS = "success";
            public const string ERROR = "error";
            public const string WARNING = "warning";
            public const string INFO = "information";
        }
        public const string DATE_FORMAT = "dd-MMM-yyyy";
        public const string TALLY_DATE_FORMAT = "yyyyMMdd";
        public const string DEFAULT_COUNTRY = "1";
        public const string DEFAULT_STATE = "21";
        public const string SCROLL_TOP = "TOP";
        public const string MCD_SALE_PAYMENT = "SALE PAYMENT";
        public const string MCD_CANCELLATION_PAYMENT = "CANCELLATION PAYMENT";
        public static readonly string[] SELECT_ITEM = { "--Select--", "" };
        public static readonly string[] SEC_QUESTION_SELECT_ITEM = { "--Select Security Question--", "" };
        public static readonly string[] APPENDERS = { "Rs.", "%", "Sq.Ft.", "Sq.Mtr." };
        public const string YES = "Y";
        public const string UPLOAD_VALIDATED = "Validated Successfully";
        public const string UPLOAD_SUCCESS = "Uploaded Successfully";
        //Account Transaction Comments
        public const string PYMT_FROM = "PYMT FROM {0}";
        public const string REV_PYMT_FROM = "REVERSAL-PYMT FROM {0}";
        public const string PYMT_TO = "PYMT TO {0}";
        public const string REV_PYMT_TO = "REVERSAL-PYMT TO {0}";
        public const string CASH_PYMT_MODE = "MODE-CASH";
        public const string CHQ_PYMT_MODE = "MODE-CHQUE,CHQUE#{0}";
        public const string NEFT_PYMT_MODE = "MODE-NEFT";
        public const string DD_PYMT_MODE = "MODE-DD";
        public const string RTGS_PYMT_MODE = "MODE-RTGS";
        public const string TX_REF = "TX REF#{0}";
        public const string REV_TX_REF = "REV TX REF#{0}";
        public const string UNIT_SALE_TYPE = "UNIT SALE-";
        public const string PROP_EXP_TYPE = "EXPENSE TYPE-";
        public const string TOKEN_FIELD_DELIMITER = "~";
        public const string SEP1 = "~~";
        public const string SEP2 = "~";
        //Tally Constant
        public const string VOUCHER_CREATE_ACTION = "Create";
        public const string VOUCHER_CANCEL_ACTION = "Cancel";
        public const string VOUCHER_TYPE_PAYMENT = "Payment";
        public const string VOUCHER_TYPE_RECEIPT = "Receipt";
        public const string VOUCHER_YES = "Yes";
        public const string VOUCHER_NO = "No";
        public const string VOUCHER_BILL_LEDGERTYPE = "Bill";
        public const string VOUCHER_BANK_LEDGERTYPE = "Bank";
        public const string VOUCHER_LEDGERNAME_CASH = "Cash";
        public const string VOUCHER_CHEQUE_COMMENT = "A/c Payee";
        public const string VOUCHER_PENDING = "Pending";
        public const string VOUCHER_BILLTYPE = "New Ref";

    }
}