﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ConstroSoft;

/// <summary>
/// Summary description for UserDefinitionDTO
/// </summary>
namespace ConstroSoft
{
    [Serializable]
    public class PropertyFilterDTO
    {
        public PropertyFilterDTO() { }
        public long PropertyId { get; set; }
        public string PropertyName { get; set; }
        public MasterControlDataDTO Type { get; set; }
        public MasterControlDataDTO Location { get; set; }
    }
    [Serializable]
    public class PropertyUnitFilterDTO
    {
        public PropertyUnitFilterDTO() { }
        public long UnitId { get; set; }
        public string UnitNo { get; set; }
        public string Wing { get; set; }
        public string FloorNo { get; set; }
        public MasterControlDataDTO UnitType { get; set; }
        public PRUnitStatus? Status { get; set; }
    }
    [Serializable]
    public class SoldUnitFilterDTO
    {
        public SoldUnitFilterDTO() { }
        public long UnitId { get; set; }
        public string UnitNo { get; set; }
        public long CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string CustRefNo { get; set; }
        public long SalesExecutiveId { get; set; }
        public string SalesExecutiveName { get; set; }
    }
    [Serializable]
    public class CustomerFilterDTO
    {
        public CustomerFilterDTO() { }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime? Dob { get; set; }
        public string Contact { get; set; }
        public string CustRefNo { get; set; }
    }
}