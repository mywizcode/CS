﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq.Expressions;
using NHibernate.Impl;
using System.Linq;
using System.Net.Mail;
using System.Net.Mime;
using System.IO;

namespace ConstroSoft.Logic.BO
{
    
    public class SoldPropertyUnitBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        

        public SoldPropertyUnitBO() { }

        public IList<PrUnitSaleDetailDTO> fetchSoldPropertyUnits(string firmNumber, long propertyTowerId, SoldUnitFilterDTO filterDTO)
        {
            ISession session = null;
            IList<PrUnitSaleDetailDTO> result = new List<PrUnitSaleDetailDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Property p = null;
                        PropertyUnit pu = null;
                        PrUnitSaleDetail pus = null;
                        Customer c = null;
                        PropertyTower pt = null;
                        MasterControlData putype = null;
                        FirmMember fm = null;

                        PrUnitSaleDetailDTO pusdto = null;

                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => pus.Id).WithAlias(() => pusdto.Id))
                                    .Add(Projections.SqlFunction("concat",
                                                NHibernateUtil.String,
                                                Projections.Property(() => c.FirstName),
                                                Projections.Constant(" "),
                                                Projections.Property(() => c.LastName)), "Customer.FirstName")
                                    .Add(Projections.Property(() => c.Id), "Customer.Id")
                                    .Add(Projections.SqlFunction("concat",
                                                NHibernateUtil.String,
                                                Projections.Property(() => fm.FirstName),
                                                Projections.Constant(" "),
                                                Projections.Property(() => fm.LastName)), "FirmMember.FirstName")
                                    .Add(Projections.Property(() => fm.Id), "FirmMember.Id")
                                    .Add(Projections.Property(() => pus.IsAgreementDone).WithAlias(() => pusdto.IsAgreementDone))
                                    .Add(Projections.Property(() => pus.IsPossessionDone).WithAlias(() => pusdto.IsPossessionDone))
                                    .Add(Projections.Property(() => p.Id), "PropertyUnit.PropertyTower.Property.Id")
                                    .Add(Projections.Property(() => p.Name), "PropertyUnit.PropertyTower.Property.Name")
                                    .Add(Projections.Property(() => pt.Id), "PropertyUnit.PropertyTower.Id")
                                    .Add(Projections.Property(() => pt.Name), "PropertyUnit.PropertyTower.Name")
                                    .Add(Projections.Property(() => pu.Id), "PropertyUnit.Id")
                                    .Add(Projections.Property(() => pu.Wing), "PropertyUnit.Wing")
                                    .Add(Projections.Property(() => pu.UnitNo), "PropertyUnit.UnitNo")
                                    .Add(Projections.Property(() => pu.BuildupArea), "PropertyUnit.BuildupArea")
                                    .Add(Projections.Property(() => pu.CarpetArea), "PropertyUnit.CarpetArea")
                                    .Add(Projections.Property(() => putype.Id), "PropertyUnit.UnitType.Id")
                                    .Add(Projections.Property(() => putype.Name), "PropertyUnit.UnitType.Name")
                                    .Add(Projections.Property(() => pus.BookingDate), "BookingDate")
                                    .Add(Projections.Property(() => pus.PossessionDate), "PossessionDate")
                                    .Add(Projections.Property(() => pus.AgreementDate), "AgreementDate");
                        var query = session.QueryOver<PrUnitSaleDetail>(() => pus)
                            .Left.JoinAlias(() => pus.PropertyUnit, () => pu)
                            .Left.JoinAlias(() => pus.PropertyUnit.UnitType, () => putype)
                            .Left.JoinAlias(() => pus.PropertyUnit.PropertyTower, () => pt)
                            .Left.JoinAlias(() => pus.PropertyUnit.PropertyTower.Property, () => p)
                            .Left.JoinAlias(() => pus.Customer, () => c)
                            .Left.JoinAlias(() => pus.FirmMember, () => fm);
                        if (filterDTO != null)
                        {
                            ICriteria criteria = query.RootCriteria;
                            if (filterDTO.UnitId > 0)
                            {
                                criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<PropertyUnit>(() => pu, x => x.Id), filterDTO.UnitId));
                            }
                            if (filterDTO.CustomerId > 0)
                            {
                                criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<Customer>(() => c, x => x.Id), filterDTO.CustomerId));
                            }
                            if (!string.IsNullOrWhiteSpace(filterDTO.CustRefNo))
                            {
                                criteria.Add(Restrictions.InsensitiveLike(CommonUtil.BuildProjection<Customer>(() => c, x => x.CustRefNo), filterDTO.CustRefNo, MatchMode.Start));
                            }
                            if (filterDTO.SalesExecutiveId > 0)
                            {
                                criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<FirmMember>(() => fm, x => x.Id), filterDTO.SalesExecutiveId));
                            }
                        }
                        result = query.Where(() => p.FirmNumber == firmNumber && pt.Id == propertyTowerId && pus.Status == PRUnitSaleStatus.Sold)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<PrUnitSaleDetailDTO>()).List<PrUnitSaleDetailDTO>();
                        result.ToList().ForEach(x => x.PropertyUnit.UnitNo
                                = CommonUIConverter.getPropertyUnitFormattedNo(x.PropertyUnit.Wing, x.PropertyUnit.UnitNo));
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching sold property units :", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        
        public PrUnitSaleDetailDTO fetchPrUnitSaleDetail(string firmNumber, long unitSaleId, long propertyId)
        {
            ISession session = null;
            PrUnitSaleDetailDTO prUnitSaleDetailDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PrUnitSaleDetail prUnitSaleDetail = session.Get<PrUnitSaleDetail>(unitSaleId);
                        prUnitSaleDetailDto = DomainToDTOUtil.convertToPrUnitSaleDetailDTO(prUnitSaleDetail, true);
                        if (prUnitSaleDetail.PrUnitSalePymts != null && prUnitSaleDetail.PrUnitSalePymts.Count > 0)
                        {
                            foreach (PrUnitSalePymt prUnitSalePymt in prUnitSaleDetail.PrUnitSalePymts)
                            {
                                PaymentMasterDTO pymtMasterDto = prUnitSaleDetailDto.PrUnitSalePymts.ToList<PrUnitSalePymtDTO>()
                                    .Find(sale => sale.Id == prUnitSalePymt.Id).PaymentMaster;
                                pymtMasterDto.TotalPaid = prUnitSalePymt.PaymentMaster.TotalPaid;
                                pymtMasterDto.Status = prUnitSalePymt.PaymentMaster.Status;
                                pymtMasterDto.hasTransactrions = prUnitSalePymt.PaymentMaster.PaymentTransactions.Count > 0;
                            }
                        }
                        PropertyTaxDetail pt= null;
                        Property p = null;
                        IList<PropertyTaxDetail> taxDetails = session.QueryOver<PropertyTaxDetail>(() => pt)
                           .JoinAlias(() => pt.Property, () => p)
                           .Where(() => p.Id ==propertyId && pt.FirmNumber == firmNumber).List<PropertyTaxDetail>();
                        prUnitSaleDetailDto.PropertyUnit.PropertyTower = new PropertyTowerDTO();
                        prUnitSaleDetailDto.PropertyUnit.PropertyTower.Property = new PropertyDTO();
                        ISet<PropertyTaxDetailDTO> taxDetailDtos = new HashSet<PropertyTaxDetailDTO>();
                        foreach (PropertyTaxDetail taxDetail in taxDetails)
                        {
                            taxDetailDtos.Add(DomainToDTOUtil.convertToPropertyTaxDetailDTO(taxDetail, true));
                        }
                        prUnitSaleDetailDto.PropertyUnit.PropertyTower.Property.PropertyTaxDetails = taxDetailDtos;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching PrUnitSale details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return prUnitSaleDetailDto;
        }

        public PrUnitSaleDetailDTO fetchPrUnitSaleDetailforLetter(string firmNumber, long unitSaleId, long propertyId)
        {
            ISession session = null;
            PrUnitSaleDetailDTO prUnitSaleDetailDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PrUnitSaleDetail prUnitSaleDetail = session.Get<PrUnitSaleDetail>(unitSaleId);
                        prUnitSaleDetailDto = DomainToDTOUtil.convertToPrUnitSaleDetailDTO(prUnitSaleDetail, true);
                        prUnitSaleDetailDto.PropertyUnit = DomainToDTOUtil.convertToPropertyUnitDTO(prUnitSaleDetail.PropertyUnit, true);
                        prUnitSaleDetailDto.Customer = DomainToDTOUtil.convertToCustomerDTO(prUnitSaleDetail.Customer, true);
                        if (prUnitSaleDetail.PrUnitSalePymts != null && prUnitSaleDetail.PrUnitSalePymts.Count > 0)
                        {
                            foreach (PrUnitSalePymt prUnitSalePymt in prUnitSaleDetail.PrUnitSalePymts)
                            {
                                PaymentMasterDTO pymtMasterDto = prUnitSaleDetailDto.PrUnitSalePymts.ToList<PrUnitSalePymtDTO>()
                                    .Find(sale => sale.Id == prUnitSalePymt.Id).PaymentMaster;
                                pymtMasterDto.TotalPaid = prUnitSalePymt.PaymentMaster.TotalPaid;
                                pymtMasterDto.Status = prUnitSalePymt.PaymentMaster.Status;
                                pymtMasterDto.hasTransactrions = prUnitSalePymt.PaymentMaster.PaymentTransactions.Count > 0;
                            }
                        }
                      
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching PrUnitSale details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return prUnitSaleDetailDto;
        }
        public void UpdateSoldPropertyUnitDetails(PrUnitSaleDetailDTO prUnitSaleDetailDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PrUnitSaleDetail prUnitSaleDetail = session.Get<PrUnitSaleDetail>(prUnitSaleDetailDto.Id);
                        DTOToDomainUtil.populatePrUnitSaleDetailUpdateFields(prUnitSaleDetail, prUnitSaleDetailDto);
                        session.Update(prUnitSaleDetail);
                        foreach (PropertyParking parking in prUnitSaleDetail.PrUnitParkings)
                        {
                            PropertyParkingDTO tmpDto = prUnitSaleDetailDto.PrParkings.FirstOrDefault(x => x.Id == parking.Id);
                            if (tmpDto == null)
                            {
                                parking.Status = ParkingStatus.Available;
                                parking.PrUnitSaleDetail = null;
                                session.Update(parking);
                            }
                        }
                        foreach (PropertyParkingDTO prPardingDto in prUnitSaleDetailDto.PrParkings)
                        {
                            PropertyParking tmpParking = prUnitSaleDetail.PrUnitParkings.FirstOrDefault(x => x.Id == prPardingDto.Id);
                            if (tmpParking == null)
                            {
                                PropertyParking parking = session.Get<PropertyParking>(prPardingDto.Id);
                                parking.Status = ParkingStatus.Allotted;
                                parking.PrUnitSaleDetail = prUnitSaleDetail;
                                session.Update(parking);
                            }
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Updating Sold property Unit:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }


        public void cancelPropertyUnitBooking(PrUnitSaleDetailDTO prUnitSaleDetailDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                PrUnitSaleDetail prUnitSaleDetail = null;
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit propertyUnit = session.Get<PropertyUnit>(prUnitSaleDetailDto.PropertyUnit.Id);
                        propertyUnit.Status = PRUnitStatus.Available;
                        session.Update(propertyUnit);

                        prUnitSaleDetail = session.Get<PrUnitSaleDetail>(prUnitSaleDetailDto.Id);
                        DTOToDomainUtil.populatePrUnitSaleCancellationAddFields(prUnitSaleDetail, prUnitSaleDetailDto);
                        session.Update(prUnitSaleDetail);
                        foreach (PropertyParking parking in prUnitSaleDetail.PrUnitParkings)
                        {
                            parking.Status = ParkingStatus.Available;
                            parking.PrUnitSaleDetail = null;
                            session.Update(parking);
                        }
                        if (prUnitSaleDetailDto.EnquiryRefNo != null)
                        {
                            string hqlUpdate = "update EnquiryDetail ed set ed.Status = :status where ed.EnquiryRefNo = :EnquiryRefNo";
                            session.CreateQuery(hqlUpdate)
                                    .SetEnum("status", EnquiryStatus.Open)
                                    .SetString("EnquiryRefNo", prUnitSaleDetailDto.EnquiryRefNo)
                                    .ExecuteUpdate();
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Updating Sold property Unit:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
                sendSMSEmail(prUnitSaleDetail);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        /**
         * This method will check Email & SMS configuration for Sales Function. 
         * If Email & SMS alerts are enabled then system will send Email & SMS to Customer.
         * */
        private static void sendSMSEmail(PrUnitSaleDetail prUnitSaleDetail)
        {
            try
            {
                PropertyAlertConfig emailSmsAlertConfig = EmailUtil.loadEmailSmsAlertConfiguration(prUnitSaleDetail.FirmNumber,
                    FunctionName.SALE.ToString(), EmailSmsType.SALESCANCEL.ToString(), prUnitSaleDetail.PropertyUnit.PropertyTower.Property.Id);
                PropertyBO propertyBO = new PropertyBO();
                if (emailSmsAlertConfig != null && emailSmsAlertConfig.Email.Equals(Constants.YES))
                {
                    PropertyDTO propertyDTO = propertyBO.fetchProperty(prUnitSaleDetail.PropertyUnit.PropertyTower.Property.Id);
                    emailSmsAlertConfig.EmailBody = populateBody(prUnitSaleDetail, emailSmsAlertConfig, propertyDTO.Name);
                    EmailUtil.sendHtmlFormattedEmail(prUnitSaleDetail.FirmNumber, emailSmsAlertConfig, prUnitSaleDetail.Customer.ContactInfo.Email);
                }
                if (emailSmsAlertConfig != null && emailSmsAlertConfig.Sms.Equals(Constants.YES))
                {
                    PropertyDTO propertyDTO = propertyBO.fetchProperty(prUnitSaleDetail.PropertyUnit.PropertyTower.Property.Id);
                    emailSmsAlertConfig.SmsContent = populateSMSBody(prUnitSaleDetail, emailSmsAlertConfig, propertyDTO.Name);
                    EmailUtil.sendSMS(prUnitSaleDetail.FirmNumber, emailSmsAlertConfig, prUnitSaleDetail.Customer.ContactInfo.Contact);
                }
            }
            catch (Exception e)
            {
                log.Error("Exception while sending Email & SMS alert for Cancellation:", e);
            }
        }
        private static string populateBody(PrUnitSaleDetail prUnitSaleDetail, PropertyAlertConfig emailSmsAlertConfig, string name)
        {
            string body = string.Empty;
            using (StreamReader reader = new StreamReader(System.Web.HttpContext.Current.Server.MapPath(emailSmsAlertConfig.EmailTemplatePath)))
            {
                body = reader.ReadToEnd();
            }
            body = body.Replace("{UserName}", prUnitSaleDetail.Customer.Salutation.Name + " " + prUnitSaleDetail.Customer.FirstName + " " + prUnitSaleDetail.Customer.LastName);
            body = body.Replace("{UnitNumber}",  CommonUIConverter.getPropertyUnitFormattedNo(prUnitSaleDetail.PropertyUnit.Wing, prUnitSaleDetail.PropertyUnit.UnitNo));
            body = body.Replace("{ProjectName}",  name);
            return body;
        }
        private static string populateSMSBody(PrUnitSaleDetail prUnitSaleDetail, PropertyAlertConfig emailSmsAlertConfig, string name)
        {
            string body = string.Empty;
            body = emailSmsAlertConfig.SmsContent.Replace("{UserName}", prUnitSaleDetail.Customer.Salutation.Name + " " + prUnitSaleDetail.Customer.FirstName + " " + prUnitSaleDetail.Customer.LastName);
            body = body.Replace("{UnitNumber}", CommonUIConverter.getPropertyUnitFormattedNo(prUnitSaleDetail.PropertyUnit.Wing, prUnitSaleDetail.PropertyUnit.UnitNo));
            body = body.Replace("{ProjectName}", name);
            return body;
        }
    }
}
