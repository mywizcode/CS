﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NHibernate;
using NHibernate.Cfg;
using System.IO;
/**
 *This will create session factory & open session with database. 
 */
public class NHibertnateSession
{
    static readonly object factorylock = new object();
    private static ISessionFactory sessionFactory = null;

    public static ISession OpenSession()
    {
        if (sessionFactory == null)
        {
            lock (factorylock)
            {
                var configuration = new Configuration();
                var configurationPath = HttpContext.Current.Server.MapPath(@"~\config\hibernate.cfg.xml");
                configuration.Configure(configurationPath);
                configuration.AddDirectory(new DirectoryInfo(HttpContext.Current.Server.MapPath("~/Model")));
                //configuration.AddAssembly("ConstroSoft");
                sessionFactory = configuration.BuildSessionFactory();
            }
        }
        ISession session = sessionFactory.OpenSession();
        session.FlushMode = FlushMode.Commit;
        return session;
    }
    public static void closeSession(ISession session)
    {
        if (session != null)
        {
            session.Close();
        }
    }
}