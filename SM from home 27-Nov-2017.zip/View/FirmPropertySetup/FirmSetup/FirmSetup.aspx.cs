﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using NHibernate;

public partial class FirmSetup : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
           log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "CommonError";
    string addModifyAddressError = "addModifyAddressError";
   string addModifyAddressModal = "addModifyAddressModal";
    MasterDataBO masterDataBO = new MasterDataBO();
    DropdownBO drpBO = new DropdownBO();
    FirmBO firmBO = new FirmBO();
    public enum FirmPageMode { MODIFY, VIEW }
    public enum AddressAction { ADD, MODIFY }

    protected void Page_Load(object sender, EventArgs e)
    {
    	if (ApplicationUtil.isSubPageRendered(Page)) clearMessages();
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
            	if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_FIRM)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                doInit();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    public void initBootstrapComponantsFromServer()
    {
    	ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private void preRenderInitFormElements()
    {
    	renderPageFieldsWithEntitlement();
    }
    private void renderPageFieldsWithEntitlement()
    {
    	UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        FirmPageMode pageMode = EnumHelper.ToEnum<FirmPageMode>(pageModeHdn.Value);
        initFormFields();
        resetPageTitle(pageMode);
        lnkModifyFirmSetup.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MODIFY_FIRM_DETAILS);
        ulSubHeaderAction.Visible = lnkModifyFirmSetup.Visible;
    }
    private void initFormFields()
    {
        bool isReadOnly = (FirmPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
        bool visible = !(FirmPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
        bool isEnabled = !isReadOnly;
        if (pnlFirmAddModify.Visible)
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            //Fields
            txtFirmName.ReadOnly = isReadOnly;
            txtWebsite.ReadOnly = isReadOnly;
            txtRegistrationNo.ReadOnly = isReadOnly;
            txtContact.ReadOnly = isReadOnly;
            txtEmail.ReadOnly = isReadOnly;
            txtDescription.ReadOnly = isReadOnly;
            txtGSTNO.ReadOnly = isReadOnly;
            lnkAddAddress.Visible = visible;
            if (addressGrid.Items.Count > 0)
            {
                foreach (ListViewItem item in addressGrid.Items)
                {
                    LinkButton modifyBtn = (LinkButton)item.FindControl("lnkModifyAddress");
                    if (modifyBtn != null) modifyBtn.Visible = visible;
                    LinkButton deleteBtn = (LinkButton)item.FindControl("lnkDeleteAddress");
                    if (deleteBtn != null) deleteBtn.Visible = visible;
                }
            }
            //Buttons
            btnFirmCancel.Visible = visible;
            btnFirmSubmit.Visible = visible;
            lnkAddAddress.Visible = visible;
        }
    }
    private void resetPageTitle(FirmPageMode pageMode)
    {
        if (FirmPageMode.MODIFY == pageMode) lbPageTitle.Text = Constants.ICON.MODIFY + Resources.Labels.MODIFY_FIRM;
        else if (FirmPageMode.VIEW == pageMode) lbPageTitle.Text = Constants.ICON.VIEW_DTL + Resources.Labels.VIEW_FIRM;
    }
    private void initPageInfo(FirmPageMode pageMode)
    {
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        pageModeHdn.Value = pageMode.ToString();
    }
    private void initCityDrp(DropDownList drp, string stateId)
    {
        drpBO.drpDataBase(drp, DrpDataType.CITY, stateId, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    
    private void setTabInfo(FirmPageMode pageMode, string activeTabValue)
    {
        pageModeHdn.Value = pageMode.ToString();
        bool isFirmView = (FirmPageMode.VIEW == pageMode);
        btnFirmSubmit.Visible = !isFirmView;
        btnFirmCancel.Visible = !isFirmView;
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        drpBO.drpDataBase(drpAddressCountry, DrpDataType.COUNTRY, null, null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAddressState, DrpDataType.STATE, Constants.DEFAULT_COUNTRY, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        initCityDrp(drpAddressCity, Constants.DEFAULT_STATE);
        drpBO.drpDataBase(drpAddressType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ADDRESS_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<PreferredAddress>(drpPreferredAddress, null);
    }
    private void doInit()
    {
        Session[Constants.Session.PAGE_DATA] = new FirmPageDTO();
        initPageInfo(FirmPageMode.VIEW);
        initDropdowns();
        fetchFirmDetails();
    }
    private void fetchFirmDetails()
    {
        try
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            FirmDTO firmDto = firmBO.fetchFirmDetails(userDefDto.FirmNumber);
            ((FirmPageDTO)Session[Constants.Session.PAGE_DATA]).SelectedFirm = firmDto;
            populateFirmDetails();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    private void populateFirmDetails()
    {
        try
        {
            FirmDTO firmDto = getDBFirmDTO();
            ContactInfoDTO contantInfo = null;
            if (firmDto != null) contantInfo = firmDto.ContactInfo;
            if (firmDto != null) txtFirmnumber.Text = firmDto.FirmNumber; else txtFirmnumber.Text = null;
            if (firmDto != null) txtGSTNO.Text = firmDto.GSTin; else txtGSTNO.Text = null;
            if (firmDto != null) txtFirmName.Text = firmDto.Name; else txtFirmName.Text = null;
            if (firmDto != null) txtRegistrationNo.Text = firmDto.RegistrationNo; else txtRegistrationNo.Text = null;
            if (firmDto != null) txtWebsite.Text = firmDto.WebSite; else txtWebsite.Text = null;
            if (contantInfo != null) txtContact.Text = contantInfo.Contact; else txtContact.Text = null;
            if (firmDto != null) txtDescription.Text = firmDto.Description; else txtDescription.Text = null;
            if (contantInfo != null) txtEmail.Text = contantInfo.Email; else txtEmail.Text = null;
            populateAddressGrid(contantInfo);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    private void populateAddressGrid(ContactInfoDTO conactInfoDto)
    {
        addressGrid.DataSource = new List<AddressDTO>();
        if (conactInfoDto != null)
        {
            assignUiIndexToAddress(conactInfoDto.Addresses);
            addressGrid.DataSource = conactInfoDto.Addresses;
        }
        addressGrid.DataBind();
        pnlAddressEmpty.Visible = (conactInfoDto.Addresses == null || conactInfoDto.Addresses.Count == 0);
    }
    
    protected void onClickModifyFirmBtn(object sender, EventArgs e)
    {
        try
        {
           initPageInfo(FirmPageMode.MODIFY);
           fetchFirmDetails();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    
    protected void cancelFirmChanges(object sender, EventArgs e)
    {
        try
        {
            initPageInfo(FirmPageMode.VIEW);
            fetchFirmDetails();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void populateFirmFromUI(FirmDTO firmDto, UserDefinitionDTO userDefDto)
    {
        firmDto.Name = txtFirmName.Text;
        firmDto.RegistrationNo = txtRegistrationNo.Text;
        firmDto.GSTin = txtGSTNO.Text;
        firmDto.ContactInfo.Contact = txtContact.Text;
        firmDto.Description = txtDescription.Text;
        firmDto.ContactInfo.Email = txtEmail.Text;
        firmDto.FirmNumber = txtFirmnumber.Text;
        firmDto.WebSite = txtWebsite.Text;
        firmDto.UpdateUser = userDefDto.Username;
        firmDto.Version = firmDto.Version;
    }
    private void populateUIFieldsFromDTO(FirmDTO firmDTO)
    {

        if (firmDTO != null) txtFirmName.Text = firmDTO.Name; else txtFirmName.Text = null;
        if (firmDTO != null) txtRegistrationNo.Text = firmDTO.RegistrationNo; else txtRegistrationNo.Text = null;
        if (firmDTO != null) txtGSTNO.Text = firmDTO.GSTin; else txtGSTNO.Text = null;
        if (firmDTO != null) txtDescription.Text = firmDTO.Description; else txtDescription.Text = null;
        if (firmDTO != null) txtContact.Text = firmDTO.ContactInfo.Contact; else txtContact.Text = null;
        if (firmDTO != null) txtEmail.Text = firmDTO.ContactInfo.Email; else txtEmail.Text = null;
        if (firmDTO != null) txtWebsite.Text = firmDTO.WebSite; else txtWebsite.Text = null;
        if (firmDTO != null) txtFirmnumber.Text = firmDTO.FirmNumber; else txtFirmnumber.Text = null;

        populateAddressGrid(firmDTO.ContactInfo);

    }
    protected void modifyFirmDetails(object sender, EventArgs e)
    {
        try
        {
            if (validateFirmUpdate())
            {
                FirmDTO firmDto = getDBFirmDTO();
                UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
                populateFirmFromUI(firmDto, userDefDto);
                firmBO.updateFirm(firmDto);
                initPageInfo(FirmPageMode.VIEW);
                fetchFirmDetails();
                setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECORD_MODIFY_DB_SUCCESS, "Firm")));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message);
            setErrorMessage(exp.Message, commonError);
        }
    }
    private void populateFirmDTOFromUI(FirmDTO firmDTO)
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        firmDTO.Name = txtFirmName.Text;
        firmDTO.RegistrationNo = txtRegistrationNo.Text;
        firmDTO.GSTin = txtGSTNO.Text;
        firmDTO.ContactInfo.Contact = txtContact.Text;
        firmDTO.ContactInfo.Email = txtEmail.Text;
        firmDTO.Description = txtDescription.Text;
        firmDTO.WebSite = txtWebsite.Text;
        firmDTO.FirmNumber = txtFirmnumber.Text;
        firmDTO.UpdateUser = userDefDto.Username;
        firmDTO.Version = userDefDto.Version;
    }
    private bool validateFirmUpdate()
    {
        bool isValid = true;
        Page.Validate(commonError);
        isValid = Page.IsValid;
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    //Address Modal - Start
    protected void loadAddressCities(object sender, EventArgs e)
    {
        try
        {
            initCityDrp(drpAddressCity, drpAddressState.Text);
            SetFocus(drpAddressCity);
            activeModalHdn.Value = addModifyAddressModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void initAddressModalFields()
    {
        lbAddressModalTitle.Text = (AddressAction.ADD.ToString().Equals(addressModalActionHdnBtn.Value))
            ? Constants.ICON.ADD + Resources.Labels.ADD_ADDRESS : Constants.ICON.MODIFY + Resources.Labels.MODIFY_ADDRESS;
    }
    private void initAddressSectionFields(AddressDTO addressDto)
    {
        if (addressDto != null) txtAddressLine1.Text = addressDto.AddressLine1; else txtAddressLine1.Text = null;
        if (addressDto != null) txtAddressLine2.Text = addressDto.AddressLine2; else txtAddressLine2.Text = null;
        if (addressDto != null) txtTown.Text = addressDto.Town; else txtTown.Text = null;
        if (addressDto != null && addressDto.City != null) drpAddressCity.Text = addressDto.City.Id.ToString(); else drpAddressCity.ClearSelection();
        if (addressDto != null && addressDto.State != null) drpAddressState.Text = addressDto.State.Id.ToString(); else drpAddressState.ClearSelection();
        if (addressDto != null && addressDto.Country != null) drpAddressCountry.Text = addressDto.Country.Id.ToString(); else drpAddressCountry.ClearSelection();
        if (addressDto != null) txtPin.Text = addressDto.Pin; else txtPin.Text = null;
        if (addressDto != null && addressDto.AddressType != null) drpAddressType.Text = addressDto.AddressType.Id.ToString(); else drpAddressType.ClearSelection();
        if (addressDto != null && addressDto.PreferredAddress != null) drpPreferredAddress.Text = addressDto.PreferredAddress.ToString(); else drpPreferredAddress.ClearSelection();
    }
    private void populateAddressFromUI(AddressDTO addressDto)
    {
        addressDto.AddressLine1 = txtAddressLine1.Text;
        addressDto.AddressLine2 = txtAddressLine2.Text;
        addressDto.Town = txtTown.Text;
        addressDto.City = CommonUIConverter.getCityDTO(drpAddressCity.Text, drpAddressCity.SelectedItem.Text);
        addressDto.State = CommonUIConverter.getStateDTO(drpAddressState.Text, drpAddressState.SelectedItem.Text);
        addressDto.Country = CommonUIConverter.getCountryDTO(drpAddressCountry.Text, drpAddressCountry.SelectedItem.Text);
        addressDto.Pin = txtPin.Text;
        addressDto.AddressType = CommonUIConverter.getMasterControlDTO(drpAddressType.Text, drpAddressType.SelectedItem.Text);
        addressDto.PreferredAddress = EnumHelper.ToEnumNullable<PreferredAddress>(drpPreferredAddress.Text);
    }
    private AddressDTO populateAddressAdd()
    {
        AddressDTO addressDto = new AddressDTO();
        return addressDto;
    }
    private void setSelectedAddress(long UiIndex)
    {
        List<AddressDTO> addressList = getDBFirmDTO().ContactInfo.Addresses.ToList<AddressDTO>();
        addressList.ForEach(c => c.isUISelected = false);
        if (UiIndex > 0) addressList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
    }
    private AddressDTO getSelectedAddress(long UiIndex)
    {
        List<AddressDTO> addressList = getDBFirmDTO().ContactInfo.Addresses.ToList<AddressDTO>();
        return (UiIndex > 0) ? addressList.Find(c => c.UiIndex == UiIndex) : addressList.Find(c => c.isUISelected);
    }
    protected void onClickAddAddressBtn(object sender, EventArgs e)
    {
        try
        {
            addressModalActionHdnBtn.Value = AddressAction.ADD.ToString();
            initAddressModalFields();
            setSelectedAddress(-1);
            initAddressSectionFields(null);
            activeModalHdn.Value = addModifyAddressModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyAddressBtn(object sender, EventArgs e)
    {
        try
        {
            addressModalActionHdnBtn.Value = AddressAction.MODIFY.ToString();
            initAddressModalFields();
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedAddress(selectedIndex);
            initAddressSectionFields(getSelectedAddress(0));
            activeModalHdn.Value = addModifyAddressModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    

    private void assignUiIndexToAddress(ISet<AddressDTO> addressDtos)
    {
        if (addressDtos != null && addressDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (AddressDTO addressDto in addressDtos)
            {
                addressDto.UiIndex = uiIndex++;
                addressDto.UiFullAddress = CommonUIConverter.getUiFullAddress(addressDto);
            }
        }
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    protected void deleteAddress(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            AddressDTO addressDTO = getSelectedAddress(selectedIndex);
            getDBFirmDTO().ContactInfo.Addresses.Remove(addressDTO);
            populateAddressGrid(getDBFirmDTO().ContactInfo);
            setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECORD_DELETE_SUCCESS, "Address")));
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private FirmDTO getDBFirmDTO()
    {
        return getSessionPageData().SelectedFirm;
    }
    private FirmPageDTO getSessionPageData()
    {
        return (FirmPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    protected void saveAddress(object sender, EventArgs e)
    {
        try
        {
            if (validateAddressAddModify())
            {
                AddressDTO addressDTO = null;
                string msg = "";
                if (AddressAction.ADD.ToString().Equals(addressModalActionHdnBtn.Value))
                {
                    addressDTO = populateAddressAdd();
                    getDBFirmDTO().ContactInfo.Addresses.Add(addressDTO);
                    msg = string.Format(Resources.Messages.RECORD_ADDED_SUCCESS, "Address");
                }
                else
                {
                    addressDTO = getSelectedAddress(0);
                    msg = string.Format(Resources.Messages.RECORD_MODIFY_SUCCESS, "Address");
                }
                populateAddressFromUI(addressDTO);
                populateAddressGrid(getDBFirmDTO().ContactInfo);
                setNotyMsg(CommonUtil.getNotySuccessMsg(msg));
            }
            else
            {
                activeModalHdn.Value = addModifyAddressModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelAddressModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateAddressAddModify()
    {
        bool isValid = true;
        Page.Validate(addModifyAddressError);
        isValid = Page.IsValid;
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    //Address Modal - End
}
