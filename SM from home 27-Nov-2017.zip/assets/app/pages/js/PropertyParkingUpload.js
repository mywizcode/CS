﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initPropertyParkingUploadGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}
function initPropertyParkingUploadGrid() {
    var dtOptions = {
        hasActionColumn: false,
        rowInfoModalTitle: "Parking Details",
        pageLength: 10
    };

    $("[id$='parkingUploadGrid']").CSBasicDatatable(dtOptions);
}


