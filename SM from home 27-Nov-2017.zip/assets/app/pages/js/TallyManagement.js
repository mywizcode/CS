﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initVoucherSearchGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initVoucherSearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#voucherSearchBtnDiv",
        pageLength: 10
    };

    $("[id$='voucherSearchGrid']").CSBasicDatatable(dtOptions);
}



