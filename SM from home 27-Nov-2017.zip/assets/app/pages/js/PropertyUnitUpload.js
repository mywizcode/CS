﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initPropertyUnitUploadGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}
function initPropertyUnitUploadGrid() {
    var dtOptions = {
        hasActionColumn: false,
        rowInfoModalTitle: "Unit Details",
        pageLength: 10
    };

    $("[id$='unitUploadGrid']").CSBasicDatatable(dtOptions);
}




