﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;


/// <summary>
/// Summary description for JobHistoryBO
/// </summary>
namespace ConstroSoft
{
    public class JobHistoryBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public JobHistoryBO() { }

        public long saveJobHistory(JobHistoryDTO jobHistoryDTO)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        JobHistory jobHistory = DTOToDomainUtil.populateJobHistoryAddFields(jobHistoryDTO);
                        session.Save(jobHistory);
                        Id = jobHistory.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Job History details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        
        public void updatejobHistoryDetails(JobHistoryDTO jobHistoryDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        JobHistory jobHistory = session.Get<JobHistory>(jobHistoryDTO.Id);
                        DTOToDomainUtil.populateJobHistoryUpdateFields(jobHistory, jobHistoryDTO);
                        session.Update(jobHistory);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating Job History details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public bool checkIfJobRunning(string firmNumber, long jobId)
        {
            ISession session = null;
            bool isJobRunning = false;
            IList<JobHistory> result = new List<JobHistory>();
            try
            {
                session = NHibertnateSession.OpenSession();
                JobHistory jh = null;
                var query = session.QueryOver<JobHistory>(() => jh);
                result = query.Where(() => jh.FirmNumber == firmNumber && jh.Status == JobRunStatus.INPROGRESS).List<JobHistory>();
                if(result != null && result.Count>0){
                    isJobRunning = true;
                }
                
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error checking in-Progress Job:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return isJobRunning;
        }
       
    }
}