﻿
/// <summary>
/// Summary description for MyENUM
/// </summary>

using System;
namespace ConstroSoft
{
    public class UserStatusStringType : NHibernate.Type.EnumStringType
    {
        public UserStatusStringType(): base(typeof(UserStatus), 1){}
        public override object GetValue(object enm)
        {
            if (null == enm)return String.Empty;
            switch ((UserStatus)enm)
            {
                case UserStatus.Setup: return "S";
                case UserStatus.Active: return "A";
                case UserStatus.InActive: return "I";
                default: throw new ArgumentException("Invalid UserStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("S".Equals(code)) return UserStatus.Setup;
            else if ("A".Equals(code)) return UserStatus.Active;
            else if ("I".Equals(code)) return UserStatus.InActive;
            throw new ArgumentException("Cannot convert value '" + code + "' to UserStatus.");
        }
    }
    public class PreferredAddressStringType : NHibernate.Type.EnumStringType
    {
        public PreferredAddressStringType(): base(typeof(PreferredAddress), 1){}
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PreferredAddress)enm)
            {
                case PreferredAddress.Yes: return "Y";
                case PreferredAddress.No: return "N";
                default: return null;
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return PreferredAddress.Yes;
            else if ("N".Equals(code)) return PreferredAddress.No;
            return null;
        }
    }
    public class PrFMAccessStringType : NHibernate.Type.EnumStringType
    {
        public PrFMAccessStringType() : base(typeof(PrFMAccess), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PrFMAccess)enm)
            {
                case PrFMAccess.Yes: return "Y";
                case PrFMAccess.No: return "N";
                default: return null;
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return PrFMAccess.Yes;
            else if ("N".Equals(code)) return PrFMAccess.No;
            return null;
        }
    }
    public class GenderStringType : NHibernate.Type.EnumStringType
    {
        public GenderStringType() : base(typeof(Gender), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((Gender)enm)
            {
                case Gender.Male: return "M";
                case Gender.Female: return "F";
                default: return null;
            }
        }
        public override object GetInstance(object code)
        {
            if ("M".Equals(code)) return Gender.Male;
            else if ("F".Equals(code)) return Gender.Female;
            return null;
        }
    }

        public class MaritalStatusStringType : NHibernate.Type.EnumStringType
    {
        public MaritalStatusStringType() : base(typeof(MaritalStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((MaritalStatus)enm)
            {
                case MaritalStatus.Single: return "S";
                case MaritalStatus.Married: return "M";
                default: return null;
            }
        }
        public override object GetInstance(object code)
        {
            if ("S".Equals(code)) return MaritalStatus.Single;
            else if ("M".Equals(code)) return MaritalStatus.Married;
            return null;
        }
    }
    public class SystemDefinedStringType : NHibernate.Type.EnumStringType
    {
        public SystemDefinedStringType() : base(typeof(SystemDefined), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((SystemDefined)enm)
            {
                case SystemDefined.Yes: return "Y";
                case SystemDefined.No: return "N";
                default: return null;
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return SystemDefined.Yes;
            else if ("N".Equals(code)) return SystemDefined.No;
            return null;
        }
    }
    public class EnquiryStatusStringType : NHibernate.Type.EnumStringType
    {
        public EnquiryStatusStringType() : base(typeof(EnquiryStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((EnquiryStatus)enm)
            {
                case EnquiryStatus.Open: return "O";
                case EnquiryStatus.Won: return "W";
                case EnquiryStatus.Lost: return "L";
                default: throw new ArgumentException("Invalid EnquiryStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("O".Equals(code)) return EnquiryStatus.Open;
            else if ("W".Equals(code)) return EnquiryStatus.Won;
            else if ("L".Equals(code)) return EnquiryStatus.Lost;
            throw new ArgumentException("Cannot convert value '" + code + "' to EnquiryStatus.");
        }
    }
    public class EnqActivityRecordTypeStringType : NHibernate.Type.EnumStringType
    {
        public EnqActivityRecordTypeStringType() : base(typeof(EnqActivityRecordType), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((EnqActivityRecordType)enm)
            {
                case EnqActivityRecordType.Activity: return "A";
                case EnqActivityRecordType.Event: return "E";
                case EnqActivityRecordType.Task: return "T";
                case EnqActivityRecordType.Action: return "S";
                default: throw new ArgumentException("Invalid EnqActivityRecordType.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("A".Equals(code)) return EnqActivityRecordType.Activity;
            else if ("E".Equals(code)) return EnqActivityRecordType.Event;
            else if ("T".Equals(code)) return EnqActivityRecordType.Task;
            else if ("S".Equals(code)) return EnqActivityRecordType.Action;
            throw new ArgumentException("Cannot convert value '" + code + "' to EnqActivityRecordType.");
        }
    }
    public class EventTaskModeStringType : NHibernate.Type.EnumStringType
    {
        public EventTaskModeStringType() : base(typeof(EventTaskMode), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((EventTaskMode)enm)
            {
                case EventTaskMode.Scheduled: return "S";
                case EventTaskMode.Rescheduled: return "R";
                case EventTaskMode.Cancelled: return "C";
                case EventTaskMode.None: return "N";
                default: throw new ArgumentException("Invalid EventTaskMode.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("S".Equals(code)) return EventTaskMode.Scheduled;
            else if ("R".Equals(code)) return EventTaskMode.Rescheduled;
            else if ("C".Equals(code)) return EventTaskMode.Cancelled;
            else if ("N".Equals(code)) return EventTaskMode.None;
            throw new ArgumentException("Cannot convert value '" + code + "' to EventTaskMode.");
        }
    }
    public class EnqActivityTypeStringType : NHibernate.Type.EnumStringType
    {
        public EnqActivityTypeStringType() : base(typeof(EnqActivityType), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((EnqActivityType)enm)
            {
                case EnqActivityType.SITE_VISIT: return "V";
                case EnqActivityType.MEETING: return "M";
                case EnqActivityType.FOLLOW_UP: return "F";
                case EnqActivityType.ASSIGNMENT: return "A";
                case EnqActivityType.RE_ASSIGNMENT: return "R";
                case EnqActivityType.CONVERTED: return "Z";
                case EnqActivityType.CREATE: return "C";
                case EnqActivityType.LOST: return "L";
                case EnqActivityType.WON: return "W";
                case EnqActivityType.BOOKING_CANCELLED: return "X";
                case EnqActivityType.RE_OPENED: return "O";
                case EnqActivityType.TASK: return "T";
                default: throw new ArgumentException("Invalid EnqActivityType.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("V".Equals(code)) return EnqActivityType.SITE_VISIT;
            else if ("M".Equals(code)) return EnqActivityType.MEETING;
            else if ("F".Equals(code)) return EnqActivityType.FOLLOW_UP;
            else if ("A".Equals(code)) return EnqActivityType.ASSIGNMENT;
            else if ("R".Equals(code)) return EnqActivityType.RE_ASSIGNMENT;
            else if ("Z".Equals(code)) return EnqActivityType.CONVERTED;
            else if ("C".Equals(code)) return EnqActivityType.CREATE;
            else if ("L".Equals(code)) return EnqActivityType.LOST;
            else if ("W".Equals(code)) return EnqActivityType.WON;
            else if ("X".Equals(code)) return EnqActivityType.BOOKING_CANCELLED;
            else if ("O".Equals(code)) return EnqActivityType.RE_OPENED;
            else if ("T".Equals(code)) return EnqActivityType.TASK;
            throw new ArgumentException("Cannot convert value '" + code + "' to EnqActivityType.");
        }
    }
    public class EnqLeadActivityStatusStringType : NHibernate.Type.EnumStringType
    {
        public EnqLeadActivityStatusStringType() : base(typeof(EnqLeadActivityStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((EnqLeadActivityStatus)enm)
            {
                case EnqLeadActivityStatus.Open: return "O";
                case EnqLeadActivityStatus.Deferred: return "X";
                case EnqLeadActivityStatus.Completed: return "C";
                default: throw new ArgumentException("Invalid EnqLeadActivityStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("O".Equals(code)) return EnqLeadActivityStatus.Open;
            else if ("X".Equals(code)) return EnqLeadActivityStatus.Deferred;
            else if ("C".Equals(code)) return EnqLeadActivityStatus.Completed;
            throw new ArgumentException("Cannot convert value '" + code + "' to EnqLeadActivityStatus.");
        }
    }
    public class LeadStatusStringType : NHibernate.Type.EnumStringType
    {
        public LeadStatusStringType() : base(typeof(LeadStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((LeadStatus)enm)
            {
                case LeadStatus.Open: return "O";
                case LeadStatus.Converted: return "C";
                case LeadStatus.Lost: return "L";
                default: throw new ArgumentException("Invalid LeadStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("O".Equals(code)) return LeadStatus.Open;
            else if ("C".Equals(code)) return LeadStatus.Converted;
            else if ("L".Equals(code)) return LeadStatus.Lost;
            throw new ArgumentException("Cannot convert value '" + code + "' to LeadStatus.");
        }
    }
    public class CommonParkingStringType : NHibernate.Type.EnumStringType
    {
        public CommonParkingStringType() : base(typeof(CommonParking), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((CommonParking)enm)
            {
                case CommonParking.Yes: return "Y";
                case CommonParking.No: return "N";
                default: throw new ArgumentException("Invalid CommonParking.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return CommonParking.Yes;
            else if ("N".Equals(code)) return CommonParking.No;
            throw new ArgumentException("Cannot convert value '" + code + "' to CommonParking.");
        }
    }
   
    public class ParkingStatusStringType : NHibernate.Type.EnumStringType
    {
        public ParkingStatusStringType() : base(typeof(ParkingStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((ParkingStatus)enm)
            {
                case ParkingStatus.Available: return "A";
                case ParkingStatus.Reserved: return "R";
                case ParkingStatus.Allotted: return "X";
                default: throw new ArgumentException("Invalid ParkingStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("A".Equals(code)) return ParkingStatus.Available;
            else if ("R".Equals(code)) return ParkingStatus.Reserved;
            else if ("X".Equals(code)) return ParkingStatus.Allotted;
            throw new ArgumentException("Cannot convert value '" + code + "' to ParkingStatus.");
        }
    }
    public class PRScheduleStageStatusStringType : NHibernate.Type.EnumStringType
    {
        public PRScheduleStageStatusStringType() : base(typeof(PRScheduleStageStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PRScheduleStageStatus)enm)
            {
                case PRScheduleStageStatus.Pending: return "P";
                case PRScheduleStageStatus.Completed: return "C";
                default: throw new ArgumentException("Invalid PRScheduleStageStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("P".Equals(code)) return PRScheduleStageStatus.Pending;
            else if ("C".Equals(code)) return PRScheduleStageStatus.Completed;
            throw new ArgumentException("Cannot convert value '" + code + "' to PRScheduleStageStatus.");
        }
    }
    public class IncludeInPymtTotalStringType : NHibernate.Type.EnumStringType
    {
        public IncludeInPymtTotalStringType() : base(typeof(IncludeInPymtTotal), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((IncludeInPymtTotal)enm)
            {
                case IncludeInPymtTotal.Yes: return "Y";
                case IncludeInPymtTotal.No: return "N";
                default: throw new ArgumentException("Invalid IncludeInPymtTotal.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return IncludeInPymtTotal.Yes;
            else if ("N".Equals(code)) return IncludeInPymtTotal.No;
            throw new ArgumentException("Cannot convert value '" + code + "' to IncludeInPymtTotal.");
        }
    }
    public class PRUnitStatusStringType : NHibernate.Type.EnumStringType
    {
        public PRUnitStatusStringType() : base(typeof(PRUnitStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PRUnitStatus)enm)
            {
                case PRUnitStatus.Available: return "A";
                case PRUnitStatus.Reserved: return "R";
                case PRUnitStatus.Sold: return "S";
                case PRUnitStatus.Deleted: return "D";
                default: throw new ArgumentException("Invalid PRUnitStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("A".Equals(code)) return PRUnitStatus.Available;
            else if ("R".Equals(code)) return PRUnitStatus.Reserved;
            else if ("S".Equals(code)) return PRUnitStatus.Sold;
            else if ("D".Equals(code)) return PRUnitStatus.Deleted;
            throw new ArgumentException("Cannot convert value '" + code + "' to PRUnitStatus.");
        }
    }
    public class IsPoaStringType : NHibernate.Type.EnumStringType
    {
        public IsPoaStringType() : base(typeof(PowerOfAtorny), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PowerOfAtorny)enm)
            {
                case PowerOfAtorny.Yes: return "Y";
                case PowerOfAtorny.No: return "N";
                default: return null;
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return PowerOfAtorny.Yes;
            else if ("N".Equals(code)) return PowerOfAtorny.No;
            return null;
        }
    }
    public class FamilyRelationshipStringType : NHibernate.Type.EnumStringType
    {
    	public FamilyRelationshipStringType() : base(typeof(FamilyRelation), 1) { }
    	public override object GetValue(object enm)
    	{
    		if (null == enm) return String.Empty;
    		switch ((FamilyRelation)enm)
    		{
    			case FamilyRelation.SON_OF: return "S";
    			case FamilyRelation.DAUGHTER_OF: return "D";
    			case FamilyRelation.WIFE_OF: return "W";
    			default: throw new ArgumentException("Invalid FamilyRelationship.");
    		}
    	}
    	public override object GetInstance(object code)
    	{
    		if ("S".Equals(code)) return FamilyRelation.SON_OF;
    		else if ("D".Equals(code)) return FamilyRelation.DAUGHTER_OF;
    		else if ("W".Equals(code)) return FamilyRelation.WIFE_OF;
    		throw new ArgumentException("Cannot convert value '" + code + "' to FamilyRelationship.");
    	}
    }
    public class PRUnitSaleStatusStringType : NHibernate.Type.EnumStringType
    {
        public PRUnitSaleStatusStringType() : base(typeof(PRUnitSaleStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PRUnitSaleStatus)enm)
            {
                case PRUnitSaleStatus.Sold: return "S";
                case PRUnitSaleStatus.Cancelled: return "C";
                default: throw new ArgumentException("Invalid PRUnitSaleStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("S".Equals(code)) return PRUnitSaleStatus.Sold;
            else if ("C".Equals(code)) return PRUnitSaleStatus.Cancelled;
            throw new ArgumentException("Cannot convert value '" + code + "' to PRUnitSaleStatus.");
        }
    }
    public class IsPossessionDoneStringType : NHibernate.Type.EnumStringType
    {
        public IsPossessionDoneStringType() : base(typeof(IsPossessionDone), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((IsPossessionDone)enm)
            {
                case IsPossessionDone.Yes: return "Y";
                case IsPossessionDone.No: return "N";
                default: throw new ArgumentException("Invalid IsPossessionDone.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return IsPossessionDone.Yes;
            else if ("N".Equals(code)) return IsPossessionDone.No;
            throw new ArgumentException("Cannot convert value '" + code + "' to IsPossessionDone.");
        }
    }
    public class IsAgreementDoneStringType : NHibernate.Type.EnumStringType
    {
        public IsAgreementDoneStringType() : base(typeof(IsAgreementDone), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((IsAgreementDone)enm)
            {
                case IsAgreementDone.Yes: return "Y";
                case IsAgreementDone.No: return "N";
                default: throw new ArgumentException("Invalid IsAgreementDone.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return IsAgreementDone.Yes;
            else if ("N".Equals(code)) return IsAgreementDone.No;
            throw new ArgumentException("Cannot convert value '" + code + "' to IsAgreementDone.");
        }
    }
    public class PymtMasterStatusStringType : NHibernate.Type.EnumStringType
    {
        public PymtMasterStatusStringType() : base(typeof(PymtMasterStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PymtMasterStatus)enm)
            {
                case PymtMasterStatus.Paid: return "P";
                case PymtMasterStatus.Pending: return "X";
                case PymtMasterStatus.Deleted: return "D";
                case PymtMasterStatus.Suspended: return "S";
                default: throw new ArgumentException("Invalid PymtMasterStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("P".Equals(code)) return PymtMasterStatus.Paid;
            else if ("X".Equals(code)) return PymtMasterStatus.Pending;
            else if ("D".Equals(code)) return PymtMasterStatus.Deleted;
            else if ("S".Equals(code)) return PymtMasterStatus.Suspended;
            throw new ArgumentException("Cannot convert value '" + code + "' to PymtMasterStatus.");
        }
    }
    public class PymtTransRcptDeliveredStringType : NHibernate.Type.EnumStringType
    {
    	public PymtTransRcptDeliveredStringType(): base(typeof(PymtTransRcptDelivered), 1){}
    	public override object GetValue(object enm)
    	{
    		if (null == enm) return String.Empty;
    		switch ((PymtTransRcptDelivered)enm)
    		{
    			case PymtTransRcptDelivered.Yes: return "Y";
    			case PymtTransRcptDelivered.No: return "N";
    			default: return null;
    		}
    	}
    	public override object GetInstance(object code)
    	{
    		if ("Y".Equals(code)) return PymtTransRcptDelivered.Yes;
    		else if ("N".Equals(code)) return PymtTransRcptDelivered.No;
    		return null;
    	}
    }
    public class PaymentMethodStringType : NHibernate.Type.EnumStringType
    {
        public PaymentMethodStringType() : base(typeof(PaymentMethod), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PaymentMethod)enm)
            {
                case PaymentMethod.CASH: return "CASH";
                case PaymentMethod.CHEQUE: return "CHQ";
                case PaymentMethod.DD: return "DD";
                case PaymentMethod.NEFT: return "NEFT";
                case PaymentMethod.RTGS: return "RTGS";
                default: throw new ArgumentException("Invalid PaymentMode.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("CASH".Equals(code)) return PaymentMethod.CASH;
            else if ("CHQ".Equals(code)) return PaymentMethod.CHEQUE;
            else if ("DD".Equals(code)) return PaymentMethod.DD;
            else if ("NEFT".Equals(code)) return PaymentMethod.NEFT;
            else if ("RTGS".Equals(code)) return PaymentMethod.RTGS;
            throw new ArgumentException("Cannot convert value '" + code + "' to PaymentMethod.");
        }
    }
    public class PymtTransStatusStringType : NHibernate.Type.EnumStringType
    {
        public PymtTransStatusStringType() : base(typeof(PymtTransStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PymtTransStatus)enm)
            {
                case PymtTransStatus.Pending: return "X";
                case PymtTransStatus.Paid: return "P";
                case PymtTransStatus.Deleted: return "D";
                case PymtTransStatus.Reversal: return "R";
                default: throw new ArgumentException("Invalid PymtTransStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("X".Equals(code)) return PymtTransStatus.Pending;
            else if ("P".Equals(code)) return PymtTransStatus.Paid;
            else if ("D".Equals(code)) return PymtTransStatus.Deleted;
            else if ("R".Equals(code)) return PymtTransStatus.Reversal;
            throw new ArgumentException("Cannot convert value '" + code + "' to PymtTransStatus.");
        }
    }
    public class ChequeStatusStringType : NHibernate.Type.EnumStringType
    {
        public ChequeStatusStringType() : base(typeof(ChequeStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((ChequeStatus)enm)
            {
                case ChequeStatus.Collected: return "C";
                case ChequeStatus.Deposited: return "D";
                case ChequeStatus.Cleared: return "P";
                case ChequeStatus.Bounced: return "B";
                case ChequeStatus.Returned: return "R";
                default: return null;
            }
        }
        public override object GetInstance(object code)
        {
            if ("C".Equals(code)) return ChequeStatus.Collected;
            else if ("D".Equals(code)) return ChequeStatus.Deposited;
            else if ("P".Equals(code)) return ChequeStatus.Cleared;
            else if ("B".Equals(code)) return ChequeStatus.Bounced;
            else if ("R".Equals(code)) return ChequeStatus.Returned;
            return null;
        }
    }
    public class PaymentModeStringType : NHibernate.Type.EnumStringType
    {
        public PaymentModeStringType() : base(typeof(PaymentMode), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PaymentMode)enm)
            {
                case PaymentMode.Receivable: return "R";
                case PaymentMode.Payable: return "P";
                default: throw new ArgumentException("Invalid PaymentMode.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("R".Equals(code)) return PaymentMode.Receivable;
            else if ("P".Equals(code)) return PaymentMode.Payable;
            throw new ArgumentException("Cannot convert value '" + code + "' to PaymentMode.");
        }
    }
    public class MPTPymtStatusStringType : NHibernate.Type.EnumStringType
    {
        public MPTPymtStatusStringType() : base(typeof(MPTPymtStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((MPTPymtStatus)enm)
            {
                case MPTPymtStatus.Pending: return "X";
                case MPTPymtStatus.Paid: return "P";
                case MPTPymtStatus.Deleted: return "D";
                default: throw new ArgumentException("Invalid MPTPymtStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("X".Equals(code)) return MPTPymtStatus.Pending;
            else if ("P".Equals(code)) return MPTPymtStatus.Paid;
            else if ("D".Equals(code)) return MPTPymtStatus.Deleted;
            throw new ArgumentException("Cannot convert value '" + code + "' to MPTPymtStatus.");
        }
    }
    public class AcntTransStatusStringType : NHibernate.Type.EnumStringType
    {
        public AcntTransStatusStringType() : base(typeof(AcntTransStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((AcntTransStatus)enm)
            {
                case AcntTransStatus.Credit: return "C";
                case AcntTransStatus.Debit: return "D";
                default: throw new ArgumentException("Invalid AcntTransStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("C".Equals(code)) return AcntTransStatus.Credit;
            else if ("D".Equals(code)) return AcntTransStatus.Debit;
            throw new ArgumentException("Cannot convert value '" + code + "' to AcntTransStatus.");
        }
    }
    public class PropertyFundStatusStringType : NHibernate.Type.EnumStringType
    {
        public PropertyFundStatusStringType() : base(typeof(PropertyFundStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PropertyFundStatus)enm)
            {
                case PropertyFundStatus.Deposited: return "C";
                case PropertyFundStatus.Reversed: return "D";
                default: throw new ArgumentException("Invalid AcntDepositStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("C".Equals(code)) return PropertyFundStatus.Deposited;
            else if ("D".Equals(code)) return PropertyFundStatus.Reversed;
            throw new ArgumentException("Cannot convert value '" + code + "' to AcntDepositStatus.");
        }
    }
    
    public class FunctionNameStringType : NHibernate.Type.EnumStringType
    {
        public FunctionNameStringType() : base(typeof(FunctionName), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((FunctionName)enm)
            {
                case FunctionName.ENQUIRY: return "ENQ";
                case FunctionName.SALE: return "SAL";
                default: throw new ArgumentException("Invalid FunctionName.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("ENQ".Equals(code)) return FunctionName.ENQUIRY;
            else if ("SAL".Equals(code)) return FunctionName.SALE;
            throw new ArgumentException("Cannot convert value '" + code + "' to FunctionName.");
        }
    }
    public class EmailSmsTypeStringType : NHibernate.Type.EnumStringType
    {
        public EmailSmsTypeStringType() : base(typeof(EmailSmsType), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((EmailSmsType)enm)
            {
                case EmailSmsType.ENQUIRYTHANKS: return "ENT";
                case EmailSmsType.SALESTHANKS: return "SAT";
                case EmailSmsType.SALESCANCEL: return "SAC";
                default: throw new ArgumentException("Invalid EmailSmsType.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("ENT".Equals(code)) return EmailSmsType.ENQUIRYTHANKS;
            else if ("SAT".Equals(code)) return EmailSmsType.SALESTHANKS;
            else if ("SAC".Equals(code)) return EmailSmsType.SALESCANCEL;
            throw new ArgumentException("Cannot convert value '" + code + "' to EmailSmsType.");
        }
    }
    public class NotificationTypeStringType : NHibernate.Type.EnumStringType
    {
        public NotificationTypeStringType() : base(typeof(NotificationType), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((NotificationType)enm)
            {
                case NotificationType.ALERT: return "A";
                case NotificationType.TASK: return "T";
                default: throw new ArgumentException("Invalid NotificationType.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("A".Equals(code)) return NotificationType.ALERT;
            else if ("T".Equals(code)) return NotificationType.TASK;
            throw new ArgumentException("Cannot convert value '" + code + "' to NotificationType.");
        }
    }
    public class NotificationSubTypeStringType : NHibernate.Type.EnumStringType
    {
    	public NotificationSubTypeStringType() : base(typeof(NotificationSubType), 1) { }
    	public override object GetValue(object enm)
    	{
    		if (null == enm) return String.Empty;
    		switch ((NotificationSubType)enm)
    		{
    			case NotificationSubType.NEW_LEAD_ASSIGNED: return "NLA";
    			case NotificationSubType.LEAD_REASSIGNED_SELF: return "LRS";
                case NotificationSubType.LEAD_REASSIGNED_USER: return "LRU";
                case NotificationSubType.LEAD_CLOSED_USER: return "LCU";
    			case NotificationSubType.ENQUIRY_REASSIGNED_SELF: return "ERS";
                case NotificationSubType.ENQUIRY_REASSIGNED_USER: return "ERU";
                case NotificationSubType.ENQUIRY_CLOSED_USER: return "ECU";
                case NotificationSubType.ENQUIRY_REOPEN_USER: return "ERO";
    			default: throw new ArgumentException("Invalid NotificationSubType.");
    		}
    	}
    	public override object GetInstance(object code)
    	{
            if ("NLA".Equals(code)) return NotificationSubType.NEW_LEAD_ASSIGNED;
            else if ("LRS".Equals(code)) return NotificationSubType.LEAD_REASSIGNED_SELF;
            else if ("LRU".Equals(code)) return NotificationSubType.LEAD_REASSIGNED_USER;
            else if ("LCU".Equals(code)) return NotificationSubType.LEAD_CLOSED_USER;
            else if ("ERS".Equals(code)) return NotificationSubType.ENQUIRY_REASSIGNED_SELF;
            else if ("ERU".Equals(code)) return NotificationSubType.ENQUIRY_REASSIGNED_USER;
            else if ("ECU".Equals(code)) return NotificationSubType.ENQUIRY_CLOSED_USER;
            else if ("ERO".Equals(code)) return NotificationSubType.ENQUIRY_REOPEN_USER;
    		throw new ArgumentException("Cannot convert value '" + code + "' to NotificationSubType.");
    	}
    }
    public class NotificationStatusStringType : NHibernate.Type.EnumStringType
    {
        public NotificationStatusStringType() : base(typeof(NotificationStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((NotificationStatus)enm)
            {
                case NotificationStatus.OPEN: return "O";
                case NotificationStatus.CLOSED: return "C";
                default: throw new ArgumentException("Invalid NotificationStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("O".Equals(code)) return NotificationStatus.OPEN;
            else if ("C".Equals(code)) return NotificationStatus.CLOSED;
            throw new ArgumentException("Cannot convert value '" + code + "' to NotificationStatus.");
        }
    }
    public class JobStatusStringType : NHibernate.Type.EnumStringType
    {
        public JobStatusStringType() : base(typeof(JobStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((JobStatus)enm)
            {
                case JobStatus.ACTIVE: return "A";
                case JobStatus.INACTIVE: return "I";
                default: throw new ArgumentException("Invalid JobStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("A".Equals(code)) return JobStatus.ACTIVE;
            else if ("I".Equals(code)) return JobStatus.INACTIVE;
            throw new ArgumentException("Cannot convert value '" + code + "' to JobStatus.");
        }
    }
    
    public class IntervalTypeStringType : NHibernate.Type.EnumStringType
    {
        public IntervalTypeStringType() : base(typeof(JobIntervalType), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((JobIntervalType)enm)
            {
                case JobIntervalType.WithCalendarIntervalSchedule: return "C";
                case JobIntervalType.WithCronSchedule: return "R";
                case JobIntervalType.WithDailyTimeIntervalSchedule: return "D";
                case JobIntervalType.WithSimpleSchedule: return "S";
                default: throw new ArgumentException("Invalid JobIntervalType.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("C".Equals(code)) return JobIntervalType.WithCalendarIntervalSchedule;
            else if ("R".Equals(code)) return JobIntervalType.WithCronSchedule;
            else if ("D".Equals(code)) return JobIntervalType.WithDailyTimeIntervalSchedule;
            else if ("S".Equals(code)) return JobIntervalType.WithSimpleSchedule;
            throw new ArgumentException("Cannot convert value '" + code + "' to JobIntervalType.");
        }
    }
    public class JobRunStatusStringType : NHibernate.Type.EnumStringType
    {
        public JobRunStatusStringType() : base(typeof(JobRunStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((JobRunStatus)enm)
            {
                case JobRunStatus.SUCCESS: return "S";
                case JobRunStatus.INPROGRESS: return "I";
                case JobRunStatus.FAILURE: return "F";
                default: throw new ArgumentException("Invalid JobRunStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("S".Equals(code)) return JobRunStatus.SUCCESS;
            else if ("I".Equals(code)) return JobRunStatus.INPROGRESS;
            else if ("F".Equals(code)) return JobRunStatus.FAILURE;
            throw new ArgumentException("Cannot convert value '" + code + "' to JobRunStatus.");
        }
    }
   
    public class CallStatusStringType : NHibernate.Type.EnumStringType
    {
        public CallStatusStringType() : base(typeof(CallStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((CallStatus)enm)
            {
                case CallStatus.QUEUED: return "Q";
                case CallStatus.INPROGRESS: return "I";
                case CallStatus.COMPLETED: return "C";
                case CallStatus.FAILED: return "F";
                case CallStatus.BUSY: return "B";
                default: throw new ArgumentException("Invalid JobStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("Q".Equals(code)) return CallStatus.QUEUED;
            else if ("I".Equals(code)) return CallStatus.INPROGRESS;
            else if ("C".Equals(code)) return CallStatus.COMPLETED;
            else if ("F".Equals(code)) return CallStatus.FAILED;
            else if ("B".Equals(code)) return CallStatus.BUSY;
            throw new ArgumentException("Cannot convert value '" + code + "' to JobStatus.");
        }
    }
    public class CallDirectionStringType : NHibernate.Type.EnumStringType
    {
        public CallDirectionStringType() : base(typeof(CallDirection), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((CallDirection)enm)
            {
                case CallDirection.INBOUND: return "I";
                case CallDirection.OUTBOUNDDAIL: return "D";
                case CallDirection.OUTBOUNDAPI: return "O";
                default: throw new ArgumentException("Invalid JobStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("I".Equals(code)) return CallDirection.INBOUND;
            else if ("D".Equals(code)) return CallDirection.OUTBOUNDDAIL;
            else if ("O".Equals(code)) return CallDirection.OUTBOUNDAPI;
            throw new ArgumentException("Cannot convert value '" + code + "' to JobStatus.");
        }
    }
}