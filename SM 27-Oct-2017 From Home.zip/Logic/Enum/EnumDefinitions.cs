﻿
/// <summary>
/// Summary description for MyENUM
/// </summary>

using System;
using System.ComponentModel;
namespace ConstroSoft
{
    /*ENUMs which are used to map Only UI fields*/
	public enum DrpDataType
    {
        MASTER_CONTROL_DATA,////Fetch all records for given type
        MASTER_CONTROL_DATA_N,//Fetch records for given type with SYSTEM_DEFINED = "N"
        COUNTRY,
        STATE,
        CITY,
        SECURITY_QUESTION,
        ENQUIRY_REFERENCE_NUMBER,
        PROPERTY_NAME,
        PROPERTY_TOWER,
        FIRM_ACCOUNT,
        ACTIVE_USERS_WITH_PR_ACCESS,
        PR_AVAILABLE_PARKING,
        CUSTOMER_SEARCH_BY_NAME_REF,
        CUSTOMER_SEARCH_BY_NAME,
        PR_AVAILABLE_UNIT,
        PR_TOWER_UNITS,
        PR_PARKING_SEARCH_BY_PARKINGNO
    }
    public enum AcntTransStmtOption
    {
        [Description("Current Month")]
        CURRENT_MONTH,
        [Description("Last Two Months")]
        LAST_TWO_MONTHS,
        [Description("Last Three Months")]
        LAST_THREE_MONTHS,
        [Description("Date Range")]
        DATE_RANGE
    }
    /*ENUMs which are used to map DB and UI fields. NOTE: If you add/remove any value then you need to modify corresponding DB mapping in EnumDBHelper.cs*/
    public enum UserStatus { Setup, Active, InActive }
    public enum PreferredAddress { Yes, No }
    public enum MaritalStatus { Single, Married }
    public enum Gender { Male, Female }
    public enum EnquiryStatus { Open, Won, Lost}
    public enum EnqActivityRecordType { Activity, Event, Task, Action}
    public enum EventTaskMode { None, Scheduled, Rescheduled, Cancelled }
    public enum EnqActivityType
    {
        [Description("Site Visit")]
        SITE_VISIT,
        [Description("Meeting")]
        MEETING,
        [Description("Followup")]
        FOLLOW_UP,
        [Description("Assignment")]
        ASSIGNMENT,
        [Description("Reassignment")]
        RE_ASSIGNMENT,
        [Description("Converted")]
        CONVERTED,
        [Description("Created")]
        CREATE,
        [Description("Lost")]
        LOST,
        [Description("Won")]
        WON,
        [Description("Booking Cancelled")]
        BOOKING_CANCELLED,
        [Description("Re-Opened")]
        RE_OPENED,
        [Description("Task")]
        TASK
    }
    public enum EnqLeadActivityStatus { Open, Deferred, Completed }
    public enum LeadStatus { Open, Converted, Lost}
	public enum PowerOfAtorny { Yes, No }
    public enum SystemDefined { Yes, No }
    public enum CommonParking { Yes, No }
    public enum ParkingStatus { Available, Reserved, Allotted, Deleted }
    public enum PRScheduleStageStatus { Pending, Completed }
    public enum IncludeInPymtTotal { Yes, No }
    public enum PRUnitStatus { Available, Reserved, Sold, Deleted }
    public enum PRUnitSaleStatus { Sold, Cancelled }
    public enum PrFMAccess { No, Yes }
    public enum VoucherType { Payment, Receipt }
    public enum TallyPostingStatus { [Description("Pending")]Pending, [Description("Posted")] Posted }
    public enum Action { Create, Cancel }
    public enum PaymentMode{ Receivable, Payable }
    public enum FunctionName
    {
        [Description("Manage Enquiry")]
        ENQUIRY,
        [Description("Manage Sales")]
        SALE
    }
    public enum EmailSmsType
    {
        [Description("Enquiry Thanks")]
        ENQUIRYTHANKS,
        [Description("Sale Thanks")]
        SALESTHANKS,
        [Description("Sale Cancel")]
        SALESCANCEL
    }
    public enum IsPossessionDone { No, Yes }
    public enum IsAgreementDone { No, Yes }
    public enum PymtTransStatus { Pending, Paid, Deleted, Reversal }
    public enum ChequeStatus { Collected, Deposited, Cleared, Bounced, Returned }
    public enum MPTPymtStatus { Pending, Paid, Deleted }
    public enum PymtMasterStatus
    {
        [Description("Paid")]
        Paid,
        [Description("Pending")]
        Pending,
        [Description("Deleted")]
        Deleted,
        [Description("Suspended")]
        Suspended
    }
    public enum PaymentMethod
    {
        [Description("Cash")]
        CASH,
        [Description("Cheque")]
        CHEQUE,
        [Description("RTGS")]
        RTGS,
        [Description("NEFT")]
        NEFT,
        [Description("Demand Draft")]
        DD
    }
    public enum AcntTransStatus { Credit, Debit }
    public enum PromoCustomerType { ENQUIRY, SALE, CO_CUSTOMER, ONLY_CUSTOMER }
    public enum PropertyFundStatus { Deposited, Reversed }

    public enum DocumentOwner
    {
        [Description("--Select--")]
        NONE,
        [Description("Property Name")]
        PROPERTY_NAME,
        [Description("Customer Name")]
        CUSTOMER_NAME,
        [Description("Supplier Name")]
        SUPPLIER_NAME,
        [Description("Contractor Name")]
        CONTACTOR_NAME,
        [Description("Employee Name")]
        EMPLOYEE_NAME
    }

    public enum MasterDataType
    {
        [Description("Salutation")]
        SALUTATION,
        [Description("Address Type")]
        ADDRESS_TYPE,
        [Description("Designation")]
        DESIGNATION,
        [Description("Security Question")]
        SECURITY_QUESTION,
        [Description("Account Type")]
        ACCOUNT_TYPE,
        [Description("Property Type")]
        PROPERTY_TYPE,
        [Description("Property Location")]
        PROPERTY_LOCATION,
        [Description("Property Tax Type")]
        PR_TAX_TYPE,
        [Description("Expenses Type")]
        PR_EXPENSE_TYPE,
        [Description("Parking Type")]
        PR_PARKING_TYPE,
        [Description("Unit Facing")]
        PR_UNIT_FACING,
        [Description("Occupation")]
        OCCUPATION,
        [Description("Customer Relation")]
        CUSTOMER_RELATION,
        [Description("Unit Payment Type")]
        PR_UNIT_PYMT_TYPE,
        [Description("Purchase Item Quality")]
        PURCHASE_ITEM_QUALITY,
        [Description("Contractor Type")]
        CONTRACTOR_TYPE,
        [Description("Enquiry Source")]
        ENQUIRY_SOURCE,
        [Description("Enquiry Media Type")]
        ENQUIRY_MEDIA_TYPE,
        [Description("Document Type")]
        DOCUMENT_TYPE,
        [Description("Property Unit Type")]
        PR_UNIT_TYPE,
        [Description("Property Unit Direction")]
        PR_UNIT_DIRECTION
    }

    public enum SelectLettersName
    {
        [Description("Demand Letter")]
        DEMAND_LETTER,
        [Description("Possession Letter")]
        POSSESSION,
        [Description("NOC for Mortgage")]
        MORTGUAGE
    }
    public enum DashboardEvent
    {
        [Description("Possession")]
        POSSESSION,
        [Description("Agreement")]
        AGREEMENT
    }
    public enum PageMode {ADD, VIEW, MODIFY, GENERATELETTER}
    public enum EnqActivityMode { NONE, ADD_ACTIVITY, ADD_EVENT, RESCHEDULE_EVENT, ADD_EVENT_ACTIVITY, CANCEL_EVENT, ADD_TASK, RESCHEDULE_TASK, COMPLETE_TASK, CANCEL_TASK}
    public enum FileType {Folder, File}
    public enum SizeUnits {Byte, KB, MB, GB}
}