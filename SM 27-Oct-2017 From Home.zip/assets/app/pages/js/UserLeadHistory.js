﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initUserLeadHistorySearchGrid();
    formatFields();
    showModal();
}

function initUserLeadHistorySearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        pageLength: 10,
        hideSearch: true
    };

    $("[id$='userLeadHistorySearchGrid']").CSBasicDatatable(dtOptions);
}




