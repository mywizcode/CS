﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initSoldUnitSearchGrid();
    formatFields();
    showModal();
}

function initSoldUnitSearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        pageLength: 10
    };
    
    $("[id$='soldUnitSearchGrid']").CSBasicDatatable(dtOptions);
}




