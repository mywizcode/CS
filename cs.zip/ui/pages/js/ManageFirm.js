$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initAccountGrid();
    formatFields();
    //This script will enable tabs which was last active even after postback call.
    if ($("[id$='activeTabHdn']").val() != "") {
        $('a[id$="' + $("[id$='activeTabHdn']").val() + '"]').tab('show');
    }
}

function initAccountGrid() {
    var dtOptions = {
        tableId: "accountGrid",
        isViewOnly: false,
        pageLength: 5,
        responsiveModalTitle: "Account Details",
        customBtnGrpId: "#customBtnDiv",
        hasRowInfo: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToAcntHdnId");
}