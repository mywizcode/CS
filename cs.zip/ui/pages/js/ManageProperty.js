$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initPropertyGrid();
    initTowerGrid();
    initAmenityGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("tab2Content");
    //This script will enable tabs which was last active even after postback call.
    enableTab(true);
}

function initTowerGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "propertyTowerGrid",
        isViewOnly: isViewOnly,
        pageLength: 5,
        responsiveModalTitle: "Property Tower Details",
        customBtnGrpId: "#propTowerGridBtnGrp",
        hasRowInfo: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPropertyTowerHdnId");
}

function initAmenityGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "amenityGrid",
        isViewOnly: isViewOnly,
        pageLength: 5,
        responsiveModalTitle: "Amenity Details",
        customBtnGrpId: "#amenityGridBtnGrp",
        hasRowInfo: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToAmenityHdnId");
}

function initPropertyGrid() {
    var dtOptions = {
        tableId: "propertyGrid",
        isViewOnly: false,
        pageLength: 10,
        responsiveModalTitle: "Property Details",
        customBtnGrpId: "#propSearchBtnDiv",
        hasRowInfo: false
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPropertyHdnId");
}