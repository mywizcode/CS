﻿
/// <summary>
/// Summary description for MyENUM
/// </summary>

using System;
namespace ConstroSoft
{
    public class UserStatusStringType : NHibernate.Type.EnumStringType
    {
        public UserStatusStringType(): base(typeof(UserStatus), 1){}
        public override object GetValue(object enm)
        {
            if (null == enm)return String.Empty;
            switch ((UserStatus)enm)
            {
                case UserStatus.Active: return "A";
                case UserStatus.InActive: return "I";
                default: throw new ArgumentException("Invalid UserStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("A".Equals(code)) return UserStatus.Active;
            else if ("I".Equals(code)) return UserStatus.InActive;
            throw new ArgumentException("Cannot convert value '" + code + "' to UserStatus.");
        }
    }
    public class PreferredAddressStringType : NHibernate.Type.EnumStringType
    {
        public PreferredAddressStringType(): base(typeof(PreferredAddress), 1){}
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PreferredAddress)enm)
            {
                case PreferredAddress.Yes: return "Y";
                case PreferredAddress.No: return "N";
                default: return null;
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return PreferredAddress.Yes;
            else if ("N".Equals(code)) return PreferredAddress.No;
            return null;
        }
    }
    public class GenderStringType : NHibernate.Type.EnumStringType
    {
        public GenderStringType() : base(typeof(Gender), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((Gender)enm)
            {
                case Gender.Male: return "M";
                case Gender.Female: return "F";
                default: return null;
            }
        }
        public override object GetInstance(object code)
        {
            if ("M".Equals(code)) return Gender.Male;
            else if ("F".Equals(code)) return Gender.Female;
            return null;
        }
    }
    public class MaritalStatusStringType : NHibernate.Type.EnumStringType
    {
        public MaritalStatusStringType() : base(typeof(MaritalStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((MaritalStatus)enm)
            {
                case MaritalStatus.Single: return "S";
                case MaritalStatus.Married: return "M";
                default: return null;
            }
        }
        public override object GetInstance(object code)
        {
            if ("S".Equals(code)) return MaritalStatus.Single;
            else if ("M".Equals(code)) return MaritalStatus.Married;
            return null;
        }
    }
    public class EnquiryStatusStringType : NHibernate.Type.EnumStringType
    {
        public EnquiryStatusStringType() : base(typeof(EnquiryStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((EnquiryStatus)enm)
            {
                case EnquiryStatus.Open: return "O";
                case EnquiryStatus.Closed: return "C";
                default: throw new ArgumentException("Invalid EnquiryStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("O".Equals(code)) return EnquiryStatus.Open;
            else if ("C".Equals(code)) return EnquiryStatus.Closed;
            throw new ArgumentException("Cannot convert value '" + code + "' to EnquiryStatus.");
        }
    }
    public class CommonParkingStringType : NHibernate.Type.EnumStringType
    {
        public CommonParkingStringType() : base(typeof(CommonParking), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((CommonParking)enm)
            {
                case CommonParking.Yes: return "Y";
                case CommonParking.No: return "N";
                default: throw new ArgumentException("Invalid CommonParking.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return CommonParking.Yes;
            else if ("N".Equals(code)) return CommonParking.No;
            throw new ArgumentException("Cannot convert value '" + code + "' to CommonParking.");
        }
    }
    public class ParkingStatusStringType : NHibernate.Type.EnumStringType
    {
        public ParkingStatusStringType() : base(typeof(ParkingStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((ParkingStatus)enm)
            {
                case ParkingStatus.Available: return "A";
                case ParkingStatus.Reserved: return "R";
                case ParkingStatus.Allotted: return "X";
                default: throw new ArgumentException("Invalid ParkingStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("A".Equals(code)) return ParkingStatus.Available;
            else if ("R".Equals(code)) return ParkingStatus.Reserved;
            else if ("X".Equals(code)) return ParkingStatus.Allotted;
            throw new ArgumentException("Cannot convert value '" + code + "' to ParkingStatus.");
        }
    }
    public class PRScheduleStageStatusStringType : NHibernate.Type.EnumStringType
    {
        public PRScheduleStageStatusStringType() : base(typeof(PRScheduleStageStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PRScheduleStageStatus)enm)
            {
                case PRScheduleStageStatus.Pending: return "P";
                case PRScheduleStageStatus.Completed: return "C";
                default: throw new ArgumentException("Invalid PRScheduleStageStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("P".Equals(code)) return PRScheduleStageStatus.Pending;
            else if ("C".Equals(code)) return PRScheduleStageStatus.Completed;
            throw new ArgumentException("Cannot convert value '" + code + "' to PRScheduleStageStatus.");
        }
    }
    public class IncludeInPymtTotalStringType : NHibernate.Type.EnumStringType
    {
        public IncludeInPymtTotalStringType() : base(typeof(IncludeInPymtTotal), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((IncludeInPymtTotal)enm)
            {
                case IncludeInPymtTotal.Yes: return "Y";
                case IncludeInPymtTotal.No: return "N";
                default: throw new ArgumentException("Invalid IncludeInPymtTotal.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return IncludeInPymtTotal.Yes;
            else if ("N".Equals(code)) return IncludeInPymtTotal.No;
            throw new ArgumentException("Cannot convert value '" + code + "' to IncludeInPymtTotal.");
        }
    }
}