﻿
/// <summary>
/// Summary description for MyENUM
/// </summary>

using System;
using System.ComponentModel;
namespace ConstroSoft
{
    /*ENUMs which are used to map Only UI fields*/
    public enum DrpDataType
    {
        MASTER_CONTROL_DATA,
        COUNTRY,
        STATE,
        CITY,
        ENQUIRY_STATUS,
        ENQUIRY_CUSTOMER_NAME,
        EMPLOYEE_SEARCH_BY_NAME,
        EMPLOYEE_SEARCH_BY_ID,
        GENDER,
        MARITAL_STATUS,
        PROPERTY_NAME,
        EMPLOYEE_NAME,
        DEPARTMENT,
        PREFERRED_ADDRESS,
        PROPERTY_SEARCH_BY_NAME,
        PROPERTY_SEARCH_BY_TYPE,
        PROPERTY_SEARCH_BY_LOCATION,
        FIRM_ACCOUNT
    }
    public enum PageMode { ADD, MODIFY, VIEW, NONE }
    public enum EnquirySearchBy { CUSTOMER_NAME, PROP_NAME, PROP_TYPE, PROP_LOCATION, PROP_UNIT_TYPE }
    public enum EmployeeSearchBy
    {
        [Description("--Select--")]
        NONE,
        [Description("Employee Name")]
        EMPLOYEE_NAME,
        [Description("Employee Id")]
        EMPLOYEE_ID,
        [Description("Department")]
        DEPARTMENT
    }
    public enum PropertySearchBy
    {
        [Description("--Select--")]
        NONE,
        [Description("Property Name")]
        PROPERTY_NAME,
        [Description("Property Type")]
        PROPERTY_TYPE,
        [Description("Property Location")]
        PROPERTY_LOCATION
    }
    /*ENUMs which are used to map DB and UI fields. NOTE: If you add/remove any value then you need to modify corresponding DB mapping in EnumDBHelper.cs*/
    public enum UserStatus { Active, InActive }
    public enum PreferredAddress { Yes, No }
    public enum MaritalStatus { Single, Married }
    public enum Gender { Male, Female }
    public enum EnquiryStatus { Open, Closed }
    public enum CommonParking { Yes, No }
    public enum ParkingStatus { Available, Reserved, Allotted }
    public enum PRScheduleStageStatus { Pending, Completed }
    public enum IncludeInPymtTotal { Yes, No }
}