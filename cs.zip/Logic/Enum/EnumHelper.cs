﻿
/// <summary>
/// Summary description for MyENUM
/// </summary>

using System;
using System.ComponentModel;
namespace ConstroSoft
{
    public static class EnumHelper
    {
        public static string GetEnumDescription<T>(string value)
        {
            Type type = typeof(T);
            var field = type.GetField(value);
            var customAttribute = field.GetCustomAttributes(typeof(DescriptionAttribute), false);
            return customAttribute.Length > 0 ? ((DescriptionAttribute)customAttribute[0]).Description : value;
        }
        public static T ToEnum<T>(this string value, bool ignoreCase = true)
        {
            return (T)Enum.Parse(typeof(T), value, ignoreCase);
        }
        public static TEnum? ToEnumNullable<TEnum>(string value) where TEnum : struct
        {
            return (string.IsNullOrWhiteSpace(value)) ? (TEnum?)null : (TEnum)Enum.Parse(typeof(TEnum), value);
        }
    }
}