﻿
/// <summary>
/// Summary description for CommonUIConverter
/// </summary>
using ConstroSoft;
using System.Collections.Generic;
using NHibernate.Criterion;
using System.Linq.Expressions;
using NHibernate.Impl;
using System;
namespace ConstroSoft
{
    public class CommonUIConverter
    {
        public CommonUIConverter() { }
        public static string getRowInfo(string col1Value, string col2Value)
        {
            string td = "<tr><td style=\"width:30%;\">{0}</td><td>{1}</td></tr>";
            return string.Format(td, col1Value, (col2Value != null) ? col2Value : "");
        }
        public static string getRowInfo(string col1Value, string col2Value, string valueClass)
        {
            string td = "<tr><td style=\"width:30%;\">{0}</td><td class=\"{2}\">{1}</td></tr>";
            return string.Format(td, col1Value, (col2Value != null) ? col2Value : "", valueClass);
        }
        public static string getGridViewRowInfo(AddressDTO addressDto)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.label_addressline1, addressDto.AddressLine1)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_addressline2, addressDto.AddressLine2)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_town, addressDto.Town)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_city, addressDto.City.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_state, addressDto.State.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_country, addressDto.Country.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_pin, addressDto.Pin)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_addresstype, (addressDto.AddressType != null) ? addressDto.AddressType.Name : "")
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_preferred_address, addressDto.PreferredAddress.ToString());
        }
        public static string getGridViewRowInfo(FirmAccountDTO firmAcntDto)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.label_accountname, firmAcntDto.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_accountnumber, firmAcntDto.AccountNo)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_accounttype, (firmAcntDto.AccountType != null) ? firmAcntDto.AccountType.Name : "")
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_accountbalance, firmAcntDto.AccountBalance.ToString(), "csamount")
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_ifsccode, firmAcntDto.IfscCode)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_bankname, firmAcntDto.BankName)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_branch, firmAcntDto.Branch)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_city, (firmAcntDto.City != null) ? firmAcntDto.City.Name : "")
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_state, (firmAcntDto.State != null) ? firmAcntDto.State.Name : "")
                    +CommonUIConverter.getRowInfo(Resources.Labels.label_country, (firmAcntDto.Country != null) ? firmAcntDto.Country.Name : "");
        }
        public static string getGridViewRowInfo(PropertyTowerDTO propertyTowerDto)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.label_towername, propertyTowerDto.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_launchdate, CommonUtil.getCSDate(propertyTowerDto.LaunchDate))
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_propertyrate, (propertyTowerDto.Rate != null) ? propertyTowerDto.Rate.ToString() : "", "csamount")
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_possession, CommonUtil.getCSDate(propertyTowerDto.Possession))
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_description, propertyTowerDto.Description);
        }
        public static string getGridViewRowInfo(PropertyAmenityDTO amenityDto)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.label_amenity, amenityDto.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_description, amenityDto.Description);
        }
        public static string getGridViewRowInfo(PropertyTaxDetailDTO propertyTaxDetailDTO)
        {
            return "";
        }
        public static CityDTO getCityDTO(string Id, string Name)
        {
            CityDTO dto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                dto = new CityDTO();
                dto.Id = long.Parse(Id);
                dto.Name = Name;
            }
            return dto;
        }
        public static StateDTO getStateDTO(string Id, string Name)
        {
            StateDTO dto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                dto = new StateDTO();
                dto.Id = long.Parse(Id);
                dto.Name = Name;
            }
            return dto;
        }
        public static CountryDTO getCountryDTO(string Id, string Name)
        {
            CountryDTO dto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                dto = new CountryDTO();
                dto.Id = long.Parse(Id);
                dto.Name = Name;
            }
            return dto;
        }
        public static MasterControlDataDTO getMasterControlDTO(string Id, string Name)
        {
            MasterControlDataDTO mdDto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                mdDto = new MasterControlDataDTO();
                mdDto.Id = long.Parse(Id);
                mdDto.Name = Name;
            }
            return mdDto;
        }
        public static DepartmentDTO getDepartmentDTO(string Id, string Name)
        {
            DepartmentDTO dto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                dto = new DepartmentDTO();
                dto.Id = long.Parse(Id);
                dto.Name = Name;
            }
            return dto;
        }
        public static FirmAccountDTO getFirmAccountDTO(string Id, string Name)
        {
            FirmAccountDTO dto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                dto = new FirmAccountDTO();
                dto.Id = long.Parse(Id);
                dto.Name = Name;
            }
            return dto;
        }
        public static MasterControlDataDTO populateMasterDataDTOAdd(string type, string name, string description, UserDefinitionDTO userDefDto)
        {
            MasterControlDataDTO masterDataDto = new MasterControlDataDTO();
            masterDataDto.Name = name;
            masterDataDto.Description = description;
            masterDataDto.FirmNumber = userDefDto.FirmNumber;
            masterDataDto.InsertUser = userDefDto.Username;
            masterDataDto.UpdateUser = userDefDto.Username;
            masterDataDto.Type = type;
            masterDataDto.SystemDefined = "N";
            return masterDataDto;
        }
        public static DepartmentDTO populateDepartmentDTOAdd(string name, string description, UserDefinitionDTO userDefDto)
        {
            DepartmentDTO departmentDto = new DepartmentDTO();
            departmentDto.Name = name;
            departmentDto.Description = description;
            departmentDto.FirmNumber = userDefDto.FirmNumber;
            departmentDto.InsertUser = userDefDto.Username;
            departmentDto.UpdateUser = userDefDto.Username;
            return departmentDto;
        }
    }
}