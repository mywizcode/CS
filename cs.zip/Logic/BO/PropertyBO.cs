﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq.Expressions;
using NHibernate.Impl;

/// <summary>
/// Summary description for propertyBO
/// </summary>
namespace ConstroSoft
{
    public class PropertyBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public PropertyBO() { }

        public IList<PropertyDTO> fetchPropertyGridData(string firmNumber, PropertySearchBy searchBy, long searchByValue)
        {
            ISession session = null;
            IList<PropertyDTO> result = new List<PropertyDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                Property p = null;
                PropertyDTO pDto = null;
                MasterControlData pType = null;
                MasterControlData pLoc = null;
                FirmAccount fa = null;
                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => p.Id).WithAlias(() => pDto.Id))
                            .Add(Projections.Property(() => p.Name).WithAlias(() => pDto.Name))
                            .Add(Projections.Property(() => pType.Name), "PropertyType.Name")
                            .Add(Projections.Property(() => pLoc.Name), "PropertyLocation.Name")
                            .Add(Projections.Property(() => p.PropertyArea).WithAlias(() => pDto.PropertyArea))
                            .Add(Projections.Property(() => fa.Name), "FirmAccount.Name");
                var query = session.QueryOver<Property>(() => p)
                    .Left.JoinAlias(() => p.PropertyType, () => pType)
                    .Left.JoinAlias(() => p.PropertyLocation, () => pLoc)
                    .Left.JoinAlias(() => p.FirmAccount, () => fa);
                if (PropertySearchBy.NONE != searchBy && searchByValue != -1)
                {
                    PropertyProjection prop = null;
                    if (PropertySearchBy.PROPERTY_NAME == searchBy)
                    {
                        prop = CommonUtil.BuildProjection<Property>(() => p, x => x.Id);
                    }
                    else if (PropertySearchBy.PROPERTY_TYPE == searchBy)
                    {
                        prop = CommonUtil.BuildProjection<MasterControlData>(() => pType, x => x.Id);
                    }
                    else if (PropertySearchBy.PROPERTY_LOCATION == searchBy)
                    {
                        prop = CommonUtil.BuildProjection<MasterControlData>(() => pLoc, x => x.Id);
                    }
                    query.Where(Restrictions.Eq(prop, searchByValue));
                }
                result = query.Where(() => p.FirmNumber == firmNumber)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<PropertyDTO>()).List<PropertyDTO>();
            }
            catch (Exception exp) {
                log.Error("Unexpected error fetching data for property search grid:");
                log.Error(exp.Message, exp);
            } finally {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public PropertyDTO fetchProperty(long Id)
        {
            ISession session = null;
            PropertyDTO propertyDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Property property = session.Get<Property>(Id);
                        propertyDto = DomainToDTOUtil.convertToPropertyDTO(property, true);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading property details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return propertyDto;
        }
        public long saveProperty(PropertyDTO propertyDto)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Property property = DTOToDomainUtil.populatePropertyAddFields(propertyDto);
                        session.Save(property);
                        Id = property.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving property details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        public void updateProperty(PropertyDTO propertyDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Property property = session.Get<Property>(propertyDto.Id);
                        DTOToDomainUtil.populatePropertyUpdateFields(property, propertyDto);
                        session.Update(property);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating property details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void deleteProperty(long Id)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Property property = session.Get<Property>(Id);
                        session.Delete(property);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while deleting property details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
    }
}