﻿using System;
using System.Web.UI.WebControls;
using NHibernate;
using System.Collections;
using System.Collections.Generic;
using NHibernate.Criterion;

/// <summary>
/// Summary description for DropdownBO
/// </summary>
namespace ConstroSoft
{
    public class DropdownBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public DropdownBO(){}
        public void drpEnum<T>(DropDownList drp, string[] firstItem)
        {
            drp.Items.Clear();
            string[] arr = Enum.GetNames(typeof(T));
            foreach (string x in arr)
            {
                string description = EnumHelper.GetEnumDescription<T>(x);
                drp.Items.Add(new ListItem(description, x));
            }
            if (firstItem != null) drp.Items.Insert(0, new ListItem(firstItem[0], firstItem[1]));
        }
        public void drpDataBase(DropDownList drp, DrpDataType drpDataType, string additionalInfo, string[] firstItem, string firmNumber)
        {
            ISession session = null;
            try
            {
                drp.Items.Clear();
                if (firstItem != null) drp.Items.Add(new ListItem(firstItem[0], firstItem[1]));
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        session = NHibertnateSession.OpenSession();
                        IList<object[]> result = getDrpItems(session, drpDataType, additionalInfo, firmNumber);
                        addItemsToDropDown(drp, result);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Unexpected error populating dropdown:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        
        private IList<object[]> getDrpItems(ISession session, DrpDataType drpDataType, string additionalInfo, string firmNumber)
        {
            IList<object[]> result = null;
            if (DrpDataType.MASTER_CONTROL_DATA == drpDataType)
            {
                result = session.QueryOver<MasterControlData>().Select(c => c.Name,
                            c => c.Id).Where(c => c.FirmNumber == firmNumber && c.Type == additionalInfo).List<object[]>();
            }
            else if (DrpDataType.COUNTRY == drpDataType)
            {
                result = session.QueryOver<Country>().Select(p => p.Name, p => p.Id).List<object[]>();
            }
            else if (DrpDataType.STATE == drpDataType && !string.IsNullOrWhiteSpace(additionalInfo))
            {
                State s = null;
                Country c = null;
                result = session.QueryOver<State>(() => s).JoinAlias(() => s.Country, () => c).Where(() => c.Id == long.Parse(additionalInfo))
                        .Select(p => p.Name, p => p.Id).List<object[]>();
            }
            else if (DrpDataType.CITY == drpDataType && !string.IsNullOrWhiteSpace(additionalInfo))
            {
                City s = null;
                State c = null;
                result = session.QueryOver<City>(() => s).JoinAlias(() => s.State, () => c).Where(() => c.Id == long.Parse(additionalInfo))
                        .Select(p => p.Name, p => p.Id).List<object[]>();
            }
            else if (DrpDataType.DEPARTMENT == drpDataType)
            {
                result = session.QueryOver<Department>().Select(p => p.Name, p => p.Id)
                        .Where(p => p.FirmNumber == firmNumber).List<object[]>();
            }
            else if (DrpDataType.EMPLOYEE_SEARCH_BY_NAME == drpDataType)
            {
                FirmMember fm = null;
                var proj = Projections.ProjectionList()
                            .Add(Projections.SqlFunction("concat",
                                        NHibernateUtil.String,
                                        Projections.Property(() => fm.FirstName),
                                        Projections.Constant(" "),
                                        Projections.Property(() => fm.LastName)))
                            .Add(Projections.Property(() => fm.Id));
                result = session.QueryOver<FirmMember>(() => fm).Select(proj)
                        .Where(p => p.FirmNumber == firmNumber).List<object[]>();
            }
            else if (DrpDataType.EMPLOYEE_SEARCH_BY_ID == drpDataType)
            {
                result = session.QueryOver<FirmMember>().Select(p => p.EmployeeId, p => p.Id)
                        .Where(p => p.FirmNumber == firmNumber).List<object[]>();
            }
            else if (DrpDataType.ENQUIRY_CUSTOMER_NAME == drpDataType)
            {
                EnquiryDetail eq = null;
                var proj = Projections.ProjectionList()
                            .Add(Projections.SqlFunction("concat",
                                        NHibernateUtil.String,
                                        Projections.Property(() => eq.FirstName),
                                        Projections.Constant(" "),
                                        Projections.Property(() => eq.LastName)))
                            .Add(Projections.Property(() => eq.Id));
                result = session.QueryOver<EnquiryDetail>(() => eq).Select(proj)
                        .Where(p => p.FirmNumber == firmNumber).List<object[]>();
            }
            else if (DrpDataType.PROPERTY_NAME == drpDataType)
            {
                result = session.QueryOver<Property>().Select(p => p.Name, p => p.Id)
                        .Where(p => p.FirmNumber == firmNumber).List<object[]>();
            }
            return result;
        }
        private void addItemsToDropDown(DropDownList drp, IList<object[]> result)
        {
            if (result != null)
            {
                foreach (object[] obj in result)
                {
                    drp.Items.Add(new ListItem((string)obj[0], obj[1]+""));
                }
            }
        }
    }
}