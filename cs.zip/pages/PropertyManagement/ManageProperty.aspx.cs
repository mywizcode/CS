﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;

public partial class ManageProperty : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string tab1ValidationGrp = "tab1Error";
    string tab2ValidationGrp = "tab2Error";
    string VS_PROPERTY_LIST = "PROPERTY_LIST";
    string VS_SELECTED_EMPLOYEE = "SELECTED_PROPERTY";
    DropdownBO drpBO = new DropdownBO();
    PropertyBO propertyBO = new PropertyBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    DepartmentBO departmentBO = new DepartmentBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (Session[Constants.Session.USERNAME] != null)
            {
                resetTabInfo(PageMode.NONE);
                initDropdowns();
                loadSearchGridAndReSelect(0);
                Page.MaintainScrollPositionOnPostBack = false;
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpPropertytype, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpPropertyLocation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_LOCATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAccount, DrpDataType.FIRM_ACCOUNT, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<EmployeeSearchBy>(drpSearchBy, null);
        drpBO.drpDataBase(drpAddressCountry, DrpDataType.COUNTRY, null, null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAddressState, DrpDataType.STATE, Constants.DEFAULT_COUNTRY, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpAddressState.Text = Constants.DEFAULT_STATE;
        initCityDrp(drpAddressCity, Constants.DEFAULT_STATE);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        applyEntitlement();
        preRenderInitFormElements();
        initBootstrapComponantsFromServer();
    }
    private bool isViewOnlyUser()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        bool isViewOnlyUser = !CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.FIRM_MEMBER_ADD_UPDATE);
        return isViewOnlyUser;
    }
    private void applyEntitlement()
    {
        if (isViewOnlyUser())
        {
            btnAddProperty.Visible = false;
            btnModifyProperty.Visible = false;
            btnDeleteProperty.Visible = false;
        }
    }
    private void preRenderInitFormElements()
    {
        PropertyDTO selectedProperty = getCurrentProperty();
        jumpToPropertyHdnId.Value = null;
        jumpToPropertyTowerHdnId.Value = null;
        if (selectedProperty != null)
        {
            jumpToPropertyHdnId.Value = selectedProperty.Id.ToString();
            List<PropertyTowerDTO> propertyTowerList = selectedProperty.PropertyTowers.ToList<PropertyTowerDTO>();
            if (propertyTowerList != null && propertyTowerList.Count > 0)
            {
                PropertyTowerDTO selectedTower = propertyTowerList.Find(a => a.isUISelected);
                if (selectedTower != null) jumpToPropertyTowerHdnId.Value = selectedTower.UiIndex.ToString();
            }
            List<PropertyAmenityDTO> amenityList = selectedProperty.PropertyAmenities.ToList<PropertyAmenityDTO>();
            if (amenityList != null && amenityList.Count > 0)
            {
                PropertyAmenityDTO amenity = amenityList.Find(a => a.isUISelected);
                if (amenity != null) jumpToAmenityHdnId.Value = amenity.UiIndex.ToString();
            }
        }
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
    }

    public void setSuccessMessage(string msg, string tabId)
    {
        activeTabHdn.Value = tabId;
        if (tabId.Equals(tab1Anchor.ID))
        {
            lbTab1Success.Text = msg;
            tab1SuccessPanel.Visible = true;
        }
        else if (tabId.Equals(tab2Anchor.ID))
        {
            lbTab2Success.Text = msg;
            tab2SuccessPanel.Visible = true;
        }
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private void clearMessages()
    {
        tab1SuccessPanel.Visible = false;
        lbTab1Success.Text = "";
        tab2SuccessPanel.Visible = false;
        lbTab2Success.Text = "";
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }

    private void resetTabInfo(PageMode pageMode)
    {
        tab2Anchor.Visible = true;
        activeTabHdn.Value = tab2Anchor.ID;
        pageModeHdn.Value = pageMode.ToString();
        initFormFields();
        pnlPropertyTowerAdd.Visible = false;
        pnlAmenityAdd.Visible = false;
        if (PageMode.ADD == pageMode)
        {
            tab2Anchor.Text = Resources.Labels.prpm_sm_manage_prop_tab2_add_name;
            initFormFields();
        }
        else if (PageMode.MODIFY == pageMode)
        {
            tab2Anchor.Text = Resources.Labels.prpm_sm_manage_prop_tab2_modify_name;
            initFormFields();
        }
        else if (PageMode.VIEW == pageMode)
        {
            tab2Anchor.Text = Resources.Labels.prpm_sm_manage_prop_tab2_view_name;
            initFormFields();
        }
        else
        {
            activeTabHdn.Value = tab1Anchor.ID;
            tab2Anchor.Visible = false;
            ViewState[VS_SELECTED_EMPLOYEE] = null;
        }
    }
    private void initFormFields()
    {
        bool isReadOnly = (PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
        bool visible = !(PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
        //Buttons
        btnAddSubmit.Visible = visible;
        //addDepartmentBtn.Visible = visible;
        //addDesignationBtn.Visible = visible;
        btnAddPropTower.Visible = visible;
        btnModifyPropTower.Visible = visible;
        btnDeletePropTower.Visible = visible;
        propertyTowerGrid.Columns[0].Visible = visible;

        btnAddAmenity.Visible = visible;
        btnModifyAmenity.Visible = visible;
        btnDeleteAmenity.Visible = visible;
        amenityGrid.Columns[0].Visible = visible;
    }
    private PropertyDTO getCurrentProperty()
    {
        return (PropertyDTO)ViewState[VS_SELECTED_EMPLOYEE];
    }
    private void setSelectedProperty(long selectedId)
    {
        List<PropertyDTO> PropertyList = (List<PropertyDTO>)ViewState[VS_PROPERTY_LIST];
        if (PropertyList != null)
        {
            PropertyList.ForEach(c => c.isUISelected = false);
            PropertyList.Find(c => c.Id == selectedId).isUISelected = true;
        }
    }
    private bool validatePropertySelected()
    {
        bool isSelected = true;
        List<PropertyDTO> PropertyList = (List<PropertyDTO>)ViewState[VS_PROPERTY_LIST];
        if (PropertyList != null)
        {
            isSelected = PropertyList.Any(c => c.isUISelected);
            if (!isSelected)
            {
                resetTabInfo(PageMode.NONE);
                setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Property"), tab1ValidationGrp);
            }
        }
        return isSelected;
    }
    private void selectPropertyGridRdBtn(long Id)
    {
        if (propertyGrid.Rows.Count > 0)
        {
            foreach (GridViewRow row in propertyGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdPropertySelect");
                Button rowIdenBtn = (Button)row.FindControl("btnPropRowIdentifier");
                if (radioBtn != null)
                {
                    radioBtn.Checked = false;
                    if (rowIdenBtn != null && Id > 0 && Id.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                    {
                        radioBtn.Checked = true;
                    }
                }
            }
        }
    }
    private void loadSearchGridAndReSelect(long Id)
    {
        try
        {
            PropertySearchBy searchBy = EnumHelper.ToEnum<PropertySearchBy>(drpSearchBy.Text);
            long searchByValId = -1;
            if (!string.IsNullOrWhiteSpace(drpSearchByValue.Text)) searchByValId = long.Parse(drpSearchByValue.Text);
            IList<PropertyDTO> results = propertyBO.fetchPropertyGridData(getUserDefinitionDTO().FirmNumber, searchBy, searchByValId);
            ViewState[VS_PROPERTY_LIST] = results;
            propertyGrid.DataSource = results;
            propertyGrid.DataBind();
            if (Id > 0)
            {
                selectPropertyGridRdBtn(Id);
                setSelectedProperty(Id);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private void fetchSelectedProperty()
    {
        try
        {
            PropertyDTO propertyDTO = null;
            if (PageMode.ADD.ToString().Equals(pageModeHdn.Value))
            {
                propertyDTO = populatepropertyDTOAdd();
                selectPropertyGridRdBtn(0);
            }
            else if (PageMode.MODIFY.ToString().Equals(pageModeHdn.Value) || PageMode.VIEW.ToString().Equals(pageModeHdn.Value))
            {
                long Id = ((List<PropertyDTO>)ViewState[VS_PROPERTY_LIST]).Find(c => c.isUISelected).Id;
                propertyDTO = propertyBO.fetchProperty(Id);
            }
            ViewState[VS_SELECTED_EMPLOYEE] = propertyDTO;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private void doViewModifyAction(PageMode pageMode)
    {
        resetTabInfo(pageMode);
        fetchSelectedProperty();
        populateUIFieldsFromDTO((PropertyDTO)ViewState[VS_SELECTED_EMPLOYEE]);
    }
    protected void onSearchBy(object sender, EventArgs e)
    {
        try
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            PropertySearchBy searchBy = EnumHelper.ToEnum<PropertySearchBy>(drpSearchBy.Text);
            drpSearchByValue.Visible = true;
            lbSearchByValue.Visible = true;
            lbSearchByValue.Text = EnumHelper.GetEnumDescription<PropertySearchBy>(searchBy.ToString());
            if (PropertySearchBy.PROPERTY_NAME == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.PROPERTY_SEARCH_BY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else if (PropertySearchBy.PROPERTY_TYPE == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.PROPERTY_SEARCH_BY_TYPE, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else if (PropertySearchBy.PROPERTY_LOCATION == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.PROPERTY_SEARCH_BY_LOCATION, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else
            {
                drpSearchByValue.ClearSelection();
                drpSearchByValue.Visible = false;
                lbSearchByValue.Visible = false;
            }
            loadSearchGridAndReSelect(0);
            resetTabInfo(PageMode.NONE);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSearchByValue(object sender, EventArgs e)
    {
        loadSearchGridAndReSelect(0);
        resetTabInfo(PageMode.NONE);
    }
    protected void selectProperty(object sender, EventArgs e)
    {
        try
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            resetTabInfo(PageMode.NONE);
            if (rd.Checked)
            {
                string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnPropRowIdentifier"))).Attributes["row-identifier"];
                setSelectedProperty(long.Parse(strId));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void gotoTab2StepyWizard(object sender, EventArgs e)
    {
        LinkButton btn = (LinkButton)sender;
        string nextPreviousStep = btn.Attributes["data-bzstep"];
        tab2ContentBzHdn.Value = nextPreviousStep;
    }
    /*
     * This method is called on click of ADD button in datatable top bar.
     */
    protected void onClickAddPropertyBtn(object sender, EventArgs e)
    {
        try
        {
            resetTabInfo(PageMode.ADD);
            fetchSelectedProperty();
            populateUIFieldsFromDTO(null);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickViewPropertyBtn(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertySelected())
            {
                doViewModifyAction(PageMode.VIEW);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickModifyPropertyBtn(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertySelected())
            {
                doViewModifyAction(PageMode.MODIFY);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void deleteProperty(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertySelected())
            {
                long Id = ((List<PropertyDTO>)ViewState[VS_PROPERTY_LIST]).Find(c => c.isUISelected).Id;
                propertyBO.deleteProperty(Id);
                loadSearchGridAndReSelect(0);
                resetTabInfo(PageMode.NONE);
                setSuccessMessage(string.Format(Resources.Messages.success_record_delete, "Property"), tab1Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void addOrModifyProperty(object sender, EventArgs e)
    {
        try
        {
            PropertyDTO propertyDTO = getCurrentProperty();
            long Id = propertyDTO.Id;
            populatePropertyDTOFromUI(propertyDTO);
            if (PageMode.ADD.ToString().Equals(pageModeHdn.Value))
            {
                Id = propertyBO.saveProperty(propertyDTO);
                setSuccessMessage(string.Format(Resources.Messages.success_record_add, "Property"), tab2Anchor.ID);
            }
            else if (PageMode.MODIFY.ToString().Equals(pageModeHdn.Value))
            {
                propertyBO.updateProperty(propertyDTO);
                setSuccessMessage(string.Format(Resources.Messages.success_record_update, "Property"), tab2Anchor.ID);
            }
            loadSearchGridAndReSelect(Id);
            doViewModifyAction(PageMode.VIEW);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    
    protected void cancelProperty(object sender, EventArgs e)
    {
        PropertyDTO propertyDTO = getCurrentProperty();
        resetTabInfo(PageMode.NONE);
        loadSearchGridAndReSelect(propertyDTO.Id);
    }
    
    private PropertyDTO populatepropertyDTOAdd()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        PropertyDTO propertyDTO = new PropertyDTO();
        propertyDTO.ContactInfo = new ContactInfoDTO();
        propertyDTO.ContactInfo.Addresses = new HashSet<AddressDTO>();
        propertyDTO.ContactInfo.Addresses.Add(new AddressDTO());
        propertyDTO.PropertyTowers = new HashSet<PropertyTowerDTO>();
        propertyDTO.PropertyAmenities = new HashSet<PropertyAmenityDTO>();
        propertyDTO.FirmNumber = userDefDto.FirmNumber;
        propertyDTO.InsertUser = userDefDto.Username;
        return propertyDTO;
    }
    private void populatePropertyDTOFromUI(PropertyDTO propertyDTO)
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        propertyDTO.Name = txtPropertyName.Text;
        propertyDTO.PropertyType = CommonUIConverter.getMasterControlDTO(drpPropertytype.Text, null);
        propertyDTO.PropertyLocation = CommonUIConverter.getMasterControlDTO(drpPropertyLocation.Text, null);
        propertyDTO.PropertyArea = CommonUtil.getDecimalWithoutExt(txtPropertyArea.Text);
        propertyDTO.EstimatedAmt = CommonUtil.getDecimalWithoutExt(txtTotalEstimation.Text);
        propertyDTO.FirmAccount = CommonUIConverter.getFirmAccountDTO(drpAccount.Text, null);
        AddressDTO addressDto = propertyDTO.ContactInfo.Addresses.First();
        addressDto.AddressLine1 = txtAddressLine1.Text;
        addressDto.AddressLine2 = txtAddressLine2.Text;
        addressDto.Town = txtTown.Text;
        addressDto.City = CommonUIConverter.getCityDTO(drpAddressCity.Text, null);
        addressDto.State = CommonUIConverter.getStateDTO(drpAddressState.Text, null);
        addressDto.Country = CommonUIConverter.getCountryDTO(drpAddressCountry.Text, null);
        addressDto.Pin = txtPin.Text;
        addressDto.PreferredAddress = PreferredAddress.Yes;
        propertyDTO.UpdateUser = userDefDto.Username;
    }
    private void populateUIFieldsFromDTO(PropertyDTO propertyDTO)
    {
        if (propertyDTO != null) txtPropertyName.Text = propertyDTO.Name; else txtPropertyName.Text = null;
        if (propertyDTO != null && propertyDTO.PropertyType != null) drpPropertytype.Text = propertyDTO.PropertyType.Id.ToString(); else drpPropertytype.ClearSelection();
        if (propertyDTO != null && propertyDTO.PropertyLocation != null) drpPropertyLocation.Text = propertyDTO.PropertyLocation.Id.ToString(); else drpPropertyLocation.ClearSelection();
        if (propertyDTO != null && propertyDTO.PropertyArea != null) txtPropertyArea.Text = propertyDTO.PropertyArea.ToString(); else txtPropertyArea.Text = null;
        if (propertyDTO != null && propertyDTO.EstimatedAmt != null) txtTotalEstimation.Text = propertyDTO.EstimatedAmt.ToString(); else txtTotalEstimation.Text = null;
        if (propertyDTO != null && propertyDTO.FirmAccount != null) drpAccount.Text = propertyDTO.FirmAccount.Id.ToString(); else drpAccount.ClearSelection();
        if (propertyDTO != null)
        {
            ISet<AddressDTO> addresses = propertyDTO.ContactInfo.Addresses;
            if (addresses.Count > 0)
            {
                foreach (AddressDTO addressDto in addresses)
                {
                    txtAddressLine1.Text = addressDto.AddressLine1;
                    txtAddressLine2.Text = addressDto.AddressLine2;
                    txtTown.Text = addressDto.Town;
                    drpAddressCountry.Text = addressDto.Country.Id.ToString();
                    drpAddressState.Text = addressDto.State.Id.ToString();
                    initCityDrp(drpAddressCity, drpAddressState.Text);
                    drpAddressCity.Text = addressDto.City.Id.ToString();
                    txtPin.Text = addressDto.Pin;
                }
            }
        }
        populatePropertyTowerGrid(propertyDTO);
        populateAmenityGrid(propertyDTO);
    }
    private void populatePropertyTowerGrid(PropertyDTO propertyDTO)
    {
        propertyTowerGrid.DataSource = new List<PropertyTowerDTO>();
        if (propertyDTO != null)
        {
            assignUiIndexToPropertyTower(propertyDTO.PropertyTowers);
            propertyTowerGrid.DataSource = propertyDTO.PropertyTowers;
        }
        propertyTowerGrid.DataBind();
    }
    private void assignUiIndexToPropertyTower(ISet<PropertyTowerDTO> propertyTowerDtos)
    {
        if (propertyTowerDtos != null && propertyTowerDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (PropertyTowerDTO propertyTower in propertyTowerDtos)
            {
                propertyTower.UiIndex = uiIndex++;
                propertyTower.RowInfo = CommonUIConverter.getGridViewRowInfo(propertyTower);
            }
        }
    }
    private void populateAmenityGrid(PropertyDTO propertyDTO)
    {
        amenityGrid.DataSource = new List<PropertyAmenityDTO>();
        if (propertyDTO != null)
        {
            assignUiIndexToAmenity(propertyDTO.PropertyAmenities);
            amenityGrid.DataSource = propertyDTO.PropertyAmenities;
        }
        amenityGrid.DataBind();
    }
    private void assignUiIndexToAmenity(ISet<PropertyAmenityDTO> amenityDtos)
    {
        if (amenityDtos != null && amenityDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (PropertyAmenityDTO amenityDto in amenityDtos)
            {
                amenityDto.UiIndex = uiIndex++;
                amenityDto.RowInfo = CommonUIConverter.getGridViewRowInfo(amenityDto);
            }
        }
    }
    private void populateTaxDetailGrid(PropertyDTO propertyDTO)
    {
        taxDetailGrid.DataSource = new List<PropertyTaxDetailDTO>();
        if (propertyDTO != null)
        {
            assignUiIndexToTaxDetail(propertyDTO.PropertyTaxDetails);
            amenityGrid.DataSource = propertyDTO.PropertyTaxDetails;
        }
        amenityGrid.DataBind();
    }
    private void assignUiIndexToTaxDetail(ISet<PropertyTaxDetailDTO> taxDetailDtos)
    {
        if (taxDetailDtos != null && taxDetailDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (PropertyTaxDetailDTO taxDetailDto in taxDetailDtos)
            {
                taxDetailDto.UiIndex = uiIndex++;
                taxDetailDto.RowInfo = CommonUIConverter.getGridViewRowInfo(taxDetailDto);
            }
        }
    }

    //Modal save logic
    protected void saveModalData(object sender, EventArgs e)
    {
        String errorMsg = "";
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        if (modalHdnType.Value == "PROPERTY_TYPE")
        {
            MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PROPERTY_TYPE, modalInput1.Text,
                   modalInput2.Text, userDefDto);
            errorMsg = validateMasterDataModalInput(masterDataDto, "Property Type");
            if (string.IsNullOrWhiteSpace(errorMsg))
            {
                masterDataBO.saveMasterData(masterDataDto);
                drpBO.drpDataBase(drpPropertyLocation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                modalIdentifierHdn.Value = "";
            }
        }
        else if (modalHdnType.Value == "PROPERTY_LOCATION")
        {
            MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PROPERTY_LOCATION, modalInput1.Text,
                   modalInput2.Text, userDefDto);
            errorMsg = validateMasterDataModalInput(masterDataDto, "Property Location");
            if (string.IsNullOrWhiteSpace(errorMsg))
            {
                masterDataBO.saveMasterData(masterDataDto);
                drpBO.drpDataBase(drpPropertyLocation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_LOCATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                modalIdentifierHdn.Value = "";
            }
        }

        if (!string.IsNullOrWhiteSpace(errorMsg))
        {
            modalErrorMsg.Value = errorMsg;
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "setModalErrorMsg", "setModalErrorMsg()", true);
        }
        else
        {
            //Reset the modal fields
            modalInput1.Text = "";
            modalInput2.Text = "";
            modalHdnType.Value = "";
            modalActionHdn.Value = "";
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "closeDialogClient", "closeDialogClient()", true);
        }
    }
    private string validateDepartmentModalInput(DepartmentDTO departmentDto)
    {
        string errorMsg = "";
        if (string.IsNullOrWhiteSpace(departmentDto.Name))
        {
            errorMsg = Resources.Messages.validation_departmentname_required;
        }
        else if (departmentBO.isAlreadyExist(departmentDto))
        {
            errorMsg = string.Format(Resources.Messages.validation_same_name_exist, "Department");
        }
        return errorMsg;
    }
    private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
    {
        string errorMsg = "";
        if (string.IsNullOrWhiteSpace(masterDataDto.Name))
        {
            errorMsg = Resources.Messages.validation_designationname_required;
        }
        else if (masterDataBO.isAlreadyExist(masterDataDto))
        {
            errorMsg = string.Format(Resources.Messages.validation_same_name_exist, type);
        }
        return errorMsg;
    }
    //PropertyTower Table actions - Start
    private void initPropertyTowerAddUpdateSection(bool isAdd)
    {
        lbPropTowerAddUpdateSectionHeader.Text = (isAdd) ? Resources.Labels.label_sectionheader_propertytower : Resources.Labels.label_sectionheader_modify_address;
        pnlPropertyTowerAdd.Visible = true;
        btnPropertyTowerAddToGrid.Visible = isAdd;
        btnPropertyTowerUpdateToGrid.Visible = !isAdd;
    }
    private void setDefaultOnAddPropertyTower()
    {
        
    }
    private void initPropertyTowerSectionFields(PropertyTowerDTO propertyTowerDto)
    {
        if (propertyTowerDto != null) txtTowerName.Text = propertyTowerDto.Name; else txtTowerName.Text = null;
        if (propertyTowerDto != null) txtTowerLaunchDate.Text = CommonUtil.getCSDate(propertyTowerDto.LaunchDate);
        if (propertyTowerDto != null && propertyTowerDto.Rate != null) txtTowerRate.Text = propertyTowerDto.Rate.ToString(); else txtTowerRate.Text = null;
        if (propertyTowerDto != null) txtTowerDescription.Text = propertyTowerDto.Description; else txtTowerDescription.Text = null;
        if (propertyTowerDto != null) txtTowerPossession.Text = CommonUtil.getCSDate(propertyTowerDto.Possession);
    }
    private void clearPropertyTowerViewState()
    {
        if (propertyTowerGrid.Rows.Count > 0)
        {
            foreach (GridViewRow row in propertyTowerGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdPropertyTowerSelect");
                if (radioBtn != null) radioBtn.Checked = false;
            }
        }
        getCurrentProperty().PropertyTowers.ToList<PropertyTowerDTO>().ForEach(c => c.isUISelected = false);
    }
    private PropertyTowerDTO getSelectedPropertyTower()
    {
        return getCurrentProperty().PropertyTowers.ToList<PropertyTowerDTO>().Find(c => c.isUISelected);
    }
    private void initCityDrp(DropDownList drp, string stateId)
    {
        drpBO.drpDataBase(drp, DrpDataType.CITY, stateId, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
    }
    private bool validatePropertyTowerSelected()
    {
        bool isSelected = true;
        PropertyTowerDTO propertyTowerDto = getSelectedPropertyTower();
        if (propertyTowerDto == null)
        {
            isSelected = false;
            pnlPropertyTowerAdd.Visible = false;
            clearPropertyTowerViewState();
            setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Property Tower"), tab2ValidationGrp);
        }
        return isSelected;
    }

    private void populatePropertyTowerFromUI(PropertyTowerDTO propertyTowerDto)
    {
        propertyTowerDto.Name = txtTowerName.Text;
        propertyTowerDto.LaunchDate = CommonUtil.getCSDate(txtTowerLaunchDate.Text);
        propertyTowerDto.Rate = CommonUtil.getDecimalWithoutExt(txtTowerRate.Text);
        propertyTowerDto.Possession = CommonUtil.getCSDate(txtTowerPossession.Text);
        propertyTowerDto.Description = txtTowerDescription.Text;
    }
    protected void loadCities(object sender, EventArgs e)
    {
        initCityDrp(drpAddressCity, drpAddressState.Text);
        SetFocus(drpAddressCity);
    }
    protected void selectPropertyTower(object sender, EventArgs e)
    {
        GroupRadioButton rd = (GroupRadioButton)sender;
        pnlPropertyTowerAdd.Visible = false;
        if (rd.Checked)
        {
            long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnTowerRowIdentifier"))).Attributes["row-identifier"]);
            List<PropertyTowerDTO> towerList = getCurrentProperty().PropertyTowers.ToList<PropertyTowerDTO>();
            towerList.ForEach(c => c.isUISelected = false);
            towerList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
        }
    }
    protected void onClickAddPropertyTowerBtn(object sender, EventArgs e)
    {
        try
        {
            initPropertyTowerAddUpdateSection(true);
            initPropertyTowerSectionFields(null);
            setDefaultOnAddPropertyTower();
            SetFocus(txtTowerName);
            scrollToFieldHdn.Value = pnlPropertyTowerAdd.ID;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void onClickModifyPropertyTowerBtn(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyTowerSelected())
            {
                initPropertyTowerAddUpdateSection(false);
                initPropertyTowerSectionFields(getSelectedPropertyTower());
                SetFocus(txtTowerName);
                scrollToFieldHdn.Value = pnlPropertyTowerAdd.ID;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void deletePropertyTower(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyTowerSelected())
            {
                PropertyDTO propertyDTO = getCurrentProperty();
                PropertyTowerDTO propertyTowerDto = getSelectedPropertyTower();
                propertyDTO.PropertyTowers.Remove(propertyTowerDto);
                pnlPropertyTowerAdd.Visible = false;
                clearPropertyTowerViewState();
                populatePropertyTowerGrid(propertyDTO);
                setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, "Property Tower"), tab2Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void addNewPropertyTower(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyTower())
            {
                PropertyDTO propertyDTO = getCurrentProperty();
                PropertyTowerDTO propertyTowerDto = new PropertyTowerDTO();
                populatePropertyTowerFromUI(propertyTowerDto);
                propertyDTO.PropertyTowers.Add(propertyTowerDto);
                pnlPropertyTowerAdd.Visible = false;
                clearPropertyTowerViewState();
                populatePropertyTowerGrid(propertyDTO);
                setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, "Property Tower"), tab2Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void updatePropertyTower(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyTower())
            {
                PropertyDTO propertyDTO = getCurrentProperty();
                PropertyTowerDTO propertyTowerDto = getSelectedPropertyTower();
                populatePropertyTowerFromUI(propertyTowerDto);
                pnlPropertyTowerAdd.Visible = false;
                clearPropertyTowerViewState();
                populatePropertyTowerGrid(propertyDTO);
                setSuccessMessage(string.Format(Resources.Messages.success_record_updatedtotable, "Property Tower"), tab2Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void cancelPropertyTower(object sender, EventArgs e)
    {
        pnlPropertyTowerAdd.Visible = false;
        clearPropertyTowerViewState();
    }
    private bool validatePropertyTower()
    {
        bool isValid = true;
        /*if (drpPreferredAddress.Text.Equals(PreferredAddress.Yes.ToString()))
        {
            List<PropertyTowerDTO> addressList = getCurrentProperty().PropertyTowers.ToList<PropertyTowerDTO>();
            bool isPreferred = addressList.Any(c => (c.PreferredAddress == PreferredAddress.Yes && !c.isUISelected));
            if (isPreferred)
            {
                isValid = false;
                setErrorMessage(Resources.Messages.validation_address_one_preferred, tab2ValidationGrp);
            }
        }*/
        return isValid;
    }
    //PropertyTower Table actions - END
    //Amenity Table actions - Start
    private void initAmenityAddUpdateSection(bool isAdd)
    {
        lbAmenityAddUpdateSectionHeader.Text = (isAdd) ? Resources.Labels.label_sectionheader_amenity : Resources.Labels.label_sectionheader_modify_address;
        pnlAmenityAdd.Visible = true;
        btnAmenityAddToGrid.Visible = isAdd;
        btnAmenityUpdateToGrid.Visible = !isAdd;
    }
    private void setDefaultOnAddAmenity()
    {

    }
    private void initAmenitySectionFields(PropertyAmenityDTO amenityDto)
    {
        if (amenityDto != null) txtAmenity.Text = amenityDto.Name; else txtAmenity.Text = null;
        if (amenityDto != null) txtAmenityDescription.Text = amenityDto.Description; else txtAmenityDescription.Text = null;
    }
    private void clearAmenityViewState()
    {
        if (amenityGrid.Rows.Count > 0)
        {
            foreach (GridViewRow row in amenityGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdAmenitySelect");
                if (radioBtn != null) radioBtn.Checked = false;
            }
        }
        getCurrentProperty().PropertyAmenities.ToList<PropertyAmenityDTO>().ForEach(c => c.isUISelected = false);
    }
    private PropertyAmenityDTO getSelectedAmenity()
    {
        return getCurrentProperty().PropertyAmenities.ToList<PropertyAmenityDTO>().Find(c => c.isUISelected);
    }
    private bool validateAmenitySelected()
    {
        bool isSelected = true;
        PropertyAmenityDTO amenityDto = getSelectedAmenity();
        if (amenityDto == null)
        {
            isSelected = false;
            pnlAmenityAdd.Visible = false;
            clearAmenityViewState();
            setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Amenity"), tab2ValidationGrp);
        }
        return isSelected;
    }

    private void populateAmenityFromUI(PropertyAmenityDTO amenityDto)
    {
        amenityDto.Name = txtAmenity.Text;
        amenityDto.Description = txtAmenityDescription.Text;
    }
    protected void selectAmenity(object sender, EventArgs e)
    {
        GroupRadioButton rd = (GroupRadioButton)sender;
        pnlAmenityAdd.Visible = false;
        if (rd.Checked)
        {
            long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnAmenityRowIdentifier"))).Attributes["row-identifier"]);
            List<PropertyAmenityDTO> amenityList = getCurrentProperty().PropertyAmenities.ToList<PropertyAmenityDTO>();
            amenityList.ForEach(c => c.isUISelected = false);
            amenityList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
        }
    }
    protected void onClickAddAmenityBtn(object sender, EventArgs e)
    {
        try
        {
            initAmenityAddUpdateSection(true);
            initAmenitySectionFields(null);
            setDefaultOnAddAmenity();
            SetFocus(txtTowerName);
            scrollToFieldHdn.Value = pnlAmenityAdd.ID;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void onClickModifyAmenityBtn(object sender, EventArgs e)
    {
        try
        {
            if (validateAmenitySelected())
            {
                initAmenityAddUpdateSection(false);
                initAmenitySectionFields(getSelectedAmenity());
                SetFocus(txtTowerName);
                scrollToFieldHdn.Value = pnlAmenityAdd.ID;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void deleteAmenity(object sender, EventArgs e)
    {
        try
        {
            if (validateAmenitySelected())
            {
                PropertyDTO propertyDTO = getCurrentProperty();
                PropertyAmenityDTO amenityDto = getSelectedAmenity();
                propertyDTO.PropertyAmenities.Remove(amenityDto);
                pnlAmenityAdd.Visible = false;
                clearAmenityViewState();
                populateAmenityGrid(propertyDTO);
                setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, "Amenity"), tab2Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void addNewAmenity(object sender, EventArgs e)
    {
        try
        {
            if (validateAmenity())
            {
                PropertyDTO propertyDTO = getCurrentProperty();
                PropertyAmenityDTO amenityDto = new PropertyAmenityDTO();
                populateAmenityFromUI(amenityDto);
                propertyDTO.PropertyAmenities.Add(amenityDto);
                pnlAmenityAdd.Visible = false;
                clearAmenityViewState();
                populateAmenityGrid(propertyDTO);
                setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, "Amenity"), tab2Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void updateAmenity(object sender, EventArgs e)
    {
        try
        {
            if (validateAmenity())
            {
                PropertyDTO propertyDTO = getCurrentProperty();
                PropertyAmenityDTO amenityDto = getSelectedAmenity();
                populateAmenityFromUI(amenityDto);
                pnlAmenityAdd.Visible = false;
                clearAmenityViewState();
                populateAmenityGrid(propertyDTO);
                setSuccessMessage(string.Format(Resources.Messages.success_record_updatedtotable, "Amenity"), tab2Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void cancelAmenity(object sender, EventArgs e)
    {
        pnlAmenityAdd.Visible = false;
        clearAmenityViewState();
    }
    private bool validateAmenity()
    {
        bool isValid = true;
        /*if (drpPreferredAddress.Text.Equals(PreferredAddress.Yes.ToString()))
        {
            List<AmenityDTO> addressList = getCurrentProperty().Amenitys.ToList<AmenityDTO>();
            bool isPreferred = addressList.Any(c => (c.PreferredAddress == PreferredAddress.Yes && !c.isUISelected));
            if (isPreferred)
            {
                isValid = false;
                setErrorMessage(Resources.Messages.validation_address_one_preferred, tab2ValidationGrp);
            }
        }*/
        return isValid;
    }
    //Amenity Table actions - END
    //TaxDetail Table actions - Start
    private void initTaxDetailAddUpdateSection(bool isAdd)
    {
        lbTaxDetailAddUpdateSectionHeader.Text = (isAdd) ? Resources.Labels.label_sectionheader_propertytower : Resources.Labels.label_sectionheader_modify_address;
        pnlTaxDetailAdd.Visible = true;
        btnTaxDetailAddToGrid.Visible = isAdd;
        btnTaxDetailUpdateToGrid.Visible = !isAdd;
    }
    private void setDefaultOnAddTaxDetail()
    {

    }
    private void initTaxDetailSectionFields(PropertyTaxDetailDTO taxDetailDto)
    {
        if (taxDetailDto != null) txtTaxType.Text = taxDetailDto.TaxType.Name; else txtTaxType.Text = null;
        if (taxDetailDto != null) txtTaxRate.Text = taxDetailDto.TaxPercentage.ToString(); else txtTaxRate.Text = null;
        if (taxDetailDto != null && taxDetailDto.TaxAmtLimit != null) txtTaxLimit.Text = taxDetailDto.TaxAmtLimit.ToString(); else txtTaxLimit.Text = null;
        if (taxDetailDto != null && taxDetailDto.IncludeInTotalPymt != null) drpTaxIncludeInPymt.Text = taxDetailDto.IncludeInTotalPymt.ToString(); else drpTaxIncludeInPymt.ClearSelection();
    }
    private void clearTaxDetailViewState()
    {
        if (taxDetailGrid.Rows.Count > 0)
        {
            foreach (GridViewRow row in taxDetailGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdTaxDetailSelect");
                if (radioBtn != null) radioBtn.Checked = false;
            }
        }
        getCurrentProperty().PropertyTaxDetails.ToList<PropertyTaxDetailDTO>().ForEach(c => c.isUISelected = false);
    }
    private PropertyTaxDetailDTO getSelectedTaxDetail()
    {
        return getCurrentProperty().PropertyTaxDetails.ToList<PropertyTaxDetailDTO>().Find(c => c.isUISelected);
    }
    private bool validateTaxDetailSelected()
    {
        bool isSelected = true;
        PropertyTaxDetailDTO taxDetailDto = getSelectedTaxDetail();
        if (taxDetailDto == null)
        {
            isSelected = false;
            pnlTaxDetailAdd.Visible = false;
            clearTaxDetailViewState();
            setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Tax Detail"), tab2ValidationGrp);
        }
        return isSelected;
    }

    private void populateTaxDetailFromUI(PropertyTaxDetailDTO taxDetailDto)
    {
        /*taxDetailDto.TaxType = CommonUIConverter.getMasterControlDTO(txtTowerName.Text);
        taxDetailDto.LaunchDate = CommonUtil.getCSDate(txtTowerLaunchDate.Text);
        taxDetailDto.Rate = CommonUtil.getDecimalWithoutExt(txtTowerRate.Text);
        taxDetailDto.Possession = CommonUtil.getCSDate(txtTowerPossession.Text);
        taxDetailDto.Description = txtTowerDescription.Text;*/
    }
    protected void selectTaxDetail(object sender, EventArgs e)
    {
        GroupRadioButton rd = (GroupRadioButton)sender;
        pnlTaxDetailAdd.Visible = false;
        if (rd.Checked)
        {
            long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnTaxDetailRowIdentifier"))).Attributes["row-identifier"]);
            List<PropertyTaxDetailDTO> towerList = getCurrentProperty().PropertyTaxDetails.ToList<PropertyTaxDetailDTO>();
            towerList.ForEach(c => c.isUISelected = false);
            towerList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
        }
    }
    protected void onClickAddTaxDetailBtn(object sender, EventArgs e)
    {
        try
        {
            initTaxDetailAddUpdateSection(true);
            initTaxDetailSectionFields(null);
            setDefaultOnAddTaxDetail();
            SetFocus(txtTowerName);
            scrollToFieldHdn.Value = pnlTaxDetailAdd.ID;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void onClickModifyTaxDetailBtn(object sender, EventArgs e)
    {
        try
        {
            if (validateTaxDetailSelected())
            {
                initTaxDetailAddUpdateSection(false);
                initTaxDetailSectionFields(getSelectedTaxDetail());
                SetFocus(txtTowerName);
                scrollToFieldHdn.Value = pnlTaxDetailAdd.ID;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void deleteTaxDetail(object sender, EventArgs e)
    {
        try
        {
            if (validateTaxDetailSelected())
            {
                PropertyDTO propertyDTO = getCurrentProperty();
                PropertyTaxDetailDTO taxDetailDto = getSelectedTaxDetail();
                propertyDTO.PropertyTaxDetails.Remove(taxDetailDto);
                pnlTaxDetailAdd.Visible = false;
                clearTaxDetailViewState();
                populateTaxDetailGrid(propertyDTO);
                setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, "Tax Detail"), tab2Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void addNewTaxDetail(object sender, EventArgs e)
    {
        try
        {
            if (validateTaxDetail())
            {
                PropertyDTO propertyDTO = getCurrentProperty();
                PropertyTaxDetailDTO taxDetailDto = new PropertyTaxDetailDTO();
                populateTaxDetailFromUI(taxDetailDto);
                propertyDTO.PropertyTaxDetails.Add(taxDetailDto);
                pnlTaxDetailAdd.Visible = false;
                clearTaxDetailViewState();
                populateTaxDetailGrid(propertyDTO);
                setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, "Tax Detail"), tab2Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void updateTaxDetail(object sender, EventArgs e)
    {
        try
        {
            if (validateTaxDetail())
            {
                PropertyDTO propertyDTO = getCurrentProperty();
                PropertyTaxDetailDTO taxDetailDto = getSelectedTaxDetail();
                populateTaxDetailFromUI(taxDetailDto);
                pnlTaxDetailAdd.Visible = false;
                clearTaxDetailViewState();
                populateTaxDetailGrid(propertyDTO);
                setSuccessMessage(string.Format(Resources.Messages.success_record_updatedtotable, "Tax Detail"), tab2Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void cancelTaxDetail(object sender, EventArgs e)
    {
        pnlTaxDetailAdd.Visible = false;
        clearTaxDetailViewState();
    }
    private bool validateTaxDetail()
    {
        bool isValid = true;
        /*if (drpPreferredAddress.Text.Equals(PreferredAddress.Yes.ToString()))
        {
            List<TaxDetailDTO> addressList = getCurrentProperty().TaxDetails.ToList<TaxDetailDTO>();
            bool isPreferred = addressList.Any(c => (c.PreferredAddress == PreferredAddress.Yes && !c.isUISelected));
            if (isPreferred)
            {
                isValid = false;
                setErrorMessage(Resources.Messages.validation_address_one_preferred, tab2ValidationGrp);
            }
        }*/
        return isValid;
    }
    //TaxDetail Table actions - END
}
