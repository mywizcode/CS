﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Vladsm.Web.UI.WebControls;

namespace ConstroSoft.pages.PropertyExpenses
{
    public partial class ManagePropertyExpense : System.Web.UI.Page
    {
        private static readonly log4net.ILog log =
              log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string tab1ValidationGrp = "tab1Error";
        string tab2ValidationGrp = "tab2Error";
        string VS_EXPENSES_LIST = "EXPENSES_LIST";
        string VS_SELECTED_EXPENSES = "SELECTED_EXPENSES";
        DropdownBO drpBO = new DropdownBO();
        PropertyBO propertyBO = new PropertyBO();
        MasterDataBO masterDataBO = new MasterDataBO();
        public enum PropExpensePageMode { ADD, MODIFY, VIEW, NONE }
        protected void Page_Load(object sender, EventArgs e)
        {
            Page.Form.Attributes.Add("enctype", "multipart/form-data");
            clearMessages();
            if (!IsPostBack)
            {
                if (CommonUtil.isSessionActive(Session))
                {
                    resetTabInfo(PropExpensePageMode.NONE);
                    initDropdowns();
                    loadSearchGridAndReSelect(0);
                    Page.MaintainScrollPositionOnPostBack = false;
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
        }
        private void initDropdowns()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            drpBO.drpDataBase(drpPropertySearchBy, DrpDataType.PROPERTY_NAME, userDefDto.Id.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpProperty, DrpDataType.PROPERTY_NAME, userDefDto.Id.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpEmployeeName, DrpDataType.EMPLOYEE_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpAgency, DrpDataType.AGENCY_SEARCHBY_AGENCYNAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpExpensesType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_EXPENSE_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpDocumentType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.DOCUMENT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        }
        /**
         * This method is called just before the page is rendered. So any change in state of the element is applied.
         **/
        protected void Page_PreRender(object sender, EventArgs e)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                applyEntitlement();
                preRenderInitFormElements();
                initBootstrapComponantsFromServer();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        private void applyEntitlement()
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            lnkAddPropertyExpenseBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_EXPENSE_ADD);
            lnkModifyPropertyExpenseBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_EXPENSE_MODIFY);
            lnkDeletePropertyExpenseBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_EXPENSE_DELETE);
        }
        private void preRenderInitFormElements()
        {
            PropertyExpenseDTO selectedExpenses = getCurrentExpenses();
            jumpToDocumentHdnId.Value = null;
            jumpToPropertyExpensesHdnId.Value = null;
            if (selectedExpenses != null)
            {
                jumpToDocumentHdnId.Value = selectedExpenses.Id.ToString();
                List<DocumentDTO> documentList = selectedExpenses.DocumentInfo.Documents.ToList<DocumentDTO>();
                if (documentList != null && documentList.Count > 0)
                {
                    DocumentDTO selecteddocument = documentList.Find(a => a.isUISelected);
                    if (selecteddocument != null) jumpToPropertyExpensesHdnId.Value = selecteddocument.UiIndex.ToString();
                }
            }
        }
        public void setErrorMessage(string message, string group)
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }

        public void setSuccessMessage(string msg, string tabId)
        {
            activeTabHdn.Value = tabId;
            if (tabId.Equals(tab1Anchor.ID))
            {
                lbTab1Success.Text = msg;
                tab1SuccessPanel.Visible = true;
            }
            else if (tabId.Equals(tab2Anchor.ID))
            {
                lbTab2Success.Text = msg;
                tab2SuccessPanel.Visible = true;
            }
        }
        public void initBootstrapComponantsFromServer()
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
        }
        private void clearMessages()
        {
            tab1SuccessPanel.Visible = false;
            lbTab1Success.Text = "";
            tab2SuccessPanel.Visible = false;
            lbTab2Success.Text = "";
        }
        private UserDefinitionDTO getUserDefinitionDTO()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }

        private void resetTabInfo(PropExpensePageMode pageMode)
        {
            tab2Anchor.Visible = true;
            activeTabHdn.Value = tab2Anchor.ID;

            pageModeHdn.Value = pageMode.ToString();
            initFormFields();
            pnlDocumentAdd.Visible = false;
            if (PropExpensePageMode.ADD == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.empm_sm_manage_exp_tab2_add_name;
                initFormFields();
            }
            else if (PropExpensePageMode.MODIFY == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.empm_sm_manage_exp_tab2_update_name;
                initFormFields();
            }
            else if (PropExpensePageMode.VIEW == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.empm_sm_manage_exp_tab2_view_name;
                initFormFields();
            }
            else
            {
                activeTabHdn.Value = tab1Anchor.ID;
                tab2Anchor.Visible = false;
                ViewState[VS_SELECTED_EXPENSES] = null;
            }
        }
        private void initFormFields()
        {
            bool visible = !(PropExpensePageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            //Buttons
            btnAddSubmit.Visible = visible;
            addExpensesTypeBtn.Visible = visible;
            addDocumentTypeBtn.Visible = visible;
            addDocumentBtn.Visible = visible;
            deleteDocumentBtn.Visible = visible;
            documentGrid.Columns[0].Visible = visible;
        }
        private PropertyExpenseDTO getCurrentExpenses()
        {
            return (PropertyExpenseDTO)ViewState[VS_SELECTED_EXPENSES];
        }
        private void setSelectedExpenses(long selectedId)
        {
            List<PropertyExpenseDTO> expensesList = (List<PropertyExpenseDTO>)ViewState[VS_EXPENSES_LIST];
            if (expensesList != null)
            {
                expensesList.ForEach(c => c.isUISelected = false);
                if (selectedId > 0) expensesList.Find(c => c.Id == selectedId).isUISelected = true;
            }
        }
        private bool validateExpensesSelected()
        {
            bool isSelected = true;
            List<PropertyExpenseDTO> expensesList = (List<PropertyExpenseDTO>)ViewState[VS_EXPENSES_LIST];
            if (expensesList != null)
            {
                isSelected = expensesList.Any(c => c.isUISelected);
                if (!isSelected)
                {
                    resetTabInfo(PropExpensePageMode.NONE);
                    setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Property Expenses"), tab1ValidationGrp);
                }
            }
            return isSelected;
        }
        private void selectExpensesGridRdBtn(long Id)
        {
            if (propertyexpensesGrid.Rows.Count > 0)
            {
                setSelectedExpenses(0);
                foreach (GridViewRow row in propertyexpensesGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdPropertyExpensesSelect");
                    Button rowIdenBtn = (Button)row.FindControl("btnPropRowIdentifier");
                    if (radioBtn != null)
                    {
                        radioBtn.Checked = false;
                        if (rowIdenBtn != null && Id > 0 && Id.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                        {
                            radioBtn.Checked = true;
                            setSelectedExpenses(Id);
                        }
                    }
                }
            }
        }
        private void loadSearchGridAndReSelect(long Id)
        {
            try
            {
                long searchByValId = -1;
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                if (!string.IsNullOrWhiteSpace(drpPropertySearchBy.Text)) searchByValId = long.Parse(drpPropertySearchBy.Text);
                IList<PropertyExpenseDTO> results = propertyBO.fetchPropertyexpense(userDefDto.FirmNumber, searchByValId);
                ViewState[VS_EXPENSES_LIST] = results;
                propertyexpensesGrid.DataSource = results;
                propertyexpensesGrid.DataBind();
                if (Id > 0)
                {
                    selectExpensesGridRdBtn(Id);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        private void fetchSelectedExpenses()
        {
            try
            {
                PropertyExpenseDTO propertyexpensesDto = null;
                if (PropExpensePageMode.ADD.ToString().Equals(pageModeHdn.Value))
                {
                    propertyexpensesDto = populateExpensesDTOAdd();
                    selectExpensesGridRdBtn(0);
                    loadSearchGridAndReSelect(0);
                }
                else if (PropExpensePageMode.MODIFY.ToString().Equals(pageModeHdn.Value) || PropExpensePageMode.VIEW.ToString().Equals(pageModeHdn.Value))
                {
                    long Id = ((List<PropertyExpenseDTO>)ViewState[VS_EXPENSES_LIST]).Find(c => c.isUISelected).Id;
                    propertyexpensesDto = propertyBO.fetchPropertyExpenses(Id);
                }
                ViewState[VS_SELECTED_EXPENSES] = propertyexpensesDto;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void doViewModifyAction(PropExpensePageMode pageMode)
        {
            resetTabInfo(pageMode);
            fetchSelectedExpenses();
            populateUIFieldsFromDTO((PropertyExpenseDTO)ViewState[VS_SELECTED_EXPENSES]);
        }
        protected void onPropertySearchBy(object sender, EventArgs e)
        {
            try
            {
                loadSearchGridAndReSelect(0);
                resetTabInfo(PropExpensePageMode.NONE);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        protected void selectPropertyExpenses(object sender, EventArgs e)
        {
            try
            {
                GroupRadioButton rd = (GroupRadioButton)sender;
                resetTabInfo(PropExpensePageMode.NONE);
                if (rd.Checked)
                {
                    string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnPropRowIdentifier"))).Attributes["row-identifier"];
                    setSelectedPropertyExpense(long.Parse(strId));
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void setSelectedPropertyExpense(long selectedId)
        {
            List<PropertyExpenseDTO> propertyExpenseList = (List<PropertyExpenseDTO>)ViewState[VS_EXPENSES_LIST];
            if (propertyExpenseList != null)
            {
                propertyExpenseList.ForEach(c => c.isUISelected = false);
                if (selectedId > 0) propertyExpenseList.Find(c => c.Id == selectedId).isUISelected = true;
            }
        }
        protected void selectExpenses(object sender, EventArgs e)
        {
            try
            {
                GroupRadioButton rd = (GroupRadioButton)sender;
                resetTabInfo(PropExpensePageMode.NONE);
                if (rd.Checked)
                {
                    string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnExpRowIdentifier"))).Attributes["row-identifier"];
                    setSelectedExpenses(long.Parse(strId));
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        protected void selectExpensesDetails(object sender, EventArgs e)
        {
            try
            {
                GroupRadioButton rd = (GroupRadioButton)sender;
                resetTabInfo(PropExpensePageMode.NONE);
                if (rd.Checked)
                {
                    string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("rdExpensesDetailsSelect"))).Attributes["row-identifier"];
                    setSelectedExpenses(long.Parse(strId));
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        /*
         * This method is called on click of ADD button in datatable top bar.
         */

        protected void onClickExpensesDetailsViewBtn(object sender, EventArgs e)
        {
            try
            {
                resetTabInfo(PropExpensePageMode.VIEW);
                fetchSelectedExpenses();
                populateUIFieldsFromDTO(null);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickDownloadDocumentBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateDocumentSelected())
                {
                    DocumentDTO documentDTO = getSelectedDocument();
                    registerPostBackControl();
                    Response.Buffer = true;
                    Response.Charset = "";
                    Response.Cache.SetCacheability(HttpCacheability.NoCache);
                    Response.ContentType = documentDTO.ContentType;
                    Response.AppendHeader("Content-Disposition", "attachment; filename=" + documentDTO.FileName);
                    Response.BinaryWrite(documentDTO.Content);
                    Response.Flush();
                    //Response.End();
                    UpdatePanel1.Update();
                    initBootstrapComponantsFromServer();
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void registerPostBackControl()
        {
            ScriptManager.GetCurrent(this).RegisterPostBackControl(deleteDocumentBtn);
        }
        private bool validateDocumentSelected()
        {
            bool isSelected = true;
            DocumentDTO selectedDocument = getSelectedDocument();
            if (selectedDocument == null)
            {
                isSelected = false;
                setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Document"), tab1ValidationGrp);
            }
            return isSelected;
        }
        protected void onClickViewPropertyExpensesBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateExpensesSelected())
                {
                    resetTabInfo(PropExpensePageMode.VIEW);
                    fetchSelectedExpenses();
                    populateUIFieldsFromDTO(getCurrentExpenses());
                }

            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        protected void onClickAddPropertyExpensesBtn(object sender, EventArgs e)
        {
            try
            {
                resetTabInfo(PropExpensePageMode.ADD);
                fetchSelectedExpenses();
                populateUIFieldsFromDTO(null);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        protected void onClickModifyPropertyExpenseBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateExpensesSelected())
                {
                    resetTabInfo(PropExpensePageMode.MODIFY);
                    fetchSelectedExpenses();
                    populateUIFieldsFromDTO(getCurrentExpenses());
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);

            }
        }

        protected void deletePropertyExpense(object sender, EventArgs e)
        {
            try
            {
                if (validateExpensesSelected())
                {
                    long Id = ((List<PropertyExpenseDTO>)ViewState[VS_EXPENSES_LIST]).Find(c => c.isUISelected).Id;
                    PropertyExpenseDTO propertyexpensesDto = propertyBO.fetchPropertyExpenses(Id);
                    if (!validatePaymentTrans(propertyexpensesDto))
                    {
                        propertyBO.deletePropertyExpenses(propertyexpensesDto);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_delete, "Property Expenses"), tab1Anchor.ID);
                        loadSearchGridAndReSelect(0);
                    }
                }

            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        protected void addOrModifyExpenses(object sender, EventArgs e)
        {
            try
            {
                PropertyExpenseDTO propertyExpensesDto = getCurrentExpenses();
                long Id = propertyExpensesDto.Id;
                populateExpensesDTOFromUI(propertyExpensesDto);
                if (PropExpensePageMode.ADD.ToString().Equals(pageModeHdn.Value))
                {
                    Id = propertyBO.saveExpensesDetails(propertyExpensesDto);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_add, "Property Expenses"), tab1Anchor.ID);
                }
                else if (PropExpensePageMode.MODIFY.ToString().Equals(pageModeHdn.Value) && !validatePaymentTrans(propertyExpensesDto))
                {
                    propertyBO.updateExpensesDetails(propertyExpensesDto);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_update, "Property Expenses"), tab1Anchor.ID);
                }
                resetTabInfo(PropExpensePageMode.NONE);
                loadSearchGridAndReSelect(Id);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }

        protected void cancelPropertyExpenses(object sender, EventArgs e)
        {
            PropertyExpenseDTO propertyExpensesDto = getCurrentExpenses();
            resetTabInfo(PropExpensePageMode.NONE);
            loadSearchGridAndReSelect(propertyExpensesDto.Id);
        }
        protected void cancelPropertyExpensesDetails(object sender, EventArgs e)
        {
            PropertyExpenseDTO propertyExpensesDto = getCurrentExpenses();
            resetTabInfo(PropExpensePageMode.NONE);
            loadSearchGridAndReSelect(propertyExpensesDto.Id);
        }

        private PropertyExpenseDTO populateExpensesDTOAdd()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            PropertyExpenseDTO propertyExpensesDto = new PropertyExpenseDTO();
            propertyExpensesDto.DocumentInfo = new DocumentInfoDTO();
            propertyExpensesDto.DocumentInfo.Documents = new HashSet<DocumentDTO>();
            propertyExpensesDto.PaymentMaster = new PaymentMasterDTO();
            propertyExpensesDto.FirmNumber = userDefDto.FirmNumber;
            propertyExpensesDto.InsertUser = userDefDto.Username;
            return propertyExpensesDto;
        }
        private void populateExpensesDTOFromUI(PropertyExpenseDTO propertyExpensesDto)
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            propertyExpensesDto.Agency = CommonUIConverter.getAgencyDTO(drpAgency.Text, null);
            propertyExpensesDto.Property = CommonUIConverter.getPropertyDTO(drpProperty.Text, null);
            propertyExpensesDto.ExpenseType = CommonUIConverter.getMasterControlDTO(drpExpensesType.Text, null);
            propertyExpensesDto.Amount = CommonUtil.getDecimaNotNulllWithoutExt(txtAmount.Text);
            propertyExpensesDto.Comments = txtComments.Text;
            propertyExpensesDto.FirmMember = CommonUIConverter.getFirmMemberDTO(drpEmployeeName.Text, null);
            propertyExpensesDto.ExpenseDate = DateTime.ParseExact(txtDate.Text, Constants.DATE_FORMAT, CultureInfo.InvariantCulture);
            propertyExpensesDto.UpdateUser = userDefDto.Username;

            PaymentMasterDTO paymentMasterDto = propertyExpensesDto.PaymentMaster;
            paymentMasterDto.TotalAmt = Convert.ToDecimal(propertyExpensesDto.Amount);
            paymentMasterDto.TotalPaid = Decimal.Zero;
            paymentMasterDto.TotalPending = Convert.ToDecimal(propertyExpensesDto.Amount);
            paymentMasterDto.TotalPdcAmt = Decimal.Zero;
            paymentMasterDto.Status = PymtMasterStatus.Pending;
            paymentMasterDto.FirmNumber = userDefDto.FirmNumber;
            paymentMasterDto.InsertUser = userDefDto.Username;
            paymentMasterDto.UpdateUser = userDefDto.Username;
            propertyExpensesDto.PaymentMaster = paymentMasterDto;
        }
        private void populateUIFieldsFromDTO(PropertyExpenseDTO propertyExpensesDto)
        {
            if (propertyExpensesDto != null && propertyExpensesDto.Property != null) drpProperty.Text = propertyExpensesDto.Property.Id.ToString(); else drpProperty.ClearSelection();
            if (propertyExpensesDto != null && propertyExpensesDto.Agency != null) drpAgency.Text = propertyExpensesDto.Agency.Id.ToString(); else drpProperty.ClearSelection();
            if (propertyExpensesDto != null && propertyExpensesDto.ExpenseType != null) drpExpensesType.Text = propertyExpensesDto.ExpenseType.Id.ToString(); else drpExpensesType.ClearSelection();
            if (propertyExpensesDto != null && propertyExpensesDto.FirmMember != null) drpEmployeeName.Text = propertyExpensesDto.FirmMember.Id.ToString(); else drpEmployeeName.ClearSelection();
            if (propertyExpensesDto != null && propertyExpensesDto.ExpenseDate != null) txtDate.Text = propertyExpensesDto.ExpenseDate.ToString(Constants.DATE_FORMAT); else txtDate.Text = null;
            if (propertyExpensesDto != null) txtAmount.Text = Convert.ToDecimal(propertyExpensesDto.Amount).ToString(); else txtAmount.Text = null;
            if (propertyExpensesDto != null) txtComments.Text = propertyExpensesDto.Comments; else txtComments.Text = null;

            populateDocumentGrid(propertyExpensesDto);
        }

        private bool validatePaymentTrans(PropertyExpenseDTO propertyExpenseDTO)
        {
            bool isPaid = false;
            if (propertyExpenseDTO.PaymentMaster != null && propertyExpenseDTO.PaymentMaster.PaymentTransactions != null)
            {
                List<PaymentTransactionDTO> paymentTransList = propertyExpenseDTO.PaymentMaster.PaymentTransactions.ToList<PaymentTransactionDTO>();
                if (paymentTransList != null && paymentTransList.Count > 0)
                {
                    isPaid = true;
                    setErrorMessage(Resources.Messages.validation_payment_transaction, tab1ValidationGrp);

                }
            }
            return isPaid;
        }

        private void populateDocumentGrid(PropertyExpenseDTO propertyExpensesDto)
        {
            documentGrid.DataSource = new List<DocumentDTO>();
            if (propertyExpensesDto != null)
            {
                assignUiIndexToDocuments(propertyExpensesDto.DocumentInfo.Documents);
                documentGrid.DataSource = propertyExpensesDto.DocumentInfo.Documents;
            }
            documentGrid.DataBind();
        }
        private void assignUiIndexToDocuments(ISet<DocumentDTO> documentDtos)
        {
            if (documentDtos != null && documentDtos.Count > 0)
            {
                long uiIndex = 1;
                foreach (DocumentDTO documentDto in documentDtos)
                {
                    documentDto.UiIndex = uiIndex++;
                    documentDto.RowInfo = CommonUIConverter.getGridViewRowInfo(documentDto);
                }
            }
        }

        //Modal save logic
        protected void saveModalData(object sender, EventArgs e)
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();

            if (modalHdnType.Value == "EXPENSES_TYPE")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_EXPENSE_TYPE, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "EXPENSES_TYPE");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpExpensesType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_EXPENSE_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            else if (modalHdnType.Value == "DOCUMENTTYPE")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.DOCUMENT_TYPE, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "DOCUMENTTYPE");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpDocumentType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.DOCUMENT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }

            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                modalErrorMsg.Value = errorMsg;
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "setModalErrorMsg", "setModalErrorMsg()", true);
            }
            else
            {
                //Reset the modal fields
                modalInput1.Text = "";
                modalInput2.Text = "";
                modalHdnType.Value = "";
                modalActionHdn.Value = "";
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "closeDialogClient", "closeDialogClient()", true);
            }
        }
        private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
        {
            string errorMsg = "";
            if (string.IsNullOrWhiteSpace(masterDataDto.Name))
            {
                errorMsg = Resources.Messages.validation_designationname_required;
            }
            else if (masterDataBO.isAlreadyExist(masterDataDto))
            {
                errorMsg = string.Format(Resources.Messages.validation_same_name_exist, type);
            }
            return errorMsg;
        }
        //Document Table actions - Start
        private void initDocumentAddUpdateSection(bool isAdd)
        {
            lbDocumentAddUpdateSectionHeader.Text = (isAdd) ? Resources.Labels.label_sectionheader_document_add : Resources.Labels.label_sectionheader_document_modify;
            pnlDocumentAdd.Visible = true;
            btnDocumentAddToGrid.Visible = isAdd;
        }

        private void initDocumentInfoSectionFields(DocumentDTO documentDto)
        {
            if (documentDto != null) txtDocumentName.Text = documentDto.Name; else txtDocumentName.Text = null;
            if (documentDto != null) drpDocumentType.Text = documentDto.DocumentType.Name + ""; else drpDocumentType.ClearSelection();
            if (documentDto != null) txtDescription.Text = documentDto.Description; else txtDescription.Text = null;
        }
        private void clearDocumentViewState()
        {
            if (documentGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in documentGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdExpensesSelect");
                    if (radioBtn != null) radioBtn.Checked = false;
                }
            }
            getCurrentExpenses().DocumentInfo.Documents.ToList<DocumentDTO>().ForEach(c => c.isUISelected = false);
        }
        private DocumentDTO getSelectedDocument()
        {
            return getCurrentExpenses().DocumentInfo.Documents.ToList<DocumentDTO>().Find(c => c.isUISelected);
        }
        private void initCityDrp(DropDownList drp, string stateId)
        {
            drpBO.drpDataBase(drp, DrpDataType.CITY, stateId, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
        }

        protected void selectDocument(object sender, EventArgs e)
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            pnlDocumentAdd.Visible = false;
            if (rd.Checked)
            {
                long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnExpensesRowIdentifier"))).Attributes["row-identifier"]);
                List<DocumentDTO> documentList = getCurrentExpenses().DocumentInfo.Documents.ToList<DocumentDTO>();
                documentList.ForEach(c => c.isUISelected = false);
                documentList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
            }
        }
        protected void onClickAddDocumentBtn(object sender, EventArgs e)
        {
            try
            {
                initDocumentAddUpdateSection(true);
                initDocumentInfoSectionFields(null);
                SetFocus(txtDocumentName);
                scrollToFieldHdn.Value = pnlDocumentAdd.ID;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }

        protected void deleteDocument(object sender, EventArgs e)
        {
            try
            {
                if (validateDocumentSelected())
                {
                    PropertyExpenseDTO propertyExpenseDTO = getCurrentExpenses();
                    DocumentDTO DocumentDto = getSelectedDocument();
                    propertyExpenseDTO.DocumentInfo.Documents.Remove(DocumentDto);
                    List<DocumentDTO> documentList = getDocumentList();
                    reBindDocumentGrid(documentList, null);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, "Document"));
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void addNewDocument(object sender, EventArgs e)
        {
            try
            {
                if (validateDocument())
                {
                    DocumentDTO documentDto = populateDocumentDTOAddFromUI();
                    PropertyExpenseDTO propertyExpenseDTO = getCurrentExpenses();
                    List<DocumentDTO> documentList = new List<DocumentDTO>();
                    if (propertyExpenseDTO.DocumentInfo == null)
                    {
                        DocumentInfoDTO documentInfoDTO = new DocumentInfoDTO();
                        propertyExpenseDTO.DocumentInfo = documentInfoDTO;
                        propertyExpenseDTO.DocumentInfo.Documents = new HashSet<DocumentDTO>();
                    }
                    propertyExpenseDTO.DocumentInfo.Documents.Add(documentDto);
                    documentList = propertyExpenseDTO.DocumentInfo.Documents.ToList();
                    pnlDocumentAdd.Visible = false;
                    reBindDocumentGrid(documentList, documentDto);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, "Document"));
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        public void setSuccessMessage(string msg)
        {
            lbTab2Success.Text = msg;
            tab2SuccessPanel.Visible = true;
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        private void reBindDocumentGrid(List<DocumentDTO> documentList, DocumentDTO documentDTO)
        {
            if (documentList != null)
            {
                assignUiIndexToDocument(documentList);
                documentGrid.DataSource = documentList;
                documentGrid.DataBind();
                if (documentDTO != null) resetDocumentSelection(documentDTO.UiIndex);
            }
        }
        private void assignUiIndexToDocument(List<DocumentDTO> documentDtos)
        {
            if (documentDtos != null && documentDtos.Count > 0)
            {
                documentDtos.ForEach(c => c.isUISelected = false);
                long uiIndex = 1;
                foreach (DocumentDTO documentDto in documentDtos)
                {
                    documentDto.UiIndex = uiIndex++;
                    documentDto.RowInfo = CommonUIConverter.getGridViewRowInfo(documentDto);
                }
            }
        }
        private void resetDocumentSelection(long uiIndex)
        {
            if (documentGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in documentGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdDocumentSelect");
                    radioBtn.Checked = false;
                    if (uiIndex > 0)
                    {
                        Button rowIdenBtn = (Button)row.FindControl("btnDocumentRowIdentifier");
                        if (rowIdenBtn != null && uiIndex.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                        {
                            radioBtn.Checked = true;
                            setSelectedDocument(uiIndex);
                        }
                    }
                }
            }
            if (uiIndex <= 0) setSelectedDocument(-1);
        }
        private void setSelectedDocument(long selectedUiIndex)
        {
            List<DocumentDTO> documentList = getDocumentList();
            if (documentList != null)
            {
                documentList.ForEach(c => c.isUISelected = false);
                if (selectedUiIndex != -1) documentList.Find(c => c.UiIndex == selectedUiIndex).isUISelected = true;
            }
        }
        private List<DocumentDTO> getDocumentList()
        {
            List<DocumentDTO> documentList = new List<DocumentDTO>();
            PropertyExpenseDTO propertyExpenseDTO = getCurrentExpenses();
            documentList = propertyExpenseDTO.DocumentInfo.Documents.ToList();
            return documentList;
        }
        private bool validateDocument()
        {
            bool isValid = true;
            Page.Validate(tab2ValidationGrp);
            isValid = Page.IsValid;
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        protected void onSelectDocument(object sender, EventArgs e)
        {
            try
            {
                GroupRadioButton rd = (GroupRadioButton)sender;
                pnlDocumentAdd.Visible = false;
                if (rd.Checked)
                {
                    long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnDocumentRowIdentifier"))).Attributes["row-identifier"]);
                    setSelectedDocument(UiIndex);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        private DocumentDTO populateDocumentDTOAddFromUI()
        {
            UserDefinitionDTO userDef = getUserDefinitionDTO();
            DocumentDTO documentDTO = new DocumentDTO();
            documentDTO.Name = txtDocumentName.Text;
            documentDTO.DocumentType = CommonUIConverter.getMasterControlDTO(drpDocumentType.Text, drpDocumentType.SelectedItem.Text);
            HttpFileCollection uploadedFiles = Request.Files;
            for (int i = 0; i < uploadedFiles.Count; i++)
            {
                HttpPostedFile userPostedFile = uploadedFiles[i];
                if (userPostedFile.ContentLength > 0)
                {
                    string filename = Path.GetFileName(userPostedFile.FileName);
                    string extension = Path.GetExtension(filename);
                    string contentType = fileUpload.PostedFile.ContentType;
                    HttpPostedFile file = fileUpload.PostedFile;
                    byte[] document = new byte[file.ContentLength];
                    file.InputStream.Read(document, 0, file.ContentLength);
                    documentDTO.Content = document;
                    documentDTO.FileName = filename;
                    documentDTO.Extension = extension;
                    documentDTO.ContentType = contentType;
                }
            }
            documentDTO.Description = txtDescription.Text;
            documentDTO.FirmNumber = userDef.FirmNumber;
            documentDTO.InsertUser = userDef.Username;
            documentDTO.UpdateUser = userDef.Username;
            documentDTO.InsertDate = DateTime.Now;
            documentDTO.UpdateDate = DateTime.Now;
            return documentDTO;
        }
        protected void cancelDocument(object sender, EventArgs e)
        {
            pnlDocumentAdd.Visible = false;
            clearDocumentViewState();
        }

    }
}