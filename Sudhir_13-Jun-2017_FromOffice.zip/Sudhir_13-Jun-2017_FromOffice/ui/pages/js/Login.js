$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    formatFields();
    $('input.submitForm').on('keypress', function (e) {
        if (e.which == 10 || e.which == 13) {
            if (document.getElementById("ContentPlaceHolder1_btnLogin") != null) {
                document.getElementById("ContentPlaceHolder1_btnLogin").click();
            } else if (document.getElementById("ContentPlaceHolder1_btnFPUsernameSubmit") != null) {
                document.getElementById("ContentPlaceHolder1_btnFPUsernameSubmit").click();
            } else if (document.getElementById("ContentPlaceHolder1_btnFPSecQuesitonSubmit") != null) {
                document.getElementById("ContentPlaceHolder1_btnFPSecQuesitonSubmit").click();
            } else if (document.getElementById("ContentPlaceHolder1_btnResetPwdSubmit") != null) {
                document.getElementById("ContentPlaceHolder1_btnResetPwdSubmit").click();
            }
        }
    });
    initNotification();
}
function initNotification() {
    $('.noty-runner').click(function () {
        var self = $(this);
        noty({
            width: 200,
            text: self.data('message'),
            type: self.data('type'),
            dismissQueue: true,
            timeout: 6000,
            layout: self.data('layout')
        });
        return false;
    });
    if ($('.successMessage').attr('data-message') != "") {
        $('.successMessage').click();
    }
    if ($('.errorMessage').attr('data-message') != "") {
        $('.errorMessage').click();
    }
    $('.successMessage').attr('data-message', '');
    $('.errorMessage').attr('data-message', '');
}
