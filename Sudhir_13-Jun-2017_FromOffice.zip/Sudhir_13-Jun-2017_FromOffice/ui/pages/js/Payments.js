$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initPymtSearchGrid();
    initPymtHistoryGrid();
    initPendingPymtGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    //This script will enable tabs which was last active even after postback call.
    enableTab(false);
    makeReadOnlySection("pnlPaymentInfo");
}

function initPymtHistoryGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'PYMT_HISTORY_READONLY');
    var dtOptions = {
        tableId: "pymtHistoryGrid",
        pageLength: 10,
        isViewOnly: isViewOnly,
        responsiveModalTitle: "Transaction Details",
        customBtnGrpId: "#pymtHistoryGridBtnGrp",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPymtHistoryHdnId");
}
function initPendingPymtGrid() {
    var dtOptions = {
        tableId: "pendingPymtGrid",
        pageLength: 5,
        isViewOnly: true,
        responsiveModalTitle: "Pending Transaction Details",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
}

function initPymtSearchGrid() {
    var pymtDirection = $("[id$='pymtDirectionHdn']").val();
    if (pymtDirection) {
        if ("CUSTOMER_FIRM" == pymtDirection || "FIRM_CUSTOMER" == pymtDirection) {
            var dtOptions = {
                tableId: "custToFromBuilderPymtGrid",
                pageLength: 10,
                isViewOnly: false,
                customBtnGrpId: "#pymtMatserSearchBtnDiv",
                hideSearch: false
            };
            var dtTable = applyDataTable(dtOptions);
            jumpToTablePage(dtTable, "jumpToCustToFromBuilderHdnId");
        } else if ("FIRM_AGENCY" == pymtDirection) {
            var dtOptions = {
                tableId: "firmToAgencyPymtGrid",
                pageLength: 10,
                isViewOnly: false,
                customBtnGrpId: "#pymtMatserSearchBtnDiv",
                hideSearch: false
            };
            var dtTable = applyDataTable(dtOptions);
            jumpToTablePage(dtTable, "jumpToFirmToAgencyHdnId");
        }
    }
}