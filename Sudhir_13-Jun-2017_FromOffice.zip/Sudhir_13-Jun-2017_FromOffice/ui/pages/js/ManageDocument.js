$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initDocumentGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("tab1Content");
    //This script will enable tabs which was last active even after postback call.
    enableTab(true);
}

function initDocumentGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "documentGrid",
        isViewOnly: isViewOnly,
        pageLength: 5,
        responsiveModalTitle: "Document Details",
        customBtnGrpId: "#documentGridBtnDiv",
        hasRowInfo: true,
        hideSearch: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToDocumentHdnId");
}