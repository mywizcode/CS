﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initEnquiryGrid();
    initAddressGrid();
    initFollowUpGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    makeReadOnlySection("pnlEnquiryInfo");
    if ($("[id$='followupModifyHdn']").val() == "true") makeReadOnlySection("divFollowUpAddFirstSection");
    initViewMode("tab2Content");
    enableTab(true);
    //This script will enable tabs which was last active even after postback call.
    if ($("[id$='activeTabHdn']").val() != "") {
        $('a[id$="' + $("[id$='activeTabHdn']").val() + '"]').tab('show');
    }
    $('.modal-backdrop').remove();
    if ($("[id$='showBookUnitModalHdnBtn']").val() == "true") {
        $('.bookUnitModal').click();
        $("[id$='showBookUnitModalHdnBtn']").val('false');
    }
}
function initFollowUpGrid() {
    var isViewOnly = ($("[id$='followupReadonlyHdn']").val() == "true");
    var dtOptions = {
        tableId: "followUpGrid",
        pageLength: 5,
        isViewOnly: isViewOnly,
        responsiveModalTitle: "Follow-Up Details",
        customBtnGrpId: "#followUpHistoryGridBtnGrp",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToFollowUpHdnId");
}
function initAddressGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "addressGrid",
        pageLength: 5,
        isViewOnly: isViewOnly,
        responsiveModalTitle: "Address Details",
        customBtnGrpId: "#addressGridBtnGrp",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToAddressHdnId");
}

function initEnquiryGrid() {
    var dtOptions = {
        tableId: "enquiryGrid",
        pageLength: 10,
        isViewOnly: false,
        customBtnGrpId: "#enqSearchBtnDiv",
        hideSearch: false
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToEnquiryHdnId");
}