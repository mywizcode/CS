﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Web;
using OfficeOpenXml;
using System.Xml.Serialization;
using System.Xml;
using System.IO;

namespace ConstroSoft.Logic.Util
{
    public static class ObjectToXMLConverter
    {
        private static readonly log4net.ILog log =
             log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public static string Serialize<T>(T dataToSerialize)
        {
            try
            {
                var emptyNamepsaces = new XmlSerializerNamespaces(new[] { XmlQualifiedName.Empty });
                var serializer = new XmlSerializer(dataToSerialize.GetType());
                var settings = new XmlWriterSettings();
                settings.Indent = true;
                settings.OmitXmlDeclaration = true;

                using (var stream = new StringWriter())
                using (var writer = XmlWriter.Create(stream, settings))
                {
                    serializer.Serialize(writer, dataToSerialize, emptyNamepsaces);
                    return stream.ToString();
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                throw exp;
            }
        }
        public static ENVELOPE populateLedgerFromAgency(AgencyDTO agencyDto)
        {
            ENVELOPE envelop = new ENVELOPE();
            HEADER header = new HEADER();
            header.VERSION = "1";
            header.TALLYREQUEST = "Import";
            header.TYPE = "Data";
            header.ID = "All Masters";
            envelop.HEADER = header;

            BODY body = new BODY();
            DATA data = new DATA();
            DESC desc = new DESC();
            body.DESC = desc;
            TALLYMESSAGE tallyMessage = new TALLYMESSAGE();
            LEDGER ledgerMaster = new LEDGER();


            //ledgerMaster.NAME = "Rainbow Advertisement";
            ledgerMaster.NAME = agencyDto.AgencyName;
            ledgerMaster.Action = "Create";

            AddressDTO addressDto = agencyDto.ContactInfo.Addresses.First<AddressDTO>();
            ADDRESS address = new ADDRESS();
            address.ADDRESSES = new List<string>();
            //address1.ADDRESSES.Add("Near Shivar Chowk");
            //address1.ADDRESSES.Add("Rahatani");
            //address1.ADDRESSES.Add("Pune");
            address.ADDRESSES.Add(addressDto.AddressLine1);
            address.ADDRESSES.Add(addressDto.AddressLine2 + " " + addressDto.Town);
            address.ADDRESSES.Add(addressDto.City.Name);
            ledgerMaster.ADDRESS = address;

            MAILINGNAME mailingName = new MAILINGNAME();
            //mailingName.MAILINGNAMES = "Rainbow Advertisement";
            mailingName.MAILINGNAMES = agencyDto.AgencyName;
            ledgerMaster.MAILINGNAME = new List<MAILINGNAME>();
            ledgerMaster.MAILINGNAME.Add(mailingName);
            //ledgerMaster.LNAME = "Rainbow Advertisement";
            ledgerMaster.LNAME = agencyDto.AgencyName;
            //ledgerMaster.PARENT = "Sundry Creditors";
            ledgerMaster.PARENT = agencyDto.Groupname;
            ledgerMaster.OPENINGBALANCE = "0.00";
            //ledgerMaster.EMAIL = "sachin.k@gmail.com";
            ledgerMaster.EMAIL = agencyDto.ContactInfo.Email;
            //ledgerMaster.STATENAME = "Maharashtra";
            ledgerMaster.STATENAME = addressDto.State.Name;
            //ledgerMaster.PINCODE = "400093";
            ledgerMaster.PINCODE = addressDto.Pin;
            //ledgerMaster.INCOMETAXNUMBER = "RSKHM2824K";
            ledgerMaster.INCOMETAXNUMBER = agencyDto.Pan;
            //ledgerMaster.SALESTAXNUMBER = "SALRSKHM282";
            ledgerMaster.SALESTAXNUMBER = agencyDto.Salestaxnumber;
            //ledgerMaster.INTERSTATESTNUMBER = "ITKHM2824K";
            ledgerMaster.INTERSTATESTNUMBER = agencyDto.Centralsalestaxnumber;
            //ledgerMaster.TAXTYPE = "Others";
            ledgerMaster.TAXTYPE = agencyDto.Taxtype;
            //ledgerMaster.EMAILCC = "sachin.k@gmail.com";
            ledgerMaster.EMAILCC = agencyDto.ContactInfo.AltEmail;
            //ledgerMaster.LEDGERPHONE = "022-40864086";
            ledgerMaster.LEDGERPHONE = agencyDto.ContactInfo.Contact;
            //ledgerMaster.LEDGERCONTACT = "Mr. Sachin Kudale";
            ledgerMaster.LEDGERCONTACT = agencyDto.OwnerName;
            //ledgerMaster.LEDGERMOBILE = "+9619896234";
            ledgerMaster.LEDGERMOBILE = agencyDto.ContactInfo.AltContact;
            //ledgerMaster.ISBILLWISEON = "Yes";
            ledgerMaster.ISBILLWISEON = agencyDto.Billwise;
            tallyMessage.LEDGER = ledgerMaster;
            data.TALLYMESSAGE = tallyMessage;
            body.DATA = data;
            envelop.BODY = body;
            return envelop;
        }

        public static ENVELOPE populateLedgerFromCustomer(CustomerDTO customerDto)
        {
            ENVELOPE envelop = new ENVELOPE();
            HEADER header = new HEADER();
            header.VERSION = "1";
            header.TALLYREQUEST = "Import";
            header.TYPE = "Data";
            header.ID = "All Masters";
            envelop.HEADER = header;

            BODY body = new BODY();
            DATA data = new DATA();
            DESC desc = new DESC();
            body.DESC = desc;
            TALLYMESSAGE tallyMessage = new TALLYMESSAGE();
            LEDGER ledgerMaster = new LEDGER();


            //ledgerMaster.NAME = "Rainbow Advertisement";
            string customerName = customerDto.Salutation.Name + " " + customerDto.FirstName + " " + customerDto.MiddleName + " " + customerDto.LastName;
            ledgerMaster.NAME = customerName;
            ledgerMaster.Action = "Create";

            AddressDTO addressDto = customerDto.ContactInfo.Addresses.First<AddressDTO>();
            ADDRESS address = new ADDRESS();
            address.ADDRESSES = new List<string>();
            //address1.ADDRESSES.Add("Near Shivar Chowk");
            //address1.ADDRESSES.Add("Rahatani");
            //address1.ADDRESSES.Add("Pune");
            address.ADDRESSES.Add(addressDto.AddressLine1);
            address.ADDRESSES.Add(addressDto.AddressLine2 + " " + addressDto.Town);
            address.ADDRESSES.Add(addressDto.City.Name);
            ledgerMaster.ADDRESS = address;

            MAILINGNAME mailingName = new MAILINGNAME();
            //mailingName.MAILINGNAMES = "Rainbow Advertisement";
            mailingName.MAILINGNAMES = customerName;
            ledgerMaster.MAILINGNAME = new List<MAILINGNAME>();
            ledgerMaster.MAILINGNAME.Add(mailingName);
            //ledgerMaster.LNAME = "Rainbow Advertisement";
            ledgerMaster.LNAME = customerName;
            //ledgerMaster.PARENT = "Sundry Creditors";
            ledgerMaster.PARENT = customerDto.Groupname;
            ledgerMaster.OPENINGBALANCE = "0.00";
            //ledgerMaster.EMAIL = "sachin.k@gmail.com";
            ledgerMaster.EMAIL = customerDto.ContactInfo.Email;
            //ledgerMaster.STATENAME = "Maharashtra";
            ledgerMaster.STATENAME = addressDto.State.Name;
            //ledgerMaster.PINCODE = "400093";
            ledgerMaster.PINCODE = addressDto.Pin;
            //ledgerMaster.INCOMETAXNUMBER = "RSKHM2824K";
            ledgerMaster.INCOMETAXNUMBER = customerDto.Pan;
            //ledgerMaster.SALESTAXNUMBER = "SALRSKHM282";
            //ledgerMaster.SALESTAXNUMBER = agencyDto.Salestaxnumber;
            //ledgerMaster.INTERSTATESTNUMBER = "ITKHM2824K";
            //ledgerMaster.INTERSTATESTNUMBER = agencyDto.Centralsalestaxnumber;
            //ledgerMaster.TAXTYPE = "Others";
            ledgerMaster.TAXTYPE = customerDto.Taxtype;
            //ledgerMaster.EMAILCC = "sachin.k@gmail.com";
            ledgerMaster.EMAILCC = customerDto.ContactInfo.AltEmail;
            //ledgerMaster.LEDGERPHONE = "022-40864086";
            ledgerMaster.LEDGERPHONE = customerDto.ContactInfo.Contact;
            //ledgerMaster.LEDGERCONTACT = "Mr. Sachin Kudale";
            ledgerMaster.LEDGERCONTACT = customerName;
            //ledgerMaster.LEDGERMOBILE = "+9619896234";
            ledgerMaster.LEDGERMOBILE = customerDto.ContactInfo.AltContact;
            //ledgerMaster.ISBILLWISEON = "Yes";
            ledgerMaster.ISBILLWISEON = customerDto.Billwise;
            tallyMessage.LEDGER = ledgerMaster;
            data.TALLYMESSAGE = tallyMessage;
            body.DATA = data;
            envelop.BODY = body;
            return envelop;
        }
        public static VENVELOPE populateVoucher(PaymentVoucher paymentVoucher)
        {
            VENVELOPE envelop = new VENVELOPE();
            VHEADER header = new VHEADER();
            header.VERSION = "1";
            header.TALLYREQUEST = "Import";
            header.TYPE = "Data";
            header.ID = "Voucher";
            envelop.HEADER = header;

            VBODY body = new VBODY();
            VDATA data = new VDATA();
            DESC desc = new DESC();
            body.DESC = desc;
            VTALLYMESSAGE tallyMessage = new VTALLYMESSAGE();
            VOUCHER voucher = new VOUCHER();
            voucher.ID = paymentVoucher.Id.ToString();
            voucher.VCHTYPE = paymentVoucher.VoucherType;
            voucher.ACTION = paymentVoucher.Action;
            voucher.VCHDATE = CommonUtil.getTallyDate(paymentVoucher.VoucherDate);
            voucher.NARRATION = paymentVoucher.VoucherNaration;
            voucher.VOUCHERTYPENAME = paymentVoucher.VoucherType;
            voucher.VOUCHERNUMBER = paymentVoucher.VoucherNumber;
            voucher.PARTYLEDGERNAME = paymentVoucher.PartyLedgerName;
            voucher.CSTFORMISSUETYPE = paymentVoucher.CstFromIssueType;
            voucher.CSTFORMRECVTYPE = paymentVoucher.CstFromRecvType;
            voucher.FBTPAYMENTTYPE = paymentVoucher.FbtPaymentType;
            voucher.PERSISTEDVIEW = paymentVoucher.PersistedView;
            voucher.VCHGSTCLASS = paymentVoucher.VchgstClass;
            voucher.EFFECTIVEDATE = CommonUtil.getTallyDate(paymentVoucher.VoucherEffectiveDate);
            voucher.HASCASHFLOW = paymentVoucher.HasCashFlow;
            
            voucher.BILLVLEDGERENTRIES = new List<VLEDGERENTRY>();
            foreach (PaymentLedger paymentLedger in paymentVoucher.PaymentLedgers){
            	VLEDGERENTRY vLedgerEntry = new VLEDGERENTRY();
            	vLedgerEntry.LEDGERNAME = paymentLedger.LedgerName;
            	vLedgerEntry.ISDEEMEDPOSITIVE = paymentLedger.IsDeemedPositive;
            	vLedgerEntry.LEDGERFROMITEM = paymentLedger.LedgerFromItem;
            	vLedgerEntry.REMOVEZEROENTRIES = paymentLedger.RemoveZeroEntries;
            	vLedgerEntry.ISPARTYLEDGER = paymentLedger.IsPartyLedger;
            	vLedgerEntry.ISLASTDEEMEDPOSITIVE = paymentLedger.IsLastDeemedPositive;
            	vLedgerEntry.AMOUNT = paymentLedger.Amount.ToString();
            	vLedgerEntry.VATEXPAMOUNT = paymentLedger.VatexpAmount.ToString();
            	if(paymentLedger.LedgerType.Equals("Bill")){
            		vLedgerEntry.BILLALLOCATIONS = new List<BILLALLOCATION>();
            		foreach(BillAllocation lbillAllocation in paymentLedger.BillAllocations)
            		{
            			BILLALLOCATION billAllocation = new BILLALLOCATION();
            			billAllocation.NAME = lbillAllocation.Name;
            			billAllocation.BILLTYPE = lbillAllocation.BillType;
            			billAllocation.TDSDEDUCTEEISSPECIALRATE = lbillAllocation.TdsDeductSpecialRate;
            			billAllocation.AMOUNT = lbillAllocation.Amount.ToString();
            			vLedgerEntry.BILLALLOCATIONS.Add(billAllocation);
            		}
            	}else if(paymentLedger.LedgerType.Equals("Bank")){
            		vLedgerEntry.BANKALLOCATIONS = new List<BANKALLOCATION>();
            		foreach(BankAllocation lbankAllocation in paymentLedger.BankAllocations)
            		{
            			BANKALLOCATION bankAllocation = new BANKALLOCATION();
            			bankAllocation.DATE = CommonUtil.getTallyDate(lbankAllocation.BDate);
            			bankAllocation.INSTRUMENTDATE = CommonUtil.getTallyDate(lbankAllocation.InstrumentDate);
            			bankAllocation.NAME = lbankAllocation.Name;
            			bankAllocation.TRANSACTIONTYPE = lbankAllocation.TransactionType;
            			bankAllocation.PAYMENTFAVOURING = lbankAllocation.PaymentFavouring;
            			bankAllocation.CHEQUECROSSCOMMENT = lbankAllocation.ChequeCrossComment;
            			bankAllocation.INSTRUMENTNUMBER = lbankAllocation.InstrumentNumber;
            			bankAllocation.STATUS = lbankAllocation.Status;
            			bankAllocation.PAYMENTMODE = lbankAllocation.PaymentMode;
            			bankAllocation.BANKPARTYNAME = lbankAllocation.BankPartyName;
            			bankAllocation.ISCONNECTEDPAYMENT = lbankAllocation.IsConnectedPayment;
            			bankAllocation.ISSPLIT = lbankAllocation.IsSplit;
            			bankAllocation.ISCONTRACTUSED = lbankAllocation.IsContractUsed;
            			bankAllocation.AMOUNT = lbankAllocation.Amount.ToString();
            			vLedgerEntry.BANKALLOCATIONS.Add(bankAllocation);
            		}
            		
            	}
            	voucher.BILLVLEDGERENTRIES.Add(vLedgerEntry);
            }
            
            tallyMessage.VOUCHER = voucher;
            data.TALLYMESSAGE = tallyMessage;
            body.DATA = data;
            envelop.VBODY = body;
            return envelop;
        }

        
    }
}