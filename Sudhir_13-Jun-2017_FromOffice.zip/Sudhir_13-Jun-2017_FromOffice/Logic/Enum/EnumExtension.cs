﻿
/// <summary>
/// Summary description for MyENUM
/// </summary>

using System;
using System.ComponentModel;
using System.Reflection;
namespace ConstroSoft
{
    public static class EnumExtention
    {
        public static string GetDescription(this Enum value)
        {
            Type type = value.GetType();
            var field = type.GetField(value.ToString());
            var customAttribute = field.GetCustomAttributes(typeof(DescriptionAttribute), false);
            return customAttribute.Length > 0 ? ((DescriptionAttribute)customAttribute[0]).Description : value.ToString();
        }
    }
}