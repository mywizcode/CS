﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Web;
using OfficeOpenXml;
using System.Xml.Serialization;
using System.Xml;
using System.IO;

namespace ConstroSoft.Logic.Util
{
    public static class ObjectToXMLConverter
    {
        private static readonly log4net.ILog log =
             log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public static string Serialize<T>(T dataToSerialize)
        {
            try
            {
                var emptyNamepsaces = new XmlSerializerNamespaces(new[] { XmlQualifiedName.Empty });
                var serializer = new XmlSerializer(dataToSerialize.GetType());
                var settings = new XmlWriterSettings();
                settings.Indent = true;
                settings.OmitXmlDeclaration = true;

                using (var stream = new StringWriter())
                using (var writer = XmlWriter.Create(stream, settings))
                {
                    serializer.Serialize(writer, dataToSerialize, emptyNamepsaces);
                    return stream.ToString();
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                throw exp;
            }
        }
    }
}