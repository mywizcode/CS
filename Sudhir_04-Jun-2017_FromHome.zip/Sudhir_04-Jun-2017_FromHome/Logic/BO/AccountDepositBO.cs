﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NHibernate;
using NHibernate.Criterion;

namespace ConstroSoft.Logic.BO
{
    public class AccountDepositBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public AccountDepositBO() { }

        public List<FirmAcntDepositeDTO> fetchAccountDepositGridData(string firmNumber, long accountId)
        {
            ISession session = null;
            List<FirmAcntDepositeDTO> firmAccountDepositList = new List<FirmAcntDepositeDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        FirmAcntDeposite facntdeposit = null;
                        FirmAccount acnt = null;
                        IList<FirmAcntDeposite> result = session.QueryOver<FirmAcntDeposite>(() => facntdeposit).JoinAlias(() => facntdeposit.FirmAccount, () => acnt)
                            .Where(() => facntdeposit.FirmNumber == firmNumber && acnt.Id == accountId).List<FirmAcntDeposite>();
                        foreach (FirmAcntDeposite firmAcntDeposite in result)
                        {
                            firmAccountDepositList.Add(DomainToDTOUtil.convertToFirmAcntDepositeDTO(firmAcntDeposite, true));
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching firm account deposit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return firmAccountDepositList;
        }

        public FirmAcntDepositeDTO fetchDeposit(long Id)
        {
            ISession session = null;
            FirmAcntDepositeDTO accountDepositDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        FirmAcntDeposite FirmAcntDepositDO = session.Get<FirmAcntDeposite>(Id);
                        accountDepositDto = DomainToDTOUtil.convertToFirmAcntDepositeDTO(FirmAcntDepositDO, true);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Account Deposit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return accountDepositDto;
        }

        public void deleteDeposit(FirmAcntDepositeDTO depositDto, AccountTransactionDTO acntTransDto)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        FirmAcntDeposite acctDeposit = DTOToDomainUtil.populateFirmAcntDepositeAddFields(depositDto);
                        acctDeposit.AccountTransaction = DTOToDomainUtil.populateAccountTransactionAddFields(acntTransDto);
                        session.Save(acctDeposit);
                        Id = acctDeposit.Id;
                        FirmAccount firmAccount = session.Get<FirmAccount>(depositDto.FirmAccount.Id);
                        decimal tmpvalue;
                        decimal result = 0.0M;
                        if (decimal.TryParse(depositDto.Amount.ToString(), out tmpvalue))
                            result = tmpvalue;
                        firmAccount.AccountBalance = Decimal.Subtract(firmAccount.AccountBalance, result);
                        session.Save(firmAccount);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Account Deposit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }

        public long saveDeposit(FirmAcntDepositeDTO depositDto, AccountTransactionDTO acntTransDto)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        FirmAcntDeposite acctDeposit = DTOToDomainUtil.populateFirmAcntDepositeAddFields(depositDto);
                        acctDeposit.AccountTransaction = DTOToDomainUtil.populateAccountTransactionAddFields(acntTransDto);
                        session.Save(acctDeposit);
                        Id = acctDeposit.Id;
                        FirmAccount firmAccount = session.Get<FirmAccount>(depositDto.FirmAccount.Id);
                        decimal tmpvalue;
                        decimal result = 0.0M;
                        if (decimal.TryParse(depositDto.Amount.ToString(), out tmpvalue))
                            result = tmpvalue;
                        firmAccount.AccountBalance = Decimal.Add(firmAccount.AccountBalance, result);
                        session.Save(firmAccount);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Account Deposit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }

    }

}