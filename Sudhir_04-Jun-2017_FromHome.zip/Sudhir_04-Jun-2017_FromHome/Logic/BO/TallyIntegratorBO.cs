﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using NHibernate;
using NHibernate.Criterion;
using NHibernate.Impl;
using NHibernate.Transform;
using ConstroSoft.Logic.Util;
using System.Net;
using System.IO;

namespace ConstroSoft.Logic.BO
{

    public class TallyIntegratorBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public TallyIntegratorBO() { }

        public TallyConfigDTO fetchTallyConfiguration(string firmNumber)
        {
            ISession session = null;
            TallyConfigDTO tallyConfigDTO = new TallyConfigDTO();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        TallyConfig tallyConfig = session.CreateCriteria<ReportConfig>().Add(
                            NHibernate.Criterion.Expression.Eq("FirmNumber", firmNumber)).List<TallyConfig>().FirstOrDefault();
                        tallyConfigDTO = DomainToDTOUtil.convertToTallyConfigDTO(tallyConfig);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching Tally configuration :", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return tallyConfigDTO;
        }
        public RENVELOPE postLedgerMaster(string firmNumber, ENVELOPE envelopLedger)
        {
            RENVELOPE renvelope = null;
            try
            {
                TallyConfigDTO tallyConfigDTO = fetchTallyConfiguration(firmNumber);
                string ledgerMasterXML = ObjectToXMLConverter.Serialize<ENVELOPE>(envelopLedger);
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create("http://" + tallyConfigDTO.Tallyhost + ":" + tallyConfigDTO.Tallyport + "");
                byte[] bytes;
                bytes = System.Text.Encoding.ASCII.GetBytes(ledgerMasterXML);
                request.ContentType = "text/xml; encoding='utf-8'";
                request.ContentLength = bytes.Length;
                request.Method = "POST";
                Stream requestStream = request.GetRequestStream();
                requestStream.Write(bytes, 0, bytes.Length);
                requestStream.Close();
                HttpWebResponse response;
                response = (HttpWebResponse)request.GetResponse();
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    Stream responseStream = response.GetResponseStream();
                    string responseStr = new StreamReader(responseStream).ReadToEnd();
                    renvelope = XMLToObjectConverter.Deserialize<RENVELOPE>(responseStr);
                }
            }
            catch (Exception e)
            {
                log.Error("Exception while connecting Tally :", e);
                throw new Exception("Unable to connect to the Tally server");
            }
            return renvelope;
        }
    }
}