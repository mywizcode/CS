﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft.Logic.BO;
using Vladsm.Web.UI.WebControls;

namespace ConstroSoft.pages.SalesManagement
{
    public partial class CancelledPropertyUnit : System.Web.UI.Page
    {
        private static readonly log4net.ILog log =
              log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        enum CancelledUnitPageMode { MODIFY, VIEW, NONE }
        string tab1ValidationGrp = "tab1Error";
        string tab2BzStep1Error = "tab2BzStep1Error";
        string tab2BzStep2Error = "tab2BzStep2Error";
        string tab2BzStep3Error = "tab2BzStep3Error";
        string tab2BzStep3Error1 = "tab2BzStep3Error1";
        string tab2BzStep1 = "bzstep1";
        string tab2BzStep2 = "bzstep2";
        string tab2BzStep3 = "bzstep3";
        string VS_PROPERTY_UNIT_LIST = "PROPERTY_UNIT_LIST";
        string VS_MASTER_PROPERTY_UNIT_LIST = "ALL_PROPERTY_UNIT_LIST";
        string VS_SELECTED_UNIT = "SELECTED_PROPERTY_UNIT";
        DropdownBO drpBO = new DropdownBO();
        PropertyBO propertyBO = new PropertyBO();
        CancelledPropertyUnitBO cancelledUnitBO = new CancelledPropertyUnitBO();
        MasterDataBO masterDataBO = new MasterDataBO();
        protected void Page_Load(object sender, EventArgs e)
        {
            clearMessages();
            if (!IsPostBack)
            {
                if (CommonUtil.isSessionActive(Session))
                {
                    resetTabInfo(CancelledUnitPageMode.NONE);
                    initDropdowns();
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
        }
        private void initDropdowns()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            drpBO.drpDataBase(drpSelectProperty, DrpDataType.PROPERTY_NAME, userDefDto.Id.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpEnum<SoldUnitSearchBy>(drpSearchBy, null);
            drpBO.drpDataBase(drpAllPaymentType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_PYMT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            List<string> removePymtTo = new List<string>();
            removePymtTo.Add(PRUnitSalePymtTo.Builder.ToString());
            drpBO.drpEnum<PRUnitSalePymtTo>(drpPaymentTo, null, removePymtTo);
        }
        /**
         * This method is called just before the page is rendered. So any change in state of the element is applied.
         **/
        protected void Page_PreRender(object sender, EventArgs e)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                applyEntitlement();
                preRenderInitFormElements();
                initBootstrapComponantsFromServer();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        private void applyEntitlement()
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            modifyCancelledUnitBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.CANCEL_UNIT_MODIFY);
        }
        private void preRenderInitFormElements()
        {
            PrUnitSaleDetailDTO selectedPrUnitSaleDetailDto = getSelectedPropertyUnit();
            PrUnitSaleDetailDTO prUnitSaleDetailDto = getCurrentCancelledUnit();
            jumpToSoldUnitsHdnId.Value = "";
            jumpToTaxDetailHdnId.Value = "";
            jumpToCMTaxDetailHdnId.Value = "";
            if (selectedPrUnitSaleDetailDto != null)
            {
                jumpToSoldUnitsHdnId.Value = selectedPrUnitSaleDetailDto.Id.ToString();
                if (prUnitSaleDetailDto != null && prUnitSaleDetailDto.uiTaxDetails != null && prUnitSaleDetailDto.uiTaxDetails.Count > 0)
                {
                    PrUnitSaleTaxDetailDTO prUnitSaleTaxDetailDto = prUnitSaleDetailDto.uiTaxDetails.Find(a => a.isUISelected);
                    if (prUnitSaleTaxDetailDto != null) jumpToTaxDetailHdnId.Value = prUnitSaleTaxDetailDto.UiIndex.ToString();
                }
                if (prUnitSaleDetailDto != null && prUnitSaleDetailDto.uiCMTaxDetails != null && prUnitSaleDetailDto.uiCMTaxDetails.Count > 0)
                {
                    PrUnitSaleTaxDetailDTO prUnitSaleTaxDetailDto = prUnitSaleDetailDto.uiCMTaxDetails.Find(a => a.isUISelected);
                    if (prUnitSaleTaxDetailDto != null) jumpToCMTaxDetailHdnId.Value = prUnitSaleTaxDetailDto.UiIndex.ToString();
                }
                if (prUnitSaleDetailDto != null && prUnitSaleDetailDto.PrUnitSalePymts != null && prUnitSaleDetailDto.PrUnitSalePymts.Count > 0)
                {
                    PrUnitSalePymtDTO prUnitSalePymtDto = prUnitSaleDetailDto.PrUnitSalePymts.ToList<PrUnitSalePymtDTO>().Find(a => a.isUISelected);
                    if (prUnitSalePymtDto != null) jumpToPaymentHdnId.Value = prUnitSalePymtDto.UiIndex.ToString();
                }
            }
            PrUnitSaleDetailDTO currentSoldUnitDto = getCurrentCancelledUnit();
            if (CancelledUnitPageMode.MODIFY.ToString().Equals(pageModeHdn.Value)) populateUnitInfoSection(currentSoldUnitDto);
            else if (CancelledUnitPageMode.VIEW.ToString().Equals(pageModeHdn.Value)) populateUIFieldsFromSaleUnitDTO(currentSoldUnitDto);
        }
        public void setErrorMessage(string message, string group)
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            if (group.Equals(tab2BzStep2Error)) tab2ContentBzHdn.Value = tab2BzStep2;
            else if (group.Equals(tab2BzStep3Error)) tab2ContentBzHdn.Value = tab2BzStep3;
        }

        public void setSuccessMessage(string msg, string tabId, string bzStep)
        {
            activeTabHdn.Value = tabId;
            if (tabId.Equals(tab1Anchor.ID))
            {
                lbTab1Success.Text = msg;
                tab1SuccessPanel.Visible = true;
            }
            else if (tabId.Equals(tab2Anchor.ID))
            {
                if (tab2BzStep1.Equals(bzStep))
                {
                    lbTab2BzStep1Success.Text = msg;
                    tab2BzStep1SuccessPanel.Visible = true;
                }
                else if (tab2BzStep2.Equals(bzStep))
                {
                    lbTab2BzStep2Success.Text = msg;
                    tab2BzStep2SuccessPanel.Visible = true;
                }
                else
                {
                    lbTab2BzStep3Success.Text = msg;
                    tab2BzStep3SuccessPanel.Visible = true;
                }
                tab2ContentBzHdn.Value = bzStep;
            }
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        public void initBootstrapComponantsFromServer()
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
        }
        private void clearMessages()
        {
            tab1SuccessPanel.Visible = false;
            lbTab1Success.Text = "";
            tab2BzStep1SuccessPanel.Visible = false;
            lbTab2BzStep1Success.Text = "";
            tab2BzStep2SuccessPanel.Visible = false;
            lbTab2BzStep2Success.Text = "";
            tab2BzStep3SuccessPanel.Visible = false;
            lbTab2BzStep3Success.Text = "";
        }
        private UserDefinitionDTO getUserDefinitionDTO()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }

        private void resetTabInfo(CancelledUnitPageMode pageMode)
        {
            pageModeHdn.Value = pageMode.ToString();
            initFormFields();
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            tab2ContentBzHdn.Value = "";
            tab2Anchor.Visible = false;
            if (CancelledUnitPageMode.MODIFY == pageMode || CancelledUnitPageMode.VIEW == pageMode)
            {
                tab2ContentBzHdn.Value = tab2BzStep1;
                activeTabHdn.Value = tab2Anchor.ID;
                tab2Anchor.Visible = true;
                initFormFields();
            } else {
                activeTabHdn.Value = tab1Anchor.ID;
                ViewState[VS_SELECTED_UNIT] = null;
            }
        }
        private void initFormFields()
        {
            bool visible = !(CancelledUnitPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            bool visibleInModify = !(CancelledUnitPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            //Buttons
            btnSubmitStep1.Visible = visible;
            btnSubmitStep2.Visible = visible;
            btnSubmitStep3.Visible = visible;
            pymtBtnGrp.Visible = visible;
            paymentGrid.Columns[0].Visible = visible;
        }
        private List<PrUnitSaleDetailDTO> getMatserCancelledUnits()
        {
            return (List<PrUnitSaleDetailDTO>)ViewState[VS_MASTER_PROPERTY_UNIT_LIST];
        }
        private List<PrUnitSaleDetailDTO> getCurrentGridCancelledUnits()
        {
            return (List<PrUnitSaleDetailDTO>)ViewState[VS_PROPERTY_UNIT_LIST];
        }
        private PrUnitSaleDetailDTO getCurrentCancelledUnit()
        {
            return (PrUnitSaleDetailDTO)ViewState[VS_SELECTED_UNIT];
        }
        private void setSelectedPropertyUnit(long selectedId)
        {
            List<PrUnitSaleDetailDTO> propertyUnitSaleList = getCurrentGridCancelledUnits();
            if (propertyUnitSaleList != null)
            {
                propertyUnitSaleList.ForEach(c => c.isUISelected = false);
                if (selectedId > 0) propertyUnitSaleList.Find(c => c.Id == selectedId).isUISelected = true;
            }
        }
        private PrUnitSaleDetailDTO getSelectedPropertyUnit()
        {
            List<PrUnitSaleDetailDTO> propertyUnitSaleList = getCurrentGridCancelledUnits();
            PrUnitSaleDetailDTO selectedSaleUnitDto = null;
            if (propertyUnitSaleList != null)
            {
                selectedSaleUnitDto = propertyUnitSaleList.Find(c => c.isUISelected);
            }
            return selectedSaleUnitDto;
        }
        private bool validatePropertyUnitSelected()
        {
            bool isSelected = true;
            List<PrUnitSaleDetailDTO> propertyUnitSaleList = getCurrentGridCancelledUnits();
            if (propertyUnitSaleList != null)
            {
                isSelected = propertyUnitSaleList.Any(c => c.isUISelected);
                if (!isSelected)
                {
                    resetTabInfo(CancelledUnitPageMode.NONE);
                    setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Property Unit"), tab1ValidationGrp);
                }
            }
            return isSelected;
        }
        private void selectPropertyUnitGridRdBtn(long Id)
        {
            if (soldUnitsGrid.Rows.Count > 0)
            {
                setSelectedPropertyUnit(0);
                foreach (GridViewRow row in soldUnitsGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdSoldUnitsSelect");
                    Button rowIdenBtn = (Button)row.FindControl("btnCancelledUnitRowIdentifier");
                    if (radioBtn != null)
                    {
                        radioBtn.Checked = false;
                        if (rowIdenBtn != null && Id > 0 && Id.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                        {
                            radioBtn.Checked = true;
                            setSelectedPropertyUnit(Id);
                        }
                    }
                }
            }
        }
        private void loadSearchGridAndReSelect(long Id)
        {
            try
            {
                List<PrUnitSaleDetailDTO> matserList = (List<PrUnitSaleDetailDTO>)getMatserCancelledUnits();
                List<PrUnitSaleDetailDTO> filterResults = new List<PrUnitSaleDetailDTO>(matserList);
                SoldUnitSearchBy searchBy = EnumHelper.ToEnum<SoldUnitSearchBy>(drpSearchBy.Text);
                if (!string.IsNullOrWhiteSpace(drpSearchByValue.Text))
                {
                    if (SoldUnitSearchBy.PROPERTY_UNIT == searchBy)
                    {
                        filterResults = matserList.FindAll(u => u.PropertyUnit.Id == long.Parse(drpSearchByValue.Text));
                    }
                    else if (SoldUnitSearchBy.UNIT_TYPE == searchBy)
                    {
                        filterResults = matserList.FindAll(u => u.PropertyUnit.UnitType.Id == long.Parse(drpSearchByValue.Text));
                    }
                    else if (SoldUnitSearchBy.CUSTOMER == searchBy)
                    {
                        filterResults = matserList.FindAll(u => u.Customer.Id == long.Parse(drpSearchByValue.Text));
                    }
                    else if (SoldUnitSearchBy.EMPLOYEE == searchBy)
                    {
                        filterResults = matserList.FindAll(u => u.FirmMember.Id == long.Parse(drpSearchByValue.Text));
                    }
                }
                ViewState[VS_PROPERTY_UNIT_LIST] = filterResults;
                soldUnitsGrid.DataSource = filterResults;
                soldUnitsGrid.DataBind();
                selectPropertyUnitGridRdBtn(Id);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                throw exp;
            }
        }
        private void fetchSoldUnits(long Id)
        {
            try
            {
                IList<PrUnitSaleDetailDTO> results = new List<PrUnitSaleDetailDTO>();
                if (!(string.IsNullOrWhiteSpace(drpSelectProperty.Text) || string.IsNullOrWhiteSpace(drpSelectPropertyTower.Text)))
                {
                    long propertyId = long.Parse(drpSelectProperty.Text);
                    long towerId = long.Parse(drpSelectPropertyTower.Text);
                    results = cancelledUnitBO.fetchCancelledPropertyUnits(getUserDefinitionDTO().FirmNumber, towerId);
                }
                ViewState[VS_MASTER_PROPERTY_UNIT_LIST] = results;
                ViewState[VS_PROPERTY_UNIT_LIST] = results;
                soldUnitsGrid.DataSource = results;
                soldUnitsGrid.DataBind();
                loadSearchGridAndReSelect(Id);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                throw exp;
            }
        }
        private void fetchSelectedPropertyUnit()
        {
            try
            {
                PrUnitSaleDetailDTO selectedPrUnitSaleDetailDto = getCurrentGridCancelledUnits().Find(c => c.isUISelected);
                PrUnitSaleDetailDTO prUnitSaleDetailDto = cancelledUnitBO.fetchPrUnitSaleDetail(getUserDefinitionDTO().FirmNumber, selectedPrUnitSaleDetailDto.Id);
                prUnitSaleDetailDto.PropertyUnit = selectedPrUnitSaleDetailDto.PropertyUnit;
                prUnitSaleDetailDto.uiTaxDetails = new List<PrUnitSaleTaxDetailDTO>();
                prUnitSaleDetailDto.uiCMTaxDetails = new List<PrUnitSaleTaxDetailDTO>();
                foreach (PrUnitSaleTaxDetailDTO taxDtl in prUnitSaleDetailDto.PrUnitSaleTaxDetails)
                {
                    if (IncludeInPymtTotal.Yes == taxDtl.IncludeInTotalPymt) prUnitSaleDetailDto.uiTaxDetails.Add(taxDtl); 
                    else prUnitSaleDetailDto.uiCMTaxDetails.Add(taxDtl);
                }
                ViewState[VS_SELECTED_UNIT] = prUnitSaleDetailDto;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                throw exp;
            }
        }
        protected void onSelectProperty(object sender, EventArgs e)
        {
            try
            {
                resetTabInfo(CancelledUnitPageMode.NONE);
                drpBO.drpDataBase(drpSelectPropertyTower, DrpDataType.PROPERTY_TOWER, drpSelectProperty.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
                if (drpSelectPropertyTower.Items.Count == 2)
                {
                    drpSelectPropertyTower.Items[1].Selected = true;
                    pnlSoldUnitGrid.Visible = true;
                }
                fetchSoldUnits(0);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onSelectPropertyTower(object sender, EventArgs e)
        {
            try
            {
                resetTabInfo(CancelledUnitPageMode.NONE);
                pnlSoldUnitGrid.Visible = !string.IsNullOrWhiteSpace(drpSelectPropertyTower.Text);
                fetchSoldUnits(0);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onSearchBy(object sender, EventArgs e)
        {
            try
            {
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                SoldUnitSearchBy searchBy = EnumHelper.ToEnum<SoldUnitSearchBy>(drpSearchBy.Text);
                drpSearchByValue.Visible = true;
                lbSearchByValue.Visible = true;
                lbSearchByValue.Text = EnumHelper.GetEnumDescription<SoldUnitSearchBy>(searchBy.ToString());
                if (SoldUnitSearchBy.PROPERTY_UNIT == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.AVAIL_UNIT_SEARCH_BY_PR_UNIT, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (SoldUnitSearchBy.UNIT_TYPE == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (SoldUnitSearchBy.CUSTOMER == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.CUSTOMER_SEARCH_BY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (SoldUnitSearchBy.EMPLOYEE == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.EMPLOYEE_SEARCH_BY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else
                {
                    drpSearchByValue.ClearSelection();
                    drpSearchByValue.Visible = false;
                    lbSearchByValue.Visible = false;
                }
                loadSearchGridAndReSelect(0);
                resetTabInfo(CancelledUnitPageMode.NONE);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onSearchByValue(object sender, EventArgs e)
        {
            try {
                loadSearchGridAndReSelect(0);
                resetTabInfo(CancelledUnitPageMode.NONE);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onSelectCancelledUnit(object sender, EventArgs e)
        {
            try
            {
                GroupRadioButton rd = (GroupRadioButton)sender;
                resetTabInfo(CancelledUnitPageMode.NONE);
                if (rd.Checked)
                {
                    string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnCancelledUnitRowIdentifier"))).Attributes["row-identifier"];
                    setSelectedPropertyUnit(long.Parse(strId));
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickViewSoldUnitsBtn(object sender, EventArgs e)
        {
            try
            {
                if (validatePropertyUnitSelected())
                {
                    doViewModifyAction(CancelledUnitPageMode.VIEW);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickModifySoldUnitsBtn(object sender, EventArgs e)
        {
            try
            {
                if (validatePropertyUnitSelected())
                {
                    doViewModifyAction(CancelledUnitPageMode.MODIFY);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void doViewModifyAction(CancelledUnitPageMode pageMode)
        {
            resetTabInfo(pageMode);
            fetchSelectedPropertyUnit();
            populateUIFieldsFromSaleUnitDTO(getCurrentCancelledUnit());
        }
        protected void submitChanges(object sender, EventArgs e)
        {
            try
            {
                if (validateUIFields() && validateCancellationPayment())
                {
                    PrUnitSaleDetailDTO prUnitSaleDetailDTO = populateCancelBookingFromUI();
                    cancelledUnitBO.UpdateCancelledPropertyUnitDetails(prUnitSaleDetailDTO);
                    resetTabInfo(CancelledUnitPageMode.NONE);
                    string unitName = prUnitSaleDetailDTO.PropertyUnit.UnitNo;
                    setSuccessMessage(string.Format("Property Unit '{0}' is updated successfully", unitName), tab2Anchor.ID, tab2BzStep1);
                    fetchSoldUnits(prUnitSaleDetailDTO.Id);
                    doViewModifyAction(CancelledUnitPageMode.MODIFY);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2BzStep1Error);
            }
        }
        protected void cancelTab2Changes(object sender, EventArgs e)
        {
            PrUnitSaleDetailDTO prUnitSaleDetailDto = getCurrentCancelledUnit();
            resetTabInfo(CancelledUnitPageMode.NONE);
            loadSearchGridAndReSelect(prUnitSaleDetailDto.Id);
        }
        protected void gotoTab2StepyWizard(object sender, EventArgs e)
        {
            bool isValid = validateTab2Step(tab2ContentBzHdn.Value);
            if (isValid)
            {
                setCurrentStep(goToStepHdn.Value);
            }
        }
        /**
         * Define all validation which will be done before add or update property.
         * */
        private bool validateUIFields()
        {
            bool isValid = validateTab2Step(tab2BzStep2);
            return isValid;
        }
        /**
         * Validates given step.
         * */
        private bool validateTab2Step(string step)
        {
            bool isValid = true;
            if (!CancelledUnitPageMode.VIEW.ToString().Equals(pageModeHdn.Value))
            {
                if (step.Equals(tab2BzStep2))
                {
                    Page.Validate(tab2BzStep2Error);
                    isValid = Page.IsValid;
                }
            }
            return isValid;
        }
        private void setCurrentStep(string step)
        {
            tab2ContentBzHdn.Value = step;
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        private PrUnitSaleDetailDTO populateCancelBookingFromUI()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            PrUnitSaleDetailDTO prUnitSaleDetailDto = getCurrentCancelledUnit();
            decimal? cancellationFee = CommonUtil.getDecimalWithoutExt(txtCancellationFee.Text);
            prUnitSaleDetailDto.CancellationFee = (cancellationFee == null) ? 0 : cancellationFee;
            prUnitSaleDetailDto.CancellationReason = txtCancellationReason.Text;
            prUnitSaleDetailDto.UpdateUser = getUserDefinitionDTO().Username;

            return prUnitSaleDetailDto;
        }
        protected void reCalculateCancellationPayment(object sender, EventArgs e)
        {
            try
            {
                if (validateTab2Step(tab2BzStep2) && validateCancellationPayment())
                {
                    PrUnitSaleDetailDTO prUnitSaleDetailTO = getCurrentCancelledUnit();
                    decimal cancellationPymtAmt = getCancellationPaymentAmt(prUnitSaleDetailTO);
                    PrUnitSalePymtDTO prUnitSalePymtDto = prUnitSaleDetailTO.PrUnitSalePymts.ToList<PrUnitSalePymtDTO>()
                            .Find(x => x.PymtType.Name.Equals(Constants.MCD_CANCELLATION_PAYMENT));
                    prUnitSalePymtDto.PymtAmt = cancellationPymtAmt;
                    prUnitSalePymtDto.UpdateUser = getUserDefinitionDTO().Username;
                    updatePymtMaster(prUnitSalePymtDto);
                    populateSalePymtGrid(prUnitSaleDetailTO);
                    setSuccessMessage("Cancellation Payment is updated, Please click submit to save changes.", tab2Anchor.ID, tab2BzStep3);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2BzStep2Error);
            }
        }
        private bool validateCancellationPayment()
        {
            bool isValid = true;
            PrUnitSaleDetailDTO prUnitSaleDetailTO = getCurrentCancelledUnit();
            decimal cancellationPymtAmt = getCancellationPaymentAmt(prUnitSaleDetailTO);
            PrUnitSalePymtDTO prUnitSalePymtDto = prUnitSaleDetailTO.PrUnitSalePymts.ToList<PrUnitSalePymtDTO>()
                            .Find(x => x.PymtType.Name.Equals(Constants.MCD_CANCELLATION_PAYMENT));
            if (prUnitSalePymtDto != null && prUnitSalePymtDto.PaymentMaster.TotalPaid.CompareTo(cancellationPymtAmt) > 0)
            {
                setErrorMessage("Firm has already paid more than Cancellation Payment. Please adjust Cancellation Fee.", tab2BzStep2Error);
                isValid = false;
            }
            return isValid;
        }
        private decimal getCancellationPaymentAmt(PrUnitSaleDetailDTO prUnitSaleDetailDto)
        {
            decimal cancellationPymtAmt = 0;
            decimal totalPaidAmt = 0;
            foreach (PrUnitSalePymtDTO prUnitSalePymtDto in prUnitSaleDetailDto.PrUnitSalePymts)
            {
                if (prUnitSalePymtDto.PaymentMaster.Status != PymtMasterStatus.Deleted && prUnitSalePymtDto.PymtTo == PRUnitSalePymtTo.Builder)
                {
                    totalPaidAmt = totalPaidAmt + prUnitSalePymtDto.PaymentMaster.TotalPaid;
                }
            }
            cancellationPymtAmt = totalPaidAmt - CommonUtil.getDecimaNotNulllWithoutExt(txtCancellationFee.Text);
            if (cancellationPymtAmt < 0) cancellationPymtAmt = 0;
            return cancellationPymtAmt;
        }
        private void populateUIFieldsFromSaleUnitDTO(PrUnitSaleDetailDTO prUnitSaleDetailDto)
        {
            PropertyUnitDTO propertyUnitDto = prUnitSaleDetailDto.PropertyUnit;
            PropertyTowerDTO propertyTowerDto = prUnitSaleDetailDto.PropertyUnit.PropertyTower;
            CustomerDTO customerDto = prUnitSaleDetailDto.Customer;
            populateUnitInfoSection(prUnitSaleDetailDto);
            cbAgreementDone.Checked = (prUnitSaleDetailDto.IsAgreementDone == IsAgreementDone.Yes);
            txtAgreementDate.Text = CommonUtil.getCSDate(prUnitSaleDetailDto.AgreementDate);
            txtAgreementNo.Text = prUnitSaleDetailDto.AgreementNo;
            cbPossessionGiven.Checked = (prUnitSaleDetailDto.IsPossessionDone == IsPossessionDone.Yes);
            txtPossesionDate.Text = CommonUtil.getCSDate(prUnitSaleDetailDto.PossessionDate);
            txtLoanBankName.Text = prUnitSaleDetailDto.LoanBankName;
            txtLoanBranch.Text = prUnitSaleDetailDto.LoanBankBranch;
            txtLoanAmount.Text = (prUnitSaleDetailDto.LoanAmt != null)?prUnitSaleDetailDto.LoanAmt.ToString():null;
            txtCancellationEmployee.Text = prUnitSaleDetailDto.CancellationFirmMember.FirstName + " " + prUnitSaleDetailDto.CancellationFirmMember.LastName;
            txtCancellationDate.Text = CommonUtil.getCSDate(prUnitSaleDetailDto.CanellationDate);
            txtCancellationFee.Text = (prUnitSaleDetailDto.CancellationFee != null) ? prUnitSaleDetailDto.CancellationFee.ToString() : null;
            txtCancellationReason.Text = prUnitSaleDetailDto.CancellationReason;
            populateTaxDetailGrid(prUnitSaleDetailDto);
            populateCMTaxDetailGrid(prUnitSaleDetailDto);
            populateCoCustomerGrid(prUnitSaleDetailDto);
            populateSalePymtGrid(prUnitSaleDetailDto);
        }
        private void populateUnitInfoSection(PrUnitSaleDetailDTO prUnitSaleDetailDto)
        {
            if (prUnitSaleDetailDto != null)
            {
                PropertyUnitDTO propertyUnitDto = prUnitSaleDetailDto.PropertyUnit;
                PropertyTowerDTO propertyTowerDto = prUnitSaleDetailDto.PropertyUnit.PropertyTower;
                txtBookPropertyName.Text = propertyTowerDto.Property.Name;
                txtBookPropertyTower.Text = propertyTowerDto.Name;
                txtBookUnitNo.Text = prUnitSaleDetailDto.PropertyUnit.UnitNo;
                txtBookUnitType.Text = (propertyUnitDto.UnitType != null) ? propertyUnitDto.UnitType.Name : null;
                txtBookBuiltupArea.Text = propertyUnitDto.BuildupArea.ToString();
                txtBookCarpetArea.Text = propertyUnitDto.CarpetArea.ToString();
                txtCustomer.Text = prUnitSaleDetailDto.Customer.FirstName + " " + prUnitSaleDetailDto.Customer.LastName; 
                txtEnquiryRefNo.Text = prUnitSaleDetailDto.EnquiryRefNo;
                txtCustomerRefNo.Text = prUnitSaleDetailDto.Customer.CustRefNo;
                txtEmployee.Text = prUnitSaleDetailDto.FirmMember.FirstName + " " + prUnitSaleDetailDto.FirmMember.LastName;
                txtBookingDate.Text = CommonUtil.getCSDate(prUnitSaleDetailDto.BookingDate);
                txtBookingRate.Text = prUnitSaleDetailDto.SaleRate.ToString();
                txtAgreementValue.Text = prUnitSaleDetailDto.AgreementAmt.ToString();
                txtBookTotalTax.Text = prUnitSaleDetailDto.TotalTaxAmt.ToString();
                txtBookTotalUnitCost.Text = prUnitSaleDetailDto.TotalPymtAmt.ToString();
            }
        }
        private void populateTaxDetailGrid(PrUnitSaleDetailDTO prUnitSaleDetailDTO)
        {
            taxDetailGrid.DataSource = new List<PrUnitSaleTaxDetailDTO>();
            if (prUnitSaleDetailDTO != null && prUnitSaleDetailDTO.uiTaxDetails != null)
            {
                assignUiIndexToTaxDetail(prUnitSaleDetailDTO.uiTaxDetails);
                taxDetailGrid.DataSource = prUnitSaleDetailDTO.uiTaxDetails;
            }
            taxDetailGrid.DataBind();
        }
        private void populateCMTaxDetailGrid(PrUnitSaleDetailDTO prUnitSaleDetailDTO)
        {
            cmTaxDetailGrid.DataSource = new List<PrUnitSaleTaxDetailDTO>();
            if (prUnitSaleDetailDTO != null && prUnitSaleDetailDTO.uiTaxDetails != null)
            {
                assignUiIndexToTaxDetail(prUnitSaleDetailDTO.uiCMTaxDetails);
                cmTaxDetailGrid.DataSource = prUnitSaleDetailDTO.uiCMTaxDetails;
            }
            cmTaxDetailGrid.DataBind();
        }
        private void assignUiIndexToTaxDetail(List<PrUnitSaleTaxDetailDTO> taxDetailDtos)
        {
            if (taxDetailDtos != null && taxDetailDtos.Count > 0)
            {
                long uiIndex = 1;
                foreach (PrUnitSaleTaxDetailDTO taxDetailDto in taxDetailDtos)
                {
                    taxDetailDto.UiIndex = uiIndex++;
                    taxDetailDto.RowInfo = CommonUIConverter.getGridViewRowInfo(taxDetailDto);
                }
            }
        }
        private void populateSalePymtGrid(PrUnitSaleDetailDTO prUnitSaleDetailDTO)
        {
            paymentGrid.DataSource = new List<PrUnitSalePymtDTO>();
            if (prUnitSaleDetailDTO != null && prUnitSaleDetailDTO.PrUnitSalePymts != null)
            {
                assignUiIndexToSalePymts(prUnitSaleDetailDTO.PrUnitSalePymts);
                paymentGrid.DataSource = prUnitSaleDetailDTO.PrUnitSalePymts;
            }
            paymentGrid.DataBind();
        }
        private void assignUiIndexToSalePymts(ISet<PrUnitSalePymtDTO> salePymtDtos)
        {
            if (salePymtDtos != null && salePymtDtos.Count > 0)
            {
                long uiIndex = 1;
                foreach (PrUnitSalePymtDTO salePymtDto in salePymtDtos)
                {
                    salePymtDto.UiIndex = uiIndex++;
                    salePymtDto.RowInfo = CommonUIConverter.getGridViewRowInfo(salePymtDto);
                }
            }
        }
        private void populateCoCustomerGrid(PrUnitSaleDetailDTO prSaleDetailDTO)
        {
            coCustomerGrid.DataSource = new List<CoCustomerDTO>();
            if (prSaleDetailDTO != null)
            {
                assignUiIndexToCoCustomer(prSaleDetailDTO.CoCustomers);
                coCustomerGrid.DataSource = prSaleDetailDTO.CoCustomers;
            }
            coCustomerGrid.DataBind();
        }
        private void assignUiIndexToCoCustomer(ISet<CoCustomerDTO> CocustomerDtos)
        {
            if (CocustomerDtos != null && CocustomerDtos.Count > 0)
            {
                long uiIndex = 1;
                foreach (CoCustomerDTO cocustomerDto in CocustomerDtos)
                {
                    cocustomerDto.FullName = CommonUIConverter.getCustomerFullName(cocustomerDto.FirstName, cocustomerDto.LastName);
                    cocustomerDto.UiIndex = uiIndex++;
                    cocustomerDto.RowInfo = CommonUIConverter.getGridViewRowInfo(cocustomerDto);
                }
            }
        }
        //Payment Table actions - Start
        private void initPaymentUpdateSection(bool isAdd)
        {
            lbAddUpdateSectionHeader.Text = (isAdd) ? Resources.Labels.label_sectionheader_addpayment : Resources.Labels.label_sectionheader_modifypayment;
            pnlPaymentAdd.Visible = true;
            btnPaymentAddToGrid.Visible = isAdd;
            btnPaymentUpdateToGrid.Visible = !isAdd;
            addPymtTypeBtn.Visible = true;
            populateDrpPaymentType(isAdd);
            enableFields(isAdd);
            if (!isAdd)
            {
                addPymtTypeBtn.Visible = false;
                PrUnitSalePymtDTO prUnitSalePymtDto = getSelectedPrUnitSalePayment();
                if (isSalePayment(prUnitSalePymtDto.PymtType.Name) || isCancellationPayment(prUnitSalePymtDto.PymtType.Name)
                    || prUnitSalePymtDto.PaymentMaster.Status == PymtMasterStatus.Deleted)
                {
                    btnPaymentUpdateToGrid.Visible = false;
                }
            }
        }
        private void enableFields(bool isAdd)
        {
            drpPaymentType.Visible = isAdd;
            txtROPaymentType.Visible = !isAdd;
            txtROPaymentType.ReadOnly = true;
            pnlPaymentDate.Visible = isAdd;
            txtROPaymentDate.Visible = !isAdd;
            txtROPaymentDate.ReadOnly = true;
            drpPaymentTo.Visible = isAdd;
            txtROPaymentTo.Visible = !isAdd;
            txtROPaymentTo.ReadOnly = true;
        }
        private void initPaymentSectionFields(PrUnitSalePymtDTO prUnitSalePymtDto)
        {
            if (prUnitSalePymtDto != null) txtPaymentAmount.Text = prUnitSalePymtDto.PymtAmt.ToString(); else txtPaymentAmount.Text = null;
            if (prUnitSalePymtDto != null) txtPaymentDescription.Text = prUnitSalePymtDto.Description; else txtPaymentDescription.Text = null;
            if (prUnitSalePymtDto != null)
            {
                txtROPaymentType.Text = prUnitSalePymtDto.PymtType.Name;
                txtROPaymentDate.Text = CommonUtil.getCSDate(prUnitSalePymtDto.PymtDate);
                txtROPaymentTo.Text = prUnitSalePymtDto.PymtTo.ToString();
                txtPaymentAmount.ReadOnly = isSalePayment(prUnitSalePymtDto.PymtType.Name) || isCancellationPayment(prUnitSalePymtDto.PymtType.Name);
                txtPaymentDescription.ReadOnly = isSalePayment(prUnitSalePymtDto.PymtType.Name) || isCancellationPayment(prUnitSalePymtDto.PymtType.Name);
            }
            else
            {
                drpPaymentType.ClearSelection();
                txtPaymentDate.Text = null;
                drpPaymentTo.ClearSelection();
                txtPaymentAmount.ReadOnly = false;
                txtPaymentDescription.ReadOnly = false;
            }
        }
        private void clearPaymentViewState()
        {
            if (paymentGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in paymentGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdPaymentSelect");
                    if (radioBtn != null) radioBtn.Checked = false;
                }
            }
            getCurrentCancelledUnit().PrUnitSalePymts.ToList<PrUnitSalePymtDTO>().ForEach(c => c.isUISelected = false);
        }
        private void selectPrUnitSalePayment(PrUnitSalePymtDTO prUnitSalePymtDto)
        {
            if (paymentGrid.Rows.Count > 0)
            {
                prUnitSalePymtDto.isUISelected = true;
                foreach (GridViewRow row in paymentGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdPaymentSelect");
                    Button rowIdenBtn = (Button)row.FindControl("btnPaymentRowIdentifier");
                    radioBtn.Checked = false;
                    if (rowIdenBtn != null && prUnitSalePymtDto.UiIndex.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                    {
                        radioBtn.Checked = true;
                    }
                }
            }
        }
        private PrUnitSalePymtDTO getSelectedPrUnitSalePayment()
        {
            return getCurrentCancelledUnit().PrUnitSalePymts.ToList<PrUnitSalePymtDTO>().Find(c => c.isUISelected);
        }
       
        private bool validatePaymentSelected()
        {
            bool isSelected = true;
            PrUnitSalePymtDTO prUnitSalePymtDto = getSelectedPrUnitSalePayment();
            if (prUnitSalePymtDto == null)
            {
                isSelected = false;
                pnlPaymentAdd.Visible = false;
                clearPaymentViewState();
                setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Payment"), tab2BzStep3Error);
            }
            return isSelected;
        }

        private PrUnitSalePymtDTO populatePrUnitSalePymtAdd()
        {
            PrUnitSalePymtDTO prUnitSalePymtDto = new PrUnitSalePymtDTO();
            UserDefinitionDTO userDef =  getUserDefinitionDTO();
            prUnitSalePymtDto.FirmNumber = userDef.FirmNumber;
            prUnitSalePymtDto.InsertUser = userDef.Username;
            return prUnitSalePymtDto;
        }
        private void populatePrUnitSalePymtFromUI(PrUnitSalePymtDTO prUnitSalePymtDto, bool isAdd)
        {
            if (isAdd)
            {
                prUnitSalePymtDto.PymtType = CommonUIConverter.getMasterControlDTO(drpPaymentType.Text, drpPaymentType.SelectedItem.Text);
                prUnitSalePymtDto.PymtDate = CommonUtil.getCSDateNotNull(txtPaymentDate.Text);
                prUnitSalePymtDto.PymtTo = EnumHelper.ToEnum<PRUnitSalePymtTo>(drpPaymentTo.Text);
            }
            prUnitSalePymtDto.PymtAmt = CommonUtil.getDecimaNotNulllWithoutExt(txtPaymentAmount.Text);
            prUnitSalePymtDto.Description = txtPaymentDescription.Text;
            prUnitSalePymtDto.UpdateUser = getUserDefinitionDTO().Username;
        }
        private void addNewPymtMaster(PrUnitSalePymtDTO prUnitSalePymtDto)
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            PaymentMasterDTO paymentMasterDto = new PaymentMasterDTO();
            paymentMasterDto.TotalAmt = Decimal.Zero;
            paymentMasterDto.TotalPaid = Decimal.Zero;
            paymentMasterDto.TotalPending = Decimal.Zero;
            paymentMasterDto.TotalPdcAmt = Decimal.Zero;
            paymentMasterDto.FirmNumber = userDefDto.FirmNumber;
            paymentMasterDto.InsertUser = userDefDto.Username;
            prUnitSalePymtDto.PaymentMaster = paymentMasterDto;
            updatePymtMaster(prUnitSalePymtDto);
        }
        private void updatePymtMaster(PrUnitSalePymtDTO prUnitSalePymtDto)
        {
            PaymentMasterDTO paymentMasterDto = prUnitSalePymtDto.PaymentMaster;
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            decimal diffAmt = Decimal.Subtract(prUnitSalePymtDto.PymtAmt, paymentMasterDto.TotalAmt);
            paymentMasterDto.TotalAmt = Decimal.Add(paymentMasterDto.TotalAmt, diffAmt);
            paymentMasterDto.TotalPending = Decimal.Subtract(paymentMasterDto.TotalAmt, paymentMasterDto.TotalPaid);
            paymentMasterDto.UpdateUser = userDefDto.Username;
            if (paymentMasterDto.TotalPending > 0) paymentMasterDto.Status = PymtMasterStatus.Pending; 
            else paymentMasterDto.Status = PymtMasterStatus.Paid;
        }
        
        protected void selectPayment(object sender, EventArgs e)
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            pnlPaymentAdd.Visible = false;
            if (rd.Checked)
            {
                long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnPaymentRowIdentifier"))).Attributes["row-identifier"]);
                List<PrUnitSalePymtDTO> pymtList = getCurrentCancelledUnit().PrUnitSalePymts.ToList<PrUnitSalePymtDTO>();
                pymtList.ForEach(c => c.isUISelected = false);
                pymtList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
            }
        }
        protected void onClickAddPaymentBtn(object sender, EventArgs e)
        {
            try
            {
                clearPaymentViewState();
                initPaymentUpdateSection(true);
                initPaymentSectionFields(null);
                SetFocus(drpPaymentType);
                scrollToFieldHdn.Value = pnlPaymentAdd.ID;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2BzStep3Error);
            }
        }
        protected void onClickModifyPaymentsBtn(object sender, EventArgs e)
        {
            try
            {
                if (validatePaymentSelected())
                {
                    initPaymentUpdateSection(false);
                    initPaymentSectionFields(getSelectedPrUnitSalePayment());
                    SetFocus(drpPaymentType);
                    scrollToFieldHdn.Value = pnlPaymentAdd.ID;
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2BzStep3Error);
            }
        }
        protected void deleterPayments(object sender, EventArgs e)
        {
            try
            {
                if (validatePaymentSelected() && validateDeletePaymentType())
                {
                    PrUnitSaleDetailDTO prUnitSaleDetailDto = getCurrentCancelledUnit();
                    PrUnitSalePymtDTO prUnitSalePymtDto = getSelectedPrUnitSalePayment();
                    if (prUnitSalePymtDto.PaymentMaster.Id > 0)
                    {
                        prUnitSalePymtDto.PaymentMaster.Status = PymtMasterStatus.Deleted;
                    }
                    else
                    {
                        prUnitSaleDetailDto.PrUnitSalePymts.Remove(prUnitSalePymtDto);
                    }
                    pnlPaymentAdd.Visible = false;
                    clearPaymentViewState();
                    populateSalePymtGrid(prUnitSaleDetailDto);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, "Payment"), tab2Anchor.ID, tab2BzStep3);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2BzStep3Error);
            }
        }
        protected void addNewPayment(object sender, EventArgs e)
        {
            try
            {
                if (validateMandatoryPymtField(false))
                {
                    PrUnitSaleDetailDTO prUnitSaleDetailDto = getCurrentCancelledUnit();
                    PrUnitSalePymtDTO prUnitSalePymtDto = populatePrUnitSalePymtAdd();
                    populatePrUnitSalePymtFromUI(prUnitSalePymtDto, true);
                    addNewPymtMaster(prUnitSalePymtDto);
                    prUnitSaleDetailDto.PrUnitSalePymts.Add(prUnitSalePymtDto);
                    pnlPaymentAdd.Visible = false;
                    clearPaymentViewState();
                    populateSalePymtGrid(prUnitSaleDetailDto);
                    selectPrUnitSalePayment(prUnitSalePymtDto);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, "Payment"), tab2Anchor.ID, tab2BzStep3);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2BzStep3Error);
            }
        }
        protected void updatePayment(object sender, EventArgs e)
        {
            try
            {
                if (validateMandatoryPymtField(false) && validatePaymentUpdate())
                {
                    PrUnitSaleDetailDTO prUnitSaleDetailDto = getCurrentCancelledUnit();
                    PrUnitSalePymtDTO prUnitSalePymtDto = getSelectedPrUnitSalePayment();
                    populatePrUnitSalePymtFromUI(prUnitSalePymtDto, false);
                    updatePymtMaster(prUnitSalePymtDto);
                    pnlPaymentAdd.Visible = false;
                    clearPaymentViewState();
                    populateSalePymtGrid(prUnitSaleDetailDto);
                    selectPrUnitSalePayment(prUnitSalePymtDto);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_updatedtotable, "Payment"), tab2Anchor.ID, tab2BzStep3);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2BzStep3Error);
            }
        }
        protected void cancelPayment(object sender, EventArgs e)
        {
            pnlPaymentAdd.Visible = false;
            clearPaymentViewState();
        }
        private bool validateMandatoryPymtField(bool isAdd)
        {
            bool isValid = true;
            if (isAdd)
            {
                Page.Validate(tab2BzStep3Error);
                isValid = Page.IsValid;
            }
            Page.Validate(tab2BzStep3Error1);
            isValid = Page.IsValid;
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        private bool validateDeletePaymentType()
        {
            bool isValid = true;
            PrUnitSalePymtDTO prUnitSalePymtDto = getSelectedPrUnitSalePayment();
            if (prUnitSalePymtDto.PaymentMaster.Status == PymtMasterStatus.Deleted)
            {
                setErrorMessage("Payment is already deleted.", tab2BzStep3Error);
                isValid = false;
            }
            else if (isSalePayment(prUnitSalePymtDto.PymtType.Name) || isCancellationPayment(prUnitSalePymtDto.PymtType.Name))
            {
                setErrorMessage("Deletion of selected Payment type is not allowed.", tab2BzStep3Error);
                isValid = false;
            }
            else if (prUnitSalePymtDto.PaymentMaster.TotalPaid > 0)
            {
                setErrorMessage("Part of the payment has been made, can not delete selected payment.", tab2BzStep3Error);
                isValid = false;
            }
            else if (prUnitSalePymtDto.PaymentMaster.Status == PymtMasterStatus.Suspended)
            {
                setErrorMessage("Part of the payment has been made, can not delete selected payment.", tab2BzStep3Error);
                isValid = false;
            }
            return isValid;
        }
        private bool validatePaymentUpdate()
        {
            bool isValid = true;
            PrUnitSalePymtDTO prUnitSalePymtDto = getSelectedPrUnitSalePayment();
            decimal pymtAmt = CommonUtil.getDecimaNotNulllWithoutExt(txtPaymentAmount.Text);
            decimal diffAmt = Decimal.Subtract(pymtAmt, prUnitSalePymtDto.PaymentMaster.TotalAmt);
            decimal effectiveAmt = Decimal.Add(prUnitSalePymtDto.PaymentMaster.TotalAmt, diffAmt);
            if (effectiveAmt.CompareTo(prUnitSalePymtDto.PaymentMaster.TotalPaid) < 0)
            {
                setErrorMessage("Payment amount can not be less than Total Paid amount.", tab2BzStep3Error);
                isValid = false;
            }
            return isValid;
        }
        private void populateDrpPaymentType(bool isAdd)
        {
            drpPaymentType.ClearSelection();
            foreach (ListItem item in drpAllPaymentType.Items)
            {
                if (isAdd && !(isSalePayment(item.Text) || isCancellationPayment(item.Text)))
                {
                    drpPaymentType.Items.Add(item);
                }
            }
        }
        private bool isSalePayment(string paymentType)
        {
            return Constants.MCD_SALE_PAYMENT.Equals(paymentType);
        }
        private bool isCancellationPayment(string paymentType)
        {
            return Constants.MCD_CANCELLATION_PAYMENT.Equals(paymentType);
        }
        //Payment Table actions - END
        //Modal save logic
        protected void saveModalData(object sender, EventArgs e)
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (modalHdnType.Value == "PR_UNIT_PYMT_TYPE")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_UNIT_PYMT_TYPE, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Sale Payment Type");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpPaymentType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_PYMT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }

            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                modalErrorMsg.Value = errorMsg;
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "setModalErrorMsg", "setModalErrorMsg()", true);
            }
            else
            {
                //Reset the modal fields
                modalInput1.Text = "";
                modalInput2.Text = "";
                modalHdnType.Value = "";
                modalActionHdn.Value = "";
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "closeDialogClient", "closeDialogClient()", true);
            }
        }
        private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
        {
            string errorMsg = "";
            if (string.IsNullOrWhiteSpace(masterDataDto.Name))
            {
                errorMsg = string.Format(Resources.Messages.validation_txtfield_required, type);
            }
            else if (masterDataBO.isAlreadyExist(masterDataDto))
            {
                errorMsg = string.Format(Resources.Messages.validation_same_name_exist, type);
            }
            return errorMsg;
        }
    }
}