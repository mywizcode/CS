﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft.Logic.Util;
using OfficeOpenXml;
using OfficeOpenXml.DataValidation;
using OfficeOpenXml.Style;
using Vladsm.Web.UI.WebControls;

namespace ConstroSoft.pages.PropertyManagement
{
    public partial class PropertyParkingManagement : System.Web.UI.Page
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string tab1ValidationGrp = "tab1Error";
        string tab2ValidationGrp = "tab2Error";
        string VS_PR_PARKING_LIST = "PR_PARKING_LIST";
        string VS_PROPERTYUPLOADPARKING_LIST = "UPLOADED_PROPERTYPARKING";
        DropdownBO drpBO = new DropdownBO();
        PropertyBO propertyBO = new PropertyBO();
        MasterDataBO masterDataBO = new MasterDataBO();
        public enum PrParkingPageMode { ADD, MODIFY, VIEW, NONE, UPLOAD }

        protected void Page_Load(object sender, EventArgs e)
        {
            clearMessages();
            if (!IsPostBack)
            {
                if (CommonUtil.isSessionActive(Session))
                {
                    resetPageInfo(PrParkingPageMode.NONE);
                    initDropdowns();
                    Page.MaintainScrollPositionOnPostBack = false;
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
        }
        private void initDropdowns()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            drpBO.drpDataBase(drpSelectProperty, DrpDataType.PROPERTY_NAME, userDefDto.Id.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpParkingType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_PARKING_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpEnum<CommonParking>(drp_commonparking, null);//Constants.SELECT_ITEM);
            drpBO.drpEnum<ParkingStatus>(drpStatus, null);
        }
        /**
         * This method is called just before the page is rendered. So any change in state of the element is applied.
         **/
        protected void Page_PreRender(object sender, EventArgs e)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                applyEntitlement();
                preRenderInitFormElements();
                initBootstrapComponantsFromServer();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        private void applyEntitlement()
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            
            addPropParkingBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_PARKING_ADD);
            modifyPropParkingBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_PARKING_MODIFY);
            deletePropParkingBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_PARKING_DELETE);
            downloandParkingTemplateBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_PARKING_ADD);
            uploadPropParkingBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_PARKING_ADD);
            bool isReadOnly = !(addPropParkingBtn.Visible || modifyPropParkingBtn.Visible || deletePropParkingBtn.Visible);
            viewOnlyTableHdn.Value = isReadOnly ? "true" : "false";
            if (btnAddSubmit.Visible) btnAddSubmit.Visible = !isReadOnly;
            propertyParkingGrid.Columns[0].Visible = !isReadOnly;
            parkingBtnGrp.Visible = !isReadOnly;
        }

        private void preRenderInitFormElements()
        {
            jumpToPropertyParkingHdnId.Value = "";
            PropertyParkingDTO propertyParkingDTO = getSelectedPropertyParking();
            if (propertyParkingDTO != null)
            {
                jumpToPropertyParkingHdnId.Value = propertyParkingDTO.UiIndex + "";
            }
        }
        public void setErrorMessage(string message, string group)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        public void setSuccessMessage(string msg, string tabId)
        {
            activeTabHdn.Value = tabId;
            if (tabId.Equals(tab1Anchor.ID))
            {
                lbTab1Success.Text = msg;
                tab1SuccessPanel.Visible = true;
            }
            else if (tabId.Equals(tab2Anchor.ID))
            {
                lbTab2Success.Text = msg;
                tab2SuccessPanel.Visible = true;
            }
        }
        public void initBootstrapComponantsFromServer()
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
        }
        private void clearMessages()
        {
            tab1SuccessPanel.Visible = false;
            lbTab1Success.Text = "";
        }
        private UserDefinitionDTO getUserDefinitionDTO()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }

        private void resetPageInfo(PrParkingPageMode pageMode)
        {
            pageModeHdn.Value = pageMode.ToString();
            initFormFields();
            pnlPropertyParkingAdd.Visible = false;
            if (PrParkingPageMode.NONE == pageMode)
            {
                activeTabHdn.Value = tab1Anchor.ID;
                tab2Anchor.Visible = false;
                pnlPropertyParkingGrid.Visible = false;
                ViewState[VS_PR_PARKING_LIST] = new List<PropertyParkingDTO>();
            }
            else if (PrParkingPageMode.UPLOAD == pageMode)
            {
                activeTabHdn.Value = tab2Anchor.ID;
                tab2Anchor.Visible = true;
            }
            else
            {
                pnlPropertyParkingGrid.Visible = true;
            }
        }
        private void initFormFields()
        {
            bool isReadOnly = (PrParkingPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            bool visible = !(PrParkingPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            //Buttons
            btnAddSubmit.Visible = visible;
            propertyParkingGrid.Columns[0].Visible = visible;
        }
        private List<PropertyParkingDTO> getPropertyParkingList()
        {
            return (List<PropertyParkingDTO>)ViewState[VS_PR_PARKING_LIST];
        }
        private PropertyParkingDTO getSelectedPropertyParking()
        {
            PropertyParkingDTO selectedParking = null;
            List<PropertyParkingDTO> prParkingList = getPropertyParkingList();
            if (prParkingList != null && prParkingList.Count != 0)
            {
                selectedParking = prParkingList.Find(c => c.isUISelected);
            }
            return selectedParking;
        }
        private void setSelectedPropertyParking(long selectedUiIndex)
        {
            List<PropertyParkingDTO> prParkingList = getPropertyParkingList();
            if (prParkingList != null)
            {
                prParkingList.ForEach(c => c.isUISelected = false);
                if (selectedUiIndex != -1) prParkingList.Find(c => c.UiIndex == selectedUiIndex).isUISelected = true;
            }
        }
        private void initPropertyParkingAddUpdateSection(bool isAdd)
        {
            lbPropertyParkingAddUpdateSectionHeader.Text = (isAdd) ? Resources.Labels.label_sectionheader_property_parkingadd : Resources.Labels.label_sectionheader_propertyparking_modify;
            pnlPropertyParkingAdd.Visible = true;
            btnPropertyParkingAddToGrid.Visible = isAdd;
            btnPropertyParkingUpdateToGrid.Visible = !isAdd;
        }
        private void setDefaultOnAddPropertyTower()
        {

        }
        private void initPropertyParkingSectionFields(PropertyParkingDTO PropertyParkingDTO)
        {
            if (PropertyParkingDTO != null && PropertyParkingDTO.ParkingType != null) drpParkingType.Text = PropertyParkingDTO.ParkingType.Id.ToString(); else drpParkingType.ClearSelection(); ;
            if (PropertyParkingDTO != null) txtParkingNo.Text = PropertyParkingDTO.ParkingNo; else txtParkingNo.Text = null;
            if (PropertyParkingDTO != null) txtArea.Text = PropertyParkingDTO.Area.ToString(); else txtArea.Text = null;
            if (PropertyParkingDTO != null) drp_commonparking.Text = PropertyParkingDTO.CommonParking.ToString(); else drp_commonparking.ClearSelection();
            if (PropertyParkingDTO != null) drpStatus.Text = PropertyParkingDTO.Status.ToString(); else drpStatus.ClearSelection();
        }
        private void resetPropertyParkingSelection(long uiIndex)
        {
            if (propertyParkingGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in propertyParkingGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdPropertyParkingSelect");
                    radioBtn.Checked = false;
                    if (uiIndex > 0)
                    {
                        Button rowIdenBtn = (Button)row.FindControl("btnPropertyParkingRowIdentifier");
                        if (rowIdenBtn != null && uiIndex.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                        {
                            radioBtn.Checked = true;
                            setSelectedPropertyParking(uiIndex);
                        }
                    }
                }
            }
            if (uiIndex <= 0) setSelectedPropertyParking(-1);
        }
        private bool validatePropertyParkingSelected()
        {
            bool isSelected = true;
            PropertyParkingDTO selectedParking = getSelectedPropertyParking();
            if (selectedParking == null)
            {
                isSelected = false;
                setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Parking"), tab1ValidationGrp);
            }
            return isSelected;
        }
        private void reBindPropertyParkingGrid(List<PropertyParkingDTO> prParkingList, PropertyParkingDTO propertyParkingDto)
        {
            if (prParkingList != null)
            {
                assignUiIndexToPropertyParking(prParkingList);
                propertyParkingGrid.DataSource = prParkingList;
                propertyParkingGrid.DataBind();
                if (propertyParkingDto != null) resetPropertyParkingSelection(propertyParkingDto.UiIndex);
            }
        }
        private void assignUiIndexToPropertyParking(List<PropertyParkingDTO> prParkingDtos)
        {
            if (prParkingDtos != null && prParkingDtos.Count > 0)
            {
                prParkingDtos.ForEach(c => c.isUISelected = false);
                long uiIndex = 1;
                foreach (PropertyParkingDTO prParkingDto in prParkingDtos)
                {
                    prParkingDto.UiIndex = uiIndex++;
                    prParkingDto.RowInfo = CommonUIConverter.getGridViewRowInfo(prParkingDto);
                }
            }
        }
        private void loadPropertyParkingGrid()
        {
            try
            {
                List<PropertyParkingDTO> results = new List<PropertyParkingDTO>();
                if (!(string.IsNullOrWhiteSpace(drpSelectProperty.Text) || string.IsNullOrWhiteSpace(drpSelectPropertyTower.Text)))
                {
                    long towerId = long.Parse(drpSelectPropertyTower.Text);
                    results = propertyBO.fetchPropertyParking(getUserDefinitionDTO().FirmNumber, towerId);
                    assignUiIndexToPropertyParking(results);
                }
                ViewState[VS_PR_PARKING_LIST] = results;
                propertyParkingGrid.DataSource = results;
                propertyParkingGrid.DataBind();
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void saveModalData(object sender, EventArgs e)
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (modalHdnType.Value == "PARKINGTYPE")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_PARKING_TYPE, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "PARKINGTYPE");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpParkingType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_PARKING_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                modalErrorMsg.Value = errorMsg;
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "setModalErrorMsg", "setModalErrorMsg()", true);
            }
            else
            {
                //Reset the modal fields
                modalInput1.Text = "";
                modalInput2.Text = "";
                modalHdnType.Value = "";
                modalActionHdn.Value = "";
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "closeDialogClient", "closeDialogClient()", true);
            }
        }
        private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
        {
            string errorMsg = "";
            if (string.IsNullOrWhiteSpace(masterDataDto.Name))
            {
                errorMsg = Resources.Messages.validation_designationname_required;
            }
            else if (masterDataBO.isAlreadyExist(masterDataDto))
            {
                errorMsg = string.Format(Resources.Messages.validation_same_name_exist, type);
            }
            return errorMsg;
        }
        protected void onSelectProperty(object sender, EventArgs e)
        {
            try
            {
                resetPageInfo(PrParkingPageMode.NONE);
                lbSearchByValue.Visible = true;
                drpSelectPropertyTower.Visible = true;
                drpBO.drpDataBase(drpSelectPropertyTower, DrpDataType.PROPERTY_TOWER, drpSelectProperty.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
                if (drpSelectPropertyTower.Items.Count == 2)
                {
                    drpSelectPropertyTower.Items[1].Selected = true;
                    resetPageInfo(PrParkingPageMode.ADD);
                    loadPropertyParkingGrid();
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onSelectPropertyTower(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(drpSelectPropertyTower.Text))
                {
                    resetPageInfo(PrParkingPageMode.ADD);
                    loadPropertyParkingGrid();
                }
                else
                {
                    resetPageInfo(PrParkingPageMode.NONE);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onSelectPropertyParking(object sender, EventArgs e)
        {
            try
            {
                GroupRadioButton rd = (GroupRadioButton)sender;
                pnlPropertyParkingAdd.Visible = false;
                lbSearchByValue.Visible = true;
                drpSelectPropertyTower.Visible = true;
                if (rd.Checked)
                {
                    long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnPropertyParkingRowIdentifier"))).Attributes["row-identifier"]);
                    setSelectedPropertyParking(UiIndex);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickAddPropertyParkingBtn(object sender, EventArgs e)
        {
            try
            {
                resetPropertyParkingSelection(-1);
                initPropertyParkingAddUpdateSection(true);
                initPropertyParkingSectionFields(null);
                SetFocus(drpParkingType);
                scrollToFieldHdn.Value = pnlPropertyParkingAdd.ID;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickModifyPropertyParkingBtn(object sender, EventArgs e)
        {
            try
            {
                if (validatePropertyParkingSelected())
                {
                    initPropertyParkingAddUpdateSection(false);
                    initPropertyParkingSectionFields(getSelectedPropertyParking());
                    SetFocus(drpParkingType);
                    scrollToFieldHdn.Value = pnlPropertyParkingAdd.ID;
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void deletePropertyParking(object sender, EventArgs e)
        {
            try
            {
                if (validatePropertyParkingSelected())
                {
                    List<PropertyParkingDTO> prParkingList = getPropertyParkingList();
                    PropertyParkingDTO PropertyParkingDto = getSelectedPropertyParking();
                    prParkingList.Remove(PropertyParkingDto);
                    reBindPropertyParkingGrid(prParkingList, null);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, "Parking"), tab2Anchor.ID);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void addNewPropertyParking(object sender, EventArgs e)
        {
            try
            {
                if (validatePropertyParking())
                {
                    PropertyParkingDTO propertyparkingDto = populatePropertyParkingDTOAddFromUI();
                    List<PropertyParkingDTO> prParkingList = getPropertyParkingList();
                    if (validateParkingNumber(propertyparkingDto, prParkingList))
                    {
                        prParkingList.Add(propertyparkingDto);
                        pnlPropertyParkingAdd.Visible = false;
                        reBindPropertyParkingGrid(prParkingList, propertyparkingDto);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, "Parking"), tab1Anchor.ID);
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        private bool validateParkingNumber(PropertyParkingDTO propertyparkingDto, List<PropertyParkingDTO> prParkingList)
        {
            bool isValid = true;
            int index = prParkingList.FindIndex(item => item.ParkingNo == propertyparkingDto.ParkingNo);
            if (index >= 0)
            {
                setErrorMessage(Resources.Messages.validation_property_parking_number, tab1ValidationGrp);
                isValid = false;
            }
            return isValid;
        }

        private bool validateModifyParkingNumber(PropertyParkingDTO propertyparkingDto, List<PropertyParkingDTO> prParkingList)
        {
            bool isValid = true;
            int index = prParkingList.FindIndex(item => (item.ParkingNo == propertyparkingDto.ParkingNo) && (item.Id != propertyparkingDto.Id));
            if (index >= 0)
            {
                setErrorMessage(Resources.Messages.validation_property_parking_number, tab1ValidationGrp);
                isValid = false;
            }
            return isValid;
        }

        protected void updatePropertyParking(object sender, EventArgs e)
        {
            try
            {
                if (validatePropertyParking())
                {
                    PropertyParkingDTO propertyParkingeDto = getSelectedPropertyParking();
                    populatePropertyParkingFromUI(propertyParkingeDto);
                    if (validateModifyParkingNumber(propertyParkingeDto, getPropertyParkingList()))
                    {
                        pnlPropertyParkingAdd.Visible = false;
                        reBindPropertyParkingGrid(getPropertyParkingList(), propertyParkingeDto);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_updatedtotable, "Parking"),  tab1Anchor.ID);
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void cancelPropertyParking(object sender, EventArgs e)
        {
            pnlPropertyParkingAdd.Visible = false;
            resetPropertyParkingSelection(-1);
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        protected void savePropertyParkingToDB(object sender, EventArgs e)
        {
            try
            {
                List<PropertyParkingDTO> prParkingList = getPropertyParkingList();
                PropertyTowerDTO propertyTowerDto = new PropertyTowerDTO();
                propertyTowerDto.Id = long.Parse(drpSelectPropertyTower.Text);
                propertyTowerDto.FirmNumber = getUserDefinitionDTO().FirmNumber;
                propertyTowerDto.PropertyParkings = new HashSet<PropertyParkingDTO>(prParkingList);
                //Save list to DB
                propertyBO.saveOrUpdatePropertyParking(propertyTowerDto);
                pnlPropertyParkingAdd.Visible = false;
                loadPropertyParkingGrid();
                setSuccessMessage(Resources.Messages.success_property_parking_update, tab1Anchor.ID);

            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private PropertyParkingDTO populatePropertyParkingDTOAddFromUI()
        {
            UserDefinitionDTO userDef = getUserDefinitionDTO();
            PropertyParkingDTO propertyParkingDTO = new PropertyParkingDTO();
            PropertyTowerDTO propertyTowerDto = new PropertyTowerDTO();
            propertyTowerDto.Id = long.Parse(drpSelectPropertyTower.Text);
            propertyTowerDto.FirmNumber = userDef.FirmNumber;
            propertyParkingDTO.PropertyTower = propertyTowerDto;
            propertyParkingDTO.FirmNumber = userDef.FirmNumber;
            propertyParkingDTO.InsertUser = userDef.Username;
            populatePropertyParkingFromUI(propertyParkingDTO);
            return propertyParkingDTO;
        }
        private void populatePropertyParkingFromUI(PropertyParkingDTO propertyParkingDTO)
        {
            propertyParkingDTO.ParkingNo = txtParkingNo.Text;
            propertyParkingDTO.ParkingType = CommonUIConverter.getMasterControlDTO(drpParkingType.Text, drpParkingType.SelectedItem.Text);
            propertyParkingDTO.Status = EnumHelper.ToEnum<ParkingStatus>(drpStatus.Text);
            propertyParkingDTO.CommonParking = EnumHelper.ToEnum<CommonParking>(drp_commonparking.Text);
            if (!string.IsNullOrWhiteSpace(txtArea.Text))
            {
                propertyParkingDTO.Area = CommonUtil.getDecimalWithoutExt(txtArea.Text);
            }
            propertyParkingDTO.UpdateUser = getUserDefinitionDTO().Username;
        }

        private bool validatePropertyParking()
        {
            bool isValid = true;
            Page.Validate(tab1ValidationGrp);
            isValid = Page.IsValid;
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }

        public void downloadParkingTemplate(object sender, EventArgs e)
        {
            List<MasterControlDataDTO> resultsParkingType;
            fetchMaster(out resultsParkingType);
            if (resultsParkingType == null || resultsParkingType.Count <= 0)
            {
                setErrorMessage("Please add property parking types before downloading parking template.", tab1ValidationGrp);
            }
            else
            {
                setResponse();
                using (ExcelPackage package = new ExcelPackage())
                {
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.Add(drpSelectProperty.SelectedItem.Text);

                    using (var range = worksheet.Cells["A1: G1048576"])
                    {
                        range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Top.Color.SetColor(Color.Black);
                        range.Style.Border.Bottom.Color.SetColor(Color.Green);
                        range.Style.Border.Left.Color.SetColor(Color.Blue);
                        range.Style.Border.Right.Color.SetColor(Color.Yellow);
                    }
                    prepareHeader(worksheet);
                    addValidationLists(resultsParkingType, package, worksheet);
                    package.Save();
                    using (MemoryStream MyMemoryStream = new MemoryStream())
                    {
                        package.SaveAs(MyMemoryStream);
                        MyMemoryStream.WriteTo(Response.OutputStream);
                        Response.Flush();
                        Response.End();
                    }
                }
            }
        }
        private void setResponse()
        {
            Response.Clear();
            Response.Buffer = true;
            Response.Charset = "";
            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            Response.AddHeader("content-disposition", "attachment;filename=" + drpSelectProperty.SelectedItem.Text + " Parking.xlsx");
        }

        private void fetchMaster(out List<MasterControlDataDTO> resultsParkingType)
        {
            resultsParkingType = masterDataBO.fetchMasterData(getUserDefinitionDTO().FirmNumber,
                            Constants.MCDType.PR_PARKING_TYPE);
        }

        private void prepareHeader(ExcelWorksheet worksheet)
        {
            worksheet.Cells[1, 1].Value = "Property Name";
            worksheet.Cells[1, 2].Value = "Tower Name";
            worksheet.Cells[1, 3].Value = "Parking Number";
            worksheet.Cells[1, 4].Value = "Parking Type";
            worksheet.Cells[1, 5].Value = "Parking Area";
            worksheet.Cells[1, 6].Value = "Common Parking";
            worksheet.Cells[1, 7].Value = "Status";
            using (var range = worksheet.Cells[1, 1, 1, 7])
            {
                range.Style.Font.Bold = true;
                range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                range.Style.Fill.BackgroundColor.SetColor(Color.Blue);
                range.Style.Font.Color.SetColor(Color.White);
            }
            worksheet.Cells["A1:G1048576"].AutoFilter = true;
            worksheet.Cells.AutoFitColumns(0);
        }
        private void addValidationLists(List<MasterControlDataDTO> resultsParkingType, ExcelPackage package, ExcelWorksheet worksheet)
        {
            addListValidationForProperty(package, worksheet);
            addListValidationForTower(package, worksheet);
            addListValidationForParkingType(package, worksheet, resultsParkingType);
            addListValidationForCommonParking(package, worksheet);
            addListValidationForStatus(package, worksheet);
        }
        private void addListValidationForParkingType(ExcelPackage package, ExcelWorksheet worksheet, List<MasterControlDataDTO> results)
        {
            var validation = worksheet.DataValidations.AddListValidation("D2:D1048576");
            validation.ShowErrorMessage = true;
            validation.ErrorStyle = ExcelDataValidationWarningStyle.stop;
            validation.ErrorTitle = "An invalid value was entered";
            validation.Error = "Select a value from the list";
            foreach (MasterControlDataDTO masterControlDataDTO in results)
            {
                validation.Formula.Values.Add(masterControlDataDTO.Name);
            }
        }
        private void addListValidationForTower(ExcelPackage package, ExcelWorksheet worksheet)
        {
            var validation = worksheet.DataValidations.AddListValidation("B2:B1048576");
            validation.ShowErrorMessage = true;
            validation.ErrorStyle = ExcelDataValidationWarningStyle.stop;
            validation.ErrorTitle = "An invalid value was entered";
            validation.Error = "Select a value from the list";
            foreach (ListItem li in drpSelectPropertyTower.Items)
            {
                if (li.Text != "--Select--")
                    validation.Formula.Values.Add(li.Text);
            }
        }
        private void addListValidationForProperty(ExcelPackage package, ExcelWorksheet worksheet)
        {
            var validation = worksheet.DataValidations.AddListValidation("A2:A1048576");
            validation.ShowErrorMessage = true;
            validation.ErrorStyle = ExcelDataValidationWarningStyle.stop;
            validation.ErrorTitle = "An invalid value was entered";
            validation.Error = "Select a value from the list";
            validation.Formula.Values.Add(drpSelectProperty.SelectedItem.Text);
        }

        private void addListValidationForCommonParking(ExcelPackage package, ExcelWorksheet worksheet)
        {
            var validation = worksheet.DataValidations.AddListValidation("F2:F1048576");
            validation.ShowErrorMessage = true;
            validation.ErrorStyle = ExcelDataValidationWarningStyle.stop;
            validation.ErrorTitle = "An invalid value was entered";
            validation.Error = "Select a value from the list";
            foreach (CommonParking CommonParking in Enum.GetValues(typeof(CommonParking)))
            {
                validation.Formula.Values.Add(CommonParking.ToString());
            }
        }
        private void addListValidationForStatus(ExcelPackage package, ExcelWorksheet worksheet)
        {
            var validation = worksheet.DataValidations.AddListValidation("G2:G1048576");
            validation.ShowErrorMessage = true;
            validation.ErrorStyle = ExcelDataValidationWarningStyle.stop;
            validation.ErrorTitle = "An invalid value was entered";
            validation.Error = "Select a value from the list";
            foreach (ParkingStatus ParkingStatus in Enum.GetValues(typeof(ParkingStatus)))
            {
                validation.Formula.Values.Add(ParkingStatus.ToString());
            }
        }
        public void uploadBulkParkings(object sender, EventArgs e)
        {
            try
            {
                resetPageInfo(PrParkingPageMode.UPLOAD);
                txtPropertyName.Text = drpSelectProperty.SelectedItem.Text;

            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        public void validatePropertyParkings(object sender, EventArgs e)
        {
            if (validateParkingUpload())
            {
                HttpFileCollection uploadedFiles = Request.Files;
                IList<PropertyParkingDTO> results = new List<PropertyParkingDTO>();
                for (int i = 0; i < uploadedFiles.Count; i++)
                {
                    HttpPostedFile userPostedFile = uploadedFiles[i];
                    if (userPostedFile.ContentLength > 0)
                    {
                        string filename = Path.GetFileName(userPostedFile.FileName);
                        string extension = Path.GetExtension(filename);
                        HttpPostedFile file = fileUpload.PostedFile;
                        if (validateFileType(extension))
                        {
                            using (file.InputStream)
                            {
                                ExcelPackage excel = new ExcelPackage(file.InputStream);
                                var workSheet = excel.Workbook.Worksheets[1];
                                IEnumerable<PropertyParkingMapperDTO> newcollection = workSheet.ConvertSheetToObjects<PropertyParkingMapperDTO>();
                                foreach (PropertyParkingMapperDTO propertyParkingMapperDTO in newcollection)
                                {
                                    results.Add(populatePropertyParkingDTO(propertyParkingMapperDTO));
                                }
                            }
                        }
                    }
                    ViewState[VS_PROPERTYUPLOADPARKING_LIST] = results;
                    parkingUploadGrid.DataSource = results;
                    parkingUploadGrid.DataBind();
                }
            }

        }
        public PropertyParkingDTO populatePropertyParkingDTO(PropertyParkingMapperDTO propertyParkingMapperDTO)
        {
            PropertyParkingDTO propertyParkingDTO = new PropertyParkingDTO();
            StringBuilder sb = new StringBuilder();
            try
            {
                UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
                if (!propertyParkingMapperDTO.PropertyName.Equals(txtPropertyName.Text))
                {
                    sb.Append("Unit Belongs to different Property.");
                }
                if (propertyParkingMapperDTO.ParkingNumber == null)
                {
                    sb.Append("Parking Number Missing. ");
                }
                else
                {
                    propertyParkingDTO.ParkingNo = propertyParkingMapperDTO.ParkingNumber;
                }
                if (propertyParkingMapperDTO.ParkingType == null)
                {
                    sb.Append("Parking Type Missing. ");
                }
                else
                {
                    foreach (ListItem li in drpParkingType.Items)
                    {
                        if (li.Text.Equals(propertyParkingMapperDTO.ParkingType))
                        {
                            propertyParkingDTO.ParkingType = CommonUIConverter.getMasterControlDTO(li.Value, propertyParkingMapperDTO.ParkingType);
                        }
                    }
                }
                if (propertyParkingMapperDTO.ParkingArea == null)
                {
                    sb.Append("Parking Area Missing. ");
                }
                else
                {
                    propertyParkingDTO.Area = CommonUtil.getDecimalWithoutExt(propertyParkingMapperDTO.ParkingArea);
                }

                if (propertyParkingMapperDTO.Status == null)
                {
                    sb.Append("Status Missing. ");
                }
                else
                {
                    propertyParkingDTO.Status = EnumHelper.ToEnum<ParkingStatus>(propertyParkingMapperDTO.Status);
                }
                if (propertyParkingMapperDTO.CommonParking == null)
                {
                    sb.Append("Common Parking Missing. ");
                }
                else
                {
                    propertyParkingDTO.CommonParking = EnumHelper.ToEnum<CommonParking>(propertyParkingMapperDTO.CommonParking);

                }
                propertyParkingDTO.FirmNumber = userDefDto.FirmNumber;
                propertyParkingDTO.Version = userDefDto.Version;
                propertyParkingDTO.UpdateUser = userDefDto.Username;
                if (propertyParkingMapperDTO.TowerName == null)
                {
                    sb.Append("Tower Name Missing. ");
                }
                else
                {
                    propertyParkingDTO.PropertyTower = new PropertyTowerDTO();
                    foreach (ListItem li in drpSelectPropertyTower.Items)
                    {
                        if (li.Text.Equals(propertyParkingMapperDTO.TowerName))
                        {
                            propertyParkingDTO.PropertyTower.Id = long.Parse(li.Value);
                            propertyParkingDTO.TowerName = propertyParkingMapperDTO.TowerName;
                        }
                    }
                }
                propertyParkingDTO.InsertUser = userDefDto.Username;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                sb.Append(exp.Message);
            }
            propertyParkingDTO.ErrorMessage = sb.ToString();
            return propertyParkingDTO;
        }
        private bool validateFileType(string extension)
        {
            bool isValid = true;
            if (extension != ".xlsx" && extension != ".xls")
            {
                isValid = false;
                setErrorMessage("Please Select Property Parking Excel with extension xlsx or xls.", tab2ValidationGrp);
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;

        }
        private bool validateParkingUpload()
        {
            bool isValid = true;
            Page.Validate("tab2Error");
            isValid = Page.IsValid;
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        private List<PropertyParkingDTO> getPropertyParkingUploadList()
        {
            return (List<PropertyParkingDTO>)ViewState[VS_PROPERTYUPLOADPARKING_LIST];
        }
        public void addPropertyParkings(object sender, EventArgs e)
        {
            try
            {
                List<PropertyParkingDTO> prParkingList = new List<PropertyParkingDTO>();
                foreach (PropertyParkingDTO propertyParkingDTO in getPropertyParkingUploadList())
                {
                    if (propertyParkingDTO.ErrorMessage == null || propertyParkingDTO.ErrorMessage.Equals(""))
                    {
                        prParkingList.Add(propertyParkingDTO);
                    }
                }
                if (prParkingList != null && prParkingList.Count > 0)
                {
                    PropertyTowerDTO propertyTowerDto = new PropertyTowerDTO();
                    propertyTowerDto.Id = long.Parse(drpSelectPropertyTower.Text);
                    propertyTowerDto.FirmNumber = getUserDefinitionDTO().FirmNumber;
                    propertyTowerDto.PropertyParkings = new HashSet<PropertyParkingDTO>(prParkingList);
                    propertyBO.saveOrUpdatePropertyParking(propertyTowerDto);
                    parkingUploadGrid.DataSource = getPropertyParkingUploadList();
                    parkingUploadGrid.DataBind();
                }
                setSuccessMessage(string.Format(Resources.Messages.success_record_add, "Property Parkings"), tab2Anchor.ID);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }

        }
        protected void cancelPropertyUploadParkings(object sender, EventArgs e)
        {
            resetPageInfo(PrParkingPageMode.NONE);
        }
    }
}