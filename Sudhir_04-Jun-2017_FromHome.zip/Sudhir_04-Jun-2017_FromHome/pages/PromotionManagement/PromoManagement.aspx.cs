﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Vladsm.Web.UI.WebControls;
using ConstroSoft;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Text;

public partial class PromoManagement : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
           log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string tab1ValidationGrp = "tab1Error";
    string VS_PROPERTY = "PROPERTY_LIST";
    string VS_PR_TOWER = "PR_TOWER_LIST";
    string VS_REC_SEARCH_RESULT = "RECIPIENT_SEARCH_RESULT";
    string VS_FILT_REC_SEARCH_RESULT = "FILTERED_RECIPIENT_SEARCH_RESULT";
    string VS_RECIPIENT_LIST = "SEL_REC_LIST";
    string VS_ATTACHMENTS = "ATTACHMENTS";
    string VS_SAVED_DRAFTS = "SAVED_DRAFTS";
    string VS_EMAIL_SENDERS = "EMAIL_SENDERS";
    DropdownBO drpBO = new DropdownBO();
    CustomerBO customerBO = new CustomerBO();
    PromotionManagementBO promoBO = new PromotionManagementBO();
    PropertyBO propertyBO = new PropertyBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                resetPageInfo(PageMode.NONE);
                initDropdowns();
                Page.MaintainScrollPositionOnPostBack = false;
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpEnum<PromotionSearchBy>(drpRecipientSearchBy, null);
        IList<EmailConfigDTO> result = promoBO.fetchEmailConfig(userDefDto.FirmNumber);
        ViewState[VS_EMAIL_SENDERS] = result;
        bindEmailSendersList();
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void applyEntitlement()
    {
        
    }

    private void preRenderInitFormElements()
    {

    }
    public void setErrorMessage(string message, string group)
    {
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }

    public void setErrorMessage(Exception exp, string group)
    {
        string message = Resources.Messages.system_error;
        if (exp is CustomException) message = exp.Message;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }

    public void setSuccessMessage(string msg, string pnlSuccess)
    {
        if (pnlSuccess.Equals(tab1SuccessPanel.ID))
        {
            lbTab1Success.Text = msg;
            tab1SuccessPanel.Visible = true;
        }
        else if (pnlSuccess.Equals(pnlSelectSavedDraftSuccess.ID))
        {
            lbSavedDraftSuccessMsg.Text = msg;
            pnlSelectSavedDraftSuccess.Visible = true;
        }
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private void clearMessages()
    {
        tab1SuccessPanel.Visible = false;
        lbTab1Success.Text = "";
        lbSavedDraftSuccessMsg.Text = "";
        pnlSelectSavedDraftSuccess.Visible = false;
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }

    private void resetPageInfo(PageMode pageMode)
    {
        pageModeHdn.Value = pageMode.ToString();
        initFormFields();

    }
    private void initFormFields()
    {
        bool isReadOnly = (PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
        bool visible = !(PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
        //Buttons

    }
    private List<PropertyDTO> getFilterPropertyList()
    {
        return (List<PropertyDTO>)ViewState[VS_PROPERTY];
    }
    private List<PropertyTowerDTO> getFilterTowerList()
    {
        return (List<PropertyTowerDTO>)ViewState[VS_PR_TOWER];
    }
    private List<PromoRecipient> getCustomerList()
    {
        return (List<PromoRecipient>)ViewState[VS_REC_SEARCH_RESULT];
    }
    private List<PromoRecipient> getFilteredCustomerList()
    {
        return (List<PromoRecipient>)ViewState[VS_FILT_REC_SEARCH_RESULT];
    }
    private Dictionary<string, List<PromoRecipient>> getRecipients()
    {
        return (Dictionary<string, List<PromoRecipient>>)ViewState[VS_RECIPIENT_LIST];
    }
    private List<PromoEmailTemplateDTO> getSavedDraftList()
    {
        return (List<PromoEmailTemplateDTO>)ViewState[VS_SAVED_DRAFTS];
    }
    private List<DocumentDTO> getAttachments()
    {
        return (List<DocumentDTO>)ViewState[VS_ATTACHMENTS];
    }
    private List<EmailConfigDTO> getEmailSenders()
    {
        return (List<EmailConfigDTO>)ViewState[VS_EMAIL_SENDERS];
    }
    private void bindFilterPropertyList()
    {
        List<PropertyDTO> pList = (getFilterPropertyList() != null) ? getFilterPropertyList() : new List<PropertyDTO>();
        propertyListGrid.DataSource = pList;
        propertyListGrid.DataBind();
    }
    private void bindFilterTowerList()
    {
        List<PropertyTowerDTO> ptList = (getFilterTowerList() != null) ? getFilterTowerList() : new List<PropertyTowerDTO>();
        propertyTowerListGrid.DataSource = ptList;
        propertyTowerListGrid.DataBind();
    }
    private void bindFilteredCustomerList()
    {
        List<PromoRecipient> cList = (getFilteredCustomerList() != null) ? getFilteredCustomerList() : new List<PromoRecipient>();
        bool isCustomerFound = cList.Count > 0;
        PromotionSearchBy selectedSearchBy = EnumHelper.ToEnum<PromotionSearchBy>(drpRecipientSearchBy.Text);
        lbNoRecipient.Visible = !isCustomerFound && selectedSearchBy != PromotionSearchBy.NONE;
        customerGrid.Visible = isCustomerFound;
        customerGrid.DataSource = cList;
        customerGrid.DataBind();
    }
    private void bindAttachmentList()
    {
        List<DocumentDTO> docList = (getAttachments() != null) ? getAttachments() : new List<DocumentDTO>();
        attachmentListGrid.DataSource = docList;
        attachmentListGrid.DataBind();
    }
    private void bindSavedDraftsList()
    {
        List<PromoEmailTemplateDTO> savedDraftsList = (getSavedDraftList() != null) ? getSavedDraftList() : new List<PromoEmailTemplateDTO>();
        bool isSavedDraftFound = savedDraftsList.Count > 0;
        lbNoSavedDraft.Visible = !isSavedDraftFound;
        savedDraftGrid.Visible = isSavedDraftFound;
        savedDraftGrid.DataSource = savedDraftsList;
        savedDraftGrid.DataBind();
    }
    private void bindEmailSendersList()
    {
        List<EmailConfigDTO> senderList = (getEmailSenders() != null) ? getEmailSenders() : new List<EmailConfigDTO>();
        emailSenderGrid.DataSource = senderList;
        emailSenderGrid.DataBind();
    }
    private void resetRecipientModal()
    {
        drpRecipientSearchBy.ClearSelection();
        resetSearchSection();
    }
    private void resetSearchSection()
    {
        resetFilter();
        pnlRecipientFilter.Visible = false;
        ViewState[VS_REC_SEARCH_RESULT] = null;
        applyFilterCriteria(-1, -1);
    }
    private void resetFilter()
    {
        lbPropertyFilterText.Text = "Select Property";
        lbTowerFilterText.Text = "Select Tower";
        clearFilterLink.Visible = false;
        propertyListGrid.DataSource = new List<PropertyDTO>();
        propertyListGrid.DataBind();
        List<PropertyDTO> pList = getFilterPropertyList();
        if (pList != null)
        {
            pList.ForEach(x => x.isUISelected = false);
        }
        bindFilterPropertyList();
        ViewState[VS_PR_TOWER] = null;
        bindFilterTowerList();
    }
    private void resetAll()
    {
        pnlEmailSection.Visible = rdEmail.Checked;
        pnlSMSSection.Visible = !rdEmail.Checked;
        savedDraftsLink.Visible = rdEmail.Checked;
        pnlEmailSender.Visible = rdEmail.Checked;
        ViewState[VS_ATTACHMENTS] = new List<DocumentDTO>();
        bindAttachmentList();
        ViewState[VS_RECIPIENT_LIST] = new Dictionary<string, List<PromoRecipient>>();
        recipientDetailsHdn.Value = "";
        txtEmailSubject.Text = "";
        txtEmailBody.Text = "";
        txtSMS.Text = "";
        resetRecipientModal();
        getEmailSenders().ForEach(x => x.isUISelected = false);
        lbEmailSernder.Text = "Select Email";
        bindEmailSendersList();
    }
    protected void onSelectPromoType(object sender, EventArgs e)
    {
        GroupRadioButton rd = (GroupRadioButton)sender;
        resetAll();
    }
    protected void showRecipientModal(object sender, EventArgs e)
    {
        try
        {
            showRecipientModalHdnBtn.Value = "true";
            resetRecipientModal();
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            IList<PropertyDTO> result = propertyBO.fetchAllProperties(userDefDto.FirmNumber);
            ViewState[VS_PROPERTY] = result;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSearchRecipients(object sender, EventArgs e)
    {
        try
        {
            resetSearchSection();
            showRecipientModalHdnBtn.Value = "true";
            PromotionSearchBy selectedSearchBy = EnumHelper.ToEnum<PromotionSearchBy>(drpRecipientSearchBy.Text);
            bindFilterPropertyList();
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            IList<PromoRecipient> results = null;
            if (PromotionSearchBy.All == selectedSearchBy)
            {
                results = promoBO.fetchAllCustomers(userDefDto.FirmNumber);
            }
            else if (PromotionSearchBy.ENQ_CUSTOMERS == selectedSearchBy)
            {
                results = promoBO.fetchEnquiryCustomers(userDefDto.FirmNumber);
            }
            else if (PromotionSearchBy.SALE_CUSTOMERS == selectedSearchBy)
            {
                results = promoBO.fetchUnitSaleCustomers(userDefDto.FirmNumber);
            }
            else
            {
                resetRecipientModal();
            }
            ViewState[VS_REC_SEARCH_RESULT] = results;
            if (results != null && results.Count > 0)
            {
                pnlRecipientFilter.Visible = true;
                applyFilterCriteria(-1, -1);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSelectEmailSender(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            string selectedSender = rd.Attributes["data-eid"];
            if (!string.IsNullOrWhiteSpace(selectedSender))
            {
                getEmailSenders().ForEach(x => x.isUISelected = false);
                EmailConfigDTO selectedSenderDto = getEmailSenders().Find(p => p.Id == long.Parse(selectedSender));
                selectedSenderDto.isUISelected = true;
                lbEmailSernder.Text = selectedSenderDto.Email;
                bindEmailSendersList();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickAddRecipientBtn(object sender, EventArgs e)
    {
        try
        {
            List<PromoRecipient> selectedList = getSelectedCustomers();
            Dictionary<string, List<PromoRecipient>> selectedRecipients = (getRecipients() == null) ? new Dictionary<string, List<PromoRecipient>>() : getRecipients();
            int count = selectedRecipients.Count + 1;
            if (selectedList.Count > 0) selectedRecipients.Add("Group" + count, selectedList);
            ViewState[VS_RECIPIENT_LIST] = selectedRecipients;
            setRecipientHdn();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private void setRecipientHdn()
    {
        Dictionary<string, List<PromoRecipient>> selectedRecipients = getRecipients();
        string toLabelList = "";
        if (selectedRecipients != null)
        {
            foreach (KeyValuePair<string, List<PromoRecipient>> entry in selectedRecipients)
            {
                List<PromoRecipient> tmpList = entry.Value;
                string tmpStr = entry.Value.Count + "~" + entry.Key;
                toLabelList = (toLabelList == "") ? tmpStr : toLabelList + "~~" + tmpStr;
            }
        }
        recipientDetailsHdn.Value = toLabelList;
    }
    private List<PromoRecipient> getSelectedCustomers()
    {
        List<PromoRecipient> selectedList = new List<PromoRecipient>();
        foreach (GridViewRow row in customerGrid.Rows)
        {
            HtmlInputCheckBox checkBox = (HtmlInputCheckBox)row.FindControl("chSelectCustomer");
            if (checkBox != null && checkBox.Checked)
            {
                PromoRecipient selectedCustomer = null;
                if (rdEmail.Checked)
                {
                    string email = checkBox.Attributes["data-email"];
                    selectedCustomer = getFilteredCustomerList().Find(x => x.Email.Equals(email));
                }
                else
                {
                    string contact = checkBox.Attributes["data-contact"];
                    selectedCustomer = getFilteredCustomerList().Find(x => x.Contact.Equals(contact));
                }
                selectedList.Add(selectedCustomer);
            }
        }
        return selectedList;
    }
    protected void onClickRemoveRecipient(object sender, EventArgs e)
    {
        try
        {
            string groupId = recipientToRemoveValHdn.Value;
            Dictionary<string, List<PromoRecipient>> selectedRecipients = getRecipients();
            if (!string.IsNullOrWhiteSpace(groupId))
            {
                selectedRecipients.Remove(groupId);
            }
            setRecipientHdn();
            recipientToRemoveValHdn.Value = "";
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickCloseRecipientBtn(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSelectFilterProperty(object sender, EventArgs e)
    {
        try
        {
            showRecipientModalHdnBtn.Value = "true";
            LinkButton rd = (LinkButton)sender;
            string selectedPropertyId = rd.Attributes["data-pid"];
            if (!string.IsNullOrWhiteSpace(selectedPropertyId))
            {
                clearFilterLink.Visible = true;
                getFilterPropertyList().ForEach(x => x.isUISelected = false);
                PropertyDTO selectedProperty = getFilterPropertyList().Find(p => p.Id == long.Parse(selectedPropertyId));
                selectedProperty.isUISelected = true;
                lbPropertyFilterText.Text = selectedProperty.Name;
                bindFilterPropertyList();
                PromotionSearchBy selectedSearchBy = EnumHelper.ToEnum<PromotionSearchBy>(drpRecipientSearchBy.Text);
                if (PromotionSearchBy.SALE_CUSTOMERS == selectedSearchBy)
                {
                    ViewState[VS_PR_TOWER] = propertyBO.fetchPropertyTowerSelective(getUserDefinitionDTO().FirmNumber, selectedProperty.Id);
                    lbTowerFilterText.Text = "Select Tower";
                    bindFilterTowerList();
                }
                applyFilterCriteria(selectedProperty.Id, -1);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSelectFilterPropertyTower(object sender, EventArgs e)
    {
        try
        {
            showRecipientModalHdnBtn.Value = "true";
            LinkButton rd = (LinkButton)sender;
            string selectedTowerId = rd.Attributes["data-ptid"];
            if (!string.IsNullOrWhiteSpace(selectedTowerId))
            {
                clearFilterLink.Visible = true;
                getFilterTowerList().ForEach(x => x.isUISelected = false);
                PropertyTowerDTO selectedTower = getFilterTowerList().Find(p => p.Id == long.Parse(selectedTowerId));
                selectedTower.isUISelected = true;
                lbTowerFilterText.Text = selectedTower.Name;
                bindFilterTowerList();
                applyFilterCriteria(getFilterPropertyList().Find(x => x.isUISelected).Id, selectedTower.Id);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSelectClearFilter(object sender, EventArgs e)
    {
        try
        {
            showRecipientModalHdnBtn.Value = "true";
            resetFilter();
            applyFilterCriteria(-1, -1);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private void applyFilterCriteria(long propertyId, long towerId)
    {
        List<PromoRecipient> custList = getCustomerList();
        List<PromoRecipient> filteredList = new List<PromoRecipient>();
        if (custList != null)
        {
            foreach (PromoRecipient tmpDto in custList)
            {
                if (isEligibleAsRecipient(tmpDto) && isEligibleAfterFilter(tmpDto, propertyId, towerId)
                    && !filteredList.Any(x => x.Contact.Equals(tmpDto.Contact) && x.Email.Equals(tmpDto.Email)))
                {
                    filteredList.Add(tmpDto);
                }
            }
        }
        ViewState[VS_FILT_REC_SEARCH_RESULT] = filteredList;
        bindFilteredCustomerList();
    }
    private bool isEligibleAsRecipient(PromoRecipient tmpDto)
    {
        bool isEligible = false;

        if (rdEmail.Checked && !string.IsNullOrWhiteSpace(tmpDto.Email))
        {
            isEligible = true;
        }
        else if (rdSMS.Checked && !string.IsNullOrWhiteSpace(tmpDto.Contact))
        {
            isEligible = true;
        }
        return isEligible;
    }
    private bool isEligibleAfterFilter(PromoRecipient tmpDto, long propertyId, long towerId)
    {
        bool isEligible = false;

        if (propertyId <= 0 || (propertyId == tmpDto.PropertyId && (towerId <= 0 || (towerId == tmpDto.TowerId))))
        {
            isEligible = true;
        }
        return isEligible;
    }

    protected void uploadAttachment(object sender, EventArgs e)
    {
        try
        {
            List<DocumentDTO> attachments = (List<DocumentDTO>)ViewState[VS_ATTACHMENTS];
            if (attachments == null)
            {
                attachments = new List<DocumentDTO>();
                ViewState[VS_ATTACHMENTS] = attachments;
            }
            HttpFileCollection uploadedFiles = Request.Files;
            for (int i = 0; i < uploadedFiles.Count; i++)
            {
                HttpPostedFile userPostedFile = uploadedFiles[i];
                if (userPostedFile.ContentLength > 0)
                {
                    DocumentDTO documentDTO = new DocumentDTO();
                    string filename = Path.GetFileName(userPostedFile.FileName);
                    string extension = Path.GetExtension(filename);
                    string contentType = fileUpload.PostedFile.ContentType;
                    HttpPostedFile file = fileUpload.PostedFile;
                    byte[] document = new byte[file.ContentLength];
                    file.InputStream.Read(document, 0, file.ContentLength);
                    documentDTO.Id = attachments.Count + 1;
                    documentDTO.Content = document;
                    documentDTO.FileName = filename;
                    documentDTO.Extension = extension;
                    documentDTO.ContentType = contentType;
                    attachments.Add(documentDTO);
                }
            }
            attachmentListGrid.DataSource = attachments;
            attachmentListGrid.DataBind();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickRemoveAttachment(object sender, EventArgs e)
    {
        try
        {
            List<DocumentDTO> attachments = (List<DocumentDTO>)ViewState[VS_ATTACHMENTS];
            if (attachments == null)
            {
                attachments = new List<DocumentDTO>();
                ViewState[VS_ATTACHMENTS] = attachments;
            }
            if (attachments.Count > 0 && !string.IsNullOrWhiteSpace(attachmentToRemoveValHdn.Value))
            {
                long Id = long.Parse(attachmentToRemoveValHdn.Value);
                DocumentDTO document = attachments.Find(x => x.Id == Id);
                if (document != null) attachments.Remove(document);
            }
            attachmentListGrid.DataSource = attachments;
            attachmentListGrid.DataBind();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void sendEmail(object sender, EventArgs e)
    {
        try
        {
            if (validateEmailSend())
            {
                Dictionary<string, List<PromoRecipient>> recipients = getRecipients();
                HashSet<string> toList = new HashSet<string>();
                foreach (KeyValuePair<string, List<PromoRecipient>> entry in recipients)
                {
                    List<PromoRecipient> tmpList = entry.Value;
                    tmpList.ForEach(x => toList.Add(x.Email));
                }
                if (toList.Count > 0)
                {
                    List<DocumentDTO> attachments = (List<DocumentDTO>)ViewState[VS_ATTACHMENTS];
                    EmailConfigDTO senderConfig = getEmailSenders().Find(x => x.isUISelected);
                    string emailContent = HttpUtility.UrlDecode(txtEmailBody.Text, System.Text.Encoding.Default);
                    promoBO.sendEmail(senderConfig, toList.ToList<string>(), txtEmailSubject.Text, emailContent, attachments);
                    resetAll();
                    setSuccessMessage("Email is sent Successfully.", tab1SuccessPanel.ID);
                }
                else
                {
                    setErrorMessage("Please select Recipients.", tab1ValidationGrp);
                }
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(exp, tab1ValidationGrp);
        }
    }
    protected void sendSMS(object sender, EventArgs e)
    {
        try
        {
            if (validateSMSBody())
            {
                Dictionary<string, List<PromoRecipient>> recipients = getRecipients();
                HashSet<string> toList = new HashSet<string>();
                foreach (KeyValuePair<string, List<PromoRecipient>> entry in recipients)
                {
                    List<PromoRecipient> tmpList = entry.Value;
                    tmpList.ForEach(x => toList.Add(x.Contact));
                }
                if (toList.Count > 0)
                {
                    EmailConfigDTO senderConfig = getEmailSenders().Find(x => x.isUISelected);
                    string smsContent = txtSMS.Text;
                    promoBO.sendSMS(getUserDefinitionDTO().FirmNumber, toList.ToList<string>(), smsContent);
                    resetAll();
                    setSuccessMessage("SMS is sent Successfully.", tab1SuccessPanel.ID);
                }
                else
                {
                    setErrorMessage("Please select Recipients.", tab1ValidationGrp);
                }
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(exp, tab1ValidationGrp);
        }
    }
    protected void discardEmail(object sender, EventArgs e)
    {
        try
        {
            resetAll();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickSaveDraft(object sender, EventArgs e)
    {
        try
        {
            if (validateEmailSubjectAndBody())
            {
                txtEmailDraftName.Text = "";
                showSaveDraftModalHdnBtn.Value = "true";
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void saveDraft(object sender, EventArgs e)
    {
        try
        {
            if (!string.IsNullOrWhiteSpace(txtEmailDraftName.Text))
            {
                UserDefinitionDTO userDef = getUserDefinitionDTO();
                PromoEmailTemplate promoDraft = new PromoEmailTemplate();
                promoDraft.FirmNumber = userDef.FirmNumber;
                promoDraft.InsertDate = DateTime.Now;
                promoDraft.UpdateDate = DateTime.Now;
                promoDraft.InsertUser = userDef.Username;
                promoDraft.UpdateUser = userDef.Username;
                promoDraft.Name = txtEmailDraftName.Text;
                promoDraft.Subject = txtEmailSubject.Text;
                promoDraft.Content = Encoding.ASCII.GetBytes(txtEmailBody.Text);
                promoBO.saveEmailDraft(promoDraft);
                resetAll();
                setSuccessMessage("Email is saved Successfully.", tab1SuccessPanel.ID);
            }
            else
            {
                setErrorMessage("Please enter draft name.", "draftNameError");
                showSaveDraftModalHdnBtn.Value = "true";
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private bool validateEmailSend()
    {
        List<EmailConfigDTO> senderList = getEmailSenders();
        bool result = true;
        if (!senderList.Any<EmailConfigDTO>(x => x.isUISelected))
        {
            setErrorMessage("Please select From Email Address.", tab1ValidationGrp);
            result = false;
        }
        else
        {
            result = validateEmailSubjectAndBody();
        }
        return result;
    }
    private bool validateEmailSubjectAndBody()
    {
        bool result = true;

        if (string.IsNullOrWhiteSpace(txtEmailSubject.Text))
        {
            setErrorMessage("Please enter Subject.", tab1ValidationGrp);
            result = false;
        }
        else if (string.IsNullOrWhiteSpace(txtEmailBody.Text))
        {
            setErrorMessage("Email content cannot be blank.", tab1ValidationGrp);
            result = false;
        }
        return result;
    }
    protected void cancelSaveDraftBtn(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void showSelectDraftModal(object sender, EventArgs e)
    {
        try
        {
            showSelectSavedDraftModalHdnBtn.Value = "true";
            fetchAndLoadSavedDrafts();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void deleteSelectedDraft(object sender, EventArgs e)
    {
        try
        {
            PromoEmailTemplateDTO template = getSelectedDraft();
            if (template != null)
            {
                promoBO.deleteEmailDraft(template.Id);
                setSuccessMessage("Email Draft deleted successfully.", pnlSelectSavedDraftSuccess.ID);
                showSelectSavedDraftModalHdnBtn.Value = "true";
                fetchAndLoadSavedDrafts();
            }
            else if (!lbNoSavedDraft.Visible)
            {
                showSelectSavedDraftModalHdnBtn.Value = "true";
                setErrorMessage("Please select record.", "savedDraftError");
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private void fetchAndLoadSavedDrafts()
    {
        List<PromoEmailTemplateDTO> savedDrafts = promoBO.fetchSavedDrafts(getUserDefinitionDTO().FirmNumber);
        ViewState[VS_SAVED_DRAFTS] = savedDrafts;
        bindSavedDraftsList();
    }
    protected void useSelectedDraft(object sender, EventArgs e)
    {
        try
        {
            PromoEmailTemplateDTO template = getSelectedDraft();
            if (template != null)
            {
                txtEmailSubject.Text = template.Subject;
                txtEmailBody.Text = Encoding.ASCII.GetString(template.Content);
            }
            else if (!lbNoSavedDraft.Visible)
            {
                showSelectSavedDraftModalHdnBtn.Value = "true";
                setErrorMessage("Please select record.", "savedDraftError");
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private PromoEmailTemplateDTO getSelectedDraft()
    {
        PromoEmailTemplateDTO template = null;
        if (savedDraftGrid.Rows.Count > 0)
        {
            foreach (GridViewRow row in savedDraftGrid.Rows)
            {
                GroupRadioButton radio = (GroupRadioButton)row.FindControl("rdSelectDraft");
                Button rowIdenBtn = (Button)row.FindControl("btnSavedDraftRowIdentifier");
                if (radio != null && radio.Checked)
                {
                    string Id = rowIdenBtn.Attributes["row-identifier"];
                    if (!string.IsNullOrWhiteSpace(Id))
                    {
                        List<PromoEmailTemplateDTO> templates = getSavedDraftList();
                        template = templates.Find(x => x.Id == long.Parse(Id));
                    }
                }
            }
        }
        return template;
    }
    private bool validateSMSBody()
    {
        bool result = true;
        if (string.IsNullOrWhiteSpace(txtSMS.Text))
        {
            setErrorMessage("SMS content cannot be blank.", tab1ValidationGrp);
            result = false;
        }
        return result;
    }

}