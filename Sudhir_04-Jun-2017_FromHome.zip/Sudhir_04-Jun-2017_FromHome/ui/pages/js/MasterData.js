﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initMasterDataGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("pnlMasterDataGrid");
    //This script will enable tabs which was last active even after postback call.
    enableTab(true);
}

function initMasterDataGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "masterControlGrid",
        pageLength: 10,
        isViewOnly: isViewOnly,
        responsiveModalTitle: "Master Data",
        customBtnGrpId: "#masSearchBtnDiv",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToMasterDataHdnId");
}