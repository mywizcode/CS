$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initAccountSummaryGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    enableTab(true);
    makeReadOnlySection("pnlAcntSummaryInfo");
}

function initAccountSummaryGrid() {
    var dtOptions = {
        tableId: "acntSummaryGrid",
        pageLength: 10,
        isViewOnly: false,
        customBtnGrpId: "#acntSummaryGridBtnGrp",
        hideSearch: false
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPropertyUnitHdnId");
}