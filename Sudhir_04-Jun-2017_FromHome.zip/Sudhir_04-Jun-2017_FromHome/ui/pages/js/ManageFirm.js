$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initAccountGrid();
    formatFields();
    initViewMode("tab1Content");
    enableTab(false);
}

function initAccountGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "accountGrid",
        pageLength: 5,
        isViewOnly: false,
        responsiveModalTitle: "Account Details",
        customBtnGrpId: "#customBtnDiv",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToAcntHdnId");
}