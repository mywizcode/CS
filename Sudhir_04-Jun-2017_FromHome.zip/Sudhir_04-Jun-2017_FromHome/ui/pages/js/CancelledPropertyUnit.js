﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initCancelledUnitsGrid();
    initTaxGrid();
    initCMTaxGrid();
    initPaymentGrid();
    initCoCustomerGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("tab2Content");
    //This script will enable tabs which was last active even after postback call.
    enableTab(true);

    //makeReadOnlySection("pnlTab2UnitInfo");
    var isModify = ($("[id$='pageModeHdn']").val() == 'MODIFY');
    if (isModify) {
        makeReadOnlySection("pnlTab2BzStep1");
    }
    /*if (!($("[id$='addPymtTypeBtn']").is(":visible"))) {
        makeReadOnlySection("pnlPaymentAdd");
    }*/
}

function initCancelledUnitsGrid() {
    var dtOptions = {
        tableId: "soldUnitsGrid",
        pageLength: 10,
        isViewOnly: false,
        customBtnGrpId: "#soldUnitsSearchBtnDiv",
        hideSearch: false
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToSoldUnitsHdnId");
}
function initTaxGrid() {
    var isViewOnly = true;
    var dtOptions = {
        tableId: "taxDetailGrid",
        pageLength: 5,
        isViewOnly: isViewOnly,
        responsiveModalTitle: "Tax Details",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToTaxDetailHdnId");
}
function initCMTaxGrid() {
    var isViewOnly = true;
    var dtOptions = {
        tableId: "cmTaxDetailGrid",
        pageLength: 5,
        isViewOnly: isViewOnly,
        responsiveModalTitle: "Tax Details",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToCMTaxDetailHdnId");
}
function initCoCustomerGrid() {
    var dtOptions = {
        tableId: "coCustomerGrid",
        pageLength: 5,
        isViewOnly: true,
        responsiveModalTitle: "Co Customer Details",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToCoCustHdnId");
}
function initPaymentGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "paymentGrid",
        pageLength: 5,
        isViewOnly: isViewOnly,
        responsiveModalTitle: "Payment Details",
        customBtnGrpId: "#paymentGridBtnGrp",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPaymentHdnId");
}