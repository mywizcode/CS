﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initAgencyGrid();
    initAddressGrid();
    initDocumentGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("tab2Content");
    enableTab(true);
}

function initAddressGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "addressGrid",
        pageLength: 5,
        isViewOnly: isViewOnly,
        responsiveModalTitle: "Address Details",
        customBtnGrpId: "#addressGridBtnGrp",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToAddressHdnId");
}

function initAgencyGrid() {
    var dtOptions = {
        tableId: "agencyGrid",
        pageLength: 10,
        isViewOnly: false,
        customBtnGrpId: "#agencySearchBtnDiv",
        hideSearch: false
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToAgencyHdnId");
}
function initDocumentGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "documentGrid",
        isViewOnly: isViewOnly,
        pageLength: 5,
        responsiveModalTitle: "Document Details",
        customBtnGrpId: "#documentGridBtnDiv",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToDocumentHdnId");
}