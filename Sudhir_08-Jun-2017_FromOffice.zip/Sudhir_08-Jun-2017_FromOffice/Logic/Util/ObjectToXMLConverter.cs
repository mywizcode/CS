﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Web;
using OfficeOpenXml;
using System.Xml.Serialization;
using System.Xml;
using System.IO;

namespace ConstroSoft.Logic.Util
{
    public static class ObjectToXMLConverter
    {
        private static readonly log4net.ILog log =
             log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public static string Serialize<T>(T dataToSerialize)
        {
            try
            {
                var emptyNamepsaces = new XmlSerializerNamespaces(new[] { XmlQualifiedName.Empty });
                var serializer = new XmlSerializer(dataToSerialize.GetType());
                var settings = new XmlWriterSettings();
                settings.Indent = true;
                settings.OmitXmlDeclaration = true;

                using (var stream = new StringWriter())
                using (var writer = XmlWriter.Create(stream, settings))
                {
                    serializer.Serialize(writer, dataToSerialize, emptyNamepsaces);
                    return stream.ToString();
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                throw exp;
            }
        }
        public static ENVELOPE populateLedgerFromAgency(AgencyDTO agencyDto)
        {
            ENVELOPE envelop = new ENVELOPE();
            HEADER header = new HEADER();
            header.VERSION = "1";
            header.TALLYREQUEST = "Import";
            header.TYPE = "Data";
            header.ID = "All Masters";
            envelop.HEADER = header;

            BODY body = new BODY();
            DATA data = new DATA();
            DESC desc = new DESC();
            body.DESC = desc;
            TALLYMESSAGE tallyMessage = new TALLYMESSAGE();
            LEDGER ledgerMaster = new LEDGER();


            //ledgerMaster.NAME = "Rainbow Advertisement";
            ledgerMaster.NAME = agencyDto.AgencyName;
            ledgerMaster.Action = "Create";

            AddressDTO addressDto = agencyDto.ContactInfo.Addresses.First<AddressDTO>();
            ADDRESS address = new ADDRESS();
            address.ADDRESSES = new List<string>();
            //address1.ADDRESSES.Add("Near Shivar Chowk");
            //address1.ADDRESSES.Add("Rahatani");
            //address1.ADDRESSES.Add("Pune");
            address.ADDRESSES.Add(addressDto.AddressLine1);
            address.ADDRESSES.Add(addressDto.AddressLine2 + " " + addressDto.Town);
            address.ADDRESSES.Add(addressDto.City.Name);
            ledgerMaster.ADDRESS = address;

            MAILINGNAME mailingName = new MAILINGNAME();
            //mailingName.MAILINGNAMES = "Rainbow Advertisement";
            mailingName.MAILINGNAMES = agencyDto.AgencyName;
            ledgerMaster.MAILINGNAME = new List<MAILINGNAME>();
            ledgerMaster.MAILINGNAME.Add(mailingName);
            //ledgerMaster.LNAME = "Rainbow Advertisement";
            ledgerMaster.LNAME = agencyDto.AgencyName;
            //ledgerMaster.PARENT = "Sundry Creditors";
            ledgerMaster.PARENT = agencyDto.Groupname;
            ledgerMaster.OPENINGBALANCE = "0.00";
            //ledgerMaster.EMAIL = "sachin.k@gmail.com";
            ledgerMaster.EMAIL = agencyDto.ContactInfo.Email;
            //ledgerMaster.STATENAME = "Maharashtra";
            ledgerMaster.STATENAME = addressDto.State.Name;
            //ledgerMaster.PINCODE = "400093";
            ledgerMaster.PINCODE = addressDto.Pin;
            //ledgerMaster.INCOMETAXNUMBER = "RSKHM2824K";
            ledgerMaster.INCOMETAXNUMBER = agencyDto.Pan;
            //ledgerMaster.SALESTAXNUMBER = "SALRSKHM282";
            ledgerMaster.SALESTAXNUMBER = agencyDto.Salestaxnumber;
            //ledgerMaster.INTERSTATESTNUMBER = "ITKHM2824K";
            ledgerMaster.INTERSTATESTNUMBER = agencyDto.Centralsalestaxnumber;
            //ledgerMaster.TAXTYPE = "Others";
            ledgerMaster.TAXTYPE = agencyDto.Taxtype;
            //ledgerMaster.EMAILCC = "sachin.k@gmail.com";
            ledgerMaster.EMAILCC = agencyDto.ContactInfo.AltEmail;
            //ledgerMaster.LEDGERPHONE = "022-40864086";
            ledgerMaster.LEDGERPHONE = agencyDto.ContactInfo.Contact;
            //ledgerMaster.LEDGERCONTACT = "Mr. Sachin Kudale";
            ledgerMaster.LEDGERCONTACT = agencyDto.OwnerName;
            //ledgerMaster.LEDGERMOBILE = "+9619896234";
            ledgerMaster.LEDGERMOBILE = agencyDto.ContactInfo.AltContact;
            //ledgerMaster.ISBILLWISEON = "Yes";
            ledgerMaster.ISBILLWISEON = agencyDto.Billwise;
            tallyMessage.LEDGER = ledgerMaster;
            data.TALLYMESSAGE = tallyMessage;
            body.DATA = data;
            envelop.BODY = body;
            return envelop;
        }

        public static ENVELOPE populateLedgerFromCustomer(CustomerDTO customerDto)
        {
            ENVELOPE envelop = new ENVELOPE();
            HEADER header = new HEADER();
            header.VERSION = "1";
            header.TALLYREQUEST = "Import";
            header.TYPE = "Data";
            header.ID = "All Masters";
            envelop.HEADER = header;

            BODY body = new BODY();
            DATA data = new DATA();
            DESC desc = new DESC();
            body.DESC = desc;
            TALLYMESSAGE tallyMessage = new TALLYMESSAGE();
            LEDGER ledgerMaster = new LEDGER();


            //ledgerMaster.NAME = "Rainbow Advertisement";
            string customerName = customerDto.Salutation.Name + " " + customerDto.FirstName + " " + customerDto.MiddleName + " " + customerDto.LastName;
            ledgerMaster.NAME = customerName;
            ledgerMaster.Action = "Create";

            AddressDTO addressDto = customerDto.ContactInfo.Addresses.First<AddressDTO>();
            ADDRESS address = new ADDRESS();
            address.ADDRESSES = new List<string>();
            //address1.ADDRESSES.Add("Near Shivar Chowk");
            //address1.ADDRESSES.Add("Rahatani");
            //address1.ADDRESSES.Add("Pune");
            address.ADDRESSES.Add(addressDto.AddressLine1);
            address.ADDRESSES.Add(addressDto.AddressLine2 + " " + addressDto.Town);
            address.ADDRESSES.Add(addressDto.City.Name);
            ledgerMaster.ADDRESS = address;

            MAILINGNAME mailingName = new MAILINGNAME();
            //mailingName.MAILINGNAMES = "Rainbow Advertisement";
            mailingName.MAILINGNAMES = customerName;
            ledgerMaster.MAILINGNAME = new List<MAILINGNAME>();
            ledgerMaster.MAILINGNAME.Add(mailingName);
            //ledgerMaster.LNAME = "Rainbow Advertisement";
            ledgerMaster.LNAME = customerName;
            //ledgerMaster.PARENT = "Sundry Creditors";
            ledgerMaster.PARENT = customerDto.Groupname;
            ledgerMaster.OPENINGBALANCE = "0.00";
            //ledgerMaster.EMAIL = "sachin.k@gmail.com";
            ledgerMaster.EMAIL = customerDto.ContactInfo.Email;
            //ledgerMaster.STATENAME = "Maharashtra";
            ledgerMaster.STATENAME = addressDto.State.Name;
            //ledgerMaster.PINCODE = "400093";
            ledgerMaster.PINCODE = addressDto.Pin;
            //ledgerMaster.INCOMETAXNUMBER = "RSKHM2824K";
            ledgerMaster.INCOMETAXNUMBER = customerDto.Pan;
            //ledgerMaster.SALESTAXNUMBER = "SALRSKHM282";
            //ledgerMaster.SALESTAXNUMBER = agencyDto.Salestaxnumber;
            //ledgerMaster.INTERSTATESTNUMBER = "ITKHM2824K";
            //ledgerMaster.INTERSTATESTNUMBER = agencyDto.Centralsalestaxnumber;
            //ledgerMaster.TAXTYPE = "Others";
            ledgerMaster.TAXTYPE = customerDto.Taxtype;
            //ledgerMaster.EMAILCC = "sachin.k@gmail.com";
            ledgerMaster.EMAILCC = customerDto.ContactInfo.AltEmail;
            //ledgerMaster.LEDGERPHONE = "022-40864086";
            ledgerMaster.LEDGERPHONE = customerDto.ContactInfo.Contact;
            //ledgerMaster.LEDGERCONTACT = "Mr. Sachin Kudale";
            ledgerMaster.LEDGERCONTACT = customerName;
            //ledgerMaster.LEDGERMOBILE = "+9619896234";
            ledgerMaster.LEDGERMOBILE = customerDto.ContactInfo.AltContact;
            //ledgerMaster.ISBILLWISEON = "Yes";
            ledgerMaster.ISBILLWISEON = customerDto.Billwise;
            tallyMessage.LEDGER = ledgerMaster;
            data.TALLYMESSAGE = tallyMessage;
            body.DATA = data;
            envelop.BODY = body;
            return envelop;
        }
        public static ENVELOPE populateVoucher(PaymentVoucher paymentVoucher)
        {
            VENVELOPE envelop = new VENVELOPE();
            VHEADER header = new VHEADER();
            header.VERSION = "1";
            header.TALLYREQUEST = "Import";
            header.TYPE = "Data";
            header.ID = "Voucher";
            envelop.HEADER = header;

            VBODY body = new VBODY();
            VDATA data = new VDATA();
            VDESC desc = new DESC();
            body.DESC = desc;
            VTALLYMESSAGE tallyMessage = new VTALLYMESSAGE();
            VOUCHER voucher = new VOUCHER();
            voucher.ID = paymentVoucher.ID;
            voucher.VCHTYPE = paymentVoucher.VCHTYPE;
            voucher.ACTION = paymentVoucher.ACTION;
            voucher.VCHDATE = paymentVoucher.VCHDATE;
            voucher.NARRATION = paymentVoucher.NARRATION;
            voucher.VOUCHERTYPENAME = paymentVoucher.VOUCHERTYPENAME;
            voucher.VOUCHERNUMBER = paymentVoucher.VOUCHERNUMBER;
            voucher.PARTYLEDGERNAME = paymentVoucher.PARTYLEDGERNAME;
            voucher.CSTFORMISSUETYPE = paymentVoucher.CSTFORMISSUETYPE;
            voucher.CSTFORMRECVTYPE = paymentVoucher.CSTFORMRECVTYPE;
            voucher.FBTPAYMENTTYPE = paymentVoucher.FBTPAYMENTTYPE;
            voucher.PERSISTEDVIEW = paymentVoucher.PERSISTEDVIEW;
            voucher.VCHGSTCLASS = paymentVoucher.VCHGSTCLASS;
            voucher.VOUCHERTYPEORIGNAME = paymentVoucher.VOUCHERTYPEORIGNAME;
            voucher.EFFECTIVEDATE = paymentVoucher.EFFECTIVEDATE;
            voucher.HASCASHFLOW = paymentVoucher.HASCASHFLOW;
            
            voucher.BILLVLEDGERENTRIES = new List<VLEDGERENTRY>();
            for(PaymentLedger paymentLedger: paymentVoucher.PaymentLedgers){
            	VLEDGERENTRY vLedgerEntry = new VLEDGERENTRY();
            	vLedgerEntry.LEDGERNAME = paymentLedger.LEDGERNAME;
            	vLedgerEntry.GSTCLASS = paymentLedger.GSTCLASS;
            	vLedgerEntry.ISDEEMEDPOSITIVE = paymentLedger.ISDEEMEDPOSITIVE;
            	vLedgerEntry.LEDGERFROMITEM = paymentLedger.LEDGERFROMITEM;
            	vLedgerEntry.REMOVEZEROENTRIES = paymentLedger.REMOVEZEROENTRIES;
            	vLedgerEntry.ISPARTYLEDGER = paymentLedger.ISPARTYLEDGER;
            	vLedgerEntry.ISLASTDEEMEDPOSITIVE = paymentLedger.ISLASTDEEMEDPOSITIVE;
            	vLedgerEntry.AMOUNT = paymentLedger.AMOUNT;
            	vLedgerEntry.VATEXPAMOUNT = paymentLedger.VATEXPAMOUNT;
            	if(paymentLedger.LedgerType.equals("Bill")){
            		vLedgerEntry.BILLALLOCATIONS = new List<BILLALLOCATION>();
            		for(BillAllocation lbillAllocation : paymentLedger.BillAllocations)
            		{
            			BILLALLOCATION billAllocation = new BILLALLOCATION();
            			billAllocation.NAME = lbillAllocation.NAME;
            			billAllocation.BILLTYPE = lbillAllocation.BILLTYPE;
            			billAllocation.TDSDEDUCTEEISSPECIALRATE = lbillAllocation.TDSDEDUCTEEISSPECIALRATE;
            			billAllocation.AMOUNT = lbillAllocation.AMOUNT;
            			vLedgerEntry.BILLALLOCATIONS.add(billAllocation);
            		}
            	}else if(paymentLedger.LedgerType.equals("Bank")){
            		vLedgerEntry.BANKALLOCATIONS = new List<BANKALLOCATION>();
            		for(BANKALLOCATION lbankAllocation : paymentLedger.BankAllocations)
            		{
            			BANKALLOCATION bankAllocation = new BANKALLOCATION();
            			bankAllocation.DATE = lbankAllocation.DATE;
            			bankAllocation.INSTRUMENTDATE = lbankAllocation.INSTRUMENTDATE;
            			bankAllocation.NAME = lbankAllocation.NAME;
            			bankAllocation.TRANSACTIONTYPE = lbankAllocation.TRANSACTIONTYPE;
            			bankAllocation.PAYMENTFAVOURING = lbankAllocation.PAYMENTFAVOURING;
            			bankAllocation.CHEQUECROSSCOMMENT = lbankAllocation.CHEQUECROSSCOMMENT;
            			bankAllocation.INSTRUMENTNUMBER = lbankAllocation.INSTRUMENTNUMBER;
            			bankAllocation.STATUS = lbankAllocation.STATUS;
            			bankAllocation.PAYMENTMODE = lbankAllocation.PAYMENTMODE;
            			bankAllocation.SECONDARYSTATUS = lbankAllocation.SECONDARYSTATUS;
            			bankAllocation.BANKPARTYNAME = lbankAllocation.BANKPARTYNAME;
            			bankAllocation.ISCONNECTEDPAYMENT = lbankAllocation.ISCONNECTEDPAYMENT;
            			bankAllocation.ISSPLIT = lbankAllocation.ISSPLIT;
            			bankAllocation.ISCONTRACTUSED = lbankAllocation.ISCONTRACTUSED;
            			bankAllocation.AMOUNT = lbankAllocation.AMOUNT;
            			vLedgerEntry.BANKALLOCATIONS.add(bankAllocation);
            		}
            		
            	}
            	voucher.BILLVLEDGERENTRIES.add(vLedgerEntry);
            }
            
            tallyMessage.VOUCHER = voucher;
            data.TALLYMESSAGE = tallyMessage;
            body.DATA = data;
            envelop.BODY = body;
            return envelop;
        }

        
    }
}