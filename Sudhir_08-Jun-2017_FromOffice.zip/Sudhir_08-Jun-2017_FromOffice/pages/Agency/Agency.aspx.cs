﻿using ConstroSoft.Logic.BO;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Vladsm.Web.UI.WebControls;

namespace ConstroSoft.pages.Agency
{
    public partial class Agency : System.Web.UI.Page
    {
        private static readonly log4net.ILog log =
            log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string tab1ValidationGrp = "tab1Error";
        string tab2ValidationGrp = "tab2Error";
        string VS_AGENCY_LIST = "AGENCY_LIST";
        string VS_SELECTED_AGENCY = "SELECTED_AGENCY";
        DropdownBO drpBO = new DropdownBO();
        AgencyBO agencyBO = new AgencyBO();
        MasterDataBO masterDataBO = new MasterDataBO();
        public enum AgencyPageMode { ADD, MODIFY, VIEW, NONE }
        protected void Page_Load(object sender, EventArgs e)
        {
            Page.Form.Attributes.Add("enctype", "multipart/form-data");
            clearMessages();
            if (!IsPostBack)
            {
                if (CommonUtil.isSessionActive(Session))
                {
                    resetTabInfo(AgencyPageMode.NONE);
                    initDropdowns();
                    loadSearchGridAndReSelect(0);
                    Page.MaintainScrollPositionOnPostBack = false;
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
        }

        private void initDropdowns()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            drpBO.drpDataBase(drpAgencyType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.AGENCY_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpEnum<AgencySearchBy>(drpSearchBy, null);
            drpBO.drpDataBase(drpAddressCountry, DrpDataType.COUNTRY, null, null, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpAddressState, DrpDataType.STATE, Constants.DEFAULT_COUNTRY, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            initCityDrp(drpAddressCity, Constants.DEFAULT_STATE);
            drpBO.drpDataBase(drpAddressType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ADDRESS_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpEnum<PreferredAddress>(drpPreferredAddress, null);
            drpBO.drpDataBase(drpDocumentType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.DOCUMENT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        }
        protected void Page_PreRender(object sender, EventArgs e)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                applyEntitlement();
                preRenderInitFormElements();
                initBootstrapComponantsFromServer();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        private void applyEntitlement()
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            addAgencyBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.AGENCY_ADD);
            modifyAgencyBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.AGENCY_MODIFY);
            deleteAgencyBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.AGENCY_DELETE);
        }
        private void preRenderInitFormElements()
        {
            AgencyDTO selectedAgency = getCurrentAgency();
            jumpToAgencyHdnId.Value = null;
            jumpToAddressHdnId.Value = null;
            jumpToDocumentHdnId.Value = null;
            if (selectedAgency != null)
            {
                jumpToAgencyHdnId.Value = selectedAgency.Id.ToString();
                List<AddressDTO> addressList = selectedAgency.ContactInfo.Addresses.ToList<AddressDTO>();
                if (addressList != null && addressList.Count > 0)
                {
                    AddressDTO selectedAddress = addressList.Find(a => a.isUISelected);
                    if (selectedAddress != null) jumpToAddressHdnId.Value = selectedAddress.UiIndex.ToString();
                }

                jumpToDocumentHdnId.Value = selectedAgency.Id.ToString();
                List<DocumentDTO> documentList = selectedAgency.DocumentInfo.Documents.ToList<DocumentDTO>();
                if (documentList != null && documentList.Count > 0)
                {
                    DocumentDTO selecteddocument = documentList.Find(a => a.isUISelected);
                    if (selecteddocument != null) jumpToDocumentHdnId.Value = selecteddocument.UiIndex.ToString();
                }
            }
        }
        private AgencyDTO getCurrentAgency()
        {
            return (AgencyDTO)ViewState[VS_SELECTED_AGENCY];
        }
        public void setErrorMessage(string message, string group)
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            this.Page.Validators.Add(val);
        }
        public void setSuccessMessage(string msg, string tabId)
        {
            activeTabHdn.Value = tabId;
            if (tabId.Equals(tab1Anchor.ID))
            {
                lbTab1Success.Text = msg;
                tab1SuccessPanel.Visible = true;
            }
            else if (tabId.Equals(tab2Anchor.ID))
            {
                lbTab2Success.Text = msg;
                tab2SuccessPanel.Visible = true;
            }
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        public void initBootstrapComponantsFromServer()
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
        }
        private void clearMessages()
        {
            tab1SuccessPanel.Visible = false;
            lbTab1Success.Text = "";
            tab2SuccessPanel.Visible = false;
            lbTab2Success.Text = "";
        }
        private UserDefinitionDTO getUserDefinitionDTO()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }

        private void resetTabInfo(AgencyPageMode pageMode)
        {
            tab2Anchor.Visible = true;
            activeTabHdn.Value = tab2Anchor.ID;
            pageModeHdn.Value = pageMode.ToString();
            initFormFields();
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            pnlAddressAdd.Visible = false;
            if (AgencyPageMode.ADD == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.agencym_sm_manage_agency_tab2_add_name;
            }
            else if (AgencyPageMode.MODIFY == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.agencym_sm_manage_agency_tab2_update_name;
            }
            else if (AgencyPageMode.VIEW == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.agencym_sm_manage_agency_tab2_view_name;
            }
            else
            {
                activeTabHdn.Value = tab1Anchor.ID;
                tab2Anchor.Visible = false;
                ViewState[VS_SELECTED_AGENCY] = null;
            }
        }
        private void initFormFields()
        {
            bool isReadOnly = (AgencyPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            bool visible = !(AgencyPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            //Buttons
            btnAddSubmit.Visible = visible;           
            btnAddAddress.Visible = visible;
            btnModifyAddress.Visible = visible;
            btnDeleteAddress.Visible = visible;
            addressGrid.Columns[0].Visible = visible;

            btnAddDocument.Visible = visible;
            btnDeleteDocument.Visible = visible;
            documentGrid.Columns[0].Visible = visible;
        }

        private void fetchSelectedAgency()
        {
            try
            {
                AgencyDTO agencyDto = null;
                if (AgencyPageMode.ADD.ToString().Equals(pageModeHdn.Value))
                {
                    agencyDto = populateAgencyDTOAdd();
                    selectAgencyGridRdBtn(0);
                }
                else if (AgencyPageMode.MODIFY.ToString().Equals(pageModeHdn.Value) || AgencyPageMode.VIEW.ToString().Equals(pageModeHdn.Value))
                {
                    long Id = ((List<AgencyDTO>)ViewState[VS_AGENCY_LIST]).Find(c => c.isUISelected).Id;
                    agencyDto = agencyBO.fetchAgency(Id);
                }
                ViewState[VS_SELECTED_AGENCY] = agencyDto;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void selectAgencyGridRdBtn(long Id)
        {
            if (agencyGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in agencyGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdAgencySelect");
                    Button rowIdenBtn = (Button)row.FindControl("btnAgencyRowIdentifier");
                    if (radioBtn != null)
                    {
                        radioBtn.Checked = false;
                        if (rowIdenBtn != null && Id > 0 && Id.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                        {
                            radioBtn.Checked = true;
                        }
                    }
                }
            }
        }
        private AgencyDTO populateAgencyDTOAdd()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            AgencyDTO agencyDto = new AgencyDTO();
            agencyDto.ContactInfo = new ContactInfoDTO();
            agencyDto.ContactInfo.Addresses = new HashSet<AddressDTO>();
            agencyDto.DocumentInfo = new DocumentInfoDTO();
            agencyDto.DocumentInfo.Documents = new HashSet<DocumentDTO>(); ;
            agencyDto.FirmNumber = userDefDto.FirmNumber;
            agencyDto.InsertUser = userDefDto.Username;
            return agencyDto;
        }
        protected void onClickAddAgencyBtn(object sender, EventArgs e)
        {
            try
            {
                resetTabInfo(AgencyPageMode.ADD);
                fetchSelectedAgency();
                populateUIFieldsFromDTO(null);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        protected void saveModalData(object sender, EventArgs e)
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (modalHdnType.Value == "AGENCY_TYPE")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.AGENCY_TYPE, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "AGENCY_TYPE");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpAgencyType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.AGENCY_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            else if (modalHdnType.Value == "DOCUMENTTYPE")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.DOCUMENT_TYPE, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "DOCUMENTTYPE");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpDocumentType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.DOCUMENT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                modalErrorMsg.Value = errorMsg;
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "setModalErrorMsg", "setModalErrorMsg()", true);
            }
            else
            {
                //Reset the modal fields
                modalInput1.Text = "";
                modalInput2.Text = "";
                modalHdnType.Value = "";
                modalActionHdn.Value = "";
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "closeDialogClient", "closeDialogClient()", true);
            }
        }
        private void doViewModifyAction(AgencyPageMode pageMode)
        {
            resetTabInfo(pageMode);
            fetchSelectedAgency();
            populateUIFieldsFromDTO((AgencyDTO)ViewState[VS_SELECTED_AGENCY]);
        }
        private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
        {
            string errorMsg = "";
            if (string.IsNullOrWhiteSpace(masterDataDto.Name))
            {
                errorMsg = Resources.Messages.validate_agency;
            }
            else if (masterDataBO.isAlreadyExist(masterDataDto))
            {
                errorMsg = string.Format(Resources.Messages.validation_same_name_exist, type);
            }
            return errorMsg;
        }
        private bool validateAgencySelected()
        {
            bool isSelected = true;
            List<AgencyDTO> agencyList = (List<AgencyDTO>)ViewState[VS_AGENCY_LIST];
            if (agencyList != null)
            {
                isSelected = agencyList.Any(c => c.isUISelected);
                if (!isSelected)
                {
                    resetTabInfo(AgencyPageMode.NONE);
                    setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Agency"), tab1ValidationGrp);
                }
            }
            return isSelected;
        }
        protected void onClickViewAgencyBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateAgencySelected())
                {
                    doViewModifyAction(AgencyPageMode.VIEW);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        protected void onClickModifyAgencyBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateAgencySelected())
                {
                    doViewModifyAction(AgencyPageMode.MODIFY);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        protected void deleteAgency(object sender, EventArgs e)
        {
            try
            {
                if (validateAgencySelected())
                {
                    long Id = ((List<AgencyDTO>)ViewState[VS_AGENCY_LIST]).Find(c => c.isUISelected).Id;
                    agencyBO.deleteAgency(Id);
                    loadSearchGridAndReSelect(0);
                    resetTabInfo(AgencyPageMode.NONE);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_delete, "Agency"), tab1Anchor.ID);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        private void populateAgencyDTOFromUI(AgencyDTO agencyDto)
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            agencyDto.AgencyName = txtAgencyName.Text;
            agencyDto.Description = txtComments.Text;
            agencyDto.OwnerName = txtOwnerName.Text;
            agencyDto.AgencyType = CommonUIConverter.getMasterControlDTO(drpAgencyType.Text, null);
            agencyDto.RegistrationNo = txtRegistrationNumber.Text;
            agencyDto.ContactInfo.Contact = txtContact.Text;
            agencyDto.ContactInfo.AltContact = txtAltContact.Text;
            agencyDto.ContactInfo.Email = txtEmail.Text;
            agencyDto.ContactInfo.AltEmail = txtAltEmailID.Text;
            agencyDto.UpdateUser = userDefDto.Username;
            agencyDto.Version = userDefDto.Version;
        }
        private void populateUIFieldsFromDTO(AgencyDTO agencyDto)
        {
            if (agencyDto != null) txtOwnerName.Text = agencyDto.OwnerName; else txtOwnerName.Text = null;
            if (agencyDto != null) txtAgencyName.Text = agencyDto.AgencyName; else txtAgencyName.Text = null;
            if (agencyDto != null) txtRegistrationNumber.Text = agencyDto.RegistrationNo; else txtRegistrationNumber.Text = null;
            if (agencyDto != null) txtContact.Text = agencyDto.ContactInfo.Contact; else txtContact.Text = null;
            if (agencyDto != null) txtAltContact.Text = agencyDto.ContactInfo.AltContact; else txtAltContact.Text = null;
            if (agencyDto != null) txtEmail.Text = agencyDto.ContactInfo.Email; else txtEmail.Text = null;
            if (agencyDto != null) txtAltEmailID.Text = agencyDto.ContactInfo.AltEmail; else txtAltEmailID.Text = null;
            if (agencyDto != null) txtComments.Text = agencyDto.Description; else txtDescription.Text = null;
            if (agencyDto != null && agencyDto.AgencyType != null) drpAgencyType.Text = agencyDto.AgencyType.Id.ToString(); else drpAgencyType.ClearSelection();
            populateAddressGrid(agencyDto);
            populateDocumentGrid(agencyDto);
        }
        private void populateAddressGrid(AgencyDTO agencyDto)
        {
            addressGrid.DataSource = new List<AddressDTO>();
            if (agencyDto != null)
            {
                assignUiIndexToAddress(agencyDto.ContactInfo.Addresses);
                addressGrid.DataSource = agencyDto.ContactInfo.Addresses;
            }
            addressGrid.DataBind();
        }

        private void assignUiIndexToAddress(ISet<AddressDTO> addressDtos)
        {
            if (addressDtos != null && addressDtos.Count > 0)
            {
                long uiIndex = 1;
                foreach (AddressDTO addressDto in addressDtos)
                {
                    addressDto.UiIndex = uiIndex++;
                    addressDto.RowInfo = CommonUIConverter.getGridViewRowInfo(addressDto);
                }
            }
        }

        private bool validateAgency()
        {
            bool isValid = true;
            Page.Validate("tab2Error");
            isValid = Page.IsValid;
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        protected void cancelAgency(object sender, EventArgs e)
        {
            AgencyDTO agencyDto = getCurrentAgency();
            resetTabInfo(AgencyPageMode.NONE);
            loadSearchGridAndReSelect(agencyDto.Id);
        }
        private void loadSearchGridAndReSelect(long Id)
        {
            try
            {
                AgencySearchBy searchBy = EnumHelper.ToEnum<AgencySearchBy>(drpSearchBy.Text);
                long searchByValId = -1;
                if (!string.IsNullOrWhiteSpace(drpSearchByValue.Text)) searchByValId = long.Parse(drpSearchByValue.Text);
                IList<AgencyDTO> results = agencyBO.fetchAgencyGridData(getUserDefinitionDTO().FirmNumber, searchBy, searchByValId);
                ViewState[VS_AGENCY_LIST] = results;
                agencyGrid.DataSource = results;
                agencyGrid.DataBind();
                if (Id > 0)
                {
                    selectAgencyGridRdBtn(Id);
                    setSelectedAgency(Id);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        private void setSelectedAgency(long selectedId)
        {
            List<AgencyDTO> AGENCYList = (List<AgencyDTO>)ViewState[VS_AGENCY_LIST];
            if (AGENCYList != null)
            {
                AGENCYList.ForEach(c => c.isUISelected = false);
                AGENCYList.Find(c => c.Id == selectedId).isUISelected = true;
            }
        }



        //Address Table actions - Start
        private void initAddressAddUpdateSection(bool isAdd)
        {
            lbAddUpdateSectionHeader.Text = (isAdd) ? Resources.Labels.label_sectionheader_add_address : Resources.Labels.label_sectionheader_modify_address;
            pnlAddressAdd.Visible = true;
            btnAddressAddToGrid.Visible = isAdd;
            btnAddressUpdateToGrid.Visible = !isAdd;
            drpAddressState.Text = Constants.DEFAULT_STATE;
        }
        private void setDefaultOnAddAddress()
        {
            drpAddressState.Text = Constants.DEFAULT_STATE;
            drpPreferredAddress.Text = PreferredAddress.No.ToString();
        }
        private void initAddressSectionFields(AddressDTO addressDto)
        {
            if (addressDto != null) txtAddressLine1.Text = addressDto.AddressLine1; else txtAddressLine1.Text = null;
            if (addressDto != null) txtAddressLine2.Text = addressDto.AddressLine2; else txtAddressLine2.Text = null;
            if (addressDto != null) txtTown.Text = addressDto.Town; else txtTown.Text = null;
            if (addressDto != null && addressDto.City != null) drpAddressCity.Text = addressDto.City.Id.ToString(); else drpAddressCity.ClearSelection();
            if (addressDto != null && addressDto.State != null) drpAddressState.Text = addressDto.State.Id.ToString(); else drpAddressState.ClearSelection();
            if (addressDto != null && addressDto.Country != null) drpAddressCountry.Text = addressDto.Country.Id.ToString(); else drpAddressCountry.ClearSelection();
            if (addressDto != null) txtPin.Text = addressDto.Pin; else txtPin.Text = null;
            if (addressDto != null && addressDto.AddressType != null) drpAddressType.Text = addressDto.AddressType.Id.ToString(); else drpAddressType.ClearSelection();
            if (addressDto != null && addressDto.PreferredAddress != null) drpPreferredAddress.Text = addressDto.PreferredAddress.ToString(); else drpPreferredAddress.ClearSelection();
        }
        private void clearAddressViewState()
        {
            if (addressGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in addressGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdAddressSelect");
                    if (radioBtn != null) radioBtn.Checked = false;
                }
            }
            getCurrentAgency().ContactInfo.Addresses.ToList<AddressDTO>().ForEach(c => c.isUISelected = false);
        }
        private AddressDTO getSelectedAddress()
        {
            return getCurrentAgency().ContactInfo.Addresses.ToList<AddressDTO>().Find(c => c.isUISelected);
        }
        private void initCityDrp(DropDownList drp, string stateId)
        {
            drpBO.drpDataBase(drp, DrpDataType.CITY, stateId, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
        }
        private bool validateAddressSelected()
        {
            bool isSelected = true;
            AddressDTO addressDto = getSelectedAddress();
            if (addressDto == null)
            {
                isSelected = false;
                pnlAddressAdd.Visible = false;
                clearAddressViewState();
                setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Address"), tab2ValidationGrp);
            }
            return isSelected;
        }

        private void populateAddressFromUI(AddressDTO addressDto)
        {
            addressDto.AddressLine1 = txtAddressLine1.Text;
            addressDto.AddressLine2 = txtAddressLine2.Text;
            addressDto.Town = txtTown.Text;
            addressDto.City = CommonUIConverter.getCityDTO(drpAddressCity.Text, drpAddressCity.SelectedItem.Text);
            addressDto.State = CommonUIConverter.getStateDTO(drpAddressState.Text, drpAddressState.SelectedItem.Text);
            addressDto.Country = CommonUIConverter.getCountryDTO(drpAddressCountry.Text, drpAddressCountry.SelectedItem.Text);
            addressDto.Pin = txtPin.Text;
            addressDto.AddressType = CommonUIConverter.getMasterControlDTO(drpAddressType.Text, drpAddressType.SelectedItem.Text);
            addressDto.PreferredAddress = EnumHelper.ToEnumNullable<PreferredAddress>(drpPreferredAddress.Text);
        }
        protected void loadCities(object sender, EventArgs e)
        {
            initCityDrp(drpAddressCity, drpAddressState.Text);
            SetFocus(drpAddressCity);
        }
        protected void selectAddress(object sender, EventArgs e)
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            pnlAddressAdd.Visible = false;
            if (rd.Checked)
            {
                long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnAddressRowIdentifier"))).Attributes["row-identifier"]);
                List<AddressDTO> addressList = getCurrentAgency().ContactInfo.Addresses.ToList<AddressDTO>();
                addressList.ForEach(c => c.isUISelected = false);
                addressList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
            }
        }
        protected void onClickAddAddressBtn(object sender, EventArgs e)
        {
            try
            {
                initAddressAddUpdateSection(true);
                initAddressSectionFields(null);
                setDefaultOnAddAddress();
                SetFocus(txtAddressLine1);
                scrollToFieldHdn.Value = pnlAddressAdd.ID;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void onClickModifyAddressBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateAddressSelected())
                {
                    initAddressAddUpdateSection(false);
                    initAddressSectionFields(getSelectedAddress());
                    SetFocus(txtAddressLine1);
                    scrollToFieldHdn.Value = pnlAddressAdd.ID;
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void deleteAddress(object sender, EventArgs e)
        {
            try
            {
                if (validateAddressSelected())
                {
                    AgencyDTO agencyDto = getCurrentAgency();
                    AddressDTO addressDto = getSelectedAddress();
                    agencyDto.ContactInfo.Addresses.Remove(addressDto);
                    pnlAddressAdd.Visible = false;
                    clearAddressViewState();
                    populateAddressGrid(agencyDto);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, "Address"), tab2Anchor.ID);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void addNewAddress(object sender, EventArgs e)
        {
            try
            {
                if (validateAddress())
                {
                    AgencyDTO agencyDto = getCurrentAgency();
                    AddressDTO addressDto = new AddressDTO();
                    populateAddressFromUI(addressDto);
                    agencyDto.ContactInfo.Addresses.Add(addressDto);
                    pnlAddressAdd.Visible = false;
                    clearAddressViewState();
                    populateAddressGrid(agencyDto);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, "Address"), tab2Anchor.ID);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void updateAddress(object sender, EventArgs e)
        {
            try
            {
                if (validateAddress())
                {
                    AgencyDTO agencyDto = getCurrentAgency();
                    AddressDTO addressDto = getSelectedAddress();
                    populateAddressFromUI(addressDto);
                    pnlAddressAdd.Visible = false;
                    clearAddressViewState();
                    populateAddressGrid(agencyDto);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_updatedtotable, "Address"), tab2Anchor.ID);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void cancelAddress(object sender, EventArgs e)
        {
            pnlAddressAdd.Visible = false;
            clearAddressViewState();
        }
        private bool validateAddress()
        {
            bool isValid = true;
            Page.Validate("tab2ErrorGrid1");
            isValid = Page.IsValid;
            if (drpPreferredAddress.Text.Equals(PreferredAddress.Yes.ToString()) && isValid)
            {
                List<AddressDTO> addressList = getCurrentAgency().ContactInfo.Addresses.ToList<AddressDTO>();
                bool isPreferred = addressList.Any(c => (c.PreferredAddress == PreferredAddress.Yes && !c.isUISelected));
                if (isPreferred)
                {
                    isValid = false;
                    setErrorMessage(Resources.Messages.validation_address_one_preferred, tab2ValidationGrp);
                }
            }
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        //Address Table actions - END

        //Document Table actions - Start
        private void initDocumentAddUpdateSection(bool isAdd)
        {
            lbDocumentAddUpdateSectionHeader.Text = (isAdd) ? Resources.Labels.label_sectionheader_document_add : Resources.Labels.label_sectionheader_document_modify;
            pnlDocumentAdd.Visible = true;
            btnDocumentAddToGrid.Visible = isAdd;
        }

        private void initDocumentInfoSectionFields(DocumentDTO documentDto)
        {
            if (documentDto != null) txtDocumentName.Text = documentDto.Name; else txtDocumentName.Text = null;
            if (documentDto != null) drpDocumentType.Text = documentDto.DocumentType.Name + ""; else drpDocumentType.ClearSelection();
            if (documentDto != null) txtDescription.Text = documentDto.Description; else txtDescription.Text = null;
        }
        private void clearDocumentViewState()
        {
            if (documentGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in documentGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdAgencySelect");
                    if (radioBtn != null) radioBtn.Checked = false;
                }
            }
            getCurrentAgency().DocumentInfo.Documents.ToList<DocumentDTO>().ForEach(c => c.isUISelected = false);
        }
        private DocumentDTO getSelectedDocument()
        {
            return getCurrentAgency().DocumentInfo.Documents.ToList<DocumentDTO>().Find(c => c.isUISelected);
        }
        protected void onSearchBy(object sender, EventArgs e)
        {
            try
            {
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                AgencySearchBy searchBy = EnumHelper.ToEnum<AgencySearchBy>(drpSearchBy.Text);
                drpSearchByValue.Visible = true;
                lbSearchByValue.Visible = true;
                lbSearchByValue.Text = EnumHelper.GetEnumDescription<AgencySearchBy>(searchBy.ToString());
                if (AgencySearchBy.Agency_Name == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.AGENCY_SEARCHBY_AGENCYNAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (AgencySearchBy.Agency_Type == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.AGENCY_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (AgencySearchBy.Owner_Name == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.AGENCY_SEARCHBY_OWNERNAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else
                {
                    drpSearchByValue.ClearSelection();
                    drpSearchByValue.Visible = false;
                    lbSearchByValue.Visible = false;
                }
                loadSearchGridAndReSelect(0);
                resetTabInfo(AgencyPageMode.NONE);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        protected void selectAgency(object sender, EventArgs e)
        {
            try
            {
                GroupRadioButton rd = (GroupRadioButton)sender;
                resetTabInfo(AgencyPageMode.NONE);
                if (rd.Checked)
                {
                    string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnAgencyRowIdentifier"))).Attributes["row-identifier"];
                    setSelectedAgency(long.Parse(strId));
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        protected void onSearchByValue(object sender, EventArgs e)
        {
            loadSearchGridAndReSelect(0);
            resetTabInfo(AgencyPageMode.NONE);
        }

        protected void selectDocument(object sender, EventArgs e)
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            pnlDocumentAdd.Visible = false;
            if (rd.Checked)
            {
                long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnAgencyRowIdentifier"))).Attributes["row-identifier"]);
                List<DocumentDTO> documentList = getCurrentAgency().DocumentInfo.Documents.ToList<DocumentDTO>();
                documentList.ForEach(c => c.isUISelected = false);
                documentList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
            }
        }
        protected void onClickAddDocumentBtn(object sender, EventArgs e)
        {
            try
            {
                initDocumentAddUpdateSection(true);
                initDocumentInfoSectionFields(null);
                SetFocus(txtDocumentName);
                scrollToFieldHdn.Value = pnlDocumentAdd.ID;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }

        protected void deleteDocument(object sender, EventArgs e)
        {
            try
            {
                if (validateDocumentSelected())
                {
                    AgencyDTO agencyDTO = getCurrentAgency();
                    DocumentDTO DocumentDto = getSelectedDocument();
                    agencyDTO.DocumentInfo.Documents.Remove(DocumentDto);
                    List<DocumentDTO> documentList = getDocumentList();
                    reBindDocumentGrid(documentList, null);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, "Document"));
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }

        private bool validateDocumentSelected()
        {
            bool isSelected = true;
            DocumentDTO selectedDocument = getSelectedDocument();
            if (selectedDocument == null)
            {
                isSelected = false;
                setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Document"), tab2ValidationGrp);
            }
            return isSelected;
        }

        protected void addNewDocument(object sender, EventArgs e)
        {
            try
            {
                if (validateDocument())
                {
                    DocumentDTO documentDto = populateDocumentDTOAddFromUI();
                    AgencyDTO agencyDTO = getCurrentAgency();
                    List<DocumentDTO> documentList = new List<DocumentDTO>();
                    if (agencyDTO.DocumentInfo == null)
                    {
                        DocumentInfoDTO documentInfoDTO = new DocumentInfoDTO();
                        agencyDTO.DocumentInfo = documentInfoDTO;
                        agencyDTO.DocumentInfo.Documents = new HashSet<DocumentDTO>();
                    }
                    agencyDTO.DocumentInfo.Documents.Add(documentDto);
                    documentList = agencyDTO.DocumentInfo.Documents.ToList();
                    pnlDocumentAdd.Visible = false;
                    reBindDocumentGrid(documentList, documentDto);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, "Document"));
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        public void setSuccessMessage(string msg)
        {
            lbTab2Success.Text = msg;
            tab2SuccessPanel.Visible = true;
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        private void reBindDocumentGrid(List<DocumentDTO> documentList, DocumentDTO documentDTO)
        {
            if (documentList != null)
            {
                assignUiIndexToDocument(documentList);
                documentGrid.DataSource = documentList;
                documentGrid.DataBind();
                if (documentDTO != null) resetDocumentSelection(documentDTO.UiIndex);
            }
        }

        private void assignUiIndexToDocument(List<DocumentDTO> documentDtos)
        {
            if (documentDtos != null && documentDtos.Count > 0)
            {
                documentDtos.ForEach(c => c.isUISelected = false);
                long uiIndex = 1;
                foreach (DocumentDTO documentDto in documentDtos)
                {
                    documentDto.UiIndex = uiIndex++;
                    documentDto.RowInfo = CommonUIConverter.getGridViewRowInfo(documentDto);
                }
            }
        }

        private void populateDocumentGrid(AgencyDTO agencyDto)
        {
            documentGrid.DataSource = new List<DocumentDTO>();
            if (agencyDto != null)
            {
                assignUiIndexToDocuments(agencyDto.DocumentInfo.Documents);
                documentGrid.DataSource = agencyDto.DocumentInfo.Documents;
            }
            documentGrid.DataBind();
        }
        private void assignUiIndexToDocuments(ISet<DocumentDTO> documentDtos)
        {
            if (documentDtos != null && documentDtos.Count > 0)
            {
                long uiIndex = 1;
                foreach (DocumentDTO documentDto in documentDtos)
                {
                    documentDto.UiIndex = uiIndex++;
                    documentDto.RowInfo = CommonUIConverter.getGridViewRowInfo(documentDto);
                }
            }
        }
        private void resetDocumentSelection(long uiIndex)
        {
            if (documentGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in documentGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdDocumentSelect");
                    radioBtn.Checked = false;
                    if (uiIndex > 0)
                    {
                        Button rowIdenBtn = (Button)row.FindControl("btnDocumentRowIdentifier");
                        if (rowIdenBtn != null && uiIndex.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                        {
                            radioBtn.Checked = true;
                            setSelectedDocument(uiIndex);
                        }
                    }
                }
            }
            if (uiIndex <= 0) setSelectedDocument(-1);
        }
        private void setSelectedDocument(long selectedUiIndex)
        {
            List<DocumentDTO> documentList = getDocumentList();
            if (documentList != null)
            {
                documentList.ForEach(c => c.isUISelected = false);
                if (selectedUiIndex != -1) documentList.Find(c => c.UiIndex == selectedUiIndex).isUISelected = true;
            }
        }
        private List<DocumentDTO> getDocumentList()
        {
            List<DocumentDTO> documentList = new List<DocumentDTO>();
            AgencyDTO agencyDTO = getCurrentAgency();
            documentList = agencyDTO.DocumentInfo.Documents.ToList();
            return documentList;
        }
        private bool validateDocument()
        {
            bool isValid = true;
            Page.Validate("tab2ErrorGrid1");
            isValid = Page.IsValid;
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        protected void onSelectDocument(object sender, EventArgs e)
        {
            try
            {
                GroupRadioButton rd = (GroupRadioButton)sender;
                pnlDocumentAdd.Visible = false;
                if (rd.Checked)
                {
                    long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnDocumentRowIdentifier"))).Attributes["row-identifier"]);
                    setSelectedDocument(UiIndex);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }

        private DocumentDTO populateDocumentDTOAddFromUI()
        {
            UserDefinitionDTO userDef = getUserDefinitionDTO();
            DocumentDTO documentDTO = new DocumentDTO();
            documentDTO.Name = txtDocumentName.Text;
            documentDTO.DocumentType = CommonUIConverter.getMasterControlDTO(drpDocumentType.Text, drpDocumentType.SelectedItem.Text);
            HttpFileCollection uploadedFiles = Request.Files;
            for (int i = 0; i < uploadedFiles.Count; i++)
            {
                HttpPostedFile userPostedFile = uploadedFiles[i];
                if (userPostedFile.ContentLength > 0)
                {
                    string filename = Path.GetFileName(userPostedFile.FileName);
                    string extension = Path.GetExtension(filename);
                    string contentType = fileUpload.PostedFile.ContentType;
                    HttpPostedFile file = fileUpload.PostedFile;
                    byte[] document = new byte[file.ContentLength];
                    file.InputStream.Read(document, 0, file.ContentLength);
                    documentDTO.Content = document;
                    documentDTO.FileName = filename;
                    documentDTO.Extension = extension;
                    documentDTO.ContentType = contentType;
                }
            }
            documentDTO.Description = txtDescription.Text;
            documentDTO.FirmNumber = userDef.FirmNumber;
            documentDTO.InsertUser = userDef.Username;
            documentDTO.UpdateUser = userDef.Username;
            documentDTO.InsertDate = DateTime.Now;
            documentDTO.UpdateDate = DateTime.Now;
            return documentDTO;
        }
        protected void cancelDocument(object sender, EventArgs e)
        {
            pnlDocumentAdd.Visible = false;
            clearDocumentViewState();
        }
        protected void onClickDownloadDocumentBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateDocumentSelected())
                {
                    DocumentDTO documentDTO = getSelectedDocument();
                    registerPostBackControl();
                    Response.Buffer = true;
                    Response.Charset = "";
                    Response.Cache.SetCacheability(HttpCacheability.NoCache);
                    Response.ContentType = documentDTO.ContentType;
                    Response.AppendHeader("Content-Disposition", "attachment; filename=" + documentDTO.FileName);
                    Response.BinaryWrite(documentDTO.Content);
                    Response.Flush();
                    //Response.End();
                    UpdatePanel1.Update();
                    initBootstrapComponantsFromServer();
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        private void registerPostBackControl()
        {
            ScriptManager.GetCurrent(this).RegisterPostBackControl(btnDeleteDocument);
        }

        protected void addOrModifyAgency(object sender, EventArgs e)
        {
            try
            {
                if (validateAgency())
                {
                    AgencyDTO agencyDto = getCurrentAgency();
                    long Id = agencyDto.Id;
                    populateAgencyDTOFromUI(agencyDto);
                    if (AgencyPageMode.ADD.ToString().Equals(pageModeHdn.Value))
                    {
                        Id = agencyBO.saveAgency(agencyDto);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_add, "Agency"), tab2Anchor.ID);
                    }
                    else if (AgencyPageMode.MODIFY.ToString().Equals(pageModeHdn.Value))
                    {
                        agencyBO.updateAgency(agencyDto);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_update, "Agency"), tab2Anchor.ID);
                    }
                    loadSearchGridAndReSelect(Id);
                    doViewModifyAction(AgencyPageMode.VIEW);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
     
    }
}