﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft.Logic.BO;

namespace ConstroSoft.pages.UserProfile
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        private static readonly log4net.ILog log =
              log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string tab1ValidationGrp = "tab1Error";      
        
        string VS_SELECTED_USER = "SELECTED_USER";
        DropdownBO drpBO = new DropdownBO();        
        MasterDataBO masterDataBO = new MasterDataBO();
        UserDefinationBO userDefinationBO = new UserDefinationBO();
        FirmMemberDTO firmmemberdto = new FirmMemberDTO();
        UserDefinitionDTO userdefinationDto = new UserDefinitionDTO();
        public enum UserProfilePageMode { MODIFY, VIEW }
        protected void Page_Load(object sender, EventArgs e)
        {
            clearMessages();
            if (!IsPostBack)
            {
                if (Session[Constants.Session.USERNAME] != null)
                {
                    resetTabInfo(PageMode.VIEW);
                    
                    fetchSelectedUser();
                    Page.MaintainScrollPositionOnPostBack = false;
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }

        }
        
        private UserDefinitionDTO getUserInfoDto()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }
        private void preRenderInitFormElements()
        {
            UserDefinitionDTO selectedUser = getCurrentUser();
            jumpToUserHdnId.Value = null;           
            if (selectedUser != null)
            {
                jumpToUserHdnId.Value = selectedUser.Id.ToString();               
            }
            
        }
       
        protected void Page_PreRender(object sender, EventArgs e)
        {
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        private UserDefinitionDTO getCurrentUser()
        {
            return (UserDefinitionDTO)ViewState[VS_SELECTED_USER];
        }

        public void setErrorMessage(string message, string group)
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            this.Page.Validators.Add(val);
        }
        public void setSuccessMessage(string msg)
        {
           
                lbTab1Success.Text = msg;
                tab1SuccessPanel.Visible = true; 
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        public void initBootstrapComponantsFromServer()
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
        }
        private void clearMessages()
        {
            tab1SuccessPanel.Visible = false;
            lbTab1Success.Text = "";            
        }
        private UserDefinitionDTO getUserDefinitionDTO()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }

        protected void ChangePassword(object sender, EventArgs e)
        {
            Response.Redirect(Constants.URL.ChangePassword, false);
        }

        private void resetTabInfo(PageMode pageMode)
        {
          
            pageModeHdn.Value = pageMode.ToString();
            initFormFields();
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;           
            
            if (PageMode.MODIFY == pageMode)
            {
                txtDOB.ReadOnly = false;
                txtContact.ReadOnly = false;
                txtAltContact.ReadOnly = false;
                initFormFields();
            }
            else
            {
                txtDOB.ReadOnly = true;
                txtContact.ReadOnly = true;
                txtAltContact.ReadOnly = true;
                initFormFields();
            }
        }
        private void initFormFields()
        {
            bool isReadOnly = (PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            bool visible = !(PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
           
        }

        protected void UpdateProfile(object sender, EventArgs e)
        {
            try
            {
                if (validateUserProfile())
                {
                    UserDefinitionDTO userDef = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
                    populateUserDTOFromUI(userDef);
                    if (PageMode.MODIFY.ToString().Equals(pageModeHdn.Value))
                    {
                        userDefinationBO.updateUserProfile(userDef);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_update, "User Profile"));
                    }
                    resetTabInfo(PageMode.NONE);
                    fetchSelectedUser();
                }
                
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }

        }

        private void populateUserDTOFromUI(UserDefinitionDTO userdefinationDTO)
        {
            if (!string.IsNullOrWhiteSpace(txtDOB.Text))
                userdefinationDTO.FirmMember.ContactInfo.Dob = DateTime.ParseExact(txtDOB.Text, Constants.DATE_FORMAT, CultureInfo.InvariantCulture);
            else userdefinationDTO.FirmMember.ContactInfo.Dob = null;

            userdefinationDTO.FirmMember.ContactInfo.Contact = txtContact.Text;
            userdefinationDTO.FirmMember.ContactInfo.AltContact = txtAltContact.Text;
            
        }
        private bool validateUserProfile()
        {
            bool isValid = true;
            Page.Validate("tab1Error");
            isValid = Page.IsValid;
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        protected void UpdatePassword(object sender, EventArgs e)
        {

        }

        protected void onClickEditUserProfile(object sender, EventArgs e)
        {
            setTabInfo(UserProfilePageMode.MODIFY);
            resetTabInfo(PageMode.MODIFY);
            fetchSelectedUser();
        }
        private void setTabInfo(UserProfilePageMode pageMode)
        {
            pageModeHdn.Value = pageMode.ToString();
            bool isFirmView = (UserProfilePageMode.VIEW == pageMode);
            btn_updatepassword.Visible = !isFirmView;
            btn_updateuserprofile.Visible = !isFirmView;
            btnChangesCancel.Visible = !isFirmView;
            btnUserProfileEdit.Visible = isFirmView;
        }

        private void fetchSelectedUser()
        {
            try
            {
                UserDefinitionDTO userDef = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
                if (userDef.Username != null) lblUsername.Text = userDef.Username; else lblUsername.Text = null;
                if (userDef.FirmMember.FirstName != null) txtFirstName.Text = userDef.FirmMember.Salutation.Name.ToString()+" "+userDef.FirmMember.FirstName ; else txtFirstName.Text = null;
                if (userDef.FirmMember.MiddleName != null) txtMiddleName.Text = userDef.FirmMember.MiddleName; else txtMiddleName.Text = null;
                if (userDef.FirmMember.LastName != null) txtLastName.Text = userDef.FirmMember.LastName; else txtLastName.Text = null;
                if (userDef.FirmMember.ContactInfo.Contact != null) txtContact.Text = userDef.FirmMember.ContactInfo.Contact; else txtContact.Text = null;
                if (userDef.FirmMember.ContactInfo.AltContact != null) txtAltContact.Text = userDef.FirmMember.ContactInfo.AltContact; else txtAltContact.Text = null;
                if (userDef.FirmMember.ContactInfo.Dob != null) txtDOB.Text = userDef.FirmMember.ContactInfo.Dob.Value.ToString(Constants.DATE_FORMAT); else txtDOB.Text = null;
                if (userDef.ProfileImg != null)
                {
                    byte[] bytes = (byte[])userDef.ProfileImg;
                    string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                    imgProfileImage.ImageUrl = "data:image/png;base64," + base64String;
                }
                ViewState[VS_SELECTED_USER] = userDef;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        protected void cancelUserChanges(object sender, EventArgs e)
        {
            setTabInfo(UserProfilePageMode.VIEW);
            resetTabInfo(PageMode.VIEW);
        }

        protected void updateProfilePicture(object sender, EventArgs e)
        {
           try{
                UserDefinitionDTO userdefDto = populateImageDTOAddFromUI();
                byte[] bytes = (byte[])userdefDto.ProfileImg;
                string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                imgProfileImage.ImageUrl = "data:image/png;base64," + base64String;
                userDefinationBO.updateUserProfile(userdefDto);
                setSuccessMessage(string.Format(Resources.Messages.success_record_update, "User Profile Picture"));
                resetTabInfo(PageMode.NONE);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }

        }
        
        private UserDefinitionDTO populateImageDTOAddFromUI()
        {
            
            UserDefinitionDTO userDef = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            HttpFileCollection uploadedFiles = Request.Files;
            for (int i = 0; i < uploadedFiles.Count; i++)
            {
                HttpPostedFile userPostedFile = uploadedFiles[i];
                if (userPostedFile.ContentLength > 0)
                {
                    string filename = Path.GetFileName(userPostedFile.FileName);
                    string extension = Path.GetExtension(filename);
                    string contentType = fileUpload.PostedFile.ContentType;
                    HttpPostedFile file = fileUpload.PostedFile;
                    byte[] profileimage = new byte[file.ContentLength];
                    file.InputStream.Read(profileimage, 0, file.ContentLength);
                    userDef.ProfileImg = profileimage;
                    userDef.FileName = filename;
                    userDef.Extension = extension;
                    userDef.ContentType = contentType;                    
                }
            }

        return userDef;
        }
    }
}