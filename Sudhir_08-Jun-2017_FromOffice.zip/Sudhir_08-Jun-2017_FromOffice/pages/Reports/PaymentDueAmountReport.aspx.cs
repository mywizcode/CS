﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft.DataSetContainer;
using CrystalDecisions.CrystalReports.Engine;
using System.Data;
using ConstroSoft.Logic.BO;
using NHibernate;
using NHibernate.Criterion;

namespace ConstroSoft.pages.Reports
{

    public partial class PaymentDueAmount : System.Web.UI.Page
    {
        
        DropdownBO drpBO = new DropdownBO();
        string tab1ValidationGrp = "tab1Error";
        PaymentDueReportBO paymentDueReportBO = new PaymentDueReportBO();
        ReportConfigBO reportConfigBO = new ReportConfigBO();
        SoldPropertyUnitBO soldUnitBO = new SoldPropertyUnitBO();
        string VS_PROPERTY_UNIT_LIST = "PROPERTY_UNIT_LIST";
        string VS_MASTER_PROPERTY_UNIT_LIST = "ALL_PROPERTY_UNIT_LIST";

        private static readonly log4net.ILog log =
             log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (CommonUtil.isSessionActive(Session))
                {
                    Session["Letter"] = null;
                    initDropdowns();

                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
            PaymentDueReportViewer.ReportSource = (ReportDocument)Session["Letter"];
            PaymentDueReportViewer.RefreshReport();
            PaymentDueReportViewer.DataBind();
        }

        private List<PrUnitSaleDetailDTO> getCurrentGridSoldUnits()
        {
            return (List<PrUnitSaleDetailDTO>)ViewState[VS_PROPERTY_UNIT_LIST];
        }
        private void initDropdowns()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            drpBO.drpDataBase(drpSelectProperty, DrpDataType.PROPERTY_NAME, userDefDto.Id.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
        }
        public void LoadReport()
        {
            try
            {
                IList<PrUnitSaleDetailDTO> selectedPrUnitSaleDetailDto = (IList<PrUnitSaleDetailDTO>)ViewState[VS_PROPERTY_UNIT_LIST];
                UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
                BusinessOutputTO businessOutputTO = null;
                ReportConfigDTO reportConfigDTO = null;
                ReportDocument letterReportDocument = new ReportDocument();
                businessOutputTO = paymentDueReportBO.processPaymentDueLetter(userDefDto.FirmNumber, selectedPrUnitSaleDetailDto, long.Parse(drpSelectProperty.Text));
                reportConfigDTO = reportConfigBO.fetchReportConfiguration(userDefDto.FirmNumber, "Payment Due Report");
                if (businessOutputTO.status == BusinessOutputTO.Status.SUCCESS)
                {
                    string reportPath = Server.MapPath(reportConfigDTO.ReportPath);                    
                    letterReportDocument.Load(reportPath);
                    letterReportDocument.Database.Tables["PropertyDetails"].SetDataSource(businessOutputTO.resultList[0]);
                    letterReportDocument.Database.Tables["PaymentDueReport"].SetDataSource(businessOutputTO.resultList[1]);
                    Session["Letter"] = letterReportDocument;
                    PaymentDueReportViewer.ReportSource = letterReportDocument;
                }


            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                throw exp;
            }
        }

        private void loadSearchGridAndReSelect(long Id)
        {
            try
            {
                List<PrUnitSaleDetailDTO> matserList = (List<PrUnitSaleDetailDTO>)getMatserSoldUnits();
                List<PrUnitSaleDetailDTO> filterResults = new List<PrUnitSaleDetailDTO>(matserList);
                filterResults = matserList.FindAll(u => u.PropertyUnit.Id == long.Parse(drpSelectProperty.Text));
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                throw exp;
            }
        }

        private List<PrUnitSaleDetailDTO> getMatserSoldUnits()
        {
            return (List<PrUnitSaleDetailDTO>)ViewState[VS_MASTER_PROPERTY_UNIT_LIST];
        }
        protected void Page_PreRender(object sender, EventArgs e)
        {
            if (Session[Constants.Session.USERNAME] != null)
            {
                initBootstrapComponantsFromServer();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        private bool isViewOnlyUser()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            bool isViewOnlyUser = !CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.FIRM_MEMBER_ADD_UPDATE);
            return isViewOnlyUser;
        }

        public void initBootstrapComponantsFromServer()
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
        }

        protected void onSelectProperty(object sender, EventArgs e)
        {
            drpSelectPropertyTower.Visible = true;
            lblPropertyTower.Visible = true;
            drpBO.drpDataBase(drpSelectPropertyTower, DrpDataType.PROPERTY_TOWER, drpSelectProperty.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);

        }
        private UserDefinitionDTO getUserDefinitionDTO()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }
        public void setErrorMessage(string message, string group)
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }
        private void fetchSoldUnits(long Id)
        {
            try
            {
                IList<PrUnitSaleDetailDTO> results = new List<PrUnitSaleDetailDTO>();
                long propertyId = 0, towerId = 0;

                if (!(string.IsNullOrWhiteSpace(drpSelectProperty.Text)))
                {
                    propertyId = long.Parse(drpSelectProperty.Text);
                    if (!(string.IsNullOrWhiteSpace(drpSelectPropertyTower.Text)))
                    {
                        towerId = long.Parse(drpSelectPropertyTower.Text);
                    }
                    results = paymentDueReportBO.fetchSoldPropertyUnits(getUserDefinitionDTO().FirmNumber, propertyId, towerId);
                    ViewState[VS_PROPERTY_UNIT_LIST] = results;
                    if (results.Count > 0)
                    {
                        LoadReport();
                    }
                    else
                    {
                        setErrorMessage(Resources.Messages.validation_paymentduereportnull, tab1ValidationGrp);
                    }
                }
                else
                {
                    setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Property Name"), tab1ValidationGrp);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                throw exp;
            }
        }

        protected void GenerateReport(object sender, EventArgs e)
        {
            fetchSoldUnits(0);
        }



    }
}