﻿using System;
using NHibernate;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using ConstroSoft;
using System.Collections.Generic;

/// <summary>
/// Summary description for FBIntegrationBO
/// </summary>
namespace ConstroSoft
{
    public class FBIntegrationBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public FBIntegrationBO()
        {
            
            // TODO: Add constructor logic here
            //
        }
        public void saveFBuser(FBUserDTO fbUserDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        FBUser FBUser = DTOToDomainUtil.populateFBUserAddFields(fbUserDTO);
                        FBUser.Password = Encrypt(FBUser.Password);
                        session.Save(FBUser);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Adding User:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public BusinessOutputTO validateFBUser(FBUserDTO FBUserDTO)
        {
            BusinessOutputTO businessTO = new BusinessOutputTO();
            ISession session = null;
            log.Debug("Validating user login");
            try
            {
                bool result = false;
                session = NHibertnateSession.OpenSession();
                string username = FBUserDTO.UserName;
                FBUser fbUser = session.QueryOver<FBUser>().Where(x => x.UserName == username).SingleOrDefault();
                if (fbUser != null)
                {
                    if (FBUserDTO.Password.Equals(Decrypt(fbUser.Password)))
                    {
                        log.Debug("Login Successful for user:" + FBUserDTO.UserName);
                        businessTO.result = getFBUserDTO(fbUser);
                        result = true;
                    }
                }
                if (!result)
                {
                    log.Debug("Login Failed for user:" + FBUserDTO.UserName);
                    businessTO.setErrorMessage(Resources.Messages.login_error_failed);
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while login:" + FBUserDTO.UserName);
                log.Error(exp.Message, exp);
                businessTO.setErrorMessage(Resources.Messages.system_error);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return businessTO;
        }
        public string checkUserExists(FBUserDTO fBUserDTO)
        {
            ISession session = null;
            string result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                FBUser fbUser = session.QueryOver<FBUser>().Where(x => x.UserName == fBUserDTO.UserName).SingleOrDefault();
                if (fbUser != null)
                {
                    result = "User with same details already exists.";
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while registering:" + fBUserDTO.UserName);
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public FBTokenManager checkTokenValidity(string tokenNumber)
        {
            ISession session = null;
            FBTokenManager fBTokenManager = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                fBTokenManager = session.QueryOver<FBTokenManager>().Where(x => x.TakenKey == tokenNumber && DateTime.Now < x.ExpiresOn).SingleOrDefault();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while validating token:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return fBTokenManager;
        }
       
        public string checkFirmExists(FBUserDTO fBUserDTO)
        {
            ISession session = null;
            string result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                Firm firm = session.QueryOver<Firm>().Where(x => x.FirmNumber == fBUserDTO.FirmNumber).SingleOrDefault();
                if (firm == null)
                {
                    result = "Firm with " + fBUserDTO.FirmNumber + " does not exist into system.";
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while registering:" + fBUserDTO.UserName);
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        private FBUserDTO getFBUserDTO(FBUser FBUser)
        {
            FBUserDTO FBUserDTO = new FBUserDTO();
            FBUserDTO.UserName = FBUser.UserName;
            FBUserDTO.Password = FBUser.Password;
            FBUserDTO.Email = FBUser.Email;
            FBUserDTO.FirmNumber = FBUser.FirmNumber;
            FBUserDTO.Id = FBUser.Id;
            return FBUserDTO;
        }
        private string Encrypt(string clearText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    clearText = Convert.ToBase64String(ms.ToArray());
                }
            }
            return clearText;
        }
        private string Decrypt(string cipherText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }
        public string validateMandatoryFields(FBUserDTO fBUserDTO)
        {
            string errorMessage = null;
            if (fBUserDTO.UserName == null)
            {
                errorMessage = "Please enter value for User Name. ";
            }
            if (fBUserDTO.Password == null)
            {
                errorMessage += "Please enter value for Password. ";
            }
            if (fBUserDTO.Email == null)
            {
                errorMessage += "Please enter value for Email. ";
            }
            if (fBUserDTO.FirmNumber == null)
            {
                errorMessage += "Please enter value for Firm Number";
            }
            return errorMessage;
        }
        public string validateLoginUser(FBUserDTO fBUserDTO)
        {
            string errorMessage = null;
            if (fBUserDTO.UserName == null)
            {
                errorMessage = "Please enter value for User Name. ";
            }
            if (fBUserDTO.Password == null)
            {
                errorMessage += "Please enter value for Password. ";
            }
            return errorMessage;
        }
        public string validateLeadFields(LeadDetailDTO leadDetailDTO)
        {
            string errorMessage = null;
            errorMessage = validateLeadMandatoryFields(leadDetailDTO);
            if(errorMessage == null){
                errorMessage =  validateProperty(leadDetailDTO);
            }
            return errorMessage;
        }
        public string validateProperty(LeadDetailDTO leadDetailDTO)
        {
            ISession session = null;
            string errorMessage = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                Property property = session.QueryOver<Property>().Where(x => x.Name == leadDetailDTO.PropertyName).SingleOrDefault();
                if (property == null)
                {
                    errorMessage = "Property with "+propertyName+" does not exist into system.";
                }else{
                    leadDetailDTO.propertyId = property.Id;
                    
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while validating property:" + propertyName);
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return errorMessage;
        }
        public string validateLeadMandatoryFields(LeadDetailDTO leadDetailDTO)
        {
            string errorMessage = null;
            if (leadDetailDTO.FirstName == null)
            {
                errorMessage = "Please enter value for First Name. ";
            }
            if (leadDetailDTO.LastName == null)
            {
                errorMessage += "Please enter value for Last Name. ";
            }
            if (leadDetailDTO.Contact == null)
            {
                errorMessage += "Please enter value for Contact. ";
            }
            if (leadDetailDTO.Email == null)
            {
                errorMessage += "Please enter value for Email. ";
            }
            if (leadDetailDTO.Budget == null)
            {
                errorMessage += "Please enter value for Budget. ";
            }
            if (leadDetailDTO.EnquiryDate == null)
            {
                errorMessage += "Please enter value for Enquiry Date. ";
            }
            if (leadDetailDTO.PropertyName == null)
            {
                errorMessage += "Please enter value for Property Name. ";
            }
            if (leadDetailDTO.TokenNumber == null)
            {
                errorMessage += "Please enter value for Token Number. ";
            }
            return errorMessage;
        }
        public string saveFBToken(FBUserDTO fbUserDTO)
        {
            ISession session = null;
            string token = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        token = GetUniqueKey(100);
                        FBTokenManager fBTokenManager = populateFBTokenManager(fbUserDTO, token);
                        session.Save(fBTokenManager);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while generating token:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return token;
        }
        public void savePortalLead(LeadDetailDTO leadDetailDTO)
        {
            ISession session = null;
            string token = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PortalleadDetail portalleadDetail = populatePortalLead(leadDetailDTO);
                        session.Save(portalleadDetail);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while generating lead:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
           
        }
       
        public static string GetUniqueKey(int maxSize = 15)
        {
            char[] chars = new char[62];
            chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890".ToCharArray();
            byte[] data = new byte[1];
            using (RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider())
            {
                crypto.GetNonZeroBytes(data);
                data = new byte[maxSize];
                crypto.GetNonZeroBytes(data);
            }
            StringBuilder result = new StringBuilder(maxSize);
            foreach (byte b in data)
            {
                result.Append(chars[b % (chars.Length)]);
            }
            return result.ToString();
        }

        public static FBTokenManager populateFBTokenManager(FBUserDTO fbUserDTO, string token)
        {
            FBTokenManager fBTokenManager = new FBTokenManager();
            fBTokenManager.TokenKey = token;
            fBTokenManager.IssuedOn = DateTime.Now;
            fBTokenManager.ExpiresOn = DateTime.Now.AddMinutes(25);
            fBTokenManager.FirmNumber = fBUserDTO.FirmNumber;
            fBTokenManager.FBUser = new FBUser();
            fBTokenManager.FBUser.Id = fBUserDTO.Id;
            fBTokenManager.InsertDate = DateTime.Now;
            fBTokenManager.InsertUser = fBUserDTO.UserName;
            fBTokenManager.UpdateDate = DateTime.Now;
            fBTokenManager.UpdateUser = fBUserDTO.UserName;
            return fBTokenManager;
        }
        public static FBTokenManager populatePortalLead(LeadDetailDTO leadDetailDTO)
        {
            PortalleadDetail portalleadDetail = new PortalleadDetail();
            portalleadDetail.TokenKey = leadDetailDTO.TokenKey;
            portalleadDetail.FirstName = leadDetailDTO.FirstName
            portalleadDetail.LastName = leadDetailDTO.LastName
            portalleadDetail.EnquiryDate = DateTime.ParseExact(leadDetailDTO.EnquiryDate, Constants.DATE_FORMAT, CultureInfo.InvariantCulture)
            portalleadDetail.Budget = leadDetailDTO.Budget;
            portalleadDetail.Contact = leadDetailDTO.Contact;
            portalleadDetail.Email = leadDetailDTO.Email;
            portalleadDetail.Property = new Property();
            portalleadDetail.Property.Id = leadDetailDTO.PropertyId;
            leadDetailDTO.EnquirySource = CommonUIConverter.getMasterControlDTO("Facebook", null);
            portalleadDetail.EnquirySource = DTOToDomainUtil.copyMasterControlId(portalleadDetail.EnquirySource, leadDetailDTO.EnquirySource);
            portalleadDetail.FirmNumber = leadDetailDTO.FirmNumber;
            portalleadDetail.FBUser = new FBUser();
            portalleadDetail.FBUser.Id = leadDetailDTO.UserId;
            portalleadDetail.InsertDate = DateTime.Now;
            portalleadDetail.InsertUser = leadDetailDto.FBUserName;
            portalleadDetail.UpdateDate = DateTime.Now;
            portalleadDetail.UpdateUser = leadDetailDto.FBUserName;
            return portalleadDetail;
        }
    }
}