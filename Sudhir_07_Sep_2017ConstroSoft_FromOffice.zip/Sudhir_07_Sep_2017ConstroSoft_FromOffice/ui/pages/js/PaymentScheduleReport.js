﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});
function initBootstrapComponants() {
    formatFields();
}
