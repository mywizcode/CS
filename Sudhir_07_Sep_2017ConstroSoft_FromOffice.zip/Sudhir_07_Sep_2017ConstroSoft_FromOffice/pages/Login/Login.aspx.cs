﻿using System;
using System.Web.UI.WebControls;
using ConstroSoft;

public partial class Login : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
          log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    private string validationErrorGrp = "loginErrorGrp";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Session.Remove(Constants.Session.USERNAME);
        }
        btnSuccessMsg.Attributes["data-message"] = CommonUtil.getSessionSuccessMsg(Session);
        btnErrorMsg.Attributes["data-message"] = CommonUtil.getSessionSuccessMsg(Session);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        initBootstrapComponantsFromServer();
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
    }
    public void initBootstrapComponantsFromServer()
    {
    
    }
    protected void login(object sender, EventArgs e)
    {
        LoginBO loginBO = new LoginBO();
        try
        {
            if (validateloginFields())
            {
                BusinessOutputTO outputTO = loginBO.validateUser(txtUserName.Text, txtPassword.Text);
                if (BusinessOutputTO.Status.SUCCESS.Equals(outputTO.status))
                {
                    UserDefinitionDTO userDef = (UserDefinitionDTO)outputTO.result;
                    Session[Constants.Session.USERNAME] = userDef.Username;
                    Session[Constants.Session.USERDEFINITION] = userDef;
                    System.Collections.Generic.List<string> d = Application["LOGGED_IN_USERS"] as System.Collections.Generic.List<string>;
                    if (d != null)
                    {
                        lock (d)
                        {
                            if (d.Contains(txtUserName.Text))
                            {
                                setErrorMessage(Resources.Messages.login_error_multiple_login, validationErrorGrp);
                            }
                            d.Add(txtUserName.Text);
                        }
                    }
                    if (userDef.Status == UserStatus.Active)
                    {
                        Response.Redirect(Constants.URL.HOME, false);
                    }
                    else
                    {
                        Response.Redirect(Constants.URL.LOGIN_SETUP, false);
                    }
                }
                else
                {
                    setErrorMessage(outputTO.errorMessage, validationErrorGrp);
                }
                txtUserName.Text = "";
                txtUserName.Text = "";
            }
        }
        catch (Exception ex)
        {
            log.Error("Unexpected error:", ex);
            setErrorMessage(Resources.Messages.system_error, validationErrorGrp);
        }
    }
    private bool validateloginFields()
    {
        Page.Validate(validationErrorGrp);
        return Page.IsValid;
    }
    protected void showForgotPasswordPage(object sender, EventArgs e)
    {
        Response.Redirect(Constants.URL.FORGOT_PASSWORD, false);
    }
    
}