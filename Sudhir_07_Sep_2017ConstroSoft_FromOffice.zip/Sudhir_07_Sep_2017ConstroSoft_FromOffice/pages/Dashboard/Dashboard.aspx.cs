﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Net;
using System.IO;
using System.Windows.Forms;
using System.Net.Mail;
using ConstroSoft;

public partial class Dashboard : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    PropertyBO propertyBO = new PropertyBO();
    DashboardBO dashboardBO = new DashboardBO();
    DropdownBO drpBO = new DropdownBO();
    EnquiryBO enquiryBO = new EnquiryBO();
    string tab1ValidationGrp = "tab1Error";
    string VS_PROPERTY = "PROPERTY_LIST";
    string VS_PR_TOWER = "PR_TOWER_LIST";
    string VS_ENQ_LIST = "ENQ_LIST";
    string VS_PDC_LIST = "PDC_LIST";
    string VS_EVENT_LIST = "EVENT_LIST";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                loadInitialData();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }   
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (Session[Constants.Session.USERNAME] != null)
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private bool isViewOnlyUser()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        bool isViewOnlyUser = !CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.FIRM_MEMBER_ADD_UPDATE);
        return isViewOnlyUser;
    }
    private void applyEntitlement()
    {
        if (isViewOnlyUser())
        {
            
        }
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private void preRenderInitFormElements()
    {

    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    public void setErrorMessage(string message)
    {
        errorMessageHdn.Value = message;
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
    }
    private List<PropertyDTO> getPropertyList()
    {
        return (List<PropertyDTO>)ViewState[VS_PROPERTY];
    }
    private List<PropertyTowerDTO> getPropertyTowerList()
    {
        return (List<PropertyTowerDTO>)ViewState[VS_PR_TOWER];
    }
    private List<EnquiryDetailDTO> getEnuiryList()
    {
        return (List<EnquiryDetailDTO>)ViewState[VS_ENQ_LIST];
    }
    private List<DashboardEventDTO> getEventList()
    {
        return (List<DashboardEventDTO>)ViewState[VS_EVENT_LIST];
    }
    private List<PostDatedChequeDTO> getPdcList()
    {
        return (List<PostDatedChequeDTO>)ViewState[VS_PDC_LIST];
    }
    private void bindPropertyList()
    {
        List<PropertyDTO> pList = (getPropertyList() != null) ? getPropertyList() : new List<PropertyDTO>();
        propertyGrid.DataSource = pList;
        propertyGrid.DataBind();
    }
    private void bindPropertyTowerList()
    {
        List<PropertyTowerDTO> pList = (getPropertyTowerList() != null) ? getPropertyTowerList() : new List<PropertyTowerDTO>();
        propertyTowerGrid.DataSource = pList;
        propertyTowerGrid.DataBind();
    }
    private void loadInitialData()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        drpBO.drpDataBase(drpEnqContactType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ENQUIRY_MEDIA_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        IList<PropertyDTO> result = propertyBO.fetchAllProperties(userDefDto.FirmNumber);
        bool hasProperty = false;
        if (result.Count > 0)
        {
            hasProperty = true;
            result.First<PropertyDTO>().isUISelected = true;
            ViewState[VS_PROPERTY] = result;
            selectAndLoadPropertyGrid();
            fetchDashBoardData();
        }
        pnlPropertySelection.Visible = hasProperty;
        pnlDashboardContent.Visible = hasProperty;
        lbNoProperty.Visible = !hasProperty;
    }
    private void fetchDashBoardData()
    {
        fetchEnquiryFollowups();
        fetchEvents();
        fetchPdc();
        fetchPrUnitCount();
    }
    private void selectAndLoadPropertyGrid()
    {
        PropertyDTO selectedProperty = getPropertyList().Find(p => p.isUISelected);
        selectedProperty.isUISelected = true;
        lbProperty.Text = selectedProperty.Name;
        bindPropertyList();
        fetchAndLoadTowers();
    }
    private void fetchAndLoadTowers()
    {
        long propId = getPropertyList().Find(x => x.isUISelected).Id;
        IList<PropertyTowerDTO> prTowerList = propertyBO.fetchPropertyTowerSelective(getUserDefinitionDTO().FirmNumber, propId);
        PropertyTowerDTO allTowerDto = new PropertyTowerDTO();
        allTowerDto.Name = "All Towers";
        allTowerDto.isUISelected = true;
        prTowerList.Insert(0, allTowerDto);
        ViewState[VS_PR_TOWER] = prTowerList;
        lbPropertyTower.Text = allTowerDto.Name;
        bindPropertyTowerList();
    }
    protected void onSelectProperty(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            string selectedPropertyId = rd.Attributes["data-pid"];
            if (!string.IsNullOrWhiteSpace(selectedPropertyId))
            {
                getPropertyList().ForEach(x => x.isUISelected = false);
                PropertyDTO selectedProperty = getPropertyList().Find(p => p.Id == long.Parse(selectedPropertyId));
                selectedProperty.isUISelected = true;
                lbProperty.Text = selectedProperty.Name;
                bindPropertyList();
                fetchAndLoadTowers();
                fetchEnquiryFollowups();
                fetchEvents();
                fetchPdc();
                fetchPrUnitCount();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error);
        }
    }
    protected void onSelectPropertyTower(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            string selectedTowerId = rd.Attributes["data-pid"];
            if (!string.IsNullOrWhiteSpace(selectedTowerId))
            {
                getPropertyTowerList().ForEach(x => x.isUISelected = false);
                PropertyTowerDTO selectedTower = getPropertyTowerList().Find(p => p.Id == long.Parse(selectedTowerId));
                selectedTower.isUISelected = true;
                lbPropertyTower.Text = selectedTower.Name;
                bindPropertyTowerList();
                fetchEvents();
                fetchPdc();
                fetchPrUnitCount();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error);
        }
    }
    private void fetchEnquiryFollowups()
    {
        try
        {
            long propertyId = getPropertyList().Find(x => x.isUISelected).Id;
            IList<EnquiryDetailDTO> enquiryList = dashboardBO.fetchEnquiryFollowupGridData(getUserDefinitionDTO().FirmNumber, propertyId);
            ViewState[VS_ENQ_LIST] = enquiryList;
            enquiryGrid.DataSource = enquiryList;
            enquiryGrid.DataBind();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error);
        }
    }
    private void fetchEvents()
    {
        try
        {
            long propertyId = getPropertyList().Find(x => x.isUISelected).Id;
            long prTowerId = getPropertyTowerList().Find(x => x.isUISelected).Id;
            List<DashboardEventDTO> eventList = dashboardBO.fetchEventGridData(getUserDefinitionDTO().FirmNumber, propertyId, prTowerId);
            ViewState[VS_EVENT_LIST] = eventList;
            eventGrid.DataSource = eventList;
            eventGrid.DataBind();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error);
        }
    }
    private void fetchPrUnitCount()
    {
        try
        {
            long propertyId = getPropertyList().Find(x => x.isUISelected).Id;
            long prTowerId = getPropertyTowerList().Find(x => x.isUISelected).Id;
            IList<DashboardUnitCountDTO> prUnitCountList = dashboardBO.fetchPrUnitCount(getUserDefinitionDTO().FirmNumber, propertyId, prTowerId);
            lbAvailableUnitCount.Text = "0";
            lbSoldUnitCount.Text = "0";
            lbReservedUnitCount.Text = "0";
            foreach (DashboardUnitCountDTO dto in prUnitCountList)
            {
                if (PRUnitStatus.Available == dto.Status) lbAvailableUnitCount.Text = dto.Count.ToString();
                else if (PRUnitStatus.Sold == dto.Status) lbSoldUnitCount.Text = dto.Count.ToString();
                else if (PRUnitStatus.Reserved == dto.Status) lbReservedUnitCount.Text = dto.Count.ToString();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error);
        }
    }
    private void fetchPdc()
    {
        try
        {
            long propertyId = getPropertyList().Find(x => x.isUISelected).Id;
            long prTowerId = getPropertyTowerList().Find(x => x.isUISelected).Id;
            IList<PostDatedChequeDTO> pdcList = dashboardBO.fetchPdcForDashboard(getUserDefinitionDTO().FirmNumber, propertyId, prTowerId);
            List<PostDatedChequeDTO> pdcFromList = new List<PostDatedChequeDTO>();
            List<PostDatedChequeDTO> pdcToList = new List<PostDatedChequeDTO>();
            foreach (PostDatedChequeDTO pdc in pdcList)
            {
                if (PaymentFromSearchBy.FIRM == pdc.PymtFrom) pdcFromList.Add(pdc);
                else pdcToList.Add(pdc);
            }
            ViewState[VS_PDC_LIST] = pdcList;
            pdcFromList = pdcFromList.OrderBy(o => o.ChequeDate).ToList();
            pdcToList = pdcToList.OrderBy(o => o.ChequeDate).ToList();
            pdcOutGrid.DataSource = pdcFromList;
            pdcOutGrid.DataBind();
            pdcInGrid.DataSource = pdcToList;
            pdcInGrid.DataBind();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error);
        }
    }
    protected void gotoPdcPage(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            string selectedPdcId = rd.Attributes["data-pid"];
            if (!string.IsNullOrWhiteSpace(selectedPdcId))
            {
                PostDatedChequeDTO pdcDto = getPdcList().Find(x => x.Id == long.Parse(selectedPdcId));
                Session[Constants.Session.FROM_DASHBOARD_PDC] = pdcDto;
                Session[Constants.Session.FROM_DASHBOARD] = "YES";
                Response.Redirect(Constants.URL.MANAGE_PDC, true);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error);
        }
    }
    private bool isReScheduleEvent()
    {
        return selectedEventActionHdn.Value.Equals("RESCHEDULE");
    }
    private bool isMarkAsCompletedEvent()
    {
        return selectedEventActionHdn.Value.Equals("MARK_AS_COMPLETED");
    }
    private bool isAddEnquiryFollowup()
    {
        return selectedEnquiryActionHdn.Value.Equals("ADD_FOLLOWUP");
    }
    private bool isCloseEnquiry()
    {
        return selectedEnquiryActionHdn.Value.Equals("CLOSE_ENQUIRY");
    }
    protected void onSelectEventAction(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            string selectedEventId = rd.Attributes["data-pid"];
            string selectedAction = rd.Attributes["data-action"];
            selectedEventActionHdn.Value = selectedAction;
            selectedEventHdn.Value = selectedEventId;
            if (!string.IsNullOrWhiteSpace(selectedEventId))
            {
                showEventModalHdnBtn.Value = "true";
                DashboardEventDTO eventDto = getEventList().Find(x => x.Id == long.Parse(selectedEventId));
                divAgreementNoModal.Visible = false;
                txtAgreementNo.Text = null;
                switch (eventDto.EventType)
                {
                    case DashboardEvent.AGREEMENT:
                        txtEventDate.Text = CommonUtil.getCSDate(eventDto.Date);
                        lbEventDate.Text = "Agreement Date:";
                        lbEventModalHeader.Text = (isReScheduleEvent()) ? "Reschedule Agreement" : "Agreement Completed";
                        divAgreementNoModal.Visible = isMarkAsCompletedEvent();
                        break;
                    case DashboardEvent.POSSESSION:
                        txtEventDate.Text = CommonUtil.getCSDate(eventDto.Date);
                        lbEventDate.Text = "Possession Date:";
                        lbEventModalHeader.Text = (isReScheduleEvent()) ? "Reschedule Possession" : "Possession Given";
                        break;
                    default:
                        setErrorMessage("Invalid Event Type, Please contact system administrator.");
                        break;
                }
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error);
        }
    }
    protected void saveEventAction(object sender, EventArgs e)
    {
        try
        {
            string selectedEventAction = selectedEventActionHdn.Value;
            if (!string.IsNullOrWhiteSpace(selectedEventHdn.Value) && !string.IsNullOrWhiteSpace(selectedEventAction))
            {
                DashboardEventDTO eventDto = getEventList().Find(x => x.Id == long.Parse(selectedEventHdn.Value));
                switch (eventDto.EventType)
                {
                    case DashboardEvent.AGREEMENT:
                        if (validateAgreementEvent(eventDto))
                        {
                            string AgreementNo = isMarkAsCompletedEvent() ? txtAgreementNo.Text : null;
                            IsAgreementDone IsAgreementDone = isMarkAsCompletedEvent() ? IsAgreementDone.Yes : IsAgreementDone.No;
                            dashboardBO.updateAgreementDetails(eventDto.Id, CommonUtil.getCSDateNotNull(txtEventDate.Text), AgreementNo, IsAgreementDone);
                            successMessageHdn.Value = isMarkAsCompletedEvent() ? "Agreement of property unit '" + eventDto .UnitNo+ "' is marked as completed."
                                : "Agreement of property unit '" + eventDto.UnitNo + "' is Rescheduled successfully.";
                            fetchDashBoardData();
                        }
                        else
                        {
                            showEventModalHdnBtn.Value = "true";
                        }
                        break;
                    case DashboardEvent.POSSESSION:
                        if (validatePossessionEvent(eventDto))
                        {
                            IsPossessionDone IsPossessionDone = isMarkAsCompletedEvent() ? IsPossessionDone.Yes : IsPossessionDone.No;
                            dashboardBO.updatePossessionDetails(eventDto.Id, CommonUtil.getCSDateNotNull(txtEventDate.Text), IsPossessionDone);
                            successMessageHdn.Value = isMarkAsCompletedEvent() ? "Possession of property unit '" + eventDto.UnitNo + "' is marked as completed."
                                : "Possession of property unit '" + eventDto.UnitNo + "' is Rescheduled successfully.";
                            fetchDashBoardData();
                        }
                        else
                        {
                            showEventModalHdnBtn.Value = "true";
                        }
                        break;
                    default:
                        setErrorMessage("Invalid Event Type, Please contact system administrator.");
                        break;
                }
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error);
        }
    }
    protected void cancelEventAction(object sender, EventArgs e)
    {
        try
        {
            
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error);
        }
    }
    private bool validateAgreementEvent(DashboardEventDTO eventDto) {
        if(string.IsNullOrWhiteSpace(txtEventDate.Text)){
            setErrorMessage("Please select Agreement Date.", "eventModalError");
            return false;
        }
        if (isMarkAsCompletedEvent() && string.IsNullOrWhiteSpace(txtAgreementNo.Text))
        {
            setErrorMessage("Please enter Agreement Number.", "eventModalError");
            return false;
        }
        string agreementNo = (isMarkAsCompletedEvent()) ? txtAgreementNo.Text : eventDto.PrUnitSaleDetail.AgreementNo;
        string errorMsg = CommonValidations.validateUnitSaleDates(eventDto.PrUnitSaleDetail.BookingDate, eventDto.PrUnitSaleDetail.PossessionDate,
                CommonUtil.getCSDate(txtEventDate.Text), agreementNo, eventDto.PrUnitSaleDetail.IsAgreementDone, eventDto.PrUnitSaleDetail.IsPossessionDone);
        if (!string.IsNullOrWhiteSpace(errorMsg))
        {
            setErrorMessage(errorMsg, "eventModalError");
            return false;
        }
        return true;
    }
    private bool validatePossessionEvent(DashboardEventDTO eventDto) {
        if(string.IsNullOrWhiteSpace(txtEventDate.Text)){
            setErrorMessage("Please select Possession Date.", "eventModalError");
            return false;
        }
        string errorMsg = CommonValidations.validateUnitSaleDates(eventDto.PrUnitSaleDetail.BookingDate, CommonUtil.getCSDate(txtEventDate.Text),
                    eventDto.PrUnitSaleDetail.AgreementDate, eventDto.PrUnitSaleDetail.AgreementNo, eventDto.PrUnitSaleDetail.IsAgreementDone, eventDto.PrUnitSaleDetail.IsPossessionDone);
        if (!string.IsNullOrWhiteSpace(errorMsg))
        {
            setErrorMessage(errorMsg, "eventModalError");
            return false;
        }
        return true;
    }
    private void resetEnquiryModal()
    {
        txtFollowUpDate.Text = null;
        txtEnqNextFollowUpDate.Text = null;
        txtEnqComment.Text = null;
        drpEnqContactType.ClearSelection();
    }
    protected void onSelectEnquiryAction(object sender, EventArgs e)
    {
        try
        {
            resetEnquiryModal();
            LinkButton rd = (LinkButton)sender;
            string selectedEnquiryId = rd.Attributes["data-eid"];
            string selectedAction = rd.Attributes["data-action"];
            selectedEnquiryActionHdn.Value = selectedAction;
            selectedEnquiryHdn.Value = selectedEnquiryId;
            if (!string.IsNullOrWhiteSpace(selectedEnquiryId))
            {
                EnquiryDetailDTO selectedEnquiryDto = getEnuiryList().Find(x => x.Id == long.Parse(selectedEnquiryId));
                txtFollowUpDate.Text = CommonUtil.getCSDate(selectedEnquiryDto.FollowupDate);
                showEnquiryFollowupModalHdn.Value = "true";
                divNextFollowupDate.Visible = true;
                if (isAddEnquiryFollowup())
                {
                    lbEnquiryModalHeader.Text = "Add Enquiry Followup";
                }
                else if (isCloseEnquiry())
                {
                    //Set as dummy date to validate successfully in case of close enquiry
                    txtEnqNextFollowUpDate.Text = CommonUtil.getCSDate(selectedEnquiryDto.FollowupDate);
                    divNextFollowupDate.Visible = false;
                    lbEnquiryModalHeader.Text = "Close Enquiry";
                }
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error);
        }
    }
    protected void saveEnquiryAction(object sender, EventArgs e)
    {
        try
        {
            string selectedEnquiryAction = selectedEnquiryActionHdn.Value;
            if (!string.IsNullOrWhiteSpace(selectedEnquiryHdn.Value) && !string.IsNullOrWhiteSpace(selectedEnquiryAction))
            {
                EnquiryDetailDTO selectedEnquiryDto = getEnuiryList().Find(x => x.Id == long.Parse(selectedEnquiryHdn.Value));
                if (validateEnquiryAction())
                {
                    if (isAddEnquiryFollowup())
                    {
                        enquiryBO.addNewFollowup(populateNewFollowup(selectedEnquiryDto));
                        successMessageHdn.Value = "Followup is added successfully for Enquiry # '" + selectedEnquiryDto.EnquiryRefNo + "'.";
                    }
                    else if (isCloseEnquiry())
                    {
                        enquiryBO.closeEnquiry(populateNewFollowup(selectedEnquiryDto));
                        successMessageHdn.Value = "Enquiry # '" + selectedEnquiryDto.EnquiryRefNo + "' is cancelled successfully.";
                    }
                    fetchDashBoardData();
                }
                else
                {
                    showEnquiryFollowupModalHdn.Value = "true";
                }
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error);
        }
    }
    private EnquiryFollowupDTO populateNewFollowup(EnquiryDetailDTO enquiryDto)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        EnquiryFollowupDTO followupDto = new EnquiryFollowupDTO();
        followupDto.FollowupDate = CommonUtil.getCSDate(txtFollowUpDate.Text);
        followupDto.CommunicationMedia = CommonUIConverter.getMasterControlDTO(drpEnqContactType.Text, null);
        followupDto.Comments = txtEnqComment.Text;
        followupDto.EnquiryDetail = new EnquiryDetailDTO();
        followupDto.EnquiryDetail.Id = enquiryDto.Id;
        followupDto.FirmMember = CommonUIConverter.getFirmMemberDTO(userDefDto.FirmMember.Id.ToString(), null);
        if(isAddEnquiryFollowup()) {
            followupDto.EnquiryDetail.FollowupDate = CommonUtil.getCSDate(txtEnqNextFollowUpDate.Text);
        }
        followupDto.FirmNumber = userDefDto.FirmNumber;
        followupDto.InsertUser = userDefDto.Username;
        followupDto.UpdateUser = userDefDto.Username;
        return followupDto;
    }
    private bool validateEnquiryAction()
    {
        Page.Validate("enquiryModalError");
        if(!Page.IsValid) return false;
        if (isAddEnquiryFollowup())
        {
            DateTime FollowupDate = CommonUtil.getCSDateNotNull(txtFollowUpDate.Text);
            DateTime NextFollowupDate = CommonUtil.getCSDateNotNull(txtEnqNextFollowUpDate.Text);
            if (FollowupDate.CompareTo(NextFollowupDate) > 0)
            {
                setErrorMessage("Followup Date cannot be greater than Next Followup Date.", "enquiryModalError");
                return false;
            }
        }
        return true;
    }
    protected void cancelEnquiryAction(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error);
        }
    }
}