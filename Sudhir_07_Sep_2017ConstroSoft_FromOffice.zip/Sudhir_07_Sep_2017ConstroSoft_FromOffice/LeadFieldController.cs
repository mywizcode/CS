﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ConstroSoft
{
    public class LeadFieldController : ApiController
    {
        [HttpGet]
        [ActionName("GetEnquiryFields")]
        public string GetEnquiryFields(string TokenNumber)
        {
            var response = JsonConvert.SerializeObject("Failure");
            if (TokenNumber != null )
            {
                FBTokenManager fBTokenManager = fBIntegrationBO.checkTokenValidity(TokenNumber)
                if (fBTokenManager != null)
                {
                    List<string> enquiryFields = new List<string>();
                    enquiryFields.Add("FirstName");
                    enquiryFields.Add("LastName");
                    enquiryFields.Add("EnquiryDate");
                    enquiryFields.Add("Budget");
                    enquiryFields.Add("Contact");
                    enquiryFields.Add("Email");
                    enquiryFields.Add("PropertyName");
                    enquiryFields.Add("TokenNumber");
                    response = JsonConvert.SerializeObject(enquiryFields);
                }
                else
                {
                    response = JsonConvert.SerializeObject("Authorization has been denied for this request, please login again.");
                }
            }
            return response;
        }
    }
}