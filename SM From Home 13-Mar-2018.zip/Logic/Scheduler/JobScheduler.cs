﻿using ConstroSoft.Logic.Job;
using Quartz;
using Quartz.Impl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ConstroSoft.Logic.CachingProvider;

namespace ConstroSoft.Logic.Scheduler
{
    public class JobScheduler
    {
        private static readonly log4net.ILog log =
                log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        
        public static void Start()
        {
            try
            {
                JobBO jobBO = new JobBO();
                FirmBO firmBO = new FirmBO();
                JobTrigger jobTrigger = new JobTrigger();
                IScheduler scheduler = StdSchedulerFactory.GetDefaultScheduler();
                scheduler.Start();
                //Fetch all active jobs from Job table for default firm.
                IList<JobDTO> jobList = jobBO.fetchJobs(Constants.DEFAULT_FIRM);
                if (jobList != null && jobList.Count > 0)
                {
                    foreach (JobDTO jobDTO in jobList)
                    {
                    	//NOTE: There will be single JOB entry for TASK_NOTIFICATION_JOB and EXOTEL_CALL_JOB which will be executed for all Firms.
                        if (jobDTO.JobName.Equals(Constants.JOBS.TASK_NOTIFICATION_JOB))
                        {
                        	if(jobDTO.JobExecutionStatus == JobExecutionStatus.Inprogress)
                        		jobBO.updateJobExecutionStatus(jobDTO.Id, DateUtil.getUserLocalDateTime(), "", JobExecutionStatus.Failed);
                        	//Set memory flags so that when jobs are scheduled, it will be executed irrespective of any new entry.
                        	NotificationCacheProvider.Instance.markNewLeadFlag();
                        	NotificationCacheProvider.Instance.markUnResolvedFlag();
                            IJobDetail notificationJob = JobBuilder.Create<TaskNotificationJob>().Build();
                            ITrigger notificationTrigger= null;
                            if(jobDTO.JobIntervalType == JobIntervalType.WithSimpleSchedule){
                                notificationTrigger = jobTrigger.CreateSimpleSchedule();
                            }
                            scheduler.Context.Put(Constants.JOBS.TASK_NOTIFICATION_JOB, jobDTO);
                            scheduler.ScheduleJob(notificationJob, notificationTrigger);
                        }
                        if (jobDTO.JobName.Equals(Constants.JOBS.EXOTEL_CALL_JOB))
                        {
                        	if(jobDTO.JobExecutionStatus == JobExecutionStatus.Inprogress)
                        		jobBO.updateJobExecutionStatus(jobDTO.Id, DateUtil.getUserLocalDateTime(), "", JobExecutionStatus.Failed);
                            IJobDetail exoteljob = JobBuilder.Create<ExotelCallRetrivalJob>().Build();
                            ITrigger exotelTrigger = null;
                            if(jobDTO.JobIntervalType == JobIntervalType.WithSimpleSchedule){
                                exotelTrigger =jobTrigger.CreateSimpleSchedule();
                            }
                            scheduler.Context.Put(Constants.JOBS.EXOTEL_CALL_JOB, jobDTO);
                            scheduler.ScheduleJob(exoteljob, exotelTrigger);
                        }
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error retriving file list:" ,exp);
            }
            finally
            {

            }
            }
            
    }
}