$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    var isCropImageModal = $("[id$='activeModalHdn']").val() == 'uploadCroppedImageModal';
    var isPageRendered = (controlToFormat == "div.content-wrapper" || controlToFormat == "body");
    if (isPageRendered) {
        var tabName = $("[id$='activeTab']").val();
        if (tabName != "") $('a.ChangePassword').click();
        else $('a.ProfileInfomation').click();
        $("[id$='activeTab']").val("");       
    }
    if (isPageRendered && isCropImageModal) {
        cropImage();
    }
    formatFields(controlToFormat);
    showModal(controlToFormat);
}
function clickProfileUpload() {
    $("[id$='fileUpload']").click();
    return false;
}
function clickUploadProfile() {
    __doPostBack('uploadProfilePicBtn', 'OnClick');
}
function cropImage() {
    var options = {
        aspectRatio: 1,
        crop: function (e) {
            $("[id$='cropXHdn']").val(Math.round(e.x));
            $("[id$='cropYHdn']").val(Math.round(e.y));
            $("[id$='cropHeightHdn']").val(Math.round(e.height));
            $("[id$='cropWidthHdn']").val(Math.round(e.width));
        }
    };
    $("[id$='ImgImageCropper']").cropper(options);
}