﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initEmailTemplateGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initEmailTemplateGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#emailTemplateGridBtnDiv",
        pageLength: 10
    };

    $("[id$='emailTemplateSearchGrid']").CSBasicDatatable(dtOptions);
}