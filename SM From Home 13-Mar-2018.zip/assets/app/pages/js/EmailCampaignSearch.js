﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initEmailCampaignGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initEmailCampaignGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#emailCampaignGridBtnDiv",
        pageLength: 10
    };

    $("[id$='emailCampaignSearchGrid']").CSBasicDatatable(dtOptions);
}