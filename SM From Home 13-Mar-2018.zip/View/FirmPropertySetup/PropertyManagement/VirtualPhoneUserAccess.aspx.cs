﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using Vladsm.Web.UI.WebControls;

public partial class VirtualPhoneUserAccess : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifyVirtualPhoneModalError = "addModifyVirtualPhoneModalError";
    string addModifyVirtualPhoneModal = "addModifyVirtualPhoneModal";
    DropdownBO drpBO = new DropdownBO();
    PropertyUserBO propertyUserBO = new PropertyUserBO();
    public enum VirtualPhoneAction { ADD, MODIFY }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                VirtualPhoneUserAccessNavDTO navDto = ApplicationUtil.getPageNavDTO<VirtualPhoneUserAccessNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.VIRTUAL_PHONE_USER_ACCESS)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
        addCheckBoxAttributes();
    }
    private void renderPageFieldsWithEntitlement()
    {

    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        drpBO.drpEnum<PhoneType>(drpPhoneType, Constants.SELECT_ITEM);
    }
    private void addCheckBoxAttributes()
    {
        foreach (ListViewItem item in UnassignedUserGrid.Items)
        {
            CheckBox chBox = (CheckBox)item.FindControl("cbUnassignedUser");
            if (chBox != null)
            {
                chBox.InputAttributes.Add("class", "styled cs-select-row");
                chBox.InputAttributes.Add("data-parent", "media-link");
            }
        }
        foreach (ListViewItem item in assignedUserGrid.Items)
        {
            CheckBox chBox = (CheckBox)item.FindControl("cbAssignedUser");
            if (chBox != null)
            {
                chBox.InputAttributes.Add("class", "styled cs-select-row");
                chBox.InputAttributes.Add("data-parent", "media-link");
            }
        }
    }
    public void setErrorMessage(string message, string group)
    {
    	string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        } else CommonUtil.getCustomValidator(Page, message, group);
    }
    private void doInit(VirtualPhoneUserAccessNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void navigateToPreviousPage()
    {
        VirtualPhoneUserAccessPageDTO PageDTO = getSessionPageData();
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is PropertySearchNavDTO)
            {
                PropertySearchNavDTO navDTO = (PropertySearchNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.PROPERTY_SEARCH, true);
            }
        }
        Response.Redirect(Constants.URL.PROPERTY_SEARCH, true);
    }
    private VirtualPhoneUserAccessPageDTO getSessionPageData()
    {
        return (VirtualPhoneUserAccessPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    protected string getVirtualPhoneType(string phoneType)
    {
        return EnumHelper.ToEnum<PhoneType>(phoneType).GetDescription();
    }
    private void initPageAfterRedirect(VirtualPhoneUserAccessNavDTO navDto)
    {
        try
        {
            VirtualPhoneUserAccessPageDTO PageDTO = new VirtualPhoneUserAccessPageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            fetchVirtualPhones(navDto.PropertyId);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void fetchVirtualPhones(long propertyId)
    {
        UserAssignmentDiv.Visible = false;
        fetchPhoneList(propertyId);
        PropertyDTO propertyDTO = getSessionPageData().Property;
        lbPropertyName.Text = propertyDTO.Name;
        lbPropertyType.Text = propertyDTO.PropertyType.Name;
        lbPropertyLocation.Text = propertyDTO.PropertyLocation.Name;
        lbReraRegNo.Text = propertyDTO.ReraRegNo;

        populateVirtualPhoneGrid(propertyDTO.VirtualPhones);
    }
    private void fetchPhoneList(long propertyId)
    {
        VirtualPhoneUserAccessPageDTO PageDTO = getSessionPageData();
        PropertyDTO propertyDTO = propertyUserBO.fetchPropertyVirtualPhones(propertyId);
        PageDTO.Property = propertyDTO;
    }
    private void populateVirtualPhoneGrid(ISet<VirtualPhoneDTO> virtualPhoneDTOList)
    {
        if(virtualPhoneDTOList == null) virtualPhoneDTOList = new HashSet<VirtualPhoneDTO>();
        bindPhoneListToGrid(virtualPhoneDTOList);
        pnlVirtualPhoneEmpty.Visible = (virtualPhoneDTOList == null || virtualPhoneDTOList.Count == 0);
    }
    private void bindPhoneListToGrid(ISet<VirtualPhoneDTO> virtualPhoneDTOList)
    {
        virtualPhoneGrid.DataSource = virtualPhoneDTOList;
        virtualPhoneGrid.DataBind();
    }
    private void fetchUsersForSelectedVirtualPhone(long vPhoneId)
    {
        UserAssignmentDiv.Visible = true;
        VirtualPhoneUserAccessPageDTO PageDTO = getSessionPageData();
        IList<FirmMemberDTO> result = propertyUserBO.fetchUsersForVitualPhone(vPhoneId, PageDTO.Property.Id);
        PageDTO.UnassignedUserList = new List<FirmMemberDTO>();
        PageDTO.AssignedUserList = new List<FirmMemberDTO>();
        PageDTO.UIUnassignedUserList = new List<FirmMemberDTO>();
        PageDTO.UIAssignedUserList = new List<FirmMemberDTO>();
        foreach (FirmMemberDTO tmpDTO in result)
        {
        	if(tmpDTO.hasAccessToVirtualPhone) PageDTO.AssignedUserList.Add(tmpDTO);
        	else PageDTO.UnassignedUserList.Add(tmpDTO);
        }
        applySearchCriteriaOnUnassignedUsers();
        applySearchCriteriaOnAssignedUsers();
    }
    private void applySearchCriteriaOnUnassignedUsers()
    {
        VirtualPhoneUserAccessPageDTO PageDTO = getSessionPageData();
        PageDTO.UIUnassignedUserList.Clear();
        string unassignedUserText = txtUnassignedUserSearch.Text.Trim();
        if (!string.IsNullOrWhiteSpace(unassignedUserText))
        {
            PageDTO.UIUnassignedUserList.AddRange(PageDTO.UnassignedUserList.FindAll(x => x.FullName.ToUpper().Contains(unassignedUserText.ToUpper())));
        }
        else
        {
            PageDTO.UIUnassignedUserList.AddRange(PageDTO.UnassignedUserList);
        }
        UnassignedUserGrid.DataSource = PageDTO.UIUnassignedUserList;
        UnassignedUserGrid.DataBind();
    }
    private void applySearchCriteriaOnAssignedUsers()
    {
        VirtualPhoneUserAccessPageDTO PageDTO = getSessionPageData();
        PageDTO.UIAssignedUserList.Clear();
        string assignedUserText = txtAssignedUserSearch.Text.Trim();
        PageDTO.UIAssignedUserList.Clear();
        if (!string.IsNullOrWhiteSpace(assignedUserText))
        {
            PageDTO.UIAssignedUserList.AddRange(PageDTO.AssignedUserList.FindAll(x => x.FullName.ToUpper().Contains(assignedUserText.ToUpper())));
        }
        else
        {
            PageDTO.UIAssignedUserList.AddRange(PageDTO.AssignedUserList);
        }
        assignedUserGrid.DataSource = PageDTO.UIAssignedUserList;
        assignedUserGrid.DataBind();
    }
    private VirtualPhoneDTO getActiveVirtualPhone()
    {
        List<VirtualPhoneDTO> vPhoneList = getSessionPageData().Property.VirtualPhones.ToList<VirtualPhoneDTO>();
        return vPhoneList.Find(c => c.isUIActive);
    }
    protected void searchUserInUnassignedList(object sender, EventArgs e)
    {
        try
        {
            VirtualPhoneUserAccessPageDTO PageDTO = getSessionPageData();
            VirtualPhoneDTO phoneDTO = getActiveVirtualPhone();
            if (phoneDTO != null)
            {
            	applySearchCriteriaOnUnassignedUsers();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void moveAllUsersToAssignedList(object sender, EventArgs e) {
    	try
        {
    		VirtualPhoneUserAccessPageDTO PageDTO = getSessionPageData();
    		VirtualPhoneDTO phoneDTO = getActiveVirtualPhone();
    		if(phoneDTO != null) {
    			if(PageDTO.UIUnassignedUserList.Count > 0) {
                    propertyUserBO.addOrRemoveUsersForVirtualPhone(phoneDTO.Id, PageDTO.UIUnassignedUserList, true);
                    fetchPhoneList(PageDTO.Property.Id);
                    setActiveVirtualPhone(phoneDTO.Id);
                	fetchUsersForSelectedVirtualPhone(phoneDTO.Id);
                	(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("All users are assigned to virtual number."));
        		} else {
        			(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("No user is available for assignment."));
        		}
    		}
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void moveSelectedUsersToAssignedList(object sender, EventArgs e) {
    	try
        {
    		VirtualPhoneUserAccessPageDTO PageDTO = getSessionPageData();
    		VirtualPhoneDTO phoneDTO = getActiveVirtualPhone();
    		if(phoneDTO != null) {
    			List<FirmMemberDTO> selectedUsers = new List<FirmMemberDTO>();
            	foreach (ListViewItem item in UnassignedUserGrid.Items)
                {
                    CheckBox chBox = (CheckBox)item.FindControl("cbUnassignedUser");
                    if (chBox.Checked)
                    {
                    	HiddenField hdnField = (HiddenField)item.FindControl("UnassignedUserIdHdn");
                    	long selectedId = long.Parse(hdnField.Value);
                        FirmMemberDTO tmpDTO = PageDTO.UIUnassignedUserList.Find(x => x.Id == selectedId);
                        if (tmpDTO != null) selectedUsers.Add(tmpDTO);
                    }
                }
            	if(selectedUsers.Count > 0) {
                    propertyUserBO.addOrRemoveUsersForVirtualPhone(phoneDTO.Id, selectedUsers, true);
                    fetchPhoneList(PageDTO.Property.Id);
                    setActiveVirtualPhone(phoneDTO.Id);
                	fetchUsersForSelectedVirtualPhone(phoneDTO.Id);
                	(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("Selected users are assigned to virtual number."));
            	} else {
        			(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please select user."));
        		}
    		}
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void searchUserInAssignedList(object sender, EventArgs e)
    {
        try
        {
            VirtualPhoneUserAccessPageDTO PageDTO = getSessionPageData();
            VirtualPhoneDTO phoneDTO = getActiveVirtualPhone();
            if (phoneDTO != null)
            {
            	applySearchCriteriaOnAssignedUsers();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void moveAllUsersToUnAssignedList(object sender, EventArgs e) {
    	try
        {
    		VirtualPhoneUserAccessPageDTO PageDTO = getSessionPageData();
    		VirtualPhoneDTO phoneDTO = getActiveVirtualPhone();
    		if(phoneDTO != null) {
    			if(PageDTO.UIAssignedUserList.Count > 0) {
                    propertyUserBO.addOrRemoveUsersForVirtualPhone(phoneDTO.Id, PageDTO.UIAssignedUserList, false);
                    fetchPhoneList(PageDTO.Property.Id);
                    setActiveVirtualPhone(phoneDTO.Id);
                	fetchUsersForSelectedVirtualPhone(phoneDTO.Id);
                	(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("All users are removed from assigned list."));
        		} else {
        			(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("No user has access to virtual number."));
        		}
    		}
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void moveSelectedUsersToUnAssignedList(object sender, EventArgs e) {
    	try
        {
    		VirtualPhoneUserAccessPageDTO PageDTO = getSessionPageData();
    		VirtualPhoneDTO phoneDTO = getActiveVirtualPhone();
    		List<FirmMemberDTO> selectedUsers = new List<FirmMemberDTO>();
        	foreach (ListViewItem item in assignedUserGrid.Items)
            {
                CheckBox chBox = (CheckBox)item.FindControl("cbAssignedUser");
                if (chBox.Checked)
                {
                	HiddenField hdnField = (HiddenField)item.FindControl("AssignedUserIdHdn");
                	long selectedId = long.Parse(hdnField.Value);
                	FirmMemberDTO tmpDTO = PageDTO.UIAssignedUserList.Find(x => x.Id == selectedId);
                    if (tmpDTO != null) selectedUsers.Add(tmpDTO);
                }
            }
        	if(selectedUsers.Count > 0) {
                propertyUserBO.addOrRemoveUsersForVirtualPhone(phoneDTO.Id, selectedUsers, false);
                fetchPhoneList(PageDTO.Property.Id);
                setActiveVirtualPhone(phoneDTO.Id);
            	fetchUsersForSelectedVirtualPhone(phoneDTO.Id);
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("Selected users are removed from assigned list."));
        	} else {
    			(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please select user."));
    		}
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setActiveVirtualPhone(long Id)
    {
        VirtualPhoneUserAccessPageDTO PageDTO = getSessionPageData();
        ISet<VirtualPhoneDTO> tmpList = PageDTO.Property.VirtualPhones;
        tmpList.ToList<VirtualPhoneDTO>().ForEach(x => x.isUIActive = false);
        VirtualPhoneDTO phoneDTO = tmpList.ToList<VirtualPhoneDTO>().Find(x => x.Id == Id);
        phoneDTO.isUIActive = true;
        populateVirtualPhoneGrid(tmpList);
    }
    protected void onChangeVirtualPhoneSelection(object sender, EventArgs e)
    {
        try
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setActiveVirtualPhone(selectedIndex);
            fetchUsersForSelectedVirtualPhone(selectedIndex);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Virtual Phone Modal - Start
    private void initVirtualPhoneModalFields()
    {
        lbVirtualPhoneModalTitle.Text = (VirtualPhoneAction.ADD.ToString().Equals(virtualPhoneModalActionHdnBtn.Value))
                ? Constants.ICON.ADD + Resources.Labels.ADD_VIRTUAL_PHONE : Constants.ICON.MODIFY + Resources.Labels.MODIFY_VIRTUAL_PHONE;
    }
    private void initVirtualPhoneSectionFields(VirtualPhoneDTO vPhoneDTO)
    {
        if (vPhoneDTO != null) txtPhoneNumber.Text = vPhoneDTO.PhoneNumber; else txtPhoneNumber.Text = null;
        if (vPhoneDTO != null) drpPhoneType.Text = vPhoneDTO.PhoneType.ToString(); else drpPhoneType.ClearSelection();
    }
    private void populateVirtualPhoneFromUI(VirtualPhoneDTO vPhoneDTO)
    {
        vPhoneDTO.PhoneNumber = txtPhoneNumber.Text;
        vPhoneDTO.PhoneType = EnumHelper.ToEnum<PhoneType>(drpPhoneType.Text);
        vPhoneDTO.UpdateUser = getUserDefinitionDTO().Username;
    }
    private VirtualPhoneDTO populateVirtualPhoneAdd()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        VirtualPhoneUserAccessPageDTO PageDTO = getSessionPageData();

        VirtualPhoneDTO vPhoneDTO = new VirtualPhoneDTO();
        vPhoneDTO.Property = CommonUIConverter.getPropertyDTO(PageDTO.Property.Id.ToString(), null);

        vPhoneDTO.FirmNumber = userDefDto.FirmNumber;
        vPhoneDTO.InsertUser = userDefDto.Username;
        vPhoneDTO.UpdateUser = userDefDto.Username;
        return vPhoneDTO;
    }
    private void setSelectedVirtualPhone(long Id)
    {
        List<VirtualPhoneDTO> vPhoneList = getSessionPageData().Property.VirtualPhones.ToList<VirtualPhoneDTO>();
        vPhoneList.ForEach(c => c.isUISelected = false);
        if (Id > 0) vPhoneList.Find(c => c.Id == Id).isUISelected = true;
    }
    private VirtualPhoneDTO getSelectedVirtualPhone(long Id)
    {
        List<VirtualPhoneDTO> vPhoneList = getSessionPageData().Property.VirtualPhones.ToList<VirtualPhoneDTO>();
        return (Id > 0) ? vPhoneList.Find(c => c.Id == Id) : vPhoneList.Find(c => c.isUISelected);
    }
    protected void onClickAddVirtualPhoneBtn(object sender, EventArgs e)
    {
        try
        {
            virtualPhoneModalActionHdnBtn.Value = VirtualPhoneAction.ADD.ToString();
            initVirtualPhoneModalFields();
            setSelectedVirtualPhone(-1);
            initVirtualPhoneSectionFields(null);
            activeModalHdn.Value = addModifyVirtualPhoneModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyVirtualPhoneBtn(object sender, EventArgs e)
    {
        try
        {
            virtualPhoneModalActionHdnBtn.Value = VirtualPhoneAction.MODIFY.ToString();
            initVirtualPhoneModalFields();
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedVirtualPhone(selectedIndex);
            initVirtualPhoneSectionFields(getSelectedVirtualPhone(0));
            activeModalHdn.Value = addModifyVirtualPhoneModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void deleteVirtualPhone(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            VirtualPhoneDTO vPhoneDTO = getSelectedVirtualPhone(selectedIndex);
            propertyUserBO.deletePropertyVirtualPhone(vPhoneDTO.Id);
            fetchVirtualPhones(getSessionPageData().Property.Id);
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECORD_DELETE_SUCCESS, "Virtual Phone")));
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void saveVirtualPhone(object sender, EventArgs e)
    {
        try
        {
            if (validateVirtualPhoneAdd())
            {
                VirtualPhoneDTO vPhoneDTO = null;
                string msg = "";
                if (VirtualPhoneAction.ADD.ToString().Equals(virtualPhoneModalActionHdnBtn.Value))
                {
                    vPhoneDTO = populateVirtualPhoneAdd();
                    msg = string.Format(Resources.Messages.RECORD_ADDED_SUCCESS, "Virtual Phone");
                }
                else
                {
                    vPhoneDTO = getSelectedVirtualPhone(0);
                    msg = string.Format(Resources.Messages.RECORD_MODIFY_SUCCESS, "Virtual Phone");
                }
                populateVirtualPhoneFromUI(vPhoneDTO);
                propertyUserBO.addOrUpdateVirtualPhone(vPhoneDTO);
                fetchVirtualPhones(getSessionPageData().Property.Id);
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(msg));
            }
            else
            {
                activeModalHdn.Value = addModifyVirtualPhoneModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelVirtualPhoneModal(object sender, EventArgs e)
    {
        try
        {
            setSelectedVirtualPhone(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateVirtualPhoneAdd()
    {
        Page.Validate(addModifyVirtualPhoneModalError);
        return Page.IsValid;
    }
    //Virtual Phone Modal - End
}