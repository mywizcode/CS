﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Vladsm.Web.UI.WebControls;

namespace ConstroSoft.pages.MasterDataManagement
{
    public partial class ManageMasterData : System.Web.UI.Page
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string tab1ValidationGrp = "tab1Error";
        string VS_MASTER_DATA_LIST = "MASTER_DATA_LIST";
        DropdownBO drpBO = new DropdownBO();        
        MasterDataBO masterDataBO = new MasterDataBO();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            clearMessages();
            if (!IsPostBack)
            {
                if (Session[Constants.Session.USERNAME] != null)
                {
                    resetPageInfo(PageMode.NONE);
                    initDropdowns();
                    Page.MaintainScrollPositionOnPostBack = false;
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
        }
        private void initDropdowns()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];           
            drpBO.drpEnum<MasterDataType>(drpMasterDataType, null);//Constants.SELECT_ITEM);          
            drpBO.drpEnum<MasterDataType>(drpSelecMasterDataType, null);
            drpBO.drpEnum<SystemDefined>(drpSystemDefined, null);
        }
        /**
         * This method is called just before the page is rendered. So any change in state of the element is applied.
         **/
        protected void Page_PreRender(object sender, EventArgs e)
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        private bool isViewOnlyUser()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            bool isViewOnlyUser = !CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.FIRM_MEMBER_ADD_UPDATE);
            return isViewOnlyUser;
        }
        private void applyEntitlement()
        {
            if (isViewOnlyUser())
            {
                resetPageInfo(PageMode.VIEW);
            }
        }

        private void preRenderInitFormElements()
        {
            jumpToMasterDataHdnId.Value = "";
            MasterControlDataDTO masterContolDTO = getSelectedMasterData();
            if (masterContolDTO != null)
            {
                jumpToMasterDataHdnId.Value = masterContolDTO.UiIndex + "";
            }
        }
        public void setErrorMessage(string message, string group)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }

        public void setSuccessMessage(string msg)
        {
            lbTab1Success.Text = msg;
            tab1SuccessPanel.Visible = true;
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        public void initBootstrapComponantsFromServer()
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
        }
        private void clearMessages()
        {
            tab1SuccessPanel.Visible = false;
            lbTab1Success.Text = "";
        }
        private UserDefinitionDTO getUserDefinitionDTO()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }

        private void resetPageInfo(PageMode pageMode)
        {
            pageModeHdn.Value = pageMode.ToString();
            initFormFields();
            pnlMasterDataAdd.Visible = false;
            if (PageMode.NONE == pageMode)
            {
                pnlMasterDataGrid.Visible = false;
                ViewState[VS_MASTER_DATA_LIST] = new List<MasterControlDataDTO>();
            }
            else
            {
                pnlMasterDataGrid.Visible = true;
            }
        }
        private void initFormFields()
        {
            bool isReadOnly = (PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            bool visible = !(PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            //Buttons
            btnAddSubmit.Visible = visible;
            btnAddMasterData.Visible = visible;            
            btnModifyMasterData.Visible = visible;
            btndeleteMasterData.Visible = visible;
            masterControlGrid.Columns[0].Visible = visible;
        }
        private List<MasterControlDataDTO> getMasterDataList()
        {            
            return (List<MasterControlDataDTO>)ViewState[VS_MASTER_DATA_LIST];
        }
        private MasterControlDataDTO getSelectedMasterData()
        {
            MasterControlDataDTO selectedMasterData = null;            
                List<MasterControlDataDTO> masterDataList = getMasterDataList();
                if (masterDataList != null && masterDataList.Count != 0)
                {
                    selectedMasterData = masterDataList.Find(c => c.isUISelected);
                }            
            return selectedMasterData;
        }
        private void setSelectedMasterData(long selectedUiIndex)
        {
            List<MasterControlDataDTO> masterDataList = getMasterDataList();
            if (masterDataList != null)
            {
                masterDataList.ForEach(c => c.isUISelected = false);
                if (selectedUiIndex != -1) masterDataList.Find(c => c.UiIndex == selectedUiIndex).isUISelected = true;
            }
        }
        private void initMasterDataAddUpdateSection(bool isAdd)
        {
            lbMasterDataAddUpdateSectionHeader.Text = (isAdd) ? Resources.Labels.label_sectionheader_master_masterdataadd : Resources.Labels.label_sectionheader_master_masterdataupdate;
            pnlMasterDataAdd.Visible = true;
            btnMasterdataAddToGrid.Visible = isAdd;
            btnMasterDataUpdateToGrid.Visible = !isAdd;
        }

        private void initMasterDataSectionFields(MasterControlDataDTO masterdataDTO)
        {
            if (masterdataDTO != null && masterdataDTO.Type != null) drpSelecMasterDataType.Text = masterdataDTO.Type.ToString(); else drpSelecMasterDataType.ClearSelection(); ;
            if (masterdataDTO != null) txtmasterdataname.Text = masterdataDTO.Name; else txtmasterdataname.Text = null;
            if (masterdataDTO != null) txtDescription.Text = masterdataDTO.Description.ToString(); else txtDescription.Text = null;
            if (masterdataDTO != null) drpSystemDefined.Text = masterdataDTO.SystemDefined.ToString(); else drpSystemDefined.ClearSelection();
            if (masterdataDTO == null) drpSelecMasterDataType.Text = drpMasterDataType.Text;
            if (masterdataDTO == null) drpSystemDefined.Text = SystemDefined.No.ToString();
        }
        private void resetMasterDataSelection(long uiIndex)
        {
            if (masterControlGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in masterControlGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdMasterDataSelect");
                    radioBtn.Checked = false;
                    if (uiIndex > 0)
                    {
                        Button rowIdenBtn = (Button)row.FindControl("btnMasterDataRowIdentifier");
                        if (rowIdenBtn != null && uiIndex.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                        {
                            radioBtn.Checked = true;
                            setSelectedMasterData(uiIndex);
                        }
                    }
                }
            }
            if (uiIndex <= 0) setSelectedMasterData(-1);
        }
        private bool validateMasterDataSelected()
        {
            bool isSelected = true;
            MasterControlDataDTO selectedMasterData = getSelectedMasterData();
            if (selectedMasterData == null)
            {
                isSelected = false;
                setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Master Data"), tab1ValidationGrp);
            }
            return isSelected;
        }
        private bool validateSystemDefined()
        {
            bool isSystemDefined= true;
            
            MasterControlDataDTO selectedMasterData = getSelectedMasterData();
            if (selectedMasterData == null) {
                List<MasterControlDataDTO> masterDataList = getMasterDataList();
                if (masterDataList != null && masterDataList.Count() > 0)
                {
                    selectedMasterData = masterDataList.First();
                }
            }
            if (selectedMasterData != null && selectedMasterData.SystemDefined == SystemDefined.Yes)
            {
                isSystemDefined = false;
                setErrorMessage(Resources.Messages.validation_master_system_defined, tab1ValidationGrp);
            }
            return isSystemDefined;
        }
        private void reBindMasterDataGrid(List<MasterControlDataDTO> masterDataList, MasterControlDataDTO masterDataDto)
        {
            if (masterDataList != null)            
            {
                assignUiIndexToMasterData(masterDataList);
                masterControlGrid.DataSource = masterDataList;
                masterControlGrid.DataBind();
                if (masterDataDto != null) resetMasterDataSelection(masterDataDto.UiIndex);
            }
        }
        private void assignUiIndexToMasterData(List<MasterControlDataDTO> masterControlDtos)
        {
            if (masterControlDtos != null && masterControlDtos.Count > 0)
            {
                masterControlDtos.ForEach(c => c.isUISelected = false);
                long uiIndex = 1;
                foreach (MasterControlDataDTO masterControlDto in masterControlDtos)
                {
                    masterControlDto.UiIndex = uiIndex++;
                    masterControlDto.RowInfo = CommonUIConverter.getGridViewRowInfo(masterControlDto);     //to do
                }
            }
        }
        private void loadmasterDataGrid()
        {
            try
            {
                List<MasterControlDataDTO> results = new List<MasterControlDataDTO>();
                if (!(string.IsNullOrWhiteSpace(drpMasterDataType.Text)))
                {
                    results = masterDataBO.fetchMasterData(getUserDefinitionDTO().FirmNumber, drpMasterDataType.Text);
                    assignUiIndexToMasterData(results);
                }
                ViewState[VS_MASTER_DATA_LIST] = results;
                masterControlGrid.DataSource = results;
                masterControlGrid.DataBind();
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void saveModalData(object sender, EventArgs e)
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (modalHdnType.Value == "PARKINGTYPE")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_PARKING_TYPE, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "PARKINGTYPE");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                   // drpBO.drpDataBase(drpMasterDataName, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_PARKING_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                modalErrorMsg.Value = errorMsg;
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "setModalErrorMsg", "setModalErrorMsg()", true);
            }
            else
            {
                //Reset the modal fields
                modalInput1.Text = "";
                modalInput2.Text = "";
                modalHdnType.Value = "";
                modalActionHdn.Value = "";
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "closeDialogClient", "closeDialogClient()", true);
            }
        }
        private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
        {
            string errorMsg = "";
            if (string.IsNullOrWhiteSpace(masterDataDto.Name))
            {
                errorMsg = Resources.Messages.validation_designationname_required;
            }
            else if (masterDataBO.isAlreadyExist(masterDataDto))
            {
                errorMsg = string.Format(Resources.Messages.validation_same_name_exist, type);
            }
            return errorMsg;
        }
        protected void onSelectMasterDataType(object sender, EventArgs e)
        {
            try
            {
                resetPageInfo(PageMode.NONE);
               
                MasterDataType searchBy = EnumHelper.ToEnum<MasterDataType>(drpMasterDataType.Text);
                UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
                drpSelecMasterDataType.Text = drpMasterDataType.Text;
                resetPageInfo(PageMode.ADD);
                loadmasterDataGrid();               
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
       
        protected void onSelectMasterData(object sender, EventArgs e)
        {
            try
            {
                GroupRadioButton rd = (GroupRadioButton)sender;
                pnlMasterDataAdd.Visible = false;
                //lbSearchByValue.Visible = true;
                //drpMasterDataName.Visible = true;
                if (rd.Checked)
                {
                    long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnMasterDataRowIdentifier"))).Attributes["row-identifier"]);
                    setSelectedMasterData(UiIndex);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickAddMaserDataBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateSystemDefined())
                {
                    resetMasterDataSelection(-1);
                    initMasterDataAddUpdateSection(true);
                    initMasterDataSectionFields(null);
                    SetFocus(drpSelecMasterDataType);
                    scrollToFieldHdn.Value = pnlMasterDataAdd.ID;
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickModifyMasterDataBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateMasterDataSelected() && validateSystemDefined())
                {
                    initMasterDataAddUpdateSection(false);
                    initMasterDataSectionFields(getSelectedMasterData());
                    SetFocus(drpSelecMasterDataType);
                    scrollToFieldHdn.Value = pnlMasterDataAdd.ID;
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void deleteMasterData(object sender, EventArgs e)
        {
            try
            {
                if (validateMasterDataSelected() && validateSystemDefined())
                {
                    List<MasterControlDataDTO> masterDataList = getMasterDataList();
                    MasterControlDataDTO masterControlDataDto = getSelectedMasterData();
                    masterDataList.Remove(masterControlDataDto);
                    reBindMasterDataGrid(masterDataList, null);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, "Master Data"));
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void addNewMasterData(object sender, EventArgs e)
        {
            try
            {
                if (validateMasterData())
                {
                    MasterControlDataDTO masterControlDto = populateMasterControlDTOAddFromUI();
                    List<MasterControlDataDTO> masterDataList = getMasterDataList();
                    if (validateMasterContolName(masterControlDto, masterDataList))
                    {
                        masterDataList.Add(masterControlDto);
                        pnlMasterDataAdd.Visible = false;
                        reBindMasterDataGrid(masterDataList, masterControlDto);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, "Master Data"));
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        private bool validateMasterContolName(MasterControlDataDTO masterDataDTO, List<MasterControlDataDTO> masterDataList)
        {
            bool isValid = true;
            int index = masterDataList.FindIndex(item => (item.Name == masterDataDTO.Name) && (item.Id != masterDataDTO.Id));
            if (index >= 0)
            {
                setErrorMessage(Resources.Messages.validation_property_parking_number, tab1ValidationGrp);
                isValid = false;
            }
            return isValid;
        }

        protected void updateMasterData(object sender, EventArgs e)
        {
            try
            {
                if (validateMasterData())
                {
                    MasterControlDataDTO masterControlDataDto = getSelectedMasterData();
                    populateMasterDataFromUI(masterControlDataDto);
                    if (validateMasterContolName(masterControlDataDto, getMasterDataList()))
                    {
                        pnlMasterDataAdd.Visible = false;
                        reBindMasterDataGrid(getMasterDataList(), masterControlDataDto);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_updatedtotable, "Master Data"));
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void cancelMasterData(object sender, EventArgs e)
        {
            pnlMasterDataAdd.Visible = false;
            resetMasterDataSelection(-1);
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        protected void saveMasterDataToDB(object sender, EventArgs e)
        {
            try
            {
                List<MasterControlDataDTO> masterDataList = getMasterDataList();
                string masterDataType = drpMasterDataType.Text;
                UserDefinitionDTO userDef = getUserDefinitionDTO();
                string firmNumber = userDef.FirmNumber; 
                masterDataBO.saveOrUpdateMasterData(firmNumber, masterDataType, masterDataList);
                pnlMasterDataAdd.Visible = false;
                loadmasterDataGrid();
                setSuccessMessage(Resources.Messages.success_master_data_update);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private MasterControlDataDTO populateMasterControlDTOAddFromUI()
        {
            UserDefinitionDTO userDef = getUserDefinitionDTO();
            MasterControlDataDTO masterControlDTO = new MasterControlDataDTO();
            masterControlDTO.FirmNumber = userDef.FirmNumber;            
            masterControlDTO.InsertUser = userDef.Username;
            populateMasterDataFromUI(masterControlDTO);
            return masterControlDTO;
        }
        private void populateMasterDataFromUI(MasterControlDataDTO masterDataDTO)
        {
            masterDataDTO.Name = txtmasterdataname.Text;
            masterDataDTO.Type = EnumHelper.ToEnum<MasterDataType>(drpSelecMasterDataType.Text).ToString();//
            masterDataDTO.SystemDefined = EnumHelper.ToEnum<SystemDefined>(drpSystemDefined.Text);
            masterDataDTO.Description = txtDescription.Text;            
            masterDataDTO.UpdateUser = getUserDefinitionDTO().Username;
        }

        private bool validateMasterData()
        {
            bool isValid = true;
            Page.Validate(tab1ValidationGrp);
            isValid = Page.IsValid;
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
    }
}