﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Vladsm.Web.UI.WebControls;

namespace ConstroSoft.pages.PropertyExpences
{
    public partial class ManagePropertyExpence : System.Web.UI.Page
    {
        private static readonly log4net.ILog log =
              log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string tab1ValidationGrp = "tab1Error";
        string tab2ValidationGrp = "tab2Error";
        string VS_EXPENCES_LIST = "EXPENCESS_LIST";
        string VS_SELECTED_EXPENCESS = "SELECTED_EXPENCESS";
        DropdownBO drpBO = new DropdownBO();
        EmployeeBO employeeBO = new EmployeeBO();
        PropertyExpense propertyExpencess = new PropertyExpense();
        PropertyBO propertyBO = new PropertyBO();
        MasterDataBO masterDataBO = new MasterDataBO();
        DepartmentBO departmentBO = new DepartmentBO();
        protected void Page_Load(object sender, EventArgs e)
        {
            clearMessages();
            if (!IsPostBack)
            {
                if (Session[Constants.Session.USERNAME] != null)
                {
                    resetTabInfo(PageMode.NONE);
                    initDropdowns();
                    loadSearchGridAndReSelect(0);
                    Page.MaintainScrollPositionOnPostBack = false;
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
        }
        private void initDropdowns()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            drpBO.drpEnum<ExpencessSearchBy>(drpSearchBy, null);
            drpBO.drpDataBase(drpProperty, DrpDataType.PROPERTY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpEmployeeName, DrpDataType.EMPLOYEE_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpAgency, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.AGENCY, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpExpencessType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_EXPENSE_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpDocumentType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.DOCUMENT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);              
        }
        /**
         * This method is called just before the page is rendered. So any change in state of the element is applied.
         **/
        protected void Page_PreRender(object sender, EventArgs e)
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        private bool isViewOnlyUser()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            bool isViewOnlyUser = !CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.FIRM_MEMBER_ADD_UPDATE);
            return isViewOnlyUser;
        }
        private void applyEntitlement()
        {
            if (isViewOnlyUser())
            {
                btnAddPropertyExpences.Visible = false;
                btnModifyPropertyExpencess.Visible = false;
                btnDeletePropertyExpencess.Visible = false;
                btnLinkManageExpencess.Visible = false;
            }
        }
        private void preRenderInitFormElements()
        {
            PropertyExpenseDTO  selectedExpencess = getCurrentExpences();
            jumpToExpencessHdnId.Value = null;
            jumpToPropertyExpencessHdnId.Value = null;
            hdnExpencessDetailsHDN.Value = null;
            if (selectedExpencess != null)
            {
                jumpToExpencessHdnId.Value = selectedExpencess.Id.ToString();
                List<DocumentDTO> documentList = selectedExpencess.DocumentInfo.Documents.ToList<DocumentDTO>();
                if (documentList != null && documentList.Count > 0)
                {
                    DocumentDTO selecteddocument = documentList.Find(a => a.isUISelected);
                    if (selecteddocument != null) jumpToPropertyExpencessHdnId.Value = selecteddocument.UiIndex.ToString();
                }
            }
        }
        public void setErrorMessage(string message, string group)
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }

        public void setSuccessMessage(string msg, string tabId)
        {
            activeTabHdn.Value = tabId;
            if (tabId.Equals(tab1Anchor.ID))
            {
                lbTab1Success.Text = msg;
                tab1SuccessPanel.Visible = true;
            }
            else if (tabId.Equals(tab2Anchor.ID))
            {
                lbTab2Success.Text = msg;
                tab2SuccessPanel.Visible = true;
            }
        }
        public void initBootstrapComponantsFromServer()
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
        }
        private void clearMessages()
        {
            tab1SuccessPanel.Visible = false;
            lbTab1Success.Text = "";
            tab2SuccessPanel.Visible = false;
            lbTab2Success.Text = "";
            tab3SuccessPanel.Visible = false;
            lbTab3Success.Text = "";
        }
        private UserDefinitionDTO getUserDefinitionDTO()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }

        private void resetTabInfo(PageMode pageMode)
        {
            tab2Anchor.Visible = true;
            activeTabHdn.Value = tab2Anchor.ID;
            
            pageModeHdn.Value = pageMode.ToString();
            initFormFields();
            pnlExpencessAdd.Visible = false;            
            if (PageMode.ADD == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.empm_sm_manage_exp_tab2_add_name;                
                initFormFields();
            }
            else if (PageMode.MODIFY == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.empm_sm_manage_exp_tab2_update_name;               
                initFormFields();
            }
            else if (PageMode.VIEW == pageMode)
            {                
                tab3Anchor.Text = Resources.Labels.empm_sm_manage_exp_tab2_view_name;
                tab2Anchor.Visible = false;    
                tab3Anchor.Visible = true;
                activeTabHdn.Value = tab3Anchor.ID;
                initFormFields();
            }
            else
            {
                activeTabHdn.Value = tab1Anchor.ID;
                tab2Anchor.Visible = false;
                tab3Anchor.Visible = false;
                ViewState[VS_SELECTED_EXPENCESS] = null;
            }
        }
        private void initFormFields()
        {
            bool isReadOnly = (PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            bool visible = !(PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            //Buttons
            btnViewPropertyExpencess.Visible = visible;
            btnLinkManageExpencess.Visible = visible;
            btnAddSubmit.Visible = visible;
            addExpencessTypeBtn.Visible = visible;
            lnkAddAgency.Visible = visible;
            btnAddPropertyExpences.Visible = visible;
           // btnModifyExpencess.Visible = visible;            
            btnDeleteExpencess.Visible = visible;
            lnkAddDocumentType.Visible = visible;
            lnkAddAgency.Visible = visible;
            btnLinkManageExpencess.Visible = visible;
            btnExpencessDetailsView.Visible = visible;
            propertyexpencessGrid.Columns[0].Visible = visible;
            
        }
        private PropertyExpenseDTO getCurrentExpences()
        {
            return (PropertyExpenseDTO)ViewState[VS_SELECTED_EXPENCESS];
        }
        private void setSelectedExpencess(long selectedId)
        {
            List<PropertyExpenseDTO> expencessList = (List<PropertyExpenseDTO>)ViewState[VS_EXPENCES_LIST];
            if (expencessList != null)
            {
                expencessList.ForEach(c => c.isUISelected = false);
                if (selectedId > 0) expencessList.Find(c => c.Id == selectedId).isUISelected = true;
            }
        }
        private bool validateExpencessSelected()
        {
            bool isSelected = true;
            List<PropertyExpenseDTO> expencessList = (List<PropertyExpenseDTO>)ViewState[VS_EXPENCES_LIST];
            if (expencessList != null)
            {
                isSelected = expencessList.Any(c => c.isUISelected);
                if (!isSelected)
                {
                    resetTabInfo(PageMode.NONE);
                    setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Property Expencess"), tab1ValidationGrp);
                }
            }
            return isSelected;
        }
        private void selectExpencessGridRdBtn(long Id)
        {
            if (propertyexpencessGrid.Rows.Count > 0)
            {
                setSelectedExpencess(0);
                foreach (GridViewRow row in propertyexpencessGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdExpencessSelect");
                    Button rowIdenBtn = (Button)row.FindControl("btnExpRowIdentifier");
                    if (radioBtn != null)
                    {
                        radioBtn.Checked = false;
                        if (rowIdenBtn != null && Id > 0 && Id.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                        {
                            radioBtn.Checked = true;
                            setSelectedExpencess(Id);
                        }
                    }
                }
            }
        }
        private void loadSearchGridAndReSelect(long Id)
        {
            try
            {
                ExpencessSearchBy searchBy = EnumHelper.ToEnum<ExpencessSearchBy>(drpSearchBy.Text);
                long searchByValId = -1;
                if (!string.IsNullOrWhiteSpace(drpSearchByValue.Text)) searchByValId = long.Parse(drpSearchByValue.Text);
                IList<PropertyExpenseDTO> results = propertyBO.fetchPropertyExpensesGrid(long.Parse(getUserDefinitionDTO().FirmNumber), searchByValId);
                ViewState[VS_EXPENCES_LIST] = results;
                propertyexpencessGrid.DataSource = results;
                propertyexpencessGrid.DataBind();
                if (Id > 0)
                {
                    selectExpencessGridRdBtn(Id);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        private void loadSearchexpencessDetaulGridAndReSelect(long Id)
        {
            try
            {
                ExpencessSearchBy searchBy = EnumHelper.ToEnum<ExpencessSearchBy>(drpSearchBy.Text);
                long searchByValId = -1;
                if (!string.IsNullOrWhiteSpace(drpSearchByValue.Text)) searchByValId = long.Parse(drpSearchByValue.Text);
                IList<PropertyExpenseDTO> results = propertyBO.fetchPropertyExpensesGrid(long.Parse(getUserDefinitionDTO().FirmNumber), searchByValId);
                ViewState[VS_EXPENCES_LIST] = results;
                GridViewExpencessDetails.DataSource = results;
                GridViewExpencessDetails.DataBind();
                if (Id > 0)
                {
                    selectExpencessGridRdBtn(Id);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        private void fetchSelectedExpencess()
        {
            try
            {
               PropertyExpenseDTO propertyexpencessDto = null;
                if (PageMode.ADD.ToString().Equals(pageModeHdn.Value))
                {
                    propertyexpencessDto = populateExpencessDTOAdd();
                    selectExpencessGridRdBtn(0);
                    loadSearchexpencessDetaulGridAndReSelect(0);
                }
                else if (PageMode.MODIFY.ToString().Equals(pageModeHdn.Value) || PageMode.VIEW.ToString().Equals(pageModeHdn.Value))
                {
                    long Id = ((List<PropertyExpenseDTO>)ViewState[VS_EXPENCES_LIST]).Find(c => c.isUISelected).Id;
                    propertyexpencessDto = propertyBO.fetchPropertyExpenses(Id);
                }
                ViewState[VS_SELECTED_EXPENCESS] = propertyexpencessDto;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void doViewModifyAction(PageMode pageMode)
        {
            resetTabInfo(pageMode);
            fetchSelectedExpencess();
            populateUIFieldsFromDTO((PropertyExpenseDTO)ViewState[VS_SELECTED_EXPENCESS]);
        }
        protected void onSearchBy(object sender, EventArgs e)
        {
            try
            {
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                ExpencessSearchBy searchBy = EnumHelper.ToEnum<ExpencessSearchBy>(drpSearchBy.Text);
                drpSearchByValue.Visible = true;
                lbSearchByValue.Visible = true;
                lbSearchByValue.Text = EnumHelper.GetEnumDescription<ExpencessSearchBy>(searchBy.ToString());
                if (ExpencessSearchBy.PROPERTY_LOCATION == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.PROPERTY_LOCATION, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (ExpencessSearchBy.PROPERTY_NAME == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.PROPERTY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (ExpencessSearchBy.PROPERTY_TYPE == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.PROPERTY_TYPE, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else
                {
                    drpSearchByValue.ClearSelection();
                    drpSearchByValue.Visible = false;
                    lbSearchByValue.Visible = false;
                }
                loadSearchGridAndReSelect(0);
                resetTabInfo(PageMode.NONE);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onSearchByValue(object sender, EventArgs e)
        {
            loadSearchGridAndReSelect(0);
            resetTabInfo(PageMode.NONE);
        }
        protected void selectExpencess(object sender, EventArgs e)
        {
            try
            {
                GroupRadioButton rd = (GroupRadioButton)sender;
                resetTabInfo(PageMode.NONE);
                if (rd.Checked)
                {
                    string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnExpRowIdentifier"))).Attributes["row-identifier"];
                    setSelectedExpencess(long.Parse(strId));
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        protected void selectExpencessDetails(object sender, EventArgs e)
        {
            try
            {
                GroupRadioButton rd = (GroupRadioButton)sender;
                resetTabInfo(PageMode.NONE);
                if (rd.Checked)
                {
                    string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("rdExpencessDetailsSelect"))).Attributes["row-identifier"];
                    setSelectedExpencess(long.Parse(strId));
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        /*
         * This method is called on click of ADD button in datatable top bar.
         */

        protected void onClickExpencessDetailsViewBtn(object sender, EventArgs e)
        {
            try
            {
                resetTabInfo(PageMode.VIEW);
                fetchSelectedExpencess();
                populateUIFieldsFromDTO(null);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }


        protected void onClickDownLoadBtn(object sender, EventArgs e)
        {

        }
        protected void onClickViewPropertyExpencessBtn(object sender, EventArgs e)
        {
            try
            {
                resetTabInfo(PageMode.VIEW);
                if (validateExpencessSelected())
                {
                    fetchSelectedExpencess();
                }
                populateUIFieldsFromDTO(null);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        protected void onClickAddPropertyExpencessBtn(object sender, EventArgs e)
        {
            try
            {
                resetTabInfo(PageMode.ADD);
                fetchSelectedExpencess();
                populateUIFieldsFromDTO(null);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
      
        protected void onClickModifyPropertyExpencessBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateExpencessSelected())
                {
                    doViewModifyAction(PageMode.MODIFY);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void deletePropertyExpencess(object sender, EventArgs e)
        {
            try
            {
                if (validateExpencessSelected())
                {
                    long Id = ((List<PropertyExpenseDTO>)ViewState[VS_EXPENCES_LIST]).Find(c => c.isUISelected).Id;
                    propertyBO.deletePropertyExpenses(Id);
                    loadSearchGridAndReSelect(0);
                    resetTabInfo(PageMode.NONE);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_delete, "Property Expencess"), tab1Anchor.ID);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void addOrModifyExpencess(object sender, EventArgs e)
        {
            try
            {
                PropertyExpenseDTO propertyExpencessDto = getCurrentExpences();
                long Id = propertyExpencessDto.Id;
                populateExpencessDTOFromUI(propertyExpencessDto);
                if (PageMode.ADD.ToString().Equals(pageModeHdn.Value))
                {
                    Id = propertyBO.saveExpensesDetails(propertyExpencessDto);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_add, "Property Expencess"), tab2Anchor.ID);
                }
                else if (PageMode.MODIFY.ToString().Equals(pageModeHdn.Value))
                {
                   // employeeBO.updateEx(propertyExpencessDto);
                   // setSuccessMessage(string.Format(Resources.Messages.success_record_update, "Property Expencess"), tab2Anchor.ID);
                }
                loadSearchGridAndReSelect(Id);
                doViewModifyAction(PageMode.VIEW);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }

        protected void cancelPropertyExpencess(object sender, EventArgs e)
        {
            PropertyExpenseDTO propertyExpencessDto = getCurrentExpences();
            resetTabInfo(PageMode.NONE);
            loadSearchGridAndReSelect(propertyExpencessDto.Id);
        }
        protected void cancelPropertyExpencessDetails(object sender, EventArgs e)
        {
            PropertyExpenseDTO propertyExpencessDto = getCurrentExpences();
            resetTabInfo(PageMode.NONE);
            loadSearchGridAndReSelect(propertyExpencessDto.Id);
        }

        private PropertyExpenseDTO populateExpencessDTOAdd()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            PropertyExpenseDTO propertyExpencessDto = new PropertyExpenseDTO();
            propertyExpencessDto.DocumentInfo = new DocumentInfoDTO();
            propertyExpencessDto.DocumentInfo.Documents = new HashSet<DocumentDTO>();
            propertyExpencessDto.FirmNumber = userDefDto.FirmNumber;
            propertyExpencessDto.InsertUser = userDefDto.Username;
            return propertyExpencessDto;
        }
        private void populateExpencessDTOFromUI(PropertyExpenseDTO propertyExpencessDto)
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            propertyExpencessDto.Agency = CommonUIConverter.getMasterControlDTO(drpAgency.Text, null);
            propertyExpencessDto.Property = CommonUIConverter.getPropertyDTO(drpProperty.Text, null);
            propertyExpencessDto.ExpenseType = CommonUIConverter.getMasterControlDTO(drpExpencessType.Text, null);
            propertyExpencessDto.Amount =Convert.ToDecimal(txtAmount.Text);
            propertyExpencessDto.Comments = txtComments.Text;
            propertyExpencessDto.FirmMember = CommonUIConverter.getFirmMemberDTO(drpEmployeeName.Text, null);
            propertyExpencessDto.ExpenseDate = DateTime.ParseExact(txtDate.Text, Constants.DATE_FORMAT, CultureInfo.InvariantCulture);            
            propertyExpencessDto.UpdateUser = userDefDto.Username;
        }
        private void populateUIFieldsFromDTO(PropertyExpenseDTO propertyExpencessDto)
        {
            if (propertyExpencessDto != null && propertyExpencessDto.Property != null) drpProperty.Text = propertyExpencessDto.Property.Id.ToString(); else drpProperty.ClearSelection();
            if (propertyExpencessDto != null && propertyExpencessDto.Agency != null) drpAgency.Text = propertyExpencessDto.Agency.Id.ToString(); else drpProperty.ClearSelection();
            if (propertyExpencessDto != null && propertyExpencessDto.ExpenseType != null) drpExpencessType.Text = propertyExpencessDto.ExpenseType.Id.ToString(); else drpExpencessType.ClearSelection();
            if (propertyExpencessDto != null && propertyExpencessDto.FirmMember != null) drpEmployeeName.Text = propertyExpencessDto.FirmMember.Id.ToString(); else drpEmployeeName.ClearSelection();
            if (propertyExpencessDto != null && propertyExpencessDto.ExpenseDate != null) txtDate.Text = propertyExpencessDto.ExpenseDate.ToString(Constants.DATE_FORMAT); else txtDate.Text = null;
            if (propertyExpencessDto != null) txtAmount.Text =Convert.ToDecimal (propertyExpencessDto.Amount).ToString(); else txtAmount.Text = null;
            if (propertyExpencessDto != null) txtComments.Text = propertyExpencessDto.Comments; else txtComments.Text = null;
            
            populateDocumentGrid(propertyExpencessDto);
        }
        private void populateDocumentGrid(PropertyExpenseDTO propertyExpencessDto)
        {
            expencessmentDocuGrid.DataSource = new List<DocumentDTO>();
            if (propertyExpencessDto != null)
            {
                assignUiIndexToDocuments(propertyExpencessDto.DocumentInfo.Documents);
                expencessmentDocuGrid.DataSource = propertyExpencessDto.DocumentInfo.Documents;
            }
            expencessmentDocuGrid.DataBind();
        }
        private void assignUiIndexToDocuments(ISet<DocumentDTO> documentDtos)
        {
            if (documentDtos != null && documentDtos.Count > 0)
            {
                long uiIndex = 1;
                foreach (DocumentDTO documentDto in documentDtos)
                {
                    documentDto.UiIndex = uiIndex++;
                    documentDto.RowInfo = CommonUIConverter.getGridViewRowInfo(documentDto);
                }
            }
        }

        //Modal save logic
        protected void saveModalData(object sender, EventArgs e)
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                 
            if (modalHdnType.Value == "AGENCY")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.AGENCY, modalInput1.Text, modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto,"");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    errorMsg = validateMasterDataModalInput(masterDataDto, "AGENCY");
                    masterDataBO.saveMasterData(masterDataDto);                    
                    drpBO.drpDataBase(drpAgency, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.AGENCY, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            else if (modalHdnType.Value == "EXPENCESS_TYPE") 
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_EXPENSE_TYPE, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "EXPENCESS_TYPE");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpExpencessType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_EXPENSE_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            else if (modalHdnType.Value == "DOCUMENTTYPE")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.DOCUMENT_TYPE, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "DOCUMENTTYPE");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpDocumentType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.DOCUMENT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }

            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                modalErrorMsg.Value = errorMsg;
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "setModalErrorMsg", "setModalErrorMsg()", true);
            }
            else
            {
                //Reset the modal fields
                modalInput1.Text = "";
                modalInput2.Text = "";
                modalHdnType.Value = "";
                modalActionHdn.Value = "";
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "closeDialogClient", "closeDialogClient()", true);
            }
        }
        private string validateDepartmentModalInput(DepartmentDTO departmentDto)
        {
            string errorMsg = "";
            if (string.IsNullOrWhiteSpace(departmentDto.Name))
            {
                errorMsg = Resources.Messages.validation_departmentname_required;
            }
            else if (departmentBO.isAlreadyExist(departmentDto))
            {
                errorMsg = string.Format(Resources.Messages.validation_same_name_exist, "Department");
            }
            return errorMsg;
        }
        private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
        {
            string errorMsg = "";
            if (string.IsNullOrWhiteSpace(masterDataDto.Name))
            {
                errorMsg = Resources.Messages.validation_designationname_required;
            }
            else if (masterDataBO.isAlreadyExist(masterDataDto))
            {
                errorMsg = string.Format(Resources.Messages.validation_same_name_exist, type);
            }
            return errorMsg;
        }
        //Address Table actions - Start
        private void initDocumentAddUpdateSection(bool isAdd)
        {
            lbAddUpdateSectionHeader.Text = (isAdd) ? Resources.Labels.label_sectionheader_add_document : Resources.Labels.label_sectionheader_modify_document;
            pnlExpencessAdd.Visible = true;            
            btnExpencessAddToGrid.Visible = isAdd;
            btnExpencessUpdateToGrid.Visible = !isAdd;            
        }
      
        private void initDocumentInfoSectionFields(DocumentDTO docuDtomentInfo)
        {
            //if (addressDto != null) txtAddressLine1.Text = addressDto.AddressLine1; else txtAddressLine1.Text = null;
            //if (addressDto != null) txtAddressLine2.Text = addressDto.AddressLine2; else txtAddressLine2.Text = null;
            //if (addressDto != null) txtTown.Text = addressDto.Town; else txtTown.Text = null;
            //if (addressDto != null && addressDto.City != null) drpAddressCity.Text = addressDto.City.Id.ToString(); else drpAddressCity.ClearSelection();
            //if (addressDto != null && addressDto.State != null) drpAddressState.Text = addressDto.State.Id.ToString(); else drpAddressState.ClearSelection();
            //if (addressDto != null && addressDto.Country != null) drpAddressCountry.Text = addressDto.Country.Id.ToString(); else drpAddressCountry.ClearSelection();
            //if (addressDto != null) txtPin.Text = addressDto.Pin; else txtPin.Text = null;
            //if (addressDto != null && addressDto.AddressType != null) drpAddressType.Text = addressDto.AddressType.Id.ToString(); else drpAddressType.ClearSelection();
            //if (addressDto != null && addressDto.PreferredAddress != null) drpPreferredAddress.Text = addressDto.PreferredAddress.ToString(); else drpPreferredAddress.ClearSelection();
        }
        private void clearAddressViewState()
        {
            if (expencessmentDocuGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in expencessmentDocuGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdExpencessSelect");
                    if (radioBtn != null) radioBtn.Checked = false;
                }
            }
            getCurrentExpences().DocumentInfo.Documents.ToList<DocumentDTO>().ForEach(c => c.isUISelected = false);
        }
        private DocumentDTO getSelectedDocument()
        {
            return getCurrentExpences().DocumentInfo.Documents.ToList<DocumentDTO>().Find(c => c.isUISelected);
        }
        private void initCityDrp(DropDownList drp, string stateId)
        {
            drpBO.drpDataBase(drp, DrpDataType.CITY, stateId, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
        }
        private bool validateAddressSelected()
        {
            bool isSelected = true;
            DocumentDTO documentDto = getSelectedDocument();
            if (documentDto == null)
            {
                isSelected = false;
                pnlExpencessAdd.Visible = false;
                clearAddressViewState();
                setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Address"), tab2ValidationGrp);
            }
            return isSelected;
        }

        private void populateDocumentFromUI(DocumentDTO documentDto)
        {
            documentDto.DocumentType = CommonUIConverter.getMasterControlDTO(drpDocumentType.Text, drpDocumentType.SelectedItem.Text); 
            documentDto.Name = txtDocumentName.Text;
           // documentDto.DocumentInfo = txtSelectDocument.Text;
        }
       
        protected void selectDocument(object sender, EventArgs e)
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            pnlExpencessAdd.Visible = false;
            if (rd.Checked)
            {
                long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnExpencessRowIdentifier"))).Attributes["row-identifier"]);
                List<DocumentDTO> documentList = getCurrentExpences().DocumentInfo.Documents.ToList<DocumentDTO>();
                documentList.ForEach(c => c.isUISelected = false);
                documentList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
            }
        }
        protected void onClickExpencessBtn(object sender, EventArgs e)
        {
            try
            {
                initDocumentAddUpdateSection(true);
                initDocumentInfoSectionFields(null);               
                SetFocus(txtDocumentName);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void onClickModifyExpencessBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateAddressSelected())
                {
                    initDocumentAddUpdateSection(false);
                    initDocumentInfoSectionFields(getSelectedDocument());
                    SetFocus(txtDocumentName);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void deleteDocuments(object sender, EventArgs e)
        {
            try
            {
                if (validateAddressSelected())
                {
                    PropertyExpenseDTO propertyExpencessDto = getCurrentExpences();
                    DocumentDTO documentDto = getSelectedDocument();
                    propertyExpencessDto.DocumentInfo.Documents.Remove(documentDto);
                    pnlExpencessAdd.Visible = false;
                    clearAddressViewState();
                    populateDocumentGrid(propertyExpencessDto);                    
                    setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, "Documents"), tab2Anchor.ID);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void addNewExpencess(object sender, EventArgs e)
        {
            try
            {
                if (validateAddress())
                {
                    PropertyExpenseDTO propertyExpencessDto = getCurrentExpences();
                    DocumentDTO documentDto = new DocumentDTO();
                    populateDocumentFromUI(documentDto);
                    propertyExpencessDto.DocumentInfo.Documents.Add(documentDto);
                    pnlExpencessAdd.Visible = false;
                    clearAddressViewState();
                    populateDocumentGrid(propertyExpencessDto);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, "Documents"), tab2Anchor.ID);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void updateExpencess(object sender, EventArgs e)
        {
            try
            {
                if (validateAddress())
                {
                    PropertyExpenseDTO propertyExpencessDto = getCurrentExpences();
                    DocumentDTO documentDto = getSelectedDocument();
                    populateDocumentFromUI(documentDto);
                    pnlExpencessAdd.Visible = false;
                    clearAddressViewState();
                    populateDocumentGrid(propertyExpencessDto);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_updatedtotable, "Document"), tab2Anchor.ID);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void cancelExpencess(object sender, EventArgs e)
        {
            pnlExpencessAdd.Visible = false;
            clearAddressViewState();
        }
        private bool validateAddress()
        {
            bool isValid = true;
            //if (drpPreferredAddress.Text.Equals(PreferredAddress.Yes.ToString()))
            //{
                List<DocumentDTO> documentList = getCurrentExpences().DocumentInfo.Documents.ToList<DocumentDTO>();
            //}
            return isValid;
        }
        /* tab3 code starts*/
      
    }
}