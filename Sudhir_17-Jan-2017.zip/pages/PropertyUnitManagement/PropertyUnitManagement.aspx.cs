﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft.Logic.BO;
using NHibernate;
using Vladsm.Web.UI.WebControls;

namespace ConstroSoft.pages.PropertyUnitManagement
{
    public partial class PropertyUnitManagement : System.Web.UI.Page
    {
        private static readonly log4net.ILog log =
              log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string tab1ValidationGrp = "tab1Error";
        string tab2ValidationGrp = "tab2Error";
        string VS_PROPERTYUNIT_LIST = "PROPERTYUNIT_LIST";
        string VS_SELECTED_PROPERTYUNIT = "SELECTED_PROPERTYUNIT";
        DropdownBO drpBO = new DropdownBO();
        PropertyUnitManagementBO propertyUnitManagementBO = new PropertyUnitManagementBO();
        MasterDataBO masterDataBO = new MasterDataBO();
        protected void Page_Load(object sender, EventArgs e)
        {
            clearMessages();
            if (!IsPostBack)
            {
                if (Session[Constants.Session.USERNAME] != null)
                {
                    resetTabInfo(PageMode.NONE);
                    initDropdowns();

                    Page.MaintainScrollPositionOnPostBack = false;
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
        }
        private void initDropdowns()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            drpBO.drpDataBase(drpSearchProperty, DrpDataType.PROPERTY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpProperty, DrpDataType.PROPERTY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);

            drpBO.drpDataBase(drpUnitType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpDirection, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_DIRECTION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpfacing, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_FACING, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpEnum<PRUnitStatus>(drpStatus, Constants.SELECT_ITEM);
            drpBO.drpEnum<PropertyUnitSearchBy>(drpSearchBy, null);
        }
        /**
         * This method is called just before the page is rendered. So any change in state of the element is applied.
         **/
        protected void Page_PreRender(object sender, EventArgs e)
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        private bool isViewOnlyUser()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            bool isViewOnlyUser = !CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.FIRM_MEMBER_ADD_UPDATE);
            return isViewOnlyUser;
        }
        private void applyEntitlement()
        {
            if (isViewOnlyUser())
            {
                btnAddPropertyUnit.Visible = false;
                btnModifyPropertyUnit.Visible = false;
                btnDeletePropertyUnit.Visible = false;
            }
        }
        private void preRenderInitFormElements()
        {
            PropertyUnitDTO selectedPropertyUnit = getCurrentPropertyUnit();
            jumpToPropertyUnitHdnId.Value = null;
        }
        public void setErrorMessage(string message, string group)
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }

        public void setSuccessMessage(string msg, string tabId)
        {
            activeTabHdn.Value = tabId;
            if (tabId.Equals(tab1Anchor.ID))
            {
                lbTab1Success.Text = msg;
                tab1SuccessPanel.Visible = true;
            }
            else if (tabId.Equals(tab2Anchor.ID))
            {
                lbTab2Success.Text = msg;
                tab2SuccessPanel.Visible = true;
            }
        }
        public void initBootstrapComponantsFromServer()
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
        }
        private void clearMessages()
        {
            tab1SuccessPanel.Visible = false;
            lbTab1Success.Text = "";
            tab2SuccessPanel.Visible = false;
            lbTab2Success.Text = "";
        }
        private UserDefinitionDTO getUserDefinitionDTO()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }

        private void resetTabInfo(PageMode pageMode)
        {
            tab2Anchor.Visible = true;
            activeTabHdn.Value = tab2Anchor.ID;
            pageModeHdn.Value = pageMode.ToString();
            initFormFields();

            if (PageMode.ADD == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.empm_sm_manage_propertyUnit_tab2_add_name;
                initFormFields();
            }
            else if (PageMode.MODIFY == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.empm_sm_manage_propertyUnit_tab2_update_name;
                initFormFields();
            }
            else if (PageMode.VIEW == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.empm_sm_manage_propertyUnit_tab2_view_name;
                initFormFields();
            }
            else
            {
                activeTabHdn.Value = tab1Anchor.ID;
                tab2Anchor.Visible = false;
                ViewState[VS_SELECTED_PROPERTYUNIT] = null;
            }
        }
        private void initFormFields()
        {
            bool isReadOnly = (PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            bool visible = !(PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            //Buttons
            btnAddSubmit.Visible = visible;
            addUnitTypeBtn.Visible = visible;
            addDirectionBtn.Visible = visible;
            addFacingBtn.Visible = visible;
            lnkPropertyViewBtn.Visible = visible;
            lnkAddPropertyUnitBtn.Visible = visible;
            lnkModifyPropertyUnitBtn.Visible = visible;
            lnkDeletePropertyunitBtn.Visible = visible;
            proprtyunitGrid.Columns[0].Visible = visible;
        }
        private PropertyUnitDTO getCurrentPropertyUnit()
        {
            return (PropertyUnitDTO)ViewState[VS_SELECTED_PROPERTYUNIT];
        }
        private void setSelectedPropertyUnit(long selectedId)
        {
            List<PropertyUnitDTO> propertyUnitList = (List<PropertyUnitDTO>)ViewState[VS_PROPERTYUNIT_LIST];
            if (propertyUnitList != null && propertyUnitList.Count != 0)
            {
                propertyUnitList.ForEach(c => c.isUISelected = false);
                if (selectedId != -1) propertyUnitList.Find(c => c.Id == selectedId).isUISelected = true;
            }
        }
        private bool validateEmployeeSelected()
        {
            bool isSelected = true;
            List<PropertyUnitDTO> propertyUnitList = (List<PropertyUnitDTO>)ViewState[VS_PROPERTYUNIT_LIST];
            if (propertyUnitList != null)
            {
                isSelected = propertyUnitList.Any(c => c.isUISelected);
                if (!isSelected)
                {
                    resetTabInfo(PageMode.NONE);
                    setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Property Unit"), tab1ValidationGrp);
                }
            }
            return isSelected;
        }
        private void selectPropertyUnitGridRdBtn(long Id)
        {
            if (proprtyunitGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in proprtyunitGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdEnquirySelect");
                    Button rowIdenBtn = (Button)row.FindControl("btnPropUnitRowIdentifier");
                    if (radioBtn != null)
                    {
                        radioBtn.Checked = false;
                        if (rowIdenBtn != null && Id > 0 && Id.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                        {
                            radioBtn.Checked = true;
                        }
                    }
                }
            }
        }

        private void resetPropertyUnitSelection(long uiIndex)
        {
            if (proprtyunitGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in proprtyunitGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdPropertyUnitSelect");
                    radioBtn.Checked = false;
                    if (uiIndex > 0)
                    {
                        Button rowIdenBtn = (Button)row.FindControl("btnPropUnitRowIdentifier");
                        if (rowIdenBtn != null && uiIndex.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                        {
                            radioBtn.Checked = true;
                            setSelectedPropertyUnit(uiIndex);
                        }
                    }
                }
            }
            if (uiIndex <= 0)
                setSelectedPropertyUnit(-1);
        }

        private void reBindPropertyUnitGrid(List<PropertyUnitDTO> prunitList, PropertyUnitDTO propertyUnitDto)
        {
            if (prunitList != null)
            {
                assignUiIndexToPropertyUnit(prunitList);
                proprtyunitGrid.DataSource = prunitList;
                proprtyunitGrid.DataBind();
                if (propertyUnitDto != null) resetPropertyUnitSelection(propertyUnitDto.UiIndex);
            }
        }
        private void assignUiIndexToPropertyUnit(List<PropertyUnitDTO> prUnitDtos)
        {
            if (prUnitDtos != null && prUnitDtos.Count > 0)
            {
                prUnitDtos.ForEach(c => c.isUISelected = false);
                long uiIndex = 1;
                foreach (PropertyUnitDTO prUnitDto in prUnitDtos)
                {
                    prUnitDto.UiIndex = uiIndex++;
                    prUnitDto.RowInfo = CommonUIConverter.getGridViewRowInfo(prUnitDto);
                }
            }
        }



        private void loadSearchGridAndReSelect(long Id)
        {
            try
            {
                IList<PropertyUnitDTO> results = propertyUnitManagementBO.fetchPropertyUnits(getUserDefinitionDTO().FirmNumber, long.Parse(drpSearchTower.Text));
                ViewState[VS_PROPERTYUNIT_LIST] = results;
                proprtyunitGrid.DataSource = results;
                proprtyunitGrid.DataBind();
                if (Id > 0)
                {
                    selectPropertyUnitGridRdBtn(Id);
                    setSelectedPropertyUnit(Id);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void fetchSelectedPropertyUnitList()
        {
            try
            {
                PropertyUnitDTO propertyUnitDto = null;
                PropertyUnitManagementBO propertyUnitManagementBO = new PropertyUnitManagementBO();
                if (PageMode.ADD.ToString().Equals(pageModeHdn.Value))
                {
                    propertyUnitDto = populatePropertyUnitDTOAdd();
                    selectPropertyUnitGridRdBtn(0);
                }
                else if (PageMode.MODIFY.ToString().Equals(pageModeHdn.Value) || PageMode.VIEW.ToString().Equals(pageModeHdn.Value))
                {
                    long Id = ((List<PropertyUnitDTO>)ViewState[VS_PROPERTYUNIT_LIST]).Find(c => c.isUISelected).Id;
                    propertyUnitDto = propertyUnitManagementBO.fetchPropertyUnitDetails(Id);
                    //Set Hidden Unit Number.
                }
                ViewState[VS_SELECTED_PROPERTYUNIT] = propertyUnitDto;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void doViewModifyAction(PageMode pageMode)
        {
            resetTabInfo(pageMode);
            fetchSelectedPropertyUnitList();
            populateUIFieldsFromDTO((PropertyUnitDTO)ViewState[VS_SELECTED_PROPERTYUNIT]);
        }
        protected void onSearchBy(object sender, EventArgs e)
        {
            try
            {
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                PropertyUnitSearchBy searchBy = EnumHelper.ToEnum<PropertyUnitSearchBy>(drpSearchBy.Text);
                drpSearchByValue.Visible = true;
                lbSearchByValue.Visible = true;
                lbSearchByValue.Text = EnumHelper.GetEnumDescription<EmployeeSearchBy>(searchBy.ToString());
                if (PropertyUnitSearchBy.UNIT == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.PROPERTY_UNIT, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (PropertyUnitSearchBy.UNIT_TYPE == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.PROPERTY_UNIT_TYPE, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (PropertyUnitSearchBy.FLAT_NO == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.FLAT_NO, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (PropertyUnitSearchBy.PROPERTYUNITSTATUS == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.PROPERTYUNITSTATUS, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (PropertyUnitSearchBy.WING == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.WING, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }

                else
                {
                    drpSearchByValue.ClearSelection();
                    drpSearchByValue.Visible = false;
                    lbSearchByValue.Visible = false;
                }
                loadSearchGridAndReSelect(0);
                resetTabInfo(PageMode.NONE);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onSearchByValue(object sender, EventArgs e)
        {
            loadSearchGridAndReSelect(0);
            resetTabInfo(PageMode.NONE);
        }
        protected void selectPropertyUnit(object sender, EventArgs e)
        {
            try
            {
                GroupRadioButton rd = (GroupRadioButton)sender;
                resetTabInfo(PageMode.NONE);
                if (rd.Checked)
                {
                    string strId = "-1";
                    if (proprtyunitGrid.Rows.Count > 0)
                    {
                        strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnPropUnitRowIdentifier"))).Attributes["row-identifier"];
                    }
                    setSelectedPropertyUnit(long.Parse(strId));
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        /*
         * This method is called on click of ADD button in datatable top bar.
         */
        protected void onClickAddPropertyUnitBtn(object sender, EventArgs e)
        {
            try
            {
                resetPropertyUnitSelection(-1);
                resetTabInfo(PageMode.ADD);
                fetchSelectedPropertyUnitList();
                populateUIFieldsFromDTO(null);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickViewPropertyUnitBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateEmployeeSelected())
                {
                    doViewModifyAction(PageMode.VIEW);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickModifyPropertyUnitBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateEmployeeSelected())
                {
                    doViewModifyAction(PageMode.MODIFY);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void deletePropertyUnit(object sender, EventArgs e)
        {
            try
            {
                if (validateEmployeeSelected())
                {
                    long Id = ((List<PropertyUnitDTO>)ViewState[VS_PROPERTYUNIT_LIST]).Find(c => c.isUISelected).Id;
                    propertyUnitManagementBO.deletePropertyUnitDetails(Id);
                    loadSearchGridAndReSelect(0);
                    resetTabInfo(PageMode.NONE);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_delete, "Property Unit"), tab1Anchor.ID);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void addOrModifyPropertyUnit(object sender, EventArgs e)
        {
            try
            {
                if (validateInput())
                {
                    PropertyUnitDTO propertyUnitDTO = getCurrentPropertyUnit();
                    long Id = propertyUnitDTO.Id;
                    populatePropertyUnitDTOFromUI(propertyUnitDTO);
                    string errorMsg = "";
                    if (PageMode.ADD.ToString().Equals(pageModeHdn.Value))
                    {
                        errorMsg = validateUnitNoInput(propertyUnitDTO);
                        if (string.IsNullOrWhiteSpace(errorMsg))
                        {
                            Id = propertyUnitManagementBO.savePropertyUnitDetails(propertyUnitDTO);
                            setSuccessMessage(string.Format(Resources.Messages.success_record_add, "Property Unit"), tab2Anchor.ID);
                        }
                        else if (!string.IsNullOrWhiteSpace(errorMsg))
                        {
                            setErrorMessage(errorMsg, tab2ValidationGrp);
                        }
                        else
                        {

                            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
                        }
                    }
                    else if (PageMode.MODIFY.ToString().Equals(pageModeHdn.Value))
                    {
                        //If hidden unit number != propertyUnitDTO.UnitNo then validateUnitNoInput.
                        propertyUnitManagementBO.updatePropertyUnitDetails(propertyUnitDTO);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_update, "Property Unit"), tab2Anchor.ID);
                    }
                    if (string.IsNullOrWhiteSpace(errorMsg))
                    {
                        loadSearchGridAndReSelect(Id);
                        doViewModifyAction(PageMode.VIEW);
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        public bool validateInput()
        {
            bool isValid = true;
            Page.Validate("tab2Error");
            isValid = Page.IsValid;
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        protected void cancelPropertyUnit(object sender, EventArgs e)
        {
            resetPropertyUnitSelection(-1);
            PropertyUnitDTO firmMemberDto = getCurrentPropertyUnit();
            resetTabInfo(PageMode.NONE);
            loadSearchGridAndReSelect(firmMemberDto.Id);
        }

        private PropertyUnitDTO populatePropertyUnitDTOAdd()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            PropertyUnitDTO propertyUnitDto = new PropertyUnitDTO();
            propertyUnitDto.PropertyTower = new PropertyTowerDTO();
            propertyUnitDto.FirmNumber = userDefDto.FirmNumber;
            propertyUnitDto.InsertUser = userDefDto.Username;
            return propertyUnitDto;
        }
        private void populatePropertyUnitDTOFromUI(PropertyUnitDTO propertyUnitDTO)
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            propertyUnitDTO.PropertyTower = CommonUIConverter.getPropertyTowerDTO(drpTower.Text, null);
            propertyUnitDTO.UnitType = CommonUIConverter.getMasterControlDTO(drpUnitType.Text, null);
            propertyUnitDTO.Wing = txtWing.Text;
            propertyUnitDTO.FloorNo = txtFloorNo.Text;
            propertyUnitDTO.UnitNo = txtunitNo.Text;
            if (!string.IsNullOrWhiteSpace(txtBuiltupArea.Text))
            {
                propertyUnitDTO.BuildupArea = CommonUtil.getDecimalWithoutExt(txtBuiltupArea.Text);
            }
            else
            {
                propertyUnitDTO.BuildupArea = 0;
            }
            if (!string.IsNullOrWhiteSpace(txtCarpetArea.Text))
            {
                propertyUnitDTO.CarpetArea = CommonUtil.getDecimalWithoutExt(txtCarpetArea.Text);
            }
            else
            {
                propertyUnitDTO.CarpetArea = 0;
            }
            if (!string.IsNullOrWhiteSpace(txtBalconyArea.Text))
            {
                propertyUnitDTO.BalconyArea = CommonUtil.getDecimalWithoutExt(txtBalconyArea.Text);
            }
            else
            {
                propertyUnitDTO.BalconyArea = 0;
            }
            propertyUnitDTO.Facing = CommonUIConverter.getMasterControlDTO(drpfacing.Text, null);
            propertyUnitDTO.Status = EnumHelper.ToEnum<PRUnitStatus>(drpStatus.Text);
            propertyUnitDTO.Direction = CommonUIConverter.getMasterControlDTO(drpDirection.Text, null);
            propertyUnitDTO.ReserveComments = txtReserveComments.Text;
            propertyUnitDTO.NoOfBalcony = Convert.ToInt32(txtNoOfBalcony.Text);
            propertyUnitDTO.FirmNumber = userDefDto.FirmNumber;
            propertyUnitDTO.Version = userDefDto.Version;
            propertyUnitDTO.UpdateUser = userDefDto.Username;
        }
        private void populateUIFieldsFromDTO(PropertyUnitDTO propertyUnitDto)
        {

            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            drpProperty.Text = drpSearchProperty.Text;
            drpBO.drpDataBase(drpTower, DrpDataType.PROPERTY_TOWER, drpSearchProperty.Text, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            if (propertyUnitDto != null && propertyUnitDto.PropertyTower != null) drpTower.Text = propertyUnitDto.PropertyTower.Id.ToString(); else drpTower.ClearSelection();
            if (propertyUnitDto != null) drpUnitType.Text = propertyUnitDto.UnitType.Id.ToString(); else drpUnitType.Text = null;
            if (propertyUnitDto != null) txtWing.Text = propertyUnitDto.Wing; else txtWing.Text = null;
            if (propertyUnitDto != null) txtReserveComments.Text = propertyUnitDto.ReserveComments; else txtReserveComments.Text = null;
            if (propertyUnitDto != null) txtNoOfBalcony.Text = Convert.ToDecimal(propertyUnitDto.NoOfBalcony).ToString(); else txtNoOfBalcony.Text = null;
            if (propertyUnitDto != null) txtFloorNo.Text = Convert.ToDecimal(propertyUnitDto.FloorNo).ToString(); else txtFloorNo.Text = null;
            if (propertyUnitDto != null && propertyUnitDto.UnitNo != null) txtunitNo.Text = propertyUnitDto.UnitNo; else txtunitNo.Text = null;
            if (propertyUnitDto != null && propertyUnitDto.BuildupArea != null) txtBuiltupArea.Text = propertyUnitDto.BuildupArea.ToString(); else txtBuiltupArea.Text = null;
            if (propertyUnitDto != null && propertyUnitDto.CarpetArea != null) txtCarpetArea.Text = propertyUnitDto.CarpetArea.ToString(); else txtCarpetArea.Text = null;
            if (propertyUnitDto != null && propertyUnitDto.BalconyArea != null) txtBalconyArea.Text = propertyUnitDto.BalconyArea.ToString(); else txtBalconyArea.Text = null;
            if (propertyUnitDto != null && propertyUnitDto.Facing != null) drpfacing.Text = propertyUnitDto.Facing.Id.ToString(); else drpfacing.Text = null;
            if (propertyUnitDto != null) drpStatus.Text = propertyUnitDto.Status.ToString(); else drpStatus.Text = null;
            if (propertyUnitDto != null && propertyUnitDto.Direction != null) drpDirection.Text = propertyUnitDto.Direction.Id.ToString(); else drpDirection.ClearSelection();

        }
        //Modal save logic
        protected void saveModalData(object sender, EventArgs e)
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (modalHdnType.Value == "UNIT_TYPE")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_UNIT_TYPE, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Unit_Type");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpUnitType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            else if (modalHdnType.Value == "DIRECTION")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_UNIT_DIRECTION, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "DIRECTION");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpDirection, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_DIRECTION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            else if (modalHdnType.Value == "FACING")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_UNIT_FACING, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "FACING");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpfacing, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_FACING, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                modalErrorMsg.Value = errorMsg;
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "setModalErrorMsg", "setModalErrorMsg()", true);
            }
            else
            {
                //Reset the modal fields
                modalInput1.Text = "";
                modalInput2.Text = "";
                modalHdnType.Value = "";
                modalActionHdn.Value = "";
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "closeDialogClient", "closeDialogClient()", true);
            }
        }

        private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
        {
            string errorMsg = "";
            if (string.IsNullOrWhiteSpace(masterDataDto.Name))
            {
                errorMsg = Resources.Messages.validation_designationname_required;
            }
            else if (masterDataBO.isAlreadyExist(masterDataDto))
            {
                errorMsg = string.Format(Resources.Messages.validation_same_name_exist, type);
            }
            return errorMsg;
        }


        private string validateUnitNoInput(PropertyUnitDTO propertyunitDto)
        {
            string errorMsg = "";
            if (string.IsNullOrWhiteSpace(propertyunitDto.UnitNo))
            {
                errorMsg = Resources.Messages.validation_unitno_required;
            }
            else if (propertyUnitManagementBO.isAlreadyExist(propertyunitDto))
            {
                errorMsg = string.Format(Resources.Messages.validation_same_name_exist, propertyunitDto.UnitNo);
            }
            return errorMsg;
        }

        protected void onSearchByProperty(object sender, EventArgs e)
        {
            try
            {
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                PropertyUnitSearchBy searchBy = EnumHelper.ToEnum<PropertyUnitSearchBy>(drpSearchBy.Text);
                drpSearchTower.Visible = true;
                label_towersearchBy.Visible = true;
                drpSearchByValue.Visible = true;
                lbSearchByValue.Visible = true;
                lbSearchByValue.Text = EnumHelper.GetEnumDescription<PropertyUnitSearchBy>(searchBy.ToString());
                drpBO.drpDataBase(drpSearchTower, DrpDataType.PROPERTY_TOWER, drpSearchProperty.Text, Constants.SELECT_ITEM, userDefDto.FirmNumber);

                if (drpSearchTower.Items.Count == 2)
                {
                    drpSearchTower.Items[1].Selected = true;
                    loadSearchGridAndReSelect(0);
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }

        }

        protected void onSearchByTower(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(drpSearchTower.Text))
            {
                loadSearchGridAndReSelect(0);
            }
        }

        protected void drpProperty_SelectedIndexChanged(object sender, EventArgs e)
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            drpBO.drpDataBase(drpTower, DrpDataType.PROPERTY_TOWER, drpProperty.Text, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        }
    }
}