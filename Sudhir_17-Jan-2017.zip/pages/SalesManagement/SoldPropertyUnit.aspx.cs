﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft.Logic.BO;
using Vladsm.Web.UI.WebControls;

namespace ConstroSoft.pages.SalesManagement
{
    public partial class SoldPropertyUnit : System.Web.UI.Page
    {
        private static readonly log4net.ILog log =
              log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        enum SoldUnitPageMode { MODIFY, MODIFY_LIMITTED, VIEW, CANCEL_BOOKING, NONE }
        string tab1ValidationGrp = "tab1Error";
        string tab3Error = "tab3Error";
        string tab2BzStep1Error = "tab2BzStep1Error";
        string tab2BzStep1ErrorGrid1 = "tab2BzStep2ErrorGrid1";
        string tab2BzStep1ErrorGrid2 = "tab2BzStep2ErrorGrid2";
        string tab2BzStep2Error = "tab2BzStep2Error";
        string tab2BzStep2Error1 = "tab2BzStep2Error1";
        string tab2BzStep3Error = "tab2BzStep3Error";
        string tab2BzStep3Error1 = "tab2BzStep3Error1";
        string tab2BzStep1 = "bzstep1";
        string tab2BzStep2 = "bzstep2";
        string tab2BzStep3 = "bzstep3";
        string VS_PROPERTY_UNIT_LIST = "PROPERTY_UNIT_LIST";
        string VS_MASTER_PROPERTY_UNIT_LIST = "ALL_PROPERTY_UNIT_LIST";
        string VS_SELECTED_UNIT = "SELECTED_PROPERTY_UNIT";
        DropdownBO drpBO = new DropdownBO();
        PropertyBO propertyBO = new PropertyBO();
        SoldPropertyUnitBO soldUnitBO = new SoldPropertyUnitBO();
        MasterDataBO masterDataBO = new MasterDataBO();
        DepartmentBO departmentBO = new DepartmentBO();
        protected void Page_Load(object sender, EventArgs e)
        {
            clearMessages();
            if (!IsPostBack)
            {
                if (Session[Constants.Session.USERNAME] != null)
                {
                    resetTabInfo(SoldUnitPageMode.NONE);
                    initDropdowns();
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
        }
        private void initDropdowns()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            drpBO.drpDataBase(drpSelectProperty, DrpDataType.PROPERTY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpEnum<SoldUnitSearchBy>(drpSearchBy, null);
            drpBO.drpDataBase(drpAllPaymentType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_PYMT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpEnum<PRUnitSalePymtTo>(drpPaymentTo, null);
            drpBO.drpDataBase(drpCancellationEmployee, DrpDataType.EMPLOYEE_SEARCH_BY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        }
        /**
         * This method is called just before the page is rendered. So any change in state of the element is applied.
         **/
        protected void Page_PreRender(object sender, EventArgs e)
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        private bool isViewOnlyUser()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            bool isViewOnlyUser = !CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.FIRM_MEMBER_ADD_UPDATE);
            return isViewOnlyUser;
        }
        private void applyEntitlement()
        {
            if (isViewOnlyUser())
            {
                btnModifySoldUnits.Visible = false;
                btnLiModifySoldUnits.Visible = false;
                btnCancelBooking.Visible = false;
                btnLiCancelBooking.Visible = false;
            }
        }
        private void preRenderInitFormElements()
        {
            PrUnitSaleDetailDTO selectedPrUnitSaleDetailDto = getSelectedPropertyUnit();
            PrUnitSaleDetailDTO prUnitSaleDetailDto = getCurrentSoldUnit();
            jumpToSoldUnitsHdnId.Value = "";
            jumpToTaxDetailHdnId.Value = "";
            jumpToCMTaxDetailHdnId.Value = "";
            if (selectedPrUnitSaleDetailDto != null)
            {
                jumpToSoldUnitsHdnId.Value = selectedPrUnitSaleDetailDto.Id.ToString();
                if (prUnitSaleDetailDto != null && prUnitSaleDetailDto.uiTaxDetails != null && prUnitSaleDetailDto.uiTaxDetails.Count > 0)
                {
                    PrUnitSaleTaxDetailDTO prUnitSaleTaxDetailDto = prUnitSaleDetailDto.uiTaxDetails.Find(a => a.isUISelected);
                    if (prUnitSaleTaxDetailDto != null) jumpToTaxDetailHdnId.Value = prUnitSaleTaxDetailDto.UiIndex.ToString();
                }
                if (prUnitSaleDetailDto != null && prUnitSaleDetailDto.uiCMTaxDetails != null && prUnitSaleDetailDto.uiCMTaxDetails.Count > 0)
                {
                    PrUnitSaleTaxDetailDTO prUnitSaleTaxDetailDto = prUnitSaleDetailDto.uiCMTaxDetails.Find(a => a.isUISelected);
                    if (prUnitSaleTaxDetailDto != null) jumpToCMTaxDetailHdnId.Value = prUnitSaleTaxDetailDto.UiIndex.ToString();
                }
                if (prUnitSaleDetailDto != null && prUnitSaleDetailDto.PrUnitSalePymts != null && prUnitSaleDetailDto.PrUnitSalePymts.Count > 0)
                {
                    PrUnitSalePymtDTO prUnitSalePymtDto = prUnitSaleDetailDto.PrUnitSalePymts.ToList<PrUnitSalePymtDTO>().Find(a => a.isUISelected);
                    if (prUnitSalePymtDto != null) jumpToPaymentHdnId.Value = prUnitSalePymtDto.UiIndex.ToString();
                }
            }
            PrUnitSaleDetailDTO currentSoldUnitDto = getCurrentSoldUnit();
            if (SoldUnitPageMode.MODIFY.ToString().Equals(pageModeHdn.Value)) populateUnitInfoSection(currentSoldUnitDto);
            else if (SoldUnitPageMode.MODIFY_LIMITTED.ToString().Equals(pageModeHdn.Value) || SoldUnitPageMode.VIEW.ToString().Equals(pageModeHdn.Value)) 
                populateUIFieldsFromSaleUnitDTO(currentSoldUnitDto);
            
            if (currentSoldUnitDto != null)
            {
                PrUnitSalePymtDTO selectedPymtDto = getSelectedPrUnitSalePayment();
                if (selectedPymtDto != null && !addPymtTypeBtn.Visible)
                {
                    initPaymentSectionFields(getSelectedPrUnitSalePayment());
                }
            }
        }
        public void setErrorMessage(string message, string group)
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            if (group.Equals(tab2BzStep1Error)) tab2ContentBzHdn.Value = tab2BzStep1;
            else if (group.Equals(tab2BzStep2Error) || group.Equals(tab2BzStep2Error1)) tab2ContentBzHdn.Value = tab2BzStep2;
            else if (group.Equals(tab2BzStep3Error)) tab2ContentBzHdn.Value = tab2BzStep3;
        }

        public void setSuccessMessage(string msg, string tabId, string bzStep)
        {
            activeTabHdn.Value = tabId;
            if (tabId.Equals(tab1Anchor.ID))
            {
                lbTab1Success.Text = msg;
                tab1SuccessPanel.Visible = true;
            }
            else if (tabId.Equals(tab2Anchor.ID))
            {
                if (tab2BzStep1.Equals(bzStep))
                {
                    lbTab2BzStep1Success.Text = msg;
                    tab2BzStep1SuccessPanel.Visible = true;
                }
                else if (tab2BzStep2.Equals(bzStep))
                {
                    lbTab2BzStep2Success.Text = msg;
                    tab2BzStep2SuccessPanel.Visible = true;
                }
                else
                {
                    lbTab2BzStep3Success.Text = msg;
                    tab2BzStep3SuccessPanel.Visible = true;
                }
                tab2ContentBzHdn.Value = bzStep;
            }
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        public void initBootstrapComponantsFromServer()
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
        }
        private void clearMessages()
        {
            tab1SuccessPanel.Visible = false;
            lbTab1Success.Text = "";
            tab2BzStep1SuccessPanel.Visible = false;
            lbTab2BzStep1Success.Text = "";
            tab2BzStep2SuccessPanel.Visible = false;
            lbTab2BzStep2Success.Text = "";
            tab2BzStep3SuccessPanel.Visible = false;
            lbTab2BzStep3Success.Text = "";
        }
        private UserDefinitionDTO getUserDefinitionDTO()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }

        private void resetTabInfo(SoldUnitPageMode pageMode)
        {
            pageModeHdn.Value = pageMode.ToString();
            initFormFields();
            pnlTaxDetailAdd.Visible = false;
            pnlCMTaxDetailAdd.Visible = false;
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            tab2ContentBzHdn.Value = "";
            tab2Anchor.Visible = false;
            tab3Anchor.Visible = false;
            if (SoldUnitPageMode.MODIFY == pageMode || SoldUnitPageMode.MODIFY_LIMITTED == pageMode || SoldUnitPageMode.VIEW == pageMode)
            {
                tab2ContentBzHdn.Value = tab2BzStep1;
                activeTabHdn.Value = tab2Anchor.ID;
                tab2Anchor.Visible = true;
                initFormFields();
            }
            else if (SoldUnitPageMode.CANCEL_BOOKING == pageMode)
            {
                activeTabHdn.Value = tab3Anchor.ID;
                tab3Anchor.Visible = true;
                
            } else {
                activeTabHdn.Value = tab1Anchor.ID;
                ViewState[VS_SELECTED_UNIT] = null;
            }
        }
        private void initFormFields()
        {
            bool visible = !(SoldUnitPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            bool visibleInModify = !(SoldUnitPageMode.VIEW.ToString().Equals(pageModeHdn.Value) || SoldUnitPageMode.MODIFY_LIMITTED.ToString().Equals(pageModeHdn.Value));
            //Buttons
            btnSubmitStep1.Visible = visible;
            btnSubmitStep2.Visible = visible;
            btnSubmitStep3.Visible = visible;
            btnAddTaxDetail.Visible = visibleInModify;
            btnDeleteTaxDetail.Visible = visibleInModify;
            btnAddCMTaxDetail.Visible = visibleInModify;
            btnDeleteCMTaxDetail.Visible = visibleInModify;
            btnAddPayments.Visible = visible;
            btnModifyPayment.Visible = visible;
            btnDeletePayment.Visible = visible;
            taxDetailGrid.Columns[0].Visible = visibleInModify;
            cmTaxDetailGrid.Columns[0].Visible = visibleInModify;
            paymentGrid.Columns[0].Visible = visible;
        }
        private List<PrUnitSaleDetailDTO> getMatserSoldUnits()
        {
            return (List<PrUnitSaleDetailDTO>)ViewState[VS_MASTER_PROPERTY_UNIT_LIST];
        }
        private List<PrUnitSaleDetailDTO> getCurrentGridSoldUnits()
        {
            return (List<PrUnitSaleDetailDTO>)ViewState[VS_PROPERTY_UNIT_LIST];
        }
        private PrUnitSaleDetailDTO getCurrentSoldUnit()
        {
            return (PrUnitSaleDetailDTO)ViewState[VS_SELECTED_UNIT];
        }
        private void setSelectedPropertyUnit(long selectedId)
        {
            List<PrUnitSaleDetailDTO> propertyUnitSaleList = getCurrentGridSoldUnits();
            if (propertyUnitSaleList != null)
            {
                propertyUnitSaleList.ForEach(c => c.isUISelected = false);
                if (selectedId > 0) propertyUnitSaleList.Find(c => c.Id == selectedId).isUISelected = true;
            }
        }
        private PrUnitSaleDetailDTO getSelectedPropertyUnit()
        {
            List<PrUnitSaleDetailDTO> propertyUnitSaleList = getCurrentGridSoldUnits();
            PrUnitSaleDetailDTO selectedSaleUnitDto = null;
            if (propertyUnitSaleList != null)
            {
                selectedSaleUnitDto = propertyUnitSaleList.Find(c => c.isUISelected);
            }
            return selectedSaleUnitDto;
        }
        private bool validatePropertyUnitSelected()
        {
            bool isSelected = true;
            List<PrUnitSaleDetailDTO> propertyUnitSaleList = getCurrentGridSoldUnits();
            if (propertyUnitSaleList != null)
            {
                isSelected = propertyUnitSaleList.Any(c => c.isUISelected);
                if (!isSelected)
                {
                    resetTabInfo(SoldUnitPageMode.NONE);
                    setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Property Unit"), tab1ValidationGrp);
                }
            }
            return isSelected;
        }
        private void selectPropertyUnitGridRdBtn(long Id)
        {
            if (soldUnitsGrid.Rows.Count > 0)
            {
                setSelectedPropertyUnit(0);
                foreach (GridViewRow row in soldUnitsGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdSoldUnitsSelect");
                    Button rowIdenBtn = (Button)row.FindControl("btnSoldUnitRowIdentifier");
                    if (radioBtn != null)
                    {
                        radioBtn.Checked = false;
                        if (rowIdenBtn != null && Id > 0 && Id.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                        {
                            radioBtn.Checked = true;
                            setSelectedPropertyUnit(Id);
                        }
                    }
                }
            }
        }
        private void loadSearchGridAndReSelect(long Id)
        {
            try
            {
                List<PrUnitSaleDetailDTO> matserList = (List<PrUnitSaleDetailDTO>)getMatserSoldUnits();
                List<PrUnitSaleDetailDTO> filterResults = new List<PrUnitSaleDetailDTO>(matserList);
                SoldUnitSearchBy searchBy = EnumHelper.ToEnum<SoldUnitSearchBy>(drpSearchBy.Text);
                if (!string.IsNullOrWhiteSpace(drpSearchByValue.Text))
                {
                    if (SoldUnitSearchBy.PROPERTY_UNIT == searchBy)
                    {
                        filterResults = matserList.FindAll(u => u.PropertyUnit.Id == long.Parse(drpSearchByValue.Text));
                    }
                    else if (SoldUnitSearchBy.UNIT_TYPE == searchBy)
                    {
                        filterResults = matserList.FindAll(u => u.PropertyUnit.UnitType.Id == long.Parse(drpSearchByValue.Text));
                    }
                    else if (SoldUnitSearchBy.CUSTOMER == searchBy)
                    {
                        filterResults = matserList.FindAll(u => u.Customer.Id == long.Parse(drpSearchByValue.Text));
                    }
                    else if (SoldUnitSearchBy.EMPLOYEE == searchBy)
                    {
                        filterResults = matserList.FindAll(u => u.FirmMember.Id == long.Parse(drpSearchByValue.Text));
                    }
                }
                ViewState[VS_PROPERTY_UNIT_LIST] = filterResults;
                soldUnitsGrid.DataSource = filterResults;
                soldUnitsGrid.DataBind();
                selectPropertyUnitGridRdBtn(Id);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                throw exp;
            }
        }
        private void fetchSoldUnits(long Id)
        {
            try
            {
                IList<PrUnitSaleDetailDTO> results = new List<PrUnitSaleDetailDTO>();
                if (!(string.IsNullOrWhiteSpace(drpSelectProperty.Text) || string.IsNullOrWhiteSpace(drpSelectPropertyTower.Text)))
                {
                    long propertyId = long.Parse(drpSelectProperty.Text);
                    long towerId = long.Parse(drpSelectPropertyTower.Text);
                    results = soldUnitBO.fetchSoldPropertyUnits(getUserDefinitionDTO().FirmNumber, towerId);
                }
                ViewState[VS_MASTER_PROPERTY_UNIT_LIST] = results;
                ViewState[VS_PROPERTY_UNIT_LIST] = results;
                soldUnitsGrid.DataSource = results;
                soldUnitsGrid.DataBind();
                loadSearchGridAndReSelect(Id);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                throw exp;
            }
        }
        private void fetchSelectedPropertyUnit()
        {
            try
            {
                PrUnitSaleDetailDTO selectedPrUnitSaleDetailDto = getCurrentGridSoldUnits().Find(c => c.isUISelected);
                PrUnitSaleDetailDTO prUnitSaleDetailDto = soldUnitBO.fetchPrUnitSaleDetail(getUserDefinitionDTO().FirmNumber, selectedPrUnitSaleDetailDto.Id,
                        selectedPrUnitSaleDetailDto.PropertyUnit.PropertyTower.Property.Id);
                selectedPrUnitSaleDetailDto.PropertyUnit.PropertyTower.Property.PropertyTaxDetails = prUnitSaleDetailDto.PropertyUnit.PropertyTower.Property.PropertyTaxDetails;
                prUnitSaleDetailDto.PropertyUnit = selectedPrUnitSaleDetailDto.PropertyUnit;
                prUnitSaleDetailDto.uiTaxDetails = new List<PrUnitSaleTaxDetailDTO>();
                prUnitSaleDetailDto.uiCMTaxDetails = new List<PrUnitSaleTaxDetailDTO>();
                foreach (PrUnitSaleTaxDetailDTO taxDtl in prUnitSaleDetailDto.PrUnitSaleTaxDetails)
                {
                    if (IncludeInPymtTotal.Yes == taxDtl.IncludeInTotalPymt) prUnitSaleDetailDto.uiTaxDetails.Add(taxDtl); 
                    else prUnitSaleDetailDto.uiCMTaxDetails.Add(taxDtl);
                }
                ViewState[VS_SELECTED_UNIT] = prUnitSaleDetailDto;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                throw exp;
            }
        }
        protected void onSelectProperty(object sender, EventArgs e)
        {
            try
            {
                resetTabInfo(SoldUnitPageMode.NONE);
                drpBO.drpDataBase(drpSelectPropertyTower, DrpDataType.PROPERTY_TOWER, drpSelectProperty.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
                pnlSoldUnitGrid.Visible = (drpSelectPropertyTower.Items.Count > 1);
                if (drpSelectPropertyTower.Items.Count == 2)
                {
                    drpSelectPropertyTower.Items[1].Selected = true;
                }
                fetchSoldUnits(0);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onSelectPropertyTower(object sender, EventArgs e)
        {
            try
            {
                resetTabInfo(SoldUnitPageMode.NONE);
                pnlSoldUnitGrid.Visible = !string.IsNullOrWhiteSpace(drpSelectPropertyTower.Text);
                fetchSoldUnits(0);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onSearchBy(object sender, EventArgs e)
        {
            try
            {
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                SoldUnitSearchBy searchBy = EnumHelper.ToEnum<SoldUnitSearchBy>(drpSearchBy.Text);
                drpSearchByValue.Visible = true;
                lbSearchByValue.Visible = true;
                lbSearchByValue.Text = EnumHelper.GetEnumDescription<SoldUnitSearchBy>(searchBy.ToString());
                if (SoldUnitSearchBy.PROPERTY_UNIT == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.AVAIL_UNIT_SEARCH_BY_PR_UNIT, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (SoldUnitSearchBy.UNIT_TYPE == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (SoldUnitSearchBy.CUSTOMER == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.CUSTOMER_SEARCH_BY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (SoldUnitSearchBy.EMPLOYEE == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.EMPLOYEE_SEARCH_BY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else
                {
                    drpSearchByValue.ClearSelection();
                    drpSearchByValue.Visible = false;
                    lbSearchByValue.Visible = false;
                }
                loadSearchGridAndReSelect(0);
                resetTabInfo(SoldUnitPageMode.NONE);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onSearchByValue(object sender, EventArgs e)
        {
            try {
                loadSearchGridAndReSelect(0);
                resetTabInfo(SoldUnitPageMode.NONE);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onSelectSoldUnit(object sender, EventArgs e)
        {
            try
            {
                GroupRadioButton rd = (GroupRadioButton)sender;
                resetTabInfo(SoldUnitPageMode.NONE);
                if (rd.Checked)
                {
                    string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnSoldUnitRowIdentifier"))).Attributes["row-identifier"];
                    setSelectedPropertyUnit(long.Parse(strId));
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickViewSoldUnitsBtn(object sender, EventArgs e)
        {
            try
            {
                if (validatePropertyUnitSelected())
                {
                    doViewModifyAction(SoldUnitPageMode.VIEW);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickModifySoldUnitsBtn(object sender, EventArgs e)
        {
            try
            {
                if (validatePropertyUnitSelected())
                {
                    doViewModifyAction(getModifyMode());
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickCancelBooking(object sender, EventArgs e)
        {
            try
            {
                if (validatePropertyUnitSelected())
                {
                    resetTabInfo(SoldUnitPageMode.CANCEL_BOOKING);
                    fetchSelectedPropertyUnit();
                    populateCancelBookingUIFields(getCurrentSoldUnit());
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void doViewModifyAction(SoldUnitPageMode pageMode)
        {
            resetTabInfo(pageMode);
            fetchSelectedPropertyUnit();
            populateUIFieldsFromSaleUnitDTO(getCurrentSoldUnit());
        }
        protected void submitChanges(object sender, EventArgs e)
        {
            try
            {
                if (validateSoldUnitChanges())
                {
                    PrUnitSaleDetailDTO prUnitSaleDetailDTO = populatePropertySaleDTOFromUI();
                    soldUnitBO.UpdateSoldPropertyUnitDetails(prUnitSaleDetailDTO);
                    resetTabInfo(SoldUnitPageMode.NONE);
                    string unitName = prUnitSaleDetailDTO.PropertyUnit.UnitNo;
                    setSuccessMessage(string.Format("Property Unit '{0}' is updated successfully", unitName), tab2Anchor.ID, tab2BzStep1);
                    fetchSoldUnits(prUnitSaleDetailDTO.Id);
                    doViewModifyAction(getModifyMode());
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2BzStep1Error);
            }
        }
        protected void cancelBooking(object sender, EventArgs e)
        {
            try
            {
                if (validateCancelBooking())
                {
                    PrUnitSaleDetailDTO prUnitSaleDetailDTO = populateCancelBookingFromUI();
                    soldUnitBO.cancelPropertyUnitBooking(prUnitSaleDetailDTO);
                    resetTabInfo(SoldUnitPageMode.NONE);
                    string unitName = prUnitSaleDetailDTO.PropertyUnit.UnitNo;
                    setSuccessMessage(string.Format("Property Unit '{0}' booking is cancelled successfully.", unitName), tab1Anchor.ID, null);
                    fetchSoldUnits(0);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab3Error);
            }
        }
        protected void cancelTab2Changes(object sender, EventArgs e)
        {
            PrUnitSaleDetailDTO prUnitSaleDetailDto = getCurrentSoldUnit();
            resetTabInfo(SoldUnitPageMode.NONE);
            loadSearchGridAndReSelect(prUnitSaleDetailDto.Id);
        }
        private SoldUnitPageMode getModifyMode()
        {
            PrUnitSaleDetailDTO prUnitSaleDetailDto = getSelectedPropertyUnit();
            return (prUnitSaleDetailDto.AgreementDate == null) ? SoldUnitPageMode.MODIFY : SoldUnitPageMode.MODIFY_LIMITTED;
        }
        protected void reCalculateTotal(object sender, EventArgs e)
        {
            PrUnitSaleDetailDTO prUnitSaleDetailTO = getCurrentSoldUnit();
            if (prUnitSaleDetailTO != null)
            {
                clearTaxSectionSelection(true);
                clearTaxSectionSelection(false);
                calculateAllSaleAmounts(prUnitSaleDetailTO);
                scrollToFieldHdn.Value = txtAgreementValue.ID;
            }
        }
        protected void gotoTab2StepyWizard(object sender, EventArgs e)
        {
            bool isValid = validateTab2Step(tab2ContentBzHdn.Value);
            if (isValid)
            {
                setCurrentStep(goToStepHdn.Value);
            }
        }
        private bool validateCancelBooking()
        {
            Page.Validate(tab3Error);
            bool isValid = Page.IsValid;
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        /**
         * Define all validation which will be done before add or update property.
         * */
        private bool validateSoldUnitChanges()
        {
            bool isValid = validateTab2Step(tab2BzStep1);
            if (isValid) isValid = validateAgreementDate();
            return isValid;
        }
        private bool validateAgreementDate()
        {
            bool isValid = true;
            DateTime? possessionDate = CommonUtil.getCSDate(txtPossesionDate.Text);
            DateTime? agreementDate = CommonUtil.getCSDate(txtAgreementDate.Text);
            if (possessionDate != null)
            {
                if (agreementDate == null || agreementDate.Value.CompareTo(possessionDate.Value) > 0)
                {
                    setErrorMessage("Possession of Property Unit not allowed before Agreement.", tab2BzStep2Error);
                    isValid = false;
                }
            }
            return isValid;
        }
        /**
         * Validates given step.
         * */
        private bool validateTab2Step(string step)
        {
            bool isValid = true;
            if (!SoldUnitPageMode.VIEW.ToString().Equals(pageModeHdn.Value))
            {
                if (step.Equals(tab2BzStep1) && SoldUnitPageMode.MODIFY.ToString().Equals(pageModeHdn.Value))
                {
                    isValid = validateAllStep1Group();
                }
                else if (step.Equals(tab2BzStep2))
                {

                }
            }
            return isValid;
        }
        private bool validateAllStep1Group()
        {
            Page.Validate(tab2BzStep1Error);
            bool isValid = Page.IsValid;
            if (!isValid)
            {
                tab2ContentBzHdn.Value = tab2BzStep1;
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        private void setCurrentStep(string step)
        {
            tab2ContentBzHdn.Value = step;
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        private void calculateAllSaleAmounts(PrUnitSaleDetailDTO prUnitSaleDetailDto)
        {
            decimal agreementValue = CommonUtil.getDecimaNotNulllWithoutExt(txtAgreementValue.Text);
            decimal totalTax = Decimal.Zero;
            decimal salePymtAmt = Decimal.Zero;
            foreach (PrUnitSaleTaxDetailDTO prUnitSaleTaxDetailDto in prUnitSaleDetailDto.uiTaxDetails)
            {
                decimal tmpPercentage = Decimal.Divide(prUnitSaleTaxDetailDto.TaxPercentage, 100);
                decimal taxAmt = Math.Round(Decimal.Multiply(agreementValue, tmpPercentage), 2);
                if (prUnitSaleTaxDetailDto.TaxAmtLimit > 0 && taxAmt > prUnitSaleTaxDetailDto.TaxAmtLimit) taxAmt = prUnitSaleTaxDetailDto.TaxAmtLimit;
                prUnitSaleTaxDetailDto.TaxAmt = taxAmt;
                totalTax = totalTax + taxAmt;
            }
            salePymtAmt = totalTax + agreementValue;
            txtBookTotalTax.Text = totalTax.ToString();
            txtBookTotalUnitCost.Text = salePymtAmt.ToString();
            foreach (PrUnitSaleTaxDetailDTO prUnitSaleTaxDetailDto in prUnitSaleDetailDto.uiCMTaxDetails)
            {
                decimal tmpPercentage = Decimal.Divide(prUnitSaleTaxDetailDto.TaxPercentage, 100);
                decimal taxAmt = Math.Round(Decimal.Multiply(agreementValue, tmpPercentage), 2);
                if (prUnitSaleTaxDetailDto.TaxAmtLimit > 0 && taxAmt > prUnitSaleTaxDetailDto.TaxAmtLimit) taxAmt = prUnitSaleTaxDetailDto.TaxAmtLimit;
                prUnitSaleTaxDetailDto.TaxAmt = taxAmt;
            }
            populateTaxDetailGrid(prUnitSaleDetailDto);
            populateCMTaxDetailGrid(prUnitSaleDetailDto);
            updateSalePaymentAmount(prUnitSaleDetailDto, salePymtAmt);
        }
        private void updateSalePaymentAmount(PrUnitSaleDetailDTO prUnitSaleDetailDto, decimal salePymtAmt) {
            PrUnitSalePymtDTO prUnitSalePymtDto = prUnitSaleDetailDto.PrUnitSalePymts.ToList<PrUnitSalePymtDTO>().Find(x => x.PymtType.Name.Equals(Constants.MCD_SALE_PAYMENT));
            if(prUnitSalePymtDto.PaymentMaster.TotalPaid.CompareTo(salePymtAmt) < 0) {
                //TODO - warning -> Customer has paid more than total sale payment.
            }
            prUnitSalePymtDto.PymtAmt = salePymtAmt;
            prUnitSalePymtDto.PaymentMaster.TotalAmt = salePymtAmt;
            decimal totalPending = prUnitSalePymtDto.PaymentMaster.TotalAmt - prUnitSalePymtDto.PaymentMaster.TotalPaid;
            if(totalPending > 0) {
                prUnitSalePymtDto.PaymentMaster.TotalPending = totalPending;
                prUnitSalePymtDto.PaymentMaster.Status = PymtMasterStatus.Pending;
            } else {
                prUnitSalePymtDto.PaymentMaster.TotalPending = 0;
                prUnitSalePymtDto.PaymentMaster.Status = PymtMasterStatus.Paid;
            }
            pnlPaymentAdd.Visible = false;
            clearPaymentViewState();
            populateSalePymtGrid(prUnitSaleDetailDto);
        }
        private PrUnitSaleTaxDetailDTO populatePrSaleTaxDetail(PropertyTaxDetailDTO propertyTaxDetailDto)
        {
            PrUnitSaleTaxDetailDTO taxDetailDto = new PrUnitSaleTaxDetailDTO();
            taxDetailDto.TaxType = propertyTaxDetailDto.TaxType;
            taxDetailDto.TaxPercentage = propertyTaxDetailDto.TaxPercentage;
            taxDetailDto.TaxAmtLimit = propertyTaxDetailDto.TaxAmtLimit;
            taxDetailDto.IncludeInTotalPymt = propertyTaxDetailDto.IncludeInTotalPymt;
            taxDetailDto.TaxAmt = Decimal.Zero;
            UserDefinitionDTO userDef = getUserDefinitionDTO();
            taxDetailDto.FirmNumber = userDef.FirmNumber;
            taxDetailDto.InsertUser = userDef.Username;
            taxDetailDto.UpdateUser = userDef.Username;

            return taxDetailDto;
        }
        private PrUnitSaleDetailDTO populatePropertySaleDTOFromUI()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            PrUnitSaleDetailDTO prUnitSaleDetailDto = getCurrentSoldUnit();
            if (SoldUnitPageMode.MODIFY.ToString().Equals(pageModeHdn.Value))
            {
                prUnitSaleDetailDto.SaleRate = CommonUtil.getDecimaNotNulllWithoutExt(txtBookingRate.Text);
                prUnitSaleDetailDto.AgreementAmt = CommonUtil.getDecimaNotNulllWithoutExt(txtAgreementValue.Text);
                prUnitSaleDetailDto.TotalTaxAmt = CommonUtil.getDecimaNotNulllWithoutExt(txtBookTotalTax.Text);
                prUnitSaleDetailDto.TotalPymtAmt = CommonUtil.getDecimaNotNulllWithoutExt(txtBookTotalUnitCost.Text);
                prUnitSaleDetailDto.TotalPackageCost = prUnitSaleDetailDto.TotalPymtAmt;
                prUnitSaleDetailDto.PrUnitSaleTaxDetails.Clear();
                prUnitSaleDetailDto.uiTaxDetails.ForEach(t => prUnitSaleDetailDto.PrUnitSaleTaxDetails.Add(t));
                prUnitSaleDetailDto.uiCMTaxDetails.ForEach(t => prUnitSaleDetailDto.PrUnitSaleTaxDetails.Add(t));
            }
            prUnitSaleDetailDto.AgreementDate = CommonUtil.getCSDate(txtAgreementDate.Text);
            prUnitSaleDetailDto.PossessionDate = CommonUtil.getCSDate(txtPossesionDate.Text);
            prUnitSaleDetailDto.LoanBankName = txtLoanBankName.Text;
            prUnitSaleDetailDto.LoanBankBranch = txtLoanBranch.Text;
            prUnitSaleDetailDto.LoanAmt = CommonUtil.getDecimalWithoutExt(txtLoanAmount.Text);

            return prUnitSaleDetailDto;
        }
        private PrUnitSaleDetailDTO populateCancelBookingFromUI()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            PrUnitSaleDetailDTO prUnitSaleDetailDto = getCurrentSoldUnit();
            prUnitSaleDetailDto.CancellationFirmMember = CommonUIConverter.getFirmMemberDTO(drpCancellationEmployee.Text, null);
            prUnitSaleDetailDto.CanellationDate = CommonUtil.getCSDateNotNull(txtCancellationDate.Text);
            decimal? cancellationFee = CommonUtil.getDecimalWithoutExt(txtCancellationFee.Text);
            prUnitSaleDetailDto.CancellationFee = (cancellationFee == null) ? 0 : cancellationFee;
            prUnitSaleDetailDto.CancellationReason = txtCancellationReason.Text;
            prUnitSaleDetailDto.Status = PRUnitSaleStatus.Cancelled;
            foreach (PrUnitSalePymtDTO prUnitSalePymtDto in prUnitSaleDetailDto.PrUnitSalePymts)
            {
                if (prUnitSalePymtDto.PaymentMaster.Status == PymtMasterStatus.Paid || prUnitSalePymtDto.PaymentMaster.Status == PymtMasterStatus.Pending)
                {
                    prUnitSalePymtDto.PaymentMaster.Status = PymtMasterStatus.Suspended;
                }
            }

            decimal cancellationPymtAmt = getCancellationPaymentAmt(prUnitSaleDetailDto);
            if (cancellationPymtAmt > 0)
            {
                PrUnitSalePymtDTO prUnitSalePymtDto = populatePrUnitSalePymtAdd();
                populatePrUnitSalePymtForCancellation(prUnitSalePymtDto, cancellationPymtAmt);
                addNewPymtMaster(prUnitSalePymtDto);
                prUnitSaleDetailDto.PrUnitSalePymts.Add(prUnitSalePymtDto);
            }

            return prUnitSaleDetailDto;
        }
        protected void reCalculateCancellationPayment(object sender, EventArgs e)
        {
            PrUnitSaleDetailDTO prUnitSaleDetailTO = getCurrentSoldUnit();
            decimal cancellationPymtAmt = getCancellationPaymentAmt(prUnitSaleDetailTO);
            lbTotalPaymentToCust.Text = cancellationPymtAmt.ToString();
            scrollToFieldHdn.Value = lbTotalPaymentAmt.ID;
        }
        private decimal getCancellationPaymentAmt(PrUnitSaleDetailDTO prUnitSaleDetailDto)
        {
            decimal cancellationPymtAmt = 0;
            decimal totalPaidAmt = 0;
            foreach (PrUnitSalePymtDTO prUnitSalePymtDto in prUnitSaleDetailDto.PrUnitSalePymts)
            {
                if (prUnitSalePymtDto.PaymentMaster.Status != PymtMasterStatus.Deleted)
                {
                    totalPaidAmt = totalPaidAmt + prUnitSalePymtDto.PaymentMaster.TotalPaid;
                }
            }
            cancellationPymtAmt = totalPaidAmt - CommonUtil.getDecimaNotNulllWithoutExt(txtCancellationFee.Text);
            if (cancellationPymtAmt < 0) cancellationPymtAmt = 0;
            return cancellationPymtAmt;
        }
        private void populatePrUnitSalePymtForCancellation(PrUnitSalePymtDTO prUnitSalePymtDto, decimal cancellationPymtAmt)
        {
            prUnitSalePymtDto.PymtType = masterDataBO.getMasterDataType(getUserDefinitionDTO().FirmNumber, Constants.MCDType.PR_UNIT_PYMT_TYPE,
                Constants.MCD_CANCELLATION_PAYMENT);
            prUnitSalePymtDto.PymtDate = CommonUtil.getCSDateNotNull(txtCancellationDate.Text);
            prUnitSalePymtDto.PymtAmt = cancellationPymtAmt;
            prUnitSalePymtDto.PymtTo = PRUnitSalePymtTo.Customer;
            prUnitSalePymtDto.Description = "Remaining payment after property unit booking cancellation.";
            prUnitSalePymtDto.UpdateUser = getUserDefinitionDTO().Username;
        }
        private void populateUIFieldsFromSaleUnitDTO(PrUnitSaleDetailDTO prUnitSaleDetailDto)
        {
            PropertyUnitDTO propertyUnitDto = prUnitSaleDetailDto.PropertyUnit;
            PropertyTowerDTO propertyTowerDto = prUnitSaleDetailDto.PropertyUnit.PropertyTower;
            CustomerDTO customerDto = prUnitSaleDetailDto.Customer;
            populateUnitInfoSection(prUnitSaleDetailDto);
            populateBookingFields(prUnitSaleDetailDto);
            txtAgreementDate.Text = CommonUtil.getCSDate(prUnitSaleDetailDto.AgreementDate);
            txtPossesionDate.Text = CommonUtil.getCSDate(prUnitSaleDetailDto.PossessionDate);
            txtLoanBankName.Text = prUnitSaleDetailDto.LoanBankName;
            txtLoanBranch.Text = prUnitSaleDetailDto.LoanBankBranch;
            txtLoanAmount.Text = (prUnitSaleDetailDto.LoanAmt != null)?prUnitSaleDetailDto.LoanAmt.ToString():null;            
            populateTaxDetailGrid(prUnitSaleDetailDto);
            populateCMTaxDetailGrid(prUnitSaleDetailDto);
            populateSalePymtGrid(prUnitSaleDetailDto);
        }
        private void populateBookingFields(PrUnitSaleDetailDTO prUnitSaleDetailDto)
        {
            txtCustomer.Text = prUnitSaleDetailDto.Customer.FirstName + " " + prUnitSaleDetailDto.Customer.LastName;
            txtEmployee.Text = prUnitSaleDetailDto.FirmMember.FirstName + " " + prUnitSaleDetailDto.FirmMember.LastName;
            txtBookingDate.Text = CommonUtil.getCSDate(prUnitSaleDetailDto.BookingDate);
            txtBookingRate.Text = prUnitSaleDetailDto.SaleRate.ToString();
            txtAgreementValue.Text = prUnitSaleDetailDto.AgreementAmt.ToString();
            txtBookTotalTax.Text = prUnitSaleDetailDto.TotalTaxAmt.ToString();
            txtBookTotalUnitCost.Text = prUnitSaleDetailDto.TotalPymtAmt.ToString();
        }
        private void populateCancelBookingUIFields(PrUnitSaleDetailDTO prUnitSaleDetailDto)
        {
            populateUnitInfoSection(prUnitSaleDetailDto);
            txtCancellationDate.Text = CommonUtil.getTodayDate();
            txtCancellationFee.Text = null;
            txtCancellationReason.Text = null;
            drpCancellationEmployee.ClearSelection();
            List<PrUnitSalePymtDTO> tmpPymtList = prUnitSaleDetailDto.PrUnitSalePymts.ToList<PrUnitSalePymtDTO>()
                .FindAll(x => x.PaymentMaster.Status != PymtMasterStatus.Deleted && x.PymtTo == PRUnitSalePymtTo.Builder);
            lbTotalPaymentAmt.Text = (tmpPymtList.Sum(x => x.PaymentMaster.TotalAmt)).ToString();
            lbTotalPaidAmt.Text = (tmpPymtList.Sum(x => x.PaymentMaster.TotalPaid)).ToString();
            lbTotalPaymentToCust.Text = lbTotalPaidAmt.Text;
            cancelInfoPymtGrid.DataSource = tmpPymtList;
            cancelInfoPymtGrid.DataBind();
        }
        private void populateUnitInfoSection(PrUnitSaleDetailDTO prUnitSaleDetailDto)
        {
            if (prUnitSaleDetailDto != null)
            {
                if (SoldUnitPageMode.CANCEL_BOOKING.ToString().Equals(pageModeHdn.Value))
                {
                    PropertyUnitDTO propertyUnitDto = prUnitSaleDetailDto.PropertyUnit;
                    PropertyTowerDTO propertyTowerDto = prUnitSaleDetailDto.PropertyUnit.PropertyTower;
                    txtCancelInfoPropertyName.Text = propertyTowerDto.Property.Name;
                    txtCancelInfoPropertyTower.Text = propertyTowerDto.Name;
                    txtCancelInfoUnitNo.Text = prUnitSaleDetailDto.PropertyUnit.UnitNo;
                    txtCancelInfoUnitType.Text = (propertyUnitDto.UnitType != null) ? propertyUnitDto.UnitType.Name : null;
                    txtCancelInfoBuiltupArea.Text = propertyUnitDto.BuildupArea.ToString();
                    txtCancelInfoCarpetArea.Text = propertyUnitDto.CarpetArea.ToString();
                    txtCancelInfoCustomer.Text = prUnitSaleDetailDto.Customer.FirstName + " " + prUnitSaleDetailDto.Customer.LastName;
                    txtCancelInfoBookingDate.Text = CommonUtil.getCSDate(prUnitSaleDetailDto.BookingDate);
                }
                else
                {
                    PropertyUnitDTO propertyUnitDto = prUnitSaleDetailDto.PropertyUnit;
                    PropertyTowerDTO propertyTowerDto = prUnitSaleDetailDto.PropertyUnit.PropertyTower;
                    txtBookPropertyName.Text = propertyTowerDto.Property.Name;
                    txtBookPropertyTower.Text = propertyTowerDto.Name;
                    txtBookUnitNo.Text = prUnitSaleDetailDto.PropertyUnit.UnitNo;
                    txtBookUnitType.Text = (propertyUnitDto.UnitType != null) ? propertyUnitDto.UnitType.Name : null;
                    txtBookBuiltupArea.Text = propertyUnitDto.BuildupArea.ToString();
                    txtBookCarpetArea.Text = propertyUnitDto.CarpetArea.ToString();
                    if (SoldUnitPageMode.MODIFY_LIMITTED.ToString().Equals(pageModeHdn.Value))
                    {
                        populateBookingFields(prUnitSaleDetailDto);
                    }
                }
            }
        }
        private void populateTaxDetailGrid(PrUnitSaleDetailDTO prUnitSaleDetailDTO)
        {
            taxDetailGrid.DataSource = new List<PrUnitSaleTaxDetailDTO>();
            if (prUnitSaleDetailDTO != null && prUnitSaleDetailDTO.uiTaxDetails != null)
            {
                assignUiIndexToTaxDetail(prUnitSaleDetailDTO.uiTaxDetails);
                taxDetailGrid.DataSource = prUnitSaleDetailDTO.uiTaxDetails;
            }
            taxDetailGrid.DataBind();
        }
        private void populateCMTaxDetailGrid(PrUnitSaleDetailDTO prUnitSaleDetailDTO)
        {
            cmTaxDetailGrid.DataSource = new List<PrUnitSaleTaxDetailDTO>();
            if (prUnitSaleDetailDTO != null && prUnitSaleDetailDTO.uiTaxDetails != null)
            {
                assignUiIndexToTaxDetail(prUnitSaleDetailDTO.uiCMTaxDetails);
                cmTaxDetailGrid.DataSource = prUnitSaleDetailDTO.uiCMTaxDetails;
            }
            cmTaxDetailGrid.DataBind();
        }
        private void assignUiIndexToTaxDetail(List<PrUnitSaleTaxDetailDTO> taxDetailDtos)
        {
            if (taxDetailDtos != null && taxDetailDtos.Count > 0)
            {
                long uiIndex = 1;
                foreach (PrUnitSaleTaxDetailDTO taxDetailDto in taxDetailDtos)
                {
                    taxDetailDto.UiIndex = uiIndex++;
                    taxDetailDto.RowInfo = CommonUIConverter.getGridViewRowInfo(taxDetailDto);
                }
            }
        }
        private void populateSalePymtGrid(PrUnitSaleDetailDTO prUnitSaleDetailDTO)
        {
            paymentGrid.DataSource = new List<PrUnitSalePymtDTO>();
            if (prUnitSaleDetailDTO != null && prUnitSaleDetailDTO.PrUnitSalePymts != null)
            {
                assignUiIndexToSalePymts(prUnitSaleDetailDTO.PrUnitSalePymts);
                paymentGrid.DataSource = prUnitSaleDetailDTO.PrUnitSalePymts;
            }
            paymentGrid.DataBind();
        }
        private void assignUiIndexToSalePymts(ISet<PrUnitSalePymtDTO> salePymtDtos)
        {
            if (salePymtDtos != null && salePymtDtos.Count > 0)
            {
                long uiIndex = 1;
                foreach (PrUnitSalePymtDTO salePymtDto in salePymtDtos)
                {
                    salePymtDto.UiIndex = uiIndex++;
                    salePymtDto.RowInfo = CommonUIConverter.getGridViewRowInfo(salePymtDto);
                }
            }
        }
        //TaxDetail Combined Table actions - Start
        private bool isCMTax(string currentTax)
        {
            return currentTax.Equals("CMTax");
        }
        private void clearTaxSectionSelection(bool isCMTaxSextion)
        {
            PrUnitSaleDetailDTO prUnitSaleDetailDto = getCurrentSoldUnit();
            if (isCMTaxSextion)
            {
                pnlCMTaxDetailAdd.Visible = false;
                if (cmTaxDetailGrid.Rows.Count > 0)
                {
                    foreach (GridViewRow row in cmTaxDetailGrid.Rows)
                    {
                        GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdCMTaxDetailSelect");
                        if (radioBtn != null) radioBtn.Checked = false;
                    }
                }
                if (prUnitSaleDetailDto.uiCMTaxDetails != null) prUnitSaleDetailDto.uiCMTaxDetails.ForEach(c => c.isUISelected = false);
            }
            else
            {
                pnlTaxDetailAdd.Visible = false;
                if (taxDetailGrid.Rows.Count > 0)
                {
                    foreach (GridViewRow row in taxDetailGrid.Rows)
                    {
                        GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdTaxDetailSelect");
                        if (radioBtn != null) radioBtn.Checked = false;
                    }
                }
                if (prUnitSaleDetailDto.uiTaxDetails != null) prUnitSaleDetailDto.uiTaxDetails.ForEach(c => c.isUISelected = false);
            }
        }
        private void selectTaxDetail(PrUnitSaleTaxDetailDTO taxDetailDto, bool isCMTaxSection)
        {
            GridView currentGrid = taxDetailGrid;
            string radioBtselector = "rdTaxDetailSelect";
            string rowBtselector = "btnTaxDetailRowIdentifier";
            if (isCMTaxSection)
            {
                currentGrid = cmTaxDetailGrid;
                radioBtselector = "rdCMTaxDetailSelect";
                rowBtselector = "btnCMTaxDetailRowIdentifier";
            }
            if (currentGrid.Rows.Count > 0)
            {
                taxDetailDto.isUISelected = true;
                foreach (GridViewRow row in currentGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl(radioBtselector);
                    Button rowIdenBtn = (Button)row.FindControl(rowBtselector);
                    radioBtn.Checked = false;
                    if (rowIdenBtn != null && taxDetailDto.UiIndex.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                    {
                        radioBtn.Checked = true;
                    }
                }
            }
        }
        private void initTaxDetailSection(bool isCMTaxSection)
        {
            if (isCMTaxSection)
            {
                lbCMTaxDetailAddUpdateSectionHeader.Text = Resources.Labels.label_sectionheader_add_tax;
                pnlCMTaxDetailAdd.Visible = true;
            }
            else
            {
                lbTaxDetailAddUpdateSectionHeader.Text = Resources.Labels.label_sectionheader_add_tax;
                pnlTaxDetailAdd.Visible = true;
            }
        }
        private void initTaxDetailSectionFields(bool isCMTaxSection)
        {
            initTaxDetailSection(isCMTaxSection);
            populateDrpTaxType(isCMTaxSection);
            if (isCMTaxSection)
            {
                drpCMTaxType.ClearSelection();
                txtCMTaxRate.Text = null;
                txtCMTaxLimit.Text = null;
                txtCMTaxAmount.Text = null;
                SetFocus(drpCMTaxType);
                scrollToFieldHdn.Value = pnlCMTaxDetailAdd.ID;
            }
            else
            {
                drpTaxType.ClearSelection();
                txtTaxRate.Text = null;
                txtTaxLimit.Text = null;
                txtTaxAmount.Text = null;
                SetFocus(drpTaxType);
                scrollToFieldHdn.Value = pnlTaxDetailAdd.ID;
            }
        }
        private bool populateDrpTaxType(bool isCMTaxSection)
        {
            bool hasTax = false;
            DropDownList tmpTaxDrp = (isCMTaxSection) ? drpCMTaxType : drpTaxType;
            PropertyDTO propertyDTO = getCurrentSoldUnit().PropertyUnit.PropertyTower.Property;
            tmpTaxDrp.Items.Clear();
            tmpTaxDrp.Items.Insert(0, new ListItem(Constants.SELECT_ITEM[0], Constants.SELECT_ITEM[1]));
            if (propertyDTO.PropertyTaxDetails != null && propertyDTO.PropertyTaxDetails.Count > 0)
            {
                PrUnitSaleDetailDTO prUnitSaleDetailDTO = getCurrentSoldUnit();
                foreach (PropertyTaxDetailDTO propertyTaxDetailDto in propertyDTO.PropertyTaxDetails)
                {
                    if (!(prUnitSaleDetailDTO.uiTaxDetails.Any(t => t.TaxType.Id == propertyTaxDetailDto.TaxType.Id)
                            || prUnitSaleDetailDTO.uiCMTaxDetails.Any(t => t.TaxType.Id == propertyTaxDetailDto.TaxType.Id)))
                    {
                        tmpTaxDrp.Items.Add(new ListItem(propertyTaxDetailDto.TaxType.Name, propertyTaxDetailDto.TaxType.Id.ToString()));
                        hasTax = true;
                    }
                }
            }
            return hasTax;
        }
        private PrUnitSaleTaxDetailDTO getSelectedTaxDetail(bool isCMTaxSection)
        {
            if (isCMTaxSection)
                return getCurrentSoldUnit().uiCMTaxDetails.Find(c => c.isUISelected);
            else
                return getCurrentSoldUnit().uiTaxDetails.Find(c => c.isUISelected);
        }
        private bool validateTaxDetailSelected(bool isCMTaxSection)
        {
            bool isSelected = true;
            PrUnitSaleTaxDetailDTO taxDetailDto = getSelectedTaxDetail(isCMTaxSection);
            if (taxDetailDto == null)
            {
                isSelected = false;
                clearTaxSectionSelection(isCMTaxSection);
                setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Tax Detail"), tab2BzStep1Error);
            }
            return isSelected;
        }
        private PrUnitSaleTaxDetailDTO populatePropertyTaxDetailAdd(PrUnitSaleDetailDTO prUnitSaleDetailDTO, bool isCMTaxSection)
        {
            PropertyDTO propertyDTO = getCurrentSoldUnit().PropertyUnit.PropertyTower.Property;
            long selectedTaxId = (isCMTaxSection) ? long.Parse(drpCMTaxType.Text) : long.Parse(drpTaxType.Text);
            PropertyTaxDetailDTO selectedTaxDetailDto = propertyDTO.PropertyTaxDetails.FirstOrDefault(t => t.TaxType.Id == selectedTaxId);
            PrUnitSaleTaxDetailDTO taxDetailDto = populatePrSaleTaxDetail(selectedTaxDetailDto);
            taxDetailDto.TaxPercentage = CommonUtil.getDecimaNotNulllWithoutExt((isCMTaxSection) ? txtCMTaxRate.Text : txtTaxRate.Text);
            taxDetailDto.TaxAmtLimit = CommonUtil.getDecimaNotNulllWithoutExt((isCMTaxSection) ? txtCMTaxLimit.Text : txtTaxLimit.Text);
            taxDetailDto.TaxAmt = CommonUtil.getDecimaNotNulllWithoutExt((isCMTaxSection) ? txtCMTaxAmount.Text : txtTaxAmount.Text);
            taxDetailDto.UpdateUser = getUserDefinitionDTO().Username;
            if (isCMTaxSection)
            {
                taxDetailDto.IncludeInTotalPymt = IncludeInPymtTotal.No;
                prUnitSaleDetailDTO.uiCMTaxDetails.Add(taxDetailDto);
            }
            else
            {
                taxDetailDto.IncludeInTotalPymt = IncludeInPymtTotal.Yes;
                prUnitSaleDetailDTO.uiTaxDetails.Add(taxDetailDto);
            }
            return taxDetailDto;
        }
        protected void onSelectTaxDetail(object sender, EventArgs e)
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            bool isCMTaxSection = isCMTax(rd.Attributes["data-taxsection"]);
            clearTaxSectionSelection(!isCMTaxSection);
            if (isCMTaxSection)
            {
                pnlCMTaxDetailAdd.Visible = false;
                if (rd.Checked)
                {
                    long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnCMTaxDetailRowIdentifier"))).Attributes["row-identifier"]);
                    List<PrUnitSaleTaxDetailDTO> taxDetailList = getCurrentSoldUnit().uiCMTaxDetails;
                    taxDetailList.ForEach(c => c.isUISelected = false);
                    taxDetailList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
                }
            }
            else
            {
                pnlTaxDetailAdd.Visible = false;
                if (rd.Checked)
                {
                    long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnTaxDetailRowIdentifier"))).Attributes["row-identifier"]);
                    List<PrUnitSaleTaxDetailDTO> taxDetailList = getCurrentSoldUnit().uiTaxDetails;
                    taxDetailList.ForEach(c => c.isUISelected = false);
                    taxDetailList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
                }
            }
        }
        protected void onClickAddTaxDetailBtn(object sender, EventArgs e)
        {
            try
            {
                LinkButton rd = (LinkButton)sender;
                bool isCMTaxSection = isCMTax(rd.Attributes["data-taxsection"]);
                clearTaxSectionSelection(!isCMTaxSection);
                clearTaxSectionSelection(isCMTaxSection);
                if (populateDrpTaxType(isCMTaxSection))
                {
                    initTaxDetailSectionFields(isCMTaxSection);
                }
                else
                {
                    setErrorMessage("Tax type not available for add", tab2BzStep1Error);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2BzStep1Error);
            }
        }
        protected void onTaxRateChanged(object sender, EventArgs e)
        {
            TextBox tmpTxtBox = (TextBox)sender;
            bool isCMTaxSection = isCMTax(tmpTxtBox.Attributes["data-taxsection"]);
            DropDownList tmpDrp = (isCMTaxSection) ? drpCMTaxType : drpTaxType;
            if (!(string.IsNullOrWhiteSpace(tmpDrp.Text) || string.IsNullOrWhiteSpace(tmpTxtBox.Text)))
            {
                decimal agreementValue = CommonUtil.getDecimaNotNulllWithoutExt(txtAgreementValue.Text);
                decimal taxPercentage = Decimal.Divide(CommonUtil.getDecimaNotNulllWithoutExt(tmpTxtBox.Text), 100);
                decimal tmpTaxLimit = (isCMTaxSection) ? CommonUtil.getDecimaNotNulllWithoutExt(txtCMTaxLimit.Text) : CommonUtil.getDecimaNotNulllWithoutExt(txtTaxLimit.Text);
                decimal taxAmt = Math.Round(Decimal.Multiply(agreementValue, taxPercentage), 2);
                if (tmpTaxLimit > 0 && taxAmt > tmpTaxLimit) taxAmt = tmpTaxLimit;
                if (isCMTaxSection) txtCMTaxAmount.Text = taxAmt.ToString(); else txtTaxAmount.Text = taxAmt.ToString();
            }
            else
            {
                if (isCMTaxSection) txtCMTaxAmount.Text = null; else txtTaxAmount.Text = null;
            }
        }
        protected void onTaxTypeChanged(object sender, EventArgs e)
        {
            DropDownList tmpDrp = (DropDownList)sender;
            bool isCMTaxSection = isCMTax(tmpDrp.Attributes["data-taxsection"]);
            if (!string.IsNullOrWhiteSpace(tmpDrp.Text))
            {
                PropertyDTO propertyDTO = getCurrentSoldUnit().PropertyUnit.PropertyTower.Property;
                long selectedTaxId = long.Parse(tmpDrp.Text);
                PropertyTaxDetailDTO selectedTaxDetailDto = propertyDTO.PropertyTaxDetails.FirstOrDefault(t => t.TaxType.Id == selectedTaxId);
                decimal agreementValue = CommonUtil.getDecimaNotNulllWithoutExt(txtAgreementValue.Text);
                decimal tmpPercentage = Decimal.Divide(selectedTaxDetailDto.TaxPercentage, 100);
                decimal taxAmt = Math.Round(Decimal.Multiply(agreementValue, tmpPercentage), 2);
                if (selectedTaxDetailDto.TaxAmtLimit > 0 && taxAmt > selectedTaxDetailDto.TaxAmtLimit) taxAmt = selectedTaxDetailDto.TaxAmtLimit;
                if (isCMTaxSection) txtCMTaxRate.Text = selectedTaxDetailDto.TaxPercentage.ToString(); else txtTaxRate.Text = selectedTaxDetailDto.TaxPercentage.ToString();
                if (isCMTaxSection) txtCMTaxLimit.Text = selectedTaxDetailDto.TaxAmtLimit.ToString(); else txtTaxLimit.Text = selectedTaxDetailDto.TaxAmtLimit.ToString();
                if (isCMTaxSection) txtCMTaxAmount.Text = taxAmt.ToString(); else txtTaxAmount.Text = taxAmt.ToString();
            }
            else
            {
                if (isCMTaxSection) txtCMTaxRate.Text = null; else txtTaxRate.Text = null;
                if (isCMTaxSection) txtCMTaxLimit.Text = null; else txtTaxLimit.Text = null;
                if (isCMTaxSection) txtCMTaxAmount.Text = null; else txtTaxAmount.Text = null;
            }
        }
        protected void deleteTaxDetail(object sender, EventArgs e)
        {
            try
            {
                Button rd = (Button)sender;
                bool isCMTaxSection = isCMTax(rd.Attributes["data-taxsection"]);
                clearTaxSectionSelection(!isCMTaxSection);
                if (validateTaxDetailSelected(isCMTaxSection))
                {
                    PrUnitSaleDetailDTO prUnitSaleDetailDTO = getCurrentSoldUnit();
                    PrUnitSaleTaxDetailDTO taxDetailDto = getSelectedTaxDetail(isCMTaxSection);
                    if (isCMTaxSection) prUnitSaleDetailDTO.uiCMTaxDetails.Remove(taxDetailDto);
                    else prUnitSaleDetailDTO.uiTaxDetails.Remove(taxDetailDto);
                    clearTaxSectionSelection(isCMTaxSection);
                    calculateAllSaleAmounts(prUnitSaleDetailDTO);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, taxDetailDto.TaxType.Name), tab2Anchor.ID, tab2BzStep1);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2BzStep1Error);
            }
        }
        protected void addNewTaxDetail(object sender, EventArgs e)
        {
            try
            {
                LinkButton rd = (LinkButton)sender;
                bool isCMTaxSection = isCMTax(rd.Attributes["data-taxsection"]);
                clearTaxSectionSelection(!isCMTaxSection);
                if (validateTaxDetail(isCMTaxSection))
                {
                    PrUnitSaleDetailDTO prUnitSaleDetailDTO = getCurrentSoldUnit();
                    PrUnitSaleTaxDetailDTO taxDetailDto = populatePropertyTaxDetailAdd(prUnitSaleDetailDTO, isCMTaxSection);
                    calculateAllSaleAmounts(prUnitSaleDetailDTO);
                    selectTaxDetail(taxDetailDto, isCMTaxSection);
                    clearTaxSectionSelection(isCMTaxSection);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, taxDetailDto.TaxType.Name), tab2Anchor.ID, tab2BzStep1);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2BzStep1Error);
            }
        }
        protected void cancelTaxDetail(object sender, EventArgs e)
        {
            LinkButton rd = (LinkButton)sender;
            bool isCMTaxSection = isCMTax(rd.Attributes["data-taxsection"]);
            clearTaxSectionSelection(isCMTaxSection);
            scrollToFieldHdn.Value = (isCMTaxSection) ? lbCMTaxSectionHeader.ID : lbTaxSectionHeader.ID;
        }
        //TaxDetail Combined Table actions - END
        private bool validateTaxDetail(bool isCMTaxSection)
        {
            bool isValid = true;
            string vGroup = (isCMTaxSection) ? "tab2BzStep1ErrorGrid2" : "tab2BzStep1ErrorGrid1";
            Page.Validate(vGroup);
            isValid = Page.IsValid;
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        //TaxDetail Table actions - END
        //Payment Table actions - Start
        private void initPaymentUpdateSection(bool isAdd)
        {
            lbAddUpdateSectionHeader.Text = (isAdd) ? Resources.Labels.label_sectionheader_addpayment : Resources.Labels.label_sectionheader_modifypayment;
            pnlPaymentAdd.Visible = true;
            btnPaymentAddToGrid.Visible = isAdd;
            btnPaymentUpdateToGrid.Visible = !isAdd;
            addPymtTypeBtn.Visible = true;
            populateDrpPaymentType(isAdd);
            enableFields(isAdd);
            if (!isAdd)
            {
                addPymtTypeBtn.Visible = false;
                PrUnitSalePymtDTO prUnitSalePymtDto = getSelectedPrUnitSalePayment();
                if (isSalePayment(prUnitSalePymtDto.PymtType.Name) || isCancellationPayment(prUnitSalePymtDto.PymtType.Name)
                    || prUnitSalePymtDto.PaymentMaster.Status == PymtMasterStatus.Deleted)
                {
                    btnPaymentUpdateToGrid.Visible = false;
                }
            }
        }
        private void enableFields(bool isAdd)
        {
            drpPaymentType.Visible = isAdd;
            txtROPaymentType.Visible = !isAdd;
            txtROPaymentType.ReadOnly = true;
            pnlPaymentDate.Visible = isAdd;
            txtROPaymentDate.Visible = !isAdd;
            txtROPaymentDate.ReadOnly = true;
            drpPaymentTo.Visible = isAdd;
            txtROPaymentTo.Visible = !isAdd;
            txtROPaymentTo.ReadOnly = true;
        }
        private void initPaymentSectionFields(PrUnitSalePymtDTO prUnitSalePymtDto)
        {
            if (prUnitSalePymtDto != null) txtPaymentAmount.Text = prUnitSalePymtDto.PymtAmt.ToString(); else txtPaymentAmount.Text = null;
            if (prUnitSalePymtDto != null) txtPaymentDescription.Text = prUnitSalePymtDto.Description; else txtPaymentDescription.Text = null;
            if (prUnitSalePymtDto != null)
            {
                txtROPaymentType.Text = prUnitSalePymtDto.PymtType.Name;
                txtROPaymentDate.Text = CommonUtil.getCSDate(prUnitSalePymtDto.PymtDate);
                txtROPaymentTo.Text = prUnitSalePymtDto.PymtTo.ToString();
                txtPaymentAmount.ReadOnly = isSalePayment(prUnitSalePymtDto.PymtType.Name) || isCancellationPayment(prUnitSalePymtDto.PymtType.Name);
                txtPaymentDescription.ReadOnly = isSalePayment(prUnitSalePymtDto.PymtType.Name) || isCancellationPayment(prUnitSalePymtDto.PymtType.Name);
            }
            else
            {
                drpPaymentType.ClearSelection();
                txtPaymentDate.Text = null;
                drpPaymentTo.ClearSelection();
                txtPaymentAmount.ReadOnly = false;
                txtPaymentDescription.ReadOnly = false;
            }
        }
        private void clearPaymentViewState()
        {
            if (paymentGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in paymentGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdPaymentSelect");
                    if (radioBtn != null) radioBtn.Checked = false;
                }
            }
            getCurrentSoldUnit().PrUnitSalePymts.ToList<PrUnitSalePymtDTO>().ForEach(c => c.isUISelected = false);
        }
        private void selectPrUnitSalePayment(PrUnitSalePymtDTO prUnitSalePymtDto)
        {
            if (paymentGrid.Rows.Count > 0)
            {
                prUnitSalePymtDto.isUISelected = true;
                foreach (GridViewRow row in paymentGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdPaymentSelect");
                    Button rowIdenBtn = (Button)row.FindControl("btnPaymentRowIdentifier");
                    radioBtn.Checked = false;
                    if (rowIdenBtn != null && prUnitSalePymtDto.UiIndex.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                    {
                        radioBtn.Checked = true;
                    }
                }
            }
        }
        private PrUnitSalePymtDTO getSelectedPrUnitSalePayment()
        {
            return getCurrentSoldUnit().PrUnitSalePymts.ToList<PrUnitSalePymtDTO>().Find(c => c.isUISelected);
        }

        private bool validatePaymentSelected()
        {
            bool isSelected = true;
            PrUnitSalePymtDTO prUnitSalePymtDto = getSelectedPrUnitSalePayment();
            if (prUnitSalePymtDto == null)
            {
                isSelected = false;
                pnlPaymentAdd.Visible = false;
                clearPaymentViewState();
                setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Payment"), tab2BzStep3Error);
            }
            return isSelected;
        }

        private PrUnitSalePymtDTO populatePrUnitSalePymtAdd()
        {
            PrUnitSalePymtDTO prUnitSalePymtDto = new PrUnitSalePymtDTO();
            UserDefinitionDTO userDef = getUserDefinitionDTO();
            prUnitSalePymtDto.FirmNumber = userDef.FirmNumber;
            prUnitSalePymtDto.InsertUser = userDef.Username;
            return prUnitSalePymtDto;
        }
        private void populatePrUnitSalePymtFromUI(PrUnitSalePymtDTO prUnitSalePymtDto, bool isAdd)
        {
            if (isAdd)
            {
                prUnitSalePymtDto.PymtType = CommonUIConverter.getMasterControlDTO(drpPaymentType.Text, drpPaymentType.SelectedItem.Text);
                prUnitSalePymtDto.PymtDate = CommonUtil.getCSDateNotNull(txtPaymentDate.Text);
                prUnitSalePymtDto.PymtTo = EnumHelper.ToEnum<PRUnitSalePymtTo>(drpPaymentTo.Text);
            }
            prUnitSalePymtDto.PymtAmt = CommonUtil.getDecimaNotNulllWithoutExt(txtPaymentAmount.Text);
            prUnitSalePymtDto.Description = txtPaymentDescription.Text;
            prUnitSalePymtDto.UpdateUser = getUserDefinitionDTO().Username;
        }
        private void addNewPymtMaster(PrUnitSalePymtDTO prUnitSalePymtDto)
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            PaymentMasterDTO paymentMasterDto = new PaymentMasterDTO();
            paymentMasterDto.TotalAmt = Decimal.Zero;
            paymentMasterDto.TotalPaid = Decimal.Zero;
            paymentMasterDto.TotalPending = Decimal.Zero;
            paymentMasterDto.TotalPdcAmt = Decimal.Zero;
            paymentMasterDto.FirmNumber = userDefDto.FirmNumber;
            paymentMasterDto.InsertUser = userDefDto.Username;
            prUnitSalePymtDto.PaymentMaster = paymentMasterDto;
            updatePymtMaster(prUnitSalePymtDto);
        }
        private void updatePymtMaster(PrUnitSalePymtDTO prUnitSalePymtDto)
        {
            PaymentMasterDTO paymentMasterDto = prUnitSalePymtDto.PaymentMaster;
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            decimal diffAmt = Decimal.Subtract(prUnitSalePymtDto.PymtAmt, paymentMasterDto.TotalAmt);
            paymentMasterDto.TotalAmt = Decimal.Add(paymentMasterDto.TotalAmt, diffAmt);
            paymentMasterDto.TotalPending = Decimal.Subtract(paymentMasterDto.TotalAmt, paymentMasterDto.TotalPaid);
            paymentMasterDto.UpdateUser = userDefDto.Username;
            if (paymentMasterDto.TotalPending > 0) paymentMasterDto.Status = PymtMasterStatus.Pending;
            else paymentMasterDto.Status = PymtMasterStatus.Paid;
        }

        protected void selectPayment(object sender, EventArgs e)
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            pnlPaymentAdd.Visible = false;
            if (rd.Checked)
            {
                long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnPaymentRowIdentifier"))).Attributes["row-identifier"]);
                List<PrUnitSalePymtDTO> pymtList = getCurrentSoldUnit().PrUnitSalePymts.ToList<PrUnitSalePymtDTO>();
                pymtList.ForEach(c => c.isUISelected = false);
                pymtList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
            }
        }
        protected void onClickAddPaymentBtn(object sender, EventArgs e)
        {
            try
            {
                clearPaymentViewState();
                initPaymentUpdateSection(true);
                initPaymentSectionFields(null);
                SetFocus(drpPaymentType);
                scrollToFieldHdn.Value = pnlPaymentAdd.ID;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2BzStep3Error);
            }
        }
        protected void onClickModifyPaymentsBtn(object sender, EventArgs e)
        {
            try
            {
                if (validatePaymentSelected())
                {
                    initPaymentUpdateSection(false);
                    initPaymentSectionFields(getSelectedPrUnitSalePayment());
                    SetFocus(drpPaymentType);
                    scrollToFieldHdn.Value = pnlPaymentAdd.ID;
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2BzStep3Error);
            }
        }
        protected void deleterPayments(object sender, EventArgs e)
        {
            try
            {
                if (validatePaymentSelected() && validateDeletePaymentType())
                {
                    PrUnitSaleDetailDTO prUnitSaleDetailDto = getCurrentSoldUnit();
                    PrUnitSalePymtDTO prUnitSalePymtDto = getSelectedPrUnitSalePayment();
                    if (prUnitSalePymtDto.PaymentMaster.Id > 0)
                    {
                        prUnitSalePymtDto.PaymentMaster.Status = PymtMasterStatus.Deleted;
                    }
                    else
                    {
                        prUnitSaleDetailDto.PrUnitSalePymts.Remove(prUnitSalePymtDto);
                    }
                    pnlPaymentAdd.Visible = false;
                    clearPaymentViewState();
                    populateSalePymtGrid(prUnitSaleDetailDto);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, "Payment"), tab2Anchor.ID, tab2BzStep3);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2BzStep3Error);
            }
        }
        protected void addNewPayment(object sender, EventArgs e)
        {
            try
            {
                if (validateMandatoryPymtField(false))
                {
                    PrUnitSaleDetailDTO prUnitSaleDetailDto = getCurrentSoldUnit();
                    PrUnitSalePymtDTO prUnitSalePymtDto = populatePrUnitSalePymtAdd();
                    populatePrUnitSalePymtFromUI(prUnitSalePymtDto, true);
                    addNewPymtMaster(prUnitSalePymtDto);
                    prUnitSaleDetailDto.PrUnitSalePymts.Add(prUnitSalePymtDto);
                    pnlPaymentAdd.Visible = false;
                    clearPaymentViewState();
                    populateSalePymtGrid(prUnitSaleDetailDto);
                    selectPrUnitSalePayment(prUnitSalePymtDto);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, "Payment"), tab2Anchor.ID, tab2BzStep3);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2BzStep3Error);
            }
        }
        protected void updatePayment(object sender, EventArgs e)
        {
            try
            {
                if (validateMandatoryPymtField(false) && validatePaymentUpdate())
                {
                    PrUnitSaleDetailDTO prUnitSaleDetailDto = getCurrentSoldUnit();
                    PrUnitSalePymtDTO prUnitSalePymtDto = getSelectedPrUnitSalePayment();
                    populatePrUnitSalePymtFromUI(prUnitSalePymtDto, false);
                    updatePymtMaster(prUnitSalePymtDto);
                    pnlPaymentAdd.Visible = false;
                    clearPaymentViewState();
                    populateSalePymtGrid(prUnitSaleDetailDto);
                    selectPrUnitSalePayment(prUnitSalePymtDto);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_updatedtotable, "Payment"), tab2Anchor.ID, tab2BzStep3);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2BzStep3Error);
            }
        }
        protected void cancelPayment(object sender, EventArgs e)
        {
            pnlPaymentAdd.Visible = false;
            clearPaymentViewState();
        }
        private bool validateMandatoryPymtField(bool isAdd)
        {
            bool isValid = true;
            if (isAdd)
            {
                Page.Validate(tab2BzStep3Error);
                isValid = Page.IsValid;
            }
            Page.Validate(tab2BzStep3Error1);
            isValid = Page.IsValid;
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        private bool validateDeletePaymentType()
        {
            bool isValid = true;
            PrUnitSalePymtDTO prUnitSalePymtDto = getSelectedPrUnitSalePayment();
            if (prUnitSalePymtDto.PaymentMaster.Status == PymtMasterStatus.Deleted)
            {
                setErrorMessage("Payment is already deleted.", tab2BzStep3Error);
                isValid = false;
            }
            else if (isSalePayment(prUnitSalePymtDto.PymtType.Name) || isCancellationPayment(prUnitSalePymtDto.PymtType.Name))
            {
                setErrorMessage("Deletion of selected Payment type is not allowed.", tab2BzStep3Error);
                isValid = false;
            }
            else if (prUnitSalePymtDto.PaymentMaster.TotalPaid > 0)
            {
                setErrorMessage("Part of the payment has been made, can not delete selected payment.", tab2BzStep3Error);
                isValid = false;
            }
            return isValid;
        }
        private bool validatePaymentUpdate()
        {
            bool isValid = true;
            PrUnitSalePymtDTO prUnitSalePymtDto = getSelectedPrUnitSalePayment();
            decimal pymtAmt = CommonUtil.getDecimaNotNulllWithoutExt(txtPaymentAmount.Text);
            decimal diffAmt = Decimal.Subtract(pymtAmt, prUnitSalePymtDto.PaymentMaster.TotalAmt);
            decimal effectiveAmt = Decimal.Add(prUnitSalePymtDto.PaymentMaster.TotalAmt, diffAmt);
            if (effectiveAmt.CompareTo(prUnitSalePymtDto.PaymentMaster.TotalPaid) < 0)
            {
                setErrorMessage("Payment amount can not be less than Total Paid amount.", tab2BzStep3Error);
                isValid = false;
            }
            return isValid;
        }
        private void populateDrpPaymentType(bool isAdd)
        {
            drpPaymentType.ClearSelection();
            foreach (ListItem item in drpAllPaymentType.Items)
            {
                if (isAdd && !(isSalePayment(item.Text) || isCancellationPayment(item.Text)))
                {
                    drpPaymentType.Items.Add(item);
                }
            }
        }
        private bool isSalePayment(string paymentType)
        {
            return Constants.MCD_SALE_PAYMENT.Equals(paymentType);
        }
        private bool isCancellationPayment(string paymentType)
        {
            return Constants.MCD_CANCELLATION_PAYMENT.Equals(paymentType);
        }
        //Payment Table actions - END
        //Modal save logic
        protected void saveModalData(object sender, EventArgs e)
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (modalHdnType.Value == "PR_UNIT_PYMT_TYPE")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_UNIT_PYMT_TYPE, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Sale Payment Type");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpPaymentType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_PYMT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }

            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                modalErrorMsg.Value = errorMsg;
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "setModalErrorMsg", "setModalErrorMsg()", true);
            }
            else
            {
                //Reset the modal fields
                modalInput1.Text = "";
                modalInput2.Text = "";
                modalHdnType.Value = "";
                modalActionHdn.Value = "";
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "closeDialogClient", "closeDialogClient()", true);
            }
        }
        private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
        {
            string errorMsg = "";
            if (string.IsNullOrWhiteSpace(masterDataDto.Name))
            {
                errorMsg = string.Format(Resources.Messages.validation_txtfield_required, type);
            }
            else if (masterDataBO.isAlreadyExist(masterDataDto))
            {
                errorMsg = string.Format(Resources.Messages.validation_same_name_exist, type);
            }
            return errorMsg;
        }
    }
}