﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Vladsm.Web.UI.WebControls;

namespace ConstroSoft.pages.EnquiryManagement
{
    public partial class TrackEnquiryFollowup : System.Web.UI.Page
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string tab1ValidationGrp = "tab1Error";
        string tab2ValidationGrp = "tab2Error";
        string VS_ENQUIRY_LIST = "ENQUIRY_LIST";
        string VS_SELECTED_ENQUIRY = "SELECTED_ENQUIRY";
        DropdownBO drpBO = new DropdownBO();
        EnquiryBO enquiryBO = new EnquiryBO();
        MasterDataBO masterDataBO = new MasterDataBO();
        EmployeeBO firmMemberBO = new EmployeeBO();
        protected void Page_Load(object sender, EventArgs e)
        {
            clearMessages();
            if (!IsPostBack)
            {
                if (Session[Constants.Session.USERNAME] != null)
                {
                    resetTabInfo(PageMode.NONE);
                    initDropdowns();
                    loadSearchGridAndReSelect(0);
                    Page.MaintainScrollPositionOnPostBack = false;
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
        }
        private void initDropdowns()
        {
            drpBO.drpEnum<EnquirySearchBy>(drpSearchBy, null);
        }
        /**
         * This method is called just before the page is rendered. So any change in state of the element is applied.
         **/
        protected void Page_PreRender(object sender, EventArgs e)
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        private bool isViewOnlyUser()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            bool isViewOnlyUser = !CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.ENQUIRY_ADD_UPDATE);
            return isViewOnlyUser;
        }
        private void applyEntitlement()
        {
            if (isViewOnlyUser())
            {

            }
        }
        private void preRenderInitFormElements()
        {
            EnquiryDetailDTO selectedEnquiry = getCurrentEnquiry();
            jumpToEnquiryHdnId.Value = null;
            jumpToFollowUpHdnId.Value = null;
            if (selectedEnquiry != null && selectedEnquiry.EnquiryFollowups != null)
            {
                jumpToEnquiryHdnId.Value = selectedEnquiry.Id.ToString();
                List<EnquiryFollowupDTO> enquiryFollowUpList = selectedEnquiry.EnquiryFollowups.ToList<EnquiryFollowupDTO>();
                if (enquiryFollowUpList != null && enquiryFollowUpList.Count > 0)
                {
                    EnquiryFollowupDTO selectedFollowup = enquiryFollowUpList.Find(a => a.isUISelected);
                    if (selectedFollowup != null) jumpToFollowUpHdnId.Value = selectedFollowup.UiIndex.ToString();
                }
            }
            if (PageMode.MODIFY.ToString() == pageModeHdn.Value)
            {
                populateEnquiryInfoSection(selectedEnquiry);
            }
        }
        public void setErrorMessage(string message, string group)
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            this.Page.Validators.Add(val);
        }

        public void setSuccessMessage(string msg, string tabId)
        {
            activeTabHdn.Value = tabId;
            if (tabId.Equals(tab1Anchor.ID))
            {
                lbTab1Success.Text = msg;
                tab1SuccessPanel.Visible = true;
            }
            else if (tabId.Equals(tab2Anchor.ID))
            {
                lbTab2Success.Text = msg;
                tab2SuccessPanel.Visible = true;
            }
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        public void initBootstrapComponantsFromServer()
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
        }
        private void clearMessages()
        {
            tab1SuccessPanel.Visible = false;
            lbTab1Success.Text = "";
            tab2SuccessPanel.Visible = false;
            lbTab2Success.Text = "";
        }
        private UserDefinitionDTO getUserDefinitionDTO()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }

        private void resetTabInfo(PageMode pageMode)
        {
            tab2Anchor.Visible = true;
            activeTabHdn.Value = tab2Anchor.ID;
            pageModeHdn.Value = pageMode.ToString();
            initFormFields();
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            pnlFollowUpAdd.Visible = false;
            if (PageMode.MODIFY == pageMode || PageMode.VIEW == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.enqm_sm_manage_enq_tab2_followup_name;
                initFormFields();
            }
            else
            {
                activeTabHdn.Value = tab1Anchor.ID;
                tab2Anchor.Visible = false;
                ViewState[VS_SELECTED_ENQUIRY] = null;
            }
        }
        private void initFormFields()
        {
            bool isReadOnly = (PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            bool visible = !(PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            //Buttons
            btnAddSubmit.Visible = visible;
            btnAddFollowUp.Visible = visible;
            btnModifyFollowUp.Visible = visible;
            btnDeleteFollowUp.Visible = visible;
            followUpGrid.Columns[0].Visible = visible;
        }
        private EnquiryDetailDTO getCurrentEnquiry()
        {
            return (EnquiryDetailDTO)ViewState[VS_SELECTED_ENQUIRY];
        }
        private void setSelectedEnquiry(long selectedId)
        {
            List<EnquiryDetailDTO> enquiryList = (List<EnquiryDetailDTO>)ViewState[VS_ENQUIRY_LIST];
            if (enquiryList != null)
            {
                enquiryList.ForEach(c => c.isUISelected = false);
                enquiryList.Find(c => c.Id == selectedId).isUISelected = true;
            }
        }
        private bool validateEnquirySelected()
        {
            bool isSelected = true;
            List<EnquiryDetailDTO> enquiryList = (List<EnquiryDetailDTO>)ViewState[VS_ENQUIRY_LIST];
            if (enquiryList != null)
            {
                isSelected = enquiryList.Any(c => c.isUISelected);
                if (!isSelected)
                {
                    resetTabInfo(PageMode.NONE);
                    setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Enquiry"), tab1ValidationGrp);
                }
            }
            return isSelected;
        }
        private void selectEnquiryGridRdBtn(long Id)
        {
            if (enquiryGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in enquiryGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdEnquirySelect");
                    Button rowIdenBtn = (Button)row.FindControl("btnEnqRowIdentifier");
                    if (radioBtn != null)
                    {
                        radioBtn.Checked = false;
                        if (rowIdenBtn != null && Id > 0 && Id.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                        {
                            radioBtn.Checked = true;
                        }
                    }
                }
            }
        }
        private void loadSearchGridAndReSelect(long Id)
        {
            try
            {
                EnquirySearchBy searchBy = EnumHelper.ToEnum<EnquirySearchBy>(drpSearchBy.Text);
                long searchByValId = -1;
                if (!string.IsNullOrWhiteSpace(drpSearchByValue.Text)) searchByValId = long.Parse(drpSearchByValue.Text);
                IList<EnquiryDetailDTO> results = enquiryBO.fetchEnquiryGridData(getUserDefinitionDTO().FirmNumber, searchBy, searchByValId);
                ViewState[VS_ENQUIRY_LIST] = results;
                enquiryGrid.DataSource = results;
                enquiryGrid.DataBind();
                if (Id > 0)
                {
                    selectEnquiryGridRdBtn(Id);
                    setSelectedEnquiry(Id);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void fetchSelectedEnquiry()
        {
            try
            {
                EnquiryDetailDTO enquiryDetailDto = null;
                if (PageMode.MODIFY.ToString().Equals(pageModeHdn.Value) || PageMode.VIEW.ToString().Equals(pageModeHdn.Value))
                {
                    long Id = ((List<EnquiryDetailDTO>)ViewState[VS_ENQUIRY_LIST]).Find(c => c.isUISelected).Id;
                    enquiryDetailDto = enquiryBO.fetchEnquiryDetails(Id);
                }
                ViewState[VS_SELECTED_ENQUIRY] = enquiryDetailDto;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void doViewModifyAction(PageMode pageMode)
        {
            resetTabInfo(pageMode);
            fetchSelectedEnquiry();
            populateUIFieldsFromDTO((EnquiryDetailDTO)ViewState[VS_SELECTED_ENQUIRY]);
        }
        protected void onSearchBy(object sender, EventArgs e)
        {
            try
            {
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                EnquirySearchBy searchBy = EnumHelper.ToEnum<EnquirySearchBy>(drpSearchBy.Text);
                drpSearchByValue.Visible = true;
                lbSearchByValue.Visible = true;
                lbSearchByValue.Text = EnumHelper.GetEnumDescription<EnquirySearchBy>(searchBy.ToString());
                if (EnquirySearchBy.CUSTOMER_NAME == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.ENQUIRY_CUSTOMER_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (EnquirySearchBy.PROP_LOCATION == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_LOCATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (EnquirySearchBy.PROP_TYPE == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (EnquirySearchBy.PROP_UNIT_TYPE == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (EnquirySearchBy.ENQUIRY_SOURCE == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ENQUIRY_SOURCE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (EnquirySearchBy.PROP_NAME == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.PROPERTY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (EnquirySearchBy.EMPLOYEE_NAME == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.EMPLOYEE_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else
                {
                    drpSearchByValue.ClearSelection();
                    drpSearchByValue.Visible = false;
                    lbSearchByValue.Visible = false;
                }
                loadSearchGridAndReSelect(0);
                resetTabInfo(PageMode.NONE);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onSearchByValue(object sender, EventArgs e)
        {
            loadSearchGridAndReSelect(0);
            resetTabInfo(PageMode.NONE);
        }
        protected void selectEnquiry(object sender, EventArgs e)
        {
            try
            {
                GroupRadioButton rd = (GroupRadioButton)sender;
                resetTabInfo(PageMode.NONE);
                if (rd.Checked)
                {
                    string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnEnqRowIdentifier"))).Attributes["row-identifier"];
                    setSelectedEnquiry(long.Parse(strId));
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        /*
         * This method is called on click of Show Follow-Up button in datatable top bar.
         */
        protected void onClickShowFollowUpBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateEnquirySelected())
                {
                    resetTabInfo(PageMode.MODIFY);
                    fetchSelectedEnquiry();
                    populateUIFieldsFromDTO((EnquiryDetailDTO)ViewState[VS_SELECTED_ENQUIRY]);
                    if (getCurrentEnquiry().Status == EnquiryStatus.Open)
                    {
                        btncloseenq.Visible = true;
                        btnopenenq.Visible = false;
                    }
                    else {
                        resetTabInfo(PageMode.VIEW);
                        btncloseenq.Visible = false;
                        btnopenenq.Visible = true;
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        protected void addOrModifyFollowUp(object sender, EventArgs e)
        {
            try
            {
                if (validateEnquiry())
                {
                    EnquiryDetailDTO enquirydetailDTO = getCurrentEnquiry();
                    long Id = enquirydetailDTO.Id;
                    if (PageMode.MODIFY.ToString().Equals(pageModeHdn.Value))
                    {
                        enquiryBO.updateEnquiryDetails(enquirydetailDTO);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_update, "Enquiry Follow-Up"), tab2Anchor.ID);
                    }
                    loadSearchGridAndReSelect(Id);
                    doViewModifyAction(PageMode.VIEW);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        private bool validateEnquiry()
        {
            bool isValid = true;
            Page.Validate("tab2Error");
            isValid = Page.IsValid;
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        protected void cancelEnquiry(object sender, EventArgs e)
        {
            EnquiryDetailDTO emquiryDetailDto = getCurrentEnquiry();
            resetTabInfo(PageMode.NONE);
            loadSearchGridAndReSelect(emquiryDetailDto.Id);
        }

        private void populateUIFieldsFromDTO(EnquiryDetailDTO enquiryDetailDTO)
        {
            if (enquiryDetailDTO != null && enquiryDetailDTO.Salutation != null) txtSalutation.Text = enquiryDetailDTO.Salutation.Name; else txtSalutation.Text = null;
            if (enquiryDetailDTO != null) txtFirstName.Text = enquiryDetailDTO.FirstName; else txtFirstName.Text = null;
            if (enquiryDetailDTO != null) txtMiddleName.Text = enquiryDetailDTO.MiddleName; else txtMiddleName.Text = null;
            if (enquiryDetailDTO != null) txtLastName.Text = enquiryDetailDTO.LastName; else txtLastName.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.ContactInfo.Gender != null) txtGender.Text = enquiryDetailDTO.ContactInfo.Gender.ToString(); else txtGender.Text = null;
            if (enquiryDetailDTO != null) txtContact.Text = enquiryDetailDTO.ContactInfo.Contact; else txtContact.Text = null;
            if (enquiryDetailDTO != null) txtAltContact.Text = enquiryDetailDTO.ContactInfo.AltContact; else txtAltContact.Text = null;
            if (enquiryDetailDTO != null) txtEmail.Text = enquiryDetailDTO.ContactInfo.Email; else txtEmail.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.EnquirySource != null) txtEnquirySource.Text = enquiryDetailDTO.EnquirySource.Name; else txtEnquirySource.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.PropertyType != null) txtPropertyType.Text = enquiryDetailDTO.PropertyType.Name; else txtPropertyType.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.PrUnitType != null) txtPropertyUnitType.Text = enquiryDetailDTO.PrUnitType.Name; else txtPropertyUnitType.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.EnquiryDate != null) txtDOE.Text = enquiryDetailDTO.EnquiryDate.Value.ToString(Constants.DATE_FORMAT); else txtDOE.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.FollowupDate != null) txtNextFollowupDate.Text = enquiryDetailDTO.FollowupDate.Value.ToString(Constants.DATE_FORMAT); else txtNextFollowupDate.Text = null;
            if (enquiryDetailDTO != null) txtBudget.Text = Convert.ToDecimal(enquiryDetailDTO.Budget).ToString(); else txtBudget.Text = null;
            if (enquiryDetailDTO != null) txtFirmMember.Text = enquiryDetailDTO.FirmMember.FirstName + " " + enquiryDetailDTO.FirmMember.LastName; else txtFirmMember.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.Status != null) txtStatus.Text = enquiryDetailDTO.Status.ToString(); else txtStatus.Text = null;

            populateFollowUpGrid(enquiryDetailDTO, true);
        }
        private void populateEnquiryInfoSection(EnquiryDetailDTO enquiryDetailDTO)
        {
            if (enquiryDetailDTO != null && enquiryDetailDTO.Salutation != null) txtSalutation.Text = enquiryDetailDTO.Salutation.Name; else txtSalutation.Text = null;
            if (enquiryDetailDTO != null) txtFirstName.Text = enquiryDetailDTO.FirstName; else txtFirstName.Text = null;
            if (enquiryDetailDTO != null) txtMiddleName.Text = enquiryDetailDTO.MiddleName; else txtMiddleName.Text = null;
            if (enquiryDetailDTO != null) txtLastName.Text = enquiryDetailDTO.LastName; else txtLastName.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.ContactInfo.Gender != null) txtGender.Text = enquiryDetailDTO.ContactInfo.Gender.ToString(); else txtGender.Text = null;
            if (enquiryDetailDTO != null) txtContact.Text = enquiryDetailDTO.ContactInfo.Contact; else txtContact.Text = null;
            if (enquiryDetailDTO != null) txtAltContact.Text = enquiryDetailDTO.ContactInfo.AltContact; else txtAltContact.Text = null;
            if (enquiryDetailDTO != null) txtEmail.Text = enquiryDetailDTO.ContactInfo.Email; else txtEmail.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.EnquirySource != null) txtEnquirySource.Text = enquiryDetailDTO.EnquirySource.Name; else txtEnquirySource.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.PropertyType != null) txtPropertyType.Text = enquiryDetailDTO.PropertyType.Name; else txtPropertyType.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.PrUnitType != null) txtPropertyUnitType.Text = enquiryDetailDTO.PrUnitType.Name; else txtPropertyUnitType.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.EnquiryDate != null) txtDOE.Text = enquiryDetailDTO.EnquiryDate.Value.ToString(Constants.DATE_FORMAT); else txtDOE.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.FollowupDate != null) txtNextFollowupDate.Text = enquiryDetailDTO.FollowupDate.Value.ToString(Constants.DATE_FORMAT); else txtNextFollowupDate.Text = null;
            if (enquiryDetailDTO != null) txtBudget.Text = Convert.ToDecimal(enquiryDetailDTO.Budget).ToString(); else txtBudget.Text = null;
            if (enquiryDetailDTO != null) txtFirmMember.Text = enquiryDetailDTO.FirmMember.FirstName + " " + enquiryDetailDTO.FirmMember.LastName; else txtFirmMember.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.Status != null) txtStatus.Text = enquiryDetailDTO.Status.ToString(); else txtStatus.Text = null;
        }

        private void populateFollowUpGrid(EnquiryDetailDTO enquiryDetailDto, bool appendName)
        {
            followUpGrid.DataSource = new List<EnquiryDetailDTO>();
            if (enquiryDetailDto != null && enquiryDetailDto.EnquiryFollowups != null)
            {
                assignUiIndexToFollowUp(enquiryDetailDto.EnquiryFollowups, appendName);
                followUpGrid.DataSource = enquiryDetailDto.EnquiryFollowups;
            }
            followUpGrid.DataBind();
        }
        private void assignUiIndexToFollowUp(ISet<EnquiryFollowupDTO> enquiryFollowupDTO, bool appendName)
        {
            if (enquiryFollowupDTO != null && enquiryFollowupDTO.Count > 0)
            {
                long uiIndex = 1;
                foreach (EnquiryFollowupDTO enqFollowupDTO in enquiryFollowupDTO)
                {
                    enqFollowupDTO.UiIndex = uiIndex++;
                    enqFollowupDTO.RowInfo = CommonUIConverter.getGridViewRowInfo(enqFollowupDTO);
                    if (appendName) enqFollowupDTO.FirmMember.FirstName = enqFollowupDTO.FirmMember.FirstName + " " + enqFollowupDTO.FirmMember.LastName;
                }
            }
        }


        //Followup Table actions - Start
        private void initFollowUpAddUpdateSection(bool isAdd)
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            lbAddUpdateSectionHeader.Text = (isAdd) ? Resources.Labels.label_sectionheader_add_followup : Resources.Labels.label_sectionheader_modify_followup;
            drpBO.drpDataBase(drpEmployeeName, DrpDataType.EMPLOYEE_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpContactType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ENQUIRY_MEDIA_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            pnlFollowUpAdd.Visible = true;
            btnFollowUpAddToGrid.Visible = isAdd;
            btnFollowUpUpdateToGrid.Visible = !isAdd;
        }
        private void initFollowUpSectionFields(EnquiryFollowupDTO enquiryFollowupDTO, EnquiryDetailDTO enquiryDetailDTO)
        {
            if (enquiryFollowupDTO != null && enquiryFollowupDTO.FirmMember != null) drpEmployeeName.Text = enquiryFollowupDTO.FirmMember.Id.ToString(); else drpEmployeeName.ClearSelection();
            if (enquiryFollowupDTO != null && enquiryFollowupDTO.FollowupDate != null)
            {
                txtFollowUpDate.Text = CommonUtil.getCSDate(enquiryFollowupDTO.FollowupDate);
                txtEnqNextFollowUpDate.Text = CommonUtil.getCSDate(enquiryDetailDTO.FollowupDate);
            }
            else
            {
                txtFollowUpDate.Text = CommonUtil.getCSDate(enquiryDetailDTO.FollowupDate);
                txtEnqNextFollowUpDate.Text = null;
            }
            if (enquiryFollowupDTO != null && enquiryFollowupDTO.CommunicationMedia != null) drpContactType.Text = enquiryFollowupDTO.CommunicationMedia.Id.ToString(); else drpContactType.ClearSelection();
            if (enquiryFollowupDTO != null) txtComment.Text = enquiryFollowupDTO.Comments; else txtComment.Text = null;
        }
        private void clearFollowUpViewState()
        {
            if (followUpGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in followUpGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdfollowUpSelect");
                    if (radioBtn != null) radioBtn.Checked = false;
                }
            }
            if (getCurrentEnquiry().EnquiryFollowups != null)
            {
                getCurrentEnquiry().EnquiryFollowups.ToList<EnquiryFollowupDTO>().ForEach(c => c.isUISelected = false);
            }
        }
        private EnquiryFollowupDTO getSelectedFollowUp()
        {
            EnquiryFollowupDTO enquiryFollowupDTO = null;
            if (getCurrentEnquiry().EnquiryFollowups != null)
            {
                enquiryFollowupDTO = getCurrentEnquiry().EnquiryFollowups.ToList<EnquiryFollowupDTO>().Find(c => c.isUISelected);
            }
            return enquiryFollowupDTO;
        }
        private bool validateFollowUpSelected()
        {
            bool isSelected = true;
            EnquiryFollowupDTO enquiryFollowupDTO = getSelectedFollowUp();
            if (enquiryFollowupDTO == null)
            {
                isSelected = false;
                pnlFollowUpAdd.Visible = false;
                clearFollowUpViewState();
                setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Follow-Up"), tab2ValidationGrp);
            }
            return isSelected;
        }

        private void populateFollowUpFromUI(EnquiryFollowupDTO enquiryFollowupDTO, EnquiryDetailDTO enquiryDetailDTO)
        {
            enquiryFollowupDTO.FirmMember = CommonUIConverter.getFirmMemberDTO(drpEmployeeName.Text, drpEmployeeName.SelectedItem.Text);
            if (!string.IsNullOrWhiteSpace(txtFollowUpDate.Text)) enquiryFollowupDTO.FollowupDate = DateTime.ParseExact(txtFollowUpDate.Text, Constants.DATE_FORMAT, CultureInfo.InvariantCulture); else enquiryFollowupDTO.FollowupDate = null;
            enquiryFollowupDTO.CommunicationMedia = CommonUIConverter.getMasterControlDTO(drpContactType.Text, drpContactType.SelectedItem.Text);
            if (!string.IsNullOrWhiteSpace(txtEnqNextFollowUpDate.Text)) enquiryDetailDTO.FollowupDate = DateTime.ParseExact(txtEnqNextFollowUpDate.Text, Constants.DATE_FORMAT, CultureInfo.InvariantCulture); else enquiryDetailDTO.FollowupDate = null;
            enquiryFollowupDTO.Comments = txtComment.Text;
        }
        protected void selectFollowUp(object sender, EventArgs e)
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            pnlFollowUpAdd.Visible = false;
            if (rd.Checked)
            {
                long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnFollowUpRowIdentifier"))).Attributes["row-identifier"]);
                List<EnquiryFollowupDTO> followUpList = getCurrentEnquiry().EnquiryFollowups.ToList<EnquiryFollowupDTO>();
                followUpList.ForEach(c => c.isUISelected = false);
                followUpList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
            }
        }
        protected void onClickAddFollowUpBtn(object sender, EventArgs e)
        {
            try
            {
                EnquiryDetailDTO enquiryDetailDTO = getCurrentEnquiry();
                initFollowUpAddUpdateSection(true);
                initFollowUpSectionFields(null, enquiryDetailDTO);
                SetFocus(drpEmployeeName);
                scrollToFieldHdn.Value = pnlFollowUpAdd.ID;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void onClickModifyFollowUpBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateFollowUpSelected())
                {
                    initFollowUpAddUpdateSection(false);
                    initFollowUpSectionFields(getSelectedFollowUp(), getCurrentEnquiry());
                    SetFocus(drpEmployeeName);
                    scrollToFieldHdn.Value = pnlFollowUpAdd.ID;
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void deleteFollowUp(object sender, EventArgs e)
        {
            try
            {
                if (validateFollowUpSelected())
                {
                    EnquiryDetailDTO enquiryDetailDTO = getCurrentEnquiry();
                    EnquiryFollowupDTO enquiryFollowupDTO = getSelectedFollowUp();
                    enquiryDetailDTO.EnquiryFollowups.Remove(enquiryFollowupDTO);
                    pnlFollowUpAdd.Visible = false;
                    clearFollowUpViewState();
                    populateFollowUpGrid(enquiryDetailDTO, false);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, "Enquiry Follow-Up"), tab2Anchor.ID);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void addNewFollowUp(object sender, EventArgs e)
        {
            try
            {
                if (validateFollowUp())
                {
                    EnquiryDetailDTO enquiryDetailDTO = getCurrentEnquiry();
                    EnquiryFollowupDTO enquiryFollowupDTO = new EnquiryFollowupDTO();
                    UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
                    populateFollowUpFromUI(enquiryFollowupDTO, enquiryDetailDTO);
                    enquiryFollowupDTO.FirmNumber = userDefDto.FirmNumber;
                    enquiryFollowupDTO.InsertUser = userDefDto.Username;
                    enquiryFollowupDTO.UpdateUser = userDefDto.Username;
                    if (enquiryDetailDTO.EnquiryFollowups == null)
                    {
                        enquiryDetailDTO.EnquiryFollowups = new HashSet<EnquiryFollowupDTO>();
                    }
                    enquiryDetailDTO.EnquiryFollowups.Add(enquiryFollowupDTO);
                    pnlFollowUpAdd.Visible = false;
                    clearFollowUpViewState();
                    populateFollowUpGrid(enquiryDetailDTO, false);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, "Enquiry Follow-Up"), tab2Anchor.ID);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void updateFollowUp(object sender, EventArgs e)
        {
            try
            {
                if (validateFollowUp())
                {
                    UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
                    EnquiryDetailDTO enquiryDetailDTO = getCurrentEnquiry();
                    EnquiryFollowupDTO enquiryFollowupDTO = getSelectedFollowUp();
                    populateFollowUpFromUI(enquiryFollowupDTO, enquiryDetailDTO);
                    enquiryFollowupDTO.UpdateUser = userDefDto.Username;
                    clearFollowUpViewState();
                    populateFollowUpGrid(enquiryDetailDTO, false);
                    pnlFollowUpAdd.Visible = false;
                    setSuccessMessage(string.Format(Resources.Messages.success_record_updatedtotable, "Enquiry Follow-Up"), tab2Anchor.ID);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void cancelFollowUp(object sender, EventArgs e)
        {
            EnquiryDetailDTO emquiryDetailDto = getCurrentEnquiry();
            resetTabInfo(PageMode.NONE);
            loadSearchGridAndReSelect(emquiryDetailDto.Id);
        }
        protected void cancelAddUpdateFollowup(object sender, EventArgs e)
        {
            pnlFollowUpAdd.Visible = false;
            clearFollowUpViewState();
        }

        private bool validateFollowUp()
        {
            bool isValid = true;
            Page.Validate("tab2ErrorGrid1");
            isValid = Page.IsValid;
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        //Address Table actions - END
        //Modal save logic
        protected void saveModalData(object sender, EventArgs e)
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();

            if (modalHdnType.Value == "COMMUNICATION_MEDIA")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.ENQUIRY_MEDIA_TYPE, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "COMMUNICATION_MEDIA");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpContactType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ENQUIRY_MEDIA_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            if (modalHdnType.Value == "CLOSE_ENQUIRY")
            {
                EnquiryDetailDTO enquiryDetailDTO = getCurrentEnquiry();
                enquiryBO.closeEnquiry(enquiryDetailDTO.Id, modalInput2.Text);
                long Id = enquiryDetailDTO.Id;
                setSuccessMessage(string.Format(Resources.Messages.success_record_update, "Enquiry"), tab2Anchor.ID);
                loadSearchGridAndReSelect(Id);
                btnopenenq.Visible = false;
                btncloseenq.Visible = false;
                doViewModifyAction(PageMode.VIEW);
            }
            if (modalHdnType.Value == "OPEN_ENQUIRY")
            {
                EnquiryDetailDTO enquiryDetailDTO = getCurrentEnquiry();
                enquiryBO.openEnquiry(enquiryDetailDTO.Id, modalInput2.Text);
                long Id = enquiryDetailDTO.Id;
                setSuccessMessage(string.Format(Resources.Messages.success_record_update, "Enquiry"), tab2Anchor.ID);
                loadSearchGridAndReSelect(Id);
                btnopenenq.Visible = false;
                btncloseenq.Visible = false;
                doViewModifyAction(PageMode.VIEW);
            }
            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                modalErrorMsg.Value = errorMsg;
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "setModalErrorMsg", "setModalErrorMsg()", true);
            }
            else
            {
                //Reset the modal fields
                modalInput1.Text = "";
                modalInput2.Text = "";
                modalHdnType.Value = "";
                modalActionHdn.Value = "";
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "closeDialogClient", "closeDialogClient()", true);
            }
        }

        private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
        {
            string errorMsg = "";
            if (string.IsNullOrWhiteSpace(masterDataDto.Name))
            {
                errorMsg = Resources.Messages.validation_designationname_required;
            }
            else if (masterDataBO.isAlreadyExist(masterDataDto))
            {
                errorMsg = string.Format(Resources.Messages.validation_same_name_exist, type);
            }
            return errorMsg;
        }
    }
}