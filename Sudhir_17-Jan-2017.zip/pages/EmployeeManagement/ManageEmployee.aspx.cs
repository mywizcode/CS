﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;

public partial class ManageEmployee : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string tab1ValidationGrp = "tab1Error";
    string tab2ValidationGrp = "tab2Error";
    string VS_EMPLOYEE_LIST = "EMPLOYEE_LIST";
    string VS_SELECTED_EMPLOYEE = "SELECTED_EMPLOYEE";
    DropdownBO drpBO = new DropdownBO();
    EmployeeBO employeeBO = new EmployeeBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    DepartmentBO departmentBO = new DepartmentBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (Session[Constants.Session.USERNAME] != null)
            {
                resetTabInfo(PageMode.NONE);
                initDropdowns();
                loadSearchGridAndReSelect(0);
                Page.MaintainScrollPositionOnPostBack = false;
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpSalutation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.SALUTATION, null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpDesignation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.DESIGNATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<EmployeeSearchBy>(drpSearchBy, null);
        drpBO.drpEnum<Gender>(drpGender, Constants.SELECT_ITEM);
        drpBO.drpEnum<MaritalStatus>(drpMaritalStatus, Constants.SELECT_ITEM);
        drpBO.drpDataBase(drpDepartment, DrpDataType.DEPARTMENT, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAddressCountry, DrpDataType.COUNTRY, null, null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAddressState, DrpDataType.STATE, Constants.DEFAULT_COUNTRY, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        initCityDrp(drpAddressCity, Constants.DEFAULT_STATE);
        drpBO.drpDataBase(drpAddressType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ADDRESS_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<PreferredAddress>(drpPreferredAddress, null);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        applyEntitlement();
        preRenderInitFormElements();
        initBootstrapComponantsFromServer();
    }
    private bool isViewOnlyUser()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        bool isViewOnlyUser = !CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.FIRM_MEMBER_ADD_UPDATE);
        return isViewOnlyUser;
    }
    private void applyEntitlement()
    {
        if (isViewOnlyUser())
        {
            btnAddEmployee.Visible = false;
            btnModifyEmployee.Visible = false;
            btnDeleteEmployee.Visible = false;
        }
    }
    private void preRenderInitFormElements()
    {
        FirmMemberDTO selectedEmployee = getCurrentEmployee();
        jumpToEmployeeHdnId.Value = null;
        jumpToAddressHdnId.Value = null;
        if (selectedEmployee != null)
        {
            jumpToEmployeeHdnId.Value = selectedEmployee.Id.ToString();
            List<AddressDTO> addressList = selectedEmployee.ContactInfo.Addresses.ToList<AddressDTO>();
            if (addressList != null && addressList.Count > 0)
            {
                AddressDTO selectedAddress = addressList.Find(a => a.isUISelected);
                if (selectedAddress != null) jumpToAddressHdnId.Value = selectedAddress.UiIndex.ToString();
            }
        }
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
    }

    public void setSuccessMessage(string msg, string tabId)
    {
        activeTabHdn.Value = tabId;
        if (tabId.Equals(tab1Anchor.ID))
        {
            lbTab1Success.Text = msg;
            tab1SuccessPanel.Visible = true;
        }
        else if (tabId.Equals(tab2Anchor.ID))
        {
            lbTab2Success.Text = msg;
            tab2SuccessPanel.Visible = true;
        }
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private void clearMessages()
    {
        tab1SuccessPanel.Visible = false;
        lbTab1Success.Text = "";
        tab2SuccessPanel.Visible = false;
        lbTab2Success.Text = "";
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }

    private void resetTabInfo(PageMode pageMode)
    {
        tab2Anchor.Visible = true;
        activeTabHdn.Value = tab2Anchor.ID;
        pageModeHdn.Value = pageMode.ToString();
        initFormFields();
        pnlAddressAdd.Visible = false;
        if (PageMode.ADD == pageMode)
        {
            tab2Anchor.Text = Resources.Labels.empm_sm_manage_emp_tab2_add_name;
            initFormFields();
        }
        else if (PageMode.MODIFY == pageMode)
        {
            tab2Anchor.Text = Resources.Labels.empm_sm_manage_emp_tab2_update_name;
            initFormFields();
        }
        else if (PageMode.VIEW == pageMode)
        {
            tab2Anchor.Text = Resources.Labels.empm_sm_manage_emp_tab2_view_name;
            initFormFields();
        }
        else
        {
            activeTabHdn.Value = tab1Anchor.ID;
            tab2Anchor.Visible = false;
            ViewState[VS_SELECTED_EMPLOYEE] = null;
        }
    }
    private void initFormFields()
    {
        bool isReadOnly = (PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
        bool visible = !(PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
        //Buttons
        btnAddSubmit.Visible = visible;
        addDepartmentBtn.Visible = visible;
        addDesignationBtn.Visible = visible;
        btnAddAddress.Visible = visible;
        btnModifyAddress.Visible = visible;
        btnDeleteAddress.Visible = visible;
        addressGrid.Columns[0].Visible = visible;
    }
    private FirmMemberDTO getCurrentEmployee()
    {
        return (FirmMemberDTO)ViewState[VS_SELECTED_EMPLOYEE];
    }
    private void setSelectedEmployee(long selectedId)
    {
        List<FirmMemberDTO> employeeList = (List<FirmMemberDTO>)ViewState[VS_EMPLOYEE_LIST];
        if (employeeList != null)
        {
            employeeList.ForEach(c => c.isUISelected = false);
            if (selectedId > 0) employeeList.Find(c => c.Id == selectedId).isUISelected = true;
        }
    }
    private bool validateEmployeeSelected()
    {
        bool isSelected = true;
        List<FirmMemberDTO> employeeList = (List<FirmMemberDTO>)ViewState[VS_EMPLOYEE_LIST];
        if (employeeList != null)
        {
            isSelected = employeeList.Any(c => c.isUISelected);
            if (!isSelected)
            {
                resetTabInfo(PageMode.NONE);
                setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Employee"), tab1ValidationGrp);
            }
        }
        return isSelected;
    }
    private void selectEmployeeGridRdBtn(long Id)
    {
        if (employeeGrid.Rows.Count > 0)
        {
            setSelectedEmployee(0);
            foreach (GridViewRow row in employeeGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdEmployeeSelect");
                Button rowIdenBtn = (Button)row.FindControl("btnEmpRowIdentifier");
                if (radioBtn != null)
                {
                    radioBtn.Checked = false;
                    if (rowIdenBtn != null && Id > 0 && Id.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                    {
                        radioBtn.Checked = true;
                        setSelectedEmployee(Id);
                    }
                }
            }
        }
    }
    private void loadSearchGridAndReSelect(long Id)
    {
        try
        {
            EmployeeSearchBy searchBy = EnumHelper.ToEnum<EmployeeSearchBy>(drpSearchBy.Text);
            long searchByValId = -1;
            if (!string.IsNullOrWhiteSpace(drpSearchByValue.Text)) searchByValId = long.Parse(drpSearchByValue.Text);
            IList<FirmMemberDTO> results = employeeBO.fetchEmployeeGridData(getUserDefinitionDTO().FirmNumber, searchBy, searchByValId);
            ViewState[VS_EMPLOYEE_LIST] = results;
            employeeGrid.DataSource = results;
            employeeGrid.DataBind();
            if (Id > 0)
            {
                selectEmployeeGridRdBtn(Id);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private void fetchSelectedEmployee()
    {
        try
        {
            FirmMemberDTO firmMemberDto = null;
            if (PageMode.ADD.ToString().Equals(pageModeHdn.Value))
            {
                firmMemberDto = populateEmployeeDTOAdd();
                selectEmployeeGridRdBtn(0);
            }
            else if (PageMode.MODIFY.ToString().Equals(pageModeHdn.Value) || PageMode.VIEW.ToString().Equals(pageModeHdn.Value))
            {
                long Id = ((List<FirmMemberDTO>)ViewState[VS_EMPLOYEE_LIST]).Find(c => c.isUISelected).Id;
                firmMemberDto = employeeBO.fetchEmployee(Id);
            }
            ViewState[VS_SELECTED_EMPLOYEE] = firmMemberDto;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private void doViewModifyAction(PageMode pageMode)
    {
        resetTabInfo(pageMode);
        fetchSelectedEmployee();
        populateUIFieldsFromDTO((FirmMemberDTO)ViewState[VS_SELECTED_EMPLOYEE]);
    }
    protected void onSearchBy(object sender, EventArgs e)
    {
        try
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            EmployeeSearchBy searchBy = EnumHelper.ToEnum<EmployeeSearchBy>(drpSearchBy.Text);
            drpSearchByValue.Visible = true;
            lbSearchByValue.Visible = true;
            lbSearchByValue.Text = EnumHelper.GetEnumDescription<EmployeeSearchBy>(searchBy.ToString());
            if (EmployeeSearchBy.EMPLOYEE_NAME == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.EMPLOYEE_SEARCH_BY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else if (EmployeeSearchBy.EMPLOYEE_ID == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.EMPLOYEE_SEARCH_BY_ID, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else if (EmployeeSearchBy.DEPARTMENT == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.DEPARTMENT, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else
            {
                drpSearchByValue.ClearSelection();
                drpSearchByValue.Visible = false;
                lbSearchByValue.Visible = false;
            }
            loadSearchGridAndReSelect(0);
            resetTabInfo(PageMode.NONE);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSearchByValue(object sender, EventArgs e)
    {
        loadSearchGridAndReSelect(0);
        resetTabInfo(PageMode.NONE);
    }
    protected void selectEmployee(object sender, EventArgs e)
    {
        try
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            resetTabInfo(PageMode.NONE);
            if (rd.Checked)
            {
                string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnEmpRowIdentifier"))).Attributes["row-identifier"];
                setSelectedEmployee(long.Parse(strId));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    /*
     * This method is called on click of ADD button in datatable top bar.
     */
    protected void onClickAddEmployeeBtn(object sender, EventArgs e)
    {
        try
        {
            resetTabInfo(PageMode.ADD);
            fetchSelectedEmployee();
            populateUIFieldsFromDTO(null);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickViewEmployeeBtn(object sender, EventArgs e)
    {
        try
        {
            if (validateEmployeeSelected())
            {
                doViewModifyAction(PageMode.VIEW);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickModifyEmployeeBtn(object sender, EventArgs e)
    {
        try
        {
            if (validateEmployeeSelected())
            {
                doViewModifyAction(PageMode.MODIFY);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void deleteEmployee(object sender, EventArgs e)
    {
        try
        {
            if (validateEmployeeSelected())
            {
                long Id = ((List<FirmMemberDTO>)ViewState[VS_EMPLOYEE_LIST]).Find(c => c.isUISelected).Id;
                employeeBO.deleteEmployee(Id);
                loadSearchGridAndReSelect(0);
                resetTabInfo(PageMode.NONE);
                setSuccessMessage(string.Format(Resources.Messages.success_record_delete, "Employee"), tab1Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void addOrModifyEmployee(object sender, EventArgs e)
    {
        try
        {
            FirmMemberDTO firmMemberDto = getCurrentEmployee();
            long Id = firmMemberDto.Id;
            populateEmployeeDTOFromUI(firmMemberDto);
            if (PageMode.ADD.ToString().Equals(pageModeHdn.Value))
            {
                Id = employeeBO.saveEmployee(firmMemberDto);
                setSuccessMessage(string.Format(Resources.Messages.success_record_add, "Employee"), tab2Anchor.ID);
            }
            else if (PageMode.MODIFY.ToString().Equals(pageModeHdn.Value))
            {
                employeeBO.updateEmployee(firmMemberDto);
                setSuccessMessage(string.Format(Resources.Messages.success_record_update, "Employee"), tab2Anchor.ID);
            }
            loadSearchGridAndReSelect(Id);
            doViewModifyAction(PageMode.VIEW);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    
    protected void cancelEmployee(object sender, EventArgs e)
    {
        FirmMemberDTO firmMemberDto = getCurrentEmployee();
        resetTabInfo(PageMode.NONE);
        loadSearchGridAndReSelect(firmMemberDto.Id);
    }
    
    private FirmMemberDTO populateEmployeeDTOAdd()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        FirmMemberDTO firmMemberDto = new FirmMemberDTO();
        firmMemberDto.ContactInfo = new ContactInfoDTO();
        firmMemberDto.ContactInfo.Addresses = new HashSet<AddressDTO>();
        firmMemberDto.FirmNumber = userDefDto.FirmNumber;
        firmMemberDto.InsertUser = userDefDto.Username;
        return firmMemberDto;
    }
    private void populateEmployeeDTOFromUI(FirmMemberDTO firmMemberDto)
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        firmMemberDto.Salutation = CommonUIConverter.getMasterControlDTO(drpSalutation.Text, null);
        firmMemberDto.FirstName = txtFirstName.Text;
        firmMemberDto.MiddleName = txtMiddleName.Text;
        firmMemberDto.LastName = txtLastName.Text;
        firmMemberDto.ContactInfo.Gender = EnumHelper.ToEnumNullable<Gender>(drpGender.Text);
        firmMemberDto.ContactInfo.Dob = DateTime.ParseExact(txtDOB.Text, Constants.DATE_FORMAT, CultureInfo.InvariantCulture);
        firmMemberDto.ContactInfo.MaritalStatus = EnumHelper.ToEnumNullable<MaritalStatus>(drpMaritalStatus.Text);
        firmMemberDto.ContactInfo.Contact = txtContact.Text;
        firmMemberDto.ContactInfo.AltContact = txtAltContact.Text;
        firmMemberDto.ContactInfo.Email = txtEmail.Text;

        firmMemberDto.Department = CommonUIConverter.getDepartmentDTO(drpDepartment.Text, null);
        if (!string.IsNullOrWhiteSpace(txtJoiningDate.Text)) firmMemberDto.JoiningDate = DateTime.ParseExact(txtJoiningDate.Text, Constants.DATE_FORMAT, CultureInfo.InvariantCulture); else firmMemberDto.JoiningDate = null;
        firmMemberDto.Designation = CommonUIConverter.getMasterControlDTO(drpDesignation.Text, null);
        firmMemberDto.Description = txtDescription.Text;
        firmMemberDto.Qualification = txtQualification.Text;
        firmMemberDto.UpdateUser = userDefDto.Username;
    }
    private void populateUIFieldsFromDTO(FirmMemberDTO firmMemberDto)
    {
        if (firmMemberDto != null && firmMemberDto.Salutation != null) drpSalutation.Text = firmMemberDto.Salutation.Id.ToString(); else drpSalutation.ClearSelection();
        if (firmMemberDto != null) txtFirstName.Text = firmMemberDto.FirstName; else txtFirstName.Text = null;
        if (firmMemberDto != null) txtMiddleName.Text = firmMemberDto.MiddleName; else txtMiddleName.Text = null;
        if (firmMemberDto != null) txtLastName.Text = firmMemberDto.LastName; else txtLastName.Text = null;
        if (firmMemberDto != null && firmMemberDto.ContactInfo.Gender != null) drpGender.Text = firmMemberDto.ContactInfo.Gender.ToString(); else drpGender.ClearSelection();
        if (firmMemberDto != null && firmMemberDto.ContactInfo.Dob != null) txtDOB.Text = firmMemberDto.ContactInfo.Dob.Value.ToString(Constants.DATE_FORMAT); else txtDOB.Text = null;
        if (firmMemberDto != null && firmMemberDto.ContactInfo.MaritalStatus != null) drpMaritalStatus.Text = firmMemberDto.ContactInfo.MaritalStatus.ToString(); else drpMaritalStatus.ClearSelection();
        if (firmMemberDto != null) txtContact.Text = firmMemberDto.ContactInfo.Contact; else txtContact.Text = null;
        if (firmMemberDto != null) txtAltContact.Text = firmMemberDto.ContactInfo.AltContact; else txtAltContact.Text = null;
        if (firmMemberDto != null) txtEmail.Text = firmMemberDto.ContactInfo.Email; else txtEmail.Text = null;

        if (firmMemberDto != null && firmMemberDto.Department != null) drpDepartment.Text = firmMemberDto.Department.Id.ToString(); else drpDepartment.ClearSelection();
        if (firmMemberDto != null && firmMemberDto.JoiningDate != null) txtJoiningDate.Text = firmMemberDto.JoiningDate.Value.ToString(Constants.DATE_FORMAT); else txtJoiningDate.Text = null;
        if (firmMemberDto != null && firmMemberDto.Designation != null) drpDesignation.Text = firmMemberDto.Designation.Id.ToString(); else drpDesignation.ClearSelection();
        if (firmMemberDto != null) txtDescription.Text = firmMemberDto.Description; else txtDescription.Text = null;
        if (firmMemberDto != null) txtQualification.Text = firmMemberDto.Qualification; else txtQualification.Text = null;
        if (firmMemberDto != null) txtEmployeeId.Text = firmMemberDto.EmployeeId; else txtEmployeeId.Text = null;

        populateAddressGrid(firmMemberDto);
    }
    private void populateAddressGrid(FirmMemberDTO firmMemberDto)
    {
        addressGrid.DataSource = new List<AddressDTO>();
        if (firmMemberDto != null)
        {
            assignUiIndexToAddress(firmMemberDto.ContactInfo.Addresses);
            addressGrid.DataSource = firmMemberDto.ContactInfo.Addresses;
        }
        addressGrid.DataBind();
    }
    private void assignUiIndexToAddress(ISet<AddressDTO> addressDtos)
    {
        if (addressDtos != null && addressDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (AddressDTO addressDto in addressDtos)
            {
                addressDto.UiIndex = uiIndex++;
                addressDto.RowInfo = CommonUIConverter.getGridViewRowInfo(addressDto);
            }
        }
    }

    //Modal save logic
    protected void saveModalData(object sender, EventArgs e)
    {
        String errorMsg = "";
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        if (modalHdnType.Value == "DEPARTMENT")
        {
            DepartmentDTO departmentDto = CommonUIConverter.populateDepartmentDTOAdd(modalInput1.Text,
                     modalInput2.Text, userDefDto);
            errorMsg = validateDepartmentModalInput(departmentDto);
            if (string.IsNullOrWhiteSpace(errorMsg))
            {
                departmentBO.saveDepartment(departmentDto);
                drpBO.drpDataBase(drpDepartment, DrpDataType.DEPARTMENT, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                modalIdentifierHdn.Value = "";
            }
        }
        else if (modalHdnType.Value == "DESIGNATION")
        {
            MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.DESIGNATION, modalInput1.Text,
                   modalInput2.Text, userDefDto);
            errorMsg = validateMasterDataModalInput(masterDataDto, "Designation");
            if (string.IsNullOrWhiteSpace(errorMsg))
            {
                masterDataBO.saveMasterData(masterDataDto);
                drpBO.drpDataBase(drpDesignation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.DESIGNATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                modalIdentifierHdn.Value = "";
            }
        }

        if (!string.IsNullOrWhiteSpace(errorMsg))
        {
            modalErrorMsg.Value = errorMsg;
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "setModalErrorMsg", "setModalErrorMsg()", true);
        }
        else
        {
            //Reset the modal fields
            modalInput1.Text = "";
            modalInput2.Text = "";
            modalHdnType.Value = "";
            modalActionHdn.Value = "";
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "closeDialogClient", "closeDialogClient()", true);
        }
    }
    private string validateDepartmentModalInput(DepartmentDTO departmentDto)
    {
        string errorMsg = "";
        if (string.IsNullOrWhiteSpace(departmentDto.Name))
        {
            errorMsg = Resources.Messages.validation_departmentname_required;
        }
        else if (departmentBO.isAlreadyExist(departmentDto))
        {
            errorMsg = string.Format(Resources.Messages.validation_same_name_exist, "Department");
        }
        return errorMsg;
    }
    private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
    {
        string errorMsg = "";
        if (string.IsNullOrWhiteSpace(masterDataDto.Name))
        {
            errorMsg = Resources.Messages.validation_designationname_required;
        }
        else if (masterDataBO.isAlreadyExist(masterDataDto))
        {
            errorMsg = string.Format(Resources.Messages.validation_same_name_exist, type);
        }
        return errorMsg;
    }
    //Address Table actions - Start
    private void initAddressAddUpdateSection(bool isAdd)
    {
        lbAddUpdateSectionHeader.Text = (isAdd) ? Resources.Labels.label_sectionheader_add_address : Resources.Labels.label_sectionheader_modify_address;
        pnlAddressAdd.Visible = true;
        btnAddressAddToGrid.Visible = isAdd;
        btnAddressUpdateToGrid.Visible = !isAdd;
        drpAddressState.Text = Constants.DEFAULT_STATE;
    }
    private void setDefaultOnAddAddress()
    {
        drpAddressState.Text = Constants.DEFAULT_STATE;
        drpPreferredAddress.Text = PreferredAddress.No.ToString();
    }
    private void initAddressSectionFields(AddressDTO addressDto)
    {
        if (addressDto != null) txtAddressLine1.Text = addressDto.AddressLine1; else txtAddressLine1.Text = null;
        if (addressDto != null) txtAddressLine2.Text = addressDto.AddressLine2; else txtAddressLine2.Text = null;
        if (addressDto != null) txtTown.Text = addressDto.Town; else txtTown.Text = null;
        if (addressDto != null && addressDto.City != null) drpAddressCity.Text = addressDto.City.Id.ToString(); else drpAddressCity.ClearSelection();
        if (addressDto != null && addressDto.State != null) drpAddressState.Text = addressDto.State.Id.ToString(); else drpAddressState.ClearSelection();
        if (addressDto != null && addressDto.Country != null) drpAddressCountry.Text = addressDto.Country.Id.ToString(); else drpAddressCountry.ClearSelection();
        if (addressDto != null) txtPin.Text = addressDto.Pin; else txtPin.Text = null;
        if (addressDto != null && addressDto.AddressType != null) drpAddressType.Text = addressDto.AddressType.Id.ToString(); else drpAddressType.ClearSelection();
        if (addressDto != null && addressDto.PreferredAddress != null) drpPreferredAddress.Text = addressDto.PreferredAddress.ToString(); else drpPreferredAddress.ClearSelection();
    }
    private void clearAddressViewState()
    {
        if (addressGrid.Rows.Count > 0)
        {
            foreach (GridViewRow row in addressGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdAddressSelect");
                if (radioBtn != null) radioBtn.Checked = false;
            }
        }
        getCurrentEmployee().ContactInfo.Addresses.ToList<AddressDTO>().ForEach(c => c.isUISelected = false);
    }
    private AddressDTO getSelectedAddress()
    {
        return getCurrentEmployee().ContactInfo.Addresses.ToList<AddressDTO>().Find(c => c.isUISelected);
    }
    private void initCityDrp(DropDownList drp, string stateId)
    {
        drpBO.drpDataBase(drp, DrpDataType.CITY, stateId, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
    }
    private bool validateAddressSelected()
    {
        bool isSelected = true;
        AddressDTO addressDto = getSelectedAddress();
        if (addressDto == null)
        {
            isSelected = false;
            pnlAddressAdd.Visible = false;
            clearAddressViewState();
            setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Address"), tab2ValidationGrp);
        }
        return isSelected;
    }

    private void populateAddressFromUI(AddressDTO addressDto)
    {
        addressDto.AddressLine1 = txtAddressLine1.Text;
        addressDto.AddressLine2 = txtAddressLine2.Text;
        addressDto.Town = txtTown.Text;
        addressDto.City = CommonUIConverter.getCityDTO(drpAddressCity.Text, drpAddressCity.SelectedItem.Text);
        addressDto.State = CommonUIConverter.getStateDTO(drpAddressState.Text, drpAddressState.SelectedItem.Text);
        addressDto.Country = CommonUIConverter.getCountryDTO(drpAddressCountry.Text, drpAddressCountry.SelectedItem.Text);
        addressDto.Pin = txtPin.Text;
        addressDto.AddressType = CommonUIConverter.getMasterControlDTO(drpAddressType.Text, drpAddressType.SelectedItem.Text);
        addressDto.PreferredAddress = EnumHelper.ToEnumNullable<PreferredAddress>(drpPreferredAddress.Text);
    }
    protected void loadCities(object sender, EventArgs e)
    {
        initCityDrp(drpAddressCity, drpAddressState.Text);
        SetFocus(drpAddressCity);
    }
    protected void selectAddress(object sender, EventArgs e)
    {
        GroupRadioButton rd = (GroupRadioButton)sender;
        pnlAddressAdd.Visible = false;
        if (rd.Checked)
        {
            long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnAddressRowIdentifier"))).Attributes["row-identifier"]);
            List<AddressDTO> addressList = getCurrentEmployee().ContactInfo.Addresses.ToList<AddressDTO>();
            addressList.ForEach(c => c.isUISelected = false);
            addressList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
        }
    }
    protected void onClickAddAddressBtn(object sender, EventArgs e)
    {
        try
        {
            initAddressAddUpdateSection(true);
            initAddressSectionFields(null);
            setDefaultOnAddAddress();
            SetFocus(txtAddressLine1);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void onClickModifyAddressBtn(object sender, EventArgs e)
    {
        try
        {
            if (validateAddressSelected())
            {
                initAddressAddUpdateSection(false);
                initAddressSectionFields(getSelectedAddress());
                SetFocus(txtAddressLine1);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void deleteAddress(object sender, EventArgs e)
    {
        try
        {
            if (validateAddressSelected())
            {
                FirmMemberDTO firmMemberDto = getCurrentEmployee();
                AddressDTO addressDto = getSelectedAddress();
                firmMemberDto.ContactInfo.Addresses.Remove(addressDto);
                pnlAddressAdd.Visible = false;
                clearAddressViewState();
                populateAddressGrid(firmMemberDto);
                setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, "Address"), tab2Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void addNewAddress(object sender, EventArgs e)
    {
        try
        {
            if (validateAddress())
            {
                FirmMemberDTO firmMemberDto = getCurrentEmployee();
                AddressDTO addressDto = new AddressDTO();
                populateAddressFromUI(addressDto);
                firmMemberDto.ContactInfo.Addresses.Add(addressDto);
                pnlAddressAdd.Visible = false;
                clearAddressViewState();
                populateAddressGrid(firmMemberDto);
                setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, "Address"), tab2Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void updateAddress(object sender, EventArgs e)
    {
        try
        {
            if (validateAddress())
            {
                FirmMemberDTO firmMemberDto = getCurrentEmployee();
                AddressDTO addressDto = getSelectedAddress();
                populateAddressFromUI(addressDto);
                pnlAddressAdd.Visible = false;
                clearAddressViewState();
                populateAddressGrid(firmMemberDto);
                setSuccessMessage(string.Format(Resources.Messages.success_record_updatedtotable, "Address"), tab2Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void cancelAddress(object sender, EventArgs e)
    {
        pnlAddressAdd.Visible = false;
        clearAddressViewState();
    }
    private bool validateAddress()
    {
        bool isValid = true;
        if (drpPreferredAddress.Text.Equals(PreferredAddress.Yes.ToString()))
        {
            List<AddressDTO> addressList = getCurrentEmployee().ContactInfo.Addresses.ToList<AddressDTO>();
            bool isPreferred = addressList.Any(c => (c.PreferredAddress == PreferredAddress.Yes && !c.isUISelected));
            if (isPreferred)
            {
                isValid = false;
                setErrorMessage(Resources.Messages.validation_address_one_preferred, tab2ValidationGrp);
            }
        }
        return isValid;
    }
    //Address Table actions - END
}
