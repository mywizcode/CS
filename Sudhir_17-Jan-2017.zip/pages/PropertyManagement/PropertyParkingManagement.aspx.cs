﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Vladsm.Web.UI.WebControls;

namespace ConstroSoft.pages.PropertyManagement
{
    public partial class PropertyParkingManagement : System.Web.UI.Page
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string tab1ValidationGrp = "tab1Error";
        string VS_PR_PARKING_LIST = "PR_PARKING_LIST";
        DropdownBO drpBO = new DropdownBO();
        PropertyBO propertyBO = new PropertyBO();
        MasterDataBO masterDataBO = new MasterDataBO();
        protected void Page_Load(object sender, EventArgs e)
        {
            clearMessages();
            if (!IsPostBack)
            {
                if (Session[Constants.Session.USERNAME] != null)
                {
                    resetPageInfo(PageMode.NONE);
                    initDropdowns();
                    Page.MaintainScrollPositionOnPostBack = false;
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
        }
        private void initDropdowns()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            drpBO.drpDataBase(drpSelectProperty, DrpDataType.PROPERTY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpParkingType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_PARKING_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpEnum<CommonParking>(drp_commonparking, null);//Constants.SELECT_ITEM);
            drpBO.drpEnum<ParkingStatus>(drpStatus, null);
        }
        /**
         * This method is called just before the page is rendered. So any change in state of the element is applied.
         **/
        protected void Page_PreRender(object sender, EventArgs e)
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        private bool isViewOnlyUser()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            bool isViewOnlyUser = !CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.FIRM_MEMBER_ADD_UPDATE);
            return isViewOnlyUser;
        }
        private void applyEntitlement()
        {
            if (isViewOnlyUser())
            {
                resetPageInfo(PageMode.VIEW);
            }
        }

        private void preRenderInitFormElements()
        {
            jumpToPropertyParkingHdnId.Value = "";
            PropertyParkingDTO propertyParkingDTO = getSelectedPropertyParking();
            if (propertyParkingDTO != null)
            {
                jumpToPropertyParkingHdnId.Value = propertyParkingDTO.UiIndex + "";
            }
        }
        public void setErrorMessage(string message, string group)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }

        public void setSuccessMessage(string msg)
        {
            lbTab1Success.Text = msg;
            tab1SuccessPanel.Visible = true;
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        public void initBootstrapComponantsFromServer()
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
        }
        private void clearMessages()
        {
            tab1SuccessPanel.Visible = false;
            lbTab1Success.Text = "";
        }
        private UserDefinitionDTO getUserDefinitionDTO()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }

        private void resetPageInfo(PageMode pageMode)
        {
            pageModeHdn.Value = pageMode.ToString();
            initFormFields();
            pnlPropertyParkingAdd.Visible = false;
            if (PageMode.NONE == pageMode)
            {
                pnlPropertyParkingGrid.Visible = false;
                ViewState[VS_PR_PARKING_LIST] = new List<PropertyParkingDTO>();
            }
            else
            {
                pnlPropertyParkingGrid.Visible = true;
            }
        }
        private void initFormFields()
        {
            bool isReadOnly = (PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            bool visible = !(PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            //Buttons
            btnAddSubmit.Visible = visible;
            btnAddPropertyParking.Visible = visible;
            btnModifyPropertyParking.Visible = visible;
            btndeletePropertyParking.Visible = visible;
            propertyParkingGrid.Columns[0].Visible = visible;
        }
        private List<PropertyParkingDTO> getPropertyParkingList()
        {
            return (List<PropertyParkingDTO>)ViewState[VS_PR_PARKING_LIST];
        }
        private PropertyParkingDTO getSelectedPropertyParking()
        {
            PropertyParkingDTO selectedParking = null;
            List<PropertyParkingDTO> prParkingList = getPropertyParkingList();
            if (prParkingList != null && prParkingList.Count !=0)
            {
                selectedParking = prParkingList.Find(c => c.isUISelected);
            }
            return selectedParking;
        }
        private void setSelectedPropertyParking(long selectedUiIndex)
        {
            List<PropertyParkingDTO> prParkingList = getPropertyParkingList();
            if (prParkingList != null)
            {
                prParkingList.ForEach(c => c.isUISelected = false);
                if (selectedUiIndex != -1) prParkingList.Find(c => c.UiIndex == selectedUiIndex).isUISelected = true;
            }
        }
        private void initPropertyParkingAddUpdateSection(bool isAdd)
        {
            lbPropertyParkingAddUpdateSectionHeader.Text = (isAdd) ? Resources.Labels.label_sectionheader_property_parkingadd : Resources.Labels.label_sectionheader_propertyparking_modify;
            pnlPropertyParkingAdd.Visible = true;
            btnPropertyParkingAddToGrid.Visible = isAdd;
            btnPropertyParkingUpdateToGrid.Visible = !isAdd;
        }
        private void setDefaultOnAddPropertyTower()
        {

        }
        private void initPropertyParkingSectionFields(PropertyParkingDTO PropertyParkingDTO)
        {
            if (PropertyParkingDTO != null && PropertyParkingDTO.ParkingType != null) drpParkingType.Text = PropertyParkingDTO.ParkingType.Id.ToString(); else drpParkingType.ClearSelection(); ;
            if (PropertyParkingDTO != null) txtParkingNo.Text = PropertyParkingDTO.ParkingNo; else txtParkingNo.Text = null;
            if (PropertyParkingDTO != null) txtArea.Text = PropertyParkingDTO.Area.ToString(); else txtArea.Text = null;
            if (PropertyParkingDTO != null) drp_commonparking.Text = PropertyParkingDTO.CommonParking.ToString(); else drp_commonparking.ClearSelection();
            if (PropertyParkingDTO != null) drpStatus.Text = PropertyParkingDTO.Status.ToString(); else drpStatus.ClearSelection();
        }
        private void resetPropertyParkingSelection(long uiIndex)
        {
            if (propertyParkingGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in propertyParkingGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdPropertyParkingSelect");
                    radioBtn.Checked = false;
                    if (uiIndex > 0)
                    {
                        Button rowIdenBtn = (Button)row.FindControl("btnPropertyParkingRowIdentifier");
                        if (rowIdenBtn != null && uiIndex.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                        {
                            radioBtn.Checked = true;
                            setSelectedPropertyParking(uiIndex);
                        }
                    }
                }
            }
            if (uiIndex <= 0) setSelectedPropertyParking(-1);
        }
        private bool validatePropertyParkingSelected()
        {
            bool isSelected = true;
            PropertyParkingDTO selectedParking = getSelectedPropertyParking();
            if (selectedParking == null)
            {
                isSelected = false;
                setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Parking"), tab1ValidationGrp);
            }
            return isSelected;
        }
        private void reBindPropertyParkingGrid(List<PropertyParkingDTO> prParkingList, PropertyParkingDTO propertyParkingDto)
        {
            if (prParkingList != null)
            {
                assignUiIndexToPropertyParking(prParkingList);
                propertyParkingGrid.DataSource = prParkingList;
                propertyParkingGrid.DataBind();
                if (propertyParkingDto != null) resetPropertyParkingSelection(propertyParkingDto.UiIndex);
            }
        }
        private void assignUiIndexToPropertyParking(List<PropertyParkingDTO> prParkingDtos)
        {
            if (prParkingDtos != null && prParkingDtos.Count > 0)
            {
                prParkingDtos.ForEach(c => c.isUISelected = false);
                long uiIndex = 1;
                foreach (PropertyParkingDTO prParkingDto in prParkingDtos)
                {
                    prParkingDto.UiIndex = uiIndex++;
                    prParkingDto.RowInfo = CommonUIConverter.getGridViewRowInfo(prParkingDto);
                }
            }
        }
        private void loadPropertyParkingGrid()
        {
            try
            {
                List<PropertyParkingDTO> results = new List<PropertyParkingDTO>();
                if (!(string.IsNullOrWhiteSpace(drpSelectProperty.Text) || string.IsNullOrWhiteSpace(drpSelectPropertyTower.Text)))
                {
                    long towerId = long.Parse(drpSelectPropertyTower.Text);
                    results = propertyBO.fetchPropertyParking(getUserDefinitionDTO().FirmNumber, towerId);
                    assignUiIndexToPropertyParking(results);
                }
                ViewState[VS_PR_PARKING_LIST] = results;
                propertyParkingGrid.DataSource = results;
                propertyParkingGrid.DataBind();
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void saveModalData(object sender, EventArgs e)
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (modalHdnType.Value == "PARKINGTYPE")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_PARKING_TYPE, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "PARKINGTYPE");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpParkingType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_PARKING_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                modalErrorMsg.Value = errorMsg;
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "setModalErrorMsg", "setModalErrorMsg()", true);
            }
            else
            {
                //Reset the modal fields
                modalInput1.Text = "";
                modalInput2.Text = "";
                modalHdnType.Value = "";
                modalActionHdn.Value = "";
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "closeDialogClient", "closeDialogClient()", true);
            }
        }
        private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
        {
            string errorMsg = "";
            if (string.IsNullOrWhiteSpace(masterDataDto.Name))
            {
                errorMsg = Resources.Messages.validation_designationname_required;
            }
            else if (masterDataBO.isAlreadyExist(masterDataDto))
            {
                errorMsg = string.Format(Resources.Messages.validation_same_name_exist, type);
            }
            return errorMsg;
        }
        protected void onSelectProperty(object sender, EventArgs e)
        {
            try
            {
                resetPageInfo(PageMode.NONE);
                lbSearchByValue.Visible = true;
                drpSelectPropertyTower.Visible = true;
                drpBO.drpDataBase(drpSelectPropertyTower, DrpDataType.PROPERTY_TOWER, drpSelectProperty.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
                if (drpSelectPropertyTower.Items.Count == 2)
                {
                    drpSelectPropertyTower.Items[1].Selected = true;
                    resetPageInfo(PageMode.ADD);
                    loadPropertyParkingGrid();
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onSelectPropertyTower(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(drpSelectPropertyTower.Text))
                {
                    resetPageInfo(PageMode.ADD);
                    loadPropertyParkingGrid();
                }
                else
                {
                    resetPageInfo(PageMode.NONE);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onSelectPropertyParking(object sender, EventArgs e)
        {
            try
            {
                GroupRadioButton rd = (GroupRadioButton)sender;
                pnlPropertyParkingAdd.Visible = false;
                lbSearchByValue.Visible = true;
                drpSelectPropertyTower.Visible = true;
                if (rd.Checked)
                {
                    long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnPropertyParkingRowIdentifier"))).Attributes["row-identifier"]);
                    setSelectedPropertyParking(UiIndex);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickAddPropertyParkingBtn(object sender, EventArgs e)
        {
            try
            {
                resetPropertyParkingSelection(-1);
                initPropertyParkingAddUpdateSection(true);
                initPropertyParkingSectionFields(null);
                SetFocus(drpParkingType);
                scrollToFieldHdn.Value = pnlPropertyParkingAdd.ID;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickModifyPropertyParkingBtn(object sender, EventArgs e)
        {
            try
            {
                if (validatePropertyParkingSelected())
                {
                    initPropertyParkingAddUpdateSection(false);
                    initPropertyParkingSectionFields(getSelectedPropertyParking());
                    SetFocus(drpParkingType);
                    scrollToFieldHdn.Value = pnlPropertyParkingAdd.ID;
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void deletePropertyParking(object sender, EventArgs e)
        {
            try
            {
                if (validatePropertyParkingSelected())
                {
                    List<PropertyParkingDTO> prParkingList = getPropertyParkingList();
                    PropertyParkingDTO PropertyParkingDto = getSelectedPropertyParking();
                    prParkingList.Remove(PropertyParkingDto);
                    reBindPropertyParkingGrid(prParkingList, null);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, "Parking"));
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void addNewPropertyParking(object sender, EventArgs e)
        {
            try
            {
                if (validatePropertyParking())
                {
                    PropertyParkingDTO propertyparkingDto = populatePropertyParkingDTOAddFromUI();
                    List<PropertyParkingDTO> prParkingList = getPropertyParkingList();
                    if (validateParkingNumber(propertyparkingDto, prParkingList))
                    {
                        prParkingList.Add(propertyparkingDto);
                        pnlPropertyParkingAdd.Visible = false;
                        reBindPropertyParkingGrid(prParkingList, propertyparkingDto);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, "Parking"));
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        private bool validateParkingNumber(PropertyParkingDTO propertyparkingDto, List<PropertyParkingDTO> prParkingList)
        {
            bool isValid = true;
            int index = prParkingList.FindIndex(item => item.ParkingNo == propertyparkingDto.ParkingNo);
            if (index >= 0)
            {
                setErrorMessage(Resources.Messages.validation_property_parking_number, tab1ValidationGrp);
                isValid = false;
            }
            return isValid;
        }

        private bool validateModifyParkingNumber(PropertyParkingDTO propertyparkingDto, List<PropertyParkingDTO> prParkingList)
        {
            bool isValid = true;
            int index = prParkingList.FindIndex(item => (item.ParkingNo == propertyparkingDto.ParkingNo) && (item.Id != propertyparkingDto.Id));
            if (index >= 0)
            {
                setErrorMessage(Resources.Messages.validation_property_parking_number, tab1ValidationGrp);
                isValid = false;
            }
            return isValid;
        }

        protected void updatePropertyParking(object sender, EventArgs e)
        {
            try
            {
                if (validatePropertyParking())
                {
                    PropertyParkingDTO propertyParkingeDto = getSelectedPropertyParking();
                    populatePropertyParkingFromUI(propertyParkingeDto);
                    if (validateModifyParkingNumber(propertyParkingeDto, getPropertyParkingList()))
                    {
                        pnlPropertyParkingAdd.Visible = false;
                        reBindPropertyParkingGrid(getPropertyParkingList(), propertyParkingeDto);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_updatedtotable, "Parking"));
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void cancelPropertyParking(object sender, EventArgs e)
        {
            pnlPropertyParkingAdd.Visible = false;
            resetPropertyParkingSelection(-1);
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        protected void savePropertyParkingToDB(object sender, EventArgs e)
        {
            try
            {
                List<PropertyParkingDTO> prParkingList = getPropertyParkingList();
                PropertyTowerDTO propertyTowerDto = new PropertyTowerDTO();
                propertyTowerDto.Id = long.Parse(drpSelectPropertyTower.Text);
                propertyTowerDto.FirmNumber = getUserDefinitionDTO().FirmNumber;
                propertyTowerDto.PropertyParkings = new HashSet<PropertyParkingDTO>(prParkingList);
                //Save list to DB
                propertyBO.saveOrUpdatePropertyParking(propertyTowerDto);
                pnlPropertyParkingAdd.Visible = false;
                loadPropertyParkingGrid();
                setSuccessMessage(Resources.Messages.success_property_parking_update);

            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private PropertyParkingDTO populatePropertyParkingDTOAddFromUI()
        {
            UserDefinitionDTO userDef = getUserDefinitionDTO();
            PropertyParkingDTO propertyParkingDTO = new PropertyParkingDTO();
            PropertyTowerDTO propertyTowerDto = new PropertyTowerDTO();
            propertyTowerDto.Id = long.Parse(drpSelectPropertyTower.Text);
            propertyTowerDto.FirmNumber = userDef.FirmNumber;
            propertyParkingDTO.PropertyTower = propertyTowerDto;
            propertyParkingDTO.FirmNumber = userDef.FirmNumber;
            propertyParkingDTO.InsertUser = userDef.Username;
            populatePropertyParkingFromUI(propertyParkingDTO);
            return propertyParkingDTO;
        }
        private void populatePropertyParkingFromUI(PropertyParkingDTO propertyParkingDTO)
        {
            propertyParkingDTO.ParkingNo = txtParkingNo.Text;
            propertyParkingDTO.ParkingType = CommonUIConverter.getMasterControlDTO(drpParkingType.Text, drpParkingType.SelectedItem.Text);
            propertyParkingDTO.Status = EnumHelper.ToEnum<ParkingStatus>(drpStatus.Text);
            propertyParkingDTO.CommonParking = EnumHelper.ToEnum<CommonParking>(drp_commonparking.Text);
            if (!string.IsNullOrWhiteSpace(txtArea.Text))
            {
                propertyParkingDTO.Area = CommonUtil.getDecimalWithoutExt(txtArea.Text);
            }
            propertyParkingDTO.UpdateUser = getUserDefinitionDTO().Username;
        }

        private bool validatePropertyParking()
        {
            bool isValid = true;
            Page.Validate(tab1ValidationGrp);
            isValid = Page.IsValid;
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
    }
}