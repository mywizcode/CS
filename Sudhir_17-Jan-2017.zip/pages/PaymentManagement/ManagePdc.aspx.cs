﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;

public partial class ManagePdc : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string tab1ValidationGrp = "tab1Error";
    string tab2ValidationGrp = "tab2Error";
    string FIRM_CUSTOMER = "FIRM_CUSTOMER";
    string FIRM_CONTRACTOR = "FIRM_CONTRACTOR";
    string FIRM_SUPPLIER = "FIRM_SUPPLIER";
    string FIRM_AGENCY = "FIRM_AGENCY";
    string CUSTOMER_FIRM = "CUSTOMER_FIRM";
    string INVALID_PYMT_DIRECTION = "INVALID_PYMT_DIRECTION";
    string VS_SEARCH_GRIDDATA = "VS_SEARCH_GRIDDATA";
    string VS_SELECTED_PDC = "VS_SELECTED_PDC";
    enum PdcPageMode { VIEW, ADD, MODIFY, NONE }
    PaymentBO paymentBO = new PaymentBO();
    DropdownBO drpBO = new DropdownBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (Session[Constants.Session.USERNAME] != null)
            {
                resetTabInfo(PdcPageMode.NONE);
                initDropdowns();
                Page.MaintainScrollPositionOnPostBack = false;
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpEnum<PaymentFromSearchBy>(drpSelectPymtFrom, null);
        drpBO.drpEnum<PdcChequeStatus>(drpChequeStatus, Constants.SELECT_ITEM);
        drpBO.populateDrpPymtToSearchBy(drpSelectPymtTo, PaymentFromSearchBy.NONE);
        drpBO.drpDataBase(drpSelectProperty, DrpDataType.PROPERTY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpInit(drpSelectPropertyTower, Constants.SELECT_ITEM);
        drpBO.drpDataBase(drpFirmAccount, DrpDataType.FIRM_ACCOUNT, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (Session[Constants.Session.USERNAME] != null)
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private bool isViewOnlyUser()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        bool isViewOnlyUser = !CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.FIRM_MEMBER_ADD_UPDATE);
        return isViewOnlyUser;
    }
    private void applyEntitlement()
    {
        if (isViewOnlyUser())
        {
            
        }
    }
    private void preRenderInitFormElements()
    {
        //populateTab2Info();
        setJumpToField();
        jumpToPdcPaymentHdnId.Value = "";
        /*PaymentMasterDTO pymtMasterDto = getCurrentPymtMaster();
        if(pymtMasterDto != null) {
            PaymentTransactionDTO pymtTransDto = pymtMasterDto.PaymentTransactions.ToList<PaymentTransactionDTO>().Find(p => p.isUISelected);
            if (pymtTransDto != null) jumpToPymtHistoryHdnId.Value = pymtTransDto.UiIndex+"";
        }*/
    }
    private void setJumpToField()
    {
        jumpToPdcHdnId.Value = "";
        string pymtDirection = getPaymentDirection();
        if (CUSTOMER_FIRM.Equals(pymtDirection) || FIRM_CUSTOMER.Equals(pymtDirection))
        {
            //PrUnitSalePymtDTO prUnitSalePymtDto = getCurrentCustToFromBuilderPymt();
            //if (prUnitSalePymtDto != null) jumpToPdcHdnId.Value = prUnitSalePymtDto.PaymentMaster.Id+"";
        }
        else if (FIRM_CONTRACTOR.Equals(pymtDirection))
        {
        }
        else if (FIRM_SUPPLIER.Equals(pymtDirection))
        {
        }
        else if (FIRM_AGENCY.Equals(pymtDirection))
        {
        }
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }

    public void setSuccessMessage(string msg, string tabId)
    {
        activeTabHdn.Value = tabId;
        if (tabId.Equals(tab1Anchor.ID))
        {
            lbTab1Success.Text = msg;
            tab1SuccessPanel.Visible = true;
        }
        if (tabId.Equals(tab2Anchor.ID))
        {
            lbTab2Success.Text = msg;
            tab2SuccessPanel.Visible = true;
        }
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private void clearMessages()
    {
        tab1SuccessPanel.Visible = false;
        lbTab1Success.Text = "";
        tab2SuccessPanel.Visible = false;
        lbTab2Success.Text = "";
        
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }

    private void resetTabInfo(PdcPageMode pageMode)
    {
    	tab2Anchor.Visible = false;
    	activeTabHdn.Value = tab1Anchor.ID;
        pageModeHdn.Value = pageMode.ToString();
        initFormFields();
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        ViewState[VS_SELECTED_PDC] = null;
        pnlChqAndPymtDetails.Visible = false;
        if (PdcPageMode.ADD == pageMode || PdcPageMode.MODIFY == pageMode || PdcPageMode.VIEW == pageMode)
        {
            tab2Anchor.Visible = true;
            activeTabHdn.Value = tab2Anchor.ID;
            initFormFields();
            initTab2(pageMode);
        }
        else
        {
            
            tab2Anchor.Visible = false;
        }
    }
    private void initFormFields()
    {
        bool visible = !(PdcPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
        //Buttons
        btnAddPdc.Visible = visible;
        btnModifyPdc.Visible = visible;
        btnDeletePdc.Visible = visible;
        btnLiAddPdc.Visible = visible;
        btnLiModifyPdc.Visible = visible;
        btnLiDeletePdc.Visible = visible;
        //pymtHistoryGrid.Columns[0].Visible = visible;

        drpChqDrawer.ClearSelection();
        drpChqPayee.ClearSelection();
    }
    private void initTab2(PdcPageMode pageAction)
    {
        if (PdcPageMode.ADD == pageAction)
        {
            tab2Anchor.Text = Resources.Labels.pymt_sm_pdc_tab2_name_add;
        }
        else if (PdcPageMode.MODIFY == pageAction)
        {
            pnlChqAndPymtDetails.Visible = true;
            tab2Anchor.Text = Resources.Labels.pymt_sm_pdc_tab2_name_modify;
        }else if (PdcPageMode.VIEW == pageAction)
        {
            pnlChqAndPymtDetails.Visible = true;
            tab2Anchor.Text = Resources.Labels.pymt_sm_pdc_tab2_name_view;
        }
    }
    private List<PostDatedChequeSearchDTO> getPdcGridList()
    {
        return (List<PostDatedChequeSearchDTO>)ViewState[VS_SEARCH_GRIDDATA];
    }
    private PostDatedChequeSearchDTO getSelectedPdcFromList()
    {
        return  getPdcGridList().Find(c => c.isUISelected);
    }
    private PostDatedChequeDTO getCurrentPdc()
    {
        return (PostDatedChequeDTO)ViewState[VS_SELECTED_PDC];
    }
    private void fetchAllPostDatedCheques(long id)
    {
        pnlChqSearchGrid.Visible = false;
        if (isValidPymtSearchSelection())
        {
            pnlChqSearchGrid.Visible = true;
            pdcGrid.Visible = false;
            string pymtDirection = getPaymentDirection();
            long propertyTowerId = long.Parse(drpSelectPropertyTower.Text);
            PaymentSearchBy searchBy = EnumHelper.ToEnum<PaymentSearchBy>(drpSearchBy.Text);
            long searchByValue = (!string.IsNullOrWhiteSpace(drpSearchByValue.Text)) ? long.Parse(drpSearchByValue.Text) : -1;
            if (CUSTOMER_FIRM.Equals(pymtDirection))
            {
                IList<PostDatedChequeSearchDTO> result = paymentBO.fetchPdcFromCustomerToFirm(getUserDefinitionDTO().FirmNumber, propertyTowerId);
                pdcGrid.Visible = true;
                ViewState[VS_SEARCH_GRIDDATA] = result;
                pdcGrid.DataSource = result;
                pdcGrid.DataBind();
                if (id > 0) selectPdcSearchGridRdBtn(id);
                drpBO.drpDataBase(drpChqDrawer, DrpDataType.PDC_DRAWER_CUSTOMER, propertyTowerId.ToString(), Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
                drpBO.drpDataBase(drpChqPayee, DrpDataType.PDC_FIRM, null, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            }else if (FIRM_CUSTOMER.Equals(pymtDirection))
            {
            }
            else if (FIRM_CONTRACTOR.Equals(pymtDirection))
            {
            }
            else if (FIRM_SUPPLIER.Equals(pymtDirection))
            {
            }
            else if (FIRM_AGENCY.Equals(pymtDirection))
            {
            }
        }
    }
    private bool isValidPymtSearchSelection()
    {
        bool isValid = true;
        PaymentFromSearchBy pymtFromSearchBy = EnumHelper.ToEnum<PaymentFromSearchBy>(drpSelectPymtFrom.Text);
        PaymentToSearchBy pymtToSearchBy = EnumHelper.ToEnum<PaymentToSearchBy>(drpSelectPymtTo.Text);
        if (string.IsNullOrWhiteSpace(drpSelectProperty.Text) || string.IsNullOrWhiteSpace(drpSelectPropertyTower.Text)
            || PaymentFromSearchBy.NONE == pymtFromSearchBy || PaymentToSearchBy.NONE == pymtToSearchBy)
        {
            isValid = false;
        }
        return isValid;
    }
    private string getPaymentDirection()
    {
        string pymtDirection = INVALID_PYMT_DIRECTION;
        PaymentFromSearchBy pymtFromSearchBy = EnumHelper.ToEnum<PaymentFromSearchBy>(drpSelectPymtFrom.Text);
        PaymentToSearchBy pymtToSearchBy = EnumHelper.ToEnum<PaymentToSearchBy>(drpSelectPymtTo.Text);
        if (PaymentFromSearchBy.FIRM == pymtFromSearchBy && PaymentToSearchBy.CUSTOMER == pymtToSearchBy) pymtDirection = FIRM_CUSTOMER;
        else if (PaymentFromSearchBy.FIRM == pymtFromSearchBy && PaymentToSearchBy.CONTRACTOR == pymtToSearchBy) pymtDirection = FIRM_CONTRACTOR;
        else if (PaymentFromSearchBy.FIRM == pymtFromSearchBy && PaymentToSearchBy.SUPPLIER == pymtToSearchBy) pymtDirection = FIRM_SUPPLIER;
        else if (PaymentFromSearchBy.FIRM == pymtFromSearchBy && PaymentToSearchBy.AGENCY == pymtToSearchBy) pymtDirection = FIRM_AGENCY;
        else if (PaymentFromSearchBy.CUSTOMER == pymtFromSearchBy && PaymentToSearchBy.FIRM == pymtToSearchBy) pymtDirection = CUSTOMER_FIRM;
        return pymtDirection;
    }
    protected void onSearchBy(object sender, EventArgs e)
    {
        try
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            PaymentSearchBy searchBy = EnumHelper.ToEnum<PaymentSearchBy>(drpSearchBy.Text);
            initSearchByValue(true);
            lbSearchByValue.Text = EnumHelper.GetEnumDescription<PaymentSearchBy>(searchBy.ToString());
            if (PaymentSearchBy.CUSTOMER_NAME == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.PYMT_SEARCH_BY_CUSTOMER_NAME, drpSelectPropertyTower.Text, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else if (PaymentSearchBy.UNIT_NO == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.PYMT_SEARCH_BY_UNITNO, drpSelectPropertyTower.Text, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else
            {
                initSearchByValue(false);
            }
            fetchAllPostDatedCheques(0);
            resetTabInfo(PdcPageMode.NONE);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private void initSearchByValue(bool isVisible)
    {
        drpSearchByValue.ClearSelection();
        drpSearchByValue.Visible = isVisible;
        lbSearchByValue.Visible = isVisible;
    }
    private void loadDrpSearchBy()
    {
        string pymtDirection = getPaymentDirection();
        drpSearchBy.Items.Clear();
        drpSearchBy.Items.Add(new ListItem(PaymentSearchBy.NONE.GetDescription(), PaymentSearchBy.NONE.ToString()));
        drpBO.drpInit(drpSearchByValue, Constants.SELECT_ITEM);
        initSearchByValue(false);
        if (CUSTOMER_FIRM.Equals(pymtDirection) || FIRM_CUSTOMER.Equals(pymtDirection))
        {
            drpSearchBy.Items.Add(new ListItem(PaymentSearchBy.CUSTOMER_NAME.GetDescription(), PaymentSearchBy.CUSTOMER_NAME.ToString()));
            drpSearchBy.Items.Add(new ListItem(PaymentSearchBy.UNIT_NO.GetDescription(), PaymentSearchBy.UNIT_NO.ToString()));
        }
        else if (FIRM_CONTRACTOR.Equals(pymtDirection))
        {
        }
        else if (FIRM_SUPPLIER.Equals(pymtDirection))
        {
        }
        else if (FIRM_AGENCY.Equals(pymtDirection))
        {
        }
    }
    protected void onSearchByValue(object sender, EventArgs e)
    {
        resetTabInfo(PdcPageMode.NONE);
        fetchAllPostDatedCheques(0);
    }
    protected void onSelectPymtFrom(object sender, EventArgs e)
    {
        try
        {
            resetTabInfo(PdcPageMode.NONE);
            PaymentFromSearchBy pymtFromSearchBy = EnumHelper.ToEnum<PaymentFromSearchBy>(drpSelectPymtFrom.Text);
            drpBO.populateDrpPymtToSearchBy(drpSelectPymtTo, pymtFromSearchBy);
            loadDrpSearchBy();
            fetchAllPostDatedCheques(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSelectPymtTo(object sender, EventArgs e)
    {
        try
        {
            resetTabInfo(PdcPageMode.NONE);
            loadDrpSearchBy();
            fetchAllPostDatedCheques(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSelectProperty(object sender, EventArgs e)
    {
        try
        {
            resetTabInfo(PdcPageMode.NONE);
            drpBO.drpDataBase(drpSelectPropertyTower, DrpDataType.PROPERTY_TOWER, drpSelectProperty.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            if (drpSelectPropertyTower.Items.Count == 2)
            {
                drpSelectPropertyTower.Items[1].Selected = true;
            }
            loadDrpSearchBy();
            fetchAllPostDatedCheques(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSelectPropertyTower(object sender, EventArgs e)
    {
        try
        {
            resetTabInfo(PdcPageMode.NONE);
            loadDrpSearchBy();
            fetchAllPostDatedCheques(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    
    private void selectPdcSearchGridRdBtn(long Id)
    {
        if (pdcGrid.Rows.Count > 0)
        {
            setSelectedPdc(0);
            foreach (GridViewRow row in pdcGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdPdcSelect");
                Button rowIdenBtn = (Button)row.FindControl("btnPdcRowIdentifier");
                if (radioBtn != null)
                {
                    radioBtn.Checked = false;
                    if (rowIdenBtn != null && Id > 0 && Id.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                    {
                        radioBtn.Checked = true;
                        setSelectedPdc(Id);
                    }
                }
            }
        }
    }
    private void setSelectedPdc(long selectedId)
    {
        List<PostDatedChequeSearchDTO> pdcDtoList = getPdcGridList();
        if (pdcDtoList != null)
        {
            pdcDtoList.ForEach(c => c.isUISelected = false);
            if (selectedId > 0) pdcDtoList.Find(c => c.Id == selectedId).isUISelected = true;
        }
    }
    protected void onSelectPostDatedCheque(object sender, EventArgs e)
    {
        try
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            resetTabInfo(PdcPageMode.NONE);
            if (rd.Checked)
            {
                string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnPdcRowIdentifier"))).Attributes["row-identifier"];
                setSelectedPdc(long.Parse(strId));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private bool validatePdcSelected()
    {
        bool isSelected = true;
        if (getSelectedPdcFromList() != null)
        {
            isSelected = false;
            resetTabInfo(PdcPageMode.NONE);
            setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Post Dated Cheque"), tab1ValidationGrp);
        }
        return isSelected;
    }
    private bool validatePaymentStatus(bool showError)
    {
        bool isValid = true;
        /*string pymtDirection = getPaymentDirection();
        if (CUSTOMER_FIRM.Equals(pymtDirection) || FIRM_CUSTOMER.Equals(pymtDirection))
        {
            PrUnitSalePymtDTO prUnitSalePymtDto = getCurrentCustToFromBuilderPymt();
            if (prUnitSalePymtDto != null && prUnitSalePymtDto.PaymentMaster.Status == PymtMasterStatus.Deleted)
            {
                if (showError) setErrorMessage("Cannot add payment transaction, Selected payment is deleted.", tab1ValidationGrp);
                isValid = false;
            }
            if (prUnitSalePymtDto != null && prUnitSalePymtDto.PaymentMaster.Status == PymtMasterStatus.Suspended)
            {
                if (showError) setErrorMessage(Resources.Messages.validation_pymt_cancelled_addpymt, tab1ValidationGrp);
                isValid = false;
            }
        }
        else if (FIRM_CONTRACTOR.Equals(pymtDirection))
        {
        }
        else if (FIRM_SUPPLIER.Equals(pymtDirection))
        {
        }
        else if (FIRM_AGENCY.Equals(pymtDirection))
        {
        }*/
        return isValid;
    }
    private void fetchSelectedPdc(PdcPageMode pageMode)
    {
        try
        {
            string pymtDirection = getPaymentDirection();
            if (CUSTOMER_FIRM.Equals(pymtDirection))
            {
                PostDatedChequeDTO pdcDto = null;
                long customerId = 0;
                if (PdcPageMode.ADD == pageMode)
                {
                    pdcDto = populatePdcDTOForAdd();
                    customerId = long.Parse(drpChqDrawer.Text); 
                }
                else
                {
                    PostDatedChequeSearchDTO pdcSearchDto = getSelectedPdcFromList();
                    customerId = pdcSearchDto.ChqDrawerId;
                    pdcDto = paymentBO.fetchPostDatedChequeDetails(pdcSearchDto.Id);
                }
                long propertyTowerId = long.Parse(drpSelectPropertyTower.Text);
                IList<PdcPymtDTO> salePayments = paymentBO.fetchPdcPymtFromCustomerToFirm(getUserDefinitionDTO().FirmNumber, propertyTowerId, customerId);
                salePayments.ToList().ForEach(x => x.UnitNo = CommonUIConverter.getPropertyUnitFormattedNo(x.Wing, x.UnitNo));
                populatePdcPymts(pdcDto, salePayments);
                ViewState[VS_SELECTED_PDC] = pdcDto;
            }
            else if (FIRM_CUSTOMER.Equals(pymtDirection))
            {
            }
            else if (FIRM_CONTRACTOR.Equals(pymtDirection))
            {
            }
            else if (FIRM_SUPPLIER.Equals(pymtDirection))
            {
            }
            else if (FIRM_AGENCY.Equals(pymtDirection))
            {
            }
            populateUiFieldsFromPDCDto(getCurrentPdc());
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private PostDatedChequeDTO populatePdcDTOForAdd()
    {
        PostDatedChequeDTO postDatedChequeDto = new PostDatedChequeDTO();
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        postDatedChequeDto.CollectionDate = DateTime.Today;
        postDatedChequeDto.PymtStatus = PdcPymtStatus.Pending;
        postDatedChequeDto.PrTower = CommonUIConverter.getPropertyTowerDTO(drpSelectPropertyTower.Text, null);
        postDatedChequeDto.PdcUiPymts = new List<PdcPymtDTO>();
        
        postDatedChequeDto.FirmNumber = userDefDto.FirmNumber;
        postDatedChequeDto.InsertUser = userDefDto.Username;
        postDatedChequeDto.UpdateUser = userDefDto.Username;

        return postDatedChequeDto;
    }
    private void populatePdcPymts(PostDatedChequeDTO postDatedChequeDto, IList<PdcPymtDTO> pdcPymtDtos)
    {
        if (postDatedChequeDto.PdcUiPymts == null) postDatedChequeDto.PdcUiPymts = new List<PdcPymtDTO>();
        if (postDatedChequeDto.PaymentTransactions != null)
        {
            foreach (PaymentTransactionDTO transDto in postDatedChequeDto.PaymentTransactions)
            {
                PdcPymtDTO tmpDto = pdcPymtDtos.ToList<PdcPymtDTO>().Find(x => x.PymtMasterId == transDto.PaymentMaster.Id);
                if (tmpDto != null)
                {
                    tmpDto.PaymentTransaction = transDto;
                    postDatedChequeDto.PdcUiPymts.Add(tmpDto);
                }
            }
        }
        List<PdcPymtDTO> tmpPdcPymtList = new List<PdcPymtDTO>();
        foreach (PdcPymtDTO pdcPymtDto in pdcPymtDtos)
        {
            if (!postDatedChequeDto.PdcUiPymts.Contains(pdcPymtDto) && postDatedChequeDto.ChequeStatus == PdcChequeStatus.Collected)
            {
                pdcPymtDto.PaymentTransaction = createNewPaymentTransaction(postDatedChequeDto);
                tmpPdcPymtList.Add(pdcPymtDto);
            }
        }
        postDatedChequeDto.PdcUiPymts.AddRange(tmpPdcPymtList);
    }
    private PaymentTransactionDTO createNewPaymentTransaction(PostDatedChequeDTO postDatedChequeDto)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        PaymentTransactionDTO pymtTransDto = new PaymentTransactionDTO();
        copyPymtTransFields(pymtTransDto, postDatedChequeDto);
        pymtTransDto.FirmNumber = userDefDto.FirmNumber;
        pymtTransDto.InsertUser = userDefDto.Username;
        pymtTransDto.UpdateUser = userDefDto.Username;
        return pymtTransDto;
    }
    private void copyPymtTransFields(PaymentTransactionDTO pymtTransDto, PostDatedChequeDTO postDatedChequeDto)
    {
        pymtTransDto.TxDate = (postDatedChequeDto.ClearanceDate == null) ? DateTime.Today : postDatedChequeDto.ClearanceDate.Value;
        pymtTransDto.Amount = postDatedChequeDto.PymtAmt;
        pymtTransDto.Status = PymtTransStatus.Pending;
        pymtTransDto.PymtMode = PaymentMode.CHEQUE;
        pymtTransDto.BankName = postDatedChequeDto.BankName;
        pymtTransDto.Branch = postDatedChequeDto.Branch;
        pymtTransDto.ChequeNo = postDatedChequeDto.ChequeNo;
        pymtTransDto.ChequeDate = postDatedChequeDto.ChequeDate;
        pymtTransDto.Comments = postDatedChequeDto.Description;
    }
    private void populateUiFieldsFromPDCDto(PostDatedChequeDTO pdcDto) {
        if(pdcDto != null) txtChequeCollectionDate.Text = CommonUtil.getCSDate(pdcDto.CollectionDate); else txtChequeCollectionDate.Text = null;
        if(pdcDto != null) txtChequeDate.Text = CommonUtil.getCSDate(pdcDto.ChequeDate); else txtChequeDate.Text = null;
        if(pdcDto != null) txtChequeNo.Text = pdcDto.ChequeNo; else txtChequeNo.Text = null;
        if(pdcDto != null) txtChequeAmount.Text = pdcDto.PymtAmt.ToString(); else txtChequeAmount.Text = null;
        if(pdcDto != null) txtBankName.Text = pdcDto.BankName; else txtBankName.Text = null;
        if(pdcDto != null) txtBranch.Text = pdcDto.Branch; else txtBranch.Text = null;
        if(pdcDto != null) drpChequeStatus.Text = pdcDto.ChequeStatus.ToString(); else drpChequeStatus.ClearSelection();
        if(pdcDto != null) txtChequeComment.Text = pdcDto.Description; else txtChequeComment.Text = null;
        if(pdcDto != null) txtChqClearanceDate.Text = CommonUtil.getCSDate(pdcDto.ClearanceDate); else txtChqClearanceDate.Text = null;
        if(pdcDto != null && pdcDto.FirmAccount != null) drpFirmAccount.Text = pdcDto.FirmAccount.Id.ToString(); else drpFirmAccount.ClearSelection();
        if(pdcDto != null) txtTotalPaidAmount.Text = calculateTotalPaidAmount(pdcDto).ToString(); else txtTotalPaidAmount.Text = null;
        populatePdcPymtDetailGrid(pdcDto);
    }
    private void populatePdcPymtDetailGrid(PostDatedChequeDTO pdcDto)
    {
        pdcPymtGrid.DataSource = new List<PdcPymtDTO>();
        if (pdcDto != null && pdcDto.PdcUiPymts != null)
        {
            assignUiIndexToPdcPymts(pdcDto.PdcUiPymts);
            pdcPymtGrid.DataSource = pdcDto.PdcUiPymts;
        }
        pdcPymtGrid.DataBind();
    }
    private void assignUiIndexToPdcPymts(List<PdcPymtDTO> pdcPymts)
    {
        if (pdcPymts != null && pdcPymts.Count > 0)
        {
            long uiIndex = 1;
            foreach (PdcPymtDTO pdcPymtDto in pdcPymts)
            {
                pdcPymtDto.UiIndex = uiIndex++;
                pdcPymtDto.RowInfo = CommonUIConverter.getGridViewRowInfo(pdcPymtDto);
            }
        }
    }
    private decimal calculateTotalPaidAmount(PostDatedChequeDTO pdcDto) {
        decimal totalPaidAmt = Decimal.Zero;
        if(pdcDto != null) {
            foreach(PdcPymtDTO pdcPymtDto in pdcDto.PdcUiPymts) {
                totalPaidAmt = totalPaidAmt + pdcPymtDto.PaymentTransaction.Amount;
            }
        }
        return totalPaidAmt;
    }
    private void setChqDrawerAndPayee()
    {
        PostDatedChequeSearchDTO pdcSearchDto = getSelectedPdcFromList();
        drpChqDrawer.Text = pdcSearchDto.ChqDrawerId + "";
        drpChqPayee.Text = pdcSearchDto.ChqPayeeId + "";
    }
    protected void onClickAddPDCBtn(object sender, EventArgs e)
    {
    	try
        {
            resetTabInfo(PdcPageMode.ADD);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickModifyPDCBtn(object sender, EventArgs e)
    {
        try
        {
            if (validatePdcSelected() && validatePaymentStatus(true))
            {
                resetTabInfo(PdcPageMode.MODIFY);
                fetchSelectedPdc(PdcPageMode.MODIFY);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickViewPDCBtn(object sender, EventArgs e)
    {
        try
        {
            if (validatePdcSelected() && validatePaymentStatus(true))
            {
                resetTabInfo(PdcPageMode.ADD);
                fetchSelectedPdc(PdcPageMode.VIEW);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }

    protected void onClickDeletePDCBtn(object sender, EventArgs e)
    {
        try
        {
            
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onChangeChequeDrawer(object sender, EventArgs e)
    {
        try
        {
            drpChqPayee.ClearSelection();
            pnlChqAndPymtDetails.Visible = false;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void onChangeChequePayee(object sender, EventArgs e)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(drpChqDrawer.Text))
            {
                setErrorMessage("Please select Chque Drawer", tab2ValidationGrp);
            } if (string.IsNullOrWhiteSpace(drpChqPayee.Text))
            {
                pnlChqAndPymtDetails.Visible = false;
            }
            else
            {
                pnlChqAndPymtDetails.Visible = true;
                fetchSelectedPdc(PdcPageMode.ADD);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private void setSelectedPdcPymt(long selectedId)
    {
        List<PdcPymtDTO> pdcPymtDtoList = getCurrentPdc().PdcUiPymts;
        if (pdcPymtDtoList != null)
        {
            pdcPymtDtoList.ForEach(c => c.isUISelected = false);
            if (selectedId > 0) pdcPymtDtoList.Find(c => c.PymtMasterId == selectedId).isUISelected = true;
        }
    }
    protected void onSelectPdcPayment(object sender, EventArgs e)
    {
        try
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            if (rd.Checked)
            {
                string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnPdcPymtRowIdentifier"))).Attributes["row-identifier"];
                setSelectedPdcPymt(long.Parse(strId));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickPayPdcPymtBtn(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickClearPdcPaymentBtn(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void addChequePayment(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }

    protected void cancelChequePayment(object sender, EventArgs e)
    {
        resetTabInfo(PdcPageMode.NONE);
    }
}
