﻿
/// <summary>
/// Summary description for CommonUtil
/// </summary>
using ConstroSoft;
using System.Collections.Generic;
namespace ConstroSoft
{
    public class DomainToDTOUtil
    {
        public DomainToDTOUtil() { }
        public static AddressDTO convertToAddressDTO(Address address)
        {
            AddressDTO addressDto = null;
            if (address != null)
            {
                addressDto = new AddressDTO();
                addressDto.Id = address.Id;
                addressDto.PreferredAddress = address.PreferredAddress;
                addressDto.AddressLine1 = address.AddressLine1;
                addressDto.AddressLine2 = address.AddressLine2;
                addressDto.Town = address.Town;
                addressDto.Pin = address.Pin;
                addressDto.AddressType = DomainToDTOUtil.convertToMasterControlDTO(address.AddressType, false);
                addressDto.City = DomainToDTOUtil.convertToCityDTO(address.City, false);
                addressDto.State = DomainToDTOUtil.convertToStateDTO(address.State, false);
                addressDto.Country = DomainToDTOUtil.convertToCountryDTO(address.Country, false);
            }
            return addressDto;
        }
        public static ContactInfoDTO convertToContactInfoDTO(ContactInfo contactInfo)
        {
            ContactInfoDTO contactInfoDto = null;
            if (contactInfo != null)
            {
                contactInfoDto = new ContactInfoDTO();
                contactInfoDto.Id = contactInfo.Id;
                contactInfoDto.Contact = contactInfo.Contact;
                contactInfoDto.AltContact = contactInfo.AltContact;
                contactInfoDto.Gender = contactInfo.Gender;
                contactInfoDto.MaritalStatus = contactInfo.MaritalStatus;
                contactInfoDto.Dob = contactInfo.Dob;
                contactInfoDto.Email = contactInfo.Email;
                contactInfoDto.AltEmail = contactInfo.AltEmail;
                contactInfoDto.Addresses = new HashSet<AddressDTO>();
                if (contactInfo.Addresses != null && contactInfo.Addresses.Count > 0)
                {
                    foreach (Address address in contactInfo.Addresses)
                    {
                        contactInfoDto.Addresses.Add(DomainToDTOUtil.convertToAddressDTO(address));
                    }
                }
            }
            return contactInfoDto;
        }
        public static FirmDTO convertToFirmDTO(Firm firm, bool allFields)
        {
            FirmDTO firmDto = null;
            if (firm != null)
            {
                firmDto = new FirmDTO();
                firmDto.Id = firm.Id;
                firmDto.Name = firm.Name;
                firmDto.FirmNumber = firm.FirmNumber;
                if (allFields)
                {
                    firmDto.RegistrationNo = firm.RegistrationNo;
                    firmDto.WebSite = firm.WebSite;
                    firmDto.Description = firm.Description;
                    firmDto.InsertDate = firm.InsertDate;
                    firmDto.UpdateDate = firm.UpdateDate;
                    firmDto.Version = firm.Version;
                    firmDto.InsertUser = firm.InsertUser;
                    firmDto.UpdateUser = firm.UpdateUser;
                    firmDto.ContactInfo = DomainToDTOUtil.convertToContactInfoDTO(firm.ContactInfo);
                }
            }
            return firmDto;
        }

        public static FirmAccountDTO convertToFirmAccountDTO(FirmAccount firmAccount, bool allFields)
        {
            FirmAccountDTO firmAccountDto = null;
            if (firmAccount != null)
            {
                firmAccountDto = new FirmAccountDTO();
                firmAccountDto.Id = firmAccount.Id;
                firmAccountDto.Name = firmAccount.Name;
                firmAccountDto.AccountNo = firmAccount.AccountNo;
                if (allFields)
                {
                    firmAccountDto.AccountType = DomainToDTOUtil.convertToMasterControlDTO(firmAccount.AccountType, false);
                    firmAccountDto.AccountBalance = firmAccount.AccountBalance;
                    firmAccountDto.IfscCode = firmAccount.IfscCode;
                    firmAccountDto.BankName = firmAccount.BankName;
                    firmAccountDto.Branch = firmAccount.Branch;
                    firmAccountDto.City = DomainToDTOUtil.convertToCityDTO(firmAccount.City, false);
                    firmAccountDto.State = DomainToDTOUtil.convertToStateDTO(firmAccount.State, false);
                    firmAccountDto.Country = DomainToDTOUtil.convertToCountryDTO(firmAccount.Country, false);
                    firmAccountDto.FirmNumber = firmAccount.FirmNumber;
                    firmAccountDto.UpdateDate = firmAccount.UpdateDate;
                    firmAccountDto.Version = firmAccount.Version;
                    firmAccountDto.InsertUser = firmAccount.InsertUser;
                    firmAccountDto.UpdateUser = firmAccount.UpdateUser;
                    firmAccountDto.RowInfo = CommonUIConverter.getGridViewRowInfo(firmAccountDto);
                }
            }
            return firmAccountDto;
        }
        public static EnquiryDetailDTO convertToEnquiryDetailDTO(EnquiryDetail enquiryDetail)
        {
            EnquiryDetailDTO enquiryDto = null;
            if (enquiryDetail != null)
            {
                enquiryDto = new EnquiryDetailDTO();
                enquiryDto.Id = enquiryDetail.Id;
                enquiryDto.Salutation = DomainToDTOUtil.convertToMasterControlDTO(enquiryDetail.Salutation, false);
                enquiryDto.FirstName = enquiryDetail.FirstName;
                enquiryDto.MiddleName = enquiryDetail.MiddleName;
                enquiryDto.LastName = enquiryDetail.LastName;
                enquiryDto.ContactInfo = DomainToDTOUtil.convertToContactInfoDTO(enquiryDetail.ContactInfo);
                enquiryDto.Occupation = DomainToDTOUtil.convertToMasterControlDTO(enquiryDetail.Occupation, false);
                enquiryDto.EnquiryDate = enquiryDetail.EnquiryDate;
                enquiryDto.PropertyType = DomainToDTOUtil.convertToMasterControlDTO(enquiryDetail.PropertyType, false);
                enquiryDto.PropertyLocation = DomainToDTOUtil.convertToMasterControlDTO(enquiryDetail.PropertyLocation, false);
                enquiryDto.Property = DomainToDTOUtil.convertToPropertyDTO(enquiryDetail.Property, false);
                enquiryDto.PrUnitType = DomainToDTOUtil.convertToMasterControlDTO(enquiryDetail.PrUnitType, false);
                enquiryDto.EnquirySource = DomainToDTOUtil.convertToMasterControlDTO(enquiryDetail.EnquirySource, false);
                enquiryDto.Budget = enquiryDetail.Budget;
                enquiryDto.FirmMember = DomainToDTOUtil.convertToFirmMemberDTO(enquiryDetail.FirmMember, false);
                enquiryDto.FirmNumber = enquiryDetail.FirmNumber;
                enquiryDto.Status = enquiryDetail.Status;
                enquiryDto.FollowupDate = enquiryDetail.FollowupDate;
                enquiryDto.Comments = enquiryDetail.Comments;
                enquiryDto.CloseReason = enquiryDetail.CloseReason;
                if (enquiryDetail.EnquiryFollowups != null && enquiryDetail.EnquiryFollowups.Count > 0)
                {
                    enquiryDto.EnquiryFollowups = new HashSet<EnquiryFollowupDTO>();
                    foreach (EnquiryFollowup enquiryFollowup in enquiryDetail.EnquiryFollowups)
                    {
                        enquiryDto.EnquiryFollowups.Add(DomainToDTOUtil.convertToEnquiryFollowupDTO(enquiryFollowup, true));
                    }
                }
                enquiryDto.InsertUser = enquiryDetail.InsertUser;
                enquiryDto.UpdateUser = enquiryDetail.UpdateUser;
                enquiryDto.InsertDate = enquiryDetail.InsertDate;
                enquiryDto.UpdateDate = enquiryDetail.UpdateDate;
                enquiryDto.Version = enquiryDetail.Version;
            }
            return enquiryDto;
        }
        public static EnquiryFollowupDTO convertToEnquiryFollowupDTO(EnquiryFollowup enquiryFollowup, bool allFields)
        {
            EnquiryFollowupDTO enquiryFollowupDto = null;
            if (enquiryFollowup != null)
            {
                enquiryFollowupDto = new EnquiryFollowupDTO();
                enquiryFollowupDto.Id = enquiryFollowup.Id;
                if (allFields)
                {
                    enquiryFollowupDto.FollowupDate = enquiryFollowup.FollowupDate;
                    enquiryFollowupDto.Comments = enquiryFollowup.Comments;
                    enquiryFollowupDto.FirmNumber = enquiryFollowup.FirmNumber;
                    enquiryFollowupDto.CommunicationMedia = DomainToDTOUtil.convertToMasterControlDTO(enquiryFollowup.CommunicationMedia, false);
                    enquiryFollowupDto.FirmMember = DomainToDTOUtil.convertToFirmMemberDTO(enquiryFollowup.FirmMember, false);
                    enquiryFollowupDto.InsertDate = enquiryFollowup.InsertDate;
                    enquiryFollowupDto.UpdateDate = enquiryFollowup.UpdateDate;
                    enquiryFollowupDto.Version = enquiryFollowup.Version;
                    enquiryFollowupDto.InsertUser = enquiryFollowup.InsertUser;
                    enquiryFollowupDto.UpdateUser = enquiryFollowup.UpdateUser;
                }
            }
            return enquiryFollowupDto;
        }
        public static DepartmentDTO convertToDepartmentDTO(Department department, bool allFields)
        {
            DepartmentDTO departmentDto = null;
            if (department != null)
            {
                departmentDto = new DepartmentDTO();
                departmentDto.Id = department.Id;
                departmentDto.Name = department.Name;
                if (allFields)
                {
                    departmentDto.Description = department.Description;
                    departmentDto.FirmNumber = department.FirmNumber;
                    departmentDto.InsertDate = department.InsertDate;
                    departmentDto.UpdateDate = department.UpdateDate;
                    departmentDto.Version = department.Version;
                    departmentDto.InsertUser = department.InsertUser;
                    departmentDto.UpdateUser = department.UpdateUser;
                }
            }
            return departmentDto;
        }
        public static PropertyDTO convertToPropertyDTO(Property property, bool allFields)
        {
            PropertyDTO propertyDto = null;
            if (property != null)
            {
                propertyDto = new PropertyDTO();
                propertyDto.Id = property.Id;
                propertyDto.Name = property.Name;
                if (allFields)
                {
                    propertyDto.FirmAccount = DomainToDTOUtil.convertToFirmAccountDTO(property.FirmAccount, false);
                    propertyDto.ContactInfo = DomainToDTOUtil.convertToContactInfoDTO(property.ContactInfo);
                    propertyDto.PropertyType = DomainToDTOUtil.convertToMasterControlDTO(property.PropertyType, false);
                    propertyDto.PropertyLocation = DomainToDTOUtil.convertToMasterControlDTO(property.PropertyLocation, false);
                    propertyDto.PropertyArea = property.PropertyArea;
                    propertyDto.Description = property.Description;
                    propertyDto.EstimatedAmt = property.EstimatedAmt;
                    propertyDto.FirmNumber = property.FirmNumber;
                    propertyDto.InsertDate = property.InsertDate;
                    propertyDto.UpdateDate = property.UpdateDate;
                    propertyDto.Version = property.Version;
                    propertyDto.InsertUser = property.InsertUser;
                    propertyDto.UpdateUser = property.UpdateUser;

                    propertyDto.PropertyTowers = new HashSet<PropertyTowerDTO>();
                    if (property.PropertyTowers != null && property.PropertyTowers.Count > 0)
                    {
                        foreach (PropertyTower propertyTower in property.PropertyTowers)
                        {
                            propertyDto.PropertyTowers.Add(DomainToDTOUtil.convertToPropertyTowerDTO(propertyTower, true));
                        }
                    }
                    propertyDto.PropertyTaxDetails = new HashSet<PropertyTaxDetailDTO>();
                    if (property.PropertyTaxDetails != null && property.PropertyTaxDetails.Count > 0)
                    {
                        foreach (PropertyTaxDetail propertyTaxDetail in property.PropertyTaxDetails)
                        {
                            propertyDto.PropertyTaxDetails.Add(DomainToDTOUtil.convertToPropertyTaxDetailDTO(propertyTaxDetail, true));
                        }
                    }
                    propertyDto.PropertyCharges = new HashSet<PropertyChargeDTO>();
                    if (property.PropertyCharges != null && property.PropertyCharges.Count > 0)
                    {
                        foreach (PropertyCharge propertyCharge in property.PropertyCharges)
                        {
                            propertyDto.PropertyCharges.Add(DomainToDTOUtil.convertToPropertyChargeDTO(propertyCharge, true));
                        }
                    }
                    propertyDto.DocumentInfo = DomainToDTOUtil.convertToDocumentInfoDTO(property.DocumentInfo);
                    propertyDto.DocumentInfo.Id = property.DocumentInfo.Id;
                    propertyDto.DocumentInfo.Description = property.DocumentInfo.Description;
                }
            }
            return propertyDto;
        }
        public static PropertyTowerDTO convertToPropertyTowerDTO(PropertyTower propertyTower, bool allFields)
        {
            PropertyTowerDTO propertyTowerDto = null;
            if (propertyTower != null)
            {
                propertyTowerDto = new PropertyTowerDTO();
                propertyTowerDto.Id = propertyTower.Id;
                propertyTowerDto.Name = propertyTower.Name;
                if (allFields)
                {
                    propertyTowerDto.Property = DomainToDTOUtil.convertToPropertyDTO(propertyTower.Property, false);
                    propertyTowerDto.Rate = propertyTower.Rate;
                    propertyTowerDto.LaunchDate = propertyTower.LaunchDate;
                    propertyTowerDto.Possession = propertyTower.Possession;
                    propertyTowerDto.Description = propertyTower.Description;
                    propertyTowerDto.FirmNumber = propertyTower.FirmNumber;
                    propertyTowerDto.InsertDate = propertyTower.InsertDate;
                    propertyTowerDto.UpdateDate = propertyTower.UpdateDate;
                    propertyTowerDto.Version = propertyTower.Version;
                    propertyTowerDto.InsertUser = propertyTower.InsertUser;
                    propertyTowerDto.UpdateUser = propertyTower.UpdateUser;
                }
            }
            return propertyTowerDto;
        }
        public static PropertyParkingDTO convertToPropertyParkingDTO(PropertyParking propertyParking, bool allFields)
        {
            PropertyParkingDTO propertyParkingDto = null;
            if (propertyParking != null)
            {
                propertyParkingDto = new PropertyParkingDTO();
                propertyParkingDto.Id = propertyParking.Id;
                propertyParkingDto.ParkingNo = propertyParking.ParkingNo;
                if (allFields)
                {
                    propertyParkingDto.PropertyTower = DomainToDTOUtil.convertToPropertyTowerDTO(propertyParking.PropertyTower, false);
                    propertyParkingDto.ParkingType = DomainToDTOUtil.convertToMasterControlDTO(propertyParking.ParkingType, false);
                    propertyParkingDto.Area = propertyParking.Area;
                    propertyParkingDto.CommonParking = propertyParking.CommonParking;
                    propertyParkingDto.Status = propertyParking.Status;
                    propertyParkingDto.FirmNumber = propertyParking.FirmNumber;
                    propertyParkingDto.InsertDate = propertyParking.InsertDate;
                    propertyParkingDto.UpdateDate = propertyParking.UpdateDate;
                    propertyParkingDto.Version = propertyParking.Version;
                    propertyParkingDto.InsertUser = propertyParking.InsertUser;
                    propertyParkingDto.UpdateUser = propertyParking.UpdateUser;
                }
            }
            return propertyParkingDto;
        }
        public static PropertyUnitDTO convertToPropertyUnitDTO(PropertyUnit propertyUnit, bool allFields)
        {
            PropertyUnitDTO propertyUnitDTO = null;
            if (propertyUnit != null)
            {
                propertyUnitDTO = new PropertyUnitDTO();
                propertyUnitDTO.Id = propertyUnit.Id;
                if (allFields)
                {
                    propertyUnitDTO.PropertyTower = DomainToDTOUtil.convertToPropertyTowerDTO(propertyUnit.PropertyTower, false);
                    propertyUnitDTO.UnitType = DomainToDTOUtil.convertToMasterControlDTO(propertyUnit.UnitType, false);
                    propertyUnitDTO.Wing = propertyUnit.Wing;
                    propertyUnitDTO.FloorNo = propertyUnit.FloorNo;
                    propertyUnitDTO.UnitNo = propertyUnit.UnitNo;
                    propertyUnitDTO.BuildupArea = propertyUnit.BuildupArea;
                    propertyUnitDTO.CarpetArea = propertyUnit.CarpetArea;
                    propertyUnitDTO.BalconyArea = propertyUnit.BalconyArea;
                    propertyUnitDTO.NoOfBalcony = propertyUnit.NoOfBalcony;
                    propertyUnitDTO.Facing = DomainToDTOUtil.convertToMasterControlDTO(propertyUnit.Facing, false);
                    propertyUnitDTO.Status = propertyUnit.Status;
                    propertyUnitDTO.Direction = DomainToDTOUtil.convertToMasterControlDTO(propertyUnit.Direction, false);
                    propertyUnitDTO.FirmNumber = propertyUnit.FirmNumber;
                    propertyUnitDTO.InsertDate = propertyUnit.InsertDate;
                    propertyUnitDTO.UpdateDate = propertyUnit.UpdateDate;
                    propertyUnitDTO.Version = propertyUnit.Version;
                    propertyUnitDTO.InsertUser = propertyUnit.InsertUser;
                    propertyUnitDTO.UpdateUser = propertyUnit.UpdateUser;
                }
            }
            return propertyUnitDTO;
        }
        public static PropertyScheduleDTO convertToPropertyScheduleDTO(PropertySchedule propertySchedule, bool allFields)
        {
            PropertyScheduleDTO propertyScheduleDto = null;
            if (propertySchedule != null)
            {
                propertyScheduleDto = new PropertyScheduleDTO();
                propertyScheduleDto.Id = propertySchedule.Id;
                if (allFields)
                {
                    propertyScheduleDto.PropertyTower = DomainToDTOUtil.convertToPropertyTowerDTO(propertySchedule.PropertyTower, false);
                    propertyScheduleDto.Stage = propertySchedule.Stage;
                    propertyScheduleDto.Percentage = propertySchedule.Percentage;
                    propertyScheduleDto.Status = propertySchedule.Status;
                    propertyScheduleDto.StageNumber = propertySchedule.StageNumber;
                    propertyScheduleDto.FirmNumber = propertySchedule.FirmNumber;
                    propertyScheduleDto.InsertDate = propertySchedule.InsertDate;
                    propertyScheduleDto.UpdateDate = propertySchedule.UpdateDate;
                    propertyScheduleDto.Version = propertySchedule.Version;
                    propertyScheduleDto.InsertUser = propertySchedule.InsertUser;
                    propertyScheduleDto.UpdateUser = propertySchedule.UpdateUser;
                }
            }
            return propertyScheduleDto;
        }

        public static PropertyChargeDTO convertToPropertyChargeDTO(PropertyCharge propertyCharge, bool allFields)
        {
            PropertyChargeDTO propertyChargeDTO = null;
            if (propertyCharge != null)
            {
                propertyChargeDTO = new PropertyChargeDTO();
                propertyChargeDTO.Id = propertyCharge.Id;
                if (allFields)
                {
                    propertyChargeDTO.Property = DomainToDTOUtil.convertToPropertyDTO(propertyCharge.Property, false);
                    propertyChargeDTO.ChargeType = DomainToDTOUtil.convertToMasterControlDTO(propertyCharge.ChargeType, false);
                    propertyChargeDTO.ChargeValue = propertyCharge.ChargeValue;
                    propertyChargeDTO.FirmNumber = propertyCharge.FirmNumber;
                    propertyChargeDTO.InsertDate = propertyCharge.InsertDate;
                    propertyChargeDTO.UpdateDate = propertyCharge.UpdateDate;
                    propertyChargeDTO.Version = propertyCharge.Version;
                    propertyChargeDTO.InsertUser = propertyCharge.InsertUser;
                    propertyChargeDTO.UpdateUser = propertyCharge.UpdateUser;
                }
            }
            return propertyChargeDTO;
        }


        public static PropertyTaxDetailDTO convertToPropertyTaxDetailDTO(PropertyTaxDetail propertyTaxDetail, bool allFields)
        {
            PropertyTaxDetailDTO propertyTaxDetailDto = null;
            if (propertyTaxDetail != null)
            {
                propertyTaxDetailDto = new PropertyTaxDetailDTO();
                propertyTaxDetailDto.Id = propertyTaxDetail.Id;
                if (allFields)
                {
                    propertyTaxDetailDto.Property = DomainToDTOUtil.convertToPropertyDTO(propertyTaxDetail.Property, false);
                    propertyTaxDetailDto.TaxType = DomainToDTOUtil.convertToMasterControlDTO(propertyTaxDetail.TaxType, false);
                    propertyTaxDetailDto.TaxPercentage = propertyTaxDetail.TaxPercentage;
                    propertyTaxDetailDto.IncludeInTotalPymt = propertyTaxDetail.IncludeInTotalPymt;
                    propertyTaxDetailDto.TaxAmtLimit = propertyTaxDetail.TaxAmtLimit;
                    propertyTaxDetailDto.FirmNumber = propertyTaxDetail.FirmNumber;
                    propertyTaxDetailDto.InsertDate = propertyTaxDetail.InsertDate;
                    propertyTaxDetailDto.UpdateDate = propertyTaxDetail.UpdateDate;
                    propertyTaxDetailDto.Version = propertyTaxDetail.Version;
                    propertyTaxDetailDto.InsertUser = propertyTaxDetail.InsertUser;
                    propertyTaxDetailDto.UpdateUser = propertyTaxDetail.UpdateUser;
                }
            }
            return propertyTaxDetailDto;
        }
        public static PrUnitSaleDetailDTO convertToPrUnitSaleDetailDTO(PrUnitSaleDetail prUnitSaleDetail, bool allFields)
        {
            PrUnitSaleDetailDTO prUnitSaleDetailDto = null;
            if (prUnitSaleDetail != null)
            {
                prUnitSaleDetailDto = new PrUnitSaleDetailDTO();
                prUnitSaleDetailDto.Id = prUnitSaleDetail.Id;
                if (allFields)
                {
                    prUnitSaleDetailDto.BookingDate = prUnitSaleDetail.BookingDate;
                    prUnitSaleDetailDto.SaleRate = prUnitSaleDetail.SaleRate;
                    prUnitSaleDetailDto.PossessionDate = prUnitSaleDetail.PossessionDate;
                    prUnitSaleDetailDto.AgreementDate = prUnitSaleDetail.AgreementDate;
                    prUnitSaleDetailDto.LoanBankName = prUnitSaleDetail.LoanBankName;
                    prUnitSaleDetailDto.LoanBankBranch = prUnitSaleDetail.LoanBankBranch;
                    prUnitSaleDetailDto.LoanAmt = prUnitSaleDetail.LoanAmt;
                    prUnitSaleDetailDto.AgreementAmt = prUnitSaleDetail.AgreementAmt;
                    prUnitSaleDetailDto.TotalTaxAmt = prUnitSaleDetail.TotalTaxAmt;
                    prUnitSaleDetailDto.TotalOtherAmt = prUnitSaleDetail.TotalOtherAmt;
                    prUnitSaleDetailDto.TotalPymtAmt = prUnitSaleDetail.TotalPymtAmt;
                    prUnitSaleDetailDto.TotalCashAmt = prUnitSaleDetail.TotalCashAmt;
                    prUnitSaleDetailDto.TotalPackageCost = prUnitSaleDetail.TotalPackageCost;
                    prUnitSaleDetailDto.CanellationDate = prUnitSaleDetail.CanellationDate;
                    prUnitSaleDetailDto.CancellationFee = prUnitSaleDetail.CancellationFee;
                    prUnitSaleDetailDto.CancellationReason = prUnitSaleDetail.CancellationReason;
                    prUnitSaleDetailDto.Status = prUnitSaleDetail.Status;
                    prUnitSaleDetailDto.FirmNumber = prUnitSaleDetail.FirmNumber;
                    prUnitSaleDetailDto.InsertDate = prUnitSaleDetail.InsertDate;
                    prUnitSaleDetailDto.UpdateDate = prUnitSaleDetail.UpdateDate;
                    prUnitSaleDetailDto.Version = prUnitSaleDetail.Version;
                    prUnitSaleDetailDto.InsertUser = prUnitSaleDetail.InsertUser;
                    prUnitSaleDetailDto.UpdateUser = prUnitSaleDetail.UpdateUser;
                    prUnitSaleDetailDto.PropertyUnit = DomainToDTOUtil.convertToPropertyUnitDTO(prUnitSaleDetail.PropertyUnit, false);
                    prUnitSaleDetailDto.Customer = DomainToDTOUtil.convertToCustomerDTO(prUnitSaleDetail.Customer, false);
                    prUnitSaleDetailDto.FirmMember = DomainToDTOUtil.convertToFirmMemberDTO(prUnitSaleDetail.FirmMember, false);
                    prUnitSaleDetailDto.CancellationFirmMember = DomainToDTOUtil.convertToFirmMemberDTO(prUnitSaleDetail.CancellationFirmMember, false);
                    prUnitSaleDetailDto.PrUnitSalePymts = new HashSet<PrUnitSalePymtDTO>();
                    if (prUnitSaleDetail.PrUnitSalePymts != null && prUnitSaleDetail.PrUnitSalePymts.Count > 0)
                    {
                        foreach (PrUnitSalePymt prUnitSalePymt in prUnitSaleDetail.PrUnitSalePymts)
                        {
                            prUnitSaleDetailDto.PrUnitSalePymts.Add(DomainToDTOUtil.convertToPrUnitSalePymtDTO(prUnitSalePymt, true));
                        }
                    }
                    prUnitSaleDetailDto.PrUnitSaleTaxDetails = new HashSet<PrUnitSaleTaxDetailDTO>();
                    if (prUnitSaleDetail.PrUnitSaleTaxDetails != null && prUnitSaleDetail.PrUnitSaleTaxDetails.Count > 0)
                    {
                        foreach (PrUnitSaleTaxDetail prUnitSaleTaxDetail in prUnitSaleDetail.PrUnitSaleTaxDetails)
                        {
                            prUnitSaleDetailDto.PrUnitSaleTaxDetails.Add(DomainToDTOUtil.convertToPrUnitSaleTaxDetailDTO(prUnitSaleTaxDetail, true));
                        }
                    }
                }
            }
            return prUnitSaleDetailDto;
        }
        public static PrUnitSaleTaxDetailDTO convertToPrUnitSaleTaxDetailDTO(PrUnitSaleTaxDetail propertyTaxDetail, bool allFields)
        {
            PrUnitSaleTaxDetailDTO propertyTaxDetailDto = null;
            if (propertyTaxDetail != null)
            {
                propertyTaxDetailDto = new PrUnitSaleTaxDetailDTO();
                propertyTaxDetailDto.Id = propertyTaxDetail.Id;
                if (allFields)
                {
                    propertyTaxDetailDto.PrUnitSaleDetail = DomainToDTOUtil.convertToPrUnitSaleDetailDTO(propertyTaxDetail.PrUnitSaleDetail, false);
                    propertyTaxDetailDto.TaxType = DomainToDTOUtil.convertToMasterControlDTO(propertyTaxDetail.TaxType, false);
                    propertyTaxDetailDto.TaxPercentage = propertyTaxDetail.TaxPercentage;
                    propertyTaxDetailDto.IncludeInTotalPymt = propertyTaxDetail.IncludeInTotalPymt;
                    propertyTaxDetailDto.TaxAmtLimit = propertyTaxDetail.TaxAmtLimit;
                    propertyTaxDetailDto.TaxAmt = propertyTaxDetail.TaxAmt;
                    propertyTaxDetailDto.FirmNumber = propertyTaxDetail.FirmNumber;
                    propertyTaxDetailDto.InsertDate = propertyTaxDetail.InsertDate;
                    propertyTaxDetailDto.UpdateDate = propertyTaxDetail.UpdateDate;
                    propertyTaxDetailDto.Version = propertyTaxDetail.Version;
                    propertyTaxDetailDto.InsertUser = propertyTaxDetail.InsertUser;
                    propertyTaxDetailDto.UpdateUser = propertyTaxDetail.UpdateUser;
                }
            }
            return propertyTaxDetailDto;
        }
        
        public static PrUnitSalePymtDTO convertToPrUnitSalePymtDTO(PrUnitSalePymt prUnitSalePymt, bool allFields)
        {
            PrUnitSalePymtDTO prUnitSalePymtDto = null;
            if (prUnitSalePymt != null)
            {
                prUnitSalePymtDto = new PrUnitSalePymtDTO();
                prUnitSalePymtDto.Id = prUnitSalePymt.Id;
                if (allFields)
                {
                    prUnitSalePymtDto.PrUnitSaleDetail = DomainToDTOUtil.convertToPrUnitSaleDetailDTO(prUnitSalePymt.PrUnitSaleDetail, false);
                    prUnitSalePymtDto.PaymentMaster = DomainToDTOUtil.convertToPaymentMasterDTO(prUnitSalePymt.PaymentMaster, true, false);
                    prUnitSalePymtDto.PymtType = DomainToDTOUtil.convertToMasterControlDTO(prUnitSalePymt.PymtType, false);
                    prUnitSalePymtDto.PymtDate = prUnitSalePymt.PymtDate;
                    prUnitSalePymtDto.PymtAmt = prUnitSalePymt.PymtAmt;
                    prUnitSalePymtDto.PymtTo = prUnitSalePymt.PymtTo;
                    prUnitSalePymtDto.Description = prUnitSalePymt.Description;
                    prUnitSalePymtDto.FirmNumber = prUnitSalePymt.FirmNumber;
                    prUnitSalePymtDto.InsertDate = prUnitSalePymt.InsertDate;
                    prUnitSalePymtDto.UpdateDate = prUnitSalePymt.UpdateDate;
                    prUnitSalePymtDto.Version = prUnitSalePymt.Version;
                    prUnitSalePymtDto.InsertUser = prUnitSalePymt.InsertUser;
                    prUnitSalePymtDto.UpdateUser = prUnitSalePymt.UpdateUser;
                }
            }
            return prUnitSalePymtDto;
        }
        public static PaymentMasterDTO convertToPaymentMasterDTO(PaymentMaster paymentMaster, bool allFields, bool fetchTransactions)
        {
        	PaymentMasterDTO paymentMasterDto = null;
        	if (paymentMaster != null)
        	{
        		paymentMasterDto = new PaymentMasterDTO();
        		paymentMasterDto.Id = paymentMaster.Id;
        		if (allFields)
        		{
        			paymentMasterDto.TotalAmt = paymentMaster.TotalAmt;
        			paymentMasterDto.TotalPaid = paymentMaster.TotalPaid;
        			paymentMasterDto.TotalPending = paymentMaster.TotalPending;
        			paymentMasterDto.TotalPdcAmt = paymentMaster.TotalPdcAmt;
        			paymentMasterDto.Status = paymentMaster.Status;
        			paymentMasterDto.FirmNumber = paymentMaster.FirmNumber;
        			paymentMasterDto.InsertDate = paymentMaster.InsertDate;
        			paymentMasterDto.UpdateDate = paymentMaster.UpdateDate;
        			paymentMasterDto.Version = paymentMaster.Version;
        			paymentMasterDto.InsertUser = paymentMaster.InsertUser;
        			paymentMasterDto.UpdateUser = paymentMaster.UpdateUser;
        			paymentMasterDto.PaymentTransactions = new HashSet<PaymentTransactionDTO>();
                    if (fetchTransactions)
                    {
                        if (paymentMaster.PaymentTransactions != null && paymentMaster.PaymentTransactions.Count > 0)
                        {
                            foreach (PaymentTransaction paymentTransaction in paymentMaster.PaymentTransactions)
                            {
                                paymentMasterDto.PaymentTransactions.Add(DomainToDTOUtil.convertToPaymentTransactionDTO(paymentTransaction, true));
                            }
                        }
                    }
        		}
        	}
        	return paymentMasterDto;
        }
        public static PostDatedChequeDTO convertToPDCDTO(PostDatedCheque pdc, bool allFields)
        {
            PostDatedChequeDTO pdcDto = null;
            if (pdc != null)
            {
                pdcDto = new PostDatedChequeDTO();
                pdcDto.Id = pdc.Id;
                if (allFields)
                {
                    pdcDto.CollectionDate = pdc.CollectionDate;
                    pdcDto.ChequeDate = pdc.ChequeDate;
                    pdcDto.PymtAmt = pdc.PymtAmt;
                    pdcDto.BankName = pdc.BankName;
                    pdcDto.Branch = pdc.Branch;
                    pdcDto.ChequeNo = pdc.ChequeNo;
                    pdcDto.ChequeStatus = pdc.ChequeStatus;
                    pdcDto.Description = pdc.Description;
                    pdcDto.PymtStatus = pdc.PymtStatus;
                    pdcDto.ClearanceDate = pdc.ClearanceDate;
                    pdcDto.FirmAccount = DomainToDTOUtil.convertToFirmAccountDTO(pdc.FirmAccount, false);
                    pdcDto.PrTower = DomainToDTOUtil.convertToPropertyTowerDTO(pdc.PrTower, false);
                    pdcDto.PdcFrom = DomainToDTOUtil.convertToPdcBookDTO(pdc.PdcFrom);
                    pdcDto.PdcTo = DomainToDTOUtil.convertToPdcBookDTO(pdc.PdcTo);
                    
                    pdcDto.FirmNumber = pdc.FirmNumber;
                    pdcDto.InsertDate = pdc.InsertDate;
                    pdcDto.UpdateDate = pdc.UpdateDate;
                    pdcDto.Version = pdc.Version;
                    pdcDto.InsertUser = pdc.InsertUser;
                    pdcDto.UpdateUser = pdc.UpdateUser;
                    pdcDto.PaymentTransactions = new HashSet<PaymentTransactionDTO>();
                    if (pdc.PaymentTransactions != null && pdc.PaymentTransactions.Count > 0)
                    {
                        foreach (PaymentTransaction paymentTransaction in pdc.PaymentTransactions)
                        {
                            pdcDto.PaymentTransactions.Add(DomainToDTOUtil.convertToPaymentTransactionDTO(paymentTransaction, true));
                        }
                    }
                }
            }
            return pdcDto;
        }
        public static PdcBookDTO convertToPdcBookDTO(PdcBook pdcBook)
        {
            PdcBookDTO pdcBookDto = null;
            if (pdcBook != null) {
                pdcBookDto = new PdcBookDTO();
                pdcBookDto.Id = pdcBook.Id;
            }
            return pdcBookDto;
        }
        public static PaymentTransactionDTO convertToPaymentTransactionDTO(PaymentTransaction paymentTransaction, bool allFields)
        {
        	PaymentTransactionDTO paymentTransactionDto = null;
        	if (paymentTransaction != null)
        	{
        		paymentTransactionDto = new PaymentTransactionDTO();
        		paymentTransactionDto.Id = paymentTransaction.Id;
        		if (allFields)
        		{
                    paymentTransactionDto.TxDate = paymentTransaction.TxDate;
        			paymentTransactionDto.Amount = paymentTransaction.Amount;
        			paymentTransactionDto.Status = paymentTransaction.Status;
        			paymentTransactionDto.PymtMode = paymentTransaction.PymtMode;
        			paymentTransactionDto.BankName = paymentTransaction.BankName;
        			paymentTransactionDto.Branch = paymentTransaction.Branch;
        			paymentTransactionDto.ChequeNo = paymentTransaction.ChequeNo;
                    paymentTransactionDto.ChequeDate = paymentTransaction.ChequeDate;
                    paymentTransactionDto.Comments = paymentTransaction.Comments;
        			paymentTransactionDto.FirmNumber = paymentTransaction.FirmNumber;
        			paymentTransactionDto.InsertDate = paymentTransaction.InsertDate;
        			paymentTransactionDto.UpdateDate = paymentTransaction.UpdateDate;
        			paymentTransactionDto.Version = paymentTransaction.Version;
        			paymentTransactionDto.InsertUser = paymentTransaction.InsertUser;
        			paymentTransactionDto.UpdateUser = paymentTransaction.UpdateUser;
        			paymentTransactionDto.AccountTransaction = DomainToDTOUtil.convertToAccountTransactionDTO(paymentTransaction.AccountTransaction, false);
        			paymentTransactionDto.PaymentMaster = DomainToDTOUtil.convertToPaymentMasterDTO(paymentTransaction.PaymentMaster, false, false);
        			paymentTransactionDto.CancelledPaymentTransaction = DomainToDTOUtil.convertToPaymentTransactionDTO(paymentTransaction.CancelledPaymentTransaction, false);
        		}
        	}
        	return paymentTransactionDto;
        }
        public static AccountTransactionDTO convertToAccountTransactionDTO(AccountTransaction accountTransaction, bool allFields)
        {
        	AccountTransactionDTO accountTransactionDto = null;
        	if (accountTransaction != null)
        	{
        		accountTransactionDto = new AccountTransactionDTO();
        		accountTransactionDto.Id = accountTransaction.Id;
                accountTransactionDto.FirmAccount = DomainToDTOUtil.convertToFirmAccountDTO(accountTransaction.FirmAccount, false);
        		if (allFields)
        		{
        			accountTransactionDto.TxDate = accountTransaction.TxDate;
        			accountTransactionDto.Amount = accountTransaction.Amount;
        			accountTransactionDto.TxType = accountTransaction.TxType;
        			accountTransactionDto.Comments = accountTransaction.Comments;
        			accountTransactionDto.FirmNumber = accountTransaction.FirmNumber;
        			accountTransactionDto.InsertDate = accountTransaction.InsertDate;
        			accountTransactionDto.UpdateDate = accountTransaction.UpdateDate;
        			accountTransactionDto.Version = accountTransaction.Version;
        			accountTransactionDto.InsertUser = accountTransaction.InsertUser;
        			accountTransactionDto.UpdateUser = accountTransaction.UpdateUser;
        		}
        	}
        	return accountTransactionDto;
        }
        public static FirmMemberDTO convertToFirmMemberDTO(FirmMember firmMember, bool allFields)
        {
            FirmMemberDTO firmMemberDto = null;
            if (firmMember != null)
            {
                firmMemberDto = new FirmMemberDTO();
                firmMemberDto.EmployeeId = firmMember.EmployeeId;
                firmMemberDto.Id = firmMember.Id;
                firmMemberDto.Salutation = DomainToDTOUtil.convertToMasterControlDTO(firmMember.Salutation, false);
                firmMemberDto.FirstName = firmMember.FirstName;
                firmMemberDto.MiddleName = firmMember.MiddleName;
                firmMemberDto.LastName = firmMember.LastName;
                if (allFields)
                {
                    firmMemberDto.JoiningDate = firmMember.JoiningDate;
                    firmMemberDto.Qualification = firmMember.Qualification;
                    firmMemberDto.Description = firmMember.Description;
                    firmMemberDto.FirmNumber = firmMember.FirmNumber;
                    firmMemberDto.ContactInfo = DomainToDTOUtil.convertToContactInfoDTO(firmMember.ContactInfo);
                    firmMemberDto.Department = DomainToDTOUtil.convertToDepartmentDTO(firmMember.Department, false);
                    firmMemberDto.Designation = DomainToDTOUtil.convertToMasterControlDTO(firmMember.Designation, false);
                    firmMemberDto.InsertDate = firmMember.InsertDate;
                    firmMemberDto.UpdateDate = firmMember.UpdateDate;
                    firmMemberDto.Version = firmMember.Version;
                    firmMemberDto.InsertUser = firmMember.InsertUser;
                    firmMemberDto.UpdateUser = firmMember.UpdateUser;
                }
            }
            return firmMemberDto;
        }
        public static FirmAcntDepositeDTO convertToFirmAcntDepositeDTO(FirmAcntDeposite firmAcntDeposite, bool allFields)
        {
            FirmAcntDepositeDTO firmAcntDepositeDto = null;
            if (firmAcntDeposite != null)
            {
                firmAcntDepositeDto = new FirmAcntDepositeDTO();
                firmAcntDepositeDto.Id = firmAcntDeposite.Id;
                if (allFields)
                {
                    firmAcntDepositeDto.DepositeDate = firmAcntDeposite.DepositeDate;
                    firmAcntDepositeDto.Amount = firmAcntDeposite.Amount;
                    firmAcntDepositeDto.PymtMode = firmAcntDeposite.PymtMode;
                    firmAcntDepositeDto.BankName = firmAcntDeposite.BankName;
                    firmAcntDepositeDto.ChequeNo = firmAcntDeposite.ChequeNo;
                    firmAcntDepositeDto.ChequeDate = firmAcntDeposite.ChequeDate;
                    firmAcntDepositeDto.Description = firmAcntDeposite.Description;
                    firmAcntDepositeDto.Status = firmAcntDeposite.Status;
                    firmAcntDepositeDto.FirmNumber = firmAcntDeposite.FirmNumber;
                    firmAcntDepositeDto.InsertDate = firmAcntDeposite.InsertDate;
                    firmAcntDepositeDto.UpdateDate = firmAcntDeposite.UpdateDate;
                    firmAcntDepositeDto.Version = firmAcntDeposite.Version;
                    firmAcntDepositeDto.InsertUser = firmAcntDeposite.InsertUser;
                    firmAcntDepositeDto.UpdateUser = firmAcntDeposite.UpdateUser;
                    //firmAcntDepositeDto.FirmAccount = DomainToDTOUtil.convertToFirmAccountDTO(firmAcntDeposite.a, false);
                    //TODO - Load Transaction
                }
            }
            return firmAcntDepositeDto;
        }
        public static MasterControlDataDTO convertToMasterControlDTO(MasterControlData masterControlData, bool allFields)
        {
            //Populate only basic fields, if allFields is true then only copy all fields.
            MasterControlDataDTO masterControlDataDto = null;
            if (masterControlData != null)
            {
                masterControlDataDto = new MasterControlDataDTO();
                masterControlDataDto.Id = masterControlData.Id;
                masterControlDataDto.Name = masterControlData.Name;
                if (allFields)
                {
                    masterControlDataDto.Type = masterControlData.Type;
                    masterControlDataDto.Description = masterControlData.Description;
                    masterControlDataDto.SystemDefined = masterControlData.SystemDefined;
                    masterControlDataDto.UpdateDate = masterControlData.UpdateDate;
                    masterControlDataDto.Version = masterControlData.Version;
                    masterControlDataDto.InsertUser = masterControlData.InsertUser;
                    masterControlDataDto.UpdateUser = masterControlData.UpdateUser;
                }
            }
            return masterControlDataDto;
        }
        public static CountryDTO convertToCountryDTO(Country country, bool allFields)
        {
            //Populate only basic fields, if allFields is true then only copy all fields.
            CountryDTO countryDto = null;
            if (country != null)
            {
                countryDto = new CountryDTO();
                countryDto.Id = country.Id;
                countryDto.Name = country.Name;
                countryDto.Abbreviation = country.Abbreviation;
            }
            return countryDto;
        }
        public static StateDTO convertToStateDTO(State state, bool allFields)
        {
            //Populate only basic fields, if allFields is true then only copy all fields.
            StateDTO stateDto = null;
            if (state != null)
            {
                stateDto = new StateDTO();
                stateDto.Id = state.Id;
                stateDto.Name = state.Name;
                stateDto.Abbreviation = state.Abbreviation;
            }
            return stateDto;
        }
        public static CityDTO convertToCityDTO(City city, bool allFields)
        {
            //Populate only basic fields, if allFields is true then only copy all fields.
            CityDTO cityDto = null;
            if (city != null)
            {
                cityDto = new CityDTO();
                cityDto.Id = city.Id;
                cityDto.Name = city.Name;
                cityDto.Abbreviation = city.Abbreviation;
            }
            return cityDto;
        }
        //Customer
        public static CustomerDTO convertToCustomerDTO(Customer customer, bool allFields)
        {
            CustomerDTO customerDto = null;
            if (customer != null)
            {
                customerDto = new CustomerDTO();
                customerDto.Id = customer.Id;
                customerDto.Salutation = DomainToDTOUtil.convertToMasterControlDTO(customer.Salutation, false);
                customerDto.FirstName = customer.FirstName;
                customerDto.MiddleName = customer.MiddleName;
                customerDto.LastName = customer.LastName;
                if (allFields)
                {
                    customerDto.Pan = customer.Pan;
                    customerDto.Occupation = DomainToDTOUtil.convertToMasterControlDTO(customer.Occupation, false);
                    customerDto.ContactInfo = DomainToDTOUtil.convertToContactInfoDTO(customer.ContactInfo);
                    customerDto.DocumentInfo = DomainToDTOUtil.convertToDocumentInfoDTO(customer.DocumentInfo);
                    customerDto.CoCustomers = new HashSet<CoCustomerDTO>();
                    if (customer.CoCustomers != null && customer.CoCustomers.Count > 0)
                    {
                        foreach (CoCustomer coCustomer in customer.CoCustomers)
                        {
                            customerDto.CoCustomers.Add(DomainToDTOUtil.convertToCocustomerDTO(coCustomer));
                        }
                    }
                    customerDto.InsertDate = customer.InsertDate;
                    customerDto.UpdateDate = customer.UpdateDate;
                    customerDto.Version = customer.Version;
                    customerDto.InsertUser = customer.InsertUser;
                    customerDto.UpdateUser = customer.UpdateUser;
                }
            }
            return customerDto;
        }

        public static CoCustomerDTO convertToCocustomerDTO(CoCustomer cocustomer)
        {
            CoCustomerDTO coCustomerDto = null;
            if (cocustomer != null)
            {
                coCustomerDto = new CoCustomerDTO();
                coCustomerDto.Id = cocustomer.Id;
                coCustomerDto.SalutationId = DomainToDTOUtil.convertToMasterControlDTO(cocustomer.SalutationId, false);
                coCustomerDto.FirstName = cocustomer.FirstName;
                coCustomerDto.MiddleName = cocustomer.MiddleName;
                coCustomerDto.LastName = cocustomer.LastName;
                coCustomerDto.RelationWhPrimCust = DomainToDTOUtil.convertToMasterControlDTO(cocustomer.RelationWhPrimCust, false);
                coCustomerDto.Occupation = DomainToDTOUtil.convertToMasterControlDTO(cocustomer.Occupation, false);
                coCustomerDto.Pan = cocustomer.Pan;
                coCustomerDto.IsPoa = cocustomer.IsPoa;
                coCustomerDto.FirmNumber = cocustomer.FirmNumber;
                coCustomerDto.ContactInfo = DomainToDTOUtil.convertToContactInfoDTO(cocustomer.ContactInfo);
            }
            return coCustomerDto;
        }

        public static PropertyExpenseDTO convertToPropertyExpenseDTO(PropertyExpense propertyExpense)
        {
            PropertyExpenseDTO propertyExpenseDTO = null;
            if (propertyExpense != null)
            {
                propertyExpenseDTO = new PropertyExpenseDTO();
                propertyExpenseDTO.Id = propertyExpense.Id;
                propertyExpenseDTO.Property = DomainToDTOUtil.convertToPropertyDTO(propertyExpense.Property, false);
                propertyExpenseDTO.Agency = DomainToDTOUtil.convertToMasterControlDTO(propertyExpense.Agency, false);
                propertyExpenseDTO.ExpenseDate = propertyExpense.ExpenseDate;
                propertyExpenseDTO.ExpenseType = DomainToDTOUtil.convertToMasterControlDTO(propertyExpense.ExpenseType, false);
                propertyExpenseDTO.FirmMember = DomainToDTOUtil.convertToFirmMemberDTO(propertyExpense.FirmMember, false);
                propertyExpenseDTO.Amount = propertyExpense.Amount;
                propertyExpenseDTO.Comments = propertyExpense.Comments;
                //propertyExpenseDTO.PaymentMaster = DomainToDTOUtil.convertToPaymentMasterDTO(propertyExpense.PaymentMaster, false);
                //propertyExpenseDTO.DocumentInfo = DomainToDTOUtil.convertToDocumentInfoDTO(propertyExpense.DocumentInfo, false);
                propertyExpenseDTO.FirmNumber = propertyExpense.FirmNumber;
                propertyExpenseDTO.InsertDate = propertyExpense.InsertDate;
                propertyExpenseDTO.UpdateDate = propertyExpense.UpdateDate;
                propertyExpenseDTO.Version = propertyExpense.Version;
                propertyExpenseDTO.InsertUser = propertyExpense.InsertUser;
                propertyExpenseDTO.UpdateUser = propertyExpense.UpdateUser;
            }
            return propertyExpenseDTO;
        }

        public static DocumentInfoDTO convertToDocumentInfoDTO(DocumentInfo documentInfo)
        {
            DocumentInfoDTO documentInfoDTO = null;
            if (documentInfo != null)
            {
                documentInfoDTO = new DocumentInfoDTO();
                documentInfoDTO.Id = documentInfo.Id;
                documentInfoDTO.Description = documentInfo.Description;
                documentInfoDTO.Documents = new HashSet<DocumentDTO>();
                if (documentInfo.Documents != null && documentInfo.Documents.Count > 0)
                {
                    foreach (Document document in documentInfo.Documents)
                    {
                        documentInfoDTO.Documents.Add(DomainToDTOUtil.convertToDocumentDTO(document));
                    }
                }
            }
            return documentInfoDTO;
        }
        public static DocumentDTO convertToDocumentDTO(Document document)
        {
            DocumentDTO documentDTO = null;
            if (document != null)
            {
                documentDTO = new DocumentDTO();
                documentDTO.Id = document.Id;
                documentDTO.Name = document.Name;
                documentDTO.Description = document.Description;
                documentDTO.DocumentType = DomainToDTOUtil.convertToMasterControlDTO(document.DocumentType, false);
                documentDTO.Content = document.Content;
                documentDTO.ContentType = document.ContentType;
                documentDTO.FileName = document.FileName;
                documentDTO.Extension = document.Extension;
                documentDTO.FirmNumber = document.FirmNumber;
                documentDTO.InsertDate = document.InsertDate;
                documentDTO.InsertUser = document.InsertUser;
                documentDTO.UpdateUser = document.UpdateUser;
                documentDTO.UpdateDate = document.UpdateDate;
                documentDTO.Version = document.Version;

            }
            return documentDTO;
        }

    }
}