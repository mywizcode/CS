﻿
/// <summary>
/// Summary description for MyENUM
/// </summary>

using System;
using System.ComponentModel;
namespace ConstroSoft
{
    /*ENUMs which are used to map Only UI fields*/
    public enum DrpDataType
    {
        MASTER_CONTROL_DATA,////Fetch all records for given type
        MASTER_CONTROL_DATA_N,//Fetch records for given type with SYSTEM_DEFINED = "N"
        COUNTRY,
        STATE,
        CITY,
        ENQUIRY_STATUS,
        ENQUIRY_CUSTOMER_NAME,
        EMPLOYEE_SEARCH_BY_NAME,
        EMPLOYEE_SEARCH_BY_ID,
        GENDER,
        MARITAL_STATUS,
        PROPERTY_NAME,
        EMPLOYEE_NAME,
        DEPARTMENT,
        PREFERRED_ADDRESS,
        PROPERTY_SEARCH_BY_NAME,
        PROPERTY_SEARCH_BY_TYPE,
        PROPERTY_SEARCH_BY_LOCATION,
        PYMT_SEARCH_BY_CUSTOMER_NAME,
        PYMT_SEARCH_BY_UNITNO,
        FIRM_ACCOUNT,
        PROPERTY_TOWER,
        RELATION_WITH_CUSTOMER,
        PROPERTY_UNIT,
        FLAT_NO,
        UNIT,
        PROPERTYUNITSTATUS,
        WING,
        CUSTOMER_SEARCH_BY_NAME,
		PROPERTY_UNIT_TYPE,
        AVAIL_UNIT_SEARCH_BY_PR_UNIT,
        PROPERTY_UNIT_FLOOR,
		PARKING_TYPE,	    
        PROPERTY_LOCATION,
        PROPERTY_TYPE,  
        AGENCY,
        PDC_FIRM,
        PDC_DRAWER_CUSTOMER,
        PDC_PAYEE_CUSTOMER,
        PROPERTY_CHARGES
    }
    public enum PageMode { ADD, MODIFY, VIEW,GETQUOTE, NONE }
    public enum EnquirySearchBy 
    {
        [Description("-Select-")]NONE, 
        [Description("Customer Name")]CUSTOMER_NAME,
        [Description("Property Name")] PROP_NAME, 
        [Description("Property Type")] PROP_TYPE,
        [Description("Property Location")] PROP_LOCATION,
        [Description("Property Unit Type")] PROP_UNIT_TYPE,
        [Description("Employee Name")] EMPLOYEE_NAME,
        [Description("Enquiry Source")] ENQUIRY_SOURCE
    }
    public enum EmployeeSearchBy
    {
        [Description("--Select--")]
        NONE,
        [Description("Employee Name")]
        EMPLOYEE_NAME,
        [Description("Employee Id")]
        EMPLOYEE_ID,
        [Description("Department")]
        DEPARTMENT
    }
    public enum PropertySearchBy
    {
        [Description("--Select--")]
        NONE,
        [Description("Property Name")]
        PROPERTY_NAME,
        [Description("Property Type")]
        PROPERTY_TYPE,
        [Description("Property Location")]
        PROPERTY_LOCATION
    }
 public enum ExpencessSearchBy
    {
        [Description("--Select--")]
        NONE,
        [Description("Property Name")]
        PROPERTY_NAME,
        [Description("Property Type")]
        PROPERTY_TYPE,
        [Description("Property Location")]
        PROPERTY_LOCATION
    }
    //Customer
    public enum CustomerSearchBy
    {
        [Description("--Select--")]
        NONE,
        [Description("Customer Name")]
        Customer_Name
    }
    public enum AccountNoSearchBy
    {
        [Description("--Select--")]
        NONE,
        [Description("Account Number")]
        Account_Number
    }

    //Property  Unit Search By
    public enum PropertyUnitSearchBy
    {
        [Description("--Select--")]
        NONE,
        [Description("Wing")]
        WING,
        [Description("Unit")]
        UNIT,
        [Description("Unit Type")]
        UNIT_TYPE,
        [Description("Flat No")]
        FLAT_NO,
        [Description("STATUS")]
        PROPERTYUNITSTATUS,
        
    }
    public enum AvailableUnitSearchBy
    {
        [Description("--Select--")]
        NONE,
        [Description("Property Unit")]
        PROPERTY_UNIT,
        [Description("Unit Type")]
        UNIT_TYPE,
        [Description("Floor")]
        FLOOR,
        [Description("Facing")]
        FACING,
        [Description("Direction")]
        DIRECTION
    }
    public enum SoldUnitSearchBy
    {
        [Description("--Select--")]
        NONE,
        [Description("Property Unit")]
        PROPERTY_UNIT,
        [Description("Unit Type")]
        UNIT_TYPE,
        [Description("Customer")]
        CUSTOMER,
        [Description("Employee")]
        EMPLOYEE
    }
    public enum PaymentFromSearchBy
    {
        [Description("--Select--")]
        NONE,
        [Description("Firm")]
        FIRM,
        [Description("Customer")]
        CUSTOMER
    }
    public enum PaymentToSearchBy
    {
        [Description("--Select--")]
        NONE,
        [Description("Firm")]
        FIRM,
        [Description("Customer")]
        CUSTOMER,
        [Description("Contractor")]
        CONTRACTOR,
        [Description("Supplier")]
        SUPPLIER,
        [Description("Agency")]
        AGENCY
    }
    public enum PaymentSearchBy
    {
        [Description("--Select--")]
        NONE,
        [Description("Customer Name")]
        CUSTOMER_NAME,
        [Description("Unit No")]
        UNIT_NO
    }


    /*ENUMs which are used to map DB and UI fields. NOTE: If you add/remove any value then you need to modify corresponding DB mapping in EnumDBHelper.cs*/
    public enum UserStatus { Active, InActive }
    public enum PreferredAddress { Yes, No }
    public enum MaritalStatus { Single, Married }
    public enum Gender { Male, Female }
    public enum EnquiryStatus { Open, Closed }
	public enum PowerOfAtorny { Yes, No }
    public enum SystemDefined { Yes, No }
    public enum CommonParking { Yes, No }    
    public enum ParkingStatus { Available, Reserved, Allotted }
    public enum PRScheduleStageStatus { Pending, Completed }
    public enum IncludeInPymtTotal { Yes, No }
    public enum PRUnitStatus { Available, Reserved, Sold, Deleted }
    public enum PRUnitSaleStatus { Sold, Cancelled }
    public enum PRUnitSalePymtTo
    {
        [Description("--Select--")]
        NONE,
        [Description("Builder")]
        Builder,
        [Description("Customer")]
        Customer
    }
    public enum PymtTransStatus { Pending, Paid, Deleted, Reversal }
    public enum PdcChequeStatus { Collected, Deposited, Paid, Bounced }
    public enum PdcPymtStatus { Pending, Paid, Deleted }
    public enum PymtMasterStatus
    {
        [Description("Paid")]
        Paid,
        [Description("Pending")]
        Pending,
        [Description("Deleted")]
        Deleted,
        [Description("Suspended")]
        Suspended
    }
    public enum PaymentMode
    {
        [Description("--Select--")]
        NONE,
        [Description("Cheque")]
        CHEQUE,
        [Description("Cash")]
        CASH,
        [Description("RTGS")]
        RTGS,
        [Description("NEFT")]
        NEFT,
        [Description("Demand Draft")]
        DD
    }
    public enum AcntTransStatus { Credit, Debit }

    public enum DocumentOwner
    {
        [Description("--Select--")]
        NONE,
        [Description("Property Name")]
        PROPERTY_NAME,
        [Description("Customer Name")]
        CUSTOMER_NAME,
        [Description("Supplier Name")]
        SUPPLIER_NAME,
        [Description("Contractor Name")]
        CONTACTOR_NAME,
        [Description("Employee Name")]
        EMPLOYEE_NAME
    }

    public enum MasterDataType
    {
        [Description("--Select--")]
        NONE,
        [Description("Salutation")]
        SALUTATION,
        [Description("Address Type")]
        ADDRESS_TYPE,
        [Description("Designation")]
        DESIGNATION,
        [Description("Security Question")]
        SECURITY_QUESTION,
        [Description("Account Type")]
        ACCOUNT_TYPE,
        [Description("Property Type")]
        PROPERTY_TYPE,
        [Description("Property Location")]
        PROPERTY_LOCATION,
        [Description("Property Tax Type")]
        PR_TAX_TYPE,
        [Description("Expences Type")]
        PR_EXPENSE_TYPE,
        [Description("Parking Type")]
        PR_PARKING_TYPE,
        [Description("Unit Facing")]
        PR_UNIT_FACING,
        [Description("Occupation")]
        OCCUPATION,
        [Description("Customer Relation")]
        CUSTOMER_RELATION,
        [Description("Unit Payment Type")]
        PR_UNIT_PYMT_TYPE,
        [Description("Purchase Item Quality")]
        PURCHASE_ITEM_QUALITY,
        [Description("Contractor Type")]
        CONTRACTOR_TYPE,
        [Description("Enquiry Source")]
        ENQUIRY_SOURCE,
        [Description("Enquiry Media Type")]
        ENQUIRY_MEDIA_TYPE,
        [Description("Document Type")]
        DOCUMENT_TYPE
    }
}