﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq.Expressions;
using NHibernate.Impl;

/// <summary>
/// Summary description for CustomerBO
/// </summary>
namespace ConstroSoft
{
    public class CustomerBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public CustomerBO() { }

        public IList<CustomerDTO> fetchCustomerGridData(string firmNumber, CustomerSearchBy searchBy, long searchByValue)
        {
            ISession session = null;
            IList<CustomerDTO> result = new List<CustomerDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                Customer cm = null;
                ContactInfo c = null;
                CustomerDTO cmDto = null;
                var proj = Projections.ProjectionList()
                           .Add(Projections.Property(() => cm.Id).WithAlias(() => cmDto.Id))
                           .Add(Projections.SqlFunction("concat",
                                       NHibernateUtil.String,
                                       Projections.Property(() => cm.FirstName),
                                       Projections.Constant(" "),
                                       Projections.Property(() => cm.LastName)
                                   ).WithAlias(() => cm.FirstName))
                           .Add(Projections.Property(() => cm.Pan).WithAlias(() => cmDto.Pan))
                           .Add(Projections.Property(() => c.Contact), "ContactInfo.Contact")
                           .Add(Projections.Property(() => c.AltContact), "ContactInfo.AltContact")
                           .Add(Projections.Property(() => c.Email), "ContactInfo.Email")
                           .Add(Projections.Property(() => c.Gender), "ContactInfo.Gender")
                           .Add(Projections.Property(() => c.Dob), "ContactInfo.Dob")
                           .Add(Projections.Property(() => c.AltEmail), "ContactInfo.AltEmail");
                var query = session.QueryOver<Customer>(() => cm)
                    .Inner.JoinAlias(() => cm.ContactInfo, () => c);
                if (CustomerSearchBy.NONE != searchBy && searchByValue != -1)
                {
                    PropertyProjection prop = null;
                    if (CustomerSearchBy.Customer_Name == searchBy)
                    {
                        prop = CommonUtil.BuildProjection<Customer>(() => cm, x => x.Id);
                    }

                    query.Where(Restrictions.Eq(prop, searchByValue));
                }
                result = query.Where(() => cm.FirmNumber == firmNumber)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<CustomerDTO>()).List<CustomerDTO>();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating dropdown:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public CustomerDTO fetchCustomer(long Id)
        {
            ISession session = null;
            CustomerDTO customerDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Customer customer = session.Get<Customer>(Id);
                        customerDto = DomainToDTOUtil.convertToCustomerDTO(customer, true);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Customer details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return customerDto;
        }
        public long saveCustomer(CustomerDTO customerDto)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Customer customer = DTOToDomainUtil.populateCustomerAddFields(customerDto);
                        session.Save(customer);
                        Id = customer.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Customer details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        public void updateCustomer(CustomerDTO customerDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Customer customer = session.Get<Customer>(customerDto.Id);
                        DTOToDomainUtil.populateCustomerUpdateFields(customer, customerDto);
                        session.Update(customer);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating Customer details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void deleteCustomer(long Id)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Customer customer = session.Get<Customer>(Id);
                        session.Delete(customer);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while deleting Customer details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
    }
}