﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NHibernate;
using NHibernate.Criterion;

namespace ConstroSoft.Logic.BO
{
    public class AccountDepositBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public AccountDepositBO() { }


        public IList<FirmAcntDepositeDTO> fetchAccountDepositGridData(string firmNumber, AccountNoSearchBy searchBy, long searchByValue)
        {
            ISession session = null;
            FirmAcntDeposite p = null;
            IList<FirmAcntDepositeDTO> result = new List<FirmAcntDepositeDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();               
                
                FirmAcntDepositeDTO depositdto = null;
                var proj = Projections.ProjectionList()
                           .Add(Projections.Property(() => depositdto.Id).WithAlias(() => depositdto.Id))
                           .Add(Projections.Property(() => depositdto.Amount).WithAlias(() => depositdto.Amount))
                           .Add(Projections.Property(() => depositdto.BankName).WithAlias(()=>depositdto.BankName))
                           .Add(Projections.Property(() => depositdto.ChequeDate).WithAlias(() => depositdto.ChequeDate))
                           .Add(Projections.Property(() => depositdto.ChequeNo).WithAlias(() => depositdto.ChequeNo))
                           .Add(Projections.Property(() => depositdto.DepositeDate).WithAlias(() => depositdto.DepositeDate))
                           .Add(Projections.Property(() => depositdto.Description).WithAlias(() => depositdto.Description));
                var query = session.QueryOver<FirmAcntDeposite>(() => p);
                 if (AccountNoSearchBy.NONE != searchBy && searchByValue != -1)
                {                   
                      PropertyProjection prop = null;
                    if (AccountNoSearchBy.Account_Number == searchBy)
                    {
                        prop = CommonUtil.BuildProjection<FirmAcntDeposite>(() => p, x => x.Id);
                    }                   
                    query.Where(Restrictions.Eq(prop, searchByValue));
                }
                result = query.Where(() => p.FirmNumber == firmNumber)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<FirmAcntDeposite>()).List<FirmAcntDepositeDTO>();            
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating dropdown:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }

        public FirmAcntDepositeDTO fetchDeposit(long Id)
        {
            ISession session = null;
            FirmAcntDepositeDTO accountDepositDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        FirmAcntDeposite firmaccount = session.Get<FirmAcntDeposite>(Id);
                       // accountDepositDto = DomainToDTOUtil.convertToFirmAcntDepositeDTO(firmaccount);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Account Deposit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return accountDepositDto;
        }

        public void deleteDeposit(long Id)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        FirmAcntDeposite accountDeposit = session.Get<FirmAcntDeposite>(Id);
                        session.Delete(accountDeposit);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while deleting Account Deposit:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }

        public long saveDeposit(FirmAcntDepositeDTO depositDto)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        FirmAcntDeposite acctDeposit = DTOToDomainUtil.populateAccountDepositAddFields(depositDto); 
                        session.Save(acctDeposit);
                        Id = acctDeposit.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Account Deposit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }

    }

}