﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NHibernate;
using NHibernate.Criterion;

namespace ConstroSoft.Logic.BO
{

    public class PropertyUnitManagementBO
    {
        private static readonly log4net.ILog log =
             log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public PropertyUnitManagementBO() { }


        //public IList<PropertyUnitDTO> fetchPropertyUnitGridData(string firmNumber, PropertyUnitSearchBy searchBy, long searchByValue, long propertyTowerId)
        //{
        //    ISession session = null;
        //    IList<PropertyUnitDTO> results = null;
        //    try
        //    {
        //        session = NHibertnateSession.OpenSession();
        //        PropertyUnitDTO puDto = null;
        //        PropertyUnit fm = null;
        //        PropertyTower en = null;
        //        MasterControlData dg = null;
        //        MasterControlData dgd = null;
        //        MasterControlData dgf = null;
        //        Property pr = null;

        //        var proj = Projections.ProjectionList()
        //                    .Add(Projections.Property(() => fm.Id).WithAlias(() => puDto.Id))
        //                    .Add(Projections.Property(() => dg.Name), "UnitTypeId.Name")
        //                    .Add(Projections.Property(() => fm.UnitNo).WithAlias(() => puDto.UnitNo))
        //                    .Add(Projections.Property(() => fm.FloorNo).WithAlias(() => puDto.FloorNo))
        //                    .Add(Projections.Property(() => fm.BuildupArea).WithAlias(() => puDto.BuildupArea))
        //                    .Add(Projections.Property(() => dgd.Name), "Direction.Name")
        //                    .Add(Projections.Property(() => fm.Status).WithAlias(() => puDto.Status))
        //                    .Add(Projections.Property(() => dgf.Name), "Facing.Name");
        //        var query = session.QueryOver<PropertyUnit>(() => fm)
        //      .Left.JoinAlias(() => fm.UnitTypeId, () => dg)
        //      .Left.JoinAlias(() => fm.Direction, () => dgd)
        //      .Left.JoinAlias(() => fm.Facing, () => dgf)
        //      .Left.JoinAlias(() => fm.PropertyTower, () => en);

        //        if (PropertyUnitSearchBy.NONE != searchBy && searchByValue != -1)
        //        {
        //            PropertyProjection prop = null;
        //            if (PropertyUnitSearchBy.FLAT_NO == searchBy)
        //            {
        //                query.Left.JoinAlias(() => fm.FloorNo, () => dg);
        //                prop = CommonUtil.BuildProjection<MasterControlData>(() => dg, x => x.Id);
        //            }
        //            else if (PropertyUnitSearchBy.PROPERTY_UNIT_STATUS == searchBy)
        //            {
        //                query.Left.JoinAlias(() => fm.Status, () => dg);
        //                prop = CommonUtil.BuildProjection<MasterControlData>(() => dg, x => x.Id);
        //            }
        //            else if (PropertyUnitSearchBy.UNIT == searchBy)
        //            {
        //                query.Left.JoinAlias(() => fm.UnitNo, () => dg);
        //                prop = CommonUtil.BuildProjection<MasterControlData>(() => dg, x => x.Id);

        //            }
        //            else if (PropertyUnitSearchBy.UNIT_TYPE == searchBy)
        //            {
        //                query.Left.JoinAlias(() => fm.UnitTypeId, () => dg);
        //                prop = CommonUtil.BuildProjection<MasterControlData>(() => dg, x => x.Id);
        //            }
        //            else if (PropertyUnitSearchBy.WING == searchBy)
        //            {
        //                query.Left.JoinAlias(() => fm.Wing, () => dg);
        //                prop = CommonUtil.BuildProjection<MasterControlData>(() => dge, x => x.Id);
        //            }

        //            query.Where(Restrictions.Eq(prop, searchByValue));
        //        }
        //        query.Where(() => fm.FirmNumber == firmNumber && en.Id= propertyTowerId)
        //            .Select(proj)
        //            .TransformUsing(new DeepTransformer<PropertyUnitDTO>()).List<PropertyUnitDTO>();
        //                    }
        //    catch (Exception exp)
        //    {
        //        log.Error("Unexpected error populating enquiry grid:");
        //        log.Error(exp.Message, exp);
        //    }
        //    finally
        //    {
        //        NHibertnateSession.closeSession(session);
        //    }
        //    return results;
        //}


        public List<PropertyUnitDTO> fetchPropertyUnits(string firmNumber, long propertyTowerId)
        {
            ISession session = null;
            List<PropertyUnitDTO> propertyUnitList = new List<PropertyUnitDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit pu = null;
                        Property p = null;
                        IList<PropertyUnit> result = session.QueryOver<PropertyUnit>(() => pu).JoinAlias(() => pu.PropertyTower, () => p)
                            .Where(() => pu.FirmNumber == firmNumber && p.Id == propertyTowerId).List<PropertyUnit>();
                        foreach (PropertyUnit propertyUnit in result)
                        {
                            propertyUnitList.Add(DomainToDTOUtil.convertToPropertyUnitDTO(propertyUnit, true));
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching property unit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return propertyUnitList;
        }

        public PropertyUnitDTO fetchPropertyUnitDetails(long Id)
        {
            ISession session = null;
            PropertyUnitDTO propertyUnitDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit propertyunit = session.Get<PropertyUnit>(Id);
                        propertyUnitDto = DomainToDTOUtil.convertToPropertyUnitDTO(propertyunit, true);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Property Unit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return propertyUnitDto;
        }
        public long savePropertyUnitDetails(PropertyUnitDTO propertyUnitDTO)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit propertyUnit = DTOToDomainUtil.populatePropertyUnitAddFields(propertyUnitDTO);
                        session.Save(propertyUnit);
                        Id = propertyUnit.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Property Unit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        public void updatePropertyUnitDetails(PropertyUnitDTO propertyUnitDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit propertyUnit = session.Get<PropertyUnit>(propertyUnitDto.Id);
                        DTOToDomainUtil.populatePropertyUnitDetailUpdateFields(propertyUnit, propertyUnitDto);
                        session.Update(propertyUnit);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating Property Unit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public BusinessOutputTO deletePropertyUnitDetails(long Id)
        {
            ISession session = null;
            BusinessOutputTO businessOutputTO = new BusinessOutputTO();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit propertyUnit = session.Get<PropertyUnit>(Id);
                        //if (!(propertyUnit.Count > 0))
                        //{
                        session.Delete(propertyUnit);
                        businessOutputTO.status = BusinessOutputTO.Status.SUCCESS;
                        //}
                        //else
                        //{
                        //    businessOutputTO.setErrorMessage(Resources.Messages.system_error);
                        //}
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while deleting Property Unit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
                return businessOutputTO;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }

        public void populatePropertyUnitDetailsDTO(PropertyUnit propertyUnitdtls)
        {
            PropertyUnitDTO propertyunitDtlDTO = new PropertyUnitDTO();
            MasterControlDataDTO masterControlDTO = new MasterControlDataDTO();
        }
        public bool isAlreadyExist(PropertyUnitDTO propertyunitdto)
        {
            ISession session = null;
            bool isExist = false;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit pu = null;
                        Property p = null;
                        IList<PropertyUnit> result = session.QueryOver<PropertyUnit>(() => pu).JoinAlias(() => pu.PropertyTower, () => p)
                            .Where(() => pu.FirmNumber == propertyunitdto.FirmNumber && p.Id == propertyunitdto.PropertyTower.Id 
                                && pu.UnitNo == propertyunitdto.UnitNo).List<PropertyUnit>();
                        if (result != null && result.Count() > 0)
                        {
                            isExist = true;
                        }

                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while validating duplicate Unit No:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return isExist;
        }

    }
}