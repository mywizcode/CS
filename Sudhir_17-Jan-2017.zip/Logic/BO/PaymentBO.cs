﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq.Expressions;
using NHibernate.Impl;
using System.Linq;

/// <summary>
/// Summary description for propertyBO
/// </summary>
namespace ConstroSoft
{
    public class PaymentBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public PaymentBO() { }

        public IList<PrUnitSalePymtDTO> fetchCustomerToFromFirmPayments(string firmNumber, long propertyTowerId, PRUnitSalePymtTo pymtTo,
            PaymentSearchBy searchBy, long searchByValue)
        {
            ISession session = null;
            IList<PrUnitSalePymtDTO> result = new List<PrUnitSalePymtDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                PrUnitSalePymt pusp = null;
                Property p = null;
                PropertyUnit pu = null;
                PrUnitSaleDetail pus = null;
                Customer c = null;
                PropertyTower pt = null;
                PaymentMaster pm = null;
                FirmAccount fa = null;
                MasterControlData putype = null;
                MasterControlData pusptype = null;

                PrUnitSalePymtDTO puspdt = null;
                
                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => pusp.Id).WithAlias(() => puspdt.Id))
                            .Add(Projections.SqlFunction("concat",
                                        NHibernateUtil.String,
                                        Projections.Property(() => c.FirstName),
                                        Projections.Constant(" "),
                                        Projections.Property(() => c.LastName)), "PrUnitSaleDetail.Customer.FirstName")
                            .Add(Projections.Property(() => p.Name), "PrUnitSaleDetail.PropertyUnit.PropertyTower.Property.Name")
                            .Add(Projections.Property(() => fa.Id), "PrUnitSaleDetail.PropertyUnit.PropertyTower.Property.FirmAccount.Id")
                            .Add(Projections.Property(() => pt.Name), "PrUnitSaleDetail.PropertyUnit.PropertyTower.Name")
                            .Add(Projections.Property(() => pu.Wing), "PrUnitSaleDetail.PropertyUnit.Wing")
                            .Add(Projections.Property(() => pu.UnitNo), "PrUnitSaleDetail.PropertyUnit.UnitNo")
                            .Add(Projections.Property(() => putype.Name), "PrUnitSaleDetail.PropertyUnit.UnitType.Name")
                            .Add(Projections.Property(() => pus.BookingDate), "PrUnitSaleDetail.BookingDate")
                            .Add(Projections.Property(() => pus.SaleRate), "PrUnitSaleDetail.SaleRate")
                            .Add(Projections.Property(() => pus.AgreementAmt), "PrUnitSaleDetail.AgreementAmt")
                            .Add(Projections.Property(() => pus.Status), "PrUnitSaleDetail.Status")
                            .Add(Projections.Property(() => pusptype.Name), "PymtType.Name")
                            .Add(Projections.Property(() => pm.Id), "PaymentMaster.Id")
                            .Add(Projections.Property(() => pm.TotalAmt), "PaymentMaster.TotalAmt")
                            .Add(Projections.Property(() => pm.TotalPaid), "PaymentMaster.TotalPaid")
                            .Add(Projections.Property(() => pm.TotalPending), "PaymentMaster.TotalPending")
                            .Add(Projections.Property(() => pm.Status), "PaymentMaster.Status")
                            .Add(Projections.Property(() => pusp.Description).WithAlias(() => puspdt.Description));
                var query = session.QueryOver<PrUnitSalePymt>(() => pusp)
                    .Inner.JoinAlias(() => pusp.PaymentMaster, () => pm)
                    .Left.JoinAlias(() => pusp.PymtType, () => pusptype)
                    .Left.JoinAlias(() => pusp.PrUnitSaleDetail, () => pus)
                    .Left.JoinAlias(() => pusp.PrUnitSaleDetail.PropertyUnit, () => pu)
                    .Left.JoinAlias(() => pusp.PrUnitSaleDetail.PropertyUnit.UnitType, () => putype)
                    .Left.JoinAlias(() => pusp.PrUnitSaleDetail.PropertyUnit.PropertyTower, () => pt)
                    .Left.JoinAlias(() => pusp.PrUnitSaleDetail.PropertyUnit.PropertyTower.Property, () => p)
                    .Left.JoinAlias(() => pusp.PrUnitSaleDetail.PropertyUnit.PropertyTower.Property.FirmAccount, () => fa)
                    .Left.JoinAlias(() => pusp.PrUnitSaleDetail.Customer, () => c);
                if (PaymentSearchBy.NONE != searchBy && searchByValue != -1)
                {
                    PropertyProjection prop = null;
                    if (PaymentSearchBy.CUSTOMER_NAME == searchBy)
                    {
                        prop = CommonUtil.BuildProjection<Customer>(() => c, x => x.Id);
                    }
                    else if (PaymentSearchBy.UNIT_NO == searchBy)
                    {
                        prop = CommonUtil.BuildProjection<PropertyUnit>(() => pu, x => x.Id);
                    }
                    query.Where(Restrictions.Eq(prop, searchByValue));
                }
                result = query.Where(() => p.FirmNumber == firmNumber && pt.Id == propertyTowerId && pusp.PymtTo == pymtTo)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<PrUnitSalePymtDTO>()).List<PrUnitSalePymtDTO>();
                result.ToList().ForEach(x => x.PrUnitSaleDetail.PropertyUnit.UnitNo
                    = CommonUIConverter.getPropertyUnitFormattedNo(x.PrUnitSaleDetail.PropertyUnit.Wing, x.PrUnitSaleDetail.PropertyUnit.UnitNo));
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error fetching data for Payment search grid:");
                log.Error(exp.Message, exp);
                throw exp;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public PaymentMasterDTO fetchPaymentMaster(long Id)
        {
            ISession session = null;
            PaymentMasterDTO paymentMasterDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PaymentMaster paymentMaster = session.Get<PaymentMaster>(Id);
                        paymentMasterDto = DomainToDTOUtil.convertToPaymentMasterDTO(paymentMaster, true, true);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Payment Masters details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return paymentMasterDto;
        }
        public void addPymtTransaction(PaymentTransactionDTO pymtTransDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PaymentMaster pymtMaster = session.Get<PaymentMaster>(pymtTransDto.PaymentMaster.Id);
                        DTOToDomainUtil.populatePaymentMasterUpdateFields(pymtMaster, pymtTransDto.PaymentMaster);
                        PaymentTransaction pymtTransaction = DTOToDomainUtil.populatePaymentTransactionAddFields(pymtTransDto);
                        pymtMaster.PaymentTransactions.Add(pymtTransaction);
                        if (pymtTransDto.Status == PymtTransStatus.Reversal)
                        {
                            PaymentTransaction orgPymtTransaction = pymtMaster.PaymentTransactions.ToList<PaymentTransaction>()
                                .Find(p => p.Id == pymtTransDto.CancelledPaymentTransaction.Id);
                            orgPymtTransaction.Status = PymtTransStatus.Deleted;
                        }
                        pymtTransaction.PaymentMaster = pymtMaster;
                        session.Update(pymtMaster);
                        FirmAccount firmAccount = session.Get<FirmAccount>(pymtTransDto.AccountTransaction.FirmAccount.Id);
                        if (pymtTransDto.Status == PymtTransStatus.Paid)
                        {
                            firmAccount.AccountBalance = Decimal.Add(firmAccount.AccountBalance, pymtTransaction.Amount);
                        }
                        else
                        {
                            firmAccount.AccountBalance = Decimal.Subtract(firmAccount.AccountBalance, pymtTransaction.Amount);
                        }
                        session.Update(firmAccount);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Adding payment transaction:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public PostDatedChequeDTO fetchPostDatedChequeDetails(long Id)
        {
            ISession session = null;
            PostDatedChequeDTO pdcDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PostDatedCheque pdc = session.Get<PostDatedCheque>(Id);
                        pdcDto = DomainToDTOUtil.convertToPDCDTO(pdc, true);
                        
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Post Dated Cheque details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return pdcDto;
        }
        public IList<PostDatedChequeSearchDTO> fetchPdcFromCustomerToFirm(string firmNumber, long prTowerId)
        {
            ISession session = null;
            IList<PostDatedChequeSearchDTO> result = new List<PostDatedChequeSearchDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PostDatedChequeSearchDTO pdcDto = null;

                        PostDatedCheque pdc = null;
                        PdcBook pdcFrom = null;
                        PdcBook pdcTo = null;
                        PropertyTower pt = null;
                        Customer c = null;
                        Firm f = null;

                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => pdc.Id).WithAlias(() => pdcDto.Id))
                                    .Add(Projections.Property(() => c.Id).WithAlias(() => pdcDto.ChqDrawerId))
                                    .Add(Projections.SqlFunction("concat",
                                        NHibernateUtil.String,
                                        Projections.Property(() => c.FirstName),
                                        Projections.Constant(" "),
                                        Projections.Property(() => c.LastName)).WithAlias(() => pdcDto.ChqDrawerName))
                                    .Add(Projections.Property(() => f.Id).WithAlias(() => pdcDto.ChqPayeeId))
                                    .Add(Projections.Property(() => f.Name).WithAlias(() => pdcDto.ChqPayeeName))
                                    .Add(Projections.Property(() => pdc.ChequeNo).WithAlias(() => pdcDto.ChequeNo))
                                    .Add(Projections.Property(() => pdc.ChequeDate).WithAlias(() => pdcDto.ChequeDate))
                                    .Add(Projections.Property(() => pdc.BankName).WithAlias(() => pdcDto.BankName))
                                    .Add(Projections.Property(() => pdc.PymtAmt).WithAlias(() => pdcDto.PymtAmt))
                                    .Add(Projections.Property(() => pdc.ChequeStatus).WithAlias(() => pdcDto.ChequeStatus))
                                    .Add(Projections.Property(() => pdc.PymtStatus).WithAlias(() => pdcDto.PymtStatus));
                        var query = session.QueryOver<PostDatedCheque>(() => pdc)
                            .Inner.JoinAlias(() => pdc.PdcFrom, () => pdcFrom)
                            .Inner.JoinAlias(() => pdc.PdcTo, () => pdcTo)
                            .Inner.JoinAlias(() => pdc.PdcFrom.CustomerOut, () => c)
                            .Inner.JoinAlias(() => pdc.PdcTo.FirmIn, () => f)
                            .Left.JoinAlias(() => pdc.PrTower, () => pt);
                        result = query.Where(() => pdc.FirmNumber == firmNumber && pt.Id == prTowerId)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<PostDatedChequeSearchDTO>()).List<PostDatedChequeSearchDTO>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading PDC search result for Customer to Firm Payment:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public IList<PdcPymtDTO> fetchPdcPymtFromCustomerToFirm(string firmNumber, long towerId, long customerId)
        {
            ISession session = null;
            IList<PdcPymtDTO> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PrUnitSalePymt pusp = null;
                        PropertyUnit pu = null;
                        PrUnitSaleDetail pus = null;
                        Customer c = null;
                        PropertyTower pt = null;
                        PaymentMaster pm = null;
                        MasterControlData pusptype = null;

                        PdcPymtDTO pdcPymtDto = null;
                        
                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => pm.Id).WithAlias(() => pdcPymtDto.PymtMasterId))
                                    .Add(Projections.Property(() => pm.TotalAmt).WithAlias(() => pdcPymtDto.TotalPymtAmt))
                                    .Add(Projections.Property(() => pm.TotalPaid).WithAlias(() => pdcPymtDto.TotalPaidAmt))
                                    .Add(Projections.Property(() => pm.TotalPending).WithAlias(() => pdcPymtDto.TotalPendingAmt))
                                    .Add(Projections.Property(() => pm.Status).WithAlias(() => pdcPymtDto.PymtMstStatus))
                                    .Add(Projections.Property(() => pm.Version).WithAlias(() => pdcPymtDto.PymtMasterVersion))
                                    .Add(Projections.Property(() => pu.Wing).WithAlias(() => pdcPymtDto.Wing))
                                    .Add(Projections.Property(() => pu.UnitNo).WithAlias(() => pdcPymtDto.UnitNo))
                                    .Add(Projections.Property(() => pusptype.Name), "SalePymtType.Name");
                        var query = session.QueryOver<PrUnitSalePymt>(() => pusp)
                            .Inner.JoinAlias(() => pusp.PaymentMaster, () => pm)
                            .Left.JoinAlias(() => pusp.PymtType, () => pusptype)
                            .Left.JoinAlias(() => pusp.PrUnitSaleDetail, () => pus)
                            .Left.JoinAlias(() => pusp.PrUnitSaleDetail.PropertyUnit, () => pu)
                            .Left.JoinAlias(() => pusp.PrUnitSaleDetail.PropertyUnit.PropertyTower, () => pt)
                            .Left.JoinAlias(() => pusp.PrUnitSaleDetail.Customer, () => c);
                        result = query.Where(() => pusp.FirmNumber == firmNumber && pt.Id == towerId 
                            && c.Id == customerId && pus.Status == PRUnitSaleStatus.Sold && pusp.PymtTo == PRUnitSalePymtTo.Builder)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<PdcPymtDTO>()).List<PdcPymtDTO>();                        
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Sales Payments for Customer to Firm Payment:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
    }
}