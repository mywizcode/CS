﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initSoldeUnitsGrid();
    initTaxGrid();
    initCMTaxGrid();
    initPaymentGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("tab2Content");
    //This script will enable tabs which was last active even after postback call.
    enableTab(true);
    makeReadOnlySection("pnlTab2UnitInfo");
    var isCancelBooking = ($("[id$='pageModeHdn']").val() == 'CANCEL_BOOKING');
    if (isCancelBooking) {
        makeReadOnlySection("pnlTab3UnitInfo");
        $("[id$='cancelInfoPymtGrid']").prepend($("<thead></thead>").append($("[id$='cancelInfoPymtGrid']").find("tr:first")));
    }
    var isModifyLimitedMode = $("[id$='pageModeHdn']").val() == 'MODIFY_LIMITTED';
    if (isModifyLimitedMode) {
        makeReadOnlySection("pnlTab2BzStep1");
    }
}

function initSoldeUnitsGrid() {
    var dtOptions = {
        tableId: "soldUnitsGrid",
        isViewOnly: false,
        pageLength: 10,
        responsiveModalTitle: "Unit Details",
        customBtnGrpId: "#soldUnitsSearchBtnDiv"
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToSoldUnitsHdnId");
}
function initTaxGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW' || $("[id$='pageModeHdn']").val() == 'MODIFY_LIMITTED');
    var dtOptions = {
        tableId: "taxDetailGrid",
        isViewOnly: isViewOnly,
        pageLength: 5,
        responsiveModalTitle: "Tax Details",
        customBtnGrpId: "#taxDetailGridBtnGrp",
        hasRowInfo: true,
        hideSearch: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToTaxDetailHdnId");
}
function initCMTaxGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW' || $("[id$='pageModeHdn']").val() == 'MODIFY_LIMITTED');
    var dtOptions = {
        tableId: "cmTaxDetailGrid",
        isViewOnly: isViewOnly,
        pageLength: 5,
        responsiveModalTitle: "Tax Details",
        customBtnGrpId: "#cmTaxDetailGridBtnGrp",
        hasRowInfo: true,
        hideSearch: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToCMTaxDetailHdnId");
}
function initPaymentGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "paymentGrid",
        isViewOnly: isViewOnly,
        pageLength: 5,
        responsiveModalTitle: "Payment Details",
        customBtnGrpId: "#paymentGridBtnGrp",
        hasRowInfo: true,
        hideSearch: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPaymentHdnId");
}