﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initDepositGrid();
    formatFields();
    //This script will enable tabs which was last active even after postback call.
    if ($("[id$='activeTabHdn']").val() != "") {
        $('a[id$="' + $("[id$='activeTabHdn']").val() + '"]').tab('show');
    }
}

function initDepositGrid() {
    var dtOptions = {
        tableId: "DepositGrid",
        isViewOnly: false,
        pageLength: 5,
        responsiveModalTitle: "Deposit Details",
        customBtnGrpId: "#DepositSearchBtnDiv",
        hasRowInfo: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToDepositHdnId");
}