$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initPdcSearchGrid();
    initPdcPymtGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    //This script will enable tabs which was last active even after postback call.
    enableTab(false);
    //makeReadOnlySection("pnlPaymentInfo");
}

function initPdcPymtGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "pdcPymtGrid",
        isViewOnly: isViewOnly,
        pageLength: 5,
        responsiveModalTitle: "PDC Payment Details",
        customBtnGrpId: "#pdcPaymentBtnDiv",
        hasRowInfo: true,
        hideSearch: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPdcPaymentHdnId");
}

function initPdcSearchGrid() {
    var dtOptions = {
        tableId: "pdcGrid",
        isViewOnly: false,
        pageLength: 10,
        responsiveModalTitle: "",
        customBtnGrpId: "#pdcSearchBtnDiv",
        hasRowInfo: false
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPdcHdnId");
}