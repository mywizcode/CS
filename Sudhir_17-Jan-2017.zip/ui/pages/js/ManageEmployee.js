$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initEmployeeGrid();
    initAddressGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("tab2Content");
    //This script will enable tabs which was last active even after postback call.
    enableTab(false);
}

function initAddressGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "addressGrid",
        isViewOnly: isViewOnly,
        pageLength: 5,
        responsiveModalTitle: "Address Details",
        customBtnGrpId: "#addressGridBtnGrp",
        hasRowInfo: true,
        defaultColToOrder: 6,
        defaultOrderDesc: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToAddressHdnId");
}

function initEmployeeGrid() {
    var dtOptions = {
        tableId: "employeeGrid",
        isViewOnly: false,
        pageLength: 10,
        responsiveModalTitle: "Employee Details",
        customBtnGrpId: "#empSearchBtnDiv",
        hasRowInfo: false
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToEmployeeHdnId");
}