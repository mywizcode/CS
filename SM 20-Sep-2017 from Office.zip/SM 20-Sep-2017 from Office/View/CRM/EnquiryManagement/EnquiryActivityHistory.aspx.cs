﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using ConstroSoft.Logic.BO;

public partial class EnquiryActivityHistory : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addMasterDataModal = "addMasterDataModal";
    string addMasterDataError = "addMasterDataError";
    DropdownBO drpBO = new DropdownBO();
    EnquiryBO EnquiryBO = new EnquiryBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                EnquiryActivityHistoryNavDTO navDto = (EnquiryActivityHistoryNavDTO)Session[Constants.Session.NAV_DTO];
                Session.Remove(Constants.Session.NAV_DTO);
                Session.Remove(Constants.Session.PAGE_DATA);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(Constants.URL.DEFAULT_HOME_PAGE, false);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();

    }
    private void preRenderInitFormElements()
    {
        renderPageLayout();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(EnquiryActivityHistoryNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new EnquiryActivityHistoryPageDTO();
        initDropdowns();
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(EnquiryActivityHistoryNavDTO navDto)
    {
        try
        {
            EnquiryDetailDTO enquiryDTO = new EnquiryDetailDTO();// EnquiryBO.fetchEnquiryDetails(navDto.EnquiryId, false);
            EnquiryActivityHistoryPageDTO pageDTO = getSessionPageData();
            pageDTO.EnquiryDTO = enquiryDTO;
            populateEnquiryInfo(enquiryDTO);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageLayout()
    {
    }
    private EnquiryActivityHistoryPageDTO getSessionPageData()
    {
        return (EnquiryActivityHistoryPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private void populateEnquiryInfo(EnquiryDetailDTO enquiryDTO)
    {
        lbCustomerName.Text = "Sunil Chavan";
        lbCustomerContact.Text = "9952508742";
        lbEnqAssignee.Text = CommonUIConverter.getCustomerFullName(getUserDefinitionDTO().FirmMember.FirstName, getUserDefinitionDTO().FirmMember.LastName);
        lbEnquiryRefNo.Text = "EQ1020";
        lbLeadRefNo.Text = "LD1023";
        lbEnqUnitType.Text = "3-BHK";
        lbEnqSource.Text = "Facebook";
        lbEnqBudget.Text = "4500000";
        lbEnqStatus.Text = "Open";
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
}
