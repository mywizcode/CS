﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initCustomerSearchGrid();
    initSoldUnitGrid();
    formatFields();
    showModal();
}

function initCustomerSearchGrid() {
    var dtOptions = {
        tableId: "customerSearchGrid",
        pageLength: 10,
        isViewOnly: false,
        customBtnGrpId: "#customerSearchBtnDiv",
        hideSearch: false
    };
    var dtTable = applyActionDataTable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitHdnId");
}
function initSoldUnitGrid() {
    var dtOptions = {
        tableId: "soldUnitsGrid",
        pageLength: 5,
        isViewOnly: true,
        hideSearch: true
    };
    applyActionDataTable(dtOptions);
}




