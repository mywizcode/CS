﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.BO;

public partial class TallyManagement : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
            log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string SearchFilterModal = "SearchFilterModal";
    DropdownBO drpBO = new DropdownBO();
    TallyIntegratorBO tallyIntegratorBO = new TallyIntegratorBO();
    PaymentVoucherBO paymentVoucherBO = new PaymentVoucherBO();

    protected void Page_Load(object sender, EventArgs e)
    {
    	if (ApplicationUtil.isSubPageRendered(Page)) clearMessages();
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                VoucherSearchNavDTO navDto = CommonUtil.getPageNavDTO<VoucherSearchNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_TALLY_MANAGEMENT)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
        * This method is called just before the page is rendered. So any change in state of the element is applied.
        **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
        addCheckBoxAttributes();
    }
    public void initBootstrapComponantsFromServer()
    {
    	ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpEnum<VoucherType>(drpVoucherTypeFilter, Constants.SELECT_ITEM);
        drpBO.drpEnum<TallyPostingStatus>(drpPostingStatusFilter, Constants.SELECT_ITEM);
        drpBO.drpEnum<ConstroSoft.Action>(drpActionFilter, Constants.SELECT_ITEM);
    }
    protected void loadCheckBoxCSS(object sender, EventArgs e)
    {
        addCheckBoxAttributes();
    }
    private void addCheckBoxAttributes()
    {
        cbSelectAllVouchers.InputAttributes.Add("class", "styled block-ui-change");
        cbSelectAllVouchers.InputAttributes.Add("data-panel", "blockui-panel-1");
        foreach (GridViewRow row in voucherSearchGrid.Rows)
        {
            CheckBox cbSelectVoucher = (CheckBox)row.FindControl("cbSelectVoucher");
            if (cbSelectVoucher != null)
            {
                cbSelectVoucher.InputAttributes.Add("class", "styled block-ui-change");
                cbSelectVoucher.InputAttributes.Add("data-panel", "blockui-panel-1");
            }
        }
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(VoucherSearchNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new VoucherSearchPageDTO();
        initDropdowns();
        VoucherFilterDTO FilterDTO = new VoucherFilterDTO();
        //Default Vouchers with Tally Posting Status Pending  will be shown when page is loaded
        FilterDTO.TallyPostingStatus = TallyPostingStatus.Pending;
        setSearchFilter(FilterDTO);
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(VoucherSearchNavDTO navDto)
    {
        try
        {
            if (navDto != null)
            {
                setSearchFilter(navDto.filterDTO);
            }
            loadVoucherSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageFieldsWithEntitlement()
    {
    }
    private VoucherSearchPageDTO getSessionPageData()
    {
        return (VoucherSearchPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<PaymentVoucherDTO> getSearchVoucherDetailList()
    {
        return getSessionPageData().SearchResult;
    }
    private PaymentVoucherDTO getSearchVoucherDetailDTO(long Id)
    {
        List<PaymentVoucherDTO> searchList = getSearchVoucherDetailList();
        PaymentVoucherDTO selectedVoucherDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            selectedVoucherDTO = searchList.Find(c => c.Id == Id);
        }
        return selectedVoucherDTO;
    }
    private void populateVoucherSearchGrid(List<PaymentVoucherDTO> tmpList)
    {
        voucherSearchGrid.DataSource = new List<PaymentVoucherDTO>();
        if (tmpList != null)
        {
            assignUiIndexToVouchers(tmpList);
            voucherSearchGrid.DataSource = tmpList;
        }
        voucherSearchGrid.DataBind();
    }
    private void assignUiIndexToVouchers(List<PaymentVoucherDTO> tmpList)
    {
        if (tmpList != null && tmpList.Count > 0)
        {
            long uiIndex = 1;
            foreach (PaymentVoucherDTO tmpDTO in tmpList)
            {
                tmpDTO.UiIndex = uiIndex++;
                tmpDTO.RowInfo = CommonUIConverter.getGridViewRowInfo(tmpDTO);
            }
        }
    }
    private void loadVoucherSearchGrid()
    {
        VoucherSearchPageDTO PageDTO = getSessionPageData();
        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        IList<PaymentVoucherDTO> results = paymentVoucherBO.fetchPaymentVoucherGridData(userDefDTO.FirmNumber, getSearchFilter());
        PageDTO.SearchResult = (results != null) ? results.ToList<PaymentVoucherDTO>() : new List<PaymentVoucherDTO>();
        populateVoucherSearchGrid(PageDTO.SearchResult);
    }
    protected void onChangeVoucherSelection(object sender, EventArgs e)
    {
        try
        {
            CheckBox cb = (CheckBox)sender;
            long selectedId = long.Parse(cb.Attributes["data-pid"]);
            getSessionPageData().SearchResult.Find(x => x.Id == selectedId).isUISelected = cb.Checked;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onChangeSelectAllVouchers(object sender, EventArgs e)
    {
        try
        {
            CheckBox cb = (CheckBox)sender;
            foreach (GridViewRow row in voucherSearchGrid.Rows)
            {
                CheckBox cbSelectVoucher = (CheckBox)row.FindControl("cbSelectVoucher");
                cbSelectVoucher.Checked = cb.Checked;
            }
            getSessionPageData().SearchResult.Find(x => x.PostingStatus.Equals(TallyPostingStatus.Pending.GetDescription())).isUISelected = cb.Checked;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private VoucherSearchNavDTO getCurrentPageNavigation()
    {
        VoucherSearchNavDTO searchNavDTO = new VoucherSearchNavDTO();
        searchNavDTO.filterDTO = getSearchFilter();
        return searchNavDTO;
    }
    protected void onClickPostVoucherBtn(object sender, EventArgs e)
    {
        try
        {
            List<PaymentVoucherDTO> selectedVoucherList = getSessionPageData().SearchResult.FindAll(x => x.isUISelected);
            if (validateVoucherSelected(selectedVoucherList))
            {
                if (selectedVoucherList != null && selectedVoucherList.Count > 0)
                {
                    postVouchersTally(selectedVoucherList);
                }
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    private void postVouchersTally(IList<PaymentVoucherDTO> resultdtos)
    {
        try
        {
            IList<PaymentVoucherDTO> results = new List<PaymentVoucherDTO>();
            foreach (PaymentVoucherDTO paymentVoucherDTO in resultdtos)
            {
                PaymentVoucherDTO paymentVoucherDTOFromDB = paymentVoucherBO.fetchPaymentVoucher(paymentVoucherDTO.Id);
                results.Add(paymentVoucherDTOFromDB);
            }
            tallyIntegratorBO.processTallyRequest(getUserDefinitionDTO().FirmNumber, results);
            setSuccessMessage(Resources.Messages.TALLY_POSTED_SUCCESS);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    private bool validateVoucherSelected(List<PaymentVoucherDTO> selectedVoucherList)
    {
        if (selectedVoucherList.Count == 0)
        {
            setNotyMsg(CommonUtil.getNotyErrorMsg("Please select atleast one voucher to post."));
            return false;
        }
        return true;
    }
    //Filter Criteria - Voucher Search - Start
    private VoucherFilterDTO getSearchFilter()
    {
        return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            VoucherFilterDTO filterDTO = getSearchFilter();
            if (filterDTO.VoucherType != null) drpVoucherTypeFilter.Text = filterDTO.VoucherType.ToString(); else drpVoucherTypeFilter.ClearSelection();
            if (filterDTO.TallyPostingStatus != null) drpPostingStatusFilter.Text = filterDTO.TallyPostingStatus.ToString(); else drpPostingStatusFilter.ClearSelection();
            if (filterDTO.Action != null) drpActionFilter.Text = filterDTO.Action.ToString(); else drpActionFilter.ClearSelection();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            VoucherFilterDTO filterDTO = new VoucherFilterDTO();
            if (!string.IsNullOrWhiteSpace(drpVoucherTypeFilter.Text))
            {
                filterDTO.VoucherType = EnumHelper.ToEnum<VoucherType>(drpVoucherTypeFilter.SelectedItem.Text);
            }
            if (!string.IsNullOrWhiteSpace(drpPostingStatusFilter.Text))
            {
                filterDTO.TallyPostingStatus = EnumHelper.ToEnum<TallyPostingStatus>(drpPostingStatusFilter.SelectedItem.Text);
            }
            if (!string.IsNullOrWhiteSpace(drpActionFilter.Text))
            {
                filterDTO.Action = EnumHelper.ToEnum<ConstroSoft.Action>(drpActionFilter.SelectedItem.Text);
            }
            setSearchFilter(filterDTO);
            loadVoucherSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }

    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            loadVoucherSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(VoucherFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new VoucherFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            VoucherFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.VOUCHER_TYPE))
            {
                filterDTO.VoucherType = null;
            }
            else if (token.StartsWith(Constants.FILTER.POSTING_STATUS))
            {
                filterDTO.TallyPostingStatus = null;
            }
            else if (token.StartsWith(Constants.FILTER.ACTION))
            {
                filterDTO.Action = null;
            }
            setSearchFilterTokens();
            loadVoucherSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        VoucherFilterDTO filterDTO = getSearchFilter();
        string filter = null;
        if (filterDTO != null)
        {
            if (filterDTO.VoucherType != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.VOUCHER_TYPE + filterDTO.VoucherType);
            if (filterDTO.TallyPostingStatus != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.POSTING_STATUS + filterDTO.TallyPostingStatus);
            if (filterDTO.Action != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.ACTION + filterDTO.Action);
        }
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - Voucher Search - End
}