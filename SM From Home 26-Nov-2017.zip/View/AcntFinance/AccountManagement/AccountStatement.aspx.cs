﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.BO;
using CrystalDecisions.CrystalReports.Engine;

public partial class AccountStatement : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
       log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "CommonError";
    public enum AccountStatementPageMode { STATEMENT, NONE }
    DropdownBO drpBO = new DropdownBO();
    FirmBO firmAccountBO = new FirmBO();
    ReportConfigBO reportConfigBO = new ReportConfigBO();
    protected void Page_Load(object sender, EventArgs e)
    {
    	if (ApplicationUtil.isSubPageRendered(Page)) clearMessages();
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                FirmAccountStatementsNavDTO navDto = CommonUtil.getPageNavDTO<FirmAccountStatementsNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_ACCOUNTS)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    private void doInit(FirmAccountStatementsNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new FirmAccountStatementPageDTO();
        initPageInfo(AccountStatementPageMode.NONE);
        initDropdowns();
        onSelectAccount(navDto);
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        drpBO.drpEnum<AcntTransStmtOption>(drpAcntStmtPeriod, null);
        
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    private void initPageInfo(AccountStatementPageMode pageMode)
    {
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        pageModeHdn.Value = pageMode.ToString();
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    protected void Page_PreRender(object sender, EventArgs e)
    {
    	if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
    	renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
    }
    private void renderPageFieldsWithEntitlement()
    {
    	bool isReadOnly = (AccountStatementPageMode.NONE.ToString().Equals(pageModeHdn.Value));
        bool visible = !(AccountStatementPageMode.NONE.ToString().Equals(pageModeHdn.Value));
        bool isEnabled = !isReadOnly;            
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();               
        txtAccountName.ReadOnly = isReadOnly;
        txtAccountNumber.ReadOnly = isReadOnly;
        txtAccountType.ReadOnly = isReadOnly;
        txtAccountBalance.ReadOnly = isReadOnly;
        drpAcntStmtPeriod.Visible = isReadOnly;          
    }
    protected void fetchAccountTransactions(object sender, EventArgs e)
    {
        try
        {
            if (validateDateRange())
            {
                DateTime startDate = DateUtil.getCSDateNotNull(txtStmtFrom.Text);
                DateTime endDate = DateUtil.getCSDateNotNull(txtStmtTo.Text);
                fetchAndPopulateAcntTrans(startDate, endDate);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    
    protected void downloadStmtPdf(object sender, EventArgs e)
    {
        try
        {           
            FirmAccountDTO accountDto = getAccountDTO();
            FirmAccountStatementPageDTO firmAccountStatementPageDTO = (FirmAccountStatementPageDTO)Session[Constants.Session.PAGE_DATA];
            List<AccountTransactionDTO> tmpAcntList = firmAccountStatementPageDTO.AccountTransactions;
            AcntTransStmtOption stmtOpts = EnumHelper.ToEnum<AcntTransStmtOption>(drpAcntStmtPeriod.Text);
            DateTime now = DateTime.Now;
            DateTime startDate = new DateTime(now.Year, now.Month, 1);
            DateTime endDate = DateTime.Now;
            if (AcntTransStmtOption.LAST_TWO_MONTHS == stmtOpts || AcntTransStmtOption.LAST_THREE_MONTHS == stmtOpts)
            {
                startDate = new DateTime(now.Year, now.Month, 1);
                if (AcntTransStmtOption.LAST_TWO_MONTHS == stmtOpts)
                {
                    now = now.AddMonths(-1);
                    startDate = new DateTime(now.Year, now.Month, 1);
                }
                else if (AcntTransStmtOption.LAST_THREE_MONTHS == stmtOpts)
                {
                    now = now.AddMonths(-2);
                    startDate = new DateTime(now.Year, now.Month, 1);
                }
            }
            DataTable AccountSummary = new DataTable();
            populateAccountSummaryDataTable(AccountSummary);
            DataRow AccountSummaryRow = AccountSummary.NewRow();
            string BLANK_STRING = "";
            populateAccountSummaryRow(accountDto, startDate, endDate, AccountSummaryRow, BLANK_STRING);
            AccountSummary.Rows.Add(AccountSummaryRow);
            DataTable AccountTransaction = new DataTable();
            populateAccountTransDataTable(AccountTransaction);
            foreach (AccountTransactionDTO accountTransactionDTO in tmpAcntList)
            {
                DataRow AccountTransactionRow = AccountTransaction.NewRow();
                populateAccountTransactionRow(accountTransactionDTO, AccountTransactionRow, BLANK_STRING);
                AccountTransaction.Rows.Add(AccountTransactionRow);
            }
            ReportConfigDTO reportConfigDTO = reportConfigBO.fetchReportConfiguration(getUserDefinitionDTO().FirmNumber, "Account Statement");
            ReportDocument accountstatementReportDocument = new ReportDocument();
            string reportPath = Server.MapPath(reportConfigDTO.ReportPath);
            accountstatementReportDocument.Load(reportPath);
            accountstatementReportDocument.Database.Tables["AccountSummary"].SetDataSource(AccountSummary);
            accountstatementReportDocument.Subreports["AccountTrans"].SetDataSource(AccountTransaction);
            Session["AccountStatementReport"] = accountstatementReportDocument;
            
            try
            {
                accountstatementReportDocument.ExportToHttpResponse
                (CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, true, accountDto.Name);
            }
            catch (Exception exp)
            {

            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(exp.Message + exp.StackTrace.ToString(), commonError);
        }
    }

    private static void populateAccountTransactionRow(AccountTransactionDTO accountTransactionDTO, DataRow AccountTransactionRow, string BLANK_STRING)
    {
        AccountTransactionRow["TransactionDate"] = DateUtil.getCSDate(accountTransactionDTO.TxDate);
        AccountTransactionRow["TransactionComment"] = accountTransactionDTO.Comments != null ? accountTransactionDTO.Comments : BLANK_STRING;
        AccountTransactionRow["CreditAmount"] = accountTransactionDTO.UiCreditAmt != null ? accountTransactionDTO.UiCreditAmt : Decimal.Zero;
        AccountTransactionRow["DebitAmount"] = accountTransactionDTO.UiDebitAmt != null ? accountTransactionDTO.UiDebitAmt : Decimal.Zero;
    }

    private static void populateAccountSummaryRow(FirmAccountDTO accountDto, DateTime startDate, DateTime endDate, DataRow AccountSummaryRow, string BLANK_STRING)
    {
        AccountSummaryRow["AccountName"] = accountDto.Name != null ? accountDto.Name : BLANK_STRING;
        AccountSummaryRow["AccountNumber"] = accountDto.AccountNo != null ? accountDto.AccountNo : BLANK_STRING;
        AccountSummaryRow["AccountType"] = accountDto.AccountType != null ? accountDto.AccountType.Name : BLANK_STRING;
        AccountSummaryRow["AccountBalance"] = accountDto.AccountBalance != null ? accountDto.AccountBalance : Decimal.Zero;
        AccountSummaryRow["BankName"] = accountDto.BankName != null ? accountDto.BankName : BLANK_STRING;
        AccountSummaryRow["BranchName"] = accountDto.Branch != null ? accountDto.Branch : BLANK_STRING;
        AccountSummaryRow["IfscCode"] = accountDto.IfscCode != null ? accountDto.IfscCode : BLANK_STRING;
        AccountSummaryRow["FromDate"] = DateUtil.getCSDate(startDate);
        AccountSummaryRow["ToDate"] = DateUtil.getCSDate(endDate);
    }

    private static void populateAccountTransDataTable(DataTable AccountTransaction)
    {
        AccountTransaction.Columns.Add("TransactionDate", typeof(string));
        AccountTransaction.Columns.Add("TransactionComment", typeof(string));
        AccountTransaction.Columns.Add("CreditAmount", typeof(Decimal));
        AccountTransaction.Columns.Add("DebitAmount", typeof(Decimal));
    }

    private static void populateAccountSummaryDataTable(DataTable AccountSummary)
    {
        AccountSummary.Columns.Add("AccountName", typeof(string));
        AccountSummary.Columns.Add("AccountNumber", typeof(string));
        AccountSummary.Columns.Add("AccountType", typeof(string));
        AccountSummary.Columns.Add("AccountBalance", typeof(Decimal));
        AccountSummary.Columns.Add("FromDate", typeof(string));
        AccountSummary.Columns.Add("ToDate", typeof(string));
        AccountSummary.Columns.Add("BankName", typeof(string));
        AccountSummary.Columns.Add("BranchName", typeof(string));
        AccountSummary.Columns.Add("IfscCode", typeof(string));
    }
    private bool validateDateRange()
    {
        bool isValid = true;
        Page.Validate("commonError");
        isValid = Page.IsValid;
        if (isValid)
        {
            DateTime fromDate = DateUtil.getCSDateNotNull(txtStmtFrom.Text);
            DateTime toDate = DateUtil.getCSDateNotNull(txtStmtTo.Text);
            if (fromDate.CompareTo(toDate) > 0)
            {
                setErrorMessage("From date cannot be greater than To date.", commonError);
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
                isValid = false;
            }
        }
        return isValid;
    }
    private void populateAccountSummary()
    {
        FirmAccountDTO accountDto = getAccountDTO();
        if (accountDto != null)
        {
            txtAccountName.Text = accountDto.Name;
            txtAccountNumber.Text = accountDto.AccountNo;
            txtAccountType.Text = accountDto.AccountType.Name;
            txtAccountBalance.Text = accountDto.AccountBalance.ToString();
        }
    }
    private void fetchAndPopulateAcntTrans(DateTime startDate, DateTime endDate)
    {
        FirmAccountDTO accountDto = getAccountDTO();
       
        if (accountDto != null)
        {
            IList<AccountTransactionDTO> acntTransDtoList = firmAccountBO.fetchAccountTransactions(getUserDefinitionDTO().FirmNumber, accountDto.Id, startDate);
            List<AccountTransactionDTO> tmpAcntList = new List<AccountTransactionDTO>();
            foreach (AccountTransactionDTO tmpAcntTransDto in acntTransDtoList)
            {
                if (AcntTransStatus.Credit == tmpAcntTransDto.TxType) tmpAcntTransDto.UiCreditAmt = tmpAcntTransDto.Amount;
                else tmpAcntTransDto.UiDebitAmt = tmpAcntTransDto.Amount;
                if (tmpAcntTransDto.TxDate.CompareTo(startDate) >= 0 && tmpAcntTransDto.TxDate.CompareTo(endDate) <= 0)
                {
                    tmpAcntList.Add(tmpAcntTransDto);                       
                }
            }                
            acntSummaryGrid.DataSource = tmpAcntList;
            acntSummaryGrid.DataBind();
            getSessionPageData().AccountTransactions = tmpAcntList;
        }
    }
    private FirmAccountDTO getAccountDTO()
    {
        return getSessionPageData().SelectedAccount;
    }
    private FirmAccountStatementPageDTO getSessionPageData()
    {
        return (FirmAccountStatementPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    
    public void onSelectAccount(FirmAccountStatementsNavDTO navDto)
    {
        try
        {
            FirmAccountDTO firmAccountDto = firmAccountBO.fetchFirmAccount(navDto.AcntID);
            getSessionPageData().SelectedAccount = firmAccountDto;
            getSessionPageData().PrevNavDTO = navDto.PrevNavDto;
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];                    
            populateAccountSummary();
            DateTime now = DateTime.Now;
            DateTime startDate = new DateTime(now.Year, now.Month, 1);
            fetchAndPopulateAcntTrans(startDate, DateTime.Now);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    protected void onSelectAcntStmtPeriod(object sender, EventArgs e)
    {
        try
        {
            AcntTransStmtOption stmtOpts = EnumHelper.ToEnum<AcntTransStmtOption>(drpAcntStmtPeriod.Text);
            if (AcntTransStmtOption.LAST_TWO_MONTHS == stmtOpts || AcntTransStmtOption.LAST_THREE_MONTHS == stmtOpts || AcntTransStmtOption.CURRENT_MONTH == stmtOpts)
            {
                DateTime now = DateTime.Now;
                DateTime startDate = new DateTime(now.Year, now.Month, 1);
                DateTime endDate = DateTime.Now;
                if (AcntTransStmtOption.LAST_TWO_MONTHS == stmtOpts)
                {
                    now = now.AddMonths(-1);
                    startDate = new DateTime(now.Year, now.Month, 1);
                    fetchAndPopulateAcntTrans(startDate, endDate);
                }
                else if (AcntTransStmtOption.LAST_THREE_MONTHS == stmtOpts)
                {
                    now = now.AddMonths(-2);
                    startDate = new DateTime(now.Year, now.Month, 1);
                    fetchAndPopulateAcntTrans(startDate, endDate);
                }
                else if (AcntTransStmtOption.CURRENT_MONTH == stmtOpts)
                {
                    now = now.AddMonths(0);
                    startDate = new DateTime(now.Year, now.Month, 1);
                    fetchAndPopulateAcntTrans(startDate, endDate);
                }
                pnlDateRange.Visible = false;
            }
            else
            {
                txtStmtFrom.Text = null;
                txtStmtTo.Text = null;
                pnlDateRange.Visible = true;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void navigateToPreviousPage()
    {
        FirmAccountStatementPageDTO firmAccountStatementPageDTO = getSessionPageData();
        FirmAccountNavDTO firmAccountNavDTO = (FirmAccountNavDTO)firmAccountStatementPageDTO.PrevNavDTO;
        Session[Constants.Session.NAV_DTO] = firmAccountNavDTO;
        Response.Redirect(Constants.URL.FIRM_ACCOUNT, true);
    }
    
}
