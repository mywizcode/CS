﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.BO;

public partial class PropertyFundDetail : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string chqPymtError = "chqPymtError";
    string nonCashPymtError = "nonCashPymtError";

    DropdownBO drpBO = new DropdownBO();
    PropertyFundsBO propertyFundsBO = new PropertyFundsBO();

    protected void Page_Load(object sender, EventArgs e)
    {
    	if (ApplicationUtil.isSubPageRendered(Page)) clearMessages();
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                PropertyFundDetailNavDTO navDto = CommonUtil.getPageNavDTO<PropertyFundDetailNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_PROPERTY_FUND_MANAGEMENT)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
        setPageTitle();
    }
    public void initBootstrapComponantsFromServer()
    {
    	ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpAccount, DrpDataType.FIRM_ACCOUNT, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<PaymentMethod>(drpPaymentMethod, null);
        drpBO.drpEnum<ChequeStatus>(drpChequeStatus, null);
    }
    private void setPageTitle()
    {
        if (isAddMode()) lbPageTitle.Text = Constants.ICON.MODIFY + Resources.Labels.ADD_FUND;
        else if (isViewMode()) lbPageTitle.Text = Constants.ICON.VIEW_DTL + Resources.Labels.FUND_DETAILS;
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(PropertyFundDetailNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(PropertyFundDetailNavDTO navDto)
    {
        try
        {
            PropertyFundPageDTO propertyFundPageDTO = new PropertyFundPageDTO();
            pageModeHdn.Value = navDto.Mode.ToString();
            Session[Constants.Session.PAGE_DATA] = propertyFundPageDTO;
            propertyFundPageDTO.PrevNavDTO = navDto.PrevNavDto;
            if (isAddMode())
            {
                propertyFundPageDTO.PropertyFundsDTO = createPropertyFundsDTOForAdd();
            }
            else
            {
                propertyFundPageDTO.PropertyFundsDTO = propertyFundsBO.fetchDeposit(navDto.propertyFundId);
                populateUIFieldsFromPropertyFundsDTO(propertyFundPageDTO.PropertyFundsDTO);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void populateUIFieldsFromPropertyFundsDTO(PropertyFundsDTO propertyFundsDTO)
    {
        if (propertyFundsDTO != null && propertyFundsDTO.FirmAccount != null) drpAccount.Text = propertyFundsDTO.FirmAccount.Id.ToString(); else drpAccount.ClearSelection();
        if (propertyFundsDTO != null ) drpPaymentMethod.Text = propertyFundsDTO.PymtMethod.ToString(); else drpPaymentMethod.ClearSelection();
        if (propertyFundsDTO != null) txtTxDate.Text = DateUtil.getCSDate(propertyFundsDTO.TxDate); else txtTxDate.Text = null;
        if (propertyFundsDTO != null && propertyFundsDTO.Amount != null) txtPaymentAmt.Text = propertyFundsDTO.Amount.ToString(); else txtPaymentAmt.Text = null;
        if (propertyFundsDTO != null) txtTxComments.Text = propertyFundsDTO.Comments; else txtTxComments.Text = null;
        if (propertyFundsDTO.PymtMethod == PaymentMethod.CHEQUE)
        {
            if (propertyFundsDTO != null) txtChequeDate.Text = DateUtil.getCSDate(propertyFundsDTO.ChequeDate); else txtChequeDate.Text = null;
            if (propertyFundsDTO != null) txtPayName.Text = propertyFundsDTO.PayName; else txtPayName.Text = null;
            if (propertyFundsDTO != null) txtCollectionDate.Text = DateUtil.getCSDate(propertyFundsDTO.TxDate); else txtCollectionDate.Text = null;
        }
        if (propertyFundsDTO.PymtMethod != PaymentMethod.CASH)
        {
            if (propertyFundsDTO != null) txtMediaNo.Text = propertyFundsDTO.MediaNo; else txtMediaNo.Text = null;
            if (propertyFundsDTO != null) txtBankName.Text = propertyFundsDTO.BankName; else txtBankName.Text = null;
            if (propertyFundsDTO != null) txtBranch.Text = propertyFundsDTO.Branch; else txtBranch.Text = null;
        }
    }
    private void navigateToPreviousPage()
    {
        PropertyFundPageDTO propertyFundPageDTO = getSessionPageData();
        if (propertyFundPageDTO != null && propertyFundPageDTO.PrevNavDTO != null)
        {
            object obj = propertyFundPageDTO.PrevNavDTO;
            if (obj is PropertyFundSearchNavDTO)
            {
                PropertyFundSearchNavDTO navDTO = (PropertyFundSearchNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.PROPERTY_FUND_SEARCH, true);
            }
        }
        Response.Redirect(Constants.URL.PROPERTY_FUND_SEARCH, true);
    }
    private void renderPageFieldsWithEntitlement()
    {
        initFormFields();
        bool viewMode = isViewMode();
        bool addMode = isAddMode();
        //Fields
        drpAccount.Enabled = addMode;
        drpPaymentMethod.Enabled = addMode;
        txtTxDate.ReadOnly = viewMode;
        txtPaymentAmt.ReadOnly = viewMode;
        txtCollectionDate.ReadOnly = viewMode;
        txtChequeDate.ReadOnly = viewMode;
        txtPayName.ReadOnly = viewMode;
        drpChequeStatus.Enabled = addMode;
        txtMediaNo.ReadOnly = viewMode;
        txtBankName.ReadOnly = viewMode;
        txtBranch.ReadOnly = viewMode;
        txtTxComments.ReadOnly = viewMode;
        btnSaveTransaction.Visible = addMode;
    }
    private void initFormFields()
    {
        PaymentMethod pymtMethod = EnumHelper.ToEnum<PaymentMethod>(drpPaymentMethod.Text);
        pnlChequeSection.Visible = (PaymentMethod.CHEQUE == pymtMethod || PaymentMethod.DD == pymtMethod);
        pnlNonCashSection.Visible = (PaymentMethod.CASH != pymtMethod);
        lbTxDate.Text = (PaymentMethod.CHEQUE == pymtMethod || PaymentMethod.DD == pymtMethod) ? Resources.Labels.TX_CLEARANCE_DATE : Resources.Labels.TX_DATE;
    }
    private bool isViewMode()
    {
        return PageMode.VIEW.ToString().Equals(pageModeHdn.Value);
    }
    private bool isAddMode()
    {
        return PageMode.ADD.ToString().Equals(pageModeHdn.Value);
    }
    private PropertyFundPageDTO getSessionPageData()
    {
        return (PropertyFundPageDTO)Session[Constants.Session.PAGE_DATA];
    }

    protected void savePropertyFund(object sender, EventArgs e)
    {
        try
        {
            if (validateAddPymtTransaction())
            {
                PropertyFundsDTO propertyFundsDTO = populatePropertyFundDTOFromUI();
                AccountTransactionDTO accountTransactionDTO = createAccountTransaction(propertyFundsDTO, false);
                propertyFundsBO.saveDeposit(propertyFundsDTO, accountTransactionDTO);
                string msg = "Property Fund is added successfully";
                Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg(msg));
                PropertyFundSearchNavDTO navDTO = new PropertyFundSearchNavDTO();
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.PROPERTY_FUND_SEARCH, true);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }

    private bool validateAddPymtTransaction()
    {
        bool isValid = validateMandatoryFields(commonError);
        if (!isValid)
        {
            Page.Validate(chqPymtError);
            isValid = Page.IsValid;
        }
        if (!isValid)
        {
            isValid = validateMandatoryFields(nonCashPymtError);
        }
        return isValid;
    }
    private bool validateMandatoryFields(string valGrp)
    {
        Page.Validate(valGrp);
        bool isValid = Page.IsValid;
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }

    private void resetChequeFields()
    {
        txtCollectionDate.Text = null;
        txtChequeDate.Text = null;
        txtPayName.Text = null;
        txtCollectionDate.Text = DateUtil.getTodayDate();
        drpChequeStatus.ClearSelection();
        drpChequeStatus.Enabled = true;
        lbTxDate.CssClass = lbTxDate.CssClass.Replace("required", "").Trim();
        lbChqDate.CssClass = lbChqDate.CssClass.Replace("required", "").Trim();
        drpChequeStatus.Text = ChequeStatus.Cleared.ToString();
        PaymentMethod pymtMethod = EnumHelper.ToEnum<PaymentMethod>(drpPaymentMethod.Text);
        lbBankName.CssClass = lbChqDate.CssClass.Replace("required", "").Trim() + ((pymtMethod == PaymentMethod.CHEQUE) ? " required" : "");
    }
    private void resetNonCashFields()
    {
        txtMediaNo.Text = null;
        txtBankName.Text = null;
        txtBranch.Text = null;
    }
    private PropertyFundsDTO createPropertyFundsDTOForAdd()
    {
        PropertyFundsDTO propertyFundsDTO = new PropertyFundsDTO();
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();

        propertyFundsDTO.FirmNumber = userDefDto.FirmNumber;
        propertyFundsDTO.InsertUser = userDefDto.Username;
        propertyFundsDTO.UpdateUser = userDefDto.Username;

        return propertyFundsDTO;
    }
    private PropertyFundsDTO populatePropertyFundDTOFromUI()
    {
        PropertyFundsDTO propertyFundsDTO = getSessionPageData().PropertyFundsDTO;
        propertyFundsDTO.PymtMethod = EnumHelper.ToEnum<PaymentMethod>(drpPaymentMethod.Text);
        propertyFundsDTO.TxDate = DateUtil.getCSDateNotNull(txtTxDate.Text);
        propertyFundsDTO.Amount = CommonUtil.getDecimaNotNulllWithoutExt(txtPaymentAmt.Text);
        propertyFundsDTO.Comments = txtTxComments.Text;

        if (propertyFundsDTO.PymtMethod == PaymentMethod.CHEQUE)
        {
            propertyFundsDTO.ChequeDate = DateUtil.getCSDate(txtChequeDate.Text);
            propertyFundsDTO.PayName = txtPayName.Text;
        }
        if (propertyFundsDTO.PymtMethod != PaymentMethod.CASH)
        {
            propertyFundsDTO.MediaNo = txtMediaNo.Text;
            propertyFundsDTO.BankName = txtBankName.Text;
            propertyFundsDTO.Branch = txtBranch.Text;
        }
        propertyFundsDTO.FirmAccount = CommonUIConverter.getFirmAccountDTO(drpAccount.Text, drpAccount.SelectedItem.Text);
        propertyFundsDTO.Property = CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO());
        return propertyFundsDTO;
    }
    public static string getAcntTransCommentPymtMethod(PaymentMethod pymtMethod, string mediaNo)
    {
        string tmpComment = "";
        if (pymtMethod == PaymentMethod.CASH)
            tmpComment = Constants.CASH_PYMT_MODE;
        else if (pymtMethod == PaymentMethod.CHEQUE)
            tmpComment = string.Format(Constants.CHQ_PYMT_MODE, mediaNo);
        else if (pymtMethod == PaymentMethod.DD)
            tmpComment = Constants.DD_PYMT_MODE;
        else if (pymtMethod == PaymentMethod.NEFT)
            tmpComment = Constants.NEFT_PYMT_MODE;
        else if (pymtMethod == PaymentMethod.RTGS)
            tmpComment = Constants.RTGS_PYMT_MODE;
        return tmpComment;
    }
    private AccountTransactionDTO createAccountTransaction(PropertyFundsDTO propertyFundsDTO, bool isDelete)
    {
        AccountTransactionDTO acntTransDto = new AccountTransactionDTO();
        acntTransDto.FirmAccount = CommonUIConverter.getFirmAccountDTO(drpAccount.Text, drpAccount.SelectedItem.Text);
        PaymentTransactionDTO pymtTransDto = new PaymentTransactionDTO();
        string pymtMethodComment = CommonUtil.getAcntTransCommentPymtMethod(propertyFundsDTO.PymtMethod, propertyFundsDTO.MediaNo);
        if (isDelete)
        {
            acntTransDto.TxType = AcntTransStatus.Debit;
            acntTransDto.Comments = string.Format(Constants.REV_PYMT_FROM, "SELF") + "," + pymtMethodComment;
        }
        else
        {
            acntTransDto.Comments = string.Format(Constants.PYMT_FROM, "SELF") + "," + pymtMethodComment;
            acntTransDto.TxType = AcntTransStatus.Credit;
        }

        acntTransDto.TxDate = propertyFundsDTO.TxDate;
        decimal tmpvalue;
        decimal result = 0.0M;
        if (decimal.TryParse(propertyFundsDTO.Amount.ToString(), out tmpvalue))
            result = tmpvalue;
        acntTransDto.Amount = result;
        acntTransDto.FirmNumber = propertyFundsDTO.FirmNumber;
        acntTransDto.InsertUser = propertyFundsDTO.InsertUser;
        acntTransDto.UpdateUser = propertyFundsDTO.UpdateUser;
        return acntTransDto;

    }
    protected void onChangePymtMethod(object sender, EventArgs e)
    {
        try
        {
            resetChequeFields();
            resetNonCashFields();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }

}