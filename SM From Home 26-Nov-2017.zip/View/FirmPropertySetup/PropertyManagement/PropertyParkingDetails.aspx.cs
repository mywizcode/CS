﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.BO;

public partial class PropertyParkingDetails : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifyStep1Error = "addModifyStep1Error";
    string addMasterDataError = "addMasterDataError";
    string addMasterDataModal = "addMasterDataModal";
    DropdownBO drpBO = new DropdownBO();
    PropertyBO propertyBO = new PropertyBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    protected void Page_Load(object sender, EventArgs e)
    {
    	if (ApplicationUtil.isSubPageRendered(Page)) clearMessages();
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                PropertyParkingDetailNavDTO navDto = CommonUtil.getPageNavDTO<PropertyParkingDetailNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_PROPERTY_PARKING)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        setPageTitle();
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
    	ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpParkingType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_PARKING_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<CommonParking>(drpCommonParking, Constants.SELECT_ITEM);
        drpBO.drpEnum<ParkingStatus>(drpStatus, Constants.SELECT_ITEM);
    }
    private void setPageTitle()
    {
        if (isAddMode()) lbPageTitle.Text = Constants.ICON.ADD + Resources.Labels.ADD_PROPERTY_PARKING;
        else if (isModifyMode()) lbPageTitle.Text = Constants.ICON.MODIFY + Resources.Labels.MODIFY_PROPERTY_PARKING;
        else lbPageTitle.Text = Constants.ICON.VIEW_DTL + Resources.Labels.PROPERTY_PARKING_DETAILS;
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void renderPageFieldsWithEntitlement()
    {
        bool modifyMode = isModifyMode();
        bool viewMode = isViewMode();
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        //Fields
        txtParkingNo.ReadOnly = viewMode || modifyMode;
        drpParkingType.Enabled = !viewMode;
        txtParkingArea.ReadOnly = viewMode;
        drpStatus.Enabled = !viewMode;
        drpCommonParking.Enabled = !viewMode;
        //Buttons
        btnAddModifyPrParkingSubmit.Visible = !viewMode;
        addParkingTypeBtn.Visible = !viewMode && CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_MANAGE_MASTER);

        liModifyPropertyParking.Visible = viewMode && CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_PARKING_MODIFY);
    }
    private void doInit(PropertyParkingDetailNavDTO navDto)
    {
        initDropdowns();
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(PropertyParkingDetailNavDTO navDto)
    {
        if (navDto != null)
        {
            PropertyParkingDetailPageDTO PageDTO = new PropertyParkingDetailPageDTO();
            pageModeHdn.Value = navDto.Mode.ToString();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            if (isAddMode())
            {
                PageDTO.ParkingDTO = populatePropertyParkingDTOAdd();
                populateUIFieldsFromDTO(null);
            }
            else
            {
                PageDTO.ParkingDTO = propertyBO.fetchPropertyParkingDetails(navDto.ParkingId);
                populateUIFieldsFromDTO(PageDTO.ParkingDTO);
            }
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void navigateToPreviousPage()
    {
        PropertyParkingDetailPageDTO PageDTO = getSessionPageData();
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is PropertyParkingSearchNavDTO)
            {
                PropertyParkingSearchNavDTO navDTO = (PropertyParkingSearchNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.PROPERTY_PARKING_SEARCH, true);
            }
        }
        Response.Redirect(Constants.URL.PROPERTY_PARKING_SEARCH, true);
    }
    private bool isViewMode()
    {
        return PageMode.VIEW.ToString().Equals(pageModeHdn.Value);
    }
    private bool isAddMode()
    {
        return PageMode.ADD.ToString().Equals(pageModeHdn.Value);
    }
    private bool isModifyMode()
    {
        return PageMode.MODIFY.ToString().Equals(pageModeHdn.Value);
    }
    private PropertyParkingDetailPageDTO getSessionPageData()
    {
        return (PropertyParkingDetailPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    protected void onClickModifyPropertyParkingBtn(object sender, EventArgs e)
    {
        try
        {
            PropertyParkingDetailPageDTO PageDTO = getSessionPageData();
            PropertyParkingDTO parkingDTO = PageDTO.ParkingDTO;
            PropertyParkingDetailNavDTO navDTO = new PropertyParkingDetailNavDTO();
            navDTO.Mode = PageMode.MODIFY;
            navDTO.ParkingId = parkingDTO.Id;
            navDTO.PrevNavDto = PageDTO.PrevNavDTO;
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.PROPERTY_PARKING_DETAILS, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void addOrModifyPropertyParking(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyParkingAddOrModify())
            {
                PropertyParkingDetailPageDTO PageDTO = getSessionPageData();
                PropertyParkingDTO parkingDTO = PageDTO.ParkingDTO;
                populatePropertyParkingDTOFromUI(parkingDTO);
                long Id = parkingDTO.Id;
                string msg = "";
                if (isAddMode())
                {
                    Id = propertyBO.savePropertyParkingDetails(parkingDTO);
                    msg = string.Format("Property Parking '{0}' is added successfully.", parkingDTO.ParkingNo);
                }
                else if (isModifyMode())
                {
                    propertyBO.updatePropertyParkingDetails(parkingDTO);
                    msg = string.Format("Property Parking '{0}' is updated successfully.", parkingDTO.ParkingNo);
                }
                Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg(msg));
                navigateToPreviousPage();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addModifyStep1Error);
        }
    }
    protected void cancelPropertyParking(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    /**
     * Define all validation which will be done before add or Modify property.
     * */
    private bool validatePropertyParkingAddOrModify()
    {
        bool isValid = validateAllStep1Group();
        return isValid;
    }
    private bool validateAllStep1Group()
    {
        bool isValid = true;
        Page.Validate(addModifyStep1Error);
        isValid = Page.IsValid;
        if (isValid) isValid = validateParkingAddOrModifyOther();
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    private bool validateParkingAddOrModifyOther()
    {
        bool isValid = true;
        ParkingStatus status = EnumHelper.ToEnum<ParkingStatus>(drpStatus.Text);
        if (!(ParkingStatus.Available == status || ParkingStatus.Reserved == status))
        {
            isValid = false;
            setErrorMessage("Please select Status as 'Available' or 'Reserved'.", addModifyStep1Error);
        }
        if (isAddMode())
        {
            if (propertyBO.validateParkingExist(getUserDefinitionDTO().FirmNumber, CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Id, txtParkingNo.Text))
            {
                setErrorMessage("Property Parking already exist.", addModifyStep1Error);
                isValid = false;
            }
        }
        return isValid;
    }
    private PropertyParkingDTO populatePropertyParkingDTOAdd()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        PropertyParkingDTO propertyParkingDto = new PropertyParkingDTO();
        propertyParkingDto.PropertyTower = new PropertyTowerDTO();
        propertyParkingDto.PropertyTower.Id = CommonUtil.getStickyPrTowerDTO(userDefDto).Id;
        propertyParkingDto.FirmNumber = userDefDto.FirmNumber;
        propertyParkingDto.InsertUser = userDefDto.Username;
        return propertyParkingDto;
    }
    private void populatePropertyParkingDTOFromUI(PropertyParkingDTO propertyParkingDTO)
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        if (isAddMode())
        {
            propertyParkingDTO.ParkingNo = txtParkingNo.Text;
        }
        propertyParkingDTO.ParkingType = CommonUIConverter.getMasterControlDTO(drpParkingType.Text, null);
        propertyParkingDTO.Area = CommonUtil.getDecimalWithoutExt(txtParkingArea.Text);
        propertyParkingDTO.Status = EnumHelper.ToEnum<ParkingStatus>(drpStatus.Text);
        propertyParkingDTO.CommonParking = EnumHelper.ToEnum<CommonParking>(drpCommonParking.Text);
        propertyParkingDTO.FirmNumber = userDefDto.FirmNumber;
        propertyParkingDTO.Version = userDefDto.Version;
        propertyParkingDTO.UpdateUser = userDefDto.Username;
    }
    private void populateUIFieldsFromDTO(PropertyParkingDTO propertyParkingDTO)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        txtProperty.Text = CommonUtil.getCurrentPropertyDTO(userDefDto).Name;
        txtTower.Text = CommonUtil.getStickyPrTowerDTO(userDefDto).Name;
        if (propertyParkingDTO != null) drpParkingType.Text = propertyParkingDTO.ParkingType.Id.ToString(); else drpParkingType.Text = null;
        if (propertyParkingDTO != null && propertyParkingDTO.ParkingNo != null) txtParkingNo.Text = propertyParkingDTO.ParkingNo; else txtParkingNo.Text = null;
        if (propertyParkingDTO != null && propertyParkingDTO.Area != null) txtParkingArea.Text = propertyParkingDTO.Area.ToString(); else txtParkingArea.Text = null;
        if (propertyParkingDTO != null) drpStatus.Text = propertyParkingDTO.Status.ToString(); else drpStatus.Text = ParkingStatus.Available.ToString();
        if (propertyParkingDTO != null) drpCommonParking.Text = propertyParkingDTO.CommonParking.ToString(); else drpCommonParking.Text = CommonParking.No.ToString();
    }
    //Master Data Modal save logic - Start
    protected void saveMasterData(object sender, EventArgs e)
    {
        try
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (masterDataModalTypeHdn.Value == "PROPERTY_PARKING_TYPE")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_PARKING_TYPE, txtMasterDataInput1.Text,
                        txtMasterDataInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Parking Type");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpParkingType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_PARKING_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
            }
            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                activeModalHdn.Value = addMasterDataModal;
                setErrorMessage(errorMsg, addMasterDataError);
            }
            else
            {
                resetMasterDataModalFields();
                setParentModalFlag();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            activeModalHdn.Value = "";
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    protected void cancelMasterDataModal(object sender, EventArgs e)
    {
        try
        {
            resetMasterDataModalFields();
            setParentModalFlag();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    private void resetMasterDataModalFields()
    {
        txtMasterDataInput1.Text = "";
        txtMasterDataInput2.Text = "";
        masterDataModalTypeHdn.Value = "";
    }
    private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
    {
        string errorMsg = "";
        if (string.IsNullOrWhiteSpace(masterDataDto.Name))
        {
            errorMsg = string.Format(Resources.Messages.TEXTFIELD_REQUIRED, type);
        }
        else if (masterDataBO.isAlreadyExist(masterDataDto))
        {
            errorMsg = string.Format(Resources.Messages.ALREADY_EXIST_DB_ERROR, type);
        }
        return errorMsg;
    }
    private void setParentModalFlag()
    {
        activeModalHdn.Value = masterDataParentModalHdn.Value;
        masterDataParentModalHdn.Value = "";
    }
    //Master Data Modal save logic - End
}