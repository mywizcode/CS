﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ConstroSoft.Controller
{
    public class ExotelOutCallController : ApiController
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        [HttpPost]
        [ActionName("PostOutCallDetails")]
        public string PostOutCallDetails([FromBody]InOutBoundCallResDTO inOutBoundCallResDTO)
        {
            var response = JsonConvert.SerializeObject("Failure");
            try
            {
                //Validate the InOutBoundCallResDTO Mandatory Fields.
                //Update Outgoing call Details in DB
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while placing outbound call");
                log.Error(exp.Message, exp);
            }
            finally
            {
            }
            return response;
        }
    }
}