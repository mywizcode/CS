﻿using Newtonsoft.Json;
using System;
using System.Web.Http;

namespace ConstroSoft.Controller
{
    public class ExotelInCallController : ApiController
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        [HttpGet]
        [ActionName("GetInCallDetails")]
        public string GetInCallDetails([FromBody]InOutBoundCallResDTO inOutBoundCallResDTO)
        {
            var response = JsonConvert.SerializeObject("Failure");
            try
            {
                //Validate the InOutBoundCallResDTO Mandatory Fields.
                //Create In Coming Details in DB
                //Add Notificatoion to user about incoming call.
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while placing outbound call");
                log.Error(exp.Message, exp);
            }
            finally
            {
            }
            return response;
        }
    }
}