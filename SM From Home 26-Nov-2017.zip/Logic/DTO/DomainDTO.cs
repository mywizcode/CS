﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ConstroSoft;

/// <summary>
/// Summary description for UserDefinitionDTO
/// </summary>
namespace ConstroSoft
{
    [Serializable]
    public class AccountTransactionDTO
    {
        public AccountTransactionDTO() { }
        public long Id { get; set; }
        public System.DateTime TxDate { get; set; }
        public decimal Amount { get; set; }
        public AcntTransStatus TxType { get; set; }
        public string Comments { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public FirmAccountDTO FirmAccount { get; set; }
        public ISet<PaymentTransactionDTO> PaymentTransactions { get; set; }
        public System.Nullable<decimal> UiCreditAmt { get; set; }
        public System.Nullable<decimal> UiDebitAmt { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class AgencyDTO
    {
        public AgencyDTO() { }
        public long Id { get; set; }
        public string OwnerName { get; set; }
        public string AgencyName { get; set; }
        public string RegistrationNo { get; set; }
        public string Description { get; set; }
        public string Pan { get; set; }
        public string Salestaxnumber { get; set; }
        public string Centralsalestaxnumber { get; set; }
        public string Groupname { get; set; }
        public string Taxclassification { get; set; }
        public string Taxtype { get; set; }
        public string Billwise { get; set; }
        public string Currency { get; set; }
        public string Tallystatus { get; set; }
        public MPTBookDTO MPTAgencyBook { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public ContactInfoDTO ContactInfo { get; set; }
        public MasterControlDataDTO AgencyType { get; set; }
        public bool isUISelected { get; set; }
    }
    [Serializable]
    public class AddressDTO
    {
        public AddressDTO() { }
        public long Id { get; set; }
        public System.Nullable<PreferredAddress> PreferredAddress { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string Town { get; set; }
        public string Pin { get; set; }
        public MasterControlDataDTO AddressType { get; set; }
        public CityDTO City { get; set; }
        public StateDTO State { get; set; }
        public CountryDTO Country { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
        public string UiFullAddress { get; set; }
    }
    [Serializable]
    public class CityDTO
    {
        public CityDTO() { }
        public long Id { get; set; }
        public string Abbreviation { get; set; }
        public string Name { get; set; }
        public StateDTO State { get; set; }
        public ISet<FirmAccountDTO> FirmAccounts { get; set; }
    }
    [Serializable]
    public class CoCustomerDTO
    {
        public CoCustomerDTO() { }
        public long Id { get; set; }
        public string CustRefNo { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string FullName { get; set; }
        public string Pan { get; set; }
        public System.Nullable<PowerOfAtorny> IsPoa { get; set; }
        public string FirmNumber { get; set; }
        public MasterControlDataDTO SalutationId { get; set; }
        public ContactInfoDTO ContactInfo { get; set; }
        public PrUnitSaleDetailDTO PrUnitSaleDetail { get; set; }
        public MasterControlDataDTO RelationWhPrimCust { get; set; }
        public MasterControlDataDTO Occupation { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class ContactInfoDTO
    {
        public ContactInfoDTO() { }
        public long Id { get; set; }
        public string Contact { get; set; }
        public string AltContact { get; set; }
        public System.Nullable<Gender> Gender { get; set; }
        public System.Nullable<MaritalStatus> MaritalStatus { get; set; }
        public string Email { get; set; }
        public string AltEmail { get; set; }
        public System.Nullable<System.DateTime> Dob { get; set; }
        public ISet<AddressDTO> Addresses { get; set; }
        public ISet<CoCustomerDTO> CoCustomers { get; set; }
        public ISet<CustomerDTO> Customers { get; set; }
        public ISet<EnquiryDetailDTO> EnquiryDetails { get; set; }
        public ISet<FirmDTO> Firms { get; set; }
        public ISet<FirmMemberDTO> FirmMembers { get; set; }
        public ISet<PropertyDTO> Properties { get; set; }
    }
    [Serializable]
    public class CountryDTO
    {
        public CountryDTO() { }
        public long Id { get; set; }
        public string Abbreviation { get; set; }
        public string Name { get; set; }
        public ISet<FirmAccountDTO> FirmAccounts { get; set; }
        public ISet<StateDTO> States { get; set; }
    }
    [Serializable]
    public class CustomerDTO
    {
        public CustomerDTO() { }
        public long Id { get; set; }
        public string CustRefNo { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public FamilyRelation FamilyRelationship { get; set; }
        public string FamilyRelName { get; set; }
        public string Pan { get; set; }
        public string PassportNo { get; set; }
        public string AadharNo { get; set; }
        public string Fax { get; set; }
        public string Groupname { get; set; }
        public string Taxclassification { get; set; }
        public string Taxtype { get; set; }
        public string Billwise { get; set; }
        public string Currency { get; set; }
        public string Tallystatus { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public ContactInfoDTO ContactInfo { get; set; }
        public MasterControlDataDTO Salutation { get; set; }
        public CountryDTO Nationality { get; set; }
        public MasterControlDataDTO ResidentialStatus { get; set; }
        public MasterControlDataDTO Occupation { get; set; }
        public ISet<PrUnitSaleDetailDTO> PrUnitSaleDetails { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
        public string FullName { get; set; }
    }
    [Serializable]
    public class DocumentDTO
    {
        public DocumentDTO() { }
        public long Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Extension { get; set; }
        public string ContentType { get; set; }
        public byte[] Content { get; set; }
        public string FirmNumber { get; set; }
        public string FileName { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public MasterControlDataDTO DocumentType { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class DocumentInfoDTO
    {
        public DocumentInfoDTO() { }
        public long Id { get; set; }
        public string Description { get; set; }
        public ISet<CustomerDTO> Customers { get; set; }
        public ISet<DocumentDTO> Documents { get; set; }
        public ISet<PropertyDTO> Properties { get; set; }
        public ISet<PropertyExpenseDTO> PropertyExpenses { get; set; }
        public ISet<AgencyDTO> agency { get; set; }
    }
    [Serializable]
    public class EnquiryDetailDTO
    {
        public EnquiryDetailDTO() { }
        public long Id { get; set; }
        public string EnquiryRefNo { get; set; }
        public string FirstName { get; set; }
        public string FullName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public System.DateTime EnquiryDate { get; set; }
        public System.Nullable<System.DateTime> AssignedDate { get; set; }
        public System.Nullable<System.DateTime> DateClosed { get; set; }
        public System.Nullable<decimal> Budget { get; set; }
        public EnquiryStatus Status { get; set; }
        public string Comments { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public ContactInfoDTO ContactInfo { get; set; }
        public LeadDetailDTO Lead { get; set; }
        public PrUnitSaleDetailDTO PrUnitSaleDetail { get; set; }
        public MasterControlDataDTO Salutation { get; set; }
        public MasterControlDataDTO Occupation { get; set; }
        public PropertyDTO Property { get; set; }
        public MasterControlDataDTO PrUnitType { get; set; }
        public MasterControlDataDTO EnquirySource { get; set; }
        public FirmMemberDTO Assignee { get; set; }
        public ISet<EnquiryActivityDTO> EnquiryActivities { get; set; }
        public List<EnquiryActivityDTO> UpcomingEvents { get; set; }
        public int NoOfDaysAssgined { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class EnquiryActivityDTO
    {
        public EnquiryActivityDTO() { }
        public long Id { get; set; }
        public EnqActivityRecordType RecordType { get; set; }
        public EnqActivityType ActivityType { get; set; }
        public EventTaskMode EventTaskMode { get; set; }
        public System.DateTime DateLogged { get; set; }
        public System.Nullable<System.DateTime> ScheduledDate { get; set; }
        public string Comments { get; set; }
        public EnqLeadActivityStatus Status { get; set; }
        public string RefNo { get; set; }
        public string RevRefNo { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public EnquiryDetailDTO EnquiryDetail { get; set; }
        public FirmMemberDTO LoggedBy { get; set; }
        public MasterControlDataDTO CommunicationMedia { get; set; }
        public string ActivityTypeDesc { get; set; }
        public System.Nullable<System.DateTime> PrevScheduledDate { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class LeadDetailDTO
    {
        public LeadDetailDTO() { }
        public long Id { get; set; }
        public string LeadRefNo { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public System.DateTime LeadDate { get; set; }
        public System.Nullable<System.DateTime> AssignedDate { get; set; }
        public System.Nullable<System.DateTime> DateClosed { get; set; }
        public System.Nullable<decimal> Budget { get; set; }
        public LeadStatus Status { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public ContactInfoDTO ContactInfo { get; set; }
        public MasterControlDataDTO Salutation { get; set; }
        public PropertyDTO Property { get; set; }
        public MasterControlDataDTO Source { get; set; }
        public FirmMemberDTO Assignee { get; set; }
        public EnquiryDetailDTO EnquiryDetail { get; set; }
        public ISet<LeadActivityDTO> LeadActivities { get; set; }
        public List<LeadActivityDTO> UpcomingEvents { get; set; }
        public string FullName { get; set; }
        public int NoOfDaysAssgined { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
        public string PropertyName { get; set; }
        public string Contact { get; set; }
        public string Email { get; set; }
        public string TokenNumber { get; set; }
        public string Salutationstr { get; set; }
    }
    [Serializable]
    public class LeadActivityDTO
    {
        public LeadActivityDTO() { }
        public long Id { get; set; }
        public EnqActivityRecordType RecordType { get; set; }
        public EnqActivityType ActivityType { get; set; }
        public EventTaskMode EventTaskMode { get; set; }
        public System.DateTime DateLogged { get; set; }
        public System.Nullable<System.DateTime> ScheduledDate { get; set; }
        public string Comments { get; set; }
        public EnqLeadActivityStatus Status { get; set; }
        public string RefNo { get; set; }
        public string RevRefNo { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public LeadDetailDTO LeadDetail { get; set; }
        public FirmMemberDTO LoggedBy { get; set; }
        public MasterControlDataDTO CommunicationMedia { get; set; }
        public string ActivityTypeDesc { get; set; }
        public System.Nullable<System.DateTime> PrevScheduledDate { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class EventlogDTO
    {
        public EventlogDTO() { }
        public long Id { get; set; }
        public string Title { get; set; }
        public System.DateTime StartDate { get; set; }
        public System.DateTime EndDate { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
    }
    [Serializable]
    public class FirmDTO
    {
        public FirmDTO() { }
        public long Id { get; set; }
        public string Name { get; set; }
        public string FirmNumber { get; set; }
        public string RegistrationNo { get; set; }
        public string GSTin { get; set; }
        public string WebSite { get; set; }
        public string Description { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public ContactInfoDTO ContactInfo { get; set; }
        public ISet<FirmAccountDTO> FirmAccounts { get; set; }
    }
    [Serializable]
    public class FirmAccountDTO
    {
        public FirmAccountDTO() { }
        public long Id { get; set; }
        public string Name { get; set; }
        public string AccountNo { get; set; }
        public decimal AccountBalance { get; set; }
        public string IfscCode { get; set; }
        public string BankName { get; set; }
        public string Branch { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public ISet<AccountTransactionDTO> AccountTransactions { get; set; }
        public CityDTO City { get; set; }
        public CountryDTO Country { get; set; }
        public FirmDTO Firm { get; set; }
        public MasterControlDataDTO AccountType { get; set; }
        public StateDTO State { get; set; }
        public ISet<PropertyFundsDTO> PropertyFunds { get; set; }
        public ISet<PropertyDTO> Properties { get; set; }
        public string RowInfo { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public List<FirmAccountDTO> SearchResult { get; set; }
        public FirmAccountDTO SelectedFirmAccount { get; set; }
        public ISet<FirmAccountDTO> FirmAccountList { get; set; }
    }
    [Serializable]
    public class PropertyFundsDTO
    {
        public PropertyFundsDTO() { }
        public long Id { get; set; }
        public System.DateTime TxDate { get; set; }
        public System.Nullable<decimal> Amount { get; set; }
        public PaymentMethod PymtMethod { get; set; }
        public string BankName { get; set; }
        public string Branch { get; set; }
        public string MediaNo { get; set; }
        public string PayName { get; set; }
        public System.Nullable<System.DateTime> ChequeDate { get; set; }
        public string Comments { get; set; }
        public PropertyFundStatus Status { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public FirmAccountDTO FirmAccount { get; set; }
        public PropertyDTO Property { get; set; }
        public AccountTransactionDTO AccountTransaction { get; set; }
        public string RowInfo { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
    }
    [Serializable]
    public class FirmMemberDTO
    {
        public FirmMemberDTO() { }
        public long Id { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public System.Nullable<System.DateTime> JoiningDate { get; set; }
        public string Qualification { get; set; }
        public string Description { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public ContactInfoDTO ContactInfo { get; set; }
        public MasterControlDataDTO Salutation { get; set; }
        public MasterControlDataDTO Designation { get; set; }
        public bool isUISelected { get; set; }
        public string FullName { get; set; }
    }
    [Serializable]
    public class MasterControlDataDTO
    {
        public MasterControlDataDTO() { }
        public long Id { get; set; }
        public string Type { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
         public SystemDefined SystemDefined { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public bool isUISelected { get; set; }
        public long UiIndex { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class PaymentMasterDTO
    {
        public PaymentMasterDTO() { }
        public long Id { get; set; }
        public decimal TotalAmt { get; set; }
        public decimal TotalPaid { get; set; }
        public decimal TotalPending { get; set; }
        public decimal TotalPdcAmt { get; set; }
        public PymtMasterStatus Status { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public ISet<PaymentTransactionDTO> PaymentTransactions { get; set; }
        public ISet<PaymentTransactionDTO> PendingTransactions { get; set; }
        public ISet<MasterPymtTransactionDTO> MasterPymtTransactions { get; set; }
        public ISet<PrUnitSalePymtDTO> PrUnitSalePymts { get; set; }
        public ISet<PropertyExpenseDTO> PropertyExpenses { get; set; }
        public PaymentTransactionDTO UIPymtTransaction { get; set; }
        public bool hasTransactrions { get; set; }
    }
    [Serializable]
    public class PaymentTransactionDTO
    {
        public PaymentTransactionDTO() { }
        public long Id { get; set; }
        public System.DateTime TxDate { get; set; }
        public decimal Amount { get; set; }
        public PymtTransRcptDelivered RcptDelivered { get; set; }
        public System.Nullable<System.DateTime> RcptDeliveryDate { get; set; }
        public PymtTransStatus Status { get; set; }
        public string InvoiceNumber { get; set; }
        public string Comments { get; set; }
        public string RcptDocPath { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public AccountTransactionDTO AccountTransaction { get; set; }
        public FirmAccountDTO FirmAccount { get; set; }
        public MasterPymtTransactionDTO MasterPymtTransaction { get; set; }
        public PaymentMasterDTO PaymentMaster { get; set; }
        public PaymentTransactionDTO CancelledPaymentTransaction { get; set; }
        public PaymentVoucherDTO PaymentVoucherDTO { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class MPTBookDTO
    {
        public MPTBookDTO() { }
        public long Id { get; set; }
        public string Description { get; set; }
        public PrUnitSaleDetailDTO PrUnitSaleDetail { get; set; }
        public AgencyDTO Agency { get; set; }
        public ISet<MasterPymtTransactionDTO> MasterPymtTransactions { get; set; }
    }
    [Serializable]
    public class PropertyDTO
    {
        public PropertyDTO() { }
        public long Id { get; set; }
        public string Name { get; set; }
        public System.Nullable<decimal> PropertyArea { get; set; }
        public string Description { get; set; }
        public System.Nullable<decimal> EstimatedAmt { get; set; }
        public string ReraRegNo { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public ContactInfoDTO ContactInfo { get; set; }
        public ISet<EnquiryDetailDTO> EnquiryDetails { get; set; }
        public FirmAccountDTO FirmAccount { get; set; }
        public MasterControlDataDTO PropertyType { get; set; }
        public MasterControlDataDTO PropertyLocation { get; set; }
        public ISet<PropertyChargeDTO> PropertyCharges { get; set; }
        public ISet<PropertyExpenseDTO> PropertyExpenses { get; set; }
        public ISet<PropertyTaxDetailDTO> PropertyTaxDetails { get; set; }
        public ISet<PropertyTowerDTO> PropertyTowers { get; set; }
        public ISet<PropertyFMAccessDTO> PropertyFMAccess { get; set; }
        public ISet<EmailSmsAlertConfigDTO> AssignedAlerts { get; set; }
        public bool isUISelected { get; set; }
    }
    [Serializable]
    public class PropertyFMAccessDTO
    {
        public PropertyFMAccessDTO() { }
        public PropertyDTO Property { get; set; }
        public FirmMemberDTO FirmMember { get; set; }
        public PrFMAccess hasAccess { get; set; }
    }
    [Serializable]
    public class PropertyChargeDTO
    {
        public PropertyChargeDTO() { }
        public long Id { get; set; }
        public System.Nullable<decimal> ChargeValue { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public MasterControlDataDTO ChargeType { get; set; }
        public PropertyDTO Property { get; set; }
        public bool isUISelected { get; set; }
        public long UiIndex { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class PropertyExpenseDTO
    {
        public PropertyExpenseDTO() { }
        public long Id { get; set; }
        public System.DateTime ExpenseDate { get; set; }
        public System.Nullable<decimal> Amount { get; set; }
        public string Comments { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public AgencyDTO Agency { get; set; }
        public FirmMemberDTO FirmMember { get; set; }
        public MasterControlDataDTO ExpenseType { get; set; }
        public PaymentMasterDTO PaymentMaster { get; set; }
        public PropertyDTO Property { get; set; }
        public bool isUISelected { get; set; }
        public long UiIndex { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class PropertyParkingDTO
    {
        public PropertyParkingDTO() { }
        public long Id { get; set; }
        public string ParkingNo { get; set; }
        public string TowerName { get; set; }
        public System.Nullable<decimal> Area { get; set; }
        public CommonParking CommonParking { get; set; }
        public ParkingStatus Status { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public MasterControlDataDTO ParkingType { get; set; }
        public PropertyTowerDTO PropertyTower { get; set; }
        public ISet<PropertyUnitDTO> PropertyUnits { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
        public bool isError { get; set; }
        public string ErrorMessage { get; set; }
    }
    [Serializable]
    public class PropertyScheduleDTO
    {
        public PropertyScheduleDTO() { }
        public long Id { get; set; }
        public string StageAbbr { get; set; }
        public string Stage { get; set; }
        public decimal Percentage { get; set; }
        public PRScheduleStageStatus Status { get; set; }
        public int StageNumber { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public PropertyTowerDTO PropertyTower { get; set; }
        public decimal TotalPercentage { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class PropertyTaxDetailDTO
    {
        public PropertyTaxDetailDTO() { }
        public long Id { get; set; }
        public decimal TaxPercentage { get; set; }
        public IncludeInPymtTotal IncludeInTotalPymt { get; set; }
        public decimal TaxAmtLimit { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public MasterControlDataDTO TaxType { get; set; }
        public PropertyDTO Property { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class PropertyTowerDTO
    {
        public PropertyTowerDTO() { }
        public long Id { get; set; }
        public string Name { get; set; }
        public System.Nullable<decimal> Rate { get; set; }
        public System.Nullable<System.DateTime> LaunchDate { get; set; }
        public System.Nullable<System.DateTime> Possession { get; set; }
        public string Description { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public PropertyDTO Property { get; set; }
        public ISet<PropertyParkingDTO> PropertyParkings { get; set; }
        public ISet<PropertyScheduleDTO> PropertySchedules { get; set; }
        public ISet<PropertyUnitDTO> PropertyUnits { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class PropertyUnitDTO
    {
        public PropertyUnitDTO() { }
        public long Id { get; set; }
        public string TowerName { get; set; }
        public string Wing { get; set; }
        public string FloorNo { get; set; }
        public string UnitNo { get; set; }
        public System.Nullable<decimal> BuildupArea { get; set; }
        public System.Nullable<decimal> CarpetArea { get; set; }
        public System.Nullable<decimal> BalconyArea { get; set; }
        public int NoOfBalcony { get; set; }
        public PRUnitStatus Status { get; set; }
        public string ReserveComments { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public MasterControlDataDTO UnitType { get; set; }
        public MasterControlDataDTO Facing { get; set; }
        public MasterControlDataDTO Direction { get; set; }
        public ISet<PrUnitSaleDetailDTO> PrUnitSaleDetails { get; set; }
        public ISet<PropertyParkingDTO> PropertyParkings { get; set; }
        public PropertyTowerDTO PropertyTower { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
        public bool isError { get; set; }
        public string ErrorMessage { get; set; }
    }
    
    [Serializable]
    public class MasterPymtTransactionDTO
    {
        public MasterPymtTransactionDTO() { }
        public long Id { get; set; }
        public PaymentMode PymtMode { get; set; }
        public string TxRefNo { get; set; }   
        public PaymentMethod PymtMethod { get; set; }
        public System.DateTime TxDate { get; set; }
        public decimal PymtAmt { get; set; }
        public System.Nullable<System.DateTime> CollectionDate { get; set; }
        public System.Nullable<System.DateTime> ChequeDate { get; set; }
        public System.Nullable<System.DateTime> ClearanceDate { get; set; }
        public string PayName { get; set; }
        public string BankName { get; set; }
        public string Branch { get; set; }        
        public string MediaNo { get; set; }
        public ChequeStatus? ChequeStatus { get; set; }
        public string Comments { get; set; }
        public MPTPymtStatus PymtStatus { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public PropertyDTO Property { get; set; }
        public MPTBookDTO MPTBook { get; set; }
        public ISet<PaymentTransactionDTO> PaymentTransactions { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class PostDatedChequeSearchDTO
    {
        public PostDatedChequeSearchDTO() { }
        public long Id { get; set; }
        public System.DateTime CollectionDate { get; set; }
        public System.Nullable<System.DateTime> ChequeDate { get; set; }
        public decimal PymtAmt { get; set; }
        public string BankName { get; set; }
        public string Branch { get; set; }
        public string MediaNo { get; set; }
        public ChequeStatus ChequeStatus { get; set; }
        public string Description { get; set; }
        public MPTPymtStatus PymtStatus { get; set; }
        public long ChqDrawerId { get; set; }
        public string ChqDrawerName { get; set; }
        public long ChqPayeeId { get; set; }
        public string ChqPayeeName { get; set; }
        public System.Nullable<System.DateTime> ClearanceDate { get; set; }
        public FirmAccountDTO FirmAccount { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class PrUnitSaleDetailDTO
    {
        public PrUnitSaleDetailDTO() { }
        public long Id { get; set; }
        public string BookingRefNo { get; set; }
        public System.DateTime BookingDate { get; set; }
        public decimal SaleRate { get; set; }
        public IsAgreementDone IsAgreementDone { get; set; }
        public System.Nullable<System.DateTime> AgreementDate { get; set; }
        public string AgreementNo { get; set; }
        public IsPossessionDone IsPossessionDone { get; set; }
        public System.Nullable<System.DateTime> PossessionDate { get; set; }
        public string LoanBankName { get; set; }
        public string LoanBankBranch { get; set; }
        public System.Nullable<decimal> LoanAmt { get; set; }
        public decimal AgreementAmt { get; set; }
        public decimal TotalTaxAmt { get; set; }
        public System.Nullable<decimal> TotalOtherAmt { get; set; }
        public decimal TotalPymtAmt { get; set; }
        public System.Nullable<decimal> TotalCashAmt { get; set; }
        public decimal TotalPackageCost { get; set; }
        public System.Nullable<System.DateTime> CanellationDate { get; set; }
        public System.Nullable<decimal> CancellationFee { get; set; }
        public string CancellationReason { get; set; }
        public PRUnitSaleStatus Status { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public CustomerDTO Customer { get; set; }
        public FirmMemberDTO FirmMember { get; set; }
        public EnquiryDetailDTO Enquiry { get; set; }
        public FirmMemberDTO CancellationFirmMember { get; set; }
        public PropertyUnitDTO PropertyUnit { get; set; }
        public ISet<DemandLetterHistoryDTO> DemandLetterHistory { get; set; }
        public ISet<PrUnitSalePymtDTO> PrUnitSalePymts { get; set; }
        public ISet<PrUnitSaleTaxDetailDTO> PrUnitSaleTaxDetails { get; set; }
        public ISet<PropertyParkingDTO> PrParkings { get; set; }
        public ISet<CoCustomerDTO> CoCustomers { get; set; }
        public MPTBookDTO MPTUnitBook { get; set; }
        public List<PrUnitSaleTaxDetailDTO> uiTaxDetails { get; set; }
        public List<PrUnitSaleTaxDetailDTO> uiCMTaxDetails { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class DemandLetterHistoryDTO
    {
        public DemandLetterHistoryDTO() { }
        public long Id { get; set; }
        public System.DateTime UploadDate { get; set; }
        public System.DateTime DeliveryDate { get; set; }
        public string FileName { get; set; }
        public string DocumentPath { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public FirmMemberDTO UploadBy { get; set; }
        public PrUnitSaleDetailDTO PrUnitSaleDetail { get; set; }
        public PropertyScheduleDTO Stage { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class PrUnitSalePymtDTO
    {
        public PrUnitSalePymtDTO() { }
        public long Id { get; set; }
        public System.DateTime PymtDate { get; set; }
        public decimal PymtAmt { get; set; }
        public PaymentMode PymtMode { get; set; }
        public string Description { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public MasterControlDataDTO PymtType { get; set; }
        public PaymentMasterDTO PaymentMaster { get; set; }
        public PrUnitSaleDetailDTO PrUnitSaleDetail { get; set; }
        public bool HasAmtDistributed { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class PrUnitSaleTaxDetailDTO
    {
        public PrUnitSaleTaxDetailDTO() { }
        public long Id { get; set; }
        public decimal TaxPercentage { get; set; }
        public decimal TaxAmtLimit { get; set; }
        public decimal TaxAmt { get; set; }
        public IncludeInPymtTotal IncludeInTotalPymt { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public MasterControlDataDTO TaxType { get; set; }
        public PrUnitSaleDetailDTO PrUnitSaleDetail { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class StateDTO
    {
        public StateDTO() { }
        public long Id { get; set; }
        public string Abbreviation { get; set; }
        public string Name { get; set; }
        public ISet<CityDTO> Cities { get; set; }
        public CountryDTO Country { get; set; }
        public ISet<FirmAccountDTO> FirmAccounts { get; set; }
    }
    [Serializable]
    public class UserDefinitionDTO
    {
        public UserDefinitionDTO() { }
        public long Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string SecurityAnswer { get; set; }
        public System.Nullable<System.DateTime> ActivationDate { get; set; }
        public System.Nullable<System.DateTime> ExpirationDate { get; set; }
        public UserStatus Status { get; set; }
        public byte[] ProfileImg { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public SecurityQuestionDTO SecurityQuestion { get; set; }
        public UserRoleDTO UserRole { get; set; }
        public FirmMemberDTO FirmMember { get; set; }
        public bool hasPropertyAccess { get; set; }
        public List<PropertyDTO> AssignedProperties { get; set; }
        public PropertyTowerDTO StickyTowerDTO { get; set; }
        public bool isUISelected { get; set; }
        public string Extension { get; set; }
        public string ContentType { get; set; }       
        public string FileName { get; set; }
    }
    [Serializable]
    public class UserEntitlementDTO
    {
        public UserEntitlementDTO() { }
        public long Id { get; set; }
        public string Name { get; set; }
        public int Level { get; set; }
        public string Description { get; set; }
        public UserEntitlementDTO parent { get; set; }
        public ISet<UserRoleDTO> UserRoles { get; set; }
    }
    [Serializable]
    public class UserRoleDTO
    {
        public UserRoleDTO() { }
        public long Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public ISet<UserDefinitionDTO> UserDefinitions { get; set; }
        public ISet<UserEntitlementDTO> UserEntitlements { get; set; }
        public List<string> EntitlementAssigned { get; set; }
    }
    [Serializable]
    public class SecurityQuestionDTO
    {
        public SecurityQuestionDTO() { }
        public long Id { get; set; }
        public string Question { get; set; }
    }
    [Serializable]
    public class ReportConfigDTO
    {
        public ReportConfigDTO() { }
        public long Id { get; set; }
        public string ReportName { get; set; }
        public string ReportPath { get; set; }
        public string ReportDecription { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
   }

    [Serializable]
    public class EmailConfigDTO
    {
        public EmailConfigDTO() { }
        public long Id { get; set; }
        public string SmtpHost { get; set; }
        public string SmtpPort { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string EnableSsl { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public bool isUISelected { get; set; }
    }
    [Serializable]
    public class SmsConfigDTO
    {
        public SmsConfigDTO() { }
        public long Id { get; set; }
        public string Url { get; set; }
        public string UserId { get; set; }
        public string Password { get; set; }
        public string SenderId { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
    }
    [Serializable]
    public class EmailSmsAlertConfigDTO
    {
        public EmailSmsAlertConfigDTO() { }
        public long Id { get; set; }
        public System.Nullable<FunctionName> FunctionName { get; set; }
        public System.Nullable<EmailSmsType> EmailSmsType { get; set; }
        public string Subject { get; set; }
        public string SmsContent { get; set; }
        public string EmailTemplatePath { get; set; }
        public string Email { get; set; }
        public string Sms { get; set; }
        public string EmailBody { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public bool isUISelected { get; set; }
    }
    [Serializable]
    public class PropertyAlertConfigDTO
    {
        public PropertyAlertConfigDTO() { }
        public long Id { get; set; }
        public PropertyDTO propertyDTO { get; set; }
        public System.Nullable<FunctionName> FunctionName { get; set; }
        public string FunctionNameStr { get { return FunctionName.GetDescription(); } }
        public System.Nullable<EmailSmsType> EmailSmsType { get; set; }
        public string EmailSmsTypeStr { get { return EmailSmsType.GetDescription(); } }
        public EmailConfigDTO EmailConfigDTO { get; set; }
        public SmsConfigDTO SmsConfigDTO { get; set; }
        public string Subject { get; set; }
        public string EmailContent { get; set; }
        public string SmsContent { get; set; }
        public string EmailTemplatePath { get; set; }
        public string Email { get; set; }
        public string Sms { get; set; }
        public string EmailBody { get; set; }
        public ISet<Property> AssignedProperties { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public bool isUISelected { get; set; }
    }
    [Serializable]
    public class PromoRecipient
    {
        public PromoRecipient() { }
        public string CustomerName {get; set;}
        public string Contact {get; set;}
        public string Email { get; set; }
        public long PropertyId { get; set; }
        public long TowerId { get; set; }
        public bool HasUnitPurchased { get; set; }
        public PromoCustomerType PromoCustomerType { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class PromoEmailTemplateDTO
    {
        public PromoEmailTemplateDTO() { }
        public long Id { get; set; }
        public string Name { get; set; }
        public string Subject { get; set; }
        public byte[] Content { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
    }
    [Serializable]
    public class TallyConfigDTO
    {
        public TallyConfigDTO() { }
        public long Id { get; set; }
        public string Tallyhost { get; set; }
        public string Tallyport { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
    }
    [Serializable]
    public class PaymentVoucherDTO
    {
    	public PaymentVoucherDTO() { }
    	public long Id { get; set; }
    	public string Action { get; set; }
    	public string VoucherType { get; set; }
    	public System.DateTime VoucherDate { get; set; }
    	public string VoucherNaration { get; set; }
    	public string VoucherNumber { get; set; }
    	public string PartyLedgerName { get; set; }
    	public System.DateTime VoucherEffectiveDate { get; set; }
    	public string CstFromIssueType { get; set; }
    	public string CstFromRecvType { get; set; }
    	public string FbtPaymentType { get; set; }
    	public string PersistedView { get; set; }
    	public string VchgstClass { get; set; }
    	public string HasCashFlow { get; set; }
    	public string PostingStatus { get; set; }
    	public PaymentTransactionDTO PaymentTransactionDTO { get; set; }
    	public ISet<PaymentLedgerDTO> PaymentLedgers { get; set; }
    	public string FirmNumber { get; set; }
    	public System.DateTime InsertDate { get; set; }
    	public System.DateTime UpdateDate { get; set; }
    	public long Version { get; set; }
    	public string InsertUser { get; set; }
    	public string UpdateUser { get; set; }
    	public long UiIndex { get; set; }
    	public bool isUISelected { get; set; }
    	public string RowInfo { get; set; }
    }
    [Serializable]
    public class PaymentLedgerDTO
    {
       	public PaymentLedgerDTO() { }
       	public long Id { get; set; }
       	public string LedgerName { get; set; }
       	public string LedgerType { get; set; }
       	public string IsDeemedPositive { get; set; }
       	public string LedgerFromItem { get; set; }
       	public string RemoveZeroEntries { get; set; }
       	public string IsPartyLedger { get; set; }
       	public string IsLastDeemedPositive { get; set; }
       	public decimal Amount { get; set; }
       	public decimal VatexpAmount { get; set; }
       	public PaymentVoucherDTO PaymentVoucherDTO { get; set; }
       	public ISet<BillAllocationDTO> BillAllocations { get; set; }
       	public ISet<BankAllocationDTO> BankAllocations { get; set; }
       	public string FirmNumber { get; set; }
       	public System.DateTime InsertDate { get; set; }
       	public System.DateTime UpdateDate { get; set; }
       	public long Version { get; set; }
       	public string InsertUser { get; set; }
       	public string UpdateUser { get; set; }
       	public long UiIndex { get; set; }
       	public bool isUISelected { get; set; }
       	public string RowInfo { get; set; }
    }
    [Serializable]
    public class BillAllocationDTO
    {
       	public BillAllocationDTO() { }
       	public long Id { get; set; }
       	public string Name { get; set; }
       	public string BillType { get; set; }
       	public string TdsDeductSpecialRate { get; set; }
       	public decimal Amount { get; set; }
       	public PaymentLedgerDTO PaymentLedgerDTO { get; set; }
       	public string FirmNumber { get; set; }
       	public System.DateTime InsertDate { get; set; }
       	public System.DateTime UpdateDate { get; set; }
       	public long Version { get; set; }
       	public string InsertUser { get; set; }
       	public string UpdateUser { get; set; }
       	public long UiIndex { get; set; }
       	public bool isUISelected { get; set; }
       	public string RowInfo { get; set; }
    }
    [Serializable]
    public class BankAllocationDTO
    {
       	public BankAllocationDTO() { }
       	public long Id { get; set; }
       	public System.DateTime BDate { get; set; }
       	public System.DateTime InstrumentDate { get; set; }
       	public string Name { get; set; }
       	public string TransactionType { get; set; }
       	public string BankName { get; set; }
       	public string BankBranchName { get; set; }
       	public string PaymentFavouring { get; set; }
       	public string ChequeCrossComment { get; set; }
       	public string InstrumentNumber { get; set; }
       	public string UniqueReferenceNumber { get; set; }
       	public string Status { get; set; }
       	public string PaymentMode { get; set; }
        public string BankPartyName { get; set; }
       	public string IsConnectedPayment { get; set; }
       	public string IsSplit { get; set; }
       	public string ChequePrinted { get; set; }
       	public string IsContractUsed { get; set; }
    	public decimal Amount { get; set; }public PaymentLedgerDTO PaymentLedgerDTO { get; set; }
       	public string FirmNumber { get; set; }
       	public System.DateTime InsertDate { get; set; }
       	public System.DateTime UpdateDate { get; set; }
       	public long Version { get; set; }
       	public string InsertUser { get; set; }
       	public string UpdateUser { get; set; }
       	public long UiIndex { get; set; }
       	public bool isUISelected { get; set; }
       	public string RowInfo { get; set; }
    }
    [Serializable]
    public class PortalUserDTO
    {
        public PortalUserDTO() { }
        public long Id { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
        public PortalTokenManagerDTO PortalTokenManagerDTO { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public bool isUISelected { get; set; }
    }
    [Serializable]
    public class PortalTokenManagerDTO
    {
        public PortalTokenManagerDTO() { }
        public long Id { get; set; }
        public string TokenKey { get; set; }
        public System.DateTime IssuedOn { get; set; }
        public System.DateTime ExpiresOn { get; set; }
        public PortalUserDTO PortalUserDTO { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public bool isUISelected { get; set; }
    }
    [Serializable]
    public class PropertyUserAccessDTO
    {
        public PropertyUserAccessDTO() { }
        public long Id { get; set; }
        public string Username { get; set; }
        public long firmMemberId { get; set; }
        public UserStatus Status { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public PrFMAccess hasAccess { get; set; }
        public bool isUISelected { get; set; }
    }
    [Serializable]
    public class NotificationDTO
    {
        public long Id { get; set; }
        //NotificationKey will hold key information which will be used to navigation to details page of corresponding notification.
        //For Example: It will hold Lead#, Enquiry# for Lead, Enquiry Assignment/Reassignment.
        public string Key { get; set; }
        public long PropertyId { get; set; }
        public NotificationType Type { get; set; }
        public string Message { get; set; }
        public NotificationStatus Status { get; set; }
        public string UserName { get; set; }
        public string FirmNumber { get; set; }
        public System.DateTime InsertDate { get; set; }
        public System.DateTime UpdateDate { get; set; }
        public long Version { get; set; }
        public string InsertUser { get; set; }
        public string UpdateUser { get; set; }
        public string[] MsgPlaceHolders { get; set; }
        public string ExtraInfo { get; set; }
        public bool isUISelected { get; set; }
    }
    [Serializable]
    public class TaskDTO
    {
        public string FirmNumber { get; set; }
        //TaskKey will hold key information which will be used to navigation to details page of corresponding task.
        //For Example: It will hold Task#, Event# for upcoming task or event.
        public long PropertyId { get; set; }
        public string TaskKey { get; set; }
        public TaskType TaskType { get; set; }
        public string TaskMessage { get; set; }
        public string UserName { get; set; }
        public bool isUISelected { get; set; }
    }
    [Serializable]
    public class JobDTO
    {
         public long Id { get; set; }
         public string JobName { get; set; }
         public string Description { get; set; }
         public JobIntervalType JobIntervalType { get; set; }
         public JobStatus JobStatus { get; set; }
         public string FirmNumber { get; set; }
         public System.DateTime InsertDate { get; set; }
         public System.DateTime UpdateDate { get; set; }
         public long Version { get; set; }
         public string InsertUser { get; set; }
         public string UpdateUser { get; set; }
         public bool isUISelected { get; set; }
    }
    [Serializable]
    public class JobHistoryDTO
    {
          public long Id { get; set; }
          public System.DateTime StartTime { get; set; }
          public System.DateTime EndTime { get; set; }
          public string Message { get; set; }
          public JobRunStatus JobRunStatus { get; set; }
          public JobDTO Job { get; set; }
          public string FirmNumber { get; set; }
          public System.DateTime InsertDate { get; set; }
          public System.DateTime UpdateDate { get; set; }
          public long Version { get; set; }
          public string InsertUser { get; set; }
          public string UpdateUser { get; set; }
          public bool isUISelected { get; set; }
    }
    [Serializable]
    public class InOutBoundCallResDTO
    {
        public Call Call { get; set; }       
    }
    [Serializable]
    public class Call
    {
             //An alpha-numeric unique identifier of the call
             public string Sid { get; set; }
             //
             public string ParentCallSid { get; set; }
             //Time in format YYYY-MM-DD HH:mm:ss; Date and time at which the user initiated the API
             public string DateCreated { get; set; }
             //Time in format YYYY-MM-DD HH:mm:ss; Date and time at which the status of the call was last updated in our system
             public string DateUpdated { get; set; }
             //Exotel account SID
             public string AccountSid { get; set; }
             //Customer's phone number
             public string To { get; set; }
             //User Phone Number, The phone number that will be called first
             public string From { get; set; }
             //This is your ExoPhone/Exotel Virtual Number
             public string PhoneNumberSid { get; set; }
             /*
              * When the call completes, an HTTP POST will be made to the URL mentioned with the following parameters:
              * queued - The call is ready and waiting in line before going out
              * in-progress - The call was answered and is currently in progress
              * completed - The call was answered and has ended normally
              * failed - The call could not be completed as dialled, most likely because the phone number was non-existent
              * busy - The caller received a busy signal no-answer - The call ended without being answered
              */
             public string Status { get; set; }
             //Time in format YYYY-MM-DD HH:mm:ss; Date and time when the call request was initiated to the operator
             public string StartTime { get; set; }
             //Time in format YYYY-MM-DD HH:mm:ss; Date and time when the call was completed
             public string EndTime { get; set; }
             //Call duration in seconds
             public string Duration { get; set; }
             //Double; If present, this will be the amount (in INR or USD) you have been charged for the call
             public string Price { get; set; }
             /**
              * inbound - Incoming call
              * outbound-dial - Outbound calls from Exotel dashboard
              * outbound-api - All other Outbound calls (API, campaign etc.)
              */
             public string Direction { get; set; }
             //human
             public string AnsweredBy { get; set; }

             public string ForwardedFrom { get; set; }
             public string CallerName { get; set; }
             //Uri is the path of the CallSid
             public string Uri { get; set; }
             //Link to the call recording
             public string RecordingUrl { get; set; }
             /**
              * When the call completes, an HTTP POST will be made to the URL mentioned with the following four parameters:
              * IVR only, no connect applet - call-attempt
              * Call conversation happened - completed
              * Client hung up during connect applet - client-hangup
              * Connect applet, no agent picked up - incomplete
              * Went to voicemail applet - voicemail
              */
             public string CallType { get; set; }
             /*
              * If there was a 'Gather' applet before this pass-through applet, the numbers that were gathered. 
              * NOTE: This parameter comes with a double quote (") before and after the number. 
              * You'll have to trim() this parameter for double quotes (") to get the actual digits.
              */
             public string digits { get; set; }
             //If the call was initiated via API , the value that was passed in CustomField in the API call.
             public string CustomField { get; set; }
             //Shows the number of the agent who was dialed to last.
             public string DialWhomNumber { get; set; }
    }
    
}    
