﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;


/// <summary>
/// Summary description for TaskBO
/// </summary>
namespace ConstroSoft
{
    public class TaskBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public TaskBO() { }

        public IList<TaskDTO> fetchUpcomingLeadTask(string firmNumber)
        {
            ISession session = null;
            IList<LeadActivity> result = new List<LeadActivity>();
            IList<TaskDTO> taskDtos = new List<TaskDTO>();
            DateTime cutOffDate = DateTime.Now.AddDays(5);
            try
            {
                session = NHibertnateSession.OpenSession();
                LeadActivity leadActivity = null;
                var query = session.QueryOver<LeadActivity>(() => leadActivity);
                result = query.Where(() => leadActivity.FirmNumber == firmNumber && leadActivity.RecordType == EnqActivityRecordType.Task && leadActivity.ScheduledDate <= cutOffDate).List<LeadActivity>();
                foreach (LeadActivity lActivity in result)
                {
                    TaskDTO taskDto = new TaskDTO();
                    taskDto.FirmNumber = lActivity.FirmNumber;
                    taskDto.TaskKey = lActivity.Id.ToString();
                    taskDto.PropertyId = lActivity.LeadDetail.Property.Id;
                    taskDto.TaskType = TaskType.TASK;
                    taskDto.TaskMessage = lActivity.RefNo+"¶"+lActivity.LeadDetail.LeadRefNo+"¶"+lActivity.ScheduledDate;
                    taskDto.UserName = lActivity.LoggedBy.FirstName+" "+lActivity.LoggedBy.LastName;
                    taskDtos.Add(taskDto);
                }

            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating Upcoming Lead tasks:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return taskDtos;
        }
        public IList<TaskDTO> fetchUpcomingEnquiryTaskandEvent(string firmNumber)
        {
            ISession session = null;
            IList<EnquiryActivity> result = new List<EnquiryActivity>();
            IList<TaskDTO> taskDtos = new List<TaskDTO>();
            DateTime cutOffDate = DateTime.Now.AddDays(5);
            try
            {
                session = NHibertnateSession.OpenSession();
                EnquiryActivity enquiryActivity = null;
                var query = session.QueryOver<EnquiryActivity>(() => enquiryActivity);
                result = query.Where(() => enquiryActivity.FirmNumber == firmNumber && (enquiryActivity.RecordType == EnqActivityRecordType.Task 
                        || enquiryActivity.RecordType == EnqActivityRecordType.Event) && enquiryActivity.ScheduledDate <= cutOffDate).List<EnquiryActivity>();
                foreach (EnquiryActivity eActivity in result)
                {
                    TaskDTO taskDto = new TaskDTO();
                    taskDto.FirmNumber = eActivity.FirmNumber;
                    taskDto.TaskKey = eActivity.Id.ToString();
                    taskDto.PropertyId = eActivity.EnquiryDetail.Property.Id;
                    if(enquiryActivity.RecordType == EnqActivityRecordType.Task ){
                        taskDto.TaskType = TaskType.TASK;
                        taskDto.TaskMessage = "Task"+"¶";
                    }
                    if(enquiryActivity.RecordType == EnqActivityRecordType.Event ){
                        taskDto.TaskType = TaskType.EVENT;
                        taskDto.TaskMessage = "Event"+"¶";
                    }
                    taskDto.TaskMessage = taskDto.TaskMessage+eActivity.RefNo+"¶"+eActivity.EnquiryDetail.EnquiryRefNo+"¶"+eActivity.ScheduledDate;
                    taskDto.UserName = eActivity.LoggedBy.FirstName+" "+eActivity.LoggedBy.LastName;
                    taskDtos.Add(taskDto);
                }

            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating Upcoming Enquiry tasks & events:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return taskDtos;
        }
        public IList<TaskDTO> fetchTotalUnassignedLeads(string firmNumber)
        {
            ISession session = null;
            int unassignedLead = 0;
            IList<TaskDTO> taskDtos = new List<TaskDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                LeadDetail leadDetail = null;
                var query = session.QueryOver<LeadDetail>(() => leadDetail);
                unassignedLead = query.Where(() => leadDetail.FirmNumber == firmNumber && leadDetail.Assignee == null).Select(Projections.RowCount()).SingleOrDefault<int>();
                
                var lst = session.QueryOver<LeadDetail>(() => leadDetail)
                        .Where(() => leadDetail.FirmNumber == firmNumber && leadDetail.Assignee == null)
                        .SelectList(list => list
                            .SelectCount(p => p.Id)
                            .SelectGroup(p => p.Property.Id)
                        ).List();
                foreach (LeadDetail leaddetails in lst)
                {
                  TaskDTO taskDto = new TaskDTO();
                  taskDto.FirmNumber = firmNumber;
                  taskDto.PropertyId = leaddetails.Property.Id;
                  //taskDto.TaskMessage = leaddetails.;
                  taskDto.TaskType = TaskType.UNASSIGNED_LEADS;
                  taskDtos.Add(taskDto);
                }   
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating Task Details:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return taskDtos;
        }
        
    }
}