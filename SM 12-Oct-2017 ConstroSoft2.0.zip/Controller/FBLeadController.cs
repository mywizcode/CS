﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ConstroSoft.Controller
{
    public class FBLeadController : ApiController
    {
        [HttpPost]
        [ActionName("PostLead")]
        public string PostLead([FromBody]LeadDetailDTO leadDetailDto)
        {
            FBIntegrationBO fBIntegrationBO = new FBIntegrationBO();
            var response = JsonConvert.SerializeObject("Failure");
            if (leadDetailDto != null)
            {
                string errorMessage = fBIntegrationBO.validateLeadFields(leadDetailDto);
                if (errorMessage == null)
                {
                    bool valid = fBIntegrationBO.checkTokenValidity(leadDetailDto);
                    if (valid)
                    {
                        fBIntegrationBO.savePortalLead(leadDetailDto);
                        response = JsonConvert.SerializeObject("Lead for " + leadDetailDto.FirstName + " " + leadDetailDto.LastName + " created successfully");
                    }
                    else
                    {
                        response = JsonConvert.SerializeObject("Authorization has been denied for this request, please login again.");
                    }
                }
                else
                {
                    response = JsonConvert.SerializeObject(errorMessage);
                }
            }
            else
            {
                response = JsonConvert.SerializeObject("Please provide valid lead input fields");
            }
            return response;
        }
    }
}