﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using ConstroSoft.Logic.BO;

public partial class SoldUnitSearch : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string SearchFilterModal = "SearchFilterModal";
    DropdownBO drpBO = new DropdownBO();
    SoldPropertyUnitBO soldUnitBO = new SoldPropertyUnitBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                SoldUnitSearchNavDTO navDto = (SoldUnitSearchNavDTO)Session[Constants.Session.NAV_DTO];
                Session.Remove(Constants.Session.NAV_DTO);
                Session.Remove(Constants.Session.PAGE_DATA);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(Constants.URL.DEFAULT_HOME_PAGE, false);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();

    }
    private void preRenderInitFormElements()
    {
    	renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpTowerFilter, DrpDataType.PROPERTY_TOWER, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(), null, userDefDto.FirmNumber);
        drpTowerFilter.Text = CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Id.ToString();
        drpBO.drpDataBase(drpCustomerFilter, DrpDataType.CUSTOMER_SEARCH_BY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpUnitNoFilter, DrpDataType.PR_TOWER_UNITS, drpTowerFilter.Text, Constants.SELECT_ITEM, userDefDto.FirmNumber);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void renderPageFieldsWithEntitlement()
    {
    }
    private void doInit(SoldUnitSearchNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new SoldUnitSearchPageDTO();
        initDropdowns();
        setSearchFilter(null);
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(SoldUnitSearchNavDTO navDto)
    {
        try
        {
            if (navDto != null)
            {
                setSearchFilter(navDto.filterDTO);
            }
            loadSoldUnitSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void setSearchGrid(IList<PrUnitSaleDetailDTO> tmpList)
    {
        getSessionPageData().SearchResult = (tmpList != null) ? tmpList.ToList<PrUnitSaleDetailDTO>() : new List<PrUnitSaleDetailDTO>();
        soldUnitSearchGrid.DataSource = getSearchPrSaleDetailList();
        soldUnitSearchGrid.DataBind();
    }
    private SoldUnitSearchPageDTO getSessionPageData()
    {
        return (SoldUnitSearchPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<PrUnitSaleDetailDTO> getSearchPrSaleDetailList()
    {
        return getSessionPageData().SearchResult;
    }
    private PrUnitSaleDetailDTO getSearchPrSaleDetailDTO(long Id)
    {
        List<PrUnitSaleDetailDTO> searchList = getSearchPrSaleDetailList();
        PrUnitSaleDetailDTO selectedUnitDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            selectedUnitDTO = searchList.Find(c => c.Id == Id);
        }
        return selectedUnitDTO;
    }
    private void loadSoldUnitSearchGrid()
    {
        IList<PrUnitSaleDetailDTO> results = soldUnitBO.fetchSoldOrCancelledPropertyUnits(long.Parse(drpTowerFilter.Text), getSearchFilter(), PRUnitSaleStatus.Sold);
        setSearchGrid(results);
    }
    private SoldUnitSearchNavDTO getCurrentPageNavigation()
    {
        SoldUnitSearchPageDTO PageDTO = getSessionPageData();
        SoldUnitSearchNavDTO navDTO = new SoldUnitSearchNavDTO();
        navDTO.filterDTO = getSearchFilter();
        return navDTO;
    }
    private void navigateToSoldUnitDetails(long selectedId, PageMode mode)
    {
        PrUnitSaleDetailDTO prUnitSaleDetailDTO = getSearchPrSaleDetailDTO(selectedId);
        SoldUnitDetailNavDTO navDTO = new SoldUnitDetailNavDTO();
        navDTO.Mode = mode;
        navDTO.PrUnitSaleDetailId = prUnitSaleDetailDTO.Id;
        navDTO.PrevNavDto = getCurrentPageNavigation();
        Session[Constants.Session.NAV_DTO] = navDTO;
        Response.Redirect(Constants.URL.SOLD_UNIT_DETAILS, true);
    }
    protected void onClickViewSoldUnitBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            navigateToSoldUnitDetails(selectedId, PageMode.VIEW);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifySoldUnitBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            navigateToSoldUnitDetails(selectedId, PageMode.MODIFY);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickCancelBookingBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            BookingCancellationNavDTO navDTO = new BookingCancellationNavDTO();
            navDTO.PrUnitSaleDetailId = selectedId;
            navDTO.PrevNavDto = getCurrentPageNavigation();
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.BOOKING_CANCELLATION);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickGenerateLettersBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            navigateToLetterDetails(selectedId, PageMode.GENERATELETTER);
            /*BookingCancelSuccessNavDTO navDTO = new BookingCancelSuccessNavDTO();
            navDTO.PrUnitSaleDetailId = selectedId;
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.BOOKING_CANCEL_SUCCESS, true);*/
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }    
    }
    private void navigateToLetterDetails(long selectedId, PageMode mode)
    {
        PrUnitSaleDetailDTO prUnitSaleDetailDTO = getSearchPrSaleDetailDTO(selectedId);
        LetterGenerationNavDTO navDTO = new LetterGenerationNavDTO();
        navDTO.Mode = mode;
        navDTO.PrUnitSaleDetailId = prUnitSaleDetailDTO.Id;
        SoldUnitSearchNavDTO searchNavDTO = new SoldUnitSearchNavDTO();
        searchNavDTO.filterDTO = getSearchFilter();
        navDTO.PrevNavDto = searchNavDTO;
        Session[Constants.Session.NAV_DTO] = navDTO;
        Response.Redirect(Constants.URL.GENERATE_LETTERS, true);
    }
    //Filter Criteria - Property Search - Start
    private SoldUnitFilterDTO getSearchFilter()
    {
        return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            SoldUnitFilterDTO filterDTO = getSearchFilter();
            drpBO.drpDataBase(drpUnitNoFilter, DrpDataType.PR_TOWER_UNITS, drpTowerFilter.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            if (filterDTO.CustomerId > 0) drpCustomerFilter.Text = filterDTO.CustomerId.ToString(); else drpCustomerFilter.ClearSelection();
            if (filterDTO.CustRefNo != null) txtCustRefNoFilter.Text = filterDTO.CustRefNo; else txtCustRefNoFilter.Text = null;
            if (filterDTO.UnitId > 0) drpUnitNoFilter.Text = filterDTO.UnitId.ToString(); else drpUnitNoFilter.ClearSelection();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onSelectFilterTower(object sender, EventArgs e)
    {
        try
        {
            drpBO.drpDataBase(drpUnitNoFilter, DrpDataType.PR_TOWER_UNITS, drpTowerFilter.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            activeModalHdn.Value = SearchFilterModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            CommonUtil.setStickyPrTowerDTO(getUserDefinitionDTO(), long.Parse(drpTowerFilter.Text), drpTowerFilter.SelectedItem.Text);
            SoldUnitFilterDTO filterDTO = new SoldUnitFilterDTO();
            if (!string.IsNullOrWhiteSpace(drpCustomerFilter.Text))
            {
                filterDTO.CustomerId = long.Parse(drpCustomerFilter.Text);
                filterDTO.CustomerName = drpCustomerFilter.SelectedItem.Text;
            }
            if (!string.IsNullOrWhiteSpace(txtCustRefNoFilter.Text))
            {
                filterDTO.CustRefNo = txtCustRefNoFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(drpUnitNoFilter.Text))
            {
                filterDTO.UnitId = long.Parse(drpUnitNoFilter.Text);
                filterDTO.UnitNo = drpUnitNoFilter.SelectedItem.Text;
            }
            setSearchFilter(filterDTO);
            loadSoldUnitSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            loadSoldUnitSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(SoldUnitFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new SoldUnitFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {
            drpTowerFilter.Text = CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Id.ToString();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            SoldUnitFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.CUSTOMER))
            {
                filterDTO.CustomerId = 0;
                filterDTO.CustomerName = "";
            }
            else if (token.StartsWith(Constants.FILTER.CUST_REF_NO)) filterDTO.CustRefNo = null;
            else if (token.StartsWith(Constants.FILTER.UNIT_NO))
            {
                filterDTO.UnitId = 0;
                filterDTO.UnitNo = "";
            }
            else if (token.StartsWith(Constants.FILTER.TOWER_NAME)) setNotyMsg(CommonUtil.getNotyInfoMsg(Resources.Messages.TOWER_FILTER_DEFAULT));

            setSearchFilterTokens();
            loadSoldUnitSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        SoldUnitFilterDTO filterDTO = getSearchFilter();
        string filter = CommonUtil.addFilterToken("", Constants.FILTER.TOWER_NAME + CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Name);
        if (filterDTO != null)
        {
            if (filterDTO.CustomerId > 0) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.CUSTOMER + filterDTO.CustomerName);
            if (filterDTO.CustRefNo != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.CUST_REF_NO + filterDTO.CustRefNo);
            if (filterDTO.UnitId > 0) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.UNIT_NO + filterDTO.UnitNo);
        }
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - PropertyUnit Search - End
}
