﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Net;
using System.IO;
using System.Windows.Forms;
using System.Net.Mail;
using ConstroSoft;
using ConstroSoft.Logic.BO;
using OfficeOpenXml;
using OfficeOpenXml.DataValidation;
using OfficeOpenXml.Style;
using System.Drawing;
using ConstroSoft.Logic.Util;
using System.Text;

public partial class MasterDataSetup : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifyMasterDataError = "addModifyMasterDataError";
    string addModifyMasterDataModal = "addModifyMasterDataModal";
    DropdownBO drpBO = new DropdownBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    public enum MCDModalAction { ADD, MODIFY }

    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                MasterDataSetupNavDTO navDto = (MasterDataSetupNavDTO)Session[Constants.Session.NAV_DTO];
                Session.Remove(Constants.Session.NAV_DTO);
                Session.Remove(Constants.Session.PAGE_DATA);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(Constants.URL.DEFAULT_HOME_PAGE, false);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpEnum<MasterDataType>(drpMasterDataType, null);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(MasterDataSetupNavDTO navDTO)
    {
        Session[Constants.Session.PAGE_DATA] = new MasterDataSetupPageDTO();
        initDropdowns();
        loadMasterDataGrid();
    }
    private void renderPageFieldsWithEntitlement()
    {

    }
    private MasterDataSetupPageDTO getSessionPageData()
    {
        return (MasterDataSetupPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<MasterControlDataDTO> getMasterDataList()
    {
        return getSessionPageData().SearchResult;
    }
    private MasterControlDataDTO getMasterDataDTO(long Id)
    {
        List<MasterControlDataDTO> searchList = getMasterDataList();
        MasterControlDataDTO selectedMasterDataDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            selectedMasterDataDTO = searchList.Find(c => c.Id == Id);
        }
        return selectedMasterDataDTO;
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private void loadMasterDataGrid()
    {
        MasterDataSetupPageDTO PageDTO = getSessionPageData();
        IList<MasterControlDataDTO> results = masterDataBO.fetchMasterData(getUserDefinitionDTO().FirmNumber, drpMasterDataType.Text);
        PageDTO.SearchResult = (results != null) ? results.ToList<MasterControlDataDTO>() : new List<MasterControlDataDTO>();
        populateMasterDataSearchGrid(PageDTO.SearchResult);
    }
    private void populateMasterDataSearchGrid(List<MasterControlDataDTO> tmpList)
    {
        masterDataGrid.DataSource = new List<MasterControlDataDTO>();
        if (tmpList != null)
        {
            assignUiIndexToMasterData(tmpList);
            masterDataGrid.DataSource = tmpList;
        }
        masterDataGrid.DataBind();
    }
    private void assignUiIndexToMasterData(List<MasterControlDataDTO> tmpList)
    {
        if (tmpList != null && tmpList.Count > 0)
        {
            long uiIndex = 1;
            foreach (MasterControlDataDTO tmpDTO in tmpList)
            {
                tmpDTO.UiIndex = uiIndex++;
            }
        }
    }
    protected void onChangeMasterDataType(object sender, EventArgs e)
    {
        try
        {
            loadMasterDataGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected string getMCDTypeDesc(string type)
    {
        return EnumHelper.ToEnum<MasterDataType>(type).GetDescription();
    }
    //Master Data Modal - Start
    private void initMasterDataModalFields()
    {

    }
    private void initMasterDataSectionFields(MasterControlDataDTO mcdDTO)
    {
        /*if (mcdDTO != null) lbStageNo.Text = mcdDTO.StageNumber.ToString(); else lbStageNo.Text = getNextStageNo().ToString();
        if (mcdDTO != null) txtStage.Text = mcdDTO.Stage; else txtStage.Text = null;
        if (mcdDTO != null) txtPercentage.Text = mcdDTO.Percentage.ToString(); else txtPercentage.Text = null;
        if (mcdDTO != null) drpStageStatus.Text = mcdDTO.Status.ToString(); else drpStageStatus.ClearSelection();*/
    }
    private void populateMasterDataFromUI(MasterControlDataDTO mcdDTO)
    {
        /*mcdDTO.StageNumber = int.Parse(lbStageNo.Text);
        mcdDTO.Stage = txtStage.Text;
        mcdDTO.Percentage = CommonUtil.getDecimaNotNulllWithoutExt(txtPercentage.Text);
        mcdDTO.Status = EnumHelper.ToEnum<PRScheduleStageStatus>(drpStageStatus.Text);
        mcdDTO.UpdateUser = getUserDefinitionDTO().Username;*/
    }
    private MasterControlDataDTO populateMasterDataAdd()
    {
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        MasterControlDataDTO mcdDTO = new MasterControlDataDTO();
        /*PropertyTowerDTO propertyTowerDto = new PropertyTowerDTO();
        propertyTowerDto.Id = long.Parse(drpPrTower.Text);
        mcdDTO.PropertyTower = propertyTowerDto;
        mcdDTO.FirmNumber = userDef.FirmNumber;
        mcdDTO.InsertUser = userDef.Username;*/
        return mcdDTO;
    }
    private void setSelectedMasterData(long Id)
    {
        List<MasterControlDataDTO> tmpList = getMasterDataList();
        tmpList.ForEach(c => c.isUISelected = false);
        if (Id > 0) tmpList.Find(c => c.Id == Id).isUISelected = true;
    }
    private MasterControlDataDTO getSelectedMasterData(long Id)
    {
        List<MasterControlDataDTO> tmpList = getMasterDataList();
        return (Id > 0) ? tmpList.Find(c => c.Id == Id) : tmpList.Find(c => c.isUISelected);
    }
    protected void onClickAddStageBtn(object sender, EventArgs e)
    {
        try
        {
            masterDataModalActionHdnBtn.Value = MCDModalAction.ADD.ToString();
            initMasterDataModalFields();
            setSelectedMasterData(-1);
            initMasterDataSectionFields(null);
            activeModalHdn.Value = addModifyMasterDataModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyStageBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            masterDataModalActionHdnBtn.Value = MCDModalAction.MODIFY.ToString();
            setSelectedMasterData(selectedIndex);
            initMasterDataModalFields();
            initMasterDataSectionFields(getSelectedMasterData(0));
            activeModalHdn.Value = addModifyMasterDataModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void deleteMasterDataStage(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            MasterControlDataDTO tmpDTO = getSelectedMasterData(selectedIndex);
            /*if (tmpDTO.Id == 0 || tmpDTO.Status == PRScheduleStageStatus.Pending)
            {
                List<MasterControlDataDTO> scheduleList = getMasterDataList();
                scheduleList.Remove(tmpDTO);
                populateMasterDataSearchGrid(scheduleList);
                setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_DELETED_FROM_TABLE, "Stage " + tmpDTO.StageNumber.ToString())));
            }
            else
            {
                setNotyMsg(CommonUtil.getNotyErrorMsg(string.Format("Stage {0} is marked as Completed, cannot delete stage.", tmpDTO.StageNumber.ToString())));
            }*/
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void saveMasterDataStage(object sender, EventArgs e)
    {
        try
        {
            if (validateMasterDataAddModify())
            {
                MasterControlDataDTO tmpDTO = null;
                /*string msg = "";
                List<MasterControlDataDTO> scheduleList = getMasterDataList();
                if (MCDModalAction.ADD.ToString().Equals(masterDataModalActionHdnBtn.Value))
                {
                    tmpDTO = populateMasterDataAdd();
                    scheduleList.Add(tmpDTO);
                    msg = string.Format(Resources.Messages.RECOED_ADDED_TO_TABLE, "Stage " + tmpDTO.StageNumber.ToString());
                }
                else
                {
                    tmpDTO = getSelectedMasterData(0);
                    msg = string.Format(Resources.Messages.RECOED_MODIFIED_TO_TABLE, "Stage " + tmpDTO.StageNumber.ToString());
                }
                populateMasterDataFromUI(tmpDTO);
                populateMasterDataSearchGrid(scheduleList);
                setNotyMsg(CommonUtil.getNotySuccessMsg(msg));*/
            }
            else
            {
                activeModalHdn.Value = addModifyMasterDataModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelMasterDataStage(object sender, EventArgs e)
    {
        try
        {
            setSelectedMasterData(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateMasterDataAddModify()
    {
        bool isValid = true;
        Page.Validate(addModifyMasterDataError);
        isValid = Page.IsValid;
        return isValid;
    }
    protected void saveMasterData(object sender, EventArgs e)
    {
        try
        {
           }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            activeModalHdn.Value = "";
            setErrorMessage(CommonUtil.getErrorMessage(exp), addModifyMasterDataError);
        }
    }

    protected void onClickModifyMCDBtn(object sender, EventArgs e)
    {
        try
        {
            //resetMasterDataModalFields();
            //setParentModalFlag();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addModifyMasterDataError);
        }
    }
    protected void deleteMasterData(object sender, EventArgs e)
    {
        try
        {
            //resetMasterDataModalFields();
            //setParentModalFlag();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addModifyMasterDataError);
        }
    }
    
    protected void cancelMasterData(object sender, EventArgs e)
    {
        try
        {
            //resetMasterDataModalFields();
            //setParentModalFlag();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addModifyMasterDataError);
        }
    }
    
    //Master Data Modal - End
}