﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initCancelledUnitSearchGrid();
    formatFields();
    showModal();
}

function initCancelledUnitSearchGrid() {
    var dtOptions = {
        tableId: "cancelledUnitSearchGrid",
        pageLength: 10,
        isViewOnly: false,
        hideSearch: false
    };
    var dtTable = applyActionDataTable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitHdnId");
}




