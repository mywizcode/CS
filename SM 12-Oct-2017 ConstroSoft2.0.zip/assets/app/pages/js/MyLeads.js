﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initMyLeadsSearchGrid();
    formatFields();
    showModal();
}

function initMyLeadsSearchGrid() {
    var dtOptions = {
        tableId: "myLeadsSearchGrid",
        pageLength: 10,
        isViewOnly: false,
        customBtnGrpId: "#leadSearchBtnDiv",
        hideSearch: false
    };
    var dtTable = applyActionDataTable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitHdnId");
}




