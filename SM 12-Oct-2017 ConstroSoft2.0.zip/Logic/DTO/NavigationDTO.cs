﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ConstroSoft;

/// <summary>
/// </summary>
namespace ConstroSoft
{
    [Serializable]
    public class AllEnquiryLeadHistoryNavDTO
    {
        public AllEnquiryLeadHistoryNavDTO() { }
    }
    [Serializable]
    public class UserEnquiryHistoryNavDTO
    {
        public UserEnquiryHistoryNavDTO() { }
        public long FirmMemberId { get; set; }
        public EnquiryFilterDTO FilterDTO { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class UserLeadHistoryNavDTO
    {
        public UserLeadHistoryNavDTO() { }
        public long FirmMemberId { get; set; }
        public LeadFilterDTO FilterDTO { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class EnquiryActivityHistoryNavDTO
    {
        public EnquiryActivityHistoryNavDTO() { }
        public long EnquiryId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class LeadActivityHistoryNavDTO
    {
        public LeadActivityHistoryNavDTO() { }
        public long LeadId { get; set; }
        public object PrevNavDto { get; set; }
    }
	[Serializable]
    public class EnquiryAddActivityNavDTO
    {
        public EnquiryAddActivityNavDTO() { }
        public long EnquiryId { get; set; }
    }
	[Serializable]
    public class EnquirySearchNavDTO
    {
        public EnquirySearchNavDTO() { }
        public EnquiryFilterDTO filterDTO { get; set; }
    }
    [Serializable]
    public class EnquiryDetailNavDTO
    {
        public EnquiryDetailNavDTO() { }
        public PageMode Mode { get; set; }
        public long EnquiryId { get; set; }
        public long ConvertedLeadId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class LeadAssignmentNavDTO
    {
        public LeadAssignmentNavDTO() { }
    }
    [Serializable]
    public class MyLeadsNavDTO
    {
        public MyLeadsNavDTO() { }
        public LeadFilterDTO filterDTO { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class BookingFormNavDTO
    {
        public BookingFormNavDTO() { }
        public long PrUnitId { get; set; }
        public long EnquiryId { get; set; }
        public bool copyCustomerDtls { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class BookingSuccessNavDTO
    {
        public BookingSuccessNavDTO() { }
        public long PrUnitSaleDetailId { get; set; }
    }
    [Serializable]
    public class BookingCancellationNavDTO
    {
        public BookingCancellationNavDTO() { }
        public long PrUnitSaleDetailId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class BookingCancelSuccessNavDTO
    {
        public BookingCancelSuccessNavDTO() { }
        public long PrUnitSaleDetailId { get; set; }
    }
    [Serializable]
    public class PropertyUnitNavDTO
    {
        public PropertyUnitNavDTO() { }
        public PropertyUnitFilterDTO filterDTO { get; set; }
    }
    [Serializable]
    public class PrPymtScheduleNavDTO
    {
        public PrPymtScheduleNavDTO() { }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class SoldUnitSearchNavDTO
    {
        public SoldUnitSearchNavDTO() { }
        public SoldUnitFilterDTO filterDTO { get; set; }
    }
    [Serializable]
    public class SoldUnitDetailNavDTO
    {
        public SoldUnitDetailNavDTO() { }
        public PageMode Mode { get; set; }
        public long PrUnitSaleDetailId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class CancelledUnitSearchNavDTO
    {
        public CancelledUnitSearchNavDTO() { }
        public SoldUnitFilterDTO filterDTO { get; set; }
    }
    [Serializable]
    public class CancelledUnitDetailNavDTO
    {
        public CancelledUnitDetailNavDTO() { }
        public PageMode Mode { get; set; }
        public long PrUnitSaleDetailId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class LetterGenerationNavDTO
    {
        public LetterGenerationNavDTO() { }
        public PageMode Mode { get; set; }
        public long PrUnitId { get; set; }
        public long PrUnitSaleDetailId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class CustomerPymtSearchNavDTO
    {
        public CustomerPymtSearchNavDTO() { }
        public CustomerPymtSearchFilterDTO filterDTO { get; set; }
    }
    [Serializable]
    public class CustomerPaymentNavDTO
    {
        public CustomerPaymentNavDTO() { }
        public bool IsPdcPayment { get; set; }
        public PageMode Mode { get; set; }
        public PaymentMode? PymtMode { get; set; }
        public long PrUnitSaleDetailId { get; set; }
        public long MPTId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class CustomerPymtHistoryNavDTO
    {
        public CustomerPymtHistoryNavDTO() { }
        public long PrUnitSaleDetailId { get; set; }
        public PaymentMode? PymtMode { get; set; }
        public bool isPdc { get; set; }
        public object PrevNavDto { get; set; }
        public CustomerPymtTxHistoryFilterDTO FilterDTO { get; set; }
    }
    [Serializable]
    public class PropertyFundSearchNavDTO
    {
        public PropertyFundSearchNavDTO() { }
        public PropertyFundFilterDTO filterDTO { get; set; }
    }
    [Serializable]
    public class PropertyFundDetailNavDTO
    {
        public PropertyFundDetailNavDTO() { }
        public PageMode Mode { get; set; }
        public long propertyFundId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class MasterDataSetupNavDTO
    {
        public MasterDataSetupNavDTO() { }
    }
	[Serializable]
    public class FirmAccountNavDTO
    {
        public FirmAccountNavDTO() { }
        public long ID { get; set; }
        public long FirmID { get; set; }
        public object PrevNavDto { get; set; }
        public PageMode Mode { get; set; }
    }
}