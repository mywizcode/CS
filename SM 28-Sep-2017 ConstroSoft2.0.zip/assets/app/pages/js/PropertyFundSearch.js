﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initPropertyFundSearchGrid();
    formatFields();
    showModal();
}

function initPropertyFundSearchGrid() {
    var dtOptions = {
        tableId: "propertyFundSearchGrid",
        pageLength: 10,
        isViewOnly: false,
        hideSearch: false
    };
    var dtTable = applyActionDataTable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitHdnId");
}




