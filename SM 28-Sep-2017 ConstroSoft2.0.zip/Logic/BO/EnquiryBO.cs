﻿using System;
using NHibernate;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using ConstroSoft;
using System.Collections.Generic;
using NHibernate.Criterion;
using NHibernate.Transform;
using System.Net.Mail;
using System.Net.Mime;

/// <summary>
/// Summary description for SupplierBO
/// </summary>
namespace ConstroSoft
{
    public class EnquiryBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public EnquiryBO() { }

        public IList<EnquiryDetailDTO> fetchEnquiryGridData(string firmNumber, long propertyId, long userId, EnquiryFilterDTO filterDTO)
        {
            ISession session = null;
            IList<EnquiryDetailDTO> results = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                EnquiryDetail ed = null;
                ContactInfo c = null;
                EnquiryDetailDTO enDto = null;
                MasterControlData dge = null;
                MasterControlData salutation = null;
                LeadDetail ld = null;
                FirmMember fm = null;

                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => ed.Id).WithAlias(() => enDto.Id))
                            .Add(Projections.Property(() => ed.FirstName).WithAlias(() => enDto.FirstName))
                            .Add(Projections.Property(() => ed.LastName).WithAlias(() => enDto.LastName))
                            .Add(Projections.Property(() => ed.EnquiryRefNo).WithAlias(() => enDto.EnquiryRefNo))
                            .Add(Projections.Property(() => ed.Status).WithAlias(() => enDto.Status))
                            .Add(Projections.Property(() => ed.EnquiryDate).WithAlias(() => enDto.EnquiryDate))
                            .Add(Projections.Property(() => c.Contact), "ContactInfo.Contact")
                            .Add(Projections.Property(() => c.AltContact), "ContactInfo.AltContact")
                            .Add(Projections.Property(() => c.Email), "ContactInfo.Email")
                            .Add(Projections.Property(() => dge.Name), "EnquirySource.Name")
                            .Add(Projections.Property(() => salutation.Name), "Salutation.Name")
                            .Add(Projections.Property(() => ld.LeadRefNo), "Lead.LeadRefNo");
                var query = session.QueryOver<EnquiryDetail>(() => ed)
                    .Inner.JoinAlias(() => ed.ContactInfo, () => c)
                    .Left.JoinAlias(() => ed.EnquirySource, () => dge)
                    .Left.JoinAlias(() => ed.Salutation, () => salutation)
                    .Left.JoinAlias(() => ed.Assignee, () => fm)
                    .Left.JoinAlias(() => ed.Lead, () => ld);
                if (filterDTO != null)
                {
                    ICriteria criteria = query.RootCriteria;
                    if (!string.IsNullOrWhiteSpace(filterDTO.FirstName))
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<EnquiryDetail>(() => ed, x => x.FirstName), filterDTO.FirstName));
                    }
                    if (!string.IsNullOrWhiteSpace(filterDTO.LastName))
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<EnquiryDetail>(() => ed, x => x.LastName), filterDTO.LastName));
                    }
                    if (!string.IsNullOrWhiteSpace(filterDTO.EnquiryRef))
                    {
                        criteria.Add(Restrictions.InsensitiveLike(CommonUtil.BuildProjection<EnquiryDetail>(() => ed, x => x.EnquiryRefNo), filterDTO.EnquiryRef, MatchMode.Start));
                    }
                    if (!string.IsNullOrWhiteSpace(filterDTO.ContactNo))
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<ContactInfo>(() => c, x => x.Contact), filterDTO.ContactNo));
                    }
                    if (filterDTO.EnquirySource != null)
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<MasterControlData>(() => dge, x => x.Id), filterDTO.EnquirySource.Id));
                    }
                    if (filterDTO.Status != null)
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<EnquiryDetail>(() => ed, x => x.Status), filterDTO.Status));
                    }
                }
                results = query.Where(() => ed.FirmNumber == firmNumber && ed.Property.Id == propertyId && ed.Assignee.Id == userId)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<EnquiryDetailDTO>()).List<EnquiryDetailDTO>();
                foreach (EnquiryDetailDTO enquiryDetailDTO in results)
                {
                    enquiryDetailDTO.FullName = CommonUIConverter.getCustomerFullName(enquiryDetailDTO.Salutation.Name, CommonUIConverter.getCustomerFullName(enquiryDetailDTO.FirstName,
                        enquiryDetailDTO.LastName));
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating enquiry grid:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }
        public IList<LeadDetailDTO> fetchMyLeadsGridData(long propertyId, long AssigneeId, LeadFilterDTO filterDTO)
        {
            ISession session = null;
            IList<LeadDetailDTO> results = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	ContactInfo c = null;
                        MasterControlData src = null;
                        LeadDetail ld = null;
                        FirmMember fm = null;
                        Property p = null;
                        EnquiryDetail ed = null;
                        
                        LeadDetailDTO ldDto = null;

                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => ld.Id).WithAlias(() => ldDto.Id))
                                    .Add(Projections.Property(() => ld.FirstName).WithAlias(() => ldDto.FirstName))
                                    .Add(Projections.Property(() => ld.MiddleName).WithAlias(() => ldDto.MiddleName))
                                    .Add(Projections.Property(() => ld.LastName).WithAlias(() => ldDto.LastName))
                                    .Add(Projections.Property(() => ld.LeadRefNo).WithAlias(() => ldDto.LeadRefNo))
                                    .Add(Projections.Property(() => ld.LeadDate).WithAlias(() => ldDto.LeadDate))
                                    .Add(Projections.Property(() => ld.AssignedDate).WithAlias(() => ldDto.AssignedDate))
                                    .Add(Projections.Property(() => ld.Budget).WithAlias(() => ldDto.Budget))
                                    .Add(Projections.Property(() => ld.Status).WithAlias(() => ldDto.Status))
                                    .Add(Projections.Property(() => c.Contact), "ContactInfo.Contact")
                                    .Add(Projections.Property(() => c.Email), "ContactInfo.Email")
                                    .Add(Projections.Property(() => src.Id), "Source.Id")
                                    .Add(Projections.Property(() => src.Name), "Source.Name")
                                    .Add(Projections.Property(() => ld.Status).WithAlias(() => ldDto.Status));
                        var query = session.QueryOver<LeadDetail>(() => ld)
                            .Inner.JoinAlias(() => ld.ContactInfo, () => c)
                            .Inner.JoinAlias(() => ld.Source, () => src)
                            .Inner.JoinAlias(() => ld.Assignee, () => fm)
                            .Inner.JoinAlias(() => ld.Property, () => p)
                            .Left.JoinAlias(() => ld.EnquiryDetail, () => ed);
                        if (filterDTO != null)
                        {
                            ICriteria criteria = query.RootCriteria;
                            if (!string.IsNullOrWhiteSpace(filterDTO.FirstName))
                            {
                                criteria.Add(Restrictions.InsensitiveLike(CommonUtil.BuildProjection<LeadDetail>(() => ld, x => x.FirstName), filterDTO.FirstName, MatchMode.Start));
                            }
                            if (!string.IsNullOrWhiteSpace(filterDTO.LastName))
                            {
                                criteria.Add(Restrictions.InsensitiveLike(CommonUtil.BuildProjection<LeadDetail>(() => ld, x => x.LastName), filterDTO.LastName, MatchMode.Start));
                            }
                            if (!string.IsNullOrWhiteSpace(filterDTO.LeadRefNo))
                            {
                                criteria.Add(Restrictions.InsensitiveLike(CommonUtil.BuildProjection<LeadDetail>(() => ld, x => x.LeadRefNo), filterDTO.LeadRefNo, MatchMode.Start));
                            }
                            if (!string.IsNullOrWhiteSpace(filterDTO.Contact))
                            {
                                criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<ContactInfo>(() => c, x => x.Contact), filterDTO.Contact));
                            }
                            if (filterDTO.SourceId > 0)
                            {
                                criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<MasterControlData>(() => src, x => x.Id), filterDTO.SourceId));
                            }
                            if (filterDTO.Status != null)
                            {
                                criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<LeadDetail>(() => ld, x => x.Status), filterDTO.Status));
                            }
                        }
                        results = query.Where(() => p.Id == propertyId && fm.Id == AssigneeId)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<LeadDetailDTO>()).List<LeadDetailDTO>();
                        foreach (LeadDetailDTO tmpDTO in results)
                        {
                        	tmpDTO.FullName = CommonUIConverter.getCustomerFullName(tmpDTO.FirstName, tmpDTO.MiddleName, tmpDTO.LastName);
                        	tmpDTO.NoOfDaysAssgined = (DateTime.Today - tmpDTO.AssignedDate.Value).Days;
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Leads assigned to user:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }
        public List<AllEnquiryLeadUIDTO> fetchAllEnquiryLeadData(string FirmNumber)
        {
            ISession session = null;
            List<AllEnquiryLeadUIDTO> resultList = new List<AllEnquiryLeadUIDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        string sqlQuery = "SELECT 'LEAD' AS RD_TYPE, FM.ID, FM.FIRST_NAME, FM.LAST_NAME, CI.CONTACT, CI.EMAIL, UD.STATUS AS USER_STATUS, "
                                + " COUNT(case when LD.STATUS = 'O' then 1 end) AS OPEN_ENQ, COUNT(case when LD.STATUS = 'C' then 1 end) AS WON_EQ, "
                                + " COUNT(case when LD.STATUS = 'X' then 1 end) AS LOST_EQ FROM LEAD_DETAILS LD INNER JOIN FIRM_MEMBER FM ON LD.ASSIGNEE = FM.ID "
                                + " INNER JOIN CONTACT_INFO CI ON FM.CONTACT_INFO_ID = CI.ID INNER JOIN USER_DEFINITION UD ON UD.FIRM_MEMBER_ID = FM.ID "
                                + " WHERE LD.FIRM_NUMBER = :FirmNumber GROUP BY FM.ID, FM.FIRST_NAME, FM.LAST_NAME, CI.CONTACT, CI.EMAIL, UD.STATUS "
                                + " UNION "
                                + " SELECT 'ENQUIRY', FM.ID, FM.FIRST_NAME, FM.LAST_NAME, CI.CONTACT, CI.EMAIL, UD.STATUS AS USER_STATUS,"
                                + " COUNT(case when ED.STATUS = 'O' then 1 end) AS OPEN_EQ, COUNT(case when ED.STATUS = 'W' then 1 end) AS WON_EQ,  "
                                + " COUNT(case when ED.STATUS = 'L' then 1 end) AS LOST_EQ FROM ENQUIRY_DETAILS ED INNER JOIN FIRM_MEMBER FM "
                                + " ON ED.ASSIGNEE = FM.ID INNER JOIN CONTACT_INFO CI ON FM.CONTACT_INFO_ID = CI.ID INNER JOIN USER_DEFINITION UD "
                                + " ON UD.FIRM_MEMBER_ID = FM.ID WHERE ED.FIRM_NUMBER = :FirmNumber GROUP BY FM.ID, FM.FIRST_NAME, FM.LAST_NAME, CI.CONTACT, CI.EMAIL, UD.STATUS";
                        IList<object[]> resultObjList = session.CreateSQLQuery(sqlQuery)
                        		.SetString("FirmNumber", FirmNumber)
                        		.List<object[]>();

                        if (resultList != null)
                        {
                            foreach (object[] row in resultObjList)
                            {
                                long Id = (long)row[1];
                                AllEnquiryLeadUIDTO tmpDTO = resultList.Find(x => x.FirmMemberId == Id);
                                if (tmpDTO == null)
                                {
                                    tmpDTO = new AllEnquiryLeadUIDTO();
                                    tmpDTO.FirmMemberId = Id;
                                    tmpDTO.FirstName = (string)row[2];
                                    tmpDTO.LastName = (string)row[3];
                                    tmpDTO.FullName = CommonUIConverter.getCustomerFullName(tmpDTO.FirstName, tmpDTO.LastName);
                                    tmpDTO.Contact = (string)row[4];
                                    tmpDTO.Email = (string)row[5];
                                    tmpDTO.Status = EnumHelper.getUserStatus((string)row[6]);
                                    resultList.Add(tmpDTO);
                                }
                                if ((string)row[0] == "LEAD")
                                {
                                    tmpDTO.LeadsOpen = tmpDTO.LeadsOpen + (int)row[7];
                                    tmpDTO.LeadsConverted = tmpDTO.LeadsConverted + (int)row[8];
                                    tmpDTO.LeadsLost = tmpDTO.LeadsLost + (int)row[9];
                                    tmpDTO.LeadsClosed = tmpDTO.LeadsConverted + tmpDTO.LeadsLost;
                                }
                                else
                                {
                                    tmpDTO.EnquiriesOpen = tmpDTO.LeadsOpen + (int)row[7];
                                    tmpDTO.EnquiriesWon = tmpDTO.EnquiriesWon + (int)row[8];
                                    tmpDTO.EnquiriesLost = tmpDTO.EnquiriesLost + (int)row[9];
                                    tmpDTO.EnquiriesClosed = tmpDTO.EnquiriesWon + tmpDTO.EnquiriesLost;
                                }
                            }
                        }

                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching all enquiry and leqads history:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return resultList;
        }
        public List<UserEnquiryHistoryUIDTO> fetchEnquiryHistoryForUser(long Assignee)
        {
            ISession session = null;
            List<UserEnquiryHistoryUIDTO> resultList = new List<UserEnquiryHistoryUIDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        string hqlQuery = "select ed.Id as EnquiryId, ed.FirstName as CustFirstName, ed.LastName as CustLastName, ed.EnquiryDate as EnquiryDate, "
                                   + " ed.EnquiryRefNo as EnquiryRefNo, ed.AssignedDate as AssignedDate, ed.Status as Status, ld.Id as LeadId, ld.LeadRefNo as LeadRefNo, "
                                   + " es.Name as EnquirySource, pusd.Id as PrUnitSaleId, pusd.Status as UnitSaleStatus, max(ea.DateLogged) as LastActivity from EnquiryDetail ed "
                                   + " inner join ed.EnquirySource es inner join ed.Assignee asgn left join ed.Lead ld left join ed.PrUnitSaleDetail pusd left join "
                                   + " ed.EnquiryActivities ea left join ea.LoggedBy lb with lb.Id = :Assignee "
                                   + " where asgn.Id = :Assignee group by ed.Id,ed.FirstName, ed.LastName, ed.EnquiryDate, ed.EnquiryRefNo, "
                                   + " ed.AssignedDate, ed.Status, ld.Id, ld.LeadRefNo, es.Name, pusd.Id, pusd.Status";
                        IList<UserEnquiryHistoryUIDTO> tmpResultList = session.CreateQuery(hqlQuery)
                                .SetInt64("Assignee", Assignee)
                                .SetResultTransformer(new DeepTransformer<UserEnquiryHistoryUIDTO>()).List<UserEnquiryHistoryUIDTO>();
                        resultList.AddRange(tmpResultList);
                        foreach (UserEnquiryHistoryUIDTO tmpDTO in resultList)
                        {
                            tmpDTO.CustFullName = CommonUIConverter.getCustomerFullName(tmpDTO.CustFirstName, tmpDTO.CustLastName);
                            tmpDTO.NoOfDaysAssgined = (DateTime.Today - tmpDTO.AssignedDate).Days;
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Enquiry History for user:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return resultList;
        }
        public AllEnquiryLeadUIDTO fetchEnquiryHistorySummaryForUser(long AssigneeId)
        {
            ISession session = null;
            AllEnquiryLeadUIDTO result = new AllEnquiryLeadUIDTO();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	string query = " SELECT FM.ID as FirmMemberId, FM.FIRST_NAME as FirstName, FM.LAST_NAME as LastName, CI.CONTACT as Contact, CI.EMAIL as Email, "
                                + " COUNT(case when ED.STATUS = 'O' then 1 end) AS EnquiriesOpen, COUNT(case when ED.STATUS = 'W' then 1 end) AS EnquiriesWon,  "
                                + " COUNT(case when ED.STATUS = 'L' then 1 end) AS EnquiriesLost FROM ENQUIRY_DETAILS ED INNER JOIN FIRM_MEMBER FM "
                                + " ON ED.ASSIGNEE = FM.ID INNER JOIN CONTACT_INFO CI ON FM.CONTACT_INFO_ID = CI.ID  "
                                + " WHERE FM.ID = :AssigneeId GROUP BY FM.ID, FM.FIRST_NAME, FM.LAST_NAME, CI.CONTACT, CI.EMAIL";
                        result = session.CreateSQLQuery(query)
                                .SetInt64("AssigneeId", AssigneeId)
                                .SetResultTransformer(new DeepTransformer<AllEnquiryLeadUIDTO>()).UniqueResult<AllEnquiryLeadUIDTO>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Enquiry history summary for user:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public List<UserLeadHistoryUIDTO> fetchLeadHistoryForUser(long Assignee)
        {
            ISession session = null;
            List<UserLeadHistoryUIDTO> resultList = new List<UserLeadHistoryUIDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	string hqlQuery = "select ld.Id as LeadId, ld.FirstName as CustFirstName, ld.MiddleName as CustMiddleName, ld.LastName as CustLastName, ld.LeadDate as LeadDate, "
                    			   + " ld.LeadRefNo as LeadRefNo, ed.EnquiryRefNo as EnquiryRefNo, ld.AssignedDate as AssignedDate, ld.Status as Status, "
                    			   + " src.Name as Source, max(la.DateLogged) as LastActivity from LeadDetail ld "
                    			   + " inner join ld.Source src inner join ld.Assignee asgn left join ld.EnquiryDetail ed left join "
                    			   + " ld.LeadActivities la left join la.LoggedBy lb with lb.Id = :Assignee "
                    			   + " where asgn.Id = :Assignee group by ld.Id, ld.FirstName, ld.MiddleName, ld.LastName, ld.LeadDate, ld.LeadRefNo, ed.EnquiryRefNo, "
                    			   + " ld.AssignedDate, ld.Status, src.Name";
                        IList<UserLeadHistoryUIDTO> tmpResultList = session.CreateQuery(hqlQuery)
                                .SetInt64("Assignee", Assignee)
                                .SetResultTransformer(new DeepTransformer<UserLeadHistoryUIDTO>()).List<UserLeadHistoryUIDTO>();
                        resultList.AddRange(tmpResultList);
                        foreach (UserLeadHistoryUIDTO tmpDTO in resultList)
                        {
                            tmpDTO.CustFullName = CommonUIConverter.getCustomerFullName(tmpDTO.CustFirstName, tmpDTO.CustLastName);
                            tmpDTO.NoOfDaysAssgined = (DateTime.Today - tmpDTO.AssignedDate).Days;
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Lead History for user:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return resultList;
        }
        public List<UserLeadHistoryUIDTO> fetchLeadsForUser(long AssigneeId, LeadStatus Status)
        {
            ISession session = null;
            List<UserLeadHistoryUIDTO> resultList = new List<UserLeadHistoryUIDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	string hqlQuery = "select ld.Id as LeadId, ld.FirstName as CustFirstName, ld.MiddleName as CustMiddleName, ld.LastName as CustLastName, ld.LeadDate as LeadDate, "
                    			   + " ld.LeadRefNo as LeadRefNo, ld.AssignedDate as AssignedDate, ld.Status as Status, "
                    			   + " src.Name as Source from LeadDetail ld inner join ld.Source src inner join ld.Assignee asgn "
                    			   + " where asgn.Id = :AssigneeId and ld.Status = :LeadStatus";
                        IList<UserLeadHistoryUIDTO> tmpResultList = session.CreateQuery(hqlQuery)
                        		.SetEnum("LeadStatus", Status)
                        		.SetInt64("AssigneeId", AssigneeId)
                                .SetResultTransformer(new DeepTransformer<UserLeadHistoryUIDTO>()).List<UserLeadHistoryUIDTO>();
                        resultList.AddRange(tmpResultList);
                        foreach (UserLeadHistoryUIDTO tmpDTO in resultList)
                        {
                            tmpDTO.CustFullName = CommonUIConverter.getCustomerFullName(tmpDTO.CustFirstName, tmpDTO.CustLastName);
                            tmpDTO.NoOfDaysAssgined = (DateTime.Today - tmpDTO.AssignedDate).Days;
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Leads for user with given Lead status:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return resultList;
        }
        public List<UserLeadHistoryUIDTO> fetchUnAssignedLeads(string FirmNumber)
        {
            ISession session = null;
            List<UserLeadHistoryUIDTO> resultList = new List<UserLeadHistoryUIDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	string hqlQuery = "select ld.Id as LeadId, ld.FirstName as CustFirstName, ld.MiddleName as CustMiddleName, ld.LastName as CustLastName, "
                                   + " ld.LeadDate as LeadDate, ld.LeadRefNo as LeadRefNo, ld.Budget as Budget, ci.Contact as Contact, ci.Email as Email, ld.Status as Status, "
                                   + " src.Name as Source from LeadDetail ld inner join ld.Source src inner join ld.ContactInfo ci "
                                   + " where ld.FirmNumber = :FirmNumber and ld.Assignee is null";
                        IList<UserLeadHistoryUIDTO> tmpResultList = session.CreateQuery(hqlQuery)
                        		.SetString("FirmNumber", FirmNumber)
                                .SetResultTransformer(new DeepTransformer<UserLeadHistoryUIDTO>()).List<UserLeadHistoryUIDTO>();
                        resultList.AddRange(tmpResultList);
                        foreach (UserLeadHistoryUIDTO tmpDTO in resultList)
                        {
                            tmpDTO.CustFullName = CommonUIConverter.getCustomerFullName(tmpDTO.CustFirstName, tmpDTO.CustLastName);
                            tmpDTO.NoOfDaysCreated = (DateTime.Today - tmpDTO.LeadDate).Days;
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Unassigned Leads:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return resultList;
        }
        public EnquiryDetailDTO fetchEnquiryDetails(long Id, bool fetchFollowups)
        {
            ISession session = null;
            EnquiryDetailDTO enquiryDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EnquiryDetail enquiry = session.Get<EnquiryDetail>(Id);
                        enquiryDto = DomainToDTOUtil.convertToEnquiryDetailDTO(enquiry, true, fetchFollowups);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Enquiry details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return enquiryDto;
        }
        public string addEnquiryDetails(EnquiryDetailDTO enquiryDto)
        {
            ISession session = null;
            string enquiryRefNo = "";
            try
            {
                session = NHibertnateSession.OpenSession();
                EnquiryDetail enquiry = null;
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        enquiry = DTOToDomainUtil.populateEnquiryDetailAddFields(enquiryDto);
                        session.Save(enquiry);
                        enquiry.EnquiryRefNo = CommonUtil.getEnquiryRefNo(enquiry.Id);
                        session.Update(enquiry);
                        enquiryRefNo = enquiry.EnquiryRefNo;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Enquiry details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
                sendSMSEmail(enquiry);
             }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return enquiryRefNo;
        }
        public void updateEnquiry(EnquiryDetailDTO enquiryDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EnquiryDetail enquiry = session.Get<EnquiryDetail>(enquiryDto.Id);
                        DTOToDomainUtil.populateEnquiryDetailUpdateFields(enquiry, enquiryDto);
                        session.Update(enquiry);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating Enquiry details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public string addLeadDetails(LeadDetailDTO leadDetailDTO)
        {
            ISession session = null;
            string leadRefNo = "";
            try
            {
                session = NHibertnateSession.OpenSession();
                LeadDetail lead = null;
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	lead = DTOToDomainUtil.populateLeadDetailAddFields(leadDetailDTO);
                        session.Save(lead);
                        lead.LeadRefNo = CommonUtil.getLeadRefNo(lead.Id);
                        session.Update(lead);
                        leadRefNo = lead.LeadRefNo;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Lead details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
             }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return leadRefNo;
        }
        /**
         * This method will check Email & SMS configuration for Enquiry Function. 
         * If Email & SMS alerts are enabled then system will send Email & SMS to Customer.
         * */
        private static void sendSMSEmail(EnquiryDetail enquiry)
        {
            try
            {
                PropertyAlertConfig emailSmsAlertConfig = EmailUtil.loadEmailSmsAlertConfiguration(enquiry.FirmNumber,
                    FunctionName.ENQUIRY.ToString(), EmailSmsType.ENQUIRYTHANKS.ToString(), enquiry.Property.Id);
                PropertyBO propertyBO = new PropertyBO();
                PropertyDTO propertyDTO = propertyBO.fetchProperty(enquiry.Property.Id);
                if (emailSmsAlertConfig != null && emailSmsAlertConfig.Email.Equals(Constants.YES))
                {
                    emailSmsAlertConfig.EmailBody = populateBody(enquiry, emailSmsAlertConfig, propertyDTO.Name);
                    EmailUtil.sendHtmlFormattedEmail(enquiry.FirmNumber, emailSmsAlertConfig, enquiry.ContactInfo.Email);
                }
                if (emailSmsAlertConfig != null && emailSmsAlertConfig.Sms.Equals(Constants.YES))
                {
                    emailSmsAlertConfig.SmsContent = populateSMSBody(enquiry, emailSmsAlertConfig, propertyDTO.Name);
                    EmailUtil.sendSMS(enquiry.FirmNumber, emailSmsAlertConfig, enquiry.ContactInfo.Contact);
                }
            }
            catch (Exception e)
            {
                log.Error("Exception while sending Email & SMS alert for enquiry:", e);
            }
        }
        private static string populateBody(EnquiryDetail enquiry, PropertyAlertConfig emailSmsAlertConfig, string propertyName)
        {
            string body = string.Empty;
            using (StreamReader reader = new StreamReader(System.Web.HttpContext.Current.Server.MapPath(emailSmsAlertConfig.EmailTemplatePath)))
            {
                body = reader.ReadToEnd();
            }
            body = body.Replace("{UserName}", enquiry.Salutation.Name + " " + enquiry.FirstName + " " + enquiry.LastName);
            body = body.Replace("{PropertyName}", propertyName);
            return body;
        }
        private static string populateSMSBody(EnquiryDetail enquiry, PropertyAlertConfig emailSmsAlertConfig, string propertyName)
        {
            string body = string.Empty;
            body = emailSmsAlertConfig.SmsContent.Replace("{UserName}", enquiry.Salutation.Name + " " +enquiry.FirstName + " " + enquiry.LastName);
            body = emailSmsAlertConfig.SmsContent.Replace("{PropertyName}", propertyName);
            return body;
        }
        public string addEnquiryActivity(long EnquiryId, EnquiryActivityDTO activityDTO, EnqActivityMode activityMode, long parentId)
        {
            ISession session = null;
            string RefNo = "";
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EnquiryActivity activity = DTOToDomainUtil.populateEnquiryActivityAddFields(activityDTO);
                        session.Save(activity);
                        activity.RefNo = (activityDTO.RecordType == EnqActivityRecordType.Event) ? CommonUtil.getEnqEventRefNo(activity.Id) : CommonUtil.getEnqTaskRefNo(activity.Id);
                        session.Update(activity);
                        RefNo = activity.RefNo;
                        if (activityMode != EnqActivityMode.NONE && parentId > 0)
                        {
                            EnqActivityStatus status = EnqActivityStatus.Completed;
                            if (activityMode == EnqActivityMode.RESCHEDULE_EVENT || activityMode == EnqActivityMode.RESCHEDULE_TASK
                                || activityMode == EnqActivityMode.CANCEL_EVENT || activityMode == EnqActivityMode.CANCEL_TASK) {
                                    status = EnqActivityStatus.Deferred;
                            }
                            string hqlUpdate = "update EnquiryActivity ea set ea.Status = :status, ea.UpdateDate = :updateDate, ea.UpdateUser = :updateUser where ea.Id = :parentId";
                            session.CreateQuery(hqlUpdate)
                                    .SetEnum("status", status)
                                    .SetDateTime("updateDate", DateTime.Now)
                                    .SetString("updateUser", activityDTO.InsertUser)
                                    .SetInt64("parentId", parentId)
                                    .ExecuteUpdate();
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while adding Enquiry activity:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return RefNo;
        }
        public void ReAssignEnquiry(long EnquiryId, long AssigneeId)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        string query = "UPDATE ENQUIRY_DETAILS ED SET ED.ASSIGNEE = :AssigneeId WHERE ED.ID = :EnquiryId";
                        session.CreateSQLQuery(query)
                                .SetInt64("AssigneeId", AssigneeId)
                                .SetInt64("EnquiryId", EnquiryId)
                                .ExecuteUpdate();
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Reassigning Enquiry:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void ReAssignLead(long LeadId, long AssigneeId)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        string query = "UPDATE LEAD_DETAILS LD SET LD.ASSIGNEE = :AssigneeId WHERE LD.ID = :LeadId";
                        session.CreateSQLQuery(query)
                                .SetInt64("AssigneeId", AssigneeId)
                                .SetInt64("LeadId", LeadId)
                                .ExecuteUpdate();
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Reassigning Lead:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void closeEnquiry(long enquiryId, List<EnquiryActivityDTO> activityList)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        string hqlActivityUpdate = "update EnquiryActivity ea set ea.Status = :status where ea.Id in (select e.id from EnquiryActivity e where e.EnquiryDetail.Id = :EnquiryId)";
                        session.CreateQuery(hqlActivityUpdate)
                                .SetEnum("status", EnqActivityStatus.Completed)
                                .SetInt64("EnquiryId", enquiryId)
                                .ExecuteUpdate();
                        
                        string hqlEnquiryUpdate = "update EnquiryDetail ed set ed.Status = :status where ed.Id = :EnquiryId";
                        session.CreateQuery(hqlEnquiryUpdate)
                                .SetEnum("status", EnquiryStatus.Lost)
                                .SetInt64("EnquiryId", enquiryId)
                                .ExecuteUpdate();
                        foreach(EnquiryActivityDTO activityDTO in activityList) {
                            EnquiryActivity activity = DTOToDomainUtil.populateEnquiryActivityAddFields(activityDTO);
                            session.Save(activity);
                            activity.RefNo = CommonUtil.getEnqEventRefNo(activity.Id);
                            session.Update(activity);
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while making Enquiry Close:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void reOpenEnquiry(long enquiryId, List<EnquiryActivityDTO> activityList)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        string hqlEnquiryUpdate = "update EnquiryDetail ed set ed.Status = :status where ed.Id = :EnquiryId";
                        session.CreateQuery(hqlEnquiryUpdate)
                                .SetEnum("status", EnquiryStatus.Open)
                                .SetInt64("EnquiryId", enquiryId)
                                .ExecuteUpdate();
                        foreach(EnquiryActivityDTO activityDTO in activityList) {
                            EnquiryActivity activity = DTOToDomainUtil.populateEnquiryActivityAddFields(activityDTO);
                            session.Save(activity);
                            activity.RefNo = CommonUtil.getEnqEventRefNo(activity.Id);
                            session.Update(activity);
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while making Enquiry Close:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
    }
}