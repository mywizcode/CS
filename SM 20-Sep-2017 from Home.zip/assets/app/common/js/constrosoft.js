/*
This method is workaround for bug -> Row level action dropdown is clipped by container of datatable.
In this method dropdown in re-positioned at same location but it is no more child of the table.
*/
function bindActionDropdown() {
    $('.fl-drp').parent().on('shown.bs.dropdown', function () {
        var $menu = $("ul", this);
        offset = $menu.offset();
        position = $menu.position();
        $('body').append($menu);
        $menu.show();
        $menu.css('position', 'absolute');
        $menu.css('top', (offset.top) + 'px');
        $menu.css('left', (offset.left) + 'px');
        $(this).data("myDropdownMenu", $menu);
    });
    $('.fl-drp').parent().on('hide.bs.dropdown', function () {
        $(this).append($(this).data("myDropdownMenu"));
        $(this).data("myDropdownMenu").removeAttr('style');

    });
}
/*
    This function will scoll to the given element (Id) so that it will be at top of the page OR scroller reaches at end. If 'elementId' value is 'TOP' 
    then it scrolls to top of the page.
*/
function scrollToField(elementId, removed_height) {
    var scrollTo = -1;
    if (elementId && elementId != "") {
        if (elementId == "TOP") {
            scrollTo = 0;
        } else {
            var $element = $("[id$='" + elementId + "']");
            if ($element) {
                scrollTo = $("[id$='" + elementId + "']").offset().top - removed_height;
            }
        }
    }
    if (scrollTo != -1) {
        $('html, body').animate({ scrollTop: scrollTo }, 'slow');
    }
}

/**
 * This function will take to the page where 'element' is present with attribute 'index' having value given in 'data'.
 * Usage - dtTable.api().page.jumpToIndex("6"); 
 */
jQuery.fn.dataTable.Api.register('page.jumpToIndex()', function (data) {
    var pos = -1;
    this.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var index = this.nodes().to$().find('.row-identifier').attr('row-identifier');
        if (index == data) {
            pos = rowLoop;
        }
    });
    if (pos >= 0) {
        var page = Math.floor(pos / this.page.info().length);
        this.page(page).draw(false);
    }
});

function formatAutoNumeric(modalBody) {
    var body = (modalBody != "") ? modalBody : 'body';
    //Format input fields as indian currency amount which has class csamount.
    $(body).find('input.csaddresspin').autoNumeric('init', { aSep: '', vMax: 999999, vMin: 0, wEmpty: '' });
    $(body).find('.csnumber').autoNumeric("init", { aSep: ',', aDec: '.', dGroup: 2, vMin: '0', vMax: '100', mDec: 0, aSign: ' ', pSign: 's' });
    $(body).find('.csnumber').attr('placeholder', '');
    $(body).find('.csamount').autoNumeric("init", { aSep: ',', aDec: '.', dGroup: 2, aSign: 'Rs. ' });
    $(body).find('.csamount').attr('placeholder', 'Rs.');
    $(body).find('.cspercentaged3').autoNumeric("init", { aSep: ',', aDec: '.', dGroup: 2, vMin: '0.000', vMax: '100.000', aSign: ' %', pSign: 's' });
    $(body).find('.cspercentaged3').attr('placeholder', '%');
    $(body).find('.cspercentaged0').autoNumeric("init", { aSep: ',', aDec: '.', dGroup: 2, vMin: '0', vMax: '100', mDec: 0, aSign: ' %', pSign: 's' });
    $(body).find('.cspercentaged0').attr('placeholder', '%');
    $(body).find('.cssqftarea').autoNumeric("init", { aSep: ',', aDec: '.', dGroup: 2, mDec: 3, aSign: ' Sq.Ft. ', pSign: 's' });
    $(body).find('.cssqftarea').attr('placeholder', 'Sq.Ft.');
    $(body).find('.cssqmtarea').autoNumeric("init", { aSep: ',', aDec: '.', dGroup: 2, mDec: 3, vMin: '0.000', vMax: '9999999.000', aSign: ' Sq.Mtr. ', pSign: 's' });
    $(body).find('.cssqmtarea').attr('placeholder', 'Sq.Mtr.');
    $(body).find('td.csamountnotempty').each(function () {
        $this = $(this);
        if ($this.text().trim() != "") $this.autoNumeric("init", { aSep: ',', aDec: '.', dGroup: 2, aSign: '' });
    });
}
function formatFields() {
    formatAutoNumeric("");
    //Convert fields as select picker which has class csdrp.
    $('.csdrp').select2({
        containerCssClass: 'select-sm',
        minimumResultsForSearch: Infinity
    });
    $('.csdrplive').select2({
        containerCssClass: 'select-sm'
    });
    $('div.bootstrap-select').addClass("dropdown-100-percent");
    $('div.bootstrap-select > button').addClass("btn-sm border-gray");
    $('div.bs-searchbox > input').addClass("input-sm");
    //Convert fields as date picker which has class csdt.
    $('div.date').each(function () {
        $this = $(this);
        var isReadOnly = $this.is('[readonly]');
        if (isReadOnly == false) {
            $this.datetimepicker({
                format: 'DD-MMM-YYYY'
            });
        }
    });
    $('div.datetime').each(function () {
        $this = $(this);
        var isReadOnly = $this.is('[readonly]');
        if (isReadOnly == false) {
            $this.datetimepicker({
                format: 'dddd, DD-MMM-YYYY, hh:mm A'
            });
        }
    });
    $('div.datetime-inline').each(function () {
        $this = $(this);
        var isReadOnly = $this.is('[readonly]');
        if (isReadOnly == false) {
            $this.datetimepicker({
                format: 'dddd, DD-MMM-YYYY, hh:mm A',
                inline: true
            });
        }
    });
    Ladda.bind('.btn-ladda-spinner');
    $("input:radio, .styled").uniform({
        radioClass: 'choice'
    });
    // Styled file input
    $('.file-styled').uniform({
        fileButtonClass: 'action btn bg-blue'
    });
    $('.filter-token-field').on('tokenfield:removedtoken', function (e) {
        $("[id$='filterRemoveHdn']").val(e.attrs.value);
        $("[id$='filterHdnBtn']").click();
    }).tokenfield({
    	delimiter: '~'
    });
    $("[id$='-tokenfield']").attr('readonly','true');//Make text input readonly
    scrollToField($("[id$='scrollToFieldHdn']").val(), 10);
    $("[id$='scrollToFieldHdn']").val('');
    bindActionDropdown();
    bindBlockUI();
    //Fix for Select2 bug -> On selection, focus should stay on select field.
    $('select').on("select2:close", function () { $(this).focus(); });
    initNotification();
    initFabMenu();
    initHeadingElements("PAGE");
}

function toolTipOnTable(tableId) {
    $("[id$='" + tableId + "']" + ' tbody td').each(function () {
        var $td = $(this);
        $td.attr('title', '');
        $td.attr('title', $td.text());
    });
    /* Apply the tooltips */
    $("[id$='" + tableId + "']" + 'thead th[title]').tooltip({
        "container": 'body'
    });
}

function jumpToTablePage(dtTable, jumpToHdnId) {
    var index = $("[id$='" + jumpToHdnId + "']").val();
    if (index && index != "") {
        dtTable.page.jumpToIndex(index);
        $("[id$='" + jumpToHdnId + "']").val('');
    }
}
/**
 * Datatable is created with below options
 * 1. tableId : Mandatory - Name of the Table.
 * 2. pageLength: Mandatory - No of records in one page.
 * 3. responsiveModalTitle: Optional - It is modal title shown in row info modal. 
 * 4. isViewOnly: Mandatory if responsiveModalTitle - true/false - If true then Eye icon is shown in first column else in second column.
 * 5. customBtnGrpId: Optional - It is 'Id' of element div for table level actions. If given then Table level action are shown which are present in DIV of given Id.
 * 6. sortColumn: Column to Sort
 * 7. sortOrder: sort order.
 */
function applyActionDataTable(dtOptions) {
    var tableId = dtOptions.tableId;
    var pageLength = (dtOptions.pageLength) ? dtOptions.pageLength : 10;
    var allSortable = ((dtOptions.allSortable == 'true') ? true : false) || dtOptions.isViewOnly;
    var colToSort = (allSortable) ? 0 : 1;
    if (dtOptions.sortColumn && dtOptions.sortColumn > 1) {
        colToSort = dtOptions.sortColumn;
        if (dtOptions.isViewOnly) colToSort = colToSort - 1;
    }
    var sortOrder = (dtOptions.sortOrder) ? dtOptions.sortOrder : "asc";
    $("[id$='" + tableId + "']").prepend($("<thead></thead>").append($("[id$='" + tableId + "']").find("tr:first")));
    $("[id$='" + tableId + "']").removeAttr("cellspacing rules border style");//CSS Class added by C# needs to be removed in order to render Limitless datatable.
    var dtTable = $("[id$='" + tableId + "']").DataTable({
        autoWidth: false,
        dom: '<"datatable-header length-left filter-right"lf><"datatable-scroll"t><"datatable-footer"ip>',
        language: {
            search: '<span>Search:</span> _INPUT_',
            searchPlaceholder: 'Type to search...'
        },
        columnDefs: [{
            orderable: allSortable,
            targets: [0]
        }],
        order: [[colToSort, sortOrder]],
        pageLength: pageLength,
        drawCallback: function () {
            $(this).find('tbody tr').slice(-3).find('.dropdown, .btn-group').addClass('dropup');
        },
        preDrawCallback: function () {
            $(this).find('tbody tr').slice(-3).find('.dropdown, .btn-group').removeClass('dropup');
        }
    });
    if (dtOptions.hideSearch == true) {
        $("[id$='" + tableId + "_wrapper']").find('.dataTables_filter').html('');
    }
    //If dtOptions has 'customBtnGrpId' then replace Page Length section with given button group.
    $("[id$='" + tableId + "_wrapper']").find('.dataTables_length').html('');
    if (dtOptions.customBtnGrpId) {
        $("[id$='" + tableId + "_wrapper']").find('.dataTables_length').html($(dtOptions.customBtnGrpId).html());
        $(dtOptions.customBtnGrpId).html('')
    }
    if ($("[id$='" + tableId + "_wrapper']").find('.btn-ladda').length < 1 && dtOptions.hideSearch == true) {
        $("[id$='" + tableId + "_wrapper']").find('.datatable-header').remove();
    }
    if (dtOptions.responsiveModalTitle) showRowInfo(dtOptions, dtTable);
    dtTable.on('draw.dt', function () { addShowRowInfoIcon(dtOptions, dtTable); formatAutoNumeric(""); });
    return dtTable;
}
function applySimpleDataTable(dtOptions) {
    var tableId = dtOptions.tableId;
    var allSortable = ((dtOptions.allSortable == 'true') ? true : false) || dtOptions.isViewOnly;
    var colToSort = (allSortable) ? 0 : 1;
    $("[id$='" + tableId + "']").prepend($("<thead></thead>").append($("[id$='" + tableId + "']").find("tr:first")));
    $("[id$='" + tableId + "']").removeAttr("cellspacing rules border style");//CSS Class added by C# needs to be removed in order to render Limitless datatable.
    var dtTable = $("[id$='" + tableId + "']").DataTable({
        autoWidth: false,
        dom: '<"datatable-scroll"t><"datatable-footer">',
        columnDefs: [{
            orderable: allSortable,
            targets: [0]
        }],
        order: [[colToSort, "asc"]],
        paging: false,
        drawCallback: function () {
            $(this).find('tbody tr').slice(-3).find('.dropdown, .btn-group').addClass('dropup');
        },
        preDrawCallback: function () {
            $(this).find('tbody tr').slice(-3).find('.dropdown, .btn-group').removeClass('dropup');
        }
    });
    if (dtOptions.hideSearch) {
        $("[id$='" + tableId + "_wrapper']").find('.dataTables_filter').html('');
    }
    if ($("[id$='" + tableId + "_wrapper']").find('.btn-ladda').length < 1) {
        $("[id$='" + tableId + "_wrapper']").find('.datatable-header').remove();
    }
    if (dtOptions.responsiveModalTitle) showRowInfo(dtOptions, dtTable);
    dtTable.on('draw.dt', function () { addShowRowInfoIcon(dtOptions, dtTable); formatAutoNumeric(""); });
    return dtTable;
}
/*
This fucntion is used to show record information of table row.
*/
function showRowInfo(dtOptions, dtTable) {
    var isViewOnly = dtOptions.isViewOnly ? true : false;
    var responsiveColumnIdx = (isViewOnly) ? 1 : 2;//Second column is default column on which + sign will be shown.
    addShowRowInfoIcon(dtOptions, dtTable);
    $("[id$='" + dtOptions.tableId + "']").find('span.show-row-info').off('click');
    $("[id$='" + dtOptions.tableId + "']").on("click", 'tbody tr td:nth-child(' + responsiveColumnIdx + ') span.show-row-info', function () {
        var tr = $(this).parents('tr');
        tableContent = getViewInfoModalContent($(tr).find('.row-info').attr('row-info'));
        var rowInfoTitle = ICON_VIEW_DTL + dtOptions.responsiveModalTitle;
        BootstrapDialog.show({
            title: rowInfoTitle,
            message: tableContent,
            nl2br: false,
            closable: true,
            buttons: [],
            onshown: function (dialogRef) {
                formatAutoNumeric(dialogRef.getModalDialog());
            }
        });
    });
}
function showInfoModal(element) {
	var infoElement = $(element).parent().find('.row-info');
	var tableContent = getViewInfoModalContent($(infoElement).attr('row-info'));
	BootstrapDialog.show({
        title: ICON_VIEW_DTL + $(infoElement).attr('data-info-title'),
        message: tableContent,
        nl2br: false,
        closable: false,
        buttons: [],
        onshown: function (dialogRef) {
            formatAutoNumeric(dialogRef.getModalDialog());
        }
    });
	return false;
}
function getViewInfoModalContent(info) {
    var tableContent = '<table class="table datatable-modal-table"><tbody>' + info;
    var footer = '<tfoot><tr><th style="text-align: center;" colspan=2>' +
                '<button type="button" class="btn btn-teal btn-sm" data-dismiss="modal">Close</button>' +
                '</th></tr></tfoot>';
    tableContent = tableContent + footer + '</table>';
    return tableContent;
}
/*
 * This fucntion is called on whenever datatable is drawn. It is requried to add row info icon if not present on that page. When datatable is initialized it does not add
 * info icon on all pages but adds it on first page only.
*/
function addShowRowInfoIcon(dtOptions, dtTable) {
    if (dtOptions.responsiveModalTitle) {
        var isViewOnly = dtOptions.isViewOnly ? true : false;
        var responsiveColumnIdx = (isViewOnly) ? 1 : 2;//Second column is default column on which + sign will be shown.
        var alreadyExist = $("[id$='" + dtOptions.tableId + "']").find('tbody tr td:nth-child(' + responsiveColumnIdx + ') span.show-row-info').length > 0;
        if (!alreadyExist) {
            $("[id$='" + dtOptions.tableId + "']").find('tbody tr td:nth-child(' + responsiveColumnIdx + ')').each(function () {
                $this = $(this);
                if ($this.parents('tr').children('td').length > 1) $this.html('<span class="show-row-info"><i class="icon-eye8 text-warning-300"></i></span>' + $this.html());
            });
        }
    }
}
function getConfirmModalMessage(element) {
    var message = $(element).attr('data-md-message');
    $(element).each(function () {
        $.each(this.attributes, function () {
            if (this.specified) {
                if (this.name.startsWith("data-md-message-opt")) {
                    var index = this.name.split('-').pop();
                    var pos = "{" + index + "}";
                    message = message.split(pos).join(this.value);
                }
            }
        });
    });
    return message;
}
function getConfirmModalHeaderIcon(action) {
    var icon = ICON_DELETE;
    if(CONFIRM == action) icon = ICON_CONFIRM;
    return icon;
}
function confirmActionModal(element) {
    var btnToClick = $(element).attr('data-md-button');
    var action = $(element).attr('data-md-action');
    var actionBtn = $("[id$=" + btnToClick + "]");
    var message = getConfirmModalMessage(element);
    var title = getConfirmModalHeaderIcon(action) + $(element).attr('data-md-title');
    BootstrapDialog.show({
        title: title,
        message: message,
        closable: false,
        buttons: [{
            label: 'Ok',
            icon: 'icon-checkmark4 mr-5 text-size-small',
            cssClass: 'btn btn-teal btn-sm btn-ok',
            action: function (dialogRef) {
            	$("[id$='btnDeleteRecordHdnId']").val($(element).attr('data-pid'));
                actionBtn.click();
                dialogRef.close();
            }
        }, {
            label: 'Cancel',
            icon: 'icon-cross2 mr-5 text-size-small',
            cssClass: 'btn btn-teal btn-sm',
            action: function(dialogRef) {
                dialogRef.close();
                Ladda.stopAll();
            }
        }]
    });
    return false;
}
function showModal(modalHdnId) {
    $('body').removeClass('modal-open');
    $('.modal-backdrop').remove();
    var modalId = $("[id$='activeModalHdn']").val();
    if (modalId) {
        if (modalId == "addMasterDataModal") {
    	    //If master data commmon modal then invoke modal again to set labels and modal title.
            invokeMasterDataModal();
        } else {
            $("#" + modalId).modal('show');
        }
        $("[id$='activeModalHdn']").val('');
    }
}
function invokeMasterDataModal() {
    var modalType = $("[id$='masterDataModalTypeHdn']").val();
    if (modalType == "PR_TAX_TYPE") addPropertyTax("");
    else if (modalType == "PROPERTY_TYPE") addPropertyType("");
    else if (modalType == "PROPERTY_LOCATION") addPropertyLocation("");
    else if (modalType == "PROPERTY_CHARGES") addPropertyChargeType("");
    else if (modalType == "UNIT_TYPE") addPropUnitType("");
    else if (modalType == "ENQUIRY_SOURCE") addEnquirySource("");
    else if (modalType == "OCCUPATION") addOccupation("");
    else if (modalType == "DESIGNATION") addDesignation("");
    else if (modalType == "RELATION_WITH_CUSTOMER") addRelation("");
    else if (modalType == "DIRECTION") addDirection("");
    else if (modalType == "FACING") addFacing("");
    else if (modalType == "COMMUNICATION_MEDIA") addCommunicationMedia("");
    else if (modalType == "AGENCY_TYPE") addAgencyType("");
    else if (modalType == "CLOSE_ENQUIRY") closeEnquiry("");
    else if (modalType == "OPEN_ENQUIRY") openEnquiry("");
    else if (modalType == "PROPERTY_PARKING_TYPE") addParkingType("");
    else if (modalType == "DOCUMENT_TYPE") addDocumentType("");
    else if (modalType == "PR_UNIT_PYMT_TYPE") addSalePymtType("");
    else if (modalType == "PR_EXPENSE_TYPE") addExpensesType("");
    else if (modalType == "PDC_PYMT") payPdcPayment("");
}
function showMasterDataModal(mdOptions) {
    if (mdOptions.parentModal) {
        var parentModalId = $(mdOptions.parentModal).attr('data-parent-modal');
        $("#" + parentModalId).modal('hide');
        $("[id$='masterDataParentModalHdn']").val(parentModalId);
	}
    $("#" + mdOptions.modalId).find('.modal-title').html(mdOptions.modalTitle);
	$("[id$='lbMasterDataModalInput1']").text(mdOptions.input1Label);
	$("[id$='lbMasterDataModalInput2']").text(mdOptions.input2Label);
	$("[id$='masterDataModalTypeHdn']").val(mdOptions.modalName);
	$("#" + mdOptions.modalId).modal('show');
}
function showSingleInputModal(mdOptions) {
    if (mdOptions.parentModal) {
        var parentModalId = $(mdOptions.parentModal).attr('data-parent-modal');
        $("#" + parentModalId).modal('hide');
        $("[id$='masterDataParentModalHdn']").val(parentModalId);
	}
    $("#" + mdOptions.modalId).find('.modal-title').html(mdOptions.modalTitle);
	$("[id$='lbMasterDataModalInput2']").text(mdOptions.input2Label);
	$("[id$='masterDataModalTypeHdn']").val(mdOptions.modalName);
	$("#"+mdOptions.modalId).modal('show');
}
function addPropertyTax(element) {
    var mdOptions = {
        parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "PR_TAX_TYPE",
        modalTitle: ICON_ADD + "Add Property Tax Type",
        input1Label: "Tax Type",
        input2Label: "Description"
    };
    showMasterDataModal(mdOptions);
    return false;
}
function addPropertyType(element) {
	var mdOptions = {
	    parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "PROPERTY_TYPE",
        modalTitle: ICON_ADD + "Add Property Type",
        input1Label: "Property Type",
        input2Label: "Description"
    };
	showMasterDataModal(mdOptions);
    return false;
}
function addPropertyLocation(element) {
	var mdOptions = {
	    parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "PROPERTY_LOCATION",
        modalTitle: ICON_ADD + "Add Property Location",
        input1Label: "Property Location",
        input2Label: "Description"
    };
	showMasterDataModal(mdOptions);
    return false;
}
function addPropertyChargeType(element) {
	var mdOptions = {
	    parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "PROPERTY_CHARGES",
        modalTitle: ICON_ADD + "Add Property Charge",
        input1Label: "Property Charge Name",
        input2Label: "Description"
    };
	showMasterDataModal(mdOptions);
    return false;
}
function addPropUnitType(element) {
	var mdOptions = {
	    parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "UNIT_TYPE",
        modalTitle: ICON_ADD + "Add Unit Type",
        input1Label: "Unit Type",
        input2Label: "Description"
    };
	showMasterDataModal(mdOptions);
    return false;
}
function addEnquirySource(element) {
	var mdOptions = {
	    parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "ENQUIRY_SOURCE",
        modalTitle: ICON_ADD + "Add Enquiry Source",
        input1Label: "Enquiry Source",
        input2Label: "Description"
    };
	showMasterDataModal(mdOptions);
    return false;
}
function addOccupation(element) {
	var mdOptions = {
	    parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "OCCUPATION",
        modalTitle: ICON_ADD + "Add Occupation",
        input1Label: "Occupation",
        input2Label: "Description"
    };
	showMasterDataModal(mdOptions);
    return false;
}
function addDesignation(element) {
	var mdOptions = {
	    parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "DESIGNATION",
        modalTitle: ICON_ADD + "Add Designation",
        input1Label: "Designation",
        input2Label: "Description"
    };
	showMasterDataModal(mdOptions);
    return false;
}
function addRelation(element) {
	var mdOptions = {
	    parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "RELATION_WITH_CUSTOMER",
        modalTitle: ICON_ADD + "Add Relation With Customer",
        input1Label: "Relation With Customer",
        input2Label: "Description"
    };
	showMasterDataModal(mdOptions);
    return false;
}
function addDirection(element) {
	var mdOptions = {
	    parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "DIRECTION",
        modalTitle: ICON_ADD + "Add Direction",
        input1Label: "Direction",
        input2Label: "Description"
    };
	showMasterDataModal(mdOptions);
    return false;
}
function addFacing(element) {
	var mdOptions = {
	    parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "FACING",
        modalTitle: ICON_ADD + "Add Unit Facing",
        input1Label: "Facing",
        input2Label: "Description"
    };
	showMasterDataModal(mdOptions);
    return false;
}
function addCommunicationMedia(element) {
	var mdOptions = {
	    parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "COMMUNICATION_MEDIA",
        modalTitle: ICON_ADD + "Add Communication Media",
        input1Label: "Communication Media",
        input2Label: "Description"
    };
	showMasterDataModal(mdOptions);
    return false;
}
function addAgencyType(element) {
	var mdOptions = {
	    parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "AGENCY_TYPE",
        modalTitle: ICON_ADD + "Add Agency Type",
        input1Label: "Agency Type",
        input2Label: "Description"
    };
	showMasterDataModal(mdOptions);
    return false;
}
function closeEnquiry(element) {
	var mdOptions = {
	    parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "CLOSE_ENQUIRY",
        modalTitle: ICON_ADD + "Close Enquiry",
        input2Label: "Close Reason"
    };
    showSingleInputModal(mdOptions);
    return false;
}
function openEnquiry(element) {
	var mdOptions = {
	    parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "OPEN_ENQUIRY",
        modalTitle: ICON_ADD + "Open Enquiry",
        input2Label: "Reason"
    };
    showSingleInputModal(mdOptions);
    return false;
}
function addParkingType(element) {
	var mdOptions = {
	    parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "PROPERTY_PARKING_TYPE",
        modalTitle: ICON_ADD + "Add Parking Type",
        input1Label: "Parking Type",
        input2Label: "Description"
    };
	showMasterDataModal(mdOptions);
    return false;
}
function addDocumentType(element) {
	var mdOptions = {
	    parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "DOCUMENT_TYPE",
        modalTitle: ICON_ADD + "Add Document Type",
        input1Label: "Document Type",
        input2Label: "Description"
    };
	showMasterDataModal(mdOptions);
    return false;
}
function addSalePymtType(element) {
	var mdOptions = {
	    parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "PR_UNIT_PYMT_TYPE",
        modalTitle: ICON_ADD + "Add Sale Payment Type",
        input1Label: "Payment Type",
        input2Label: "Description"
    };
	showMasterDataModal(mdOptions);
    return false;
}
function addExpensesType(element) {
	var mdOptions = {
	    parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "PR_EXPENSE_TYPE",
        modalTitle: ICON_ADD + "Add Expenses Type",
        input1Label: "Expenses Type",
        input2Label: "Description"
    };
	showMasterDataModal(mdOptions);
    return false;
}
function payPdcPayment(element) {
	var mdOptions = {
	    parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "PDC_PYMT",
        modalTitle: ICON_ADD + "Pay Amount",
        input1Label: "Payment Amount",
        input2Label: "Comments"
    };
	showMasterDataModal(mdOptions);
    return false;
}
