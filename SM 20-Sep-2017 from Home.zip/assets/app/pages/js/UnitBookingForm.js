﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
	initTaxGrid();
	initCMTaxGrid();
    formatFields();
    showModal();
}

function initTaxGrid() {
    var dtOptions = {
        tableId: "taxDetailGrid",
        isViewOnly: false
    };
    var dtTable = applySimpleDataTable(dtOptions);
}
function initCMTaxGrid() {
    var dtOptions = {
        tableId: "cmTaxDetailGrid",
        isViewOnly: false
    };
    var dtTable = applySimpleDataTable(dtOptions);
}



