﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ConstroSoft.Controller
{
    public class FBUserLoginController : ApiController
    {
        [HttpPost]
        [ActionName("LoginUser")]
        public string LoginUser([FromBody]PortalUserDTO portalUserDTO)
        {
            FBIntegrationBO fBIntegrationBO = new FBIntegrationBO();
            List<string> responseJson = new List<string>();
            var response = JsonConvert.SerializeObject("Failure");
            string tokenKey;
            if (portalUserDTO != null)
            {
                string errorMessage = fBIntegrationBO.validateLoginUser(portalUserDTO);
                if (errorMessage == null)
                {
                    BusinessOutputTO outputTO = fBIntegrationBO.validateFBUser(portalUserDTO);
                    if (BusinessOutputTO.Status.SUCCESS.Equals(outputTO.status))
                    {
                        portalUserDTO = (PortalUserDTO)outputTO.result;
                        tokenKey = fBIntegrationBO.saveFBToken(portalUserDTO);
                        responseJson.Add("User log in successfully for " + portalUserDTO.UserName);
                        responseJson.Add(" Token: " + tokenKey);
                        responseJson.Add(" Token Expiry: 1800000");
                        response = JsonConvert.SerializeObject(responseJson);
                    }
                    else
                    {
                        response = JsonConvert.SerializeObject(outputTO.errorMessage);
                    }

                }
                else
                {
                    response = JsonConvert.SerializeObject(errorMessage);
                }
            }
            return response;
        }
    }
}