﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initSoldUnitSearchGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initSoldUnitSearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        pageLength: 10
    };
    
    $("[id$='soldUnitSearchGrid']").CSBasicDatatable(dtOptions);
}




