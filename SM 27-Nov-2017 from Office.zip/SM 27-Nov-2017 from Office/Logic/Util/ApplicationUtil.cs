﻿using System.Web.UI;
/// <summary>
/// Summary description for EmailUtil
/// </summary>

namespace ConstroSoft
{
    public static class ApplicationUtil
    {
        //Logger Instance
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        /**
         * This method checks whether Current request async call.
         */
        public static bool isAsyncPostBack(Page page)
        {
            return ScriptManager.GetCurrent(page).IsInAsyncPostBack;
        }
        /**
         * This method checks whether Current request is Post call or async call for inner page. If yes then returns true.
         */
        public static bool isSubPageRendered(Page page)
        {
            bool isAsyncCall = ScriptManager.GetCurrent(page).IsInAsyncPostBack;
            string updatePnlId = ScriptManager.GetCurrent(page).AsyncPostBackSourceElementID;
            return (!isAsyncCall || (isAsyncCall && updatePnlId.Contains("$ContentPlaceHolder1")));
        }
        /**
         * This method returns control element identifier on which bootstrap CSS will be applied. This method is called at end of the AJAX request. So when page is rendered
         * all controls inside it will be converted to bootstrap elements.
         **/
        public static string getParentToApplyCSS(Page page)
        {
            string parent = "body";
            bool isAsyncCall = ScriptManager.GetCurrent(page).IsInAsyncPostBack;
            string updatePnlId = ScriptManager.GetCurrent(page).AsyncPostBackSourceElementID;
            if (isAsyncCall)
            {
                if (updatePnlId.Contains("$ContentPlaceHolder1")) parent = "div.content-wrapper";
                else if (updatePnlId.Contains("$notificationGrid") || updatePnlId.Contains("$RefreshNotificationTimer")) parent = "ul.ulNotification";
            }
            return parent;
        }
        public static string getSessionNotyMsg(System.Web.SessionState.HttpSessionState Session)
        {
            string msg = "";
            if(Session[Constants.Session.NOTY_MSG] != null && (Session[Constants.Session.NOTY_MSG]).ToString().Trim() != "") {
                msg = (Session[Constants.Session.NOTY_MSG]).ToString();
                Session.Remove(Constants.Session.NOTY_MSG);
            }
            return msg;
        }
        public static bool isSessionActive(System.Web.SessionState.HttpSessionState Session)
        {
            return (Session[Constants.Session.USERNAME] != null && (Session[Constants.Session.USERNAME]).ToString().Trim() != "") ? true : false;
        }
    }
}