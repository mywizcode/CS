﻿using ConstroSoft.Logic.Job;
using Quartz;
using Quartz.Impl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ConstroSoft.Logic.Scheduler
{
    public class JobScheduler
    {
        private static readonly log4net.ILog log =
                log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        
        public static void Start()
        {
            try
            {
                JobBO jobBO = new JobBO();
                JobTrigger jobTrigger = new JobTrigger();
                JobHistoryBO jobHistoryBO = new JobHistoryBO();
                IScheduler scheduler = StdSchedulerFactory.GetDefaultScheduler();
                scheduler.Start();
                //Fetch all the active jobs from Job table.
                UserDefinitionDTO userDefinitionDTO = null;
                HttpContext httpContext = HttpContext.Current;
                if (httpContext.ApplicationInstance.Session.Count > 0){
                   userDefinitionDTO = (UserDefinitionDTO)httpContext.ApplicationInstance.Session[Constants.Session.USERDEFINITION];
                   scheduler.Context.Put("UserDefinitionDTO", userDefinitionDTO);
                }
                IList<JobDTO> jobList = jobBO.fetchJobs(userDefinitionDTO.FirmMember.Id.ToString());
                if (jobList != null && jobList.Count > 0)
                {
                    foreach (JobDTO jobDTO in jobList)
                    {
                        if(jobDTO.JobName.Equals(Constants.NOTIFICATION_JOB) && !jobHistoryBO.checkIfJobRunning(userDefinitionDTO.FirmNumber, jobDTO.Id)){
                            IJobDetail notificationJob = JobBuilder.Create<NotificationJob>().Build();
                            ITrigger notificationTrigger= null;
                            if(jobDTO.JobIntervalType == JobIntervalType.WithSimpleSchedule){
                                notificationTrigger = jobTrigger.CreateSimpleSchedule();
                            }
                            scheduler.Context.Put(Constants.NOTIFICATION_JOB, jobDTO);
                            scheduler.ScheduleJob(notificationJob, notificationTrigger);
                        }
                        if(jobDTO.JobName.Equals(Constants.TASK_JOB) && !jobHistoryBO.checkIfJobRunning(userDefinitionDTO.FirmNumber, jobDTO.Id)){
                            IJobDetail taskjob = JobBuilder.Create<TaskJob>().Build();
                            ITrigger taskTrigger = null;
                            if(jobDTO.JobIntervalType == JobIntervalType.WithSimpleSchedule){
                                taskTrigger =jobTrigger.CreateSimpleSchedule();
                            }
                            scheduler.Context.Put(Constants.TASK_JOB, jobDTO);
                            scheduler.ScheduleJob(taskjob, taskTrigger);
                        }                    
                    }
                }
                
                
                /**IJobDetail job = JobBuilder.Create<EmailJob>().Build();
                ITrigger trigger = TriggerBuilder.Create()
                    .WithDailyTimeIntervalSchedule
                      (s =>
                         s.WithIntervalInHours(24)
                        .OnEveryDay()
                        .StartingDailyAt(TimeOfDay.HourAndMinuteOfDay(0, 0))
                      )
                    .Build();
    
                 ITrigger trigger1 = TriggerBuilder.Create()
                    .WithIdentity("trigger1", "group1")
                    .StartNow()
                    .WithSimpleSchedule(x => x
                        .WithIntervalInSeconds(10)
                        .RepeatForever())
                    .Build();
    
                scheduler.ScheduleJob(job, trigger1);**/
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error retriving file list:" ,exp);
            }
            finally
            {

            }
            }
            
    }
}