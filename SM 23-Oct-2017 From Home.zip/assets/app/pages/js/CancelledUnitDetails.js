﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
	initTaxGrid();
	initCMTaxGrid();
	initPaymentGrid();
    formatFields();
    showModal();
}

function initTaxGrid() {
    var dtOptions = {
        hasActionColumn: false,
        hideSearch: true,
        pagination: false,
        sorting: false
    };

    $("[id$='taxDetailGrid']").CSBasicDatatable(dtOptions);
}
function initCMTaxGrid() {
    var dtOptions = {
        hasActionColumn: false,
        hideSearch: true,
        pagination: false,
        sorting: false
    };

    $("[id$='cmTaxDetailGrid']").CSBasicDatatable(dtOptions);
}
function initPaymentGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: isViewOnly,
        customBtnGrpId: "#paymentGridBtnGrp",
        rowInfoModalTitle: "Payment Details",
        pageLength: 5,
        sortColumn: 2,
        hideSearch: true
    };

    $("[id$='paymentGrid']").CSBasicDatatable(dtOptions);
}



