﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initCancelledUnitSearchGrid();
    formatFields();
    showModal();
}

function initCancelledUnitSearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        pageLength: 10
    };

    $("[id$='cancelledUnitSearchGrid']").CSBasicDatatable(dtOptions);
}




