﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;

public partial class Customer : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifyStep1Error = "addModifyStep1Error";
    string addModifyStep1Error1 = "addModifyStep1Error1";
    string addMasterDataError = "addMasterDataError";
    string addModifyAddressError = "addModifyAddressError";
    string addMasterDataModal = "addMasterDataModal";
    string SearchFilterModal = "SearchFilterModal";
    string addModifyAddressModal = "addModifyAddressModal";
    string step1 = "step1";
    string step2 = "step2";
    DropdownBO drpBO = new DropdownBO();
    CustomerBO customerBO = new CustomerBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    public enum CustomerPageMode { ADD, MODIFY, VIEW, NONE }
    public enum AddressAction { ADD, MODIFY }
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                Session.Remove(Constants.Session.PAGE_DATA);
                doInit();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg) {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        lnkAddCustomerBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.CUSTOMER_ADD);
        if (customerSearchGrid.Rows.Count > 0)
        {
            for (var i = 0; i < customerSearchGrid.Rows.Count; i++)
            {
                LinkButton tmpModifyBtn = (LinkButton)customerSearchGrid.Rows[i].FindControl("lnkModifyCustomerBtn");
                if (tmpModifyBtn != null)
                {
                    tmpModifyBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.CUSTOMER_MODIFY);
                }
                LinkButton tmpDeleteBtn = (LinkButton)customerSearchGrid.Rows[i].FindControl("lnkDeleteCustomerBtn");
                if (tmpDeleteBtn != null)
                {
                    tmpDeleteBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.CUSTOMER_DELETE);
                }
            }
        }
    }
    private CustomerPageMode getModifyModeIfEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        return CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.CUSTOMER_MODIFY) ? CustomerPageMode.MODIFY : CustomerPageMode.VIEW;
    }
    private void preRenderInitFormElements()
    {
        renderPageLayout();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        drpBO.drpDataBase(drpSalutation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.SALUTATION, null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpOccupation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.OCCUPATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<Gender>(drpGender, Constants.SELECT_ITEM);
        drpBO.drpEnum<MaritalStatus>(drpMaritalStatus, Constants.SELECT_ITEM);

        drpBO.drpDataBase(drpAddressCountry, DrpDataType.COUNTRY, null, null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAddressState, DrpDataType.STATE, Constants.DEFAULT_COUNTRY, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        initCityDrp(drpAddressCity, Constants.DEFAULT_STATE);
        drpBO.drpDataBase(drpAddressType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ADDRESS_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<PreferredAddress>(drpPreferredAddress, null);
    }
    private void initCityDrp(DropDownList drp, string stateId)
    {
        drpBO.drpDataBase(drp, DrpDataType.CITY, stateId, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit()
    {
        Session[Constants.Session.PAGE_DATA] = new CustomerPageDTO();
        setSearchFilter(null);
        initPageInfo(CustomerPageMode.NONE);
        clearSearchGrid();
        initDropdowns();
        loadCustomerSearchGrid();
    }
    private void initPageInfo(CustomerPageMode pageMode)
    {
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        pageModeHdn.Value = pageMode.ToString();
        activeStepHdn.Value = step1;
        if (CustomerPageMode.NONE == pageMode)
        {
            getSessionPageData().SelectedCustomer = null;
        }
    }
    private void renderPageLayout()
    {
        CustomerPageMode pageMode = EnumHelper.ToEnum<CustomerPageMode>(pageModeHdn.Value);
        btnReturnToList.Visible = (CustomerPageMode.NONE != pageMode);
        pnlCustomerSearch.Visible = (CustomerPageMode.NONE == pageMode);
        pnlCustomerAddModify.Visible = (CustomerPageMode.ADD == pageMode || CustomerPageMode.MODIFY == pageMode || CustomerPageMode.VIEW == pageMode);
        initFormFields();
        resetPageTitle(pageMode);
    }
    private void resetPageTitle(CustomerPageMode pageMode)
    {
        if (CustomerPageMode.NONE == pageMode) lbPageTitle.Text = Constants.ICON.SEARCH + Resources.Labels.SEARCH_CUSTOMER;
        else if (CustomerPageMode.ADD == pageMode) lbPageTitle.Text = Constants.ICON.ADD + Resources.Labels.ADD_CUSTOMER;
        else if (CustomerPageMode.MODIFY == pageMode) lbPageTitle.Text = Constants.ICON.MODIFY + Resources.Labels.MODIFY_CUSTOMER;
        else if (CustomerPageMode.VIEW == pageMode) lbPageTitle.Text = Constants.ICON.VIEW_DTL + Resources.Labels.CUSTOMER_DETAILS;
    }
    private void initFormFields()
    {
        bool isReadOnly = (CustomerPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
        bool visible = !(CustomerPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
        bool isEnabled = !isReadOnly;
        if (pnlCustomerAddModify.Visible)
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            //Fields
            drpSalutation.Enabled = isEnabled;
            txtFirstName.ReadOnly = isReadOnly;
            txtMiddleName.ReadOnly = isReadOnly;
            txtLastName.ReadOnly = isReadOnly;
            drpGender.Enabled = isEnabled;
            txtDOB.ReadOnly = isReadOnly;
            drpMaritalStatus.Enabled = isEnabled;
            txtContact.ReadOnly = isReadOnly;
            txtAltContact.ReadOnly = isReadOnly;
            txtEmail.ReadOnly = isReadOnly;
            txtAltEmailID.ReadOnly = isReadOnly;
            drpOccupation.Enabled = isEnabled;
            txtPan.ReadOnly = isReadOnly;
            
            lnkAddAddress.Visible = visible;
            if (addressGrid.Items.Count > 0)
            {
                foreach(ListViewItem item in addressGrid.Items){
                    LinkButton modifyBtn = (LinkButton)item.FindControl("lnkModifyAddress");
                    if (modifyBtn != null) modifyBtn.Visible = visible;
                    LinkButton deleteBtn = (LinkButton)item.FindControl("lnkDeleteAddress");
                    if (deleteBtn != null) deleteBtn.Visible = visible;
                }
            }
            //Buttons
            btnAddModifyCustomerSubmit.Visible = visible;
            addOccupation.Visible = visible;
        }
    }
    private void clearSearchGrid()
    {
        List<CustomerDTO> tmpList = new List<CustomerDTO>();
        getSessionPageData().SearchResult = tmpList;
        customerSearchGrid.DataSource = tmpList;
        customerSearchGrid.DataBind();
    }
    private CustomerPageDTO getSessionPageData()
    {
        return (CustomerPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<CustomerDTO> getSearchCustomerList()
    {
        return getSessionPageData().SearchResult;
    }
    private CustomerDTO getDBCustomerDTO()
    {
        return getSessionPageData().SelectedCustomer;
    }
    private CustomerDTO getSearchCustomerDTO(long Id)
    {
        List<CustomerDTO> searchList = getSearchCustomerList();
        CustomerDTO selectedCustomerDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            selectedCustomerDTO = searchList.Find(c => c.Id == Id);
        }
        return selectedCustomerDTO;
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private void loadCustomerSearchGrid()
    {
        IList<CustomerDTO> results = customerBO.fetchCustomerGridData(getUserDefinitionDTO().FirmNumber, getSearchFilter());
        getSessionPageData().SearchResult = results.ToList<CustomerDTO>();
        customerSearchGrid.DataSource = results;
        customerSearchGrid.DataBind();
    }
    private void fetchSelectedCustomer(long Id)
    {
        CustomerDTO customerDTO = null;
        pnlSoldUnits.Visible = false;
        if (CustomerPageMode.ADD.ToString().Equals(pageModeHdn.Value))
        {
            customerDTO = populateCustomerDTOAdd();
        }
        else if (CustomerPageMode.MODIFY.ToString().Equals(pageModeHdn.Value) || CustomerPageMode.VIEW.ToString().Equals(pageModeHdn.Value))
        {
            customerDTO = customerBO.fetchCustomerWithUnits(Id);
            if (customerDTO.PrUnitSaleDetails != null && customerDTO.PrUnitSaleDetails.Count > 0)
            {
            	pnlSoldUnits.Visible = true;
                soldUnitsGrid.DataSource = customerDTO.PrUnitSaleDetails;
                soldUnitsGrid.DataBind();
            }
        }
        getSessionPageData().SelectedCustomer = customerDTO;
    }
    private void doViewModifyAction(CustomerPageMode pageMode, long Id)
    {
        initPageInfo(pageMode);
        fetchSelectedCustomer(Id);
        populateUIFieldsFromDTO(getDBCustomerDTO());
    }
    protected void gotoSoldUnit(object sender, EventArgs e)
    {
        try
        {
        	LinkButton rd = (LinkButton)sender;
            string selectedSoldUnitId = rd.Attributes["data-pid"];
            if (!string.IsNullOrWhiteSpace(selectedSoldUnitId))
            {
            	CustomerDTO customerDto = getDBCustomerDTO();
            	PrUnitSaleDetailDTO soldUnitDto = customerDto.PrUnitSaleDetails.ToList<PrUnitSaleDetailDTO>().Find(x => x.Id == long.Parse(selectedSoldUnitId));
            	if (isValidForRedirection(soldUnitDto)) {
                    if(soldUnitDto.Status == PRUnitSaleStatus.Sold) {
                    	SoldUnitDetailNavDTO navDTO = new SoldUnitDetailNavDTO();
                        navDTO.Mode = PageMode.VIEW;
                        navDTO.PrUnitSaleDetailId = soldUnitDto.Id;
                        //navDTO.PrevNavDto = getCurrentPageNavigation(); TODO - Do we need to navigate back to customer
                        Session[Constants.Session.NAV_DTO] = navDTO;
                        Response.Redirect(Constants.URL.SOLD_UNIT_DETAILS, true);
                    } else {
                    	CancelledUnitDetailNavDTO navDTO = new CancelledUnitDetailNavDTO();
                    	navDTO.Mode = PageMode.VIEW;
                    	navDTO.PrUnitSaleDetailId = soldUnitDto.Id;
                    	//navDTO.PrevNavDto = getCurrentPageNavigation();
                    	Session[Constants.Session.NAV_DTO] = navDTO;
                    	Response.Redirect(Constants.URL.CANCELLED_UNIT_DETAILS, true);
                    }
            	}
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    private bool isValidForRedirection(PrUnitSaleDetailDTO soldUnitDto) {
    	//TODO - Check whether user has access for Property of Selected Unit
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
    	bool isValid = true;
    	if(true) {
    		setErrorMessage("You do not have access for '"+ soldUnitDto.PropertyUnit.PropertyTower.Property.Name +"' Property.", commonError);
    		isValid = false;
    	} else if(soldUnitDto.Status == PRUnitSaleStatus.Sold && CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_SOLD_PROPERTY_UNITS)) {
    		setErrorMessage("You do not have access to sold property units.", commonError);
    		isValid = false;
    	} else if(soldUnitDto.Status == PRUnitSaleStatus.Cancelled && CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_CANCELLED_PROPERTY_UNITS)) {
    		setErrorMessage("You do not have access to cancelled property units.", commonError);
    		isValid = false;
    	}
    	return isValid;
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            initPageInfo(CustomerPageMode.NONE);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickAddCustomerBtn(object sender, EventArgs e)
    {
        try
        {
            initPageInfo(CustomerPageMode.ADD);
            fetchSelectedCustomer(0);
            populateUIFieldsFromDTO(getDBCustomerDTO());
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickViewCustomerBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            string selectedId = rd.Attributes["data-pid"];
            doViewModifyAction(CustomerPageMode.VIEW, long.Parse(selectedId));
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyCustomerBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            string selectedId = rd.Attributes["data-pid"];
            doViewModifyAction(CustomerPageMode.MODIFY, long.Parse(selectedId));
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void addOrModifyCustomer(object sender, EventArgs e)
    {
        try
        {
            if (validateCustomerAddOrModify())
            {
                CustomerDTO customerDTO = getDBCustomerDTO();
                populateCustomerDTOFromUI(customerDTO);
                long Id = customerDTO.Id;
                if (CustomerPageMode.ADD.ToString().Equals(pageModeHdn.Value))
                {
                    Id = customerBO.saveCustomer(customerDTO);
                    setSuccessMessage(CommonUtil.getRecordAddSuccessMsg("Customer"));
                }
                else if (CustomerPageMode.MODIFY.ToString().Equals(pageModeHdn.Value))
                {
                    customerBO.updateCustomer(customerDTO);
                    setSuccessMessage(CommonUtil.getRecordModifySuccessMsg("Customer"));
                }
                loadCustomerSearchGrid();
                doViewModifyAction(getModifyModeIfEntitlement(), Id);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addModifyStep1Error);
        }
    }
    protected void deleteCustomer(object sender, EventArgs e)
    {
        try
        {
            long selectedId = getDeleteRecordHdnId();
            customerBO.deleteCustomer(selectedId);
            initPageInfo(CustomerPageMode.NONE);
            loadCustomerSearchGrid();
            setSuccessMessage(CommonUtil.getRecordDeleteSuccessMsg("Customer"));
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelCustomer(object sender, EventArgs e)
    {
        try
        {
            initPageInfo(CustomerPageMode.NONE);
            loadCustomerSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    /**
     * Define all validation which will be done before add or Modify property.
     * */
    private bool validateCustomerAddOrModify()
    {
        return validateStep1();
    }
    private bool validateAddressMandatory() {
        bool isValid = true;
        List<AddressDTO> addressList = getDBCustomerDTO().ContactInfo.Addresses.ToList<AddressDTO>();
        if (addressList == null || addressList.Count == 0) {
            setErrorMessage(Resources.Messages.ADDRESS_MANDATORY, addModifyStep1Error);
            isValid = false;
        } else {
            int preferredCount = 0;
            foreach(AddressDTO addressDto in addressList) {
                if(PreferredAddress.Yes == addressDto.PreferredAddress) preferredCount++;
            }
            if(preferredCount == 0) {
                setErrorMessage(Resources.Messages.PRIMARY_ADDRESS_MANDATORY, addModifyStep1Error);
                isValid = false;
            } else if(preferredCount > 1) {
                setErrorMessage(Resources.Messages.PRIMARY_ADDRESS_MULTIPLE_NOT_ALLOWED, addModifyStep1Error);
                isValid = false;
            }
        }
        return isValid;
    }
    private bool validateStep1() {
        return validateMandatoryFields(addModifyStep1Error, step1) && validateAddressMandatory();
    }
    private bool validateMandatoryFields(string valGrp, string step)
    {
        Page.Validate(valGrp);
        bool isValid = Page.IsValid;
        if (!isValid)
        {
            if (!string.IsNullOrWhiteSpace(step)) setCurrentStep(step);
        }
        return isValid;
    }
    private void setCurrentStep(string step)
    {
        activeStepHdn.Value = step;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private CustomerDTO populateCustomerDTOAdd()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.ContactInfo = new ContactInfoDTO();
        customerDTO.ContactInfo.Addresses = new HashSet<AddressDTO>();
        customerDTO.DocumentInfo = new DocumentInfoDTO();
        customerDTO.FirmNumber = userDefDto.FirmNumber;
        customerDTO.InsertUser = userDefDto.Username;
        return customerDTO;
    }
    private void populateCustomerDTOFromUI(CustomerDTO customerDTO)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        customerDTO.Salutation = CommonUIConverter.getMasterControlDTO(drpSalutation.Text, null);
        customerDTO.FirstName = txtFirstName.Text;
        customerDTO.MiddleName = txtMiddleName.Text;
        customerDTO.LastName = txtLastName.Text;
        customerDTO.Occupation = CommonUIConverter.getMasterControlDTO(drpOccupation.Text, null);
        customerDTO.Pan = txtPan.Text;
        customerDTO.ContactInfo.Gender = EnumHelper.ToEnumNullable<Gender>(drpGender.Text);
        customerDTO.ContactInfo.Dob = CommonUtil.getCSDate(txtDOB.Text);
        customerDTO.ContactInfo.MaritalStatus = EnumHelper.ToEnumNullable<MaritalStatus>(drpMaritalStatus.Text);
        customerDTO.ContactInfo.Contact = txtContact.Text;
        customerDTO.ContactInfo.AltContact = txtAltContact.Text;
        customerDTO.ContactInfo.Email = txtEmail.Text;
        customerDTO.ContactInfo.AltEmail = txtAltEmailID.Text;
        
        customerDTO.UpdateUser = userDefDto.Username;
        customerDTO.Version = userDefDto.Version;
    }
    private void populateUIFieldsFromDTO(CustomerDTO customerDTO)
    {
        if (customerDTO != null && customerDTO.Salutation != null) drpSalutation.Text = customerDTO.Salutation.Id.ToString(); else drpSalutation.ClearSelection();
        if (customerDTO != null) txtFirstName.Text = customerDTO.FirstName; else txtFirstName.Text = null;
        if (customerDTO != null) txtMiddleName.Text = customerDTO.MiddleName; else txtMiddleName.Text = null;
        if (customerDTO != null) txtLastName.Text = customerDTO.LastName; else txtLastName.Text = null;
        if (customerDTO != null && customerDTO.ContactInfo.Gender != null) drpGender.Text = customerDTO.ContactInfo.Gender.ToString(); else drpGender.ClearSelection();
        if (customerDTO != null) txtDOB.Text = CommonUtil.getCSDate(customerDTO.ContactInfo.Dob); else txtDOB.Text = null;
        if (customerDTO != null && customerDTO.ContactInfo.MaritalStatus != null) drpMaritalStatus.Text = customerDTO.ContactInfo.MaritalStatus.ToString(); else drpMaritalStatus.ClearSelection();
        if (customerDTO != null) txtContact.Text = customerDTO.ContactInfo.Contact; else txtContact.Text = null;
        if (customerDTO != null) txtAltContact.Text = customerDTO.ContactInfo.AltContact; else txtAltContact.Text = null;
        if (customerDTO != null) txtEmail.Text = customerDTO.ContactInfo.Email; else txtEmail.Text = null;
        if (customerDTO != null) txtAltEmailID.Text = customerDTO.ContactInfo.AltEmail; else txtAltEmailID.Text = null;
        if (customerDTO != null) txtPan.Text = customerDTO.Pan; else txtPan.Text = null;
        if (customerDTO != null) txtCustomerRefNo.Text = customerDTO.CustRefNo; else txtCustomerRefNo.Text = null;
        if (customerDTO != null && customerDTO.Occupation != null) drpOccupation.Text = customerDTO.Occupation.Id.ToString(); else drpOccupation.ClearSelection();

        populateAddressGrid(customerDTO.ContactInfo);
    }
    private void populateAddressGrid(ContactInfoDTO conactInfoDto)
    {
        addressGrid.DataSource = new List<AddressDTO>();
        if (conactInfoDto != null)
        {
            assignUiIndexToAddress(conactInfoDto.Addresses);
            addressGrid.DataSource = conactInfoDto.Addresses;
        }
        addressGrid.DataBind();
        pnlAddressEmpty.Visible = (conactInfoDto.Addresses == null || conactInfoDto.Addresses.Count == 0);
    }

    private void assignUiIndexToAddress(ISet<AddressDTO> addressDtos)
    {
        if (addressDtos != null && addressDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (AddressDTO addressDto in addressDtos)
            {
                addressDto.UiIndex = uiIndex++;
                addressDto.UiFullAddress = CommonUIConverter.getUiFullAddress(addressDto);
            }
        }
    }
    //Filter Criteria - Property Search - Start
    private CustomerFilterDTO getSearchFilter()
    {
        return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            CustomerFilterDTO filterDTO = getSearchFilter();
            if (!string.IsNullOrWhiteSpace(filterDTO.FirstName)) txtFirstNameFilter.Text = filterDTO.FirstName; else txtFirstNameFilter.Text = null;
            if (!string.IsNullOrWhiteSpace(filterDTO.LastName)) txtLastNameFilter.Text = filterDTO.LastName; else txtLastNameFilter.Text = null;
            if (filterDTO.Dob != null) txtDOBFilter.Text = CommonUtil.getCSDate(filterDTO.Dob); else txtDOBFilter.Text = null;
            if (!string.IsNullOrWhiteSpace(filterDTO.Contact)) txtContactFilter.Text = filterDTO.Contact; else txtContactFilter.Text = null;
            if (!string.IsNullOrWhiteSpace(filterDTO.CustRefNo)) txtCustRefNoFilter.Text = filterDTO.CustRefNo; else txtCustRefNoFilter.Text = null;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            CustomerFilterDTO filterDTO = new CustomerFilterDTO();
            if (!string.IsNullOrWhiteSpace(txtFirstNameFilter.Text))
            {
                filterDTO.FirstName = txtFirstNameFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(txtLastNameFilter.Text))
            {
                filterDTO.LastName = txtLastNameFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(txtDOBFilter.Text))
            {
                filterDTO.Dob = CommonUtil.getCSDate(txtDOBFilter.Text);
            }
            if (!string.IsNullOrWhiteSpace(txtContactFilter.Text))
            {
                filterDTO.Contact = txtContactFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(txtCustRefNoFilter.Text))
            {
                filterDTO.CustRefNo = txtCustRefNoFilter.Text;
            }
            setSearchFilter(filterDTO);
            loadCustomerSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            loadCustomerSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(CustomerFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new CustomerFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            CustomerFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.FIRST_NAME)) filterDTO.FirstName = null;
            else if (token.StartsWith(Constants.FILTER.LAST_NAME)) filterDTO.LastName = null;
            else if (token.StartsWith(Constants.FILTER.DOB)) filterDTO.Dob = null;
            else if (token.StartsWith(Constants.FILTER.CONTACT)) filterDTO.Contact = null;
            else if (token.StartsWith(Constants.FILTER.CUST_REF_NO)) filterDTO.CustRefNo = null;

            setSearchFilterTokens();
            loadCustomerSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        CustomerFilterDTO filterDTO = getSearchFilter();
        string filter = "";
        if (!string.IsNullOrWhiteSpace(filterDTO.FirstName)) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.FIRST_NAME + filterDTO.FirstName);
        if (!string.IsNullOrWhiteSpace(filterDTO.LastName)) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.LAST_NAME + filterDTO.LastName);
        if (filterDTO.Dob != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.DOB + CommonUtil.getCSDate(filterDTO.Dob));
        if (!string.IsNullOrWhiteSpace(filterDTO.Contact)) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.CONTACT + filterDTO.Contact);
        if (!string.IsNullOrWhiteSpace(filterDTO.CustRefNo)) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.CUST_REF_NO + filterDTO.CustRefNo);
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - Customer Search - End
    //Master Data Modal save logic - Start
    protected void saveMasterData(object sender, EventArgs e)
    {
        try
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (masterDataModalTypeHdn.Value == "OCCUPATION")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.OCCUPATION, txtMasterDataInput1.Text,
                        txtMasterDataInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Occupation");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpOccupation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.OCCUPATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
            }

            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                activeModalHdn.Value = addMasterDataModal;
                setErrorMessage(errorMsg, addMasterDataError);
            }
            else
            {
                resetMasterDataModalFields();
                setParentModalFlag();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            activeModalHdn.Value = "";
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    protected void cancelMasterDataModal(object sender, EventArgs e)
    {
        try
        {
            resetMasterDataModalFields();
            setParentModalFlag();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    private void resetMasterDataModalFields()
    {
        txtMasterDataInput1.Text = "";
        txtMasterDataInput2.Text = "";
        masterDataModalTypeHdn.Value = "";
    }
    private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
    {
        string errorMsg = "";
        if (string.IsNullOrWhiteSpace(masterDataDto.Name))
        {
            errorMsg = string.Format(Resources.Messages.TEXTFIELD_REQUIRED, type);
        }
        else if (masterDataBO.isAlreadyExist(masterDataDto))
        {
            errorMsg = string.Format(Resources.Messages.ALREADY_EXIST_DB_ERROR, type);
        }
        return errorMsg;
    }
    private void setParentModalFlag()
    {
        activeModalHdn.Value = masterDataParentModalHdn.Value;
        masterDataParentModalHdn.Value = "";
    }
    //Master Data Modal save logic - End
    //Address Modal - Start
    protected void loadAddressCities(object sender, EventArgs e)
    {
        try
        {
            initCityDrp(drpAddressCity, drpAddressState.Text);
            SetFocus(drpAddressCity);
            activeModalHdn.Value = addModifyAddressModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void initAddressModalFields()
    {
        lbAddressModalTitle.Text = (AddressAction.ADD.ToString().Equals(addressModalActionHdnBtn.Value)) 
            ? Constants.ICON.ADD + Resources.Labels.ADD_ADDRESS : Constants.ICON.MODIFY + Resources.Labels.MODIFY_ADDRESS;
    }
    private void initAddressSectionFields(AddressDTO addressDto)
    {
        if (addressDto != null) txtAddressLine1.Text = addressDto.AddressLine1; else txtAddressLine1.Text = null;
        if (addressDto != null) txtAddressLine2.Text = addressDto.AddressLine2; else txtAddressLine2.Text = null;
        if (addressDto != null) txtTown.Text = addressDto.Town; else txtTown.Text = null;
        if (addressDto != null && addressDto.City != null) drpAddressCity.Text = addressDto.City.Id.ToString(); else drpAddressCity.ClearSelection();
        if (addressDto != null && addressDto.State != null) drpAddressState.Text = addressDto.State.Id.ToString(); else drpAddressState.ClearSelection();
        if (addressDto != null && addressDto.Country != null) drpAddressCountry.Text = addressDto.Country.Id.ToString(); else drpAddressCountry.ClearSelection();
        if (addressDto != null) txtPin.Text = addressDto.Pin; else txtPin.Text = null;
        if (addressDto != null && addressDto.AddressType != null) drpAddressType.Text = addressDto.AddressType.Id.ToString(); else drpAddressType.ClearSelection();
        if (addressDto != null && addressDto.PreferredAddress != null) drpPreferredAddress.Text = addressDto.PreferredAddress.ToString(); else drpPreferredAddress.ClearSelection();
    }
    private void populateAddressFromUI(AddressDTO addressDto)
    {
        addressDto.AddressLine1 = txtAddressLine1.Text;
        addressDto.AddressLine2 = txtAddressLine2.Text;
        addressDto.Town = txtTown.Text;
        addressDto.City = CommonUIConverter.getCityDTO(drpAddressCity.Text, drpAddressCity.SelectedItem.Text);
        addressDto.State = CommonUIConverter.getStateDTO(drpAddressState.Text, drpAddressState.SelectedItem.Text);
        addressDto.Country = CommonUIConverter.getCountryDTO(drpAddressCountry.Text, drpAddressCountry.SelectedItem.Text);
        addressDto.Pin = txtPin.Text;
        addressDto.AddressType = CommonUIConverter.getMasterControlDTO(drpAddressType.Text, drpAddressType.SelectedItem.Text);
        addressDto.PreferredAddress = EnumHelper.ToEnumNullable<PreferredAddress>(drpPreferredAddress.Text);
    }
    private AddressDTO populateAddressAdd()
    {
        AddressDTO addressDto = new AddressDTO();
        return addressDto;
    }
    private void setSelectedAddress(long UiIndex) {
        List<AddressDTO> addressList = getDBCustomerDTO().ContactInfo.Addresses.ToList<AddressDTO>();
        addressList.ForEach(c => c.isUISelected = false);
        if (UiIndex > 0) addressList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
    }
    private AddressDTO getSelectedAddress(long UiIndex)
    {
        List<AddressDTO> addressList = getDBCustomerDTO().ContactInfo.Addresses.ToList<AddressDTO>();
        return (UiIndex > 0) ? addressList.Find(c => c.UiIndex == UiIndex) : addressList.Find(c => c.isUISelected);
    }
    protected void onClickAddAddressBtn(object sender, EventArgs e)
    {
        try
        {
            addressModalActionHdnBtn.Value = AddressAction.ADD.ToString();
            initAddressModalFields();
            setSelectedAddress(-1);
            initAddressSectionFields(null);
            activeModalHdn.Value = addModifyAddressModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyAddressBtn(object sender, EventArgs e)
    {
        try
        {
            addressModalActionHdnBtn.Value = AddressAction.MODIFY.ToString();
            initAddressModalFields();
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedAddress(selectedIndex);
            initAddressSectionFields(getSelectedAddress(0));
            activeModalHdn.Value = addModifyAddressModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void deleteAddress(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            AddressDTO addressDTO = getSelectedAddress(selectedIndex);
            getDBCustomerDTO().ContactInfo.Addresses.Remove(addressDTO);
            populateAddressGrid(getDBCustomerDTO().ContactInfo);
            setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECORD_DELETE_SUCCESS, "Address")));
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void saveAddress(object sender, EventArgs e)
    {
        try
        {
            if (validateAddressAddModify())
            {
                AddressDTO addressDTO = null;
                string msg = "";
                if (AddressAction.ADD.ToString().Equals(addressModalActionHdnBtn.Value))
                {
                    addressDTO = populateAddressAdd();
                    getDBCustomerDTO().ContactInfo.Addresses.Add(addressDTO);
                    msg = string.Format(Resources.Messages.RECORD_ADDED_SUCCESS, "Address");
                }
                else
                {
                    addressDTO = getSelectedAddress(0);
                    msg = string.Format(Resources.Messages.RECORD_MODIFY_SUCCESS, "Address");
                }
                populateAddressFromUI(addressDTO);
                populateAddressGrid(getDBCustomerDTO().ContactInfo);
                setNotyMsg(CommonUtil.getNotySuccessMsg(msg));
            }
            else
            {
                activeModalHdn.Value = addModifyAddressModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelAddressModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateAddressAddModify()
    {
        bool isValid = true;
        Page.Validate(addModifyAddressError);
        isValid = Page.IsValid;
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    //Address Modal - End
}