﻿using Newtonsoft.Json;
using System;
using System.Web.Http;

namespace ConstroSoft.Controller
{
    public class ExotelInCallController : ApiController
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        CallHistoryBO callHistoryBO = new CallHistoryBO();

        [HttpGet]
        [ActionName("GetInCallDetails")]
        public string GetInCallDetails()
        {
            var response = JsonConvert.SerializeObject("Failure");
            try
            {
                string CallSid = HttpContext.Current.Request.Params["CallSid"];
                string From = HttpContext.Current.Request.Params["From"];
                string To = HttpContext.Current.Request.Params["To"];
                string Direction = HttpContext.Current.Request.Params["Direction"];
                string DialCallDuration = HttpContext.Current.Request.Params["DialCallDuration"];
                string StartTime = HttpContext.Current.Request.Params["StartTime"];
                string CurrentTime = HttpContext.Current.Request.Params["CurrentTime"];
                string EndTime = HttpContext.Current.Request.Params["EndTime"];
                string CallType = HttpContext.Current.Request.Params["CallType"];
                string digits = HttpContext.Current.Request.Params["digits"];
                string RecordingUrl = HttpContext.Current.Request.Params["RecordingUrl"];
                string CustomField = HttpContext.Current.Request.Params["CustomField"];
                string DialWhomNumber = HttpContext.Current.Request.Params["DialWhomNumber"];

                log.Error("ExotelOutCallController:" + CallSid);
                log.Error("ExotelOutCallController:" + From);
                log.Error("ExotelOutCallController:" + To);
                log.Error("ExotelOutCallController:" + RecordingUrl);
                //Validate the InOutBoundCallResDTO Mandatory Fields.
                if (!string.IsNullOrEmpty(CallSid))
                {
                    Call call = new Call();
                    call.Sid = CallSid;
                    call.Status = "inprogress";
                    call.From = From;
                    call.To = To;
                    call.Direction = Direction;
                    call.DialCallDuration = DialCallDuration;
                    call.StartTime = Convert.ToDateTime(StartTime);
                    call.CurrentTime = Convert.ToDateTime(CurrentTime);
                    call.EndTime = Convert.ToDateTime(EndTime);
                    call.CallType = CallType;
                    call.RecordingUrl = RecordingUrl;
                    call.digits = digits;
                    call.CustomField = CustomField;
                    call.DialWhomNumber = DialWhomNumber;
                    call.FirmNumber =Constants.EXOTEL.EXOTEL_FIRMNUMBER;
                    call.InsertUser = Constants.EXOTEL.EXOTEL_SID;
                    call.UpdateUser = Constants.EXOTEL.EXOTEL_SID;
                    callHistoryBO.addCallHistory(call);
                    response = JsonConvert.SerializeObject("Inbound Call Details Recieved Successfully.");
                }else{
                    log.Error("ExotelInCallController: CallSid is Missing");
                    response = JsonConvert.SerializeObject("CallSid is Missing");
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while getting inbound call details.");
                response = JsonConvert.SerializeObject("Unexpected error while getting inbound call details.");
                log.Error(exp.Message, exp);
            }
            finally
            {
            }
            return response;
        }
    }
}