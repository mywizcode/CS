﻿using System;
using System.Collections.Generic;

namespace ConstroSoft
{
    public static class NotificationUtil
    {
        //Logger Instance
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public static string getNotificationUserKey(string userName, long properyId)
        {
        	return userName + Constants.NOTIFICATIONS.KEY_SEPARATOR + properyId.ToString();
        }
        public static string getNotificationEntitlementKey(string entitlement, long properyId)
        {
        	return entitlement + Constants.NOTIFICATIONS.KEY_SEPARATOR + properyId.ToString();
        }
        public static string getCacheKey(string key)
        {
            string resultKey = key;
            if (key.StartsWith(Constants.Entitlement.MENU_LEAD_ASSIGNMENT)) resultKey = Constants.Entitlement.MENU_LEAD_ASSIGNMENT;
            return resultKey;
        }
        public static List<NotificationDTO> getQualifiedNotifications(string key, List<NotificationDTO> notificationList)
        {
            List<NotificationDTO> resultList = notificationList;
            if (notificationList != null)
            {
                /*
                 * Unassined leads are kept in memory with key as 'MENU_LEAD_ASSIGNMENT' but when they are fetched from memory then it is expected to retrieve them 
                 * for given property formed in key using method 'NotificationUtil.getNotificationEntitlementKey()'.
                 * */
                if (key.StartsWith(Constants.Entitlement.MENU_LEAD_ASSIGNMENT))
                {
                    string[] sep = {Constants.NOTIFICATIONS.KEY_SEPARATOR};
                    string[] tmpKeys = key.Split(sep, StringSplitOptions.None);
                    NotificationDTO tmpDTO = notificationList.Find(x => x.PropertyId == long.Parse(tmpKeys[1]));
                    resultList = new List<NotificationDTO>();
                    resultList.Add(tmpDTO);
                }
            }
            return resultList;
        }
        public static void addToNotificationDict(Dictionary<string, List<NotificationDTO>> dict, string key, NotificationDTO notificationDTO)
        {
            List<NotificationDTO> tmpValues = dict.ContainsKey(key) ? dict[key] : null;
            if (tmpValues == null)
            {
                tmpValues = new List<NotificationDTO>();
                dict.Add(key, tmpValues);
            }
            tmpValues.Add(notificationDTO);
        }
        public static string[] getAllKeysForNotification(UserDefinitionDTO userDTO)
        {
        	List<string> keys = new List<string>();
        	PropertyDTO propertyDto = CommonUtil.getCurrentPropertyDTO(userDTO);
        	if(propertyDto != null) {
                keys.Add(getNotificationUserKey(userDTO.Username, propertyDto.Id));
                if (CommonUtil.hasEntitlement(userDTO, Constants.Entitlement.MENU_LEAD_ASSIGNMENT))
                {
                    keys.Add(getNotificationEntitlementKey(Constants.Entitlement.MENU_LEAD_ASSIGNMENT, propertyDto.Id));
                }
        	}
        	return keys.ToArray();
        }
        public static Notification getAlertNotification(UserDefinitionDTO userDefDTO, string message, DateTime scheduledDate, NotificationSubType subType, 
            string refEntityInfo, string userNameToNotify)
        {
            Notification notification = createNotification(userDefDTO);
            notification.Type = NotificationType.ALERT;
            notification.SubType = subType;
            notification.PropertyId = CommonUtil.getCurrentPropertyDTO(userDefDTO).Id;
            notification.Message = message;
            notification.ScheduledDate = scheduledDate;
            notification.Status = NotificationStatus.OPEN;
            notification.UserName = userNameToNotify;
            notification.RefEntityInfo = refEntityInfo;
            return notification;
        }
        public static Notification createNotification(UserDefinitionDTO userDefDto)
        {
            Notification notification = new Notification();
            notification.FirmNumber = userDefDto.FirmNumber;
            notification.InsertUser = userDefDto.Username;
            notification.InsertDate = DateTime.Now;
            notification.UpdateUser = userDefDto.Username;
            notification.UpdateDate = DateTime.Now;
            return notification;
        }
        public static string createNotificationAlertMessage(NotificationSubType subType, params string[] parameters)
        {
            string message = "";
            if (subType == NotificationSubType.NEW_LEAD_ASSIGNED)
            {
                message = "New lead# {0} is assigned to you." + Constants.NOTIFICATIONS.MSG_SEPARATOR + Constants.NOTIFICATIONS.PARAM_LINK + parameters[0];
            }
            else if (subType == NotificationSubType.LEAD_REASSIGNED_SELF)
            {
                message = "Lead# {0} is reassgined to you." + Constants.NOTIFICATIONS.MSG_SEPARATOR + Constants.NOTIFICATIONS.PARAM_LINK + parameters[0];
            }
            else if (subType == NotificationSubType.LEAD_REASSIGNED_USER)
            {
                message = "Lead# {0} is reassgined to {1}." + Constants.NOTIFICATIONS.MSG_SEPARATOR + Constants.NOTIFICATIONS.PARAM_LINK + parameters[0]
                    + Constants.NOTIFICATIONS.PARAM_SEPARATOR + Constants.NOTIFICATIONS.PARAM_BOLD + parameters[1];
            }
            else if (subType == NotificationSubType.LEAD_CLOSED_USER)
            {
                message = "Your lead# {0} is closed by {1}." + Constants.NOTIFICATIONS.MSG_SEPARATOR + Constants.NOTIFICATIONS.PARAM_LINK + parameters[0]
                    + Constants.NOTIFICATIONS.PARAM_SEPARATOR + Constants.NOTIFICATIONS.PARAM_BOLD + parameters[1];
            }
            else if (subType == NotificationSubType.LEAD_ACTIVITY_LOGGED_BY_USER)
            {
                message = "New activity is logged in lead# {0} by {1}" + Constants.NOTIFICATIONS.MSG_SEPARATOR + Constants.NOTIFICATIONS.PARAM_LINK + parameters[0]
                    + Constants.NOTIFICATIONS.PARAM_SEPARATOR + Constants.NOTIFICATIONS.PARAM_BOLD + parameters[1];
            }
            else if (subType == NotificationSubType.ENQUIRY_REASSIGNED_SELF)
            {
                message = "Enquiry# {0} is reassgined to you." + Constants.NOTIFICATIONS.MSG_SEPARATOR + Constants.NOTIFICATIONS.PARAM_LINK + parameters[0];
            }
            else if (subType == NotificationSubType.ENQUIRY_REASSIGNED_USER)
            {
                message = "Enquiry# {0} is reassgined to {1}." + Constants.NOTIFICATIONS.MSG_SEPARATOR + Constants.NOTIFICATIONS.PARAM_LINK + parameters[0]
                    + Constants.NOTIFICATIONS.PARAM_SEPARATOR + Constants.NOTIFICATIONS.PARAM_BOLD + parameters[1];
            }
            else if (subType == NotificationSubType.ENQUIRY_CLOSED_USER)
            {
                message = "Your enquiry# {0} is closed by {1}." + Constants.NOTIFICATIONS.MSG_SEPARATOR + Constants.NOTIFICATIONS.PARAM_LINK + parameters[0]
                    + Constants.NOTIFICATIONS.PARAM_SEPARATOR + Constants.NOTIFICATIONS.PARAM_BOLD + parameters[1];
            }
            else if (subType == NotificationSubType.ENQUIRY_REOPEN_USER)
            {
                message = "Your enquiry# {0} is reopened by {1}." + Constants.NOTIFICATIONS.MSG_SEPARATOR + Constants.NOTIFICATIONS.PARAM_LINK + parameters[0]
                    + Constants.NOTIFICATIONS.PARAM_SEPARATOR + Constants.NOTIFICATIONS.PARAM_BOLD + parameters[1];
            }
            else if (subType == NotificationSubType.ENQUIRY_ACTIVITY_LOGGED_BY_USER)
            {
                message = "New activity is logged in enquiry# {0} by {1}" + Constants.NOTIFICATIONS.MSG_SEPARATOR + Constants.NOTIFICATIONS.PARAM_LINK + parameters[0]
                    + Constants.NOTIFICATIONS.PARAM_SEPARATOR + Constants.NOTIFICATIONS.PARAM_BOLD + parameters[1];
            }
            return message;
        }
        public static string createNotificationAlertRefEntityInfo(NotificationSubType subType, params string[] parameters)
        {
        	//NOTE: In case there are multiple params for entity info then concatinate all params with Constants.NOTIFICATIONS.PARAM_SEPARATOR
            string refInfo = "";
            int type = getNotificationAlertInfoType(subType);
            switch (type)
            {
                case 1:
                    {
                    	refInfo = parameters[0];
                        break;
                    }
                default:
                    {
                    	log.Error("ERROR: Incorrect Notification Alert Info Type. SubType:"+ subType +", Type:"+ type);
                        break;
                    }
            }
            return refInfo;
        }
        public static void populateNotificationAlertInfo(NotificationDTO notificationDTO)
        {
        	notificationDTO.UIUniqueKey = notificationDTO.Id.ToString();
        	//NOTE: In case there are multiple params for entity info then split them by Constants.NOTIFICATIONS.PARAM_SEPARATOR
            int type = getNotificationAlertInfoType(notificationDTO.SubType);
            switch (type)
            {
                case 1:
                    {
                    	notificationDTO.EntityRefId = long.Parse(notificationDTO.RefEntityInfo);
                        break;
                    }
                default:
                    {
                    	log.Error("ERROR: Incorrect Notification Alert Info Type. SubType:"+ notificationDTO.SubType +", Type:"+ type);
                        break;
                    }
            }
        }
        private static int getNotificationAlertInfoType(NotificationSubType subType)
        {
        	int type = 0;
            if (subType == NotificationSubType.NEW_LEAD_ASSIGNED || subType == NotificationSubType.LEAD_REASSIGNED_SELF
                || subType == NotificationSubType.LEAD_REASSIGNED_USER || subType == NotificationSubType.LEAD_CLOSED_USER
                || subType == NotificationSubType.ENQUIRY_REASSIGNED_SELF || subType == NotificationSubType.ENQUIRY_REASSIGNED_USER 
                || subType == NotificationSubType.ENQUIRY_CLOSED_USER || subType == NotificationSubType.ENQUIRY_REOPEN_USER
                || subType == NotificationSubType.LEAD_ACTIVITY_LOGGED_BY_USER || subType == NotificationSubType.ENQUIRY_ACTIVITY_LOGGED_BY_USER)
            {
            	type = 1;
            }
            return type;
        }
        public static NotificationDTO createEnquiryReminderNotification(UserDefinitionDTO userDefDTO, EnquiryActivity activity, string userNameToNotify)
        {
        	/*
        	 * Tasks notifications are not saved in DB so no need to set RefEntityInfo instead populate required fields like EntityRefId to be used in UI
        	 */
            NotificationDTO notification = new NotificationDTO();
            notification.Type = NotificationType.TASK;
            notification.SubType = NotificationSubType.ENQUIRY_REMINDER;
            notification.PropertyId = CommonUtil.getCurrentPropertyDTO(userDefDTO).Id;
            notification.Message = "Enquiry# {0}: Reminder scheduled on {1}" + Constants.NOTIFICATIONS.MSG_SEPARATOR + Constants.NOTIFICATIONS.PARAM_LINK + activity.EnquiryDetail.EnquiryRefNo
                    + Constants.NOTIFICATIONS.PARAM_SEPARATOR + Constants.NOTIFICATIONS.PARAM_BOLD + DateUtil.getCSDateTime(activity.ScheduledDate);
            notification.ScheduledDate = activity.ScheduledDate;
            notification.Status = NotificationStatus.OPEN;
            notification.UserName = userNameToNotify;
            notification.EntityRefId = activity.EnquiryDetail.Id;
            notification.UIUniqueKey = activity.RefNo;
            return notification;
        }
        public static NotificationDTO createLeadReminderNotification(UserDefinitionDTO userDefDTO, LeadActivity activity, string userNameToNotify)
        {
        	/*
        	 * Tasks notifications are not saved in DB so no need to set RefEntityInfo instead populate required fields like EntityRefId to be used in UI
        	 */
            NotificationDTO notification = new NotificationDTO();
            notification.Type = NotificationType.TASK;
            notification.SubType = NotificationSubType.LEAD_REMINDER;
            notification.PropertyId = CommonUtil.getCurrentPropertyDTO(userDefDTO).Id;
            notification.Message = "Lead# {0}: Reminder scheduled on {1}" + Constants.NOTIFICATIONS.MSG_SEPARATOR + Constants.NOTIFICATIONS.PARAM_LINK + activity.LeadDetail.LeadRefNo
                    + Constants.NOTIFICATIONS.PARAM_SEPARATOR + Constants.NOTIFICATIONS.PARAM_BOLD + DateUtil.getCSDateTime(activity.ScheduledDate);
            notification.ScheduledDate = activity.ScheduledDate;
            notification.Status = NotificationStatus.OPEN;
            notification.UserName = userNameToNotify;
            notification.EntityRefId = activity.LeadDetail.Id;
            notification.UIUniqueKey = activity.RefNo;
            return notification;
        }
        public static NotificationDTO createUnAssignedLeadsNotification(long PropertyId, int leadCount)
        {
            /*
             * Unassgined lead notification is raised one per property. So Unique key has property id.
             */
            NotificationDTO notification = new NotificationDTO();
            notification.Type = NotificationType.TASK;
            notification.SubType = NotificationSubType.UNASSIGNED_LEADS;
            notification.PropertyId = PropertyId;
            notification.Message = "New lead/s logged, Total unassigned leads are {0}. Please assign leads." + Constants.NOTIFICATIONS.MSG_SEPARATOR 
                + Constants.NOTIFICATIONS.PARAM_LINK + leadCount;
            notification.ScheduledDate = DateTime.Now;
            notification.Status = NotificationStatus.OPEN;
            notification.UIUniqueKey = NotificationSubType.UNASSIGNED_LEADS + "_" + PropertyId;
            return notification;
        }
    }
}