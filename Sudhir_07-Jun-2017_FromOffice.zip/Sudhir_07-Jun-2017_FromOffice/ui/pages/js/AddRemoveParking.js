﻿var sep1 = "~~";
var sep2 = "~";
function initParking() {
    var parkingDtls = $("[id$='parkingDetailsHdn']").val();
    //"P-101~Covered, 100Sq.Ft~~P-102~Open, 120Sq.Ft"
    $('div.parkingLabelDiv').html('');
    $('button.btnRemoveParking').removeClass('hidden');
    if (parkingDtls && parkingDtls != "") {
        var parkings = parkingDtls.split(sep1);
        $.each(parkings, function (index, value) {
            var recs = value.split(sep2);
            var $parkingLb = $('div.parkingLabelHdnDiv').clone();
            $parkingLb.removeClass('parkingLabelHdnDiv hidden');
            $parkingLb.find('div.pno').html(recs[0]);
            $parkingLb.find('div.pinfo').html("<span class=\"status-mark border-danger marginright5\"></span>" + recs[1]);
            $parkingLb.appendTo('div.parkingLabelDiv')
        });
    } else {
        $('div.parkingLabelDiv').html('Parking not Allocated.');
        $('button.btnRemoveParking').addClass('hidden');
    }
}
function editParking() {
    $("[id$='parkingAddDiv']").addClass('hidden');
    $("[id$='parkingEditDiv']").removeClass('hidden');
    $('.parkingRemoveBtn').removeClass('hidden');
}
function cancelEditParking() {
    $("[id$='parkingAddDiv']").removeClass('hidden');
    $("[id$='parkingEditDiv']").addClass('hidden');
    $('.parkingRemoveBtn').addClass('hidden');
}
function confirmRemoveParking(element) {
    var pNo = $(element).parent().find('div.pno').html();
    BootstrapDialog.confirm({
        title: "Remove Parking",
        message: "Do you want to remove parking '" + pNo + "'?",
        btnOKClass: 'btn btn-primary btn-sm',
        btnCancelClass: 'btn btn-primary btn-sm',
        closable: false,
        callback: function (result) {
            if (result) {
                var parkingDtls = $("[id$='parkingDetailsHdn']").val();
                if (parkingDtls && parkingDtls != "") {
                    var parkings = parkingDtls.split(sep1);
                    var newParkings = "";
                    $.each(parkings, function (index, value) {
                        var recs = value.split(sep2);
                        if (recs[0] != pNo) {
                            if (newParkings == "") newParkings = value;
                            else newParkings = newParkings + sep1 + value;
                        }
                    });
                    $("[id$='parkingDetailsHdn']").val(newParkings);
                    initParking();
                }
            }
        }
    });
    return false;
}
var prParkingDialogue;
function selectParking() {
    prParkingDialogue = new BootstrapDialog({
        title: "Select Parking",
        message: $('#modalPrParking').html(),
        nl2br: false,
        closable: false,
        buttons: [],
        onshown: function (dialogRef) {
            prParkingDialogue.getModalBody().find('.csdrplivemodal').selectpicker({
                dropupAuto: false,
                liveSearch: true,
                selectOnTab: true,
                noneSelectedText: "Nothing to Select"
            });
            prParkingDialogue.getModalBody().find('div.bootstrap-select').addClass("dropdown-100-percent");
            prParkingDialogue.getModalBody().find('div.bootstrap-select > button').addClass("btn-sm border-gray");
            prParkingDialogue.getModalBody().find('div.bs-searchbox > input').addClass("input-sm");
        }
    });
    prParkingDialogue.open();
}
function addNewParkingClient() {
    $("[id$=prParkingHdn]").val(prParkingDialogue.getModalBody().find('div.dropdown-menu').find('ul').find('li.selected').find('a span.text').text());
    $("[id$=btAddParkingModalId]").click();
}
function closeParkingDialogClient() {
    if (prParkingDialogue) {
        prParkingDialogue.close();
    }
}