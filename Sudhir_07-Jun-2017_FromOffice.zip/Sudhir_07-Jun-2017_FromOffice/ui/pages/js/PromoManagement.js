﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    $("input:radio, .styled").uniform({
        radioClass: 'choice'
    });
    formatFields();
    initRecipient();
    $('.modal-body li.dropdown.dropdown-inner a.dropdown-toggle').on('click', function (event) {
        $(this).parent().toggleClass('open');
    });
    $('.modal-body li.dropdown.dropdown-inner ul.dropdown-menu a').on('click', function (event) {
        $(this).parents('li.dropdown.dropdown-inner').removeClass('open');
    });
    $('.modal-body').on('click', function (e) {
        if (!$('li.dropdown.dropdown-inner').is(e.target)
            && $('li.dropdown.dropdown-inner').has(e.target).length === 0
            && $('.open').has(e.target).length === 0
        ) {
            $('li.dropdown.dropdown-inner').removeClass('open');
        }
    });
    initSummernote();

    $('table').removeAttr('rules');
    $('table').removeAttr('border');

    $('.modal-backdrop').remove();
    if ($("[id$='showRecipientModalHdnBtn']").val() == "true") {
        $('.addRecipients').click();
        $("[id$='showRecipientModalHdnBtn']").val('false');
    } else if ($("[id$='showSaveDraftModalHdnBtn']").val() == "true") {
        $('.saveDraftModal').click();
        $("[id$='showSaveDraftModalHdnBtn']").val('false');
    } else if ($("[id$='showSelectSavedDraftModalHdnBtn']").val() == "true") {
        $('.selectSavedDraftModal').click();
        $("[id$='showSelectSavedDraftModalHdnBtn']").val('false');
    }

    initSelectAllAndFilter();
    enableTab();
}
function initSummernote() {
    $('.summernote').on("summernote.blur", function () {
        $("[id$='txtEmailBody']").html(escape($('.summernote').summernote('code'))); 
    }).summernote({
        height: 300        
    });
    $('.summernote').summernote("code", unescape($("[id$='txtEmailBody']").text()));
    $(".note-modal-form input[type=checkbox], .note-modal-form input[type=radio]").uniform({
        radioClass: 'choice'
    });
    // Styled file input
    $(".note-image-input").uniform({
        wrapperClass: 'bg-blue',
        fileButtonHtml: '<i class="icon-googleplus5"></i>'
    });
}

var sep1 = "~~";
var sep2 = "~";
function initRecipient() {
    var recipientDtls = $("[id$='recipientDetailsHdn']").val();
    $("[id$='recipientToRemoveValHdn']").val('');
    $('div.recipientLabelDiv').html('');
    if (recipientDtls && recipientDtls != "") {
        var recipients = recipientDtls.split(sep1);
        $.each(recipients, function (index, value) {
            var recs = value.split(sep2);
            var $recipientLb = $('div.recipientLabelHdnDiv').clone();
            $recipientLb.removeClass('recipientLabelHdnDiv hidden');
            $recipientLb.find('span.rtext').html("<span class=\"badge badge-flat border-success text-success-600\">" + recs[0] + "</span> Recipients");
            $recipientLb.find('input.rid').val(recs[1]);
            $recipientLb.appendTo('div.recipientLabelDiv')
        });
    } else {
        $('div.recipientLabelDiv').html('');
    }
}
function confirmRemoveRecipient(element) {
    var rId = $(element).parent().find('input.rid').val();
    BootstrapDialog.confirm({
        title: "Remove Recipient",
        message: "Do you want to remove Recipients?",
        btnOKClass: 'btn btn-primary btn-sm',
        btnCancelClass: 'btn btn-primary btn-sm',
        closable: false,
        callback: function (result) {
            if (result) {
                $("[id$='recipientToRemoveValHdn']").val(rId);
                $("[id$='recipientToRemoveHdn']").click();
            }
        }
    });
    return false;
}

function selectAllCustomers(ch) {
    var isChecked = false;
    if (ch.checked) {
        isChecked = true;
    }
    $("[id$='customerGrid']").find('tbody tr').each(function () {
        $this = $(this);
        $this.find('.selectCustomer').prop("checked", isChecked);
        $this.find('.selectCustomer').parent().removeClass('checked');
        if (isChecked) $this.find('.selectCustomer').parent().addClass('checked');
    });
}

function initSelectAllAndFilter() {
    //Hide/Show Select All checkbox in modal
    var rowCount = $("[id$='customerGrid']").find('tbody tr').length;
    $('.selectAllLi').removeClass('hidden');
    if (rowCount < 1) {
        $('.selectAllLi').addClass('hidden');
    }
    $('.propFilter').removeClass('hidden');
    if ($('.propFilter').children('ul.dropdown-menu').length < 1) {
        $('.propFilter').addClass('hidden');
    }
    $('.towerFilter').removeClass('hidden');
    if ($('.towerFilter').children('ul.dropdown-menu').length < 1) {
        $('.towerFilter').addClass('hidden');
    }
    //Set text color of selected filter
    if ($('.propFilter ul.dropdown-menu').children('li.selected').length > 0) {
        $('.propFilter a.dropdown-toggle').addClass('text-success');
    }
    if ($('.towerFilter ul.dropdown-menu').children('li.selected').length > 0) {
        $('.towerFilter a.dropdown-toggle').addClass('text-success');
    }
}

function uploadAttachment() {
    $("[id$='btnUploadAttachment']").click();
}

function confirmRemoveAttachment(element) {
    var rId = $(element).parent().find('input.aid').val();
    BootstrapDialog.confirm({
        title: "Remove Attachment",
        message: "Do you want to remove Attached file?",
        btnOKClass: 'btn btn-primary btn-sm',
        btnCancelClass: 'btn btn-primary btn-sm',
        closable: false,
        callback: function (result) {
            if (result) {
                $("[id$='attachmentToRemoveValHdn']").val(rId);
                $("[id$='btnRemoveAttachment']").click();
            }
        }
    });
    return false;
}