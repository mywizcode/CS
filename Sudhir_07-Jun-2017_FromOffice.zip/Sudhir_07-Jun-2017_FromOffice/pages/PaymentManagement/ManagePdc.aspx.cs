﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;

public partial class ManagePdc : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string tab1ValidationGrp = "tab1Error";
    string tab2ValidationGrp = "tab2Error";
    string tab2Error1 = "tab2Error1";
    string tab2Error2 = "tab2Error2";
    string VS_SEARCH_GRIDDATA = "VS_SEARCH_GRIDDATA";
    string VS_SELECTED_PDC = "VS_SELECTED_PDC";
    enum PdcPageMode { VIEW, ADD, MODIFY, NONE }
    PaymentBO paymentBO = new PaymentBO();
    DropdownBO drpBO = new DropdownBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                resetTabInfo(PdcPageMode.NONE);
                initDropdowns();
                Page.MaintainScrollPositionOnPostBack = false;
                if (Session[Constants.Session.FROM_DASHBOARD] != null)
                {
                    PostDatedChequeDTO pdcDto = (PostDatedChequeDTO)Session[Constants.Session.FROM_DASHBOARD_PDC];
                    Session.Remove(Constants.Session.FROM_DASHBOARD_PDC);
                    Session.Remove(Constants.Session.FROM_DASHBOARD);
                    initPageAfterRedirect(pdcDto);
                }
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpEnum<PaymentFromSearchBy>(drpSelectPymtFrom, null);
        drpBO.drpEnum<PdcChequeStatus>(drpChequeStatus, Constants.SELECT_ITEM);
        drpBO.drpEnum<PdcSearchBy>(drpSearchBy, null);
        drpBO.populateDrpPymtToSearchBy(drpSelectPymtTo, PaymentFromSearchBy.NONE);
        drpBO.drpDataBase(drpSelectProperty, DrpDataType.PROPERTY_NAME, userDefDto.Id.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpInit(drpSelectPropertyTower, Constants.SELECT_ITEM);
        drpBO.drpDataBase(drpFirmAccount, DrpDataType.FIRM_ACCOUNT, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        addPdcBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PDC_ADD);
        modifyPdcBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PDC_MODIFY);
        deletePdcBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PDC_DELETE);
    }
    private void preRenderInitFormElements()
    {
        jumpToPdcPaymentHdnId.Value = "";
        PostDatedChequeSearchDTO selectedSearchPdcDto = getSelectedPdcFromList();
        if (selectedSearchPdcDto != null) jumpToPdcHdnId.Value = selectedSearchPdcDto.Id.ToString();
        PostDatedChequeDTO currentPdcDto = getCurrentPdc();
        if (currentPdcDto != null)
        {
            PdcPymtDTO selectedPdcPymtDto = currentPdcDto.PdcUiPymts.Find(x => x.isUISelected);
            if (selectedPdcPymtDto != null) jumpToPdcPaymentHdnId.Value = selectedPdcPymtDto.PymtMasterId.ToString();
        }
        if (PdcPageMode.VIEW.ToString() == pageModeHdn.Value) populateUiFieldsFromPDCDto(getCurrentPdc());
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }

    public void setSuccessMessage(string msg, string tabId)
    {
        activeTabHdn.Value = tabId;
        if (tabId.Equals(tab1Anchor.ID))
        {
            lbTab1Success.Text = msg;
            tab1SuccessPanel.Visible = true;
        }
        if (tabId.Equals(tab2Anchor.ID))
        {
            lbTab2Success.Text = msg;
            tab2SuccessPanel.Visible = true;
        }
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private void clearMessages()
    {
        tab1SuccessPanel.Visible = false;
        lbTab1Success.Text = "";
        tab2SuccessPanel.Visible = false;
        lbTab2Success.Text = "";
        
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }

    private void resetTabInfo(PdcPageMode pageMode)
    {
    	tab2Anchor.Visible = false;
    	activeTabHdn.Value = tab1Anchor.ID;
        pageModeHdn.Value = pageMode.ToString();
        initFormFields();
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        ViewState[VS_SELECTED_PDC] = null;
        pnlChqAndPymtDetails.Visible = false;
        if (PdcPageMode.ADD == pageMode || PdcPageMode.MODIFY == pageMode || PdcPageMode.VIEW == pageMode)
        {
            tab2Anchor.Visible = true;
            activeTabHdn.Value = tab2Anchor.ID;
            initFormFields();
            initTab2(pageMode);
        }
        else
        {
            
            tab2Anchor.Visible = false;
        }
    }
    private void initFormFields()
    {
        bool visible = !(PdcPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
        //Buttons
        pdcTransBtnGrp.Visible = visible;
        pdcPymtGrid.Columns[0].Visible = visible;
        pdcAgencyPymtGrid.Columns[0].Visible = visible;

        drpChqDrawer.ClearSelection();
        drpChqPayee.ClearSelection();
    }
    private void initTab2(PdcPageMode pageAction)
    {
        btnAddSubmit.Visible = false;
        btnUpdateSubmit.Visible = false;
        if (PdcPageMode.ADD == pageAction)
        {
            btnAddSubmit.Visible = true;
            tab2Anchor.Text = Resources.Labels.pymt_sm_pdc_tab2_name_add;
        }
        else if (PdcPageMode.MODIFY == pageAction)
        {
            btnUpdateSubmit.Visible = true;
            pnlChqAndPymtDetails.Visible = true;
            tab2Anchor.Text = Resources.Labels.pymt_sm_pdc_tab2_name_modify;
        }else if (PdcPageMode.VIEW == pageAction)
        {
            pnlChqAndPymtDetails.Visible = true;
            tab2Anchor.Text = Resources.Labels.pymt_sm_pdc_tab2_name_view;
        }
    }
    private List<PostDatedChequeSearchDTO> getPdcGridList()
    {
        return (List<PostDatedChequeSearchDTO>)ViewState[VS_SEARCH_GRIDDATA];
    }
    private PostDatedChequeSearchDTO getSelectedPdcFromList()
    {
        return  (getPdcGridList() != null) ? getPdcGridList().Find(c => c.isUISelected) : null;
    }
    private PostDatedChequeDTO getCurrentPdc()
    {
        return (PostDatedChequeDTO)ViewState[VS_SELECTED_PDC];
    }
    private void fetchAllPostDatedCheques(long id)
    {
        pnlChqSearchGrid.Visible = false;
        pymtDirectionHdn.Value = "";
        if (isValidPymtSearchSelection())
        {
            pnlChqSearchGrid.Visible = true;
            pdcGrid.Visible = false;
            string pymtDirection = getPaymentDirection();
            pymtDirectionHdn.Value = pymtDirection;
            long propertyId = long.Parse(drpSelectProperty.Text);
            long propertyTowerId = long.Parse(drpSelectPropertyTower.Text);
            PdcSearchBy searchBy = EnumHelper.ToEnum<PdcSearchBy>(drpSearchBy.Text);
            if (Constants.PYMT_DIRECTION.CUSTOMER_FIRM.Equals(pymtDirection))
            {
                IList<PostDatedChequeSearchDTO> result = paymentBO.fetchPdcFromCustomerToFirm(getUserDefinitionDTO().FirmNumber, propertyTowerId, searchBy, drpSearchByValue.Text);
                pdcGrid.Visible = true;
                ViewState[VS_SEARCH_GRIDDATA] = result;
                pdcGrid.DataSource = result;
                pdcGrid.DataBind();
                if (id > 0) selectPdcSearchGridRdBtn(id);
                drpBO.drpDataBase(drpChqDrawer, DrpDataType.PDC_CUSTOMER, propertyTowerId.ToString(), Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
                drpBO.drpDataBase(drpChqPayee, DrpDataType.PDC_FIRM, null, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            }else if (Constants.PYMT_DIRECTION.FIRM_CUSTOMER.Equals(pymtDirection))
            {
                IList<PostDatedChequeSearchDTO> result = paymentBO.fetchPdcFromFirmToCustomer(getUserDefinitionDTO().FirmNumber, propertyTowerId, searchBy, drpSearchByValue.Text);
                pdcGrid.Visible = true;
                ViewState[VS_SEARCH_GRIDDATA] = result;
                pdcGrid.DataSource = result;
                pdcGrid.DataBind();
                if (id > 0) selectPdcSearchGridRdBtn(id);
                drpBO.drpDataBase(drpChqDrawer, DrpDataType.PDC_FIRM, null, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
                drpBO.drpDataBase(drpChqPayee, DrpDataType.PDC_CUSTOMER, propertyTowerId.ToString(), Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            }
            else if (Constants.PYMT_DIRECTION.FIRM_CONTRACTOR.Equals(pymtDirection))
            {
            }
            else if (Constants.PYMT_DIRECTION.FIRM_SUPPLIER.Equals(pymtDirection))
            {
            }
            else if (Constants.PYMT_DIRECTION.FIRM_AGENCY.Equals(pymtDirection))
            {
                IList<PostDatedChequeSearchDTO> result = paymentBO.fetchPdcFromFirmToAgency(getUserDefinitionDTO().FirmNumber, propertyId, searchBy, drpSearchByValue.Text);
                pdcGrid.Visible = true;
                ViewState[VS_SEARCH_GRIDDATA] = result;
                pdcGrid.DataSource = result;
                pdcGrid.DataBind();
                if (id > 0) selectPdcSearchGridRdBtn(id);
                drpBO.drpDataBase(drpChqDrawer, DrpDataType.PDC_FIRM, null, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
                drpBO.drpDataBase(drpChqPayee, DrpDataType.PDC_AGENCY, propertyTowerId.ToString(), Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            }
        }
    }
    private bool isValidPymtSearchSelection()
    {
        bool isValid = true;
        PaymentFromSearchBy pymtFromSearchBy = EnumHelper.ToEnum<PaymentFromSearchBy>(drpSelectPymtFrom.Text);
        PaymentToSearchBy pymtToSearchBy = EnumHelper.ToEnum<PaymentToSearchBy>(drpSelectPymtTo.Text);
        if (string.IsNullOrWhiteSpace(drpSelectProperty.Text) || string.IsNullOrWhiteSpace(drpSelectPropertyTower.Text)
            || PaymentFromSearchBy.NONE == pymtFromSearchBy || PaymentToSearchBy.NONE == pymtToSearchBy)
        {
            isValid = false;
        }
        return isValid;
    }
    private string getPaymentDirection()
    {
        string pymtDirection = Constants.PYMT_DIRECTION.INVALID_PYMT_DIRECTION;
        PaymentFromSearchBy pymtFromSearchBy = EnumHelper.ToEnum<PaymentFromSearchBy>(drpSelectPymtFrom.Text);
        PaymentToSearchBy pymtToSearchBy = EnumHelper.ToEnum<PaymentToSearchBy>(drpSelectPymtTo.Text);
        if (PaymentFromSearchBy.FIRM == pymtFromSearchBy && PaymentToSearchBy.CUSTOMER == pymtToSearchBy) pymtDirection = Constants.PYMT_DIRECTION.FIRM_CUSTOMER;
        else if (PaymentFromSearchBy.FIRM == pymtFromSearchBy && PaymentToSearchBy.CONTRACTOR == pymtToSearchBy) pymtDirection = Constants.PYMT_DIRECTION.FIRM_CONTRACTOR;
        else if (PaymentFromSearchBy.FIRM == pymtFromSearchBy && PaymentToSearchBy.SUPPLIER == pymtToSearchBy) pymtDirection = Constants.PYMT_DIRECTION.FIRM_SUPPLIER;
        else if (PaymentFromSearchBy.FIRM == pymtFromSearchBy && PaymentToSearchBy.AGENCY == pymtToSearchBy) pymtDirection = Constants.PYMT_DIRECTION.FIRM_AGENCY;
        else if (PaymentFromSearchBy.CUSTOMER == pymtFromSearchBy && PaymentToSearchBy.FIRM == pymtToSearchBy) pymtDirection = Constants.PYMT_DIRECTION.CUSTOMER_FIRM;
        return pymtDirection;
    }
    private void initPageAfterRedirect(PostDatedChequeDTO pdcDto)
    {
        try
        {
            resetTabInfo(PdcPageMode.NONE);
            drpSelectPymtFrom.Text = pdcDto.PymtFrom.ToString();
            drpBO.populateDrpPymtToSearchBy(drpSelectPymtTo, pdcDto.PymtFrom);
            drpSelectPymtTo.Text = pdcDto.PymtTo.ToString();
            drpSelectProperty.Text = pdcDto.Property.Id.ToString();
            drpBO.drpDataBase(drpSelectPropertyTower, DrpDataType.PROPERTY_TOWER, drpSelectProperty.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            drpSelectPropertyTower.Text = pdcDto.PrTower.Id.ToString();
            fetchAllPostDatedCheques(0);
            drpSearchBy.Text = PdcSearchBy.CHQ_NO.ToString();
            loadSearchBySelection(false);
            drpSearchByValue.Text = pdcDto.ChequeNo;
            fetchAllPostDatedCheques(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSearchBy(object sender, EventArgs e)
    {
        try
        {
            loadSearchBySelection(true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private void loadSearchBySelection(bool fetchPdc)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        PdcSearchBy searchBy = EnumHelper.ToEnum<PdcSearchBy>(drpSearchBy.Text);
        initSearchByValue(true);
        lbSearchByValue.Text = EnumHelper.GetEnumDescription<PdcSearchBy>(searchBy.ToString());
        List<object[]> values = getSearchByValues(searchBy);
        if (values != null && values.Count > 0)
        {
            foreach (object[] value in values)
            {
                drpSearchByValue.Items.Add(new ListItem(value[0].ToString(), value[1].ToString()));
            }
        }
        else
        {
            initSearchByValue(false);
        }

        if (fetchPdc) fetchAllPostDatedCheques(0);
        resetTabInfo(PdcPageMode.NONE);
    }
    private List<object[]> getSearchByValues(PdcSearchBy searchBy)
    {
        List<object[]> values = new List<object[]>();
        List<PostDatedChequeSearchDTO> pdcSearchDtoList = getPdcGridList();
        if (pdcSearchDtoList != null && pdcSearchDtoList.Count > 0)
        {
            if (PdcSearchBy.CHQ_DRAWER == searchBy)
            {
                IList<PostDatedChequeSearchDTO> tmpList = pdcSearchDtoList.GroupBy(x => x.ChqDrawerName).Select(g => g.First()).ToList();
                foreach (PostDatedChequeSearchDTO pdcSearchDto in tmpList)
                {
                    values.Add(new object[] { pdcSearchDto.ChqDrawerName, pdcSearchDto.ChqDrawerId.ToString() });
                }
            }
            else if (PdcSearchBy.CHQ_PAYEE == searchBy)
            {
                IList<PostDatedChequeSearchDTO> tmpList = pdcSearchDtoList.GroupBy(x => x.ChqPayeeName).Select(g => g.First()).ToList();
                foreach (PostDatedChequeSearchDTO pdcSearchDto in tmpList)
                {
                    values.Add(new object[] { pdcSearchDto.ChqPayeeName, pdcSearchDto.ChqPayeeId.ToString() });
                }
            }
            else if (PdcSearchBy.CHQ_NO == searchBy)
            {
                IList<PostDatedChequeSearchDTO> tmpList = pdcSearchDtoList.GroupBy(x => x.ChequeNo).Select(g => g.First()).ToList();
                foreach (PostDatedChequeSearchDTO pdcSearchDto in tmpList)
                {
                    values.Add(new object[] { pdcSearchDto.ChequeNo, pdcSearchDto.ChequeNo });
                }
            }
            else if (PdcSearchBy.CHQ_STATUS == searchBy)
            {
                IList<PostDatedChequeSearchDTO> tmpList = pdcSearchDtoList.GroupBy(x => x.ChequeStatus).Select(g => g.First()).ToList();
                foreach (PostDatedChequeSearchDTO pdcSearchDto in tmpList)
                {
                    values.Add(new object[] { pdcSearchDto.ChequeStatus, pdcSearchDto.ChequeStatus });
                }
            }
        }
        return values;
    }
    private void initSearchByValue(bool isVisible)
    {
        drpBO.drpInit(drpSearchByValue, Constants.SELECT_ITEM);
        drpSearchByValue.Visible = isVisible;
        lbSearchByValue.Visible = isVisible;
    }
    protected void onSearchByValue(object sender, EventArgs e)
    {
        resetTabInfo(PdcPageMode.NONE);
        fetchAllPostDatedCheques(0);
    }
    protected void onSelectPymtFrom(object sender, EventArgs e)
    {
        try
        {
            resetTabInfo(PdcPageMode.NONE);
            PaymentFromSearchBy pymtFromSearchBy = EnumHelper.ToEnum<PaymentFromSearchBy>(drpSelectPymtFrom.Text);
            drpBO.populateDrpPymtToSearchBy(drpSelectPymtTo, pymtFromSearchBy);
            fetchAllPostDatedCheques(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSelectPymtTo(object sender, EventArgs e)
    {
        try
        {
            resetTabInfo(PdcPageMode.NONE);
            fetchAllPostDatedCheques(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSelectProperty(object sender, EventArgs e)
    {
        try
        {
            resetTabInfo(PdcPageMode.NONE);
            drpBO.drpDataBase(drpSelectPropertyTower, DrpDataType.PROPERTY_TOWER, drpSelectProperty.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            if (drpSelectPropertyTower.Items.Count == 2)
            {
                drpSelectPropertyTower.Items[1].Selected = true;
            }
            fetchAllPostDatedCheques(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSelectPropertyTower(object sender, EventArgs e)
    {
        try
        {
            resetTabInfo(PdcPageMode.NONE);
            fetchAllPostDatedCheques(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    
    private void selectPdcSearchGridRdBtn(long Id)
    {
        if (pdcGrid.Rows.Count > 0)
        {
            setSelectedPdc(0);
            foreach (GridViewRow row in pdcGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdPdcSelect");
                Button rowIdenBtn = (Button)row.FindControl("btnPdcRowIdentifier");
                if (radioBtn != null)
                {
                    radioBtn.Checked = false;
                    if (rowIdenBtn != null && Id > 0 && Id.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                    {
                        radioBtn.Checked = true;
                        setSelectedPdc(Id);
                    }
                }
            }
        }
    }
    private void setSelectedPdc(long selectedId)
    {
        List<PostDatedChequeSearchDTO> pdcDtoList = getPdcGridList();
        if (pdcDtoList != null)
        {
            pdcDtoList.ForEach(c => c.isUISelected = false);
            if (selectedId > 0) pdcDtoList.Find(c => c.Id == selectedId).isUISelected = true;
        }
    }
    protected void onSelectPostDatedCheque(object sender, EventArgs e)
    {
        try
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            resetTabInfo(PdcPageMode.NONE);
            if (rd.Checked)
            {
                string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnPdcRowIdentifier"))).Attributes["row-identifier"];
                setSelectedPdc(long.Parse(strId));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private bool validatePdcSelected()
    {
        bool isSelected = true;
        if (getSelectedPdcFromList() == null)
        {
            isSelected = false;
            resetTabInfo(PdcPageMode.NONE);
            setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Post Dated Cheque"), tab1ValidationGrp);
        }
        return isSelected;
    }
    private bool validateModifyChequeStatus()
    {
        bool isValid = true;
        PostDatedChequeSearchDTO pdcSearchDto = getSelectedPdcFromList();
        if (PdcChequeStatus.Cleared == pdcSearchDto.ChequeStatus || PdcChequeStatus.Bounced == pdcSearchDto.ChequeStatus)
        {
            setErrorMessage(string.Format("{0} checks cannot be modified.", pdcSearchDto.ChequeStatus.ToString()), tab1ValidationGrp);
            isValid = false;
        }
        return isValid;
    }
    private void fetchSelectedPdc(PdcPageMode pageMode)
    {
        try
        {
            pdcPymtGrid.Visible = false;
            pdcAgencyPymtGrid.Visible = false;
            string pymtDirection = getPaymentDirection();
            if (Constants.PYMT_DIRECTION.CUSTOMER_FIRM.Equals(pymtDirection) || Constants.PYMT_DIRECTION.FIRM_CUSTOMER.Equals(pymtDirection))
            {
                PostDatedChequeDTO pdcDto = null;
                long customerId = 0;
                PRUnitSalePymtTo pymtTo = Constants.PYMT_DIRECTION.CUSTOMER_FIRM.Equals(pymtDirection) ? PRUnitSalePymtTo.Builder : PRUnitSalePymtTo.Customer;
                if (PdcPageMode.ADD == pageMode)
                {
                    pdcDto = populatePdcDTOForAdd();
                    customerId = (Constants.PYMT_DIRECTION.CUSTOMER_FIRM.Equals(pymtDirection)) ? long.Parse(drpChqDrawer.Text) : long.Parse(drpChqPayee.Text); 
                }
                else
                {
                    PostDatedChequeSearchDTO pdcSearchDto = getSelectedPdcFromList();
                    customerId = (Constants.PYMT_DIRECTION.CUSTOMER_FIRM.Equals(pymtDirection)) ? pdcSearchDto.ChqDrawerId : pdcSearchDto.ChqPayeeId;
                    pdcDto = paymentBO.fetchPostDatedChequeDetails(pdcSearchDto.Id);
                }
                long propertyTowerId = long.Parse(drpSelectPropertyTower.Text);
                IList<PdcPymtDTO> salePayments = paymentBO.fetchPdcPymtFromCustomerToFromFirm(getUserDefinitionDTO().FirmNumber, propertyTowerId, customerId, pymtTo);
                salePayments.ToList().ForEach(x => x.PymtFor = CommonUIConverter.getPropertyUnitFormattedNo(x.Wing, x.UnitNo));
                populatePdcPymts(pdcDto, salePayments, pageMode);
                ViewState[VS_SELECTED_PDC] = pdcDto;
            }
            else if (Constants.PYMT_DIRECTION.FIRM_CONTRACTOR.Equals(pymtDirection))
            {
            }
            else if (Constants.PYMT_DIRECTION.FIRM_SUPPLIER.Equals(pymtDirection))
            {
            }
            else if (Constants.PYMT_DIRECTION.FIRM_AGENCY.Equals(pymtDirection))
            {
                PostDatedChequeDTO pdcDto = null;
                long agencyId = 0;
                if (PdcPageMode.ADD == pageMode)
                {
                    pdcDto = populatePdcDTOForAdd();
                    agencyId = long.Parse(drpChqPayee.Text);
                }
                else
                {
                    PostDatedChequeSearchDTO pdcSearchDto = getSelectedPdcFromList();
                    agencyId = pdcSearchDto.ChqPayeeId;
                    pdcDto = paymentBO.fetchPostDatedChequeDetails(pdcSearchDto.Id);
                }
                long propertyId = long.Parse(drpSelectProperty.Text);
                IList<PdcPymtDTO> salePayments = paymentBO.fetchPdcPymtFromFirmToAgency(getUserDefinitionDTO().FirmNumber, propertyId, agencyId);
                populatePdcPymts(pdcDto, salePayments, pageMode);
                ViewState[VS_SELECTED_PDC] = pdcDto;
            }
            populateUiFieldsFromPDCDto(getCurrentPdc());
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private PostDatedChequeDTO populatePdcDTOForAdd()
    {
        PostDatedChequeDTO postDatedChequeDto = new PostDatedChequeDTO();
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        postDatedChequeDto.CollectionDate = DateTime.Today;
        postDatedChequeDto.PymtFrom = EnumHelper.ToEnum<PaymentFromSearchBy>(drpSelectPymtFrom.Text);
        postDatedChequeDto.PymtTo = EnumHelper.ToEnum<PaymentToSearchBy>(drpSelectPymtTo.Text);
        if (postDatedChequeDto.PymtFrom == PaymentFromSearchBy.FIRM)
            postDatedChequeDto.Name = drpChqPayee.SelectedItem.Text;
        else
            postDatedChequeDto.Name = drpChqDrawer.SelectedItem.Text;
        postDatedChequeDto.PymtStatus = PdcPymtStatus.Pending;
        postDatedChequeDto.Property = CommonUIConverter.getPropertyDTO(drpSelectProperty.Text, null);
        postDatedChequeDto.PrTower = CommonUIConverter.getPropertyTowerDTO(drpSelectPropertyTower.Text, null);
        postDatedChequeDto.PaymentTransactions = new HashSet<PaymentTransactionDTO>();
        postDatedChequeDto.PdcUiPymts = new List<PdcPymtDTO>();
        
        postDatedChequeDto.FirmNumber = userDefDto.FirmNumber;
        postDatedChequeDto.InsertUser = userDefDto.Username;
        postDatedChequeDto.UpdateUser = userDefDto.Username;

        return postDatedChequeDto;
    }
    private void populatePdcPymts(PostDatedChequeDTO postDatedChequeDto, IList<PdcPymtDTO> pdcPymtDtos, PdcPageMode pageMode)
    {
        postDatedChequeDto.PdcUiPymts = new List<PdcPymtDTO>();
        if (postDatedChequeDto.PaymentTransactions != null)
        {
            foreach (PaymentTransactionDTO transDto in postDatedChequeDto.PaymentTransactions)
            {
                if (transDto.Status != PymtTransStatus.Reversal)
                {
                    PdcPymtDTO tmpDto = pdcPymtDtos.ToList<PdcPymtDTO>().Find(x => x.PymtMasterId == transDto.PaymentMaster.Id);
                    if (tmpDto != null)
                    {
                        tmpDto.PaymentTransaction = transDto;
                        postDatedChequeDto.PdcUiPymts.Add(tmpDto);
                    }
                }
            }
        }
        List<PdcPymtDTO> tmpPdcPymtList = new List<PdcPymtDTO>();
        /*
         * Payments which are pending/Paid (PymtMasterStatus.Pending/Paid) will be shown on UI if no Pdc payment was added for that payment. Also note that below payments will be shown
         * on UI only if Check status is Collected.
         */
        if(PdcPageMode.VIEW != pageMode && postDatedChequeDto.ChequeStatus == PdcChequeStatus.Collected) {
            foreach (PdcPymtDTO pdcPymtDto in pdcPymtDtos)
            {
                bool isExist = postDatedChequeDto.PdcUiPymts.Any(x => x.PymtMasterId == pdcPymtDto.PymtMasterId);
                if (!isExist && (pdcPymtDto.PymtMstStatus == PymtMasterStatus.Pending || pdcPymtDto.PymtMstStatus == PymtMasterStatus.Paid))
                {
                    PaymentTransactionDTO pymtTransDto = createNewPaymentTransaction(postDatedChequeDto, null, pdcPymtDto);
                    pymtTransDto.PaymentMaster = new PaymentMasterDTO();
                    pymtTransDto.PaymentMaster.Id = pdcPymtDto.PymtMasterId;
                    pdcPymtDto.PaymentTransaction = pymtTransDto;
                    tmpPdcPymtList.Add(pdcPymtDto);
                }
            }
        }
        postDatedChequeDto.PdcUiPymts.AddRange(tmpPdcPymtList);
    }

    private PaymentTransactionDTO createNewPaymentTransaction(PostDatedChequeDTO postDatedChequeDto, PaymentTransactionDTO deletedPymtTransDto, PdcPymtDTO pdcPymtDto)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        PaymentTransactionDTO pymtTransDto = new PaymentTransactionDTO();
        pymtTransDto.Amount = (deletedPymtTransDto != null) ? deletedPymtTransDto.Amount : Decimal.Zero;
        pymtTransDto.PymtMode = PaymentMode.CHEQUE;
        pymtTransDto.Status = (deletedPymtTransDto != null) ? PymtTransStatus.Reversal : PymtTransStatus.Pending;
        copyPymtTransFields(pymtTransDto, postDatedChequeDto, deletedPymtTransDto, pdcPymtDto);
        pymtTransDto.FirmNumber = userDefDto.FirmNumber;
        pymtTransDto.InsertUser = userDefDto.Username;
        pymtTransDto.UpdateUser = userDefDto.Username;
        return pymtTransDto;
    }
    private void copyPymtTransFields(PaymentTransactionDTO pymtTransDto, PostDatedChequeDTO postDatedChequeDto, PaymentTransactionDTO deletedPymtTransDto, PdcPymtDTO pdcPymtDto)
    {
        pymtTransDto.TxDate = ((postDatedChequeDto.ClearanceDate == null && pymtTransDto.TxDate != null) || pymtTransDto.Status == PymtTransStatus.Reversal) 
                ? DateTime.Today : postDatedChequeDto.ClearanceDate.Value;
        pymtTransDto.BankName = postDatedChequeDto.BankName;
        pymtTransDto.Branch = postDatedChequeDto.Branch;
        pymtTransDto.ChequeNo = postDatedChequeDto.ChequeNo;
        pymtTransDto.ChequeDate = postDatedChequeDto.ChequeDate;
        if(pymtTransDto.Status == PymtTransStatus.Reversal) {
            createAccountTransaction(pymtTransDto, postDatedChequeDto, deletedPymtTransDto, pdcPymtDto);
        } else {
            pymtTransDto.Status = (postDatedChequeDto.ChequeStatus == PdcChequeStatus.Cleared) ? PymtTransStatus.Paid : PymtTransStatus.Pending;
            if (PymtTransStatus.Paid == pymtTransDto.Status && pymtTransDto.AccountTransaction == null) 
                createAccountTransaction(pymtTransDto, postDatedChequeDto, null, pdcPymtDto);
        }
        
    }
    private void createAccountTransaction(PaymentTransactionDTO pymtTransDto, PostDatedChequeDTO postDatedChequeDto, PaymentTransactionDTO deletedPymtTransDto,
        PdcPymtDTO pdcPymtDto)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        AccountTransactionDTO acntTransDto = new AccountTransactionDTO();
        acntTransDto.FirmAccount = postDatedChequeDto.FirmAccount;
        string pymtDirection = getPaymentDirection();
        if (pymtTransDto.Status == PymtTransStatus.Reversal)
        {
            acntTransDto.TxType = (deletedPymtTransDto.AccountTransaction.TxType == AcntTransStatus.Credit) ? AcntTransStatus.Debit : AcntTransStatus.Credit;
            acntTransDto.Comments = getAccountTransactionComments(pymtTransDto, deletedPymtTransDto, pdcPymtDto);
        }
        else
        {
            acntTransDto.TxType = (pymtDirection.Equals(Constants.PYMT_DIRECTION.CUSTOMER_FIRM)) ? AcntTransStatus.Credit : AcntTransStatus.Debit;
            acntTransDto.Comments = getAccountTransactionComments(pymtTransDto, deletedPymtTransDto, pdcPymtDto);
        }        
        acntTransDto.TxDate = pymtTransDto.TxDate;
        acntTransDto.Amount = pymtTransDto.Amount;
        acntTransDto.FirmNumber = userDefDto.FirmNumber;
        acntTransDto.InsertUser = userDefDto.Username;
        acntTransDto.UpdateUser = userDefDto.Username;
        pymtTransDto.AccountTransaction = acntTransDto;
    }
    private string getAccountTransactionComments(PaymentTransactionDTO pymtTransDto, PaymentTransactionDTO deletedTransDto, PdcPymtDTO pdcPymtDto)
    {
        string comments = "";
        string pymtDirection = getPaymentDirection();
        string pymtModeComment = CommonUtil.getAcntTransCommentPymtMode(pymtTransDto);
        PostDatedChequeSearchDTO pdcSearchDto = getSelectedPdcFromList();
        string drawerName = (pageModeHdn.Value.Equals(PdcPageMode.ADD.ToString())) ? drpChqDrawer.SelectedItem.Text : pdcSearchDto.ChqDrawerName;
        string payeeName = (pageModeHdn.Value.Equals(PdcPageMode.ADD.ToString())) ? drpChqPayee.SelectedItem.Text : pdcSearchDto.ChqPayeeName;
        if (pageModeHdn.Value.Equals(PdcPageMode.ADD.ToString()))
        {
        }
        if (Constants.PYMT_DIRECTION.CUSTOMER_FIRM.Equals(pymtDirection))
        {
            if (deletedTransDto == null)
                comments = string.Format(Constants.PYMT_FROM, drawerName) + "," + pymtModeComment
                    + "," + Constants.TX_REF + "," + string.Format(Constants.UNIT_SALE_TYPE+"{0}", pdcPymtDto.PymtType.Name);
            else
                comments = string.Format(Constants.REV_PYMT_FROM, drawerName) + "," + pymtModeComment
                    + "," + Constants.TX_REF + "," + string.Format(Constants.REV_TX_REF, deletedTransDto.Id)
                    + "," + getPymtType(pymtDirection, deletedTransDto.AccountTransaction.Comments);
            
        }
        else if (Constants.PYMT_DIRECTION.FIRM_CUSTOMER.Equals(pymtDirection))
        {
            if (deletedTransDto == null)
                comments = string.Format(Constants.PYMT_TO, payeeName) + "," + pymtModeComment
                    + "," + Constants.TX_REF + "," + string.Format(Constants.UNIT_SALE_TYPE+"{0}", pdcPymtDto.PymtType.Name);
            else
                comments = string.Format(Constants.REV_PYMT_TO, payeeName) + "," + pymtModeComment
                    + "," + Constants.TX_REF + "," + string.Format(Constants.REV_TX_REF, deletedTransDto.Id)
                    + "," + getPymtType(pymtDirection, deletedTransDto.AccountTransaction.Comments);
        }
        else if (Constants.PYMT_DIRECTION.FIRM_CONTRACTOR.Equals(pymtDirection))
        {
        }
        else if (Constants.PYMT_DIRECTION.FIRM_SUPPLIER.Equals(pymtDirection))
        {
        }
        else if (Constants.PYMT_DIRECTION.FIRM_AGENCY.Equals(pymtDirection))
        {
            if (deletedTransDto == null)
                comments = string.Format(Constants.PYMT_TO, payeeName) + "," + pymtModeComment
                    + "," + Constants.TX_REF + "," + string.Format(Constants.PROP_EXP_TYPE + "{0}", pdcPymtDto.PymtType.Name);
            else
                comments = string.Format(Constants.REV_PYMT_TO, payeeName) + "," + pymtModeComment
                    + "," + Constants.TX_REF + "," + string.Format(Constants.REV_TX_REF, deletedTransDto.Id)
                    + "," + getPymtType(pymtDirection, deletedTransDto.AccountTransaction.Comments);
        }
        return comments;
    }
    private string getPymtType(string pymtDirection, string fwComments)
    {
        string comments = "";
        if (Constants.PYMT_DIRECTION.CUSTOMER_FIRM.Equals(pymtDirection))
        {
            comments = fwComments.Substring(fwComments.IndexOf(Constants.UNIT_SALE_TYPE));
        }
        else if (Constants.PYMT_DIRECTION.FIRM_CUSTOMER.Equals(pymtDirection))
        {
            comments = fwComments.Substring(fwComments.IndexOf(Constants.UNIT_SALE_TYPE));
        }
        else if (Constants.PYMT_DIRECTION.FIRM_CONTRACTOR.Equals(pymtDirection))
        {
        }
        else if (Constants.PYMT_DIRECTION.FIRM_SUPPLIER.Equals(pymtDirection))
        {
        }
        else if (Constants.PYMT_DIRECTION.FIRM_AGENCY.Equals(pymtDirection))
        {
            comments = fwComments.Substring(fwComments.IndexOf(Constants.PROP_EXP_TYPE));
        }
        return comments;
    }
    private void populateUiFieldsFromPDCDto(PostDatedChequeDTO pdcDto) {
        if (!pageModeHdn.Value.Equals(PdcPageMode.ADD.ToString()))
        {
            PostDatedChequeSearchDTO pdcSearchDto = getSelectedPdcFromList();
            drpChqDrawer.Text = pdcSearchDto.ChqDrawerId.ToString();
            drpChqPayee.Text = pdcSearchDto.ChqPayeeId.ToString();
        }
        if(pdcDto != null) txtChequeCollectionDate.Text = CommonUtil.getCSDate(pdcDto.CollectionDate); else txtChequeCollectionDate.Text = null;
        if(pdcDto != null) txtChequeDate.Text = CommonUtil.getCSDate(pdcDto.ChequeDate); else txtChequeDate.Text = null;
        if(pdcDto != null) txtChequeNo.Text = pdcDto.ChequeNo; else txtChequeNo.Text = null;
        if(pdcDto != null) txtChequeAmount.Text = pdcDto.PymtAmt.ToString(); else txtChequeAmount.Text = null;
        if(pdcDto != null) txtBankName.Text = pdcDto.BankName; else txtBankName.Text = null;
        if(pdcDto != null) txtBranch.Text = pdcDto.Branch; else txtBranch.Text = null;
        if(pdcDto != null) drpChequeStatus.Text = pdcDto.ChequeStatus.ToString(); else drpChequeStatus.ClearSelection();
        if(pdcDto != null) txtChequeComment.Text = pdcDto.Description; else txtChequeComment.Text = null;
        if(pdcDto != null) txtChqClearanceDate.Text = CommonUtil.getCSDate(pdcDto.ClearanceDate); else txtChqClearanceDate.Text = null;
        if(pdcDto != null && pdcDto.FirmAccount != null) drpFirmAccount.Text = pdcDto.FirmAccount.Id.ToString(); else drpFirmAccount.ClearSelection();
        populatePdcPymtDetailGrid(pdcDto);
    }
    private void populatePdcPymtDetailGrid(PostDatedChequeDTO pdcDto)
    {
        string pymtDirection = getPaymentDirection();
        if (Constants.PYMT_DIRECTION.CUSTOMER_FIRM.Equals(pymtDirection) || Constants.PYMT_DIRECTION.FIRM_CUSTOMER.Equals(pymtDirection))
        {
            pdcPymtGrid.Visible = true;
            pdcPymtGrid.DataSource = new List<PdcPymtDTO>();
            if (pdcDto != null && pdcDto.PdcUiPymts != null)
            {
                txtTotalPaidAmount.Text = calculateTotalPaidAmount(pdcDto).ToString();
                assignUiIndexToPdcPymts(pdcDto.PdcUiPymts);
                pdcPymtGrid.DataSource = pdcDto.PdcUiPymts;
            }
            pdcPymtGrid.DataBind();
        }
        else if (Constants.PYMT_DIRECTION.FIRM_CONTRACTOR.Equals(pymtDirection))
        {
        }
        else if (Constants.PYMT_DIRECTION.FIRM_SUPPLIER.Equals(pymtDirection))
        {
        }
        else if (Constants.PYMT_DIRECTION.FIRM_AGENCY.Equals(pymtDirection))
        {
            pdcAgencyPymtGrid.Visible = true;
            pdcAgencyPymtGrid.DataSource = new List<PdcPymtDTO>();
            if (pdcDto != null && pdcDto.PdcUiPymts != null)
            {
                txtTotalPaidAmount.Text = calculateTotalPaidAmount(pdcDto).ToString();
                assignUiIndexToPdcPymts(pdcDto.PdcUiPymts);
                pdcAgencyPymtGrid.DataSource = pdcDto.PdcUiPymts;
            }
            pdcAgencyPymtGrid.DataBind();
        }
        
    }
    private void assignUiIndexToPdcPymts(List<PdcPymtDTO> pdcPymts)
    {
        if (pdcPymts != null && pdcPymts.Count > 0)
        {
            long uiIndex = 1;
            string pymtDirection = getPaymentDirection();
            foreach (PdcPymtDTO pdcPymtDto in pdcPymts)
            {
                pdcPymtDto.UiIndex = uiIndex++;
                pdcPymtDto.RowInfo = CommonUIConverter.getGridViewRowInfo(pdcPymtDto, pymtDirection);
            }
        }
    }
    private decimal calculateTotalPaidAmount(PostDatedChequeDTO pdcDto) {
        decimal totalPaidAmt = Decimal.Zero;
        if(pdcDto != null) {
            foreach(PdcPymtDTO pdcPymtDto in pdcDto.PdcUiPymts) {
                totalPaidAmt = totalPaidAmt + pdcPymtDto.PaymentTransaction.Amount;
            }
        }
        return totalPaidAmt;
    }
    private void populatePdcDetailsFromUI(PostDatedChequeDTO pdcDto, PdcPageMode pageMode)
    {
        pdcDto.CollectionDate = CommonUtil.getCSDateNotNull(txtChequeCollectionDate.Text);
        pdcDto.ChequeDate = CommonUtil.getCSDate(txtChequeDate.Text);
        pdcDto.ChequeNo = txtChequeNo.Text;
        pdcDto.PymtAmt = CommonUtil.getDecimaNotNulllWithoutExt(txtChequeAmount.Text);
        pdcDto.BankName = txtBankName.Text;
        pdcDto.Branch = txtBranch.Text;
        pdcDto.ChequeStatus = EnumHelper.ToEnum<PdcChequeStatus>(drpChequeStatus.Text);
        pdcDto.Description = txtChequeComment.Text;
        pdcDto.ClearanceDate = CommonUtil.getCSDate(txtChqClearanceDate.Text);
        pdcDto.FirmAccount = CommonUIConverter.getFirmAccountDTO(drpFirmAccount.Text, null);
        pdcDto.PymtStatus = (PdcChequeStatus.Cleared != pdcDto.ChequeStatus) ? PdcPymtStatus.Pending : PdcPymtStatus.Paid;

        if (pageMode == PdcPageMode.ADD)
        {
            string pymtDirection = getPaymentDirection();
            long fromId = long.Parse(drpChqDrawer.Text);
            long toId = long.Parse(drpChqPayee.Text);
            List<PdcBookDTO> pdcBookDtos = paymentBO.getPdcBookDTO(pymtDirection, fromId, toId);
            pdcDto.PdcFrom = pdcBookDtos[0];
            pdcDto.PdcTo = pdcBookDtos[1];
        }
        pdcDto.PaymentTransactions.Clear();
        //If Check is Bounced then there should not be any payment transaction for that check
        if (PdcChequeStatus.Bounced != pdcDto.ChequeStatus)
        {
            foreach (PdcPymtDTO pdcPymtDto in pdcDto.PdcUiPymts)
            {
                if (pdcPymtDto.PaymentTransaction.Amount > 0)
                {
                    PaymentTransactionDTO pymtTransDto = pdcPymtDto.PaymentTransaction;
                    copyPymtTransFields(pymtTransDto, pdcDto, null, pdcPymtDto);
                    pdcDto.PaymentTransactions.Add(pymtTransDto);
                }
            }
        }
    }
    protected void onClickAddPDCBtn(object sender, EventArgs e)
    {
    	try
        {
            resetTabInfo(PdcPageMode.ADD);
            selectPdcSearchGridRdBtn(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickModifyPDCBtn(object sender, EventArgs e)
    {
        try
        {
            if (validatePdcSelected() && validateModifyChequeStatus())
            {
                resetTabInfo(PdcPageMode.MODIFY);
                fetchSelectedPdc(PdcPageMode.MODIFY);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickViewPDCBtn(object sender, EventArgs e)
    {
        try
        {
            if (validatePdcSelected())
            {
                resetTabInfo(PdcPageMode.VIEW);
                fetchSelectedPdc(PdcPageMode.VIEW);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }

    protected void onChangeChequeDrawer(object sender, EventArgs e)
    {
        try
        {
            drpChqPayee.ClearSelection();
            pnlChqAndPymtDetails.Visible = false;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void onChangeChequePayee(object sender, EventArgs e)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(drpChqDrawer.Text))
            {
                setErrorMessage("Please select Cheque Drawer", tab2ValidationGrp);
            } if (string.IsNullOrWhiteSpace(drpChqPayee.Text))
            {
                pnlChqAndPymtDetails.Visible = false;
            }
            else
            {
                pnlChqAndPymtDetails.Visible = true;
                fetchSelectedPdc(PdcPageMode.ADD);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    private void setSelectedPdcPymt(long selectedId)
    {
        List<PdcPymtDTO> pdcPymtDtoList = getCurrentPdc().PdcUiPymts;
        if (pdcPymtDtoList != null)
        {
            pdcPymtDtoList.ForEach(c => c.isUISelected = false);
            if (selectedId > 0) pdcPymtDtoList.Find(c => c.PymtMasterId == selectedId).isUISelected = true;
        }
    }
    private PdcPymtDTO getSelectedPdcPymt() {
        PdcPymtDTO selectedPymt = null;
        List<PdcPymtDTO> pdcPymtDtoList = getCurrentPdc().PdcUiPymts;
        if (pdcPymtDtoList != null)
        {
            selectedPymt = pdcPymtDtoList.Find(x => x.isUISelected);
        }
        return selectedPymt;
    }
    private bool validatePaymentSelected() {
        bool isSelected = (getSelectedPdcPymt() != null);
        if(!isSelected) setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Payment"), tab2Error1);
        return isSelected;
    }
    private decimal getRemainingPayment()
    {
        decimal chequePymt = CommonUtil.getDecimaNotNulllWithoutExt(txtChequeAmount.Text);
        decimal totalPaid = calculateTotalPaidAmount(getCurrentPdc());
        return chequePymt - totalPaid;
    }
    protected void onSelectPdcPayment(object sender, EventArgs e)
    {
        try
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            if (rd.Checked)
            {
                string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnPdcPymtRowIdentifier"))).Attributes["row-identifier"];
                setSelectedPdcPymt(long.Parse(strId));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void onClickPayPdcPymtBtn(object sender, EventArgs e)
    {
        try
        {
            if(validatePaymentSelected()) {
                lbModalRemainingPymt.Text = getRemainingPayment().ToString();
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "PodcPayment", "payPdcPayment()", true);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void onClickClearPdcPaymentBtn(object sender, EventArgs e)
    {
        try
        {
            if(validatePaymentSelected()) {
                setPaymentAndComments(Decimal.Zero, "");
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void addChequePayment(object sender, EventArgs e)
    {
        try
        {
            if (validateAddUpdateChequePymt())
            {
                PostDatedChequeDTO pdcDto = getCurrentPdc();
                populatePdcDetailsFromUI(pdcDto, PdcPageMode.ADD);
                long Id = paymentBO.addPostDatedChequeDetails(pdcDto);
                fetchAllPostDatedCheques(Id);
                resetTabInfo(PdcPageMode.NONE);
                setSuccessMessage("Post Dated Cheque added successfully.", tab1Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void updateChequePayment(object sender, EventArgs e)
    {
        try
        {
            if (validateAddUpdateChequePymt())
            {
                PostDatedChequeDTO pdcDto = getCurrentPdc();
                populatePdcDetailsFromUI(pdcDto, PdcPageMode.MODIFY);
                paymentBO.updatePostDatedChequeDetails(pdcDto);
                fetchAllPostDatedCheques(pdcDto.Id);
                resetTabInfo(PdcPageMode.NONE);
                setSuccessMessage("Post Dated Cheque updated successfully.", tab1Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void onClickDeletePDCBtn(object sender, EventArgs e)
    {
        try
        {
            if (validatePdcSelected() && validatePdcDelete())
            {
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                PostDatedChequeSearchDTO pdcSearchDto = getSelectedPdcFromList();
                if (PdcChequeStatus.Cleared == pdcSearchDto.ChequeStatus)
                {
                    PostDatedChequeDTO pdcDto = paymentBO.fetchPostDatedChequeDetails(pdcSearchDto.Id);
                    pdcDto.PymtStatus = PdcPymtStatus.Deleted;
                    pdcDto.UpdateUser = userDefDto.Username;
                    List<PaymentTransactionDTO> reversalPymtTransDtos = new List<PaymentTransactionDTO>();
                    foreach (PaymentTransactionDTO transDto in pdcDto.PaymentTransactions)
                    {
                        transDto.Status = PymtTransStatus.Deleted;
                        transDto.UpdateUser = userDefDto.Username;
                        PaymentTransactionDTO reversalPymtTransDto = createNewPaymentTransaction(pdcDto, transDto, null);
                        reversalPymtTransDto.PaymentMaster = transDto.PaymentMaster;
                        transDto.CancelledPaymentTransaction = reversalPymtTransDto;
                        reversalPymtTransDtos.Add(reversalPymtTransDto);
                    }
                    reversalPymtTransDtos.ForEach(x => pdcDto.PaymentTransactions.Add(x));
                    paymentBO.updatePostDatedChequeDetails(pdcDto);
                } else {
                    paymentBO.deleteUnpaidPdcDetails(pdcSearchDto.Id, userDefDto.Username);
                }
                fetchAllPostDatedCheques(0);
                resetTabInfo(PdcPageMode.NONE);
                setSuccessMessage("Post Dated Cheque deleted successfully.", tab1Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void cancelChequePayment(object sender, EventArgs e)
    {
        resetTabInfo(PdcPageMode.NONE);
    }
    private bool validatePdcDelete() {
        PostDatedChequeSearchDTO pdcSearchDto = getSelectedPdcFromList();
        if(pdcSearchDto.PymtStatus == PdcPymtStatus.Deleted) {
            setErrorMessage("Selected Post Dated Cheque record already deleted.", tab1ValidationGrp);
            return false;
        }
        return true;
    }
    private void setPaymentAndComments(decimal pymtAmount, string comments) {
        PdcPymtDTO selectedPymt = getSelectedPdcPymt();
        selectedPymt.PaymentTransaction.Amount = pymtAmount;
        selectedPymt.PaymentTransaction.Comments = comments;
        populatePdcPymtDetailGrid(getCurrentPdc());
    }
    private bool validateAddUpdateChequePymt()
    {
        Page.Validate(tab2ValidationGrp);
        bool isValid = Page.IsValid;
        if (isValid)
        {
            PdcChequeStatus chqStatus = EnumHelper.ToEnum<PdcChequeStatus>(drpChequeStatus.Text);
            if (chqStatus != PdcChequeStatus.Collected)
            {
                Page.Validate(tab2Error1);
                isValid = Page.IsValid;
                decimal chequePymt = CommonUtil.getDecimaNotNulllWithoutExt(txtChequeAmount.Text);
                if (isValid && chequePymt <= 0)
                {
                    setErrorMessage("Cheque Amount cannot be zero", tab2Error2);
                    return false;
                }
            }
            if (isValid && chqStatus == PdcChequeStatus.Cleared)
            {
                Page.Validate(tab2Error2);
                isValid = Page.IsValid;
                if (isValid)
                {
                    DateTime clearanceDate = CommonUtil.getCSDateNotNull(txtChqClearanceDate.Text);
                    if (CommonUtil.isGreaterThanToday(clearanceDate))
                    {
                        setErrorMessage("Cheque Clearance date cannot be in future.", tab2Error2);
                        return false;
                    }
                    isValid = validatePaidAmounts();
                }
            }
        }

        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    private bool validatePaidAmounts() {
        DateTime clearanceDate = CommonUtil.getCSDateNotNull(txtChqClearanceDate.Text);
        DateTime chequeDate = CommonUtil.getCSDateNotNull(txtChequeDate.Text);
        if (clearanceDate.CompareTo(chequeDate) < 0)
        {
            setErrorMessage("Cheque Date cannot be greater than Clearance Date.", tab2Error2);
            return false;
        } 
        decimal remainingPymt = getRemainingPayment();
        if(remainingPymt != 0) {
            setErrorMessage("Cheque Amount and Total Paid Akmount is not same.", tab2Error2);
            return false;
        }
        PdcChequeStatus checkStatus = EnumHelper.ToEnum<PdcChequeStatus>(drpChequeStatus.Text);
        if (PdcChequeStatus.Bounced == checkStatus)
        {
            PostDatedChequeDTO pdcDto = getCurrentPdc();
            foreach (PdcPymtDTO pdcPymtDto in pdcDto.PdcUiPymts)
            {
                if (pdcPymtDto.PaymentTransaction.Amount > 0)
                {
                    setErrorMessage("Payment cannot be done if check is bounced. Please clear payments.", tab2Error2);
                    return false;
                }
            }
        }
        return true;
    }
    //Modal save logic
    protected void saveModalData(object sender, EventArgs e)
    {
        String errorMsg = "";
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        if (modalHdnType.Value == "PDC_PYMT")
        {
            errorMsg = validatePymtAmountModal();
            if (string.IsNullOrWhiteSpace(errorMsg))
            {
                decimal pymtAmount = CommonUtil.getDecimaNotNulllWithoutExt(modalInput1.Text);
                setPaymentAndComments(pymtAmount, modalInput2.Text);
            }
        }

        if (!string.IsNullOrWhiteSpace(errorMsg))
        {
            modalErrorMsg.Value = errorMsg;
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "setModalErrorMsg", "setModalErrorMsg()", true);
        }
        else
        {
            //Reset the modal fields
            modalInput1.Text = "";
            modalInput2.Text = "";
            modalHdnType.Value = "";
            modalActionHdn.Value = "";
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "closeDialogClient", "closeDialogClient()", true);
        }
    }
    private string validatePymtAmountModal()
    {
        string errorMsg = "";
        if (string.IsNullOrWhiteSpace(modalInput1.Text))
        {
            errorMsg = string.Format(Resources.Messages.validation_txtfield_required, "Payment Amount");
        }
        else
        {
            decimal pymtAmount = CommonUtil.getDecimaNotNulllWithoutExt(modalInput1.Text);
            decimal remainingPymt = getRemainingPayment();
            if (pymtAmount > remainingPymt)
            {
                errorMsg = "Payment Amount cannot be more than remaining cheque payment.";
            }
        }
        return errorMsg;
    }
}
