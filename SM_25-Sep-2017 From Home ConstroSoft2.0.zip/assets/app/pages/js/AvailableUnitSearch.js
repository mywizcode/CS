﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initAvailableUnitSearchGrid();
    formatFields();
    showModal();
}

function initAvailableUnitSearchGrid() {
    var dtOptions = {
        tableId: "availableUnitSearchGrid",
        pageLength: 10,
        responsiveModalTitle: "Unit Details",
        isViewOnly: false,
        hideSearch: false
    };
    var dtTable = applyActionDataTable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitHdnId");
}




