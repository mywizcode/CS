﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq.Expressions;
using NHibernate.Impl;
using System.Linq;
using System.Data;
using CrystalDecisions.CrystalReports.Engine;

namespace ConstroSoft.Logic.BO
{

    public class DemandLetterBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public DemandLetterBO() { }

        public BusinessOutputTO processDemandLetter(string firmNumber, PrUnitSaleDetailDTO selectedPrUnitSaleDetailDto)
        {
            BusinessOutputTO businessOutputTO = new BusinessOutputTO();
            string BLANK_STRING = "";
            try
            {
                DataTable DemandLetter = populateDemandLetterColumns();
                FirmBO firmBO = new FirmBO();
                PropertyBO propertyBO = new PropertyBO();
                SoldPropertyUnitBO soldUnitBO = new SoldPropertyUnitBO();
                PrUnitSaleDetailDTO prUnitSaleDetailDto = soldUnitBO.fetchPrUnitSaleDetailforLetter(firmNumber, selectedPrUnitSaleDetailDto.Id,
                        selectedPrUnitSaleDetailDto.PropertyUnit.PropertyTower.Property.Id);
                FirmDTO firmDto = firmBO.fetchFirmDetails(firmNumber);
                PropertyDTO propertyDTO = propertyBO.fetchProperty(selectedPrUnitSaleDetailDto.PropertyUnit.PropertyTower.Property.Id);
                List<PropertyScheduleDTO> propertyScheduleList = propertyBO.fetchPropertySchedule(firmNumber, 
                    prUnitSaleDetailDto.PropertyUnit.PropertyTower.Id);
                List<PropertyScheduleDTO> tmpStageList = propertyScheduleList.FindAll(x => x.Status == PRScheduleStageStatus.Completed);
                string errorMessage = validateStageSetup(tmpStageList);
                if (!string.IsNullOrWhiteSpace(errorMessage))
                {
                    businessOutputTO.status = BusinessOutputTO.Status.FAILURE;
                    businessOutputTO.errorMessage = errorMessage;
                }
                else
                {
                    DataRow DemandLetterRow = populateDemandLetterRows(DemandLetter, prUnitSaleDetailDto, selectedPrUnitSaleDetailDto,
                        firmDto, propertyDTO, tmpStageList, firmNumber);
                    DemandLetter.Rows.Add(DemandLetterRow);
                    businessOutputTO.status = BusinessOutputTO.Status.SUCCESS;
                    businessOutputTO.result = DemandLetter;
                    string customerName = prUnitSaleDetailDto.Customer.Salutation.Name + " " + prUnitSaleDetailDto.Customer.FirstName + " ";
                    customerName = string.Concat(customerName, prUnitSaleDetailDto.Customer.MiddleName != null ? prUnitSaleDetailDto.Customer.MiddleName + " " : BLANK_STRING);
                    customerName = string.Concat(customerName, prUnitSaleDetailDto.Customer.LastName != null ? prUnitSaleDetailDto.Customer.LastName + " " : BLANK_STRING);
                    businessOutputTO.successMessage = "Demand Letter for "+customerName;
                }
            }
            catch (Exception e)
            {
                log.Error("Exception while generating demand letter", e);
                throw new Exception(Resources.Messages.system_error);
            }
            return businessOutputTO;
        }
        private DataRow populateDemandLetterRows(DataTable DemandLetter, PrUnitSaleDetailDTO prUnitSaleDetailDto,
            PrUnitSaleDetailDTO selectedPrUnitSaleDetailDto, FirmDTO firmDto, PropertyDTO propertyDTO, List<PropertyScheduleDTO> tmpStageList,
            string firmNumber)
        {
            DataRow DemandLetterRow = DemandLetter.NewRow();
            string BLANK_STRING = "";
            DemandLetterRow["Loanbankname"] = prUnitSaleDetailDto.LoanBankName != null ? prUnitSaleDetailDto.LoanBankName : BLANK_STRING;
            DemandLetterRow["Loanbankbranch"] = prUnitSaleDetailDto.LoanBankBranch != null ? prUnitSaleDetailDto.LoanBankBranch : BLANK_STRING;

            string customerName = prUnitSaleDetailDto.Customer.Salutation.Name + " " + prUnitSaleDetailDto.Customer.FirstName + " ";
            customerName = string.Concat(customerName, prUnitSaleDetailDto.Customer.MiddleName != null ? prUnitSaleDetailDto.Customer.MiddleName + " " : BLANK_STRING);
            customerName = string.Concat(customerName, prUnitSaleDetailDto.Customer.LastName != null ? prUnitSaleDetailDto.Customer.LastName + " " : BLANK_STRING);
            DemandLetterRow["Customername"] = customerName;
            string coCustomerName = null;
            if (prUnitSaleDetailDto.CoCustomers != null && prUnitSaleDetailDto.CoCustomers.Count > 0)
            {
                List<CoCustomerDTO> coCustomerDTOs = prUnitSaleDetailDto.CoCustomers.ToList();
                coCustomerName = coCustomerDTOs[0].SalutationId.Name + " " + coCustomerDTOs[0].FirstName + " ";
                coCustomerName = string.Concat(coCustomerName, coCustomerDTOs[0].MiddleName != null ? coCustomerDTOs[0].MiddleName + " " : BLANK_STRING);
                coCustomerName = string.Concat(coCustomerName, coCustomerDTOs[0].LastName != null ? coCustomerDTOs[0].LastName + " " : BLANK_STRING);
            }
            DemandLetterRow["CoCustomername"] = coCustomerName != null ? coCustomerName : BLANK_STRING;

            PropertyUnitDTO propertyUnitDto = prUnitSaleDetailDto.PropertyUnit;
            PropertyTowerDTO propertyTowerDto = prUnitSaleDetailDto.PropertyUnit.PropertyTower;
            DemandLetterRow["Flatnumber"] = prUnitSaleDetailDto.PropertyUnit.UnitNo;
            DemandLetterRow["Floornumber"] = propertyUnitDto.FloorNo;
            DemandLetterRow["Carpetarea"] = propertyUnitDto.CarpetArea.ToString();
            DemandLetterRow["Builtuparea"] = propertyUnitDto.BuildupArea.ToString();
            DemandLetterRow["Balconyarea"] = propertyUnitDto.BalconyArea.ToString();
            DemandLetterRow["Flatnumber"] = prUnitSaleDetailDto.PropertyUnit.UnitNo;
            DemandLetterRow["Propertyname"] = propertyDTO.Name;
            AddressDTO addressDTO = propertyDTO.ContactInfo.Addresses.ToList()[0];

            string address = addressDTO.AddressLine1 + " ";
            address = string.Concat(address, addressDTO.AddressLine2 != null ? addressDTO.AddressLine2 : BLANK_STRING);
            address = string.Concat(address, " "+addressDTO.Town != null ? addressDTO.Town : BLANK_STRING);
            address = string.Concat(address, " " + addressDTO.City.Name + " " + addressDTO.State.Name + " " + addressDTO.Country.Name + " " + addressDTO.Pin);
            DemandLetterRow["Propertyaddress"] = address;

            DemandLetterRow["Firmname"] = firmDto.Name;
            DemandLetterRow["Towername"] = selectedPrUnitSaleDetailDto.PropertyUnit.PropertyTower.Name;
            DemandLetterRow["UnitType"] = prUnitSaleDetailDto.PropertyUnit.UnitType.Name;
            
            decimal totalPaidAmt;
            decimal totalPaymentAmount;
            PrUnitSalePymtDTO tmpPrUnitSalePymtDTO = prUnitSaleDetailDto.PrUnitSalePymts.ToList<PrUnitSalePymtDTO>().Find(x => isSalePayment(x.PymtType.Name));
            totalPaymentAmount = tmpPrUnitSalePymtDTO.PymtAmt;
            totalPaidAmt = tmpPrUnitSalePymtDTO.PaymentMaster.TotalPaid;

            decimal stagePercentge;
            PropertyScheduleDTO propertyScheduleDTO = null;
            decimal actualPaymentDue = 0.0M;
            if (tmpStageList != null && tmpStageList.Count > 0)
            {
                stagePercentge = (tmpStageList.Sum(x => x.Percentage));
                decimal totalPaymentDue = (totalPaymentAmount * stagePercentge) / 100;
                actualPaymentDue = totalPaymentDue - totalPaidAmt;
                int maxZ = tmpStageList.Max(obj => obj.StageNumber);
                propertyScheduleDTO = (PropertyScheduleDTO)tmpStageList.Where(obj => obj.StageNumber == maxZ).FirstOrDefault();
            }
            DemandLetterRow["Stage"] = propertyScheduleDTO.Stage != null ? propertyScheduleDTO.Stage : BLANK_STRING;
            DemandLetterRow["Paymentamount"] = actualPaymentDue.ToString("#.##");
            DemandLetterRow["TotalPaidAmount"] = totalPaymentAmount.ToString("#.##"); ;
            return DemandLetterRow;
        }
        private static DataTable populateDemandLetterColumns()
        {
            DataTable DemandLetter = new DataTable();
            DemandLetter.Columns.Add("Loanbankname", typeof(string));
            DemandLetter.Columns.Add("Loanbankbranch", typeof(string));
            DemandLetter.Columns.Add("Customername", typeof(string));
            DemandLetter.Columns.Add("CoCustomername", typeof(string));
            DemandLetter.Columns.Add("Flatnumber", typeof(string));
            DemandLetter.Columns.Add("Floornumber", typeof(string));
            DemandLetter.Columns.Add("Carpetarea", typeof(string));
            DemandLetter.Columns.Add("Builtuparea", typeof(string));
            DemandLetter.Columns.Add("Balconyarea", typeof(string));
            DemandLetter.Columns.Add("Propertyname", typeof(string));
            DemandLetter.Columns.Add("Propertyaddress", typeof(string));
            DemandLetter.Columns.Add("Stage", typeof(string));
            DemandLetter.Columns.Add("Paymentamount", typeof(string));
            DemandLetter.Columns.Add("Firmname", typeof(string));
            DemandLetter.Columns.Add("Towername", typeof(string));
            DemandLetter.Columns.Add("UnitType", typeof(string));
            DemandLetter.Columns.Add("TotalPaidAmount", typeof(string));
             return DemandLetter;
        }
        public static string validateStageSetup(List<PropertyScheduleDTO> tmpStageList)
        {
            string errorMessage = "";
            if (tmpStageList == null && tmpStageList.Count == 0)
            {
                errorMessage = "Property Schedule is not set. Please set Property Schedule";
            }
            return errorMessage;
        }
        private bool isSalePayment(string paymentType)
        {
            return Constants.MCD_SALE_PAYMENT.Equals(paymentType);
        }
    }
}
