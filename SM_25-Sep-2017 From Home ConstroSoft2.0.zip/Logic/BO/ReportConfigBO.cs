﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using NHibernate;
using NHibernate.Criterion;
using NHibernate.Impl;
using NHibernate.Transform;

namespace ConstroSoft.Logic.BO
{

    public class ReportConfigBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public ReportConfigBO() { }

        public ReportConfigDTO fetchReportConfiguration(string firmNumber, string reportName)
        {
            ISession session = null;
            ReportConfigDTO reportConfigDTO = new ReportConfigDTO();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        ReportConfig ReportConfig = session.CreateCriteria<ReportConfig>().Add(
                            NHibernate.Criterion.Expression.Eq("FirmNumber", firmNumber)).Add(
                            NHibernate.Criterion.Expression.Eq("ReportName", reportName)).List<ReportConfig>().FirstOrDefault();
                        reportConfigDTO = DomainToDTOUtil.convertToReportConfigDTO(ReportConfig);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching report configuration :", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return reportConfigDTO;
        }
    }
}