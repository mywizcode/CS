﻿using System;
using NHibernate;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using ConstroSoft;
using System.Collections.Generic;
using NHibernate.Criterion;
using NHibernate.Transform;

/// <summary>
/// Summary description for SupplierBO
/// </summary>
namespace ConstroSoft
{
    public class DocumentBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public DocumentBO() { }
        public IList<EnquiryDetailDTO> fetchDocumentGridData(string firmNumber, long searchByValue)
        {
            ISession session = null;
            IList<EnquiryDetailDTO> results = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                EnquiryDetail ed = null;
                ContactInfo c = null;
                FirmMember fm = null;
                EnquiryDetailDTO enDto = null;
                MasterControlData dg = null;
                MasterControlData dge = null;
                Property pr = null;

                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => ed.Id).WithAlias(() => enDto.Id))
                            .Add(Projections.SqlFunction("concat",
                                        NHibernateUtil.String,
                                        Projections.Property(() => ed.FirstName),
                                        Projections.Constant(" "),
                                        Projections.Property(() => ed.LastName)
                                    ).WithAlias(() => ed.FirstName))
                            .Add(Projections.Property(() => ed.Budget).WithAlias(() => enDto.Budget))
                            .Add(Projections.Property(() => ed.EnquiryDate).WithAlias(() => enDto.EnquiryDate))
                            .Add(Projections.Property(() => ed.Status).WithAlias(() => enDto.Status))
                            .Add(Projections.Property(() => c.Contact), "ContactInfo.Contact")
                            .Add(Projections.Property(() => c.Email), "ContactInfo.Email")
                            .Add(Projections.Property(() => dge.Name), "EnquirySource.Name")
                            .Add(Projections.SqlFunction("concat",
                                        NHibernateUtil.String,
                                        Projections.Property(() => fm.FirstName),
                                        Projections.Constant(" "),
                                        Projections.Property(() => fm.LastName)
                                    ).WithAlias(() => fm.FirstName), "FirmMember.FirstName");
                var query = session.QueryOver<EnquiryDetail>(() => ed)
                    .Inner.JoinAlias(() => ed.ContactInfo, () => c)
                    .Left.JoinAlias(() => ed.Assignee, () => fm)
                    .Left.JoinAlias(() => ed.EnquirySource, () => dge); ;
                results = query.Where(() => ed.FirmNumber == firmNumber)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<EnquiryDetailDTO>()).List<EnquiryDetailDTO>();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating enquiry grid:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }
       
    }
}