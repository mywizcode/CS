﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ConstroSoft.View.CRM.EnquiryManagement
{
    public partial class EnquirySearch : System.Web.UI.Page
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string commonError = "commonError";
        string SearchFilterModal = "SearchFilterModal";
        DropdownBO drpBO = new DropdownBO();
        EnquiryBO enquiryBO = new EnquiryBO();
        protected void Page_Load(object sender, EventArgs e)
        {
            clearMessages();
            if (!IsPostBack)
            {
                if (CommonUtil.isSessionActive(Session))
                {
                    EnquirySearchNavDTO navDto = (EnquirySearchNavDTO)Session[Constants.Session.NAV_DTO];
                    Session.Remove(Constants.Session.NAV_DTO);
                    Session.Remove(Constants.Session.PAGE_DATA);
                    if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(Constants.URL.DEFAULT_HOME_PAGE, false);
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, true);
                }
            }
            setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
        }
        private void setNotyMsg(string msg)
        {
            btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
        }
        /**
         * This method is called just before the page is rendered. So any change in state of the element is applied.
         **/
        protected void Page_PreRender(object sender, EventArgs e)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                applyEntitlement();
                preRenderInitFormElements();
                initBootstrapComponantsFromServer();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        private void applyEntitlement()
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            lnkAddEnquiryUnitBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_ADD);
            if (enquirySearchGrid.Rows.Count > 0)
            {
                for (var i = 0; i < enquirySearchGrid.Rows.Count; i++)
                {
                    LinkButton tmpModifyBtn = (LinkButton)enquirySearchGrid.Rows[i].FindControl("lnkModifyEnquiryBtn");
                    if (tmpModifyBtn != null)
                    {
                        tmpModifyBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_MODIFY);
                    }
                    LinkButton tmpActivityBtn = (LinkButton)enquirySearchGrid.Rows[i].FindControl("lnkActivityHistoryBtn");
                    if (tmpActivityBtn != null)
                    {
                        tmpActivityBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_MODIFY);
                    }
                }
            }

        }
        private void preRenderInitFormElements()
        {
            renderPageLayout();
        }
        public void initBootstrapComponantsFromServer()
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
        }
        private UserDefinitionDTO getUserDefinitionDTO()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }
        private void initDropdowns()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];            
            drpBO.drpDataBase(drpEnquirySourceFilter, DrpDataType.ENQUIRY_SOURCE_Name, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpStatusFilter, DrpDataType.ENQUIRY_STATUS, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        }
        public void setErrorMessage(string message, string group)
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        private void clearMessages()
        {
            pnlSuccessMsg.Visible = false;
            lbSuccessMsg.Text = "";
        }
        public void setSuccessMessage(string msg)
        {
            lbSuccessMsg.Text = msg;
            pnlSuccessMsg.Visible = true;
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        private void doInit(EnquirySearchNavDTO navDto)
        {
            Session[Constants.Session.PAGE_DATA] = new EnquirySearchPageDTO();
            initDropdowns();
            setSearchFilter(null);
            initPageAfterRedirect(navDto);
        }
        private void initPageAfterRedirect(EnquirySearchNavDTO navDto)
        {
            try
            {
                if (navDto != null)
                {
                    setSearchFilter(navDto.filterDTO);
                }
                loadEnquirySearchGrid();
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                throw exp;
            }
        }
        private void renderPageLayout()
        {
        }
        private void setSearchGrid(IList<EnquiryDetailDTO> tmpList)
        {
            getSessionPageData().SearchResult = (tmpList != null) ? tmpList.ToList<EnquiryDetailDTO>() : new List<EnquiryDetailDTO>();
            enquirySearchGrid.DataSource = getSearchEnquiryDetailList();
            enquirySearchGrid.DataBind();
        }
        private EnquirySearchPageDTO getSessionPageData()
        {
            return (EnquirySearchPageDTO)Session[Constants.Session.PAGE_DATA];
        }
        private List<EnquiryDetailDTO> getSearchEnquiryDetailList()
        {
            return getSessionPageData().SearchResult;
        }
        private EnquiryDetailDTO getSearchEnquiryDetailDTO(long Id)
        {
            List<EnquiryDetailDTO> searchList = getSearchEnquiryDetailList();
            EnquiryDetailDTO selectedUnitDTO = null;
            if (searchList != null && searchList.Count > 0)
            {
                selectedUnitDTO = searchList.Find(c => c.Id == Id);
            }
            return selectedUnitDTO;
        }
        private void loadEnquirySearchGrid()
        {
            IList<EnquiryDetailDTO> results = enquiryBO.fetchEnquiryGridData(getUserDefinitionDTO().FirmNumber, CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()).Id,getUserDefinitionDTO().Id, getSearchFilter());
            setSearchGrid(results);
        }

        protected void onClickSearchFilter(object sender, EventArgs e)
        {
            try
            {
                activeModalHdn.Value = SearchFilterModal;
                EnquiryFilterDTO filterDTO = getSearchFilter();
                drpBO.drpDataBase(drpEnquirySourceFilter, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ENQUIRY_SOURCE, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
                drpBO.drpEnum<EnquiryStatus>(drpStatusFilter, Constants.SELECT_ITEM);
                if (filterDTO.LeadRef != null) txtLeadReferanceNo.Text = filterDTO.LeadRef; else txtLeadReferanceNo.Text = null;
                if (filterDTO.FirstName != null) txtFirstName.Text = filterDTO.FirstName; else txtFirstName.Text = null;
                if (filterDTO.LastName != null) txtLastName.Text = filterDTO.LastName; else txtLastName.Text = null;
                if (filterDTO.ContactNo != null) txtContact.Text = filterDTO.ContactNo; else txtContact.Text = null;
                if (filterDTO.Status !=null) drpStatusFilter.Text = filterDTO.Status.ToString(); else drpStatusFilter.ClearSelection();
                if (filterDTO.EnquirySource != null) drpEnquirySourceFilter.Text = filterDTO.EnquirySource.Id.ToString(); else drpEnquirySourceFilter.ClearSelection();
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
            }
        }

        private void navigateToEnquiryDetails(long selectedId, PageMode mode)
        {
            EnquiryDetailDTO enquiryDetailDTO = getSearchEnquiryDetailDTO(selectedId);
            EnquiryDetailNavDTO navDTO = new EnquiryDetailNavDTO();
            navDTO.Mode = mode;
            navDTO.enquiryId = enquiryDetailDTO.Id;            
            EnquirySearchNavDTO searchNavDTO = new EnquirySearchNavDTO();
            searchNavDTO.filterDTO = getSearchFilter();
            navDTO.PrevNavDto = searchNavDTO;
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.ENQUIRY_DETAIL, true);
        }        
        //Filter Criteria - Property Search - Start
        private EnquiryFilterDTO getSearchFilter()
        {
            return getSessionPageData().FilterDTO;
        }
        protected void onClickViewEnquiryBtn(object sender, EventArgs e)
        {
            try
            {
                LinkButton rd = (LinkButton)sender;
                long selectedId = long.Parse(rd.Attributes["data-pid"]);
                //navigateToEnquiryDetails(selectedId, PageMode.VIEW);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
            }
        }
        protected void onClickModifyEnquiryBtn(object sender, EventArgs e)
        {
            try
            {
                LinkButton rd = (LinkButton)sender;
                long selectedId = long.Parse(rd.Attributes["data-pid"]);
                //navigateToEnquiryDetails(selectedId, PageMode.MODIFY);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
            }
        }
        protected void onClickActiveHistoryBtn(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
            }
        }
        protected void onClickAddEnquiryBtn(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
            }
        }
       
        protected void applySearchFilterCriteria(object sender, EventArgs e)
        {
            try
            {

                EnquiryFilterDTO filterDTO = new EnquiryFilterDTO();
                
                if (!string.IsNullOrWhiteSpace(txtEnquiryRefNoFilter.Text))
                {
                    filterDTO.EnquiryRef = txtEnquiryRefNoFilter.Text;
                }
                if (!string.IsNullOrWhiteSpace(txtFirstName.Text))
                {
                    filterDTO.FirstName = txtFirstName.Text;
                }
                if (!string.IsNullOrWhiteSpace(txtLastName.Text))
                {
                    filterDTO.LastName = txtLastName.Text;
                }
                if (!string.IsNullOrWhiteSpace(txtContact.Text))
                {
                    filterDTO.ContactNo = txtContact.Text;
                }
                if (!string.IsNullOrWhiteSpace(txtLeadReferanceNo.Text))
                {
                    filterDTO.LeadRef = txtLeadReferanceNo.Text;
                }
                if (!string.IsNullOrWhiteSpace(drpEnquirySourceFilter.Text))
                {
                    filterDTO.EnquirySource = CommonUIConverter.getMasterControlDTO(drpEnquirySourceFilter.Text, drpEnquirySourceFilter.SelectedItem.Text);
                    
                }
                if (!string.IsNullOrWhiteSpace(drpStatusFilter.Text))
                {
                    filterDTO.Status = EnumHelper.ToEnum<EnquiryStatus>(drpStatusFilter.SelectedItem.Text);
                }
                setSearchFilter(filterDTO);
                loadEnquirySearchGrid();
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
            }
        }

        protected void clearSearchFilter(object sender, EventArgs e)
        {
            try
            {
                setSearchFilter(null);
                loadEnquirySearchGrid();
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
            }
        }
        private void setSearchFilter(EnquiryFilterDTO searchFilterDTO)
        {
            getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new EnquiryFilterDTO();
            setSearchFilterTokens();
        }
        protected void cancelSearchFilterModal(object sender, EventArgs e)
        {
            try
            {
               
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
            }
        }
        protected void removeSearchFilterToken(object sender, EventArgs e)
        {
            try
            {
                string token = filterRemoveHdn.Value;
                filterRemoveHdn.Value = "";
                EnquiryFilterDTO filterDTO = getSearchFilter();
                if (token.StartsWith(Constants.FILTER.ENQUIRY_Ref_No))
                {
                    filterDTO.EnquiryRef =null;                    
                }
                else if (token.StartsWith(Constants.FILTER.LEAD_REF_NO)) filterDTO.LeadRef = null;
                else if (token.StartsWith(Constants.FILTER.CONTACT))
                {
                    filterDTO.ContactNo = null;
                    
                }
                else if (token.StartsWith(Constants.FILTER.FIRST_NAME))
                {
                    filterDTO.FirstName = null;                    
                }
                else if (token.StartsWith(Constants.FILTER.LAST_NAME))
                {
                    filterDTO.LastName = null;
                }
                else if (token.StartsWith(Constants.FILTER.ENQUIRY_SOURCE))
                {
                    filterDTO.EnquirySource = null;
                }
                else if (token.StartsWith(Constants.FILTER.ENQUIRY_STATUS))
                {
                    filterDTO.Status = null;
                }
                else if (token.StartsWith(Constants.FILTER.PROPERTY_NAME)) setNotyMsg(CommonUtil.getNotyInfoMsg(Resources.Messages.PROPERTY_NAME_REQUIRED));

                setSearchFilterTokens();
                loadEnquirySearchGrid();
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
            }
        }
        private void setSearchFilterTokens()
        {
            EnquiryFilterDTO filterDTO = getSearchFilter();
            string filter = null;
            if (filterDTO != null)
            {
                if (filterDTO.EnquiryRef != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.ENQUIRY_Ref_No + filterDTO.EnquiryRef);
                if (filterDTO.LeadRef != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.LEAD_REF_NO + filterDTO .LeadRef);
                if (filterDTO.EnquirySource != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.ENQUIRY_SOURCE + filterDTO.EnquirySource.Name);
                if (filterDTO.Status != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.ENQUIRY_STATUS + filterDTO.Status);
                if (filterDTO.FirstName != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.FIRST_NAME + filterDTO.FirstName);
                if (filterDTO.LastName != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.LAST_NAME + filterDTO.LastName);
                if (filterDTO.ContactNo != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.CONTACT + filterDTO.ContactNo);
            }
            txtSelectedFilter.Text = filter;
        }
    }
}