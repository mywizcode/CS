﻿using ConstroSoft.Logic.CachingProvider;
using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Caching;

namespace ConstroSoft.Logic.Job
{
    public class ExotelCallRetrivalJob : IJob
    {
        private static readonly log4net.ILog log =
                log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        
        CallHistoryBO callHistoryBO = new CallHistoryBO();
        
        public void Execute(IJobExecutionContext context)
        {
            JobHistoryDTO jobHistoryDTO = new JobHistoryDTO();
            string message = null;
            try{
                var schedulerContext = context.Scheduler.Context;
                JobDTO jobDTO = (JobDTO)schedulerContext.Get(Constants.NOTIFICATION_JOB);
                UserDefinitionDTO userDefinitionDTO = (UserDefinitionDTO)schedulerContext.Get("UserDefinitionDTO");
                populateJobHistoryAddDto(jobHistoryDTO, jobDTO, userDefinitionDTO);
                long Id =jobHistoryBO.saveJobHistory(jobHistoryDTO);
                jobHistoryDTO.Id = Id;
                //Fetch all the incoming calls for which Direction is INBOUND and Call Status is INPROGRESS.
                IList<Call> calls = callHistoryBO.fetchCallHistory(userDefinitionDTO.FirmNumber);
                //Iterate over each call & invoke ExotelClient.getCallDetails
                //If Call Status is COMPLETED, FAILED, BUSY then update call history.
                foreach (Call call in calls) {
                    InOutBoundCallResDTO outBoundCallResDTO = ExotelClient.getCallDetails(call.Sid);
                    if(outBoundCallResDTO.Call.Status == "COMPLETED" || outBoundCallResDTO.Call.Status == "FAILED" || outBoundCallResDTO.Call.Status == "BUSY" )
                    {
                        callHistoryBO.updateCallHistory(call);
                    }
                }
               
            }catch (Exception exp)
            {
                message = exp.Message;
                log.Error(exp.Message, exp);
            }finally{
                populateJobHistoryUpdateDto(jobHistoryDTO, message);
                jobHistoryBO.updatejobHistoryDetails(jobHistoryDTO);
            }
           
        }

        private void populateJobHistoryAddDto(JobHistoryDTO jobHistoryDTO, JobDTO jobDTO, UserDefinitionDTO userDefinitionDTO)
        {
            jobHistoryDTO.StartTime = DateTime.Now;
            jobHistoryDTO.JobRunStatus = JobRunStatus.INPROGRESS;
            jobHistoryDTO.Job = jobDTO;
            jobHistoryDTO.FirmNumber = userDefinitionDTO.FirmNumber;
            jobHistoryDTO.Version = userDefinitionDTO.Version;
            jobHistoryDTO.InsertUser = userDefinitionDTO.Username;
            jobHistoryDTO.UpdateUser = userDefinitionDTO.Username;
            jobHistoryDTO.InsertDate = DateTime.Now;
            jobHistoryDTO.UpdateDate = DateTime.Now;
        }

        private void populateJobHistoryUpdateDto(JobHistoryDTO jobHistoryDTO, string message)
        {
            jobHistoryDTO.EndTime = DateTime.Now;
            if (message != null)
            {
                jobHistoryDTO.JobRunStatus = JobRunStatus.FAILURE;
                jobHistoryDTO.Message = message;
            }
            else
            {
                jobHistoryDTO.JobRunStatus = JobRunStatus.SUCCESS;
                jobHistoryDTO.Message = "Job execution completed successfully.";
            }
            jobHistoryDTO.UpdateDate = DateTime.Now;
        }

    }

}