﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Net;
using System.IO;
using System.Windows.Forms;
using System.Net.Mail;
using ConstroSoft;
using ConstroSoft.Logic.BO;
using OfficeOpenXml;
using OfficeOpenXml.DataValidation;
using OfficeOpenXml.Style;
using System.Drawing;
using ConstroSoft.Logic.Util;
using System.Text;

public partial class CustomerPayment : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string chqPymtError = "chqPymtError";
    string nonCashPymtError = "nonCashPymtError";
    string pdcPymtError = "pdcPymtError";
    string distTransAmtModalError = "distTransAmtModalError";
    string distTransAmtModal = "distTransAmtModal";
    DropdownBO drpBO = new DropdownBO();
    PaymentBO paymentBO = new PaymentBO();
    public enum CustomerPymtPageMode { ADD, MODIFY, VIEW}
    protected void Page_Load(object sender, EventArgs e)
    {
    	if (ApplicationUtil.isSubPageRendered(Page)) clearMessages();
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                CustomerPaymentNavDTO navDto = CommonUtil.getPageNavDTO<CustomerPaymentNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.PAYMENT_ADD)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
    	ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpEnum<PaymentMethod>(drpPaymentMethod, null);
        drpBO.drpEnum<ChequeStatus>(drpChequeStatus, null);
        drpBO.drpDataBase(drpDistTransAccount, DrpDataType.FIRM_ACCOUNT, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        if (!group.Equals(distTransAmtModalError)) {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(CustomerPaymentNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(CustomerPaymentNavDTO navDto)
    {
        try
        {
            CustomerPaymentPageDTO customerPymtDTO = new CustomerPaymentPageDTO();
            pageModeHdn.Value = navDto.Mode.ToString();
            customerPymtDTO.IsPdcPayment = navDto.IsPdcPayment;
            Session[Constants.Session.PAGE_DATA] = customerPymtDTO;
            customerPymtDTO.PrevNavDTO = navDto.PrevNavDto;
            customerPymtDTO.PrUnitSaleDetail = paymentBO.fetchPrUnitDetails(getUserDefinitionDTO().FirmNumber, navDto.PrUnitSaleDetailId);
            //Derive PaymentMode
            PaymentMode PymtMode = (navDto.PymtMode != null) ? (PaymentMode)navDto.PymtMode : PaymentMode.Receivable;
            customerPymtDTO.PymtMode = PymtMode;
            if (isAddMode())
            {
                customerPymtDTO.MasterPymtTxDTO = createMPTDTOForAdd();
            } else {
                customerPymtDTO.isMultiplePymts = Constants.NO;
                customerPymtDTO.MasterPymtTxDTO = paymentBO.fetchMasterPymtTransactionDetails(navDto.MPTId);
            }
            fetchUnitPaymentHeaders(customerPymtDTO);
            populateUIOnInit(customerPymtDTO);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void navigateToPreviousPage()
    {
        CustomerPaymentPageDTO customerPymtDTO = getSessionPageData();
        if (customerPymtDTO != null && customerPymtDTO.PrevNavDTO != null)
        {
            object obj = customerPymtDTO.PrevNavDTO;
            if (obj is CustomerPymtHistoryNavDTO)
            {
                CustomerPymtHistoryNavDTO navDTO = (CustomerPymtHistoryNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.CUSTOMER_PYMT_HISTORY, true);
            }
            else if (obj is CustomerPymtSearchNavDTO)
            {
                CustomerPymtSearchNavDTO navDTO = (CustomerPymtSearchNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.CUSTOMER_PYMT_SEARCH, true);
            }
        }
        Response.Redirect(Constants.URL.CUSTOMER_PYMT_SEARCH, true);
    }
    private void renderPageFieldsWithEntitlement()
    {
        resetPageTitle();

        PaymentMethod pymtMethod = EnumHelper.ToEnum<PaymentMethod>(drpPaymentMethod.Text);
        pnlChequeSection.Visible = (PaymentMethod.CHEQUE == pymtMethod || PaymentMethod.DD == pymtMethod);
        pnlNonCashSection.Visible = (PaymentMethod.CASH != pymtMethod);
        lbTxDate.Text = (PaymentMethod.CHEQUE == pymtMethod || PaymentMethod.DD == pymtMethod) ? Resources.Labels.TX_CLEARANCE_DATE : Resources.Labels.TX_DATE;
    }
    private void resetPageTitle()
    {
        if (isAddMode()) lbPageTitle.Text = Constants.ICON.ADD + (IsPdcPayment() ? Resources.Labels.ADD_PDC : Resources.Labels.ADD_PAYMENT);
        else lbPageTitle.Text = Constants.ICON.MODIFY + Resources.Labels.MODIFY_PDC;
    }
    private CustomerPaymentPageDTO getSessionPageData()
    {
        return (CustomerPaymentPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private bool IsPdcPayment()
    {
        return getSessionPageData().IsPdcPayment;
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private bool isAddMode()
    {
        return CustomerPymtPageMode.ADD.ToString().Equals(pageModeHdn.Value);
    }
    private bool isModifyMode()
    {
        return CustomerPymtPageMode.MODIFY.ToString().Equals(pageModeHdn.Value);
    }
    private void fetchUnitPaymentHeaders(CustomerPaymentPageDTO customerPymtDTO) {
        PaymentMode? PymtModeToFetch = (!string.IsNullOrWhiteSpace(customerPymtDTO.isMultiplePymts)) ? (PaymentMode?)customerPymtDTO.PymtMode : null;
        IList<PrUnitSalePymtDTO> pymtHeadersList = paymentBO.fetchUnitPaymentHeaders(getUserDefinitionDTO().FirmNumber,
            customerPymtDTO.PrUnitSaleDetail.Id, PymtModeToFetch, true);
        customerPymtDTO.PymtHeaders = new List<PrUnitSalePymtDTO>(pymtHeadersList);
        if (PymtModeToFetch == null) setMultiplePymtFlag(customerPymtDTO);
        
        TotalPymtDTO totalPymtDTO = new TotalPymtDTO();
        foreach (PrUnitSalePymtDTO tmpPymtHeader in customerPymtDTO.PymtHeaders)
        {
            totalPymtDTO.TotalPymtAmt = Decimal.Add(totalPymtDTO.TotalPymtAmt, tmpPymtHeader.PaymentMaster.TotalAmt);
            totalPymtDTO.TotalPaidAmt = Decimal.Add(totalPymtDTO.TotalPaidAmt, tmpPymtHeader.PaymentMaster.TotalPaid);
            totalPymtDTO.TotalPendingAmt = Decimal.Add(totalPymtDTO.TotalPendingAmt, tmpPymtHeader.PaymentMaster.TotalPending);
            if(tmpPymtHeader.PaymentMaster.Status == PymtMasterStatus.Suspended) totalPymtDTO.PymtStatus = PymtMasterStatus.Suspended;
            else if (totalPymtDTO.PymtStatus != PymtMasterStatus.Suspended) {
                if (totalPymtDTO.TotalPendingAmt > 0) totalPymtDTO.PymtStatus = PymtMasterStatus.Pending;
                else totalPymtDTO.PymtStatus = PymtMasterStatus.Paid;
            }
        }
        customerPymtDTO.TotalPymtDTO = totalPymtDTO;
    }
    private void setMultiplePymtFlag(CustomerPaymentPageDTO customerPymtDTO) {
        if(string.IsNullOrWhiteSpace(customerPymtDTO.isMultiplePymts)) {
            customerPymtDTO.isMultiplePymts = Constants.NO;
            PaymentMode? PymtMode = null;
            foreach (PrUnitSalePymtDTO tmpPymtHeader in customerPymtDTO.PymtHeaders)
            {
                if(PymtMode == null) PymtMode = tmpPymtHeader.PymtMode;
                else if(PymtMode != tmpPymtHeader.PymtMode) {
                    customerPymtDTO.isMultiplePymts = Constants.YES;
                    break;
                }
            }
            //First time system fetches all Pymt headers, so remove for which pymtmode not same as current pymtmode.
            customerPymtDTO.PymtHeaders.RemoveAll(x => x.PymtMode != customerPymtDTO.PymtMode);
        }
    }
    private void populateUIOnInit(CustomerPaymentPageDTO customerPymtDTO) {
        soldUnitIcon.Visible = (customerPymtDTO.PrUnitSaleDetail.Status == PRUnitSaleStatus.Sold);
        cancelledUnitIcon.Visible = !soldUnitIcon.Visible;
        btnSoldUnitInfoHdn.Attributes["row-info"] = CommonUIConverter.getUnitInfo(customerPymtDTO.PrUnitSaleDetail);
        btnCancelledUnitInfoHdn.Attributes["row-info"] = CommonUIConverter.getUnitInfo(customerPymtDTO.PrUnitSaleDetail);
        btnCustomerHdn.Attributes["row-info"] = CommonUIConverter.getCustomerInfo(customerPymtDTO.PrUnitSaleDetail);
        lbUnitNo.Text = CommonUIConverter.getPropertyUnitFormattedNo(customerPymtDTO.PrUnitSaleDetail.PropertyUnit.Wing, customerPymtDTO.PrUnitSaleDetail.PropertyUnit.UnitNo);
        lbBookingRefNo.Text = customerPymtDTO.PrUnitSaleDetail.BookingRefNo;
        lbCustomerName.Text = CommonUIConverter.getCustomerFullName(customerPymtDTO.PrUnitSaleDetail.Customer.FirstName, customerPymtDTO.PrUnitSaleDetail.Customer.LastName);
        lbCustomerRefNo.Text = customerPymtDTO.PrUnitSaleDetail.Customer.CustRefNo;

        initUnitPymtHeaderSection(customerPymtDTO);
        populateTransactionFields(customerPymtDTO.MasterPymtTxDTO);
    }
    private void fetchAndInitUnitPymtHeaders(CustomerPaymentPageDTO customerPymtDTO) {
        fetchUnitPaymentHeaders(customerPymtDTO);
        initUnitPymtHeaderSection(customerPymtDTO);
    }
    private void initUnitPymtHeaderSection(CustomerPaymentPageDTO customerPymtDTO)
    {
        //Populate Selected Payment Mode(Receivable/Payable) Total amounts
        lbUnitPaymentMode.Text = customerPymtDTO.PymtMode.ToString();
        lnkPymtShuffle.Visible = Constants.YES.Equals(customerPymtDTO.isMultiplePymts);
        lbUnitPymtStatus.Text = customerPymtDTO.TotalPymtDTO.PymtStatus.ToString();
        if (customerPymtDTO.TotalPymtDTO.PymtStatus == PymtMasterStatus.Paid) spUnitPymtStatus.Attributes["class"] = "label label-success pull-right";
        else if (customerPymtDTO.TotalPymtDTO.PymtStatus == PymtMasterStatus.Pending) spUnitPymtStatus.Attributes["class"] = "label label-warning pull-right";
        else if (customerPymtDTO.TotalPymtDTO.PymtStatus == PymtMasterStatus.Suspended) spUnitPymtStatus.Attributes["class"] = "label label-default pull-right";
        lbUnitTotalAmt.Text = customerPymtDTO.TotalPymtDTO.TotalPymtAmt.ToString();
        lbUnitTotalPaid.Text = customerPymtDTO.TotalPymtDTO.TotalPaidAmt.ToString();
        lbUnitTotalPending.Text = customerPymtDTO.TotalPymtDTO.TotalPendingAmt.ToString();

        lbTransactionComment.Text = (customerPymtDTO.PymtMode == PaymentMode.Receivable) ? "Payment to be received from customer" : "Payment to be paid to customer";
        initPymtHeaders(customerPymtDTO);
        loadPaymentHeaderGrid(customerPymtDTO.PymtHeaders);
    }
    private void populateTransactionFields(MasterPymtTransactionDTO mptDTO) {
        if (IsPdcPayment())
        {
            drpPaymentMethod.Text = PaymentMethod.CHEQUE.ToString();
            drpPaymentMethod.Enabled = false;
            resetChequeFields();
        } else {
            txtTxDate.Text = DateUtil.getTodayDate();
        }
        if(isModifyMode()) {
            txtTxDate.Text = DateUtil.getCSDate(mptDTO.ClearanceDate);
            txtPaymentAmt.Text = mptDTO.PymtAmt.ToString();
            txtTxComments.Text = mptDTO.Comments;
            txtCollectionDate.Text = DateUtil.getCSDate(mptDTO.CollectionDate);
            txtChequeDate.Text = DateUtil.getCSDate(mptDTO.ChequeDate);
            txtPayName.Text = mptDTO.PayName;
            drpChequeStatus.Text = mptDTO.ChequeStatus.ToString();
            txtMediaNo.Text = mptDTO.MediaNo;
            txtBankName.Text = mptDTO.BankName;
            txtBranch.Text = mptDTO.Branch;
        }
    }
    private void initPymtHeaders(CustomerPaymentPageDTO customerPymtDTO)
    {
        FirmAccountDTO accountDTO = customerPymtDTO.PrUnitSaleDetail.PropertyUnit.PropertyTower.Property.FirmAccount;
        foreach (PrUnitSalePymtDTO pymtHeader in customerPymtDTO.PymtHeaders)
        {
            pymtHeader.PaymentMaster.UIPymtTransaction = getPymtTransactionForHeader(customerPymtDTO.MasterPymtTxDTO, pymtHeader, accountDTO);
        }
    }
    private PaymentTransactionDTO getPymtTransactionForHeader(MasterPymtTransactionDTO mptDTO, PrUnitSalePymtDTO pymtHeader, FirmAccountDTO accountDTO)
    {
        PaymentTransactionDTO pymtTxDTO = createEmptyPymtTransactionDTO(accountDTO, pymtHeader.PaymentMaster);
        if(isModifyMode()) {
            PaymentTransactionDTO tmpPymtTxDTO = mptDTO.PaymentTransactions.ToList<PaymentTransactionDTO>().Find(x => x.PaymentMaster.Id == pymtHeader.PaymentMaster.Id);
            if (tmpPymtTxDTO != null)
            {
                pymtTxDTO.Id = tmpPymtTxDTO.Id;
                pymtTxDTO.Amount = tmpPymtTxDTO.Amount;
                pymtTxDTO.Comments = tmpPymtTxDTO.Comments;
                pymtTxDTO.FirmAccount.Id = tmpPymtTxDTO.FirmAccount.Id;
                pymtTxDTO.FirmAccount.Name = tmpPymtTxDTO.FirmAccount.Name;
                pymtTxDTO.isUISelected = true;
            }
        } 
        return pymtTxDTO;
    }
    private void loadPaymentHeaderGrid(List<PrUnitSalePymtDTO> pymtHeaders)
    {
        paymentHeaderGrid.DataSource = pymtHeaders;
        paymentHeaderGrid.DataBind();
    }
    private PaymentTransactionDTO createEmptyPymtTransactionDTO(FirmAccountDTO accountDTO, PaymentMasterDTO paymentMasterDTO)
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        PaymentTransactionDTO pymtTransDto = new PaymentTransactionDTO();
        pymtTransDto.Amount = decimal.Zero;
        pymtTransDto.FirmAccount = accountDTO;
        pymtTransDto.FirmNumber = userDefDto.FirmNumber;
        pymtTransDto.InsertUser = userDefDto.Username;
        pymtTransDto.UpdateUser = userDefDto.Username;

        pymtTransDto.PaymentMaster = paymentMasterDTO;
        return pymtTransDto;
    }
    private decimal calculateRemainingPayment()
    {
        CustomerPaymentPageDTO customerPymtDTO = getSessionPageData();
        decimal distributedAmt = decimal.Zero;
        foreach (PrUnitSalePymtDTO tmpPymtHeader in customerPymtDTO.PymtHeaders)
        {
            if (tmpPymtHeader.PaymentMaster.UIPymtTransaction.isUISelected)
            {
                distributedAmt = Decimal.Add(distributedAmt, tmpPymtHeader.PaymentMaster.UIPymtTransaction.Amount);
            }
        }
        decimal remainingAmt = Decimal.Subtract(CommonUtil.getDecimaNotNulllWithoutExt(txtPaymentAmt.Text), distributedAmt);
        return (remainingAmt > 0) ? remainingAmt : decimal.Zero;
    }
    protected void onClickPymtShuffle(object sender, EventArgs e)
    {
        try
        {
            CustomerPaymentPageDTO customerPymtDTO = getSessionPageData();
            customerPymtDTO.PymtMode = (PaymentMode.Receivable == customerPymtDTO.PymtMode) ? PaymentMode.Payable : PaymentMode.Receivable;
            fetchAndInitUnitPymtHeaders(customerPymtDTO);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onChangePymtMethod(object sender, EventArgs e)
    {
        try
        {
            resetChequeFields();
            resetNonCashFields();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void savePaymentTransaction(object sender, EventArgs e)
    {
        try
        {
            if (validatePymtAddModify())
            {
                MasterPymtTransactionDTO masterPymtTransDTO = populateMasterPymtTransFromUI();
                string txRefNo = "";
                if(isAddMode()) {
                    txRefNo = paymentBO.addMasterPymtTransactionDetails(masterPymtTransDTO);
                } else {
                    txRefNo = paymentBO.updateMasterPymtTransactionDetails(masterPymtTransDTO);
                }
                string msg = "Payment is added successfully. Transaction Reference # " + txRefNo;
                if(IsPdcPayment()) {
                    if(masterPymtTransDTO.PymtStatus != MPTPymtStatus.Paid) {
                        msg = isAddMode() ? "Post Dated Cheque is added successfully. Media # " :
                            "Post Dated Cheque is updated successfully. Media # " ;
                        msg += masterPymtTransDTO.MediaNo;
                    }
                }
                Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg(msg));
                CustomerPymtHistoryNavDTO navDTO = new CustomerPymtHistoryNavDTO();
                navDTO.PrUnitSaleDetailId = getSessionPageData().PrUnitSaleDetail.Id;
                navDTO.PymtMode = masterPymtTransDTO.PymtMode;
                navDTO.isPdc = IsPdcPayment();
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.CUSTOMER_PYMT_HISTORY, true);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validatePymtAddModify()
    {
        if (IsPdcPayment()) return validateAddModifyPdcTransaction();
        else return validateAddPymtTransaction();
    }
    private bool validateAddModifyPdcTransaction()
    {
        bool isValid = validateMandatoryFields(pdcPymtError);
        if (isValid)
        {
            ChequeStatus chqStatus = EnumHelper.ToEnum<ChequeStatus>(drpChequeStatus.Text);
            DateTime? clearanceDate = DateUtil.getCSDate(txtTxDate.Text);
            DateTime? chequeDate = DateUtil.getCSDate(txtChequeDate.Text);
            DateTime collectionDate = DateUtil.getCSDateNotNull(txtCollectionDate.Text);
            if (CommonUtil.isGreaterThanToday(collectionDate))
            {
                setErrorMessage("Collection date cannot be in future.", pdcPymtError);
                return false;
            }
            if (CommonUtil.getDecimaNotNulllWithoutExt(txtPaymentAmt.Text) <= 0)
            {
                setErrorMessage("Please enter valid Payment Amount.", pdcPymtError);
                return false;
            }
            if (ChequeStatus.Collected != chqStatus && ChequeStatus.Returned != chqStatus)
            {
                if (chequeDate == null)
                {
                    setErrorMessage("Please select Cheque Date.", pdcPymtError);
                    return false;
                }
                if (collectionDate.CompareTo(chequeDate.Value) > 0)
                {
                    setErrorMessage("Collection Date cannot be greater than Cheque Date.", pdcPymtError);
                    return false;
                }
            }
            if (chqStatus == ChequeStatus.Cleared)
            {
                if (clearanceDate == null)
                {
                    setErrorMessage("Please enter Tx/Clearance Date.", pdcPymtError);
                    return false;
                }
                if (chequeDate.Value.CompareTo(clearanceDate.Value) > 0)
                {
                    setErrorMessage("Cheque Date cannot be greater than Clearance Date.", pdcPymtError);
                    return false;
                }
                if (CommonUtil.isGreaterThanToday(clearanceDate))
                {
                    setErrorMessage("Clearance date cannot be in future.", pdcPymtError);
                    return false;
                }
            }
            if (ChequeStatus.Deposited == chqStatus || ChequeStatus.Cleared == chqStatus) isValid = validatePaidAmounts();
            else if (ChequeStatus.Bounced == chqStatus || ChequeStatus.Returned == chqStatus) isValid = validateChqBouncedOrReturned();
        }
        return isValid;
    }
    private bool validateChqBouncedOrReturned()
    {
        List<PrUnitSalePymtDTO> prUnitPymtDTOs = getSessionPageData().PymtHeaders;
        foreach (PrUnitSalePymtDTO pymtHeader in prUnitPymtDTOs)
        {
            PaymentTransactionDTO pymtTransDTO = pymtHeader.PaymentMaster.UIPymtTransaction;
            if (pymtTransDTO.isUISelected && pymtTransDTO.Amount > 0)
            {
                setErrorMessage("Payment cannot be done if check is bounced/Returned. Please remove distributed payments.", pdcPymtError);
                return false;
            }
        }
        return true;
    }
    private bool validateAddPymtTransaction()
    {
        bool isValid = validateMandatoryFields(commonError);
        if(!isValid) {
            Page.Validate(chqPymtError);
            isValid = Page.IsValid;
        }
        if (!isValid)
        {
            isValid = validateMandatoryFields(nonCashPymtError);
        }
        if (isValid)
        {
            isValid = validatePaidAmounts();
        }
        return isValid;
    }
    private bool validateMandatoryFields(string valGrp)
    {
        Page.Validate(valGrp);
        bool isValid = Page.IsValid;
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    private bool validatePaidAmounts()
    {
        TotalPymtDTO totalPymtDTO = getSessionPageData().TotalPymtDTO;
        if (CommonUtil.getDecimaNotNulllWithoutExt(txtPaymentAmt.Text) > totalPymtDTO.TotalPendingAmt)
        {
            setErrorMessage("Payment Amount cannot be more than Total Pending amount of Unit.", commonError);
            return false;
        }
        decimal remainingAmt = calculateRemainingPayment();
        if (remainingAmt < 0)
        {
            setErrorMessage("Total distributed amount is more than Payment amount.", commonError);
            return false;
        }
        else if (remainingAmt > 0)
        {
            setErrorMessage("Total distributed amount is less than Payment amount.", commonError);
            return false;
        }
        return true;
    }
    private void resetChequeFields()
    {
        txtCollectionDate.Text = null;
        txtChequeDate.Text = null;
        txtPayName.Text = null;
        txtCollectionDate.Text = DateUtil.getTodayDate();
        if (IsPdcPayment())
        {
            drpChequeStatus.ClearSelection();
            drpChequeStatus.Enabled = true;
            lbTxDate.CssClass = lbTxDate.CssClass.Replace("required", "").Trim();
            lbChqDate.CssClass = lbChqDate.CssClass.Replace("required", "").Trim();
        }
        else drpChequeStatus.Text = ChequeStatus.Cleared.ToString();
        PaymentMethod pymtMethod = EnumHelper.ToEnum<PaymentMethod>(drpPaymentMethod.Text);
        lbBankName.CssClass = lbChqDate.CssClass.Replace("required", "").Trim() + ((pymtMethod == PaymentMethod.CHEQUE) ? " required" : "");
    }
    private void resetNonCashFields()
    {
        txtMediaNo.Text = null;
        txtBankName.Text = null;
        txtBranch.Text = null;
    }
    private MasterPymtTransactionDTO createMPTDTOForAdd()
    {
        MasterPymtTransactionDTO masterPymtTransDTO = new MasterPymtTransactionDTO();
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        masterPymtTransDTO.Property = CommonUIConverter.getPropertyDTO(getSessionPageData().PrUnitSaleDetail.PropertyUnit.PropertyTower.Property.Id.ToString(), "");
        masterPymtTransDTO.PaymentTransactions = new HashSet<PaymentTransactionDTO>();
        
        masterPymtTransDTO.FirmNumber = userDefDto.FirmNumber;
        masterPymtTransDTO.InsertUser = userDefDto.Username;
        masterPymtTransDTO.UpdateUser = userDefDto.Username;

        return masterPymtTransDTO;
    }
    private MasterPymtTransactionDTO populateMasterPymtTransFromUI()
    {
        MasterPymtTransactionDTO masterPymtTransDTO = getSessionPageData().MasterPymtTxDTO;
        if (isAddMode())
        {
            CustomerPaymentPageDTO customerPymtDTO = getSessionPageData();
            masterPymtTransDTO.PymtMode = customerPymtDTO.PymtMode;
            masterPymtTransDTO.MPTBook = customerPymtDTO.PrUnitSaleDetail.MPTUnitBook;
            masterPymtTransDTO.PymtMethod = EnumHelper.ToEnum<PaymentMethod>(drpPaymentMethod.Text);
        }        
        masterPymtTransDTO.TxDate = DateUtil.getCSDateNotNull(txtTxDate.Text);
        masterPymtTransDTO.PymtAmt = CommonUtil.getDecimaNotNulllWithoutExt(txtPaymentAmt.Text);
        masterPymtTransDTO.Comments = txtTxComments.Text;

        if (masterPymtTransDTO.PymtMethod == PaymentMethod.CHEQUE)
        {
            masterPymtTransDTO.CollectionDate = DateUtil.getCSDateNotNull(txtCollectionDate.Text);
            masterPymtTransDTO.ChequeDate = DateUtil.getCSDate(txtChequeDate.Text);
            masterPymtTransDTO.ClearanceDate = DateUtil.getCSDate(txtTxDate.Text);
            masterPymtTransDTO.PayName = txtPayName.Text;
            masterPymtTransDTO.ChequeStatus = EnumHelper.ToEnum<ChequeStatus>(drpChequeStatus.Text);
        }
        if (masterPymtTransDTO.PymtMethod != PaymentMethod.CASH)
        {
            masterPymtTransDTO.MediaNo = txtMediaNo.Text;
            masterPymtTransDTO.BankName = txtBankName.Text;
            masterPymtTransDTO.Branch = txtBranch.Text;
        }
        masterPymtTransDTO.PymtStatus = (IsPdcPayment() && masterPymtTransDTO.PymtMethod == PaymentMethod.CHEQUE && masterPymtTransDTO.ChequeStatus != ChequeStatus.Cleared) 
                        ? MPTPymtStatus.Pending : MPTPymtStatus.Paid;
        populatePaymentTransactions(masterPymtTransDTO);
        return masterPymtTransDTO;
    }
    private void populatePaymentTransactions(MasterPymtTransactionDTO masterPymtTransDTO)
    {
        List<PrUnitSalePymtDTO> prUnitPymtDTOs = getSessionPageData().PymtHeaders;
        List<PaymentTransactionDTO> tmpUIPymtTxDTOList = new List<PaymentTransactionDTO>();
        foreach (PrUnitSalePymtDTO pymtHeader in prUnitPymtDTOs)
        {
            PaymentTransactionDTO pymtTransDTO = pymtHeader.PaymentMaster.UIPymtTransaction;
            if (pymtTransDTO.isUISelected)
            {
                pymtTransDTO.TxDate = masterPymtTransDTO.TxDate;
                pymtTransDTO.Status = (masterPymtTransDTO.PymtStatus == MPTPymtStatus.Pending) ? PymtTransStatus.Pending : PymtTransStatus.Paid;
                if(pymtTransDTO.Status == PymtTransStatus.Paid)
                {    
                    pymtTransDTO.AccountTransaction = createAccountTransaction(pymtTransDTO, masterPymtTransDTO, pymtHeader);
                    pymtTransDTO.PaymentVoucherDTO = createPaymentVoucher(pymtTransDTO, masterPymtTransDTO, pymtHeader);
                }
                tmpUIPymtTxDTOList.Add(pymtTransDTO);
            }
        }
        if(isModifyMode()) {
            //In Modify Mode -> Replace Orginal PymtTxDTo to corresponding UI PymtTxDTO in tmpUIPymtTxDTOList.
            List<PaymentTransactionDTO> tmpOrgPymtTxDTOList = new List<PaymentTransactionDTO>(masterPymtTransDTO.PaymentTransactions);
            masterPymtTransDTO.PaymentTransactions.Clear();
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            foreach (PaymentTransactionDTO tmpUIPymtTxDTO in tmpUIPymtTxDTOList) {
                PaymentTransactionDTO tmpOrgPymtTxDTO = tmpOrgPymtTxDTOList.Find(x => x.PaymentMaster.Id == tmpUIPymtTxDTO.PaymentMaster.Id);
                if(tmpOrgPymtTxDTO != null) {
                    tmpOrgPymtTxDTO.TxDate = tmpUIPymtTxDTO.TxDate;
                    tmpOrgPymtTxDTO.Amount = tmpUIPymtTxDTO.Amount;
                    tmpOrgPymtTxDTO.Status = tmpUIPymtTxDTO.Status;
                    tmpOrgPymtTxDTO.Comments = tmpUIPymtTxDTO.Comments;
                    tmpOrgPymtTxDTO.FirmAccount = tmpUIPymtTxDTO.FirmAccount;
                    tmpOrgPymtTxDTO.AccountTransaction = tmpUIPymtTxDTO.AccountTransaction;
                    tmpOrgPymtTxDTO.PaymentVoucherDTO = tmpUIPymtTxDTO.PaymentVoucherDTO;
                    tmpOrgPymtTxDTO.UpdateUser = userDefDto.Username;
                    masterPymtTransDTO.PaymentTransactions.Add(tmpOrgPymtTxDTO);
                } else {
                    masterPymtTransDTO.PaymentTransactions.Add(tmpUIPymtTxDTO);
                }
                
            }
        } else {
            tmpUIPymtTxDTOList.ForEach(x => masterPymtTransDTO.PaymentTransactions.Add(x));
        }
    }
    private AccountTransactionDTO createAccountTransaction(PaymentTransactionDTO pymtTransDTO, MasterPymtTransactionDTO masterPymtTransDTO, PrUnitSalePymtDTO pymtHeader)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        AccountTransactionDTO acntTransDto = new AccountTransactionDTO();
        acntTransDto.FirmAccount = pymtTransDTO.FirmAccount;
        acntTransDto.TxType = (getSessionPageData().PymtMode == PaymentMode.Receivable) ?
                AcntTransStatus.Credit : AcntTransStatus.Debit;
        acntTransDto.Comments = getAccountTransactionComments(masterPymtTransDTO, pymtHeader);
        acntTransDto.TxDate = pymtTransDTO.TxDate;
        acntTransDto.Amount = pymtTransDTO.Amount;
        acntTransDto.FirmNumber = userDefDto.FirmNumber;
        acntTransDto.InsertUser = userDefDto.Username;
        acntTransDto.UpdateUser = userDefDto.Username;
        return acntTransDto;
    }
    private string getAccountTransactionComments(MasterPymtTransactionDTO masterPymtTransDTO, PrUnitSalePymtDTO pymtHeader)
    {
        string comments = "";
        CustomerDTO customerDTO = getSessionPageData().PrUnitSaleDetail.Customer;
        string pymtModeComment = CommonUtil.getAcntTransCommentPymtMethod(masterPymtTransDTO.PymtMethod, masterPymtTransDTO.MediaNo);
        string customerName = CommonUIConverter.getCustomerFullName(customerDTO.FirstName, customerDTO.LastName);
        if (masterPymtTransDTO.PymtMode == PaymentMode.Receivable)
        {
            comments = string.Format(Constants.PYMT_FROM, customerName) + "," + pymtModeComment
                   + "," + Constants.TX_REF + "," + string.Format(Constants.UNIT_SALE_TYPE + "{0}", pymtHeader.PymtType.Name);
        }
        else
        {
            comments = string.Format(Constants.PYMT_TO, customerName) + "," + pymtModeComment
                    + "," + Constants.TX_REF + "," + string.Format(Constants.UNIT_SALE_TYPE + "{0}", pymtHeader.PymtType.Name);
        }
        return comments;
    }
    private PaymentVoucherDTO createPaymentVoucher(PaymentTransactionDTO pymtTransDto, MasterPymtTransactionDTO masterPymtTransDTO, PrUnitSalePymtDTO pymtHeader)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        PaymentVoucherDTO paymentVoucherDto = new PaymentVoucherDTO();
        PaymentLedgerDTO billPaymentLedgerDto = new PaymentLedgerDTO();
        BillAllocationDTO billAllocationDTO = new BillAllocationDTO();
        PaymentLedgerDTO bankPaymentLedgerDto = new PaymentLedgerDTO();
        BankAllocationDTO bankAllocationDTO = new BankAllocationDTO();
        paymentVoucherDto.PaymentLedgers = new HashSet<PaymentLedgerDTO>();
        populatePaymentVoucher(pymtTransDto, paymentVoucherDto, masterPymtTransDTO, pymtHeader);
        CustomerDTO customerDTO = getSessionPageData().PrUnitSaleDetail.Customer;
        string ledgerName = CommonUIConverter.getCustomerFullName(customerDTO.FirstName, 
                customerDTO.MiddleName ,customerDTO.LastName);
        if (masterPymtTransDTO.PymtMode == PaymentMode.Receivable)
        {
            paymentVoucherDto.VoucherType = Constants.VOUCHER_TYPE_RECEIPT;
            paymentVoucherDto.PartyLedgerName = ledgerName;
            billPaymentLedgerDto.LedgerName = ledgerName;
            billPaymentLedgerDto.Amount = pymtTransDto.Amount;
            bankPaymentLedgerDto.Amount = -pymtTransDto.Amount;
            if (masterPymtTransDTO.PymtMethod != PaymentMethod.CASH)
            {
                billAllocationDTO.Amount = pymtTransDto.Amount;
                bankAllocationDTO.Amount = -pymtTransDto.Amount;
                bankAllocationDTO.BankPartyName = ledgerName;
            }
        }
        else
        {
            paymentVoucherDto.VoucherType = Constants.VOUCHER_TYPE_PAYMENT;
            paymentVoucherDto.PartyLedgerName = ledgerName;
            billPaymentLedgerDto.LedgerName = ledgerName;
            billPaymentLedgerDto.Amount = -pymtTransDto.Amount;
            bankPaymentLedgerDto.Amount = pymtTransDto.Amount;
            if (masterPymtTransDTO.PymtMethod != PaymentMethod.CASH)
            {
                billAllocationDTO.Amount = -pymtTransDto.Amount;
                bankAllocationDTO.Amount = pymtTransDto.Amount;
                bankAllocationDTO.BankPartyName = ledgerName;
            }
        }
        populateBillPaymentLedger(pymtTransDto, billPaymentLedgerDto);
        if (masterPymtTransDTO.PymtMethod != PaymentMethod.CASH)
        {
            populateBillAllocationDto(pymtTransDto, billAllocationDTO, ledgerName);
            billPaymentLedgerDto.BillAllocations = new HashSet<BillAllocationDTO>();
            billPaymentLedgerDto.BillAllocations.Add(billAllocationDTO);
            bankAllocationDTO.BDate = pymtTransDto.TxDate;
            if (masterPymtTransDTO.PymtMethod == PaymentMethod.CHEQUE)
            {
                bankAllocationDTO.InstrumentDate = (DateTime)masterPymtTransDTO.ChequeDate;
                bankAllocationDTO.ChequeCrossComment = Constants.VOUCHER_CHEQUE_COMMENT;
                bankAllocationDTO.InstrumentNumber = masterPymtTransDTO.MediaNo;
            }
            else
            {
                bankAllocationDTO.InstrumentDate = pymtTransDto.TxDate;
                bankAllocationDTO.InstrumentNumber = pymtTransDto.Id.ToString();
            }
            populateBankAllocationDto(pymtTransDto, bankAllocationDTO, masterPymtTransDTO);
            bankPaymentLedgerDto.BankAllocations = new HashSet<BankAllocationDTO>();
            bankPaymentLedgerDto.BankAllocations.Add(bankAllocationDTO);
        }
        if (masterPymtTransDTO.PymtMethod == PaymentMethod.CASH)
        {
            bankPaymentLedgerDto.LedgerName = Constants.VOUCHER_LEDGERNAME_CASH;
        }
        else
        {
            bankPaymentLedgerDto.LedgerName = masterPymtTransDTO.BankName;
        }
        populateBankPaymentLedgerDto(pymtTransDto, bankPaymentLedgerDto);
        paymentVoucherDto.PaymentLedgers.Add(billPaymentLedgerDto);
        paymentVoucherDto.PaymentLedgers.Add(bankPaymentLedgerDto);
        return paymentVoucherDto;
    }
    private void populatePaymentVoucher(PaymentTransactionDTO pymtTransDto, PaymentVoucherDTO paymentVoucherDto, MasterPymtTransactionDTO masterPymtTransDTO,
            PrUnitSalePymtDTO pymtHeader)
    {
        paymentVoucherDto.Action = Constants.VOUCHER_CREATE_ACTION;
        paymentVoucherDto.VoucherDate = pymtTransDto.TxDate;
        paymentVoucherDto.VoucherNaration = getAccountTransactionComments(masterPymtTransDTO, pymtHeader);
        paymentVoucherDto.VoucherEffectiveDate = pymtTransDto.TxDate;
        paymentVoucherDto.VoucherNumber = pymtTransDto.Id.ToString();
        paymentVoucherDto.HasCashFlow = Constants.VOUCHER_YES;
        paymentVoucherDto.PostingStatus = Constants.VOUCHER_PENDING;
        paymentVoucherDto.FirmNumber = pymtTransDto.FirmNumber;
        paymentVoucherDto.InsertUser = pymtTransDto.InsertUser;
        paymentVoucherDto.UpdateUser = pymtTransDto.UpdateUser;
    }
    private static void populateBillPaymentLedger(PaymentTransactionDTO pymtTransDto, PaymentLedgerDTO billPaymentLedgerDto)
    {
        billPaymentLedgerDto.LedgerType = Constants.VOUCHER_BILL_LEDGERTYPE;
        billPaymentLedgerDto.IsDeemedPositive = Constants.VOUCHER_NO;
        billPaymentLedgerDto.LedgerFromItem = Constants.VOUCHER_NO;
        billPaymentLedgerDto.RemoveZeroEntries = Constants.VOUCHER_NO;
        billPaymentLedgerDto.IsPartyLedger = Constants.VOUCHER_YES;
        billPaymentLedgerDto.IsLastDeemedPositive = Constants.VOUCHER_NO;
        billPaymentLedgerDto.VatexpAmount = 0.0M;
        billPaymentLedgerDto.FirmNumber = pymtTransDto.FirmNumber;
        billPaymentLedgerDto.InsertUser = pymtTransDto.InsertUser;
        billPaymentLedgerDto.UpdateUser = pymtTransDto.UpdateUser;
    }
    private static void populateBillAllocationDto(PaymentTransactionDTO pymtTransDto, BillAllocationDTO billAllocationDTO, string ledgerName)
    {
        billAllocationDTO.Name = ledgerName;
        billAllocationDTO.BillType = Constants.VOUCHER_BILLTYPE;
        billAllocationDTO.TdsDeductSpecialRate = Constants.VOUCHER_NO;
        billAllocationDTO.FirmNumber = pymtTransDto.FirmNumber;
        billAllocationDTO.InsertUser = pymtTransDto.InsertUser;
        billAllocationDTO.UpdateUser = pymtTransDto.UpdateUser;
    }
    private static void populateBankAllocationDto(PaymentTransactionDTO pymtTransDto, BankAllocationDTO bankAllocationDTO, MasterPymtTransactionDTO masterPymtTransDTO)
    {
        bankAllocationDTO.Name = masterPymtTransDTO.BankName;
        bankAllocationDTO.TransactionType = masterPymtTransDTO.PymtMethod.GetDescription();
        bankAllocationDTO.BankName = masterPymtTransDTO.BankName;
        bankAllocationDTO.BankBranchName = masterPymtTransDTO.Branch;
        bankAllocationDTO.UniqueReferenceNumber = pymtTransDto.Id.ToString();
        bankAllocationDTO.Status = Constants.VOUCHER_NO;
        bankAllocationDTO.PaymentMode = masterPymtTransDTO.PymtMethod.GetDescription();
        bankAllocationDTO.IsConnectedPayment = Constants.VOUCHER_NO;
        bankAllocationDTO.IsSplit = Constants.VOUCHER_NO;
        bankAllocationDTO.IsContractUsed = Constants.VOUCHER_NO;
        bankAllocationDTO.FirmNumber = pymtTransDto.FirmNumber;
        bankAllocationDTO.InsertUser = pymtTransDto.InsertUser;
        bankAllocationDTO.UpdateUser = pymtTransDto.UpdateUser;
    }
    private static void populateBankPaymentLedgerDto(PaymentTransactionDTO pymtTransDto, PaymentLedgerDTO bankPaymentLedgerDto)
    {
        bankPaymentLedgerDto.LedgerType = Constants.VOUCHER_BANK_LEDGERTYPE;
        bankPaymentLedgerDto.IsDeemedPositive = Constants.VOUCHER_NO;
        bankPaymentLedgerDto.LedgerFromItem = Constants.VOUCHER_NO;
        bankPaymentLedgerDto.RemoveZeroEntries = Constants.VOUCHER_NO;
        bankPaymentLedgerDto.IsPartyLedger = Constants.VOUCHER_YES;
        bankPaymentLedgerDto.IsLastDeemedPositive = Constants.VOUCHER_NO;
        bankPaymentLedgerDto.VatexpAmount = 0.0M;
        bankPaymentLedgerDto.FirmNumber = pymtTransDto.FirmNumber;
        bankPaymentLedgerDto.InsertUser = pymtTransDto.InsertUser;
        bankPaymentLedgerDto.UpdateUser = pymtTransDto.UpdateUser;
    }
    //Distribute Transaction Amount Modal - Start
    private void initDistTransAmtSectionFields(PrUnitSalePymtDTO pymtHeader)
    {
        lbDistTransAmtPymtHeader.Text = pymtHeader.PymtType.Name;
        lbDistTransAmtRemainingAmt.Text = calculateRemainingPayment().ToString();
        drpDistTransAccount.Text = pymtHeader.PaymentMaster.UIPymtTransaction.FirmAccount.Id.ToString();
        txtDistTransAmount.Text = (pymtHeader.PaymentMaster.UIPymtTransaction.Amount > 0) ? pymtHeader.PaymentMaster.UIPymtTransaction.Amount.ToString() : null;
        txtDistTransComments.Text = pymtHeader.PaymentMaster.UIPymtTransaction.Comments;
    }
    private void setSelectedPymtHeader(long Id)
    {
        CustomerPaymentPageDTO custPymtDTO = getSessionPageData();
        custPymtDTO.PymtHeaders.ForEach(c => c.isUISelected = false);
        if (Id > 0) custPymtDTO.PymtHeaders.Find(c => c.Id == Id).isUISelected = true;
    }
    private PrUnitSalePymtDTO getSelectedPymtHeader(long Id)
    {
        CustomerPaymentPageDTO custPymtDTO = getSessionPageData();
        return (Id > 0) ? custPymtDTO.PymtHeaders.Find(c => c.Id == Id) : custPymtDTO.PymtHeaders.Find(c => c.isUISelected);
    }
    protected void onClickDistributeAmtBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedPymtHeader(selectedIndex);
            initDistTransAmtSectionFields(getSelectedPymtHeader(0));
            activeModalHdn.Value = distTransAmtModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickClearDistrubutedAmtBtn(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            CustomerPaymentPageDTO custPymtDTO = getSessionPageData();
            PrUnitSalePymtDTO pymtHeaderDTO = custPymtDTO.PymtHeaders.Find(x => x.Id == selectedIndex);
            pymtHeaderDTO.PaymentMaster.UIPymtTransaction = createEmptyPymtTransactionDTO(custPymtDTO.PrUnitSaleDetail.PropertyUnit.PropertyTower.Property.FirmAccount,
                pymtHeaderDTO.PaymentMaster);
            setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format("Amount distributed to '{0}' is removed successfully.", pymtHeaderDTO.PymtType.Name)));
            loadPaymentHeaderGrid(custPymtDTO.PymtHeaders);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void saveDistTransAmt(object sender, EventArgs e)
    {
        try
        {
            if (validateDistTransAmt())
            {
                PrUnitSalePymtDTO pymtHeaderDTO = getSelectedPymtHeader(0);
                pymtHeaderDTO.PaymentMaster.UIPymtTransaction.FirmAccount = CommonUIConverter.getFirmAccountDTO(drpDistTransAccount.Text, drpDistTransAccount.SelectedItem.Text);
                pymtHeaderDTO.PaymentMaster.UIPymtTransaction.Amount = CommonUtil.getDecimaNotNulllWithoutExt(txtDistTransAmount.Text);
                pymtHeaderDTO.PaymentMaster.UIPymtTransaction.Comments = txtDistTransComments.Text;
                pymtHeaderDTO.PaymentMaster.UIPymtTransaction.isUISelected = true;
                loadPaymentHeaderGrid(getSessionPageData().PymtHeaders);
            }
            else
            {
                activeModalHdn.Value = distTransAmtModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelDistTransAmtModal(object sender, EventArgs e)
    {
        try
        {
            setSelectedPymtHeader(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateDistTransAmt()
    {
        Page.Validate(distTransAmtModalError);
        bool isValid = Page.IsValid;
        if (isValid)
        {
            decimal transAmt = CommonUtil.getDecimaNotNulllWithoutExt(txtDistTransAmount.Text);
            if (transAmt <= 0)
            {
                setErrorMessage("Please enter Amount.", distTransAmtModalError);
                return false;
            }
            PrUnitSalePymtDTO pymtHeaderDTO = getSelectedPymtHeader(0);
            if (transAmt > pymtHeaderDTO.PaymentMaster.TotalPending)
            {
                setErrorMessage("Transaction amount cannot be more than pending amount of Payment Type.", distTransAmtModalError);
                return false;
            }
            decimal remainingAmt = calculateRemainingPayment();
            remainingAmt = Decimal.Add(remainingAmt, pymtHeaderDTO.PaymentMaster.UIPymtTransaction.Amount);
            remainingAmt = Decimal.Subtract(remainingAmt, transAmt);
            if (remainingAmt < 0)
            {
                setErrorMessage("Total distributed amount is more than Payment amount.", distTransAmtModalError);
                lbDistTransAmtRemainingAmt.Text = remainingAmt.ToString();
                isValid = false;
            }
        }
        return isValid;
    }
    //Distribute Transaction Amount Modal - End
}