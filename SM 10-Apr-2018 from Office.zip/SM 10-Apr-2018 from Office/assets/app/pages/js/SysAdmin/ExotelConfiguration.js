﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initExotelConfigGrid();
	formatFields(controlToFormat);
    showModal(controlToFormat);
}
function initExotelConfigGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#ExotelConfigSearchBtnDiv",
        pageLength: 5,
        hideSearch: true
    };

    $("[id$='ExotelConfigGrid']").CSBasicDatatable(dtOptions);
}