﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initUserLeadHistorySearchGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initUserLeadHistorySearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        pageLength: 10,
        hideSearch: true
    };

    $("[id$='userLeadHistorySearchGrid']").CSBasicDatatable(dtOptions);
}




