﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initAvailableUnitSearchGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initAvailableUnitSearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        rowInfoModalTitle: "Unit Details",
        pageLength: 10
    };

    $("[id$='availableUnitSearchGrid']").CSBasicDatatable(dtOptions);
}




