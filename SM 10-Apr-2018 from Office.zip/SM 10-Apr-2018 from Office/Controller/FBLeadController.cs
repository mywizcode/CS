﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ConstroSoft.Logic.CachingProvider;

namespace ConstroSoft.Controller
{
    public class FBLeadController : ApiController
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        FBIntegrationBO fBIntegrationBO = new FBIntegrationBO();
        EnquiryBO enquiryBO = new EnquiryBO();
        PropertyBO propertyBO = new PropertyBO();
        LoginBO loginBO = new LoginBO();

        [HttpPost]
        [ActionName("PostLead")]
        public string PostLead([FromBody]FacebookLeadDTO inputDTO)
        {
        	List<string> responseJson = new List<string>();
        	try
            {
        		if(inputDTO == null) throw new CustomException("Input object cannot be NULL.");
        		
        		responseJson = validateInputFields(inputDTO);
                if(responseJson.Count == 0) {
                	
                	PropertyDTO propertyDTO = propertyBO.fetchPropertyByName(inputDTO.PropertyName);
                	if(propertyDTO == null) throw new CustomException("Property does not exist in system.");
                	UserDefinitionDTO userDefDTO = loginBO.fetchSystemUser(Constants.SYSDEFAULT.SYSADMIN_USER);
                	if(userDefDTO == null) throw new CustomException("Internal error - System User not created.");
                	//Override User's Firm Number
                	userDefDTO.FirmNumber = propertyDTO.FirmNumber;
                	
                	VwEnquiryLead dupLeadEnquiry = fetchDuplicateLeadOrEnquiry(propertyDTO.Id, inputDTO.Contact);
                	if(dupLeadEnquiry == null) {
                		LeadDetailDTO leadDTO = createLeadDTO(inputDTO, propertyDTO, userDefDTO);
                		NotificationCacheProvider.Instance.markNewLeadFlag();
                    	string leadRefNo = enquiryBO.addLeadDetails(leadDTO, userDefDTO, "FACEBOOK");
                    	responseJson.Add(string.Format("Lead {0} is logged successfully.", leadRefNo));
                	} else {
                		//Add activity on lead or enquiry.
                		if(Constants.VW_ENTITY_TYPE_EQ.Equals(dupLeadEnquiry.EntityType)) {
                			enquiryBO.addEnquiryActivityForFacebook(dupLeadEnquiry.EntityId, userDefDTO);
                		} else {
                			enquiryBO.addLeadActivityForFacebook(dupLeadEnquiry.EntityId, userDefDTO);
                		}
                	}
                }                
            }
        	catch (Exception exp)
            {
                log.Error("Unexpected error while posting new lead through Facebook.", exp);
                responseJson.Add(CommonUtil.getErrorMessage(exp));
            }
        	return JsonConvert.SerializeObject(responseJson);
        }
        
        private List<string> validateInputFields(FacebookLeadDTO inputDTO)
        {
        	List<string> responseJson = validateInputMandatoryFields(inputDTO);
        	if(responseJson.Count == 0 && !fBIntegrationBO.validatePortalToken(inputDTO.TokenNumber)) {
        		responseJson.Add("Authorization has been denied for this request, please login again.");
        	}
            return responseJson;
        }
        private List<string> validateInputMandatoryFields(FacebookLeadDTO inputDTO)
        {
        	List<string> responseJson = new List<string>();
            if (string.IsNullOrWhiteSpace(inputDTO.TokenNumber)) responseJson.Add("Token number is mandatory.");
            if (string.IsNullOrWhiteSpace(inputDTO.PropertyName)) responseJson.Add("Property Name is mandatory.");
            if (string.IsNullOrWhiteSpace(inputDTO.FirstName)) responseJson.Add("First Name is mandatory.");
            if (string.IsNullOrWhiteSpace(inputDTO.LastName)) responseJson.Add("Last Name is mandatory.");
            if (string.IsNullOrWhiteSpace(inputDTO.Contact)) responseJson.Add("Contact is mandatory.");
            return responseJson;
        }
        private VwEnquiryLead fetchDuplicateLeadOrEnquiry(long propertyId, string contact) {
        	VwEnquiryLead openLeadOrEnquiry = null;
        	IList<VwEnquiryLead> enqLeadList = enquiryBO.fetchDuplicateEnquiryOrLead(propertyId, contact, "");
        	if(enqLeadList != null && enqLeadList.Count > 0) openLeadOrEnquiry = enqLeadList[0];
        	return openLeadOrEnquiry;
        }
        private LeadDetailDTO createLeadDTO(FacebookLeadDTO inputDTO, PropertyDTO propertyDTO, UserDefinitionDTO userDefDTO) {
        	MasterDataBO masterDataBO = new MasterDataBO(); 
        	
        	LeadDetailDTO tmpDTO = new LeadDetailDTO();
        	string tmpSalutation = (!string.IsNullOrWhiteSpace(inputDTO.Salutation)) ? inputDTO.Salutation : Constants.SYSDEFAULT.MCD_SALUTATION_MR;
        	tmpDTO.Salutation = masterDataBO.getMasterDataType(propertyDTO.FirmNumber, MasterDataType.SALUTATION.ToString(), tmpSalutation);
        	tmpDTO.FirstName = inputDTO.FirstName;
        	tmpDTO.LastName = inputDTO.LastName;
        	tmpDTO.LeadDate = DateUtil.getUserLocalDateTime();
        	tmpDTO.ContactInfo = new ContactInfoDTO();
        	tmpDTO.ContactInfo.Contact = inputDTO.Contact;
        	tmpDTO.ContactInfo.Email = inputDTO.Email;
        	tmpDTO.Property = new PropertyDTO();
        	tmpDTO.Property.Id = propertyDTO.Id;
        	tmpDTO.Source = masterDataBO.getMasterDataType(propertyDTO.FirmNumber, MasterDataType.ENQUIRY_SOURCE.ToString(), Constants.SYSDEFAULT.MCD_FACEBOOK);
        	tmpDTO.Status = LeadStatus.Open;
        	tmpDTO.FirmNumber = propertyDTO.FirmNumber;
        	tmpDTO.InsertUser = userDefDTO.Username;
        	tmpDTO.UpdateUser = userDefDTO.Username;
        	
        	return tmpDTO;
        }
    }
}