﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;
using System.Data.SqlClient;


/// <summary>
/// Summary description for PropertyAlertBO
/// </summary>
namespace ConstroSoft
{
    public class SystemAdminstrationBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public SystemAdminstrationBO() { }

        public IList<SecurityQuestionDTO> fetchSecurityQuestions()
        {
            ISession session = null;
            IList<SecurityQuestionDTO> result = new List<SecurityQuestionDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	SecurityQuestion x = null;
                    	
                    	IList<SecurityQuestion> tmpResult = session.QueryOver<SecurityQuestion>().List<SecurityQuestion>();
                    	if(tmpResult != null) {
                    		foreach(SecurityQuestion tmpObj in tmpResult) {
                                SecurityQuestionDTO tmpDTO = DomainToDTOUtil.convertToSecurityQuestionDTO(tmpObj, true);
                    			result.Add(tmpDTO);
                    		}
                    	}
                    } catch (Exception e)
                    {
                        log.Error("Exception while fetching Security Questions:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public void saveOrUpdateSecurityQuestion(SecurityQuestionDTO tmpDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	SecurityQuestion tmpObj = null;
                    	if(tmpDTO.Id > 0) {
                            tmpObj = session.Get<SecurityQuestion>(tmpDTO.Id);
                            DTOToDomainUtil.populateSecurityQuestionUpdateFields(tmpObj, tmpDTO);
                            session.Update(tmpObj);
                    	} else {
                            tmpObj = DTOToDomainUtil.populateSecurityQuestionAddFields(tmpDTO);
                            session.Save(tmpObj);
                            tmpDTO.Id = tmpObj.Id;
                    	}
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while adding or updating Security Question:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void deleteSecurityQuestion(long Id)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	SecurityQuestion tmpObj = session.Get<SecurityQuestion>(Id);
                        session.Delete(tmpObj);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while deleting Security Question:", e);
                        throw new CustomException(CommonUtil.getActualErrorMsg(e, "Security Question"));
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public IList<CityDTO> fetchAllCities(long StateId)
        {
        	ISession session = null;
        	IList<CityDTO> result = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				City city = null;
        				State state = null;
        				
        				CityDTO cityDTO = null;                    	
        				var proj = Projections.ProjectionList()
        						.Add(Projections.Property(() => city.Id).WithAlias(() => cityDTO.Id))
        						.Add(Projections.Property(() => city.Name).WithAlias(() => cityDTO.Name))
        						.Add(Projections.Property(() => city.Abbreviation).WithAlias(() => cityDTO.Abbreviation))
                                .Add(Projections.Property(() => state.Id), "State.Id");
        				var query = session.QueryOver<City>(() => city)
        						.Inner.JoinAlias(() => city.State, () => state);
                        result = query.Where(() => state.Id == StateId).Select(proj)
        							.TransformUsing(new DeepTransformer<CityDTO>()).List<CityDTO>();
        				
        			} catch (Exception e)
        			{
        				log.Error("Exception while fetching all Cities:", e);
        				throw new CustomException(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        	return result;
        }
        public IList<StateDTO> fetchAllStates(long CountryId)
        {
            ISession session = null;
            IList<StateDTO> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	State state = null;
                    	Country cnt = null;
                    	
	                    StateDTO stateDTO = null;                    	
	                    var proj = Projections.ProjectionList()
	                    		.Add(Projections.Property(() => state.Id).WithAlias(() => stateDTO.Id))
	                    		.Add(Projections.Property(() => state.Name).WithAlias(() => stateDTO.Name))
	                    		.Add(Projections.Property(() => state.Abbreviation).WithAlias(() => stateDTO.Abbreviation))
	                    		.Add(Projections.Property(() => cnt.Id), "Country.Id");
	                    var query = session.QueryOver<State>(() => state)
	                    		.Inner.JoinAlias(() => state.Country, () => cnt);
	                    result = query.Where(() => cnt.Id == CountryId).Select(proj)
	                    			.TransformUsing(new DeepTransformer<StateDTO>()).List<StateDTO>();
	                    
                    } catch (Exception e)
                    {
                        log.Error("Exception while fetching all States:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public IList<CountryDTO> fetchAllCountries()
        {
            ISession session = null;
            IList<CountryDTO> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	Country cnt = null;                    	
                    	CountryDTO cntDTO = null;                    	
                    	var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => cnt.Id).WithAlias(() => cntDTO.Id))
                                .Add(Projections.Property(() => cnt.Name).WithAlias(() => cntDTO.Name))
                                .Add(Projections.Property(() => cnt.Abbreviation).WithAlias(() => cntDTO.Abbreviation));
	                    var query = session.QueryOver<Country>(() => cnt);
                        result = query.Select(proj)
	                                .TransformUsing(new DeepTransformer<CountryDTO>()).List<CountryDTO>();
	                    
                    } catch (Exception e)
                    {
                        log.Error("Exception while fetching all countries:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public void saveOrUpdateCountry(CountryDTO tmpDTO)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				Country tmpObj = null;
        				if(tmpDTO.Id > 0) {
                            tmpObj = session.Get<Country>(tmpDTO.Id);
                            DTOToDomainUtil.populateCountryUpdateFields(tmpObj, tmpDTO);
                            session.Update(tmpObj);
        				} else {
                            tmpObj = DTOToDomainUtil.populateCountryAddFields(tmpDTO);
                            session.Save(tmpObj);
                            tmpDTO.Id = tmpObj.Id;
        				}
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while adding or updating Country:", e);
        				throw new CustomException(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
        public void saveOrUpdateState(StateDTO tmpDTO)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				State tmpObj = null;
        				if(tmpDTO.Id > 0) {
                            tmpObj = session.Get<State>(tmpDTO.Id);
                            DTOToDomainUtil.populateStateUpdateFields(tmpObj, tmpDTO);
                            session.Update(tmpObj);
        				} else {
                            tmpObj = DTOToDomainUtil.populateStateAddFields(tmpDTO);
                            session.Save(tmpObj);
                            tmpDTO.Id = tmpObj.Id;
        				}
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while adding or updating State:", e);
        				throw new CustomException(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
        public void saveOrUpdateCity(CityDTO tmpDTO)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				City tmpObj = null;
        				if(tmpDTO.Id > 0) {
                            tmpObj = session.Get<City>(tmpDTO.Id);
                            DTOToDomainUtil.populateCityUpdateFields(tmpObj, tmpDTO);
                            session.Update(tmpObj);
        				} else {
                            tmpObj = DTOToDomainUtil.populateCityAddFields(tmpDTO);
                            session.Save(tmpObj);
                            tmpDTO.Id = tmpObj.Id;
        				}
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while adding or updating City:", e);
        				throw new CustomException(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
        public void deleteCountry(long Id)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				Country tmpObj = session.Get<Country>(Id);
        				session.Delete(tmpObj);
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while deleting Country:", e);
                        throw new CustomException(CommonUtil.getActualErrorMsg(e, "Country"));
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
        public void deleteState(long Id)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				State tmpObj = session.Get<State>(Id);
        				session.Delete(tmpObj);
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while deleting State:", e);
                        throw new CustomException(CommonUtil.getActualErrorMsg(e, "State"));
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
        public void deleteCity(long Id)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				City tmpObj = session.Get<City>(Id);
        				session.Delete(tmpObj);
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while deleting City:", e);
                        throw new CustomException(CommonUtil.getActualErrorMsg(e, "City"));
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
        public void saveOrUpdateReportTemplateMaster(ReportTemplateMasterDTO tmpDTO)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				ReportTemplateMaster tmpObj = null;
        				if(tmpDTO.Id > 0) {
        					tmpObj = session.Get<ReportTemplateMaster>(tmpDTO.Id);
        					DTOToDomainUtil.populateReportTemplateMasterUpdateFields(tmpObj, tmpDTO);
        					session.Update(tmpObj);
        				} else {
        					tmpObj = DTOToDomainUtil.populateReportTemplateMasterAddFields(tmpDTO);
        					session.Save(tmpObj);
        					tmpDTO.Id = tmpObj.Id;
        				}
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while adding or updating ReportTemplateMaster:", e);
        				throw new CustomException(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
        public IList<UserRoleDTO> fetchUserRoles(string FirmNumber)
        {
        	ISession session = null;
        	IList<UserRoleDTO> result = new List<UserRoleDTO>();
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				IList<UserRole> tmpResult = session.QueryOver<UserRole>().Where(x => x.FirmNumber == FirmNumber).List<UserRole>();
        				if(tmpResult != null) {
        					foreach(UserRole tmpObj in tmpResult) {
        						UserRoleDTO tmpDTO = DomainToDTOUtil.convertToUserRoleDTO(tmpObj, true);
        						result.Add(tmpDTO);
        					}
        				}
        			} catch (Exception e)
        			{
        				log.Error("Exception while fetching User Roles:", e);
        				throw new CustomException(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        	return result;
        }
        public void saveOrUpdateUserRole(UserRoleDTO tmpDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        UserRole tmpObj = null;
                        if (tmpDTO.Id > 0)
                        {
                            tmpObj = session.Get<UserRole>(tmpDTO.Id);
                            DTOToDomainUtil.populateUserRoleUpdateFields(tmpObj, tmpDTO);
                            session.Update(tmpObj);
                        }
                        else
                        {
                            tmpObj = DTOToDomainUtil.populateUserRoleAddFields(tmpDTO);
                            session.Save(tmpObj);
                            tmpDTO.Id = tmpObj.Id;
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while adding or updating UserRole:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void deleteUserRole(long Id)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				UserRole tmpObj = session.Get<UserRole>(Id);
        				session.Delete(tmpObj);
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
                        tx.Rollback();
        				log.Error("Exception while deleting User Role:", e);
                        throw new CustomException(CommonUtil.getActualErrorMsg(e, "User Role"));
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
        public IList<PortalUserDTO> fetchPortalUsers(string FirmNumber)
        {
        	ISession session = null;
        	IList<PortalUserDTO> result = new List<PortalUserDTO>();
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				IList<PortalUser> tmpResult = session.QueryOver<PortalUser>().Where(x => x.FirmNumber == FirmNumber).List<PortalUser>();
        				if(tmpResult != null) {
        					foreach(PortalUser tmpObj in tmpResult) {
        						PortalUserDTO tmpDTO = DomainToDTOUtil.convertToPortalUserDTO(tmpObj);
        						result.Add(tmpDTO);
        					}
        				}
        			} catch (Exception e)
        			{
        				log.Error("Exception while fetching Portal User:", e);
        				throw new CustomException(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        	return result;
        }
        public void saveOrUpdatePortalUser(PortalUserDTO tmpDTO)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				PortalUser tmpObj = null;
        				if(tmpDTO.Id > 0) {
        					tmpObj = session.Get<PortalUser>(tmpDTO.Id);
        					DTOToDomainUtil.populatePortalUserUpdateFields(tmpObj, tmpDTO);
        					session.Update(tmpObj);
        				} else {
        					tmpObj = DTOToDomainUtil.populatePortalUserAddFields(tmpDTO);
        					session.Save(tmpObj);
        					tmpDTO.Id = tmpObj.Id;
        				}
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while adding or updating Portal User:", e);
        				throw new CustomException(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
        public void deletePortalUser(long Id)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				PortalUser tmpObj = session.Get<PortalUser>(Id);
        				session.Delete(tmpObj);
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while deleting Portal User:", e);
        				throw new CustomException(CommonUtil.getActualErrorMsg(e, "Portal User"));
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
    }
}