﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;


/// <summary>
/// Summary description for MarketingCampaignBO
/// </summary>
namespace ConstroSoft
{
    public class MarketingCampaignBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public MarketingCampaignBO() { }

        public IList<EmailSmsStoreDTO> fetchEmailSmsStoreGridData(string firmNumber, EmailSmsStoreFilterDTO filterDTO)
        {
            ISession session = null;
            IList<EmailSmsStoreDTO> result = new List<EmailSmsStoreDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	EmailSmsStore ec = null;
                        EmailSmsStoreDTO esDto = null;
                        FirmMember cb = null;
                        FirmMember ub = null;
                        
                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => ec.Id).WithAlias(() => esDto.Id))
                                    .Add(Projections.Property(() => ec.RefNo).WithAlias(() => esDto.RefNo))
                                    .Add(Projections.Property(() => ec.Name).WithAlias(() => esDto.Name))
                                    .Add(Projections.Property(() => ec.RecordType).WithAlias(() => esDto.RecordType))
                                    .Add(Projections.Property(() => ec.SystemDefined).WithAlias(() => esDto.SystemDefined))
                                    .Add(Projections.Property(() => ec.Status).WithAlias(() => esDto.Status))
                                    .Add(Projections.Property(() => cb.FirstName), "CreatedBy.FirstName")
                                    .Add(Projections.Property(() => cb.LastName), "CreatedBy.LastName")
                                    .Add(Projections.Property(() => ec.CreateDate).WithAlias(() => esDto.CreateDate))
                                    .Add(Projections.Property(() => ub.FirstName), "UpdatedBy.FirstName")
                                    .Add(Projections.Property(() => ub.LastName), "UpdatedBy.LastName")
                                    .Add(Projections.Property(() => ec.LastUpdateDate).WithAlias(() => esDto.LastUpdateDate));
                        var query = session.QueryOver<EmailSmsStore>(() => ec)
                            .Inner.JoinAlias(() => ec.CreatedBy, () => cb)
                            .Inner.JoinAlias(() => ec.UpdatedBy, () => ub);
                        if (filterDTO != null)
                        {
                            ICriteria criteria = query.RootCriteria;
                            if (!string.IsNullOrWhiteSpace(filterDTO.RefNo))
                            {
                                criteria.Add(Restrictions.InsensitiveLike(CommonUtil.BuildProjection<EmailSmsStore>(() => ec, x => x.RefNo), filterDTO.RefNo, MatchMode.Anywhere));
                            }
                            if (!string.IsNullOrWhiteSpace(filterDTO.Name))
                            {
                                criteria.Add(Restrictions.InsensitiveLike(CommonUtil.BuildProjection<EmailSmsStore>(() => ec, x => x.Name), filterDTO.Name, MatchMode.Anywhere));
                            }
                            if (filterDTO.Type != null)
                            {
                            	criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<EmailSmsStore>(() => ec, x => x.RecordType), filterDTO.Type));
                            }
                            if (filterDTO.Status != null)
                            {
                            	criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<EmailSmsStore>(() => ec, x => x.Status), filterDTO.Status));
                            }
                        }
                        result = query.Where(() => (ec.FirmNumber == firmNumber
                                    || (ec.FirmNumber == Constants.SYSDEFAULT.DEFAULT_FIRM && ec.Status == EmailSmsStoreStatus.Published)))
                            .Select(proj)
                            .OrderBy(() => ec.InsertDate).Desc()
                            .TransformUsing(new DeepTransformer<EmailSmsStoreDTO>()).List<EmailSmsStoreDTO>();
                    } catch (Exception e)
                    {
                    	log.Error("Unexpected error fetching data for Email and SMS Store search grid:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public IList<EmailSmsCampaignDTO> fetchEmailSmsCampaignGridData(string firmNumber, EmailSMSCampaignFilterDTO filterDTO)
        {
        	ISession session = null;
        	IList<EmailSmsCampaignDTO> result = new List<EmailSmsCampaignDTO>();
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				EmailSmsCampaign ec = null;
        				EmailSmsCampaignDTO esDto = null;
        				FirmMember cb = null;
        				FirmMember ub = null;
        				
        				var proj = Projections.ProjectionList()
        							.Add(Projections.Property(() => ec.Id).WithAlias(() => esDto.Id))
        							.Add(Projections.Property(() => ec.RefNo).WithAlias(() => esDto.RefNo))
        							.Add(Projections.Property(() => ec.Name).WithAlias(() => esDto.Name))
        							.Add(Projections.Property(() => ec.RecordType).WithAlias(() => esDto.RecordType))
        							.Add(Projections.Property(() => ec.Status).WithAlias(() => esDto.Status))
        							.Add(Projections.Property(() => ec.Stage).WithAlias(() => esDto.Stage))
                                    .Add(Projections.Property(() => ec.ScheduleOption).WithAlias(() => esDto.ScheduleOption))
        							.Add(Projections.Property(() => ec.ScheduledDate).WithAlias(() => esDto.ScheduledDate))
        							.Add(Projections.Property(() => cb.FirstName), "CreatedBy.FirstName")
        							.Add(Projections.Property(() => cb.LastName), "CreatedBy.LastName")
        							.Add(Projections.Property(() => ec.CreateDate).WithAlias(() => esDto.CreateDate))
        							.Add(Projections.Property(() => ub.FirstName), "UpdatedBy.FirstName")
        							.Add(Projections.Property(() => ub.LastName), "UpdatedBy.LastName")
        							.Add(Projections.Property(() => ec.LastUpdateDate).WithAlias(() => esDto.LastUpdateDate));
        				var query = session.QueryOver<EmailSmsCampaign>(() => ec)
        					.Inner.JoinAlias(() => ec.CreatedBy, () => cb)
        					.Inner.JoinAlias(() => ec.UpdatedBy, () => ub);
        				if (filterDTO != null)
        				{
        					ICriteria criteria = query.RootCriteria;
        					if (!string.IsNullOrWhiteSpace(filterDTO.RefNo))
        					{
        						criteria.Add(Restrictions.InsensitiveLike(CommonUtil.BuildProjection<EmailSmsCampaign>(() => ec, x => x.RefNo), filterDTO.RefNo, MatchMode.Anywhere));
        					}
        					if (!string.IsNullOrWhiteSpace(filterDTO.Name))
        					{
        						criteria.Add(Restrictions.InsensitiveLike(CommonUtil.BuildProjection<EmailSmsCampaign>(() => ec, x => x.Name), filterDTO.Name, MatchMode.Anywhere));
        					}
        					if (filterDTO.Type != null)
        					{
        						criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<EmailSmsCampaign>(() => ec, x => x.RecordType), filterDTO.Type));
        					}
        					if (filterDTO.Stage != null)
        					{
        						criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<EmailSmsCampaign>(() => ec, x => x.Stage), filterDTO.Stage));
        					}
        				}
        				result = query.Where(() => ec.FirmNumber == firmNumber)
        					.Select(proj)
                            .OrderBy(() => ec.InsertDate).Desc()
        					.TransformUsing(new DeepTransformer<EmailSmsCampaignDTO>()).List<EmailSmsCampaignDTO>();
        			} catch (Exception e)
        			{
        				log.Error("Unexpected error fetching data for Email and SMS Campaign search grid:", e);
        				throw new Exception(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        	return result;
        }
        public EmailSmsStoreDTO fetchEmailSmsTemplate(long Id)
        {
            ISession session = null;
            EmailSmsStoreDTO result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	EmailSmsStore tmpObj = session.Get<EmailSmsStore>(Id);
                    	result = DomainToDTOUtil.convertToEmailSmsStoreDTO(tmpObj, true, true);
                    	
                    } catch (Exception e)
                    {
                        log.Error("Exception while fetching Email SMS Template for given Id:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public long addOrModifyEmailSmsStoreTemplate(EmailSmsStoreDTO templateDTO)
        {
            ISession session = null;
            long Id = 0;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	EmailSmsStore template = null;
                    	if(templateDTO.Id > 0) {
                    		template = session.Get<EmailSmsStore>(templateDTO.Id);
                    		DTOToDomainUtil.populateEmailSmsStoreUpdateFields(template, templateDTO);
                    	} else {
                            template = DTOToDomainUtil.populateEmailSmsStoreAddFields(templateDTO);
                    		session.Save(template);
                    		template.RefNo = CommonUtil.getEmailSmsStoreRefNo(template.Id);
                    	}
                    	session.Update(template);
                    	Id = template.Id;
                        tx.Commit();
                    } catch (Exception e)
                    {
                    	tx.Rollback();
                        log.Error("Exception while add or modify of email template:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        public void deleteEmailSmsStoreTemplate(long Id)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EmailSmsStore template =  session.Get<EmailSmsStore>(Id);
                        session.Delete(template);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while deleting email template:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void unPublishEmailSmsStoreTemplate(long Id, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EmailSmsStore tmpObj = session.Get<EmailSmsStore>(Id);
                        tmpObj.Status = EmailSmsStoreStatus.Draft;
                        tmpObj.UpdateDate = DateUtil.getUserLocalDateTime();
                        tmpObj.UpdateUser = userDefDTO.Username;
                        session.Update(tmpObj);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while unpublishing email template :", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public EmailSmsCampaignDTO fetchEmailSmsCampaign(long Id)
        {
            ISession session = null;
            EmailSmsCampaignDTO result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EmailSmsCampaign tmpObj = session.Get<EmailSmsCampaign>(Id);
                        result = DomainToDTOUtil.convertToEmailSmsCampaignDTO(tmpObj, true, true);

                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while fetching Email SMS Campaign for given Id:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public long addOrModifyEmailSmsCampaign(EmailSmsCampaignDTO campaignDTO)
        {
            ISession session = null;
            long Id = 0;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EmailSmsCampaign campaign = null;
                        if (campaignDTO.Id > 0)
                        {
                            campaign = session.Get<EmailSmsCampaign>(campaignDTO.Id);
                            DTOToDomainUtil.populateEmailSmsCampaignUpdateFields(campaign, campaignDTO);
                        }
                        else
                        {
                            campaign = DTOToDomainUtil.populateEmailSmsCampaignAddFields(campaignDTO);
                            session.Save(campaign);
                            campaign.RefNo = CommonUtil.getEmailSmsCampaignRefNo(campaign.Id);
                        }
                        session.Update(campaign);
                        Id = campaign.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while add or modify of email campaign:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        public void deleteEmailSmsCampaign(long Id)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EmailSmsCampaign campaign =  session.Get<EmailSmsCampaign>(Id);
                        session.Delete(campaign);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while deleting email or sms campaign:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void stopCampaign(long Id, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EmailSmsCampaign tmpObj = session.Get<EmailSmsCampaign>(Id);
                        if (tmpObj.ScheduleOption == EmailSmsScheduleOption.Now) tmpObj.ScheduledDate = null;
                        tmpObj.Stage = EmailSmsCampaignStage.Draft;
                        tmpObj.Status = EmailSmsCampaignStatus.NotStarted;
                        tmpObj.UpdateDate = DateUtil.getUserLocalDateTime();
                        tmpObj.UpdateUser = userDefDTO.Username;
                        session.Update(tmpObj);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while stopping email or SMS campaign :", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public IList<EmailSmsCampaignDTO> fetchCampaignsToSchedule()
        {
            ISession session = null;
            IList<EmailSmsCampaignDTO> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	EmailSmsCampaign ec = null;

                    	EmailSmsCampaignDTO ecDto = null;
                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => ec.Id).WithAlias(() => ecDto.Id))
                                    .Add(Projections.Property(() => ec.ScheduledDate).WithAlias(() => ecDto.ScheduledDate));
                        result = session.QueryOver<EmailSmsCampaign>(() => ec)
                                .Select(proj)
                                .Where(() => ec.Stage == EmailSmsCampaignStage.Scheduled)
                                .TransformUsing(new DeepTransformer<EmailSmsCampaignDTO>()).List<EmailSmsCampaignDTO>();
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while fetching email or SMS campaign which are to be scheduled:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public EmailSmsCampaignDTO fetchEmailSMSCampaignSelective(long Id)
        {
            ISession session = null;
            EmailSmsCampaignDTO result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	EmailSmsCampaign ec = null;

                    	EmailSmsCampaignDTO ecDto = null;
                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => ec.Id).WithAlias(() => ecDto.Id))
                                    .Add(Projections.Property(() => ec.Name).WithAlias(() => ecDto.Name))
                                    .Add(Projections.Property(() => ec.ScheduledDate).WithAlias(() => ecDto.ScheduledDate))
                                    .Add(Projections.Property(() => ec.Stage).WithAlias(() => ecDto.Stage))
                                    .Add(Projections.Property(() => ec.Status).WithAlias(() => ecDto.Status));
                        result = session.QueryOver<EmailSmsCampaign>(() => ec)
                                .Select(proj)
                                .Where(() => ec.Id == Id)
                                .TransformUsing(new DeepTransformer<EmailSmsCampaignDTO>()).SingleOrDefault<EmailSmsCampaignDTO>();
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while fetching email or SMS campaign, selective fields:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public void updateCampaignStatus(long Id, EmailSmsCampaignStatus status, string message)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EmailSmsCampaign tmpObj = session.Get<EmailSmsCampaign>(Id);
                        if(status == EmailSmsCampaignStatus.Inprogress) {
                        	tmpObj.StartTime = DateUtil.getUserLocalDateTime();
                        } else {
                        	tmpObj.EndTime = DateUtil.getUserLocalDateTime();
                        }
                        if(status == EmailSmsCampaignStatus.Success || status == EmailSmsCampaignStatus.Failed) tmpObj.Stage = EmailSmsCampaignStage.Completed;
                        tmpObj.Status = status;
                        tmpObj.Message = message;
                        session.Update(tmpObj);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating email or SMS campaign status from Job:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public object[] fetchDataForEmailSMSCampaignJob(long CampaignId)
        {
        	object[] tmpResult = new object[2];
            ISession session = null;
            EmailSmsCampaignDTO CampaignDTO = null;
        	try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	EmailSmsCampaign campaign = session.Get<EmailSmsCampaign>(CampaignId);
                    	CampaignDTO = DomainToDTOUtil.convertToEmailSmsCampaignDTO(campaign, true, true);
                    	
                    	string UnitSaleDetailStatus = "";
                		IList<VwCustomer> customerList = null;
                		//It is assumed that there would be only one recipient distribution list selection on UI
                		foreach(EmailSmsCampaignRecipient rCriteria in campaign.Recipients) 
                		{
                			long PropertyId = rCriteria.PropertyId;
                			long TowerId = (EmailSmsRcpntType.ONLY_SOLD_UNIT_CUSTOMERS == rCriteria.RecipientType) ? rCriteria.TowerId : 0;
                			
                			List<string> EntityTypeList = new List<string>();
                            if (EmailSmsRcpntType.ALL_LEADS == rCriteria.RecipientType) {
                            	EntityTypeList.Add(Constants.VWCustomerEntityType.ENQUIRY);
                            	EntityTypeList.Add(Constants.VWCustomerEntityType.LEAD);
                            }
                            else if (EmailSmsRcpntType.ALL_CUSTOMERS == rCriteria.RecipientType || EmailSmsRcpntType.ONLY_SOLD_UNIT_CUSTOMERS == rCriteria.RecipientType) {
                            	EntityTypeList.Add(Constants.VWCustomerEntityType.UNIT_OWNER);
                            	EntityTypeList.Add(Constants.VWCustomerEntityType.UNIT_CO_OWNER);
                            	if (EmailSmsRcpntType.ONLY_SOLD_UNIT_CUSTOMERS == rCriteria.RecipientType) {
                                	UnitSaleDetailStatus = "S";
                                }
                            }
                            VwCustomer vw= null;
                            var query = session.QueryOver<VwCustomer>(() => vw).Where(() => vw.FirmNumber == campaign.FirmNumber);
                            
                            if (PropertyId > 0) query.Where(() => vw.PropertyId == PropertyId);
                            if (EntityTypeList.Count > 0) query.WhereRestrictionOn(() => vw.EntityType).IsIn(EntityTypeList);
                            if (TowerId > 0) query.Where(() => vw.TowerId == TowerId);
                            if (!string.IsNullOrWhiteSpace(UnitSaleDetailStatus)) query.Where(() => vw.Status == UnitSaleDetailStatus);
                            
                            customerList = query.List<VwCustomer>();
                		}
                		
                		tmpResult[0] = CampaignDTO;
                		tmpResult[1] = customerList;
                    } catch (Exception e)
                    {
                        log.Error("Exception while fetching required data for Email/SMS Campaign job:", e);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        	return tmpResult;
        }
    }
}