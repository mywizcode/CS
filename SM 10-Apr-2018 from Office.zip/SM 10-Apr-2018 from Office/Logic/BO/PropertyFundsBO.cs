﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NHibernate;
using NHibernate.Criterion;

namespace ConstroSoft.Logic.BO
{
    public class PropertyFundsBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public PropertyFundsBO() { }

        public IList<PropertyFundsDTO> fetchAccountDepositGridData(string firmNumber, PropertyFundFilterDTO filterDTO, long propertyId)
        {
            ISession session = null;
            IList<PropertyFundsDTO> firmAccountDepositList = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyFundsDTO propertyFundsDTO = null;
                        PropertyFunds pf = null;
                        FirmAccount acnt = null;
                        Property pr = null;
                        var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => pf.Id).WithAlias(() => propertyFundsDTO.Id))
                            .Add(Projections.Property(() => acnt.Id), "FirmAccount.Id")
                            .Add(Projections.Property(() => acnt.Name), "FirmAccount.Name")
                            .Add(Projections.Property(() => pf.TxDate).WithAlias(() => propertyFundsDTO.TxDate))
                            .Add(Projections.Property(() => pf.PymtMethod).WithAlias(() => propertyFundsDTO.PymtMethod))
                            .Add(Projections.Property(() => pf.Amount).WithAlias(() => propertyFundsDTO.Amount))
                            .Add(Projections.Property(() => pf.MediaNo).WithAlias(() => propertyFundsDTO.MediaNo))
                            .Add(Projections.Property(() => pf.PymtStatus).WithAlias(() => propertyFundsDTO.Status));
                        var query = session.QueryOver<PropertyFunds>(() => pf)
                            .JoinAlias(() => pf.FirmAccount,() => acnt)
                            .JoinAlias(() => pf.Property, () => pr);
                            
                        if (filterDTO != null)
                        {
                            ICriteria criteria = query.RootCriteria;
                            if (filterDTO.AccountName != null)
                            {
                                 criteria.Add(Restrictions.InsensitiveLike(CommonUtil.BuildProjection<FirmAccount>(() => acnt, x => x.Name), filterDTO.AccountName, MatchMode.Anywhere));
                            }
                            if (filterDTO.PymtMethod != null)
                            {
                               criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<PropertyFunds>(() => pf, x => x.PymtMethod), filterDTO.PymtMethod));
                            }
                            if (filterDTO.MediaNo != null)
                            {
                                 criteria.Add(Restrictions.InsensitiveLike(CommonUtil.BuildProjection<PropertyFunds>(() => pf, x => x.MediaNo), filterDTO.MediaNo, MatchMode.Anywhere));
                            }
                         }
                       firmAccountDepositList = query.Where(() => pf.FirmNumber == firmNumber && pr.Id == propertyId)
                            .Select(proj).TransformUsing(new DeepTransformer<PropertyFundsDTO>()).List<PropertyFundsDTO>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching firm account deposit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return firmAccountDepositList;
        }

        public PropertyFundsDTO fetchDeposit(long Id)
        {
            ISession session = null;
            PropertyFundsDTO accountDepositDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyFunds FirmAcntDepositDO = session.Get<PropertyFunds>(Id);
                        accountDepositDto = DomainToDTOUtil.convertToPropertyFundDTO(FirmAcntDepositDO, true);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Account Deposit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return accountDepositDto;
        }

        public void deleteDeposit(long Id, AccountTransactionDTO acntTransDto, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	PropertyFunds fundDeposit = session.Get<PropertyFunds>(Id);
                    	fundDeposit.PymtStatus = PropertyFundStatus.Reversed;
                    	fundDeposit.UpdateDate = DateUtil.getUserLocalDateTime();
                    	fundDeposit.UpdateUser = userDefDTO.Username;
                        fundDeposit.AccountTransactions.Add(DTOToDomainUtil.populateAccountTransactionAddFields(acntTransDto));
                        session.Update(fundDeposit);
                        FirmAccount firmAccount = session.Get<FirmAccount>(acntTransDto.FirmAccount.Id);
                        firmAccount.AccountBalance = Decimal.Subtract(firmAccount.AccountBalance, fundDeposit.Amount);
                        session.Update(firmAccount);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while deleting Account Deposit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }

        public long saveDeposit(PropertyFundsDTO depositDto, AccountTransactionDTO acntTransDto)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        /*PropertyFunds fundDeposit = DTOToDomainUtil.populatePropertyFundsAddFields(depositDto);
                        session.Save(fundDeposit);

                        AccountTransaction trans = DTOToDomainUtil.populateAccountTransactionAddFields(acntTransDto);
                        trans.PropertyFunds = fundDeposit;
                        session.Save(trans);*/
                    	
                    	PropertyFunds fundDeposit = DTOToDomainUtil.populatePropertyFundsAddFields(depositDto);
                    	fundDeposit.AccountTransactions.Add(DTOToDomainUtil.populateAccountTransactionAddFields(acntTransDto));
                        session.Save(fundDeposit);

                        Id = fundDeposit.Id;

                        FirmAccount firmAccount = session.Get<FirmAccount>(depositDto.FirmAccount.Id);
                        firmAccount.AccountBalance = Decimal.Add(firmAccount.AccountBalance, fundDeposit.Amount);
                        session.Update(firmAccount);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Account Deposit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }

    }

}