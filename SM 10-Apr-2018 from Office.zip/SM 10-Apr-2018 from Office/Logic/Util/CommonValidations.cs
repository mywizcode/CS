﻿using ConstroSoft;
using System.Collections.Generic;
using NHibernate.Criterion;
using System.Linq.Expressions;
using NHibernate.Impl;
using System;
using System.Web.UI.WebControls;
using System.Globalization;
namespace ConstroSoft
{
    public class CommonValidations
    {
        public CommonValidations() { }
        public static string validateUnitSaleDates(DateTime bookingDate, DateTime? possessionDate, DateTime? agreementDate, string agreementNo,
            IsAgreementDone isAgreementDone, IsPossessionDone isPossessionDone)
        {
            string errorMessage = "";
            if (IsAgreementDone.Yes == isAgreementDone)
            {
                if (agreementDate == null) return Resources.Messages.AGREENENT_DATE_REQUIRED;
                else if (agreementDate != null && agreementDate.Value.CompareTo(DateUtil.getUserLocalDate()) > 0) return "Agreement Date cannot be in future.";
                else if (string.IsNullOrWhiteSpace(agreementNo)) return Resources.Messages.AGREENENT_NO_REQUIRED;
            }
            if (IsPossessionDone.Yes == isPossessionDone)
            {
                if (possessionDate == null) return Resources.Messages.POSSESSION_DATE_REQUIRED;
                else if (possessionDate != null && possessionDate.Value.CompareTo(DateUtil.getUserLocalDate()) > 0) return "Possession Date cannot be in future.";
                else if (IsAgreementDone.No == isAgreementDone || agreementDate == null) return Resources.Messages.ERROR_AGREEMENT_AFTER_POSSESSION;
            }
            if (agreementDate != null && bookingDate.CompareTo(agreementDate.Value) > 0)
            {
                return Resources.Messages.ERROR_BOOKING_AFTER_AGREEMENT;
            }
            if (possessionDate != null)
            {
                if (agreementDate == null || agreementDate.Value.CompareTo(possessionDate.Value) > 0)
                {
                    errorMessage = Resources.Messages.ERROR_AGREEMENT_AFTER_POSSESSION;
                }
            }
            return errorMessage;
        }
        public static bool validateEnquiryLeadAssignment(FirmMember firmMember, long propertyId)
        {
            bool isValid = false;

            if (firmMember.User.Status == UserStatus.Active)
            {
                foreach (PropertyFMAccess access in firmMember.PropertyFMAccess)
                {
                    if (access.Property.Id == propertyId && access.HasAccess == PrFMAccess.Yes)
                    {
                        isValid = true;
                        break;
                    }
                }
            }
            return isValid;
        }
    }
}