﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft.Logic.BO;
using CrystalDecisions.CrystalReports.Engine;

namespace ConstroSoft.View.CRM.ReportsAndAnalytics
{
    public partial class LeadAndEnquiryUserReport : System.Web.UI.Page
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string commonError = "commonError";
        EnquiryBO enquiryBO = new EnquiryBO();
        ReportConfigBO reportConfigBO = new ReportConfigBO();
        LeadEnquiryReportBO leadEnquiryReportBO = new LeadEnquiryReportBO();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (ApplicationUtil.isSessionActive(Session))
                {
                    LeadEnquiryUserReportNavDTO navDto = ApplicationUtil.getPageNavDTO<LeadEnquiryUserReportNavDTO>(Session);
                    if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.LEAD_ENQUIRY_USER_REPORT)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                    if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, true);
                }
            }
        }
        protected void Page_PreRender(object sender, EventArgs e)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                if (ApplicationUtil.isSubPageRendered(Page))
                {
                    (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                    preRenderInitFormElements();
                }
                if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        private void preRenderInitFormElements()
        {
            renderPageLayout();
        }
        public void initBootstrapComponantsFromServer()
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
        }
        private UserDefinitionDTO getUserDefinitionDTO()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }
        private void initDropdowns()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }

        public void setErrorMessage(string message, string group)
        {
            string[] pageErrorGrp = { commonError };
            if (pageErrorGrp.Contains(group))
            {
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            else
            {
                CustomValidator val = new CustomValidator();
                val.IsValid = false;
                val.ErrorMessage = message;
                val.ValidationGroup = group;
                this.Page.Validators.Add(val);
            }
        }
        private void doInit(LeadEnquiryUserReportNavDTO navDto)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        private void initPageAfterRedirect(LeadEnquiryUserReportNavDTO navDto)
        {
            try
            {
                LeadEnquiryUserReportNavDTO leadEnquiryUserReportNavDTO = new LeadEnquiryUserReportNavDTO();
                Session[Constants.Session.PAGE_DATA] = leadEnquiryUserReportNavDTO;
                if (navDto != null) leadEnquiryUserReportNavDTO.PrevNavDto = navDto.PrevNavDto;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                throw exp;
            }
        }
        private void renderPageLayout()
        {
            setPageTitle();
        }
        private void setPageTitle()
        {

        }
        private EnquiryandLeadUserReportPageDTO getSessionPageData()
        {
            return (EnquiryandLeadUserReportPageDTO)Session[Constants.Session.PAGE_DATA];
        }
        private bool validateMandatoryFields()
        {
            Page.Validate(commonError);
            bool isValid = Page.IsValid;
            if (!isValid)
            {
                (this.Master as CSMaster).setPageErrorInNotyMsg(Page.Validators);
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;

        }
        public void onClickGenerateReport(object sender, EventArgs e)
        {
            try
            {
                if (validateMandatoryFields())
                {
                    UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
                    ReportTemplateMasterDTO reportConfigDTO = null;
                    long propertyId = 0;
                    propertyId = CommonUtil.getCurrentPropertyDTO(userDefDto).Id;
                    IList<AllEnquiryLeadUIDTO> result = enquiryBO.fetchAllEnquiryLeadData(propertyId);
                    ReportDocument letterReportDocument = new ReportDocument();
                    DataTable enquiryDataTable = populateEnquiryDataTable();
                    DataTable leadDataTable = populateLeadDataTable();
                    reportConfigDTO = reportConfigBO.fetchPropertyReportTemplate(propertyId, ReportTemplateType.ENQ_LEAD_REPORT.GetDescription());
                    if (result.Count > 0)
                    {
                        string reportPath = Server.MapPath(reportConfigDTO.Path);
                        letterReportDocument.Load(reportPath);
                        letterReportDocument.Database.Tables["EnquiryReport"].SetDataSource(enquiryDataTable);
                        letterReportDocument.Database.Tables["LeadReport"].SetDataSource(leadDataTable);
                        try
                        {
                            letterReportDocument.ExportToHttpResponse
                            (CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, true, "ReportsAndAnalitics");
                        }
                        catch (Exception exp)
                        {

                        }
                    }
                    else
                    {
                        setErrorMessage(Resources.Messages.SOLD_UNIT_NOT_PRESENT, commonError);
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, commonError);
            }
        }
        private DataTable populateLeadDataTable()
        {
            DataTable leadDataTable = new DataTable();
            leadDataTable.Columns.Add("TotalLoggedLead", typeof(Int32));
            leadDataTable.Columns.Add("TotalOpenLead", typeof(Int32));
            leadDataTable.Columns.Add("TotalLostLead", typeof(Int32));
            leadDataTable.Columns.Add("TotalOwnedLead", typeof(Int32));
            leadDataTable.Columns.Add("TotalProcessedLead", typeof(Int32));
            
            PropertyDTO propertyDTO = CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO());
            object[] leadStats = leadEnquiryReportBO.fetchLeadStatsForReport(propertyDTO.Id, Convert.ToDateTime(txtFromDate.Text), Convert.ToDateTime(txtToDate.Text));
            LeadsOpenedGadgetDTO leadsOpenedGadgetDTO = (LeadsOpenedGadgetDTO)leadStats[0];
            LeadsProcessedCountDTO leadsProcessedDto = (LeadsProcessedCountDTO)leadStats[2];
            
            DataRow leadRow = leadDataTable.NewRow();
            leadRow["TotalLoggedLead"] = leadsOpenedGadgetDTO.TotalCount;
            leadRow["TotalOpenLead"] = leadsOpenedGadgetDTO.AverageOpened;
            leadRow["TotalLostLead"] = leadsProcessedDto.TotalLost;
            leadRow["TotalOwnedLead"] = leadsProcessedDto.TotalConverted;
            leadRow["TotalProcessedLead"] = leadsProcessedDto.TotalProcessed;
            leadDataTable.Rows.Add(leadRow);
            return leadDataTable;
        }
        
        private DataTable populateEnquiryDataTable()
        {
            DataTable enquiryDataTable = new DataTable();
            enquiryDataTable.Columns.Add("TotalLoggedEnquiry", typeof(Int32));
            enquiryDataTable.Columns.Add("TotalOpenEnquiry", typeof(Int32));
            enquiryDataTable.Columns.Add("TotalLostEnquiry", typeof(Int32));
            enquiryDataTable.Columns.Add("TotalOwnedEnquiry", typeof(Int32));
            enquiryDataTable.Columns.Add("PropertyName", typeof(string));
            enquiryDataTable.Columns.Add("FromDate", typeof(DateTime));
            enquiryDataTable.Columns.Add("ToDate", typeof(DateTime));
            
            PropertyDTO propertyDTO = CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO());
            object[] enquiryStats = leadEnquiryReportBO.fetchEnquiryStatsForReport(propertyDTO.Id, Convert.ToDateTime(txtFromDate.Text), Convert.ToDateTime(txtToDate.Text));
            EnquiryCountStatsDTO enqCountStatsDTO = (EnquiryCountStatsDTO)enquiryStats[3];

            DataRow enquiryRow = enquiryDataTable.NewRow();
            enquiryRow["TotalLoggedEnquiry"] = enqCountStatsDTO.TotalLogged;
            enquiryRow["TotalOpenEnquiry"] = enqCountStatsDTO.TotalOpen;
            enquiryRow["TotalLostEnquiry"] = enqCountStatsDTO.TotalClosed;
            enquiryRow["TotalOwnedEnquiry"] = enqCountStatsDTO.TotalLogged + enqCountStatsDTO.TotalClosed + enqCountStatsDTO.TotalOpen;
            enquiryRow["PropertyName"] = propertyDTO.Name;
            enquiryRow["FromDate"] = Convert.ToDateTime(txtFromDate.Text);
            enquiryRow["ToDate"] = Convert.ToDateTime(txtToDate.Text);
            enquiryDataTable.Rows.Add(enquiryRow);
            return enquiryDataTable;
        }
    }
}