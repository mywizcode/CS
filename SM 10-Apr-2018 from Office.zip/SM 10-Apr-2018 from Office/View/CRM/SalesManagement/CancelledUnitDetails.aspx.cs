﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.BO;
using ConstroSoft.TelephonyProvider;

public partial class CancelledUnitDetails : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addMasterDataError = "addMasterDataError";
    string cancelledUnitStep1Error = "cancelledUnitStep1Error";
    string cancelledUnitStep2Error = "cancelledUnitStep2Error";
    string cancelledUnitStep3Error = "cancelledUnitStep3Error";
    string addModifyPaymentError = "addModifyPaymentError";
    string addMasterDataModal = "addMasterDataModal";
    string addModifyPaymentModal = "addModifyPaymentModal";
    string step1 = "step1";
    string step2 = "step2";
    string step3 = "step3";
    string ClickToCallModal = "ClickToCallModal";
    string clickToCallError = "clickToCallError";
    DropdownBO drpBO = new DropdownBO();
    PropertyBO propertyBO = new PropertyBO();
    PropertyUnitManagementBO prUnitBO = new PropertyUnitManagementBO();
    PropertyUserBO propertyUserBO = new PropertyUserBO();
    SoldPropertyUnitBO soldUnitBO = new SoldPropertyUnitBO();
    CustomerBO customerBO = new CustomerBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    DocumentBO documentBO = new DocumentBO();
    CallHistoryBO callHistoryBO =new CallHistoryBO();
    public enum PageAction { VIEW, MODIFY }
    public enum PaymentAction { ADD, MODIFY }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                CancelledUnitDetailNavDTO navDto = ApplicationUtil.getPageNavDTO<CancelledUnitDetailNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_CANCELLED_PR_UNIT)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
            RegisterPostBackControl();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        string currentStep = activeStepHdn.Value;
        pnlCancelledUnitStep1.Visible = step1.Equals(currentStep);
        pnlCancelledUnitStep2.Visible = step2.Equals(currentStep);
        pnlCancelledUnitStep3.Visible = step3.Equals(currentStep);
        renderPageFieldsWithEntitlement();
        setPageTitle();
    }
    public void initBootstrapComponantsFromServer()
    {
    	 ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpCustSalutation, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.SALUTATION.ToString(), null, userDefDto.FirmNumber);
        drpBO.drpEnum<FamilyRelation>(drpFamilyRelation, Constants.SELECT_ITEM);
        drpBO.drpDataBase(drpNationality, DrpDataType.COUNTRY, null, null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAllPaymentType, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.PR_UNIT_PYMT_TYPE.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<PaymentMode>(drpPaymentMode, null);
    }
    public void setErrorMessage(string message, string group)
    {
    	string[] pageErrorGrp = { commonError, cancelledUnitStep1Error, cancelledUnitStep2Error, cancelledUnitStep3Error };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        } else CommonUtil.getCustomValidator(Page, message, group);
        setErrorActiveStep(group);
    }
    private void setErrorActiveStep(string group)
    {
        if (group.Equals(commonError) || group.Equals(cancelledUnitStep1Error)) activeStepHdn.Value = step1;
        if (group.Equals(cancelledUnitStep2Error)) activeStepHdn.Value = step2;
        if (group.Equals(cancelledUnitStep3Error)) activeStepHdn.Value = step3;
    }
    private void RegisterPostBackControl()
    {
        if (dlHistoryGrid.Rows.Count > 0)
        {
            for (var i = 0; i < dlHistoryGrid.Rows.Count; i++)
            {
                LinkButton tmpBtn = (LinkButton)dlHistoryGrid.Rows[i].FindControl("lnkDownloadDLHistBtn");
                if (tmpBtn != null)
                {
                    ScriptManager mgr = ScriptManager.GetCurrent(this.Page);
                    mgr.RegisterPostBackControl(tmpBtn);
                }
            }
        }
    }
    private void doInit(CancelledUnitDetailNavDTO navDto)
    {
        if (navDto != null)
        {
            setCurrentStep(step1);
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(CancelledUnitDetailNavDTO navDto)
    {
        try
        {
            CancelledUnitDetailPageDTO cancelledUnitPageDTO = new CancelledUnitDetailPageDTO();
            Session[Constants.Session.PAGE_DATA] = cancelledUnitPageDTO;
            pageModeHdn.Value = navDto.Mode.ToString();
            cancelledUnitPageDTO.PrevNavDTO = navDto.PrevNavDto;
            PrUnitSaleDetailDTO prUnitSaleDetailDto = soldUnitBO.fetchPrUnitSaleDetail(navDto.PrUnitSaleDetailId, true);
            cancelledUnitPageDTO.UnitDTO = propertyBO.fetchPropertyUnitWithParent(prUnitSaleDetailDto.PropertyUnit.Id, false);
            prUnitSaleDetailDto.PropertyUnit = cancelledUnitPageDTO.UnitDTO;
            prUnitSaleDetailDto.uiTaxDetails = new List<PrUnitSaleTaxDetailDTO>();
            prUnitSaleDetailDto.uiCMTaxDetails = new List<PrUnitSaleTaxDetailDTO>();
            foreach (PrUnitSaleTaxDetailDTO taxDtl in prUnitSaleDetailDto.PrUnitSaleTaxDetails)
            {
                if (IncludeInPymtTotal.Yes == taxDtl.IncludeInTotalPymt) prUnitSaleDetailDto.uiTaxDetails.Add(taxDtl);
                else prUnitSaleDetailDto.uiCMTaxDetails.Add(taxDtl);
            }
            cancelledUnitPageDTO.PrUnitSaleDTO = prUnitSaleDetailDto;
            populateUIFieldsFromSaleUnitDTO(getCancelledUnitDetails());
            initContactDrp(prUnitSaleDetailDto);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void navigateToPreviousPage()
    {
        CancelledUnitDetailPageDTO cancelledUnitPageDTO = getSessionPageData();
        if (cancelledUnitPageDTO != null && cancelledUnitPageDTO.PrevNavDTO != null)
        {
            object obj = cancelledUnitPageDTO.PrevNavDTO;
            if (obj is CustomerPymtHistoryNavDTO)
            {
                CustomerPymtHistoryNavDTO navDTO = (CustomerPymtHistoryNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.CUSTOMER_PYMT_HISTORY, true);
            }
            else if (obj is CancelledUnitSearchNavDTO)
            {
                CancelledUnitSearchNavDTO navDTO = (CancelledUnitSearchNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.CANCELLED_UNIT_SEARCH, true);
            }
            else if (obj is EnquiryDetailNavDTO)
            {
                EnquiryDetailNavDTO navDTO = (EnquiryDetailNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.ENQUIRY_DETAILS, true);
            }
            else if (obj is UserEnquiryHistoryNavDTO)
            {
                UserEnquiryHistoryNavDTO navDTO = (UserEnquiryHistoryNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.USER_ENQUIRY_HISTORY, true);
            }
        }
        Response.Redirect(Constants.URL.CANCELLED_UNIT_SEARCH, true);
    }
    private void setPageTitle()
    {
        if (isModifyMode()) lbPageTitle.Text = Constants.ICON.MODIFY + Resources.Labels.MODIFY_CANCELLED_UNIT;
        else if (isViewMode()) lbPageTitle.Text = Constants.ICON.VIEW_DTL + Resources.Labels.CANCELLED_UNIT_DETAILS;
        setSubHeaderPageTitle();
    }
    private void setSubHeaderPageTitle()
    {
        string jumpTo = activeStepHdn.Value;
        lbSubHeaderPageTitle.Text = " - ";
        if (jumpTo.Equals(step1))
        {
            lbSubHeaderPageTitle.Text += Resources.Labels.CANCELLED_UNIT_PAGE1_TITLE;
        }
        else if (jumpTo.Equals(step2))
        {
            lbSubHeaderPageTitle.Text += Resources.Labels.CANCELLED_UNIT_PAGE2_TITLE;
        }
        else if (jumpTo.Equals(step3))
        {
            lbSubHeaderPageTitle.Text += Resources.Labels.CANCELLED_UNIT_PAGE3_TITLE;
        }
    }
    private void renderPageFieldsWithEntitlement()
    {
        bool modifyMode = isModifyMode();
        bool viewMode = isViewMode();

        //Page 3 Fields
        txtCancellationCharge.ReadOnly = viewMode;
        txtCancellationComments.ReadOnly = viewMode;
        addSalePaymentBtn.Visible = modifyMode;
        paymentGrid.Columns[0].Visible = modifyMode;

        btnCancelledUnitSubmit.Visible = modifyMode;

        //SubHeader links and Other btns with Entitlement
        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        liModifyCancelledUnit.Visible = viewMode && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.CANCELLED_UNIT_MODIFY);;
        liClickToCall.Visible = CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.CANCELLED_UNIT_CLICK_TO_CALL);
        liNavigation.Visible = CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_CUSTOMER_PAYMENTS);
        
        if (addPymtTypeBtn.Visible) addPymtTypeBtn.Visible = CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MASTER_DATA_ADD);
    }
    private bool isModifyMode()
    {
        return PageMode.MODIFY.ToString().Equals(pageModeHdn.Value);
    }
    private bool isViewMode()
    {
        return PageMode.VIEW.ToString().Equals(pageModeHdn.Value);
    }
    private CancelledUnitDetailPageDTO getSessionPageData()
    {
        return (CancelledUnitDetailPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private PrUnitSaleDetailDTO getCancelledUnitDetails()
    {
        return getSessionPageData().PrUnitSaleDTO;
    }
    private PropertyUnitDTO getCancelledUnit()
    {
        return getSessionPageData().UnitDTO;
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private void populateCustomerFields(CustomerDTO customerDTO)
    {
        if (customerDTO != null && customerDTO.Salutation != null) drpCustSalutation.Text = customerDTO.Salutation.Id.ToString(); else drpCustSalutation.ClearSelection();
        if (customerDTO != null) txtCustFirstName.Text = customerDTO.FirstName; else txtCustFirstName.Text = null;
        if (customerDTO != null) txtCustMiddleName.Text = customerDTO.MiddleName; else txtCustMiddleName.Text = null;
        if (customerDTO != null) txtCustLastName.Text = customerDTO.LastName; else txtCustLastName.Text = null;
        if (customerDTO != null && customerDTO.ContactInfo.Gender != null) txtCustGender.Text = customerDTO.ContactInfo.Gender.ToString(); else txtCustGender.Text = null;
        if (customerDTO != null && customerDTO.ContactInfo.Dob != null) txtCustDOB.Text = customerDTO.ContactInfo.Dob.Value.ToString(Constants.DATE_FORMAT); else txtCustDOB.Text = null;
        if (customerDTO != null && customerDTO.ContactInfo.MaritalStatus != null) txtCustMaritalStatus.Text = customerDTO.ContactInfo.MaritalStatus.ToString(); else txtCustMaritalStatus.Text = null;
        if (customerDTO != null) txtCustContact.Text = customerDTO.ContactInfo.Contact; else txtCustContact.Text = null;
        if (customerDTO != null) txtCustAltContact.Text = customerDTO.ContactInfo.AltContact; else txtCustAltContact.Text = null;
        if (customerDTO != null) txtCustEmail.Text = customerDTO.ContactInfo.Email; else txtCustEmail.Text = null;
        if (customerDTO != null) txtCustAltEmail.Text = customerDTO.ContactInfo.AltEmail; else txtCustAltEmail.Text = null;
        if (customerDTO != null && customerDTO.Occupation != null) txtCustOccupation.Text = customerDTO.Occupation.Id.ToString(); else txtCustOccupation.Text = null;
        if (customerDTO != null) txtCustPan.Text = customerDTO.Pan; else txtCustPan.Text = null;
        if (customerDTO != null) txtRelativeName.Text = customerDTO.FamilyRelName; else txtRelativeName.Text = null;
        if (customerDTO != null && customerDTO.AadharNo != null) txtAdarNo.Text = customerDTO.AadharNo; else txtAdarNo.Text = null;
        if (customerDTO != null && customerDTO.PassportNo != null) txtPassportNo.Text = customerDTO.PassportNo; else txtPassportNo.Text = null;
        if (customerDTO != null && customerDTO.Fax != null) txtFaxNo.Text = customerDTO.Fax; else txtFaxNo.Text = null;
        if (customerDTO != null && customerDTO.Nationality != null) drpNationality.Text = customerDTO.Nationality.Id.ToString(); else drpNationality.ClearSelection();
        if (customerDTO != null && customerDTO.ResidentialStatus != null) drpResidentialStatus.Text = customerDTO.ResidentialStatus.Id.ToString(); else drpResidentialStatus.ClearSelection();
        if (customerDTO != null && customerDTO.FamilyRelationship != null) drpFamilyRelation.Text = customerDTO.FamilyRelationship.ToString(); else drpFamilyRelation.ClearSelection();

        lbCustomerRefNo.Text = customerDTO.CustRefNo;

        populateAddressGrid(customerDTO.ContactInfo);
    }
    private void populateUIFieldsFromSaleUnitDTO(PrUnitSaleDetailDTO prUnitSaleDetailDto)
    {
        PropertyUnitDTO propertyUnitDto = prUnitSaleDetailDto.PropertyUnit;
        PropertyTowerDTO propertyTowerDto = prUnitSaleDetailDto.PropertyUnit.PropertyTower;
        //Page 1 Details
        spEnquiryRefNo.Visible = false;
        if (prUnitSaleDetailDto.Enquiry != null)
        {
            spEnquiryRefNo.Visible = true;
            lbEnquiryRefNo.Text = prUnitSaleDetailDto.Enquiry.EnquiryRefNo;
        }

        populateCustomerFields(prUnitSaleDetailDto.Customer);
        populateCoApplicantGrid(prUnitSaleDetailDto);
        //Page 2 Details
        populateUnitInfoSection(prUnitSaleDetailDto);
        txtBookingEmployee.Text = CommonUIConverter.getCustomerFullName(prUnitSaleDetailDto.FirmMember.FirstName, "", prUnitSaleDetailDto.FirmMember.LastName);
        txtBookingDate.Text = DateUtil.getCSDate(prUnitSaleDetailDto.BookingDate);
        txtBookingRate.Text = (propertyTowerDto.Rate != null) ? propertyTowerDto.Rate.ToString() : null;
        txtAgreementValue.Text = prUnitSaleDetailDto.AgreementAmt.ToString();
        txtBookingRefNo.Text = prUnitSaleDetailDto.BookingRefNo;
        lbBookTotalTax.Text = prUnitSaleDetailDto.TotalTaxAmt.ToString();
        lbBookTotalUnitCost.Text = prUnitSaleDetailDto.TotalPymtAmt.ToString();
        cbAgreementDone.Checked = (prUnitSaleDetailDto.IsAgreementDone == IsAgreementDone.Yes);
        txtAgreementDate.Text = DateUtil.getCSDate(prUnitSaleDetailDto.AgreementDate);
        txtAgreementNo.Text = prUnitSaleDetailDto.AgreementNo;
        cbPossessionGiven.Checked = (prUnitSaleDetailDto.IsPossessionDone == IsPossessionDone.Yes);
        txtPossesionDate.Text = DateUtil.getCSDate(prUnitSaleDetailDto.PossessionDate);
        populateTaxDetailGrid(prUnitSaleDetailDto);
        populateCMTaxDetailGrid(prUnitSaleDetailDto);
        //Page 3 Details
        txtLoanBankName.Text = prUnitSaleDetailDto.LoanBankName;
        txtLoanBranch.Text = prUnitSaleDetailDto.LoanBankBranch;
        txtLoanAmount.Text = (prUnitSaleDetailDto.LoanAmt != null) ? prUnitSaleDetailDto.LoanAmt.ToString() : null;
        populateDLHistoryGrid(prUnitSaleDetailDto);

        txtCancelledEmployee.Text = CommonUIConverter.getCustomerFullName(prUnitSaleDetailDto.CancellationFirmMember.FirstName, "", prUnitSaleDetailDto.CancellationFirmMember.LastName);
        txtCancellationDate.Text = DateUtil.getCSDate(prUnitSaleDetailDto.CanellationDate);
        txtCancellationCharge.Text = prUnitSaleDetailDto.CancellationFee.ToString();
        txtCancellationComments.Text = prUnitSaleDetailDto.CancellationReason;
        populateSalePymtGrid(prUnitSaleDetailDto);
    }
    private void populateUnitInfoSection(PrUnitSaleDetailDTO prUnitSaleDetailDto)
    {
        PropertyUnitDTO propertyUnitDto = prUnitSaleDetailDto.PropertyUnit;
        PropertyTowerDTO propertyTowerDto = prUnitSaleDetailDto.PropertyUnit.PropertyTower;
        lbBookProperty.Text = propertyTowerDto.Property.Name;
        lbBookTower.Text = propertyTowerDto.Name;
        lbBookBaseRate.Text = (propertyTowerDto.Rate != null) ? propertyTowerDto.Rate.ToString() : null;
        lbBookWing.Text = propertyUnitDto.Wing;
        lbBookUnitNo.Text = propertyUnitDto.UnitNo;
        lbBookUnitType.Text = propertyUnitDto.UnitType.Name;
        btnCancelledUnitInfoHdn.Attributes["row-info"] = CommonUIConverter.getGridViewRowInfo(propertyUnitDto);
    }
    private void populateDLHistoryGrid(PrUnitSaleDetailDTO prUnitSaleDetailDTO)
    {
        dlHistoryGrid.DataSource = (prUnitSaleDetailDTO.DemandLetterHistory != null) ? prUnitSaleDetailDTO.DemandLetterHistory.ToList<DemandLetterHistoryDTO>()
                : new List<DemandLetterHistoryDTO>();
        dlHistoryGrid.DataBind();
    }
    private void populateTaxDetailGrid(PrUnitSaleDetailDTO prUnitSaleDetailDTO)
    {
        taxDetailGrid.DataSource = new List<PrUnitSaleTaxDetailDTO>();
        if (prUnitSaleDetailDTO != null && prUnitSaleDetailDTO.uiTaxDetails != null)
        {
            assignUiIndexToTaxDetail(prUnitSaleDetailDTO.uiTaxDetails);
            taxDetailGrid.DataSource = prUnitSaleDetailDTO.uiTaxDetails;
        }
        taxDetailGrid.DataBind();
    }
    private void populateCMTaxDetailGrid(PrUnitSaleDetailDTO prUnitSaleDetailDTO)
    {
        cmTaxDetailGrid.DataSource = new List<PrUnitSaleTaxDetailDTO>();
        if (prUnitSaleDetailDTO != null && prUnitSaleDetailDTO.uiTaxDetails != null)
        {
            assignUiIndexToTaxDetail(prUnitSaleDetailDTO.uiCMTaxDetails);
            cmTaxDetailGrid.DataSource = prUnitSaleDetailDTO.uiCMTaxDetails;
        }
        cmTaxDetailGrid.DataBind();
    }
    private void assignUiIndexToTaxDetail(List<PrUnitSaleTaxDetailDTO> taxDetailDtos)
    {
        if (taxDetailDtos != null && taxDetailDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (PrUnitSaleTaxDetailDTO taxDetailDto in taxDetailDtos)
            {
                taxDetailDto.UiIndex = uiIndex++;
                taxDetailDto.RowInfo = CommonUIConverter.getGridViewRowInfo(taxDetailDto);
            }
        }
    }
    private void populateCoApplicantGrid(PrUnitSaleDetailDTO prSaleDetailDTO)
    {
        coApplicantGrid.DataSource = new List<CoCustomerDTO>();
        if (prSaleDetailDTO != null)
        {
            assignUiIndexToCoApplicant(prSaleDetailDTO.CoCustomers);
            coApplicantGrid.DataSource = prSaleDetailDTO.CoCustomers;
        }
        coApplicantGrid.DataBind();
        pnlSecApplicantEmpty.Visible = (prSaleDetailDTO.CoCustomers == null || prSaleDetailDTO.CoCustomers.Count == 0);
    }
    private void assignUiIndexToCoApplicant(ISet<CoCustomerDTO> CocustomerDtos)
    {
        if (CocustomerDtos != null && CocustomerDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (CoCustomerDTO cocustomerDto in CocustomerDtos)
            {
                cocustomerDto.FullName = CommonUIConverter.getCustomerFullName(cocustomerDto.SalutationId.Name, cocustomerDto.FirstName, "", cocustomerDto.LastName);
                cocustomerDto.UiIndex = uiIndex++;
                cocustomerDto.RowInfo = CommonUIConverter.getGridViewRowInfo(cocustomerDto);
            }
        }
    }
    private void populateAddressGrid(ContactInfoDTO conactInfoDto)
    {
        addressGrid.DataSource = new List<AddressDTO>();
        if (conactInfoDto != null)
        {
            assignUiIndexToAddress(conactInfoDto.Addresses);
            addressGrid.DataSource = conactInfoDto.Addresses;
        }
        addressGrid.DataBind();
        pnlAddressEmpty.Visible = (conactInfoDto.Addresses == null || conactInfoDto.Addresses.Count == 0);
    }

    private void assignUiIndexToAddress(ISet<AddressDTO> addressDtos)
    {
        if (addressDtos != null && addressDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (AddressDTO addressDto in addressDtos)
            {
                addressDto.UiIndex = uiIndex++;
                addressDto.UiFullAddress = CommonUIConverter.getUiFullAddress(addressDto);
            }
        }
    }
    private void populateSalePymtGrid(PrUnitSaleDetailDTO prUnitSaleDetailDTO)
    {
        paymentGrid.DataSource = new List<PrUnitSalePymtDTO>();
        if (prUnitSaleDetailDTO != null && prUnitSaleDetailDTO.PrUnitSalePymts != null)
        {
            assignUiIndexToSalePymts(prUnitSaleDetailDTO.PrUnitSalePymts);
            paymentGrid.DataSource = prUnitSaleDetailDTO.PrUnitSalePymts;
        }
        paymentGrid.DataBind();
    }
    private void assignUiIndexToSalePymts(ISet<PrUnitSalePymtDTO> salePymtDtos)
    {
        if (salePymtDtos != null && salePymtDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (PrUnitSalePymtDTO salePymtDto in salePymtDtos)
            {
                salePymtDto.UiIndex = uiIndex++;
                salePymtDto.RowInfo = CommonUIConverter.getGridViewRowInfo(salePymtDto);
            }
        }
    }
    private CancelledUnitDetailNavDTO getCurrentPageNavigation(PageMode mode)
    {
        CancelledUnitDetailPageDTO PageDTO = getSessionPageData();
        CancelledUnitDetailNavDTO navDTO = new CancelledUnitDetailNavDTO();
        navDTO.Mode = mode;
        navDTO.PrUnitSaleDetailId = PageDTO.PrUnitSaleDTO.Id;
        navDTO.PrevNavDto = getSessionPageData().PrevNavDTO;
        return navDTO;
    }
    protected void onClickNavToPymtHistory(object sender, EventArgs e)
    {
        try
        {
            PrUnitSaleDetailDTO prUnitSaleDTO = getCancelledUnitDetails();
            CustomerPymtHistoryNavDTO navDTO = new CustomerPymtHistoryNavDTO();
            navDTO.PrUnitSaleDetailId = prUnitSaleDTO.Id;
            navDTO.PymtMode = PaymentMode.Receivable;
            navDTO.PrevNavDto = getCurrentPageNavigation(EnumHelper.ToEnum<PageMode>(pageModeHdn.Value));
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.CUSTOMER_PYMT_HISTORY, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyCancelledUnitBtn(object sender, EventArgs e)
    {
        try
        {
            PrUnitSaleDetailDTO prUnitSaleDTO = getCancelledUnitDetails();
            CancelledUnitDetailNavDTO navDTO = getCurrentPageNavigation(PageMode.MODIFY);
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.CANCELLED_UNIT_DETAILS, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickConnectCall(object sender, EventArgs e)
    {
        try
        {
        	UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
    		IList<VirtualPhoneDTO> vPhoneList = propertyUserBO.fetchOutgoingVitualPhonesAllocattedToUser(userDefDTO.FirmMember.Id, CommonUtil.getCurrentPropertyDTO(userDefDTO).Id);
    		if(vPhoneList != null && vPhoneList.Count > 0) {
    			if (drpCustomerContact.Items.Count == 1 && vPhoneList.Count == 1) {
    				makeCallToCustomer(userDefDTO.FirmMember.ContactInfo.Contact, drpCustomerContact.Text, vPhoneList[0].PhoneNumber);
    			} else {
    				drpCustomerContact.ClearSelection();
    				initVirtualPhoneDrp(vPhoneList);
    				
    				divCustomerNumber.Visible = (drpCustomerContact.Items.Count > 1);
    				lbCustomerNumberField.Visible = !divCustomerNumber.Visible;
    				lbCustomerNumber.Text = drpCustomerContact.Text;
    				
    				divVirtualPhone.Visible = (vPhoneList.Count > 1);
    				lbVirtualPhoneField.Visible = !divVirtualPhone.Visible;
    				lbVirtualPhone.Text = vPhoneList[0].PhoneNumber;
    				
    				activeModalHdn.Value = ClickToCallModal;
    			}    			
    		} else {
    			(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Virtual Phone is not assigned to you. Please contact your supervisor."));
    		}           
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void makeCallToCustomer(string agentNumber, string customerNumber, string virtualPhone) {
    	UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        OutboundCallDialDTO callDialDTO = new OutboundCallDialDTO();
        callDialDTO.AgentNumber = agentNumber;
        callDialDTO.CustomerNumber = customerNumber;
        callDialDTO.VirtualPhone = virtualPhone;
        callDialDTO.PropertyId = CommonUtil.getCurrentPropertyDTO(userDefDTO).Id;
        callDialDTO.PrUnitSaleId = getCancelledUnitDetails().Id;

        CallClient callClient = new CallClient();
        CallHistoryDTO callHistoryDTO = callClient.placeOutBoundCall(callDialDTO, userDefDTO);
        (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("Call is placed successfully."));
    }
    protected void connectToCall(object sender, EventArgs e)
    {
        try
        {
        	UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        	makeCallToCustomer(userDefDTO.FirmMember.ContactInfo.Contact, drpCustomerContact.Text, drpVirtualPhone.Text);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelCall(object sender, EventArgs e)
    {
    }
    private void initContactDrp(PrUnitSaleDetailDTO prUnitSaleDetailDto)
    {
        drpCustomerContact.Items.Clear();
        if (!String.IsNullOrEmpty(prUnitSaleDetailDto.Customer.ContactInfo.Contact))
        {
            drpCustomerContact.Items.Add(new ListItem("Primary Contact: " + prUnitSaleDetailDto.Customer.ContactInfo.Contact, 
            		prUnitSaleDetailDto.Customer.ContactInfo.Contact));
        }
        if (!String.IsNullOrEmpty(prUnitSaleDetailDto.Customer.ContactInfo.AltContact))
        {
            drpCustomerContact.Items.Add(new ListItem("Alternate Contact: " + prUnitSaleDetailDto.Customer.ContactInfo.AltContact, 
            		prUnitSaleDetailDto.Customer.ContactInfo.AltContact));
        }
    }
    private void initVirtualPhoneDrp(IList<VirtualPhoneDTO> phoneDTOList) {
    	drpVirtualPhone.Items.Clear();
    	foreach(VirtualPhoneDTO tmpDTO in phoneDTOList) {
    		drpVirtualPhone.Items.Add(new ListItem(tmpDTO.PhoneNumber, tmpDTO.PhoneNumber));
    	}
    }
    protected void onClickDownloadDLHistBtn(object sender, EventArgs e)
    {
        try
        {
            CancelledUnitDetailPageDTO PageDTO = getSessionPageData();
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            DemandLetterHistoryDTO dlHistoryDTO = PageDTO.PrUnitSaleDTO.DemandLetterHistory.ToList<DemandLetterHistoryDTO>().Find(x => x.Id == selectedId);
            string FullPath = CommonUtil.appendNameToPath(dlHistoryDTO.DocumentPath, dlHistoryDTO.FileName);
            byte[] fileContent = documentBO.downloadFile(FullPath);
            Response.Buffer = true;
            Response.Charset = "";
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + dlHistoryDTO.FileName);
            Response.BinaryWrite(fileContent);
            Response.Flush();
            UpdatePanel1.Update();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void reCalculateCancellationPayment(object sender, EventArgs e)
    {
        try
        {
            if (validateCancellationPayment())
            {
                PrUnitSaleDetailDTO prUnitSaleDetailTO = getCancelledUnitDetails();
                decimal cancellationPymtAmt = getCancellationPaymentAmt(prUnitSaleDetailTO);
                PrUnitSalePymtDTO prUnitSalePymtDto = prUnitSaleDetailTO.PrUnitSalePymts.ToList<PrUnitSalePymtDTO>()
                        .Find(x => x.PymtType.Name.Equals(Constants.SYSDEFAULT.MCD_CANCELLATION_PAYMENT));
                prUnitSalePymtDto.PymtAmt = cancellationPymtAmt;
                prUnitSalePymtDto.UpdateUser = getUserDefinitionDTO().Username;
                updatePymtMaster(prUnitSalePymtDto);
                populateSalePymtGrid(prUnitSaleDetailTO);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateCancellationPayment()
    {
        bool isValid = false;
        PrUnitSaleDetailDTO prUnitSaleDetailTO = getCancelledUnitDetails();
        decimal cancellationPymtAmt = getCancellationPaymentAmt(prUnitSaleDetailTO);
        PrUnitSalePymtDTO prUnitSalePymtDto = prUnitSaleDetailTO.PrUnitSalePymts.ToList<PrUnitSalePymtDTO>()
                        .Find(x => x.PymtType.Name.Equals(Constants.SYSDEFAULT.MCD_CANCELLATION_PAYMENT));
        /*
         * If Customer has paid more than calculated cancellation payment then force user to adjust cancellation charges. It is assumed that when booking is cancellation and 
         * Payment to Customer is ZERO then also add Cancellation Payment record. 
         */
        if (prUnitSalePymtDto.PymtAmt.CompareTo(cancellationPymtAmt) != 0)
        {
            isValid = true;
            if (prUnitSalePymtDto.PaymentMaster.TotalPaid.CompareTo(cancellationPymtAmt) > 0)
            {
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Customer has been paid more than cancellation payment. Please adjust Cancellation Charges."));
                isValid = false;
            }
        }        
        return isValid;
    }
    /*
     * Total payment to customer will be calculated from all 'Suspended' payments
     * 	-> Total Payment to Customer = Total paid by customer (Suspended Payments) - Total Paid to Customer (Suspended Payments) - Cancellation Charges.
     * NOTE: When booking is cancelled all payments (Receivable/Payable) are Suspended. However once booking is cancelled, user can add more Payable payments. These payments
     * wont be considered in calculating Cancellation Payment.
     */
    private decimal getCancellationPaymentAmt(PrUnitSaleDetailDTO prUnitSaleDetailDto)
    {
        decimal cancellationPymtAmt = 0;
        decimal totalPaidToFirm = 0;
        decimal totalPaidToCustomer = 0;
        foreach (PrUnitSalePymtDTO prUnitSalePymtDto in prUnitSaleDetailDto.PrUnitSalePymts)
        {
            if (prUnitSalePymtDto.PaymentMaster.Status == PymtMasterStatus.Suspended)
            {
                if (prUnitSalePymtDto.PymtMode == PaymentMode.Receivable) totalPaidToFirm = Decimal.Add(totalPaidToFirm, prUnitSalePymtDto.PaymentMaster.TotalPaid);
                else totalPaidToCustomer = Decimal.Add(totalPaidToCustomer, prUnitSalePymtDto.PaymentMaster.TotalPaid);
            }
        }
        cancellationPymtAmt = totalPaidToFirm - totalPaidToCustomer - CommonUtil.getDecimaNotNulllWithoutExt(txtCancellationCharge.Text);
        if (cancellationPymtAmt < 0) cancellationPymtAmt = 0;
        return cancellationPymtAmt;
    }
    //Next-Previous actions
    protected void goToStep(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            string stepToJump = rd.Attributes["data-step"];
            List<string> stepsToValidate = CommonUtil.getStepsToValidate(activeStepHdn.Value, stepToJump);
            bool isValid = true;
            foreach (string step in stepsToValidate)
            {
                if (!validateGoToStep(step))
                {
                    isValid = false;
                    break;
                }
            }
            if (isValid)
            {
                setCurrentStep(stepToJump);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void modifyCancelledUnitDetails(object sender, EventArgs e)
    {
        try
        {
            if (validateCancelledUnitSubmit())
            {
                PrUnitSaleDetailDTO prUnitSaleDetailDTO = populatePropertySaleDTOFromUI(getCancelledUnitDetails());
                soldUnitBO.UpdateSoldPropertyUnitDetails(prUnitSaleDetailDTO);
                Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg(string.Format("Cancelled booking #{0} details are updated successfully.", prUnitSaleDetailDTO.BookingRefNo)));
                //Navigate to same page in VIEW mode
                CancelledUnitDetailNavDTO navDTO = getCurrentPageNavigation(PageMode.VIEW);
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.CANCELLED_UNIT_DETAILS, true);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateCancelledUnitSubmit()
    {
        return validateStep1() && validateStep2() && validateStep2();
    }
    private bool validateGoToStep(string jumpTo)
    {
        bool isValid = true;
        if (jumpTo.Equals(step1))
        {
            isValid = validateStep1();
        }
        else if (jumpTo.Equals(step2))
        {
            isValid = validateStep2();
        }
        else if (jumpTo.Equals(step3))
        {
            isValid = validateStep3();
        }
        return isValid;
    }
    private bool validateStep1()
    {
        return true;
    }
    private bool validateStep2()
    {
        return true;
    }
    private bool validateStep3()
    {
        return validateMandatoryFields(cancelledUnitStep3Error, step3);
    }
    private bool validateMandatoryFields(string valGrp, string step)
    {
        Page.Validate(valGrp);
        bool isValid = Page.IsValid;
        if (!isValid)
        {
        	(this.Master as CSMaster).setPageErrorInNotyMsg(Page.Validators);
            if (!string.IsNullOrWhiteSpace(step)) setCurrentStep(step);
        }
        return isValid;
    }
    private void setCurrentStep(string step)
    {
        activeStepHdn.Value = step;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private PrUnitSaleDetailDTO populatePropertySaleDTOFromUI(PrUnitSaleDetailDTO prUnitSaleDetailDto)
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        //Page 3 Details
        prUnitSaleDetailDto.CancellationFee = CommonUtil.getDecimalWithoutExt(txtCancellationCharge.Text);
        prUnitSaleDetailDto.CancellationReason = txtCancellationComments.Text.TrimNullable();

        return prUnitSaleDetailDto;
    }
    private void updateSalePaymentAmount(PrUnitSaleDetailDTO prUnitSaleDetailDto, decimal salePymtAmt)
    {
        PrUnitSalePymtDTO prUnitSalePymtDto = prUnitSaleDetailDto.PrUnitSalePymts.ToList<PrUnitSalePymtDTO>().Find(x => isSalePayment(x.PymtType.Name));
        if (prUnitSalePymtDto.PaymentMaster.TotalPaid.CompareTo(salePymtAmt) < 0)
        {
            //TODO - warning -> Customer has paid more than total sale payment.
        }
        prUnitSalePymtDto.PymtAmt = salePymtAmt;
        prUnitSalePymtDto.PaymentMaster.TotalAmt = salePymtAmt;
        decimal totalPending = prUnitSalePymtDto.PaymentMaster.TotalAmt - prUnitSalePymtDto.PaymentMaster.TotalPaid;
        if (totalPending > 0)
        {
            prUnitSalePymtDto.PaymentMaster.TotalPending = totalPending;
            prUnitSalePymtDto.PaymentMaster.Status = PymtMasterStatus.Pending;
        }
        else
        {
            prUnitSalePymtDto.PaymentMaster.TotalPending = 0;
            prUnitSalePymtDto.PaymentMaster.Status = PymtMasterStatus.Paid;
        }
        populateSalePymtGrid(prUnitSaleDetailDto);
    }
    //Master Data Modal save logic - Start
    protected void saveMasterData(object sender, EventArgs e)
    {
        try
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (MasterDataType.PR_UNIT_PYMT_TYPE.ToString().Equals(masterDataModalTypeHdn.Value))
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(MasterDataType.PR_UNIT_PYMT_TYPE.ToString(), txtMasterDataInput1.Text.TrimNullable(),
                       txtMasterDataInput2.Text.TrimNullable(), SystemDefined.No, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Payment Type");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpAllPaymentType, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.PR_UNIT_PYMT_TYPE.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    populateDrpPaymentType();
                }
            }
            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                activeModalHdn.Value = addMasterDataModal;
                setErrorMessage(errorMsg, addMasterDataError);
            }
            else
            {
                resetMasterDataModalFields();
                setParentModalFlag();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            activeModalHdn.Value = "";
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelMasterDataModal(object sender, EventArgs e)
    {
        try
        {
            resetMasterDataModalFields();
            setParentModalFlag();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void resetMasterDataModalFields()
    {
        txtMasterDataInput1.Text = "";
        txtMasterDataInput2.Text = "";
        masterDataModalTypeHdn.Value = "";
    }
    private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
    {
        string errorMsg = "";
        if (string.IsNullOrWhiteSpace(masterDataDto.Name))
        {
            errorMsg = string.Format(Resources.Messages.TEXTFIELD_REQUIRED, type);
        }
        else if (masterDataBO.isAlreadyExist(masterDataDto))
        {
            errorMsg = string.Format(Resources.Messages.ALREADY_EXIST_DB_ERROR, type);
        }
        return errorMsg;
    }
    private void setParentModalFlag()
    {
        activeModalHdn.Value = masterDataParentModalHdn.Value;
        masterDataParentModalHdn.Value = "";
    }
    //Master Data Modal save logic - End
    //Payment Modal - Start
    private bool isSalePayment(string paymentType)
    {
        return Constants.SYSDEFAULT.MCD_SALE_PAYMENT.Equals(paymentType);
    }
    private bool isCancellationPayment(string paymentType)
    {
        return Constants.SYSDEFAULT.MCD_CANCELLATION_PAYMENT.Equals(paymentType);
    }
    private void initPaymentModalFields()
    {
        lbPaymentModalTitle.Text = (PaymentAction.ADD.ToString().Equals(paymentModalActionHdnBtn.Value))
            ? Constants.ICON.ADD + Resources.Labels.ADD_PAYMENT : Constants.ICON.MODIFY + Resources.Labels.MODIFY_PAYMENT;
    }
    private void initPaymentSectionFields(PrUnitSalePymtDTO prUnitSalePymtDto)
    {
        bool isAdd = PaymentAction.ADD.ToString().Equals(paymentModalActionHdnBtn.Value);
        bool isModify = PaymentAction.MODIFY.ToString().Equals(paymentModalActionHdnBtn.Value);
        populateDrpPaymentType();
        drpPaymentMode.Text = PaymentMode.Payable.ToString();//Payment mode will always be 'Payable' in Add mode
        if (prUnitSalePymtDto != null) drpPaymentType.Text = prUnitSalePymtDto.PymtType.Id.ToString(); else drpPaymentType.ClearSelection();
        if (prUnitSalePymtDto != null) txtPaymentDate.Text = DateUtil.getCSDate(prUnitSalePymtDto.PymtDate); else txtPaymentDate.Text = null;
        if (prUnitSalePymtDto != null) txtPaymentAmount.Text = prUnitSalePymtDto.PymtAmt.ToString(); else txtPaymentAmount.Text = null;
        if (prUnitSalePymtDto != null) drpPaymentMode.Text = prUnitSalePymtDto.PymtMode.ToString();
        if (prUnitSalePymtDto != null) txtPaymentDescription.Text = prUnitSalePymtDto.Description; else txtPaymentDescription.Text = null;

        addPymtTypeBtn.Visible = isAdd;
        drpPaymentType.Enabled = isAdd;
        txtPaymentDate.ReadOnly = !isAdd;
        drpPaymentMode.Enabled = false;
        txtPaymentAmount.ReadOnly = isModify && (isSalePayment(prUnitSalePymtDto.PymtType.Name) || isCancellationPayment(prUnitSalePymtDto.PymtType.Name));
    }
    private void populatePaymentFromUI(PrUnitSalePymtDTO prUnitSalePymtDto)
    {
        bool isAdd = PaymentAction.ADD.ToString().Equals(paymentModalActionHdnBtn.Value);
        bool isModify = PaymentAction.MODIFY.ToString().Equals(paymentModalActionHdnBtn.Value);
        if (isAdd)
        {
            prUnitSalePymtDto.PymtType = CommonUIConverter.getMasterControlDTO(drpPaymentType.Text, drpPaymentType.SelectedItem.Text);
            prUnitSalePymtDto.PymtDate = DateUtil.getCSDateNotNull(txtPaymentDate.Text);
            prUnitSalePymtDto.PymtMode = EnumHelper.ToEnum<PaymentMode>(drpPaymentMode.Text);
        }
        //Can not modify Amount when Sale/Cancellation Payment
        if (isAdd || !(isSalePayment(prUnitSalePymtDto.PymtType.Name) && isCancellationPayment(prUnitSalePymtDto.PymtType.Name)))
        {
            prUnitSalePymtDto.PymtAmt = CommonUtil.getDecimaNotNulllWithoutExt(txtPaymentAmount.Text);
        }
        prUnitSalePymtDto.Description = txtPaymentDescription.Text.TrimNullable();
        prUnitSalePymtDto.UpdateUser = getUserDefinitionDTO().Username;
    }
    private void addNewPymtMaster(PrUnitSalePymtDTO prUnitSalePymtDto)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        PaymentMasterDTO paymentMasterDto = new PaymentMasterDTO();
        paymentMasterDto.TotalAmt = Decimal.Zero;
        paymentMasterDto.TotalPaid = Decimal.Zero;
        paymentMasterDto.TotalPending = Decimal.Zero;
        paymentMasterDto.TotalPdcAmt = Decimal.Zero;
        paymentMasterDto.FirmNumber = userDefDto.FirmNumber;
        paymentMasterDto.InsertUser = userDefDto.Username;
        prUnitSalePymtDto.PaymentMaster = paymentMasterDto;
        updatePymtMaster(prUnitSalePymtDto);
    }
    private void updatePymtMaster(PrUnitSalePymtDTO prUnitSalePymtDto)
    {
        PaymentMasterDTO paymentMasterDto = prUnitSalePymtDto.PaymentMaster;
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        decimal diffAmt = Decimal.Subtract(prUnitSalePymtDto.PymtAmt, paymentMasterDto.TotalAmt);
        paymentMasterDto.TotalAmt = Decimal.Add(paymentMasterDto.TotalAmt, diffAmt);
        paymentMasterDto.TotalPending = Decimal.Subtract(paymentMasterDto.TotalAmt, paymentMasterDto.TotalPaid);
        paymentMasterDto.UpdateUser = userDefDto.Username;
        if (paymentMasterDto.TotalPending > 0) paymentMasterDto.Status = PymtMasterStatus.Pending;
        else paymentMasterDto.Status = PymtMasterStatus.Paid;
    }
    private PrUnitSalePymtDTO populatePaymentAdd()
    {
        PrUnitSalePymtDTO prUnitSalePymtDto = new PrUnitSalePymtDTO();
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        prUnitSalePymtDto.FirmNumber = userDef.FirmNumber;
        prUnitSalePymtDto.InsertUser = userDef.Username;
        return prUnitSalePymtDto;
    }
    private void setSelectedPayment(long UiIndex)
    {
        List<PrUnitSalePymtDTO> paymentList = getCancelledUnitDetails().PrUnitSalePymts.ToList<PrUnitSalePymtDTO>();
        paymentList.ForEach(c => c.isUISelected = false);
        if (UiIndex > 0) paymentList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
    }
    private PrUnitSalePymtDTO getSelectedPayment(long UiIndex)
    {
        List<PrUnitSalePymtDTO> paymentList = getCancelledUnitDetails().PrUnitSalePymts.ToList<PrUnitSalePymtDTO>();
        return (UiIndex > 0) ? paymentList.Find(c => c.UiIndex == UiIndex) : paymentList.Find(c => c.isUISelected);
    }
    protected void onClickAddPaymentBtn(object sender, EventArgs e)
    {
        try
        {
            paymentModalActionHdnBtn.Value = PaymentAction.ADD.ToString();
            initPaymentModalFields();
            setSelectedPayment(-1);
            initPaymentSectionFields(null);
            activeModalHdn.Value = addModifyPaymentModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyPaymentBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            PrUnitSalePymtDTO prUnitSalePymtDto = getSelectedPayment(selectedIndex);
            if (!(prUnitSalePymtDto.PaymentMaster.Status == PymtMasterStatus.Deleted && prUnitSalePymtDto.PaymentMaster.Status == PymtMasterStatus.Suspended))
            {
                paymentModalActionHdnBtn.Value = PaymentAction.MODIFY.ToString();
                initPaymentModalFields();
                setSelectedPayment(selectedIndex);
                initPaymentSectionFields(getSelectedPayment(0));
                activeModalHdn.Value = addModifyPaymentModal;
            }
            else
            {
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(string.Format("Payment is {0}, cannot be modified.", prUnitSalePymtDto.PaymentMaster.Status.ToString())));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void deletePayment(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            if (validatePaymentDelete(selectedIndex))
            {
                PrUnitSalePymtDTO prUnitSalePymtDto = getSelectedPayment(selectedIndex);
                PrUnitSaleDetailDTO prUnitSaleDetailDTO = getCancelledUnitDetails();
                if (prUnitSalePymtDto.PaymentMaster.Id > 0)
                {
                    prUnitSalePymtDto.PaymentMaster.Status = PymtMasterStatus.Deleted;
                }
                else
                {
                    prUnitSaleDetailDTO.PrUnitSalePymts.Remove(prUnitSalePymtDto);
                }
                populateSalePymtGrid(prUnitSaleDetailDTO);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void savePayment(object sender, EventArgs e)
    {
        try
        {
            if (validatePaymentAddModify())
            {
                PrUnitSalePymtDTO prUnitSalePymtDto = null;
                PrUnitSaleDetailDTO prUnitSaleDetailDTO = getCancelledUnitDetails();
                if (PaymentAction.ADD.ToString().Equals(paymentModalActionHdnBtn.Value))
                {
                    prUnitSalePymtDto = populatePaymentAdd();
                    populatePaymentFromUI(prUnitSalePymtDto);
                    addNewPymtMaster(prUnitSalePymtDto);
                    prUnitSaleDetailDTO.PrUnitSalePymts.Add(prUnitSalePymtDto);
                }
                else
                {
                    prUnitSalePymtDto = getSelectedPayment(0);
                    populatePaymentFromUI(prUnitSalePymtDto);
                    updatePymtMaster(prUnitSalePymtDto);
                }
                populateSalePymtGrid(prUnitSaleDetailDTO);
            }
            else
            {
                activeModalHdn.Value = addModifyPaymentModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelPaymentModal(object sender, EventArgs e)
    {
        try
        {
            setSelectedPayment(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validatePaymentAddModify()
    {
        bool isValid = true;
        Page.Validate(addModifyPaymentError);
        isValid = Page.IsValid;
        if (PaymentAction.MODIFY.ToString().Equals(paymentModalActionHdnBtn.Value))
        {
            isValid = validatePaymentUpdate(getSelectedPayment(0));
        }
        return isValid;
    }
    private bool validatePaymentDelete(long UiIndex)
    {
        bool isValid = true;
        PrUnitSalePymtDTO prUnitSalePymtDto = getSelectedPayment(UiIndex);
        string errorMsg = "";
        if (prUnitSalePymtDto.PaymentMaster.Status == PymtMasterStatus.Deleted)
        {
            errorMsg = "Payment is already deleted.";
        }
        else if (prUnitSalePymtDto.PaymentMaster.Status == PymtMasterStatus.Suspended)
        {
            errorMsg = "Payment is suspended, cannot be deleted.";
        }
        else if (isSalePayment(prUnitSalePymtDto.PymtType.Name) || isCancellationPayment(prUnitSalePymtDto.PymtType.Name))
        {
            errorMsg = string.Format("Deletion of Payment '{0}' is not allowed.", prUnitSalePymtDto.PymtType.Name);
        }
        else if (prUnitSalePymtDto.PaymentMaster.TotalPaid > 0)
        {
            errorMsg = "Full/Partial amount has been paid, Payment cannot be deleted.";
        }
        else if (prUnitSalePymtDto.PaymentMaster.TotalPdcAmt > 0)
        {
            errorMsg = "Post Dated Cheque payment is pending for selected Payment.";
        }
        if (!string.IsNullOrWhiteSpace(errorMsg))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(errorMsg));
            isValid = false;
        }
        return isValid;
    }
    private bool validatePaymentUpdate(PrUnitSalePymtDTO prUnitSalePymtDto)
    {
        bool isValid = true;
        decimal pymtAmt = CommonUtil.getDecimaNotNulllWithoutExt(txtPaymentAmount.Text);
        decimal diffAmt = Decimal.Subtract(pymtAmt, prUnitSalePymtDto.PaymentMaster.TotalAmt);
        decimal effectiveAmt = Decimal.Add(prUnitSalePymtDto.PaymentMaster.TotalAmt, diffAmt);
        if (effectiveAmt.CompareTo(prUnitSalePymtDto.PaymentMaster.TotalPaid) < 0)
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Payment amount can not be less than Total Paid amount."));
            isValid = false;
        }
        return isValid;
    }
    private void populateDrpPaymentType()
    {
        bool isModify = PaymentAction.MODIFY.ToString().Equals(paymentModalActionHdnBtn.Value);
        drpPaymentType.Items.Clear();
        foreach (ListItem item in drpAllPaymentType.Items)
        {
            if (isModify || !(isSalePayment(item.Text) || isCancellationPayment(item.Text)))
            {
                drpPaymentType.Items.Add(item);
            }
        }
    }
    //Property Charges Modal - End
}