﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.BO;

public partial class PropertyReportLetterTemplate : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
            log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string SelectTemplateModal = "SelectTemplateModal";
    DropdownBO drpBO = new DropdownBO();
    PropertyBO propertyBO = new PropertyBO();
    ReportConfigBO reportConfigBO = new ReportConfigBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                ReportLetterTemplateNavDTO navDto = ApplicationUtil.getPageNavDTO<ReportLetterTemplateNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.PROPERTY_REPORT_TEMPLATES)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
        * This method is called just before the page is rendered. So any change in state of the element is applied.
        **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    public void setErrorMessage(string message, string group)
    {
        string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }
    }
    private void doInit(ReportLetterTemplateNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void renderPageFieldsWithEntitlement()
    {

    }
    private void navigateToPreviousPage()
    {
        ReportLetterTemplatePageDTO PageDTO = getSessionPageData();
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is PropertyConfigurationNavDTO)
            {
                PropertyConfigurationNavDTO navDTO = (PropertyConfigurationNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.PROPERTY_CONFIGURATIONS, true);
            }
        }
        Response.Redirect(Constants.URL.PROPERTY_SEARCH, true);
    }
    private void initPageAfterRedirect(ReportLetterTemplateNavDTO navDto)
    {
        try
        {
            ReportLetterTemplatePageDTO PageDTO = new ReportLetterTemplatePageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            PageDTO.PropertyId = navDto.PropertyId;
            populatePropertyFields();

            fetchTemplateAndEnableTab(true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void fetchTemplateAndEnableTab(bool isLetterTab)
    {
        ReportLetterTemplatePageDTO PageDTO = getSessionPageData();
        IList<ReportTemplateMasterDTO> result = reportConfigBO.fetchPropertyReportTemplates(PageDTO.PropertyId);
        PageDTO.TemplateList = (result == null) ? new List<ReportTemplateMasterDTO>() : result.ToList<ReportTemplateMasterDTO>();

        EnableTab(isLetterTab);
    }
    private ReportLetterTemplatePageDTO getSessionPageData()
    {
        return (ReportLetterTemplatePageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private ReportTemplateMasterDTO getSelectedTemplateDTO(long Id)
    {
        List<ReportTemplateMasterDTO> tmpList = getSessionPageData().TemplateList;
        return (Id > 0) ? tmpList.Find(c => c.Id == Id) : null;
    }
    protected string getTemplateTypeDescription(string type)
    {
        return EnumHelper.ToEnum<ReportTemplateType>(type).GetDescription();
    }
    private void populatePropertyFields()
    {
        PropertyDTO propertyDTO = propertyBO.fetchPropertySelective(getSessionPageData().PropertyId);
        lbPropertyName.Text = propertyDTO.Name;
        lbPropertyType.Text = propertyDTO.PropertyType.Name;
        lbPropertyLocation.Text = propertyDTO.PropertyLocation.Name;
        lbReraRegNo.Text = propertyDTO.ReraRegNo;
    }
    private void EnableTab(bool isLetterTab)
    {
        ReportLetterTemplatePageDTO PageDTO = getSessionPageData();
        liLetterTemplates.Attributes["class"] = (isLetterTab) ? "active" : "";
        liReportTemplates.Attributes["class"] = (isLetterTab) ? "" : "active";


        List<ReportTemplateMasterDTO> tmpList = PageDTO.TemplateList.FindAll(x => (isLetterTab) ? CommonUIConverter.IsTemplateLetterType(x.TemplateType)
                : !CommonUIConverter.IsTemplateLetterType(x.TemplateType));
        populateTemplateGrid(tmpList);
    }
    private void populateTemplateGrid(List<ReportTemplateMasterDTO> tmpList)
    {
        templateGrid.DataSource = new List<ReportTemplateMasterDTO>();
        if (tmpList != null)
        {
            templateGrid.DataSource = tmpList;
        }
        templateGrid.DataBind();
    }
    protected void onClickLetterTemplates(object sender, EventArgs e)
    {
        try
        {
            EnableTab(true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickReportTemplates(object sender, EventArgs e)
    {
        try
        {
            EnableTab(false);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickTemplateType(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);

            ReportTemplateMasterDTO TemplateDTO = getSelectedTemplateDTO(selectedIndex);

            IList<ReportTemplateMasterDTO> result = reportConfigBO.fetchFirmReportTemplatesByType(getUserDefinitionDTO().FirmNumber, TemplateDTO.TemplateType);
            if (result != null && result.Count > 0)
            {
                ReportTemplateMasterDTO currentDTO = result.ToList<ReportTemplateMasterDTO>().Find(x => x.Id == TemplateDTO.Id);
                if (currentDTO != null) result.Remove(currentDTO);
            }
            getSessionPageData().TmpTemplateList = (result != null) ? result.ToList<ReportTemplateMasterDTO>() : new List<ReportTemplateMasterDTO>();
            SelectTemplateGrid.DataSource = (result != null) ? result : new List<ReportTemplateMasterDTO>();
            SelectTemplateGrid.DataBind();

            activeModalHdn.Value = SelectTemplateModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Select Template Modal - Start
    protected void onSelectTemplate(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            ReportLetterTemplatePageDTO PageDTO = getSessionPageData();
            ReportTemplateMasterDTO tmpDTO = PageDTO.TmpTemplateList.Find(x => x.Id == selectedIndex);
            if (tmpDTO != null)
            {
                reportConfigBO.assignReportTemplate(PageDTO.PropertyId, tmpDTO);
                fetchTemplateAndEnableTab(CommonUIConverter.IsTemplateLetterType(tmpDTO.TemplateType));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelSelectTemplateModal(object sender, EventArgs e)
    {
        try
        {
           
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Select Template Modal - End

}