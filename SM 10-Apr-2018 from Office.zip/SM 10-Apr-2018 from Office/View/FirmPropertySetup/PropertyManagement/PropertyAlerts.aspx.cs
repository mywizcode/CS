﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using ConstroSoft;

public partial class PropertyAlerts : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
            log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    DropdownBO drpBO = new DropdownBO();
    PropertyBO propertyBO = new PropertyBO();
    PropertyAlertBO propertyAlertBO = new PropertyAlertBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                PropertyAlertsNavDTO navDto = ApplicationUtil.getPageNavDTO<PropertyAlertsNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.PROPERTY_ALERT_CONFIG)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
        * This method is called just before the page is rendered. So any change in state of the element is applied.
        **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
    	ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    public void setErrorMessage(string message, string group)
    {
    	string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
	        CustomValidator val = new CustomValidator();
	        val.IsValid = false;
	        val.ErrorMessage = message;
	        val.ValidationGroup = group;
	        this.Page.Validators.Add(val);
        }
    }
    private void doInit(PropertyAlertsNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(PropertyAlertsNavDTO navDto)
    {
        try
        {
            PropertyAlertsPageDTO PageDTO = new PropertyAlertsPageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            PageDTO.PropertyId = navDto.PropertyId;
            populatePropertyFields();
            IList<PropertyAlertConfigDTO> result = propertyAlertBO.fetchPropertyAlerts(navDto.PropertyId);
            PageDTO.AlertList = (result == null) ? new List<PropertyAlertConfigDTO>() : result.ToList<PropertyAlertConfigDTO>();
            
            propertyAlertGrid.DataSource = PageDTO.AlertList;
            propertyAlertGrid.DataBind();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageFieldsWithEntitlement()
    {
    	
    }
    private void navigateToPreviousPage()
    {
        PropertyAlertsPageDTO PageDTO = getSessionPageData();
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is PropertyConfigurationNavDTO)
            {
                PropertyConfigurationNavDTO navDTO = (PropertyConfigurationNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.PROPERTY_CONFIGURATIONS, true);
            }
        }
        Response.Redirect(Constants.URL.PROPERTY_SEARCH, true);
    }
    private PropertyAlertsPageDTO getSessionPageData()
    {
        return (PropertyAlertsPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private void populatePropertyFields()
    {
    	PropertyDTO propertyDTO = propertyBO.fetchPropertySelective(getSessionPageData().PropertyId);
    	lbPropertyName.Text = propertyDTO.Name;
        lbPropertyType.Text = propertyDTO.PropertyType.Name;
        lbPropertyLocation.Text = propertyDTO.PropertyLocation.Name;
        lbReraRegNo.Text = propertyDTO.ReraRegNo;
    }
    protected string getFunctionName(string fnName)
    {
        return EnumHelper.ToEnum<PrAlertFunctionName>(fnName).GetDescription();
    }
    protected string getFunctionDescription(string fnName)
    {
    	return CommonUtil.getPrAlertFunctionDescription(fnName);
    }
    private PropertyAlertsNavDTO getCurrentPageNavigation()
    {
    	PropertyAlertsPageDTO PageDTO = getSessionPageData();
        PropertyAlertsNavDTO navDTO = new PropertyAlertsNavDTO();
        navDTO.PropertyId = PageDTO.PropertyId;
        navDTO.PrevNavDto = PageDTO.PrevNavDTO;
        return navDTO;
    }
    protected void onClickFunctionName(object sender, EventArgs e)
    {
        try
        {
        	LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            PropertyAlertConfigDTO tmpDTO = getSessionPageData().AlertList.Find(x => x.Id == selectedId);
            PropertyAlertDetailsNavDTO navDTO = new PropertyAlertDetailsNavDTO();
            navDTO.PropertyId = getSessionPageData().PropertyId;
            navDTO.AlertId = tmpDTO.Id;
            navDTO.PrevNavDto = getCurrentPageNavigation();
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.PROPERTY_ALERT_DETAILS, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
}