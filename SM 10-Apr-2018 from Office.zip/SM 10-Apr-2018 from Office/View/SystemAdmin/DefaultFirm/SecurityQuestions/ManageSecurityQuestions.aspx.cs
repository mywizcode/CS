﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;

public partial class ManageSecurityQuestions : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifySecurityQuestionModal = "addModifySecurityQuestionModal";
    string addModifySecurityQuestionModalError = "addModifySecurityQuestionModalError";
    DropdownBO drpBO = new DropdownBO();
    SystemAdminstrationBO sysAdminBO = new SystemAdminstrationBO();
    public enum SecurityQuestionModalAction { ADD, MODIFY }
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Form.Attributes.Add("enctype", "multipart/form-data");
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                ManageSecurityQuestionsNavDTO navDto = ApplicationUtil.getPageNavDTO<ManageSecurityQuestionsNavDTO>(Session);
                if (!CommonUtil.IsSystemAdminRole(getUserDefinitionDTO())) (this.Master as CSAdminMaster).doLogout(Constants.URL.SYS_ADMIN_LOGIN_FAILED);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSAdminMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    public void setErrorMessage(string message, string group)
    {
        string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else CommonUtil.getCustomValidator(Page, message, group);
    }
    private void doInit(ManageSecurityQuestionsNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new ManageSecurityQuestionsPageDTO();
        initDropdowns();
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(ManageSecurityQuestionsNavDTO navDto)
    {
        try
        {
            loadSecurityQuestions();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageFieldsWithEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();

    }
    private ManageSecurityQuestionsPageDTO getSessionPageData()
    {
        return (ManageSecurityQuestionsPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private void loadSecurityQuestions()
    {
        IList<SecurityQuestionDTO> results = sysAdminBO.fetchSecurityQuestions();
        getSessionPageData().SearchResult = (results != null) ? results.ToList<SecurityQuestionDTO>() : new List<SecurityQuestionDTO>();
        QuestionGrid.DataSource = getSessionPageData().SearchResult;
        QuestionGrid.DataBind();
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    protected void onClickDeleteSecurityQuestionBtn(object sender, EventArgs e)
    {
        try
        {
            long selectedId = getDeleteRecordHdnId();
            SecurityQuestionDTO selectedDTO = getSelectedSecurityQuestion(selectedId);
            sysAdminBO.deleteSecurityQuestion(selectedDTO.Id);
            //TODO- If Security Question already used then proper message should be displayed to user
            (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(CommonUtil.getRecordDeleteSuccessMsg("Security Question")));
            loadSecurityQuestions();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Security Question  Modal - Start
    private bool IsSecurityQuestionModalAddMode()
    {
        return (SecurityQuestionModalAction.ADD.ToString().Equals(SecurityQuestionModalActionHdnBtn.Value));
    }
    private bool IsSecurityQuestionModalModifyMode()
    {
        return (SecurityQuestionModalAction.MODIFY.ToString().Equals(SecurityQuestionModalActionHdnBtn.Value));
    }
    private void initSecurityQuestionModalFields()
    {
        lbSecurityQuestionModalTitle.Text = IsSecurityQuestionModalAddMode() ? Constants.ICON.ADD + "Add Security Question" : Constants.ICON.MODIFY + "Modify Security Question";
    }
    private void initSecurityQuestionSectionFields(SecurityQuestionDTO tmpDTO)
    {
        if (tmpDTO != null) txtSecurityQuestion.Text = tmpDTO.Question; else txtSecurityQuestion.Text = null;
    }
    private void populateSecurityQuestionFromUI(SecurityQuestionDTO tmpDTO)
    {
        tmpDTO.Question = txtSecurityQuestion.Text.TrimNullable();
        tmpDTO.UpdateUser = getUserDefinitionDTO().Username;
    }
    private SecurityQuestionDTO populateSecurityQuestionAdd()
    {
        SecurityQuestionDTO tmpDTO = new SecurityQuestionDTO();
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        tmpDTO.FirmNumber = Constants.SYSDEFAULT.DEFAULT_FIRM;
        tmpDTO.InsertUser = userDef.Username;
        return tmpDTO;
    }
    private void setSelectedSecurityQuestion(long Id)
    {
        List<SecurityQuestionDTO> tmpList = getSessionPageData().SearchResult;
        tmpList.ForEach(c => c.isUISelected = false);
        if (Id > 0) tmpList.Find(c => c.Id == Id).isUISelected = true;
    }
    private SecurityQuestionDTO getSelectedSecurityQuestion(long Id)
    {
        List<SecurityQuestionDTO> tmpList = getSessionPageData().SearchResult;
        return (Id > 0) ? tmpList.Find(c => c.Id == Id) : tmpList.Find(c => c.isUISelected);
    }
    protected void onClickAddSecurityQuestionBtn(object sender, EventArgs e)
    {
        try
        {
            SecurityQuestionModalActionHdnBtn.Value = SecurityQuestionModalAction.ADD.ToString();
            initSecurityQuestionModalFields();
            setSelectedSecurityQuestion(-1);
            initSecurityQuestionSectionFields(null);
            activeModalHdn.Value = addModifySecurityQuestionModal;
            SetFocus(txtSecurityQuestion);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifySecurityQuestionBtn(object sender, EventArgs e)
    {
        try
        {
            SecurityQuestionModalActionHdnBtn.Value = SecurityQuestionModalAction.MODIFY.ToString();
            initSecurityQuestionModalFields();
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedSecurityQuestion(selectedIndex);
            initSecurityQuestionSectionFields(getSelectedSecurityQuestion(0));
            activeModalHdn.Value = addModifySecurityQuestionModal;
            SetFocus(txtSecurityQuestion);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void saveSecurityQuestion(object sender, EventArgs e)
    {
        try
        {
            if (validateSecurityQuestionAddModify())
            {
                SecurityQuestionDTO tmpDTO = null;
                string msg = CommonUtil.getNotySuccessMsg(CommonUtil.getRecordAddSuccessMsg("Security Question"));
                if (IsSecurityQuestionModalAddMode())
                {
                    tmpDTO = populateSecurityQuestionAdd();
                }
                else
                {
                    tmpDTO = getSelectedSecurityQuestion(0);
                    msg = CommonUtil.getNotySuccessMsg(CommonUtil.getRecordModifySuccessMsg("Security Question"));
                }
                populateSecurityQuestionFromUI(tmpDTO);
                sysAdminBO.saveOrUpdateSecurityQuestion(tmpDTO);
                (this.Master as CSAdminMaster).setNotyMsg(msg);
                loadSecurityQuestions();
            }
            else
            {
                activeModalHdn.Value = addModifySecurityQuestionModal;
                SetFocus(txtSecurityQuestion);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelSecurityQuestionModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateSecurityQuestionAddModify()
    {
        Page.Validate(addModifySecurityQuestionModalError);
        bool IsValid = Page.IsValid;
        return IsValid;
    }
    //Security Question Modal - End
}