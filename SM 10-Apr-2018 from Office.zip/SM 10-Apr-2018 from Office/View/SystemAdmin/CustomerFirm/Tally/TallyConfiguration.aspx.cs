﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using ConstroSoft;

public partial class TallyConfiguration : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifyTallyConfigError = "addModifyTallyConfigError";
    string addModifyTallyConfigModal = "addModifyTallyConfigModal";
    DropdownBO drpBO = new DropdownBO();
    FirmBO firmBO = new FirmBO();
    public enum TallyConfigModalAction { ADD, MODIFY }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                TallyConfigurationNavDTO navDto = ApplicationUtil.getPageNavDTO<TallyConfigurationNavDTO>(Session);
                if (!CommonUtil.IsSystemAdminRole(getUserDefinitionDTO())) (this.Master as CSAdminMaster).doLogout(Constants.URL.SYS_ADMIN_LOGIN_FAILED);
                if (CommonUtil.getCurrentFirmDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToSystemDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSAdminMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
        addCheckBoxAttributes();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private void addCheckBoxAttributes()
    {
        cbTallyConfigEnable.InputAttributes.Add("class", "styled");
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];

    }
    public void setErrorMessage(string message, string group)
    {
        string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }
    }
    private void doInit(TallyConfigurationNavDTO navDTO)
    {
        Session[Constants.Session.PAGE_DATA] = new TallyConfigurationPageDTO();
        initDropdowns();
        loadTallyConfigGrid();
    }
    private void renderPageFieldsWithEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
    }
    private TallyConfigurationPageDTO getSessionPageData()
    {
        return (TallyConfigurationPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private void loadTallyConfigGrid()
    {
        TallyConfigurationPageDTO PageDTO = getSessionPageData();
        IList<TallyConfigDTO> result = firmBO.fetchTallyConfigs(CommonUtil.getCurrentFirmDTO(getUserDefinitionDTO()).FirmNumber);
        PageDTO.TallyConfigList = (result != null) ? result.ToList<TallyConfigDTO>() : new List<TallyConfigDTO>();

        populateTallyConfigGrid(PageDTO.TallyConfigList);
    }
    private void populateTallyConfigGrid(List<TallyConfigDTO> tmpList)
    {
        TallyConfigGrid.DataSource = new List<TallyConfigDTO>();
        if (tmpList != null)
        {
            assignUiIndexToTallyConfig(tmpList);
            TallyConfigGrid.DataSource = tmpList;
        }
        TallyConfigGrid.DataBind();
    }
    private void assignUiIndexToTallyConfig(List<TallyConfigDTO> tmpList)
    {

    }
    protected void onClickDeleteTallyConfigBtn(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            TallyConfigDTO selectedDTO = getSelectedTallyConfig(selectedIndex);
            firmBO.deleteTallyConfig(selectedDTO.Id);
            (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(CommonUtil.getRecordDeleteSuccessMsg("Tally Configuration")));
            loadTallyConfigGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //TallyConfig Modal - Start
    private bool isTallyConfigAddMode()
    {
        return (TallyConfigModalAction.ADD.ToString().Equals(TallyConfigModalActionHdnBtn.Value));
    }
    private void initTallyConfigModalFields()
    {
        lbTallyConfigModalTitle.Text = (TallyConfigModalAction.ADD.ToString().Equals(TallyConfigModalActionHdnBtn.Value))
            ? Constants.ICON.ADD + "Add Configuration" : Constants.ICON.MODIFY + "Modify Configuration";
    }
    private void initTallyConfigSectionFields(TallyConfigDTO tmpDTO)
    {
        if (tmpDTO != null) txtTallyConfigHost.Text = tmpDTO.Tallyhost; else txtTallyConfigHost.Text = null;
        if (tmpDTO != null) txtTallyConfigPort.Text = tmpDTO.Tallyport; else txtTallyConfigPort.Text = null;
        
        cbTallyConfigEnable.Checked = (tmpDTO != null && tmpDTO.IsEnabled == IsEnabled.Yes);
    }
    private void populateTallyConfigFromUI(TallyConfigDTO tmpDTO)
    {
        tmpDTO.Tallyhost = txtTallyConfigHost.Text.TrimNullable();
        tmpDTO.Tallyport = txtTallyConfigPort.Text.TrimNullable();
        tmpDTO.IsEnabled = (cbTallyConfigEnable.Checked) ? IsEnabled.Yes : IsEnabled.No;
        tmpDTO.UpdateUser = getUserDefinitionDTO().Username;
    }
    private TallyConfigDTO populateTallyConfigAdd()
    {
        TallyConfigDTO tmpDTO = new TallyConfigDTO();
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        tmpDTO.FirmNumber = CommonUtil.getCurrentFirmDTO(userDef).FirmNumber;
        tmpDTO.InsertUser = userDef.Username;
        return tmpDTO;
    }
    private void setSelectedTallyConfig(long Id)
    {
        List<TallyConfigDTO> tmpList = getSessionPageData().TallyConfigList;
        tmpList.ForEach(c => c.isUISelected = false);
        if (Id > 0) tmpList.Find(c => c.Id == Id).isUISelected = true;
    }
    private TallyConfigDTO getSelectedTallyConfig(long Id)
    {
        List<TallyConfigDTO> tmpList = getSessionPageData().TallyConfigList;
        return (Id > 0) ? tmpList.Find(c => c.Id == Id) : tmpList.Find(c => c.isUISelected);
    }
    protected void onClickAddTallyConfigBtn(object sender, EventArgs e)
    {
        try
        {
            TallyConfigModalActionHdnBtn.Value = TallyConfigModalAction.ADD.ToString();
            initTallyConfigModalFields();
            setSelectedTallyConfig(-1);
            initTallyConfigSectionFields(null);
            activeModalHdn.Value = addModifyTallyConfigModal;
            SetFocus(txtTallyConfigHost);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyTallyConfigBtn(object sender, EventArgs e)
    {
        try
        {
            TallyConfigModalActionHdnBtn.Value = TallyConfigModalAction.MODIFY.ToString();
            initTallyConfigModalFields();
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedTallyConfig(selectedIndex);
            initTallyConfigSectionFields(getSelectedTallyConfig(0));
            activeModalHdn.Value = addModifyTallyConfigModal;
            SetFocus(txtTallyConfigHost);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void saveTallyConfig(object sender, EventArgs e)
    {
        try
        {
            if (validateTallyConfigAddModify())
            {
                TallyConfigDTO tmpDTO = null;
                string msg = "";
                if (isTallyConfigAddMode())
                {
                    tmpDTO = populateTallyConfigAdd();
                    msg = CommonUtil.getNotySuccessMsg(CommonUtil.getRecordAddSuccessMsg("Tally Configuration"));
                }
                else
                {
                    tmpDTO = getSelectedTallyConfig(0);
                    msg = CommonUtil.getNotySuccessMsg(CommonUtil.getRecordModifySuccessMsg("Tally Configuration"));
                }
                populateTallyConfigFromUI(tmpDTO);
                firmBO.saveOrUpdateTallyConfig(tmpDTO);
                (this.Master as CSAdminMaster).setNotyMsg(msg);
                loadTallyConfigGrid();
            }
            else
            {
                activeModalHdn.Value = addModifyTallyConfigModal;
                SetFocus(txtTallyConfigHost);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelTallyConfigModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateTallyConfigAddModify()
    {
        Page.Validate(addModifyTallyConfigError);
        bool IsValid = Page.IsValid;
        if (IsValid)
        {
            if (isTallyConfigAddMode() && cbTallyConfigEnable.Checked)
            {
                if (getSessionPageData().TallyConfigList.Any(x => x.IsEnabled == IsEnabled.Yes))
                {
                    setErrorMessage("Another exotel configuration is already enabled.", addModifyTallyConfigError);
                }
            }
            else if (!isTallyConfigAddMode() && cbTallyConfigEnable.Checked)
            {
                TallyConfigDTO tmpDTO = getSelectedTallyConfig(0);
                if (getSessionPageData().TallyConfigList.Any(x => x.IsEnabled == IsEnabled.Yes && x.Id != tmpDTO.Id))
                {
                    setErrorMessage("Another exotel configuration is already enabled.", addModifyTallyConfigError);
                }
            }
        }
        return IsValid;
    }
    //TallyConfig Modal - End
}