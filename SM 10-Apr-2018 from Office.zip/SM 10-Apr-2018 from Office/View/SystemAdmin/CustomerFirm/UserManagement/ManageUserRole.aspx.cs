﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using ConstroSoft;

public partial class ManageUserRole : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifyUserRoleError = "addModifyUserRoleError";
    string addModifyUserRoleModal = "addModifyUserRoleModal";
    DropdownBO drpBO = new DropdownBO();
    SystemAdminstrationBO sysAdminBO = new SystemAdminstrationBO();
    public enum UserRoleModalAction { ADD, MODIFY }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                ManageUserRoleNavDTO navDto = ApplicationUtil.getPageNavDTO<ManageUserRoleNavDTO>(Session);
                if (!CommonUtil.IsSystemAdminRole(getUserDefinitionDTO())) (this.Master as CSAdminMaster).doLogout(Constants.URL.SYS_ADMIN_LOGIN_FAILED);
                if (CommonUtil.getCurrentFirmDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToSystemDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSAdminMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];

    }
    public void setErrorMessage(string message, string group)
    {
        string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }
    }
    private void doInit(ManageUserRoleNavDTO navDTO)
    {
        Session[Constants.Session.PAGE_DATA] = new ManageUserRolePageDTO();
        initDropdowns();
        loadUserRoleGrid();
    }
    private void renderPageFieldsWithEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
    }
    private ManageUserRolePageDTO getSessionPageData()
    {
        return (ManageUserRolePageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private void loadUserRoleGrid()
    {
        ManageUserRolePageDTO PageDTO = getSessionPageData();
        IList<UserRoleDTO> result = sysAdminBO.fetchUserRoles(CommonUtil.getCurrentFirmDTO(getUserDefinitionDTO()).FirmNumber);
        PageDTO.UserRoleList = (result != null) ? result.ToList<UserRoleDTO>() : new List<UserRoleDTO>();

        populateUserRoleGrid(PageDTO.UserRoleList);
    }
    private void populateUserRoleGrid(List<UserRoleDTO> tmpList)
    {
        UserRoleGrid.DataSource = new List<UserRoleDTO>();
        if (tmpList != null)
        {
            assignUiIndexToUserRole(tmpList);
            UserRoleGrid.DataSource = tmpList;
        }
        UserRoleGrid.DataBind();
    }
    private void assignUiIndexToUserRole(List<UserRoleDTO> tmpList)
    {
        if (tmpList != null && tmpList.Count > 0)
        {
            foreach (UserRoleDTO tmpDTO in tmpList)
            {

            }
        }
    }
    protected void onClickDeleteUserRoleBtn(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            UserRoleDTO selectedDTO = getSelectedUserRole(selectedIndex);
            sysAdminBO.deleteUserRole(selectedDTO.Id);
            (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(CommonUtil.getRecordDeleteSuccessMsg("User Role")));
            loadUserRoleGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //UserRole Modal - Start
    private bool isUserRoleAddMode()
    {
        return (UserRoleModalAction.ADD.ToString().Equals(UserRoleModalActionHdnBtn.Value));
    }
    private void initUserRoleModalFields()
    {
        lbUserRoleModalTitle.Text = (UserRoleModalAction.ADD.ToString().Equals(UserRoleModalActionHdnBtn.Value))
            ? Constants.ICON.ADD + "Add User Role" : Constants.ICON.MODIFY + "Modify User Role";
    }
    private void initUserRoleSectionFields(UserRoleDTO tmpDTO)
    {
        if (tmpDTO != null) txtUserRoleName.Text = tmpDTO.Name; else txtUserRoleName.Text = null;
        if (tmpDTO != null) txtUserRoleDescription.Text = tmpDTO.Description; else txtUserRoleDescription.Text = null;
    }
    private void populateUserRoleFromUI(UserRoleDTO tmpDTO)
    {
        tmpDTO.Name = txtUserRoleName.Text.TrimNullable();
        tmpDTO.Description = txtUserRoleDescription.Text.TrimNullable();
        tmpDTO.UpdateUser = getUserDefinitionDTO().Username;
    }
    private UserRoleDTO populateUserRoleAdd()
    {
        UserRoleDTO tmpDTO = new UserRoleDTO();
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        tmpDTO.FirmNumber = CommonUtil.getCurrentFirmDTO(userDef).FirmNumber;
        tmpDTO.InsertUser = userDef.Username;
        return tmpDTO;
    }
    private void setSelectedUserRole(long Id)
    {
        List<UserRoleDTO> tmpList = getSessionPageData().UserRoleList;
        tmpList.ForEach(c => c.isUISelected = false);
        if (Id > 0) tmpList.Find(c => c.Id == Id).isUISelected = true;
    }
    private UserRoleDTO getSelectedUserRole(long Id)
    {
        List<UserRoleDTO> tmpList = getSessionPageData().UserRoleList;
        return (Id > 0) ? tmpList.Find(c => c.Id == Id) : tmpList.Find(c => c.isUISelected);
    }
    protected void onClickAddUserRoleBtn(object sender, EventArgs e)
    {
        try
        {
            UserRoleModalActionHdnBtn.Value = UserRoleModalAction.ADD.ToString();
            initUserRoleModalFields();
            setSelectedUserRole(-1);
            initUserRoleSectionFields(null);
            activeModalHdn.Value = addModifyUserRoleModal;
            SetFocus(txtUserRoleName);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyUserRoleBtn(object sender, EventArgs e)
    {
        try
        {
            UserRoleModalActionHdnBtn.Value = UserRoleModalAction.MODIFY.ToString();
            initUserRoleModalFields();
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedUserRole(selectedIndex);
            initUserRoleSectionFields(getSelectedUserRole(0));
            activeModalHdn.Value = addModifyUserRoleModal;
            SetFocus(txtUserRoleName);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void saveUserRole(object sender, EventArgs e)
    {
        try
        {
            if (validateUserRoleAddModify())
            {
                UserRoleDTO tmpDTO = null;
                string msg = "";
                if (isUserRoleAddMode())
                {
                    tmpDTO = populateUserRoleAdd();
                    msg = CommonUtil.getNotySuccessMsg(CommonUtil.getRecordAddSuccessMsg("User Role"));
                }
                else
                {
                    tmpDTO = getSelectedUserRole(0);
                    msg = CommonUtil.getNotySuccessMsg(CommonUtil.getRecordModifySuccessMsg("User Role"));
                }
                populateUserRoleFromUI(tmpDTO);
                sysAdminBO.saveOrUpdateUserRole(tmpDTO);
                (this.Master as CSAdminMaster).setNotyMsg(msg);
                loadUserRoleGrid();
            }
            else
            {
                activeModalHdn.Value = addModifyUserRoleModal;
                SetFocus(txtUserRoleName);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelUserRoleModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateUserRoleAddModify()
    {
        Page.Validate(addModifyUserRoleError);
        bool IsValid = Page.IsValid;
        if (IsValid)
        {
            if (isUserRoleAddMode())
            {
                ManageUserRolePageDTO PageDTO = getSessionPageData();
                if (PageDTO.UserRoleList.Any(x => x.Name.Equals(txtUserRoleName.Text.TrimNullable())))
                {
                    setErrorMessage("User Role with same name already exist.", addModifyUserRoleError);
                    IsValid = false;
                }
            }
        }
        return IsValid;
    }
    //UserRole Modal - End
}