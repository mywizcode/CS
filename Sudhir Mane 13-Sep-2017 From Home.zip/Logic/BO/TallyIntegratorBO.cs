﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using NHibernate;
using NHibernate.Criterion;
using NHibernate.Impl;
using NHibernate.Transform;
using ConstroSoft.Logic.Util;
using System.Net;
using System.IO;

namespace ConstroSoft.Logic.BO
{

    public class TallyIntegratorBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        AgencyBO agencyBO = new AgencyBO();
        CustomerBO customerBO = new CustomerBO();
        PaymentVoucherBO paymentVoucherBO = new PaymentVoucherBO();

        public TallyIntegratorBO() { }

        public void processTallyRequest(string firmNumber, IList<PaymentVoucherDTO> results)
        {
            RENVELOPE renvelope = null;
            try
            {
                TallyConfigDTO tallyConfigDTO = fetchTallyConfiguration(firmNumber);
                foreach (PaymentVoucherDTO paymentVoucher in results)
                {
                    try
                    {
                        Boolean masterPosted = true;
                        if (paymentVoucher.VoucherType.Equals("Create") && paymentVoucher.VoucherType.Equals(VoucherType.Payment.ToString()))
                        {
                            masterPosted = postAgencyMaster(tallyConfigDTO, firmNumber, paymentVoucher, masterPosted);
                        }
                        if (paymentVoucher.VoucherType.Equals("Create") && paymentVoucher.VoucherType.Equals(VoucherType.Receipt.ToString()))
                        {
                            masterPosted = postCustomerMaster(tallyConfigDTO, firmNumber, paymentVoucher, masterPosted);
                        }
                        if (masterPosted)
                        {
                            VENVELOPE envelopVoucher = ObjectToXMLConverter.populateVoucher(paymentVoucher);
                            renvelope = postPaymentVoucher(tallyConfigDTO, firmNumber, envelopVoucher);
                            if (renvelope.RHEADER.STATUS.Equals("0"))
                            {
                                paymentVoucher.PostingStatus = "Posted";
                                paymentVoucherBO.updatePaymentVoucher(paymentVoucher);
                            }
                            else
                            {
                                log.Error("Exception while Posting Voucher Tally :");
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while connecting Tally :", e);
                    }
                }
            }
            catch (Exception e)
            {
                log.Error("Exception while connecting Tally :", e);
                throw new Exception("Unable to connect to the Tally server");
            }
        }

        private bool postCustomerMaster(TallyConfigDTO tallyConfigDTO, string firmNumber, PaymentVoucherDTO paymentVoucher, Boolean masterPosted)
        {
            CustomerDTO customerDTO = customerBO.GetByProperty(paymentVoucher.PartyLedgerName);
            if (customerDTO.Tallystatus == null || customerDTO.Tallystatus.Equals("Pending"))
            {
                ENVELOPE ledgerCustomerEnvelop = ObjectToXMLConverter.populateLedgerFromCustomer(customerDTO);
                RENVELOPE renvelopeCustomer = postLedgerMaster(tallyConfigDTO, firmNumber, ledgerCustomerEnvelop);
                if (!renvelopeCustomer.RHEADER.STATUS.Equals("0"))
                {
                    masterPosted = false;
                }
                else
                {
                    customerDTO.Tallystatus = "Posted";
                    customerBO.updateCustomer(customerDTO);
                }
            }
            return masterPosted;
        }

        private bool postAgencyMaster(TallyConfigDTO tallyConfigDTO, string firmNumber, PaymentVoucherDTO paymentVoucher, Boolean masterPosted)
        {
            AgencyDTO agencyDTO = agencyBO.GetByProperty("AgencyName", paymentVoucher.PartyLedgerName);
            if (agencyDTO.Tallystatus != null && agencyDTO.Tallystatus.Equals("Pending"))
            {   
                ENVELOPE ledgerAgencyEnvelop = ObjectToXMLConverter.populateLedgerFromAgency(agencyDTO);
                RENVELOPE renvelopeAgency = postLedgerMaster(tallyConfigDTO, firmNumber, ledgerAgencyEnvelop);
                if (!renvelopeAgency.RHEADER.STATUS.Equals("0"))
                {
                    masterPosted = false;
                }
                else
                {
                    agencyDTO.Tallystatus = "Posted";
                    agencyBO.updateAgency(agencyDTO);
                }
            }
            return masterPosted;
        }

        public TallyConfigDTO fetchTallyConfiguration(string firmNumber)
        {
            ISession session = null;
            TallyConfigDTO tallyConfigDTO = new TallyConfigDTO();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        TallyConfig tallyConfig = session.CreateCriteria<TallyConfig>().Add(
                            NHibernate.Criterion.Expression.Eq("FirmNumber", firmNumber)).List<TallyConfig>().FirstOrDefault();
                        tallyConfigDTO = DomainToDTOUtil.convertToTallyConfigDTO(tallyConfig);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching Tally configuration :", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return tallyConfigDTO;
        }
        public RENVELOPE postLedgerMaster(TallyConfigDTO tallyConfigDTO, string firmNumber, ENVELOPE envelopLedger)
        {
            RENVELOPE renvelope = null;
            try
            {
                string ledgerMasterXML = ObjectToXMLConverter.Serialize<ENVELOPE>(envelopLedger);
                renvelope = postDataToTally(tallyConfigDTO, firmNumber, renvelope, ledgerMasterXML);
            }
            catch (Exception e)
            {
                log.Error("Exception while connecting Tally :", e);
                throw new Exception("Unable to connect to the Tally server");
            }
            return renvelope;
        }

        public RENVELOPE postPaymentVoucher(TallyConfigDTO tallyConfigDTO, string firmNumber, VENVELOPE envelopVoucher)
        {
            RENVELOPE renvelope = null;
            try
            {
                string voucherXML = ObjectToXMLConverter.Serialize<VENVELOPE>(envelopVoucher);
                renvelope = postDataToTally(tallyConfigDTO, firmNumber, renvelope, voucherXML);
            }
            catch (Exception e)
            {
                log.Error("Exception while connecting Tally :", e);
                throw new Exception("Unable to connect to the Tally server");
            }
            return renvelope;
        }

        private RENVELOPE postDataToTally(TallyConfigDTO tallyConfigDTO, string firmNumber, RENVELOPE renvelope, string xmlData)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create("http://" + tallyConfigDTO.Tallyhost + ":" + tallyConfigDTO.Tallyport + "");
            byte[] bytes;
            bytes = System.Text.Encoding.ASCII.GetBytes(xmlData);
            request.ContentType = "text/xml; encoding='utf-8'";
            request.ContentLength = bytes.Length;
            request.Method = "POST";
            Stream requestStream = request.GetRequestStream();
            requestStream.Write(bytes, 0, bytes.Length);
            requestStream.Close();
            HttpWebResponse response;
            response = (HttpWebResponse)request.GetResponse();
            if (response.StatusCode == HttpStatusCode.OK)
            {
                Stream responseStream = response.GetResponseStream();
                string responseStr = new StreamReader(responseStream).ReadToEnd();
                renvelope = XMLToObjectConverter.Deserialize<RENVELOPE>(responseStr);
            }
            return renvelope;
        }
    }
}