﻿
/// <summary>
/// Summary description for MyENUM
/// </summary>

using System;
using System.ComponentModel;
namespace ConstroSoft
{
    /*ENUMs which are used to map Only UI fields*/
    public enum DrpDataType
    {
        MASTER_CONTROL_DATA,////Fetch all records for given type
        MASTER_CONTROL_DATA_N,//Fetch records for given type with SYSTEM_DEFINED = "N"
        COUNTRY,
        STATE,
        CITY,
        SECURITY_QUESTION,
        ENQUIRY_STATUS,
        ENQUIRY_CUSTOMER_NAME,
        ENQUIRY_REFERENCE_NUMBER,
        EMPLOYEE_SEARCH_BY_NAME,
        EMPLOYEE_SEARCH_BY_ID,
        GENDER,
        MARITAL_STATUS,
        PROPERTY_NAME,
        EMPLOYEE_NAME,
        PREFERRED_ADDRESS,
        PR_AVAILABLE_PARKING,
        PROPERTY_USER_ACCESS,
        PROPERTY_SEARCH_BY_TYPE,
        PROPERTY_SEARCH_BY_LOCATION,
        PYMT_SEARCH_BY_CUSTOMER_NAME,
        PYMT_SEARCH_BY_UNITNO,
        FIRM_ACCOUNT,
        PROPERTY_TOWER,
        RELATION_WITH_CUSTOMER,
        PR_UNIT_SEARCH_BY_UNITNO,
        PR_UNIT_SEARCH_BY_FLOORNO,
        PR_UNIT_SEARCH_BY_WING,
        CUSTOMER_SEARCH_BY_NAME,
        CUSTOMER_SEARCH_BY_NAME_REF,
        AVAIL_UNIT_SEARCH_BY_PR_UNIT,
        PR_AVAILABLE_UNIT,
        PROPERTY_UNIT_FLOOR,
		PARKING_TYPE,	    
        PROPERTY_LOCATION,
        PROPERTY_TYPE,  
        AGENCY,
        PDC_FIRM,
        PDC_CUSTOMER,
        PDC_AGENCY,
        PDC_PAYEE_CUSTOMER,
        PROPERTY_CHARGES,
        AGENCY_SEARCHBY_AGENCYNAME,
        AGENCY_SEARCHBY_AGENCYTYPE,
        AGENCY_SEARCHBY_OWNERNAME,
        FROM_EMAIL_ID,
        PR_PARKING_SEARCH_BY_PARKINGNO
    }
    public enum AcntTransStmtOption
    {
        [Description("Current Month")]
        CURRENT_MONTH,
        [Description("Last Two Months")]
        LAST_TWO_MONTHS,
        [Description("Last Three Months")]
        LAST_THREE_MONTHS,
        [Description("Date Range")]
        DATE_RANGE
    }
    public enum EnquirySearchBy 
    {
        [Description("-Select-")]NONE, 
        [Description("Customer Name")]CUSTOMER_NAME,
        [Description("Property Name")] PROP_NAME, 
        [Description("Property Type")] PROP_TYPE,
        [Description("Property Location")] PROP_LOCATION,
        [Description("Property Unit Type")] PROP_UNIT_TYPE,
        [Description("Employee Name")] EMPLOYEE_NAME,
        [Description("Enquiry Source")] ENQUIRY_SOURCE,
        [Description("Enquiry Name")] Enquiry_Name
    }
    public enum EmployeeSearchBy
    {
        [Description("--Select--")]
        NONE,
        [Description("Employee Name")]
        EMPLOYEE_NAME,
        [Description("Employee Id")]
        EMPLOYEE_ID
    }
    public enum PropertySearchBy
    {
        [Description("--Select--")]
        NONE,
        [Description("Property Name")]
        PROPERTY_NAME,
        [Description("Property Type")]
        PROPERTY_TYPE,
        [Description("Property Location")]
        PROPERTY_LOCATION
    }
    public enum ExpensesSearchBy
    {
        [Description("--Select--")]
        NONE,
        [Description("Property Name")]
        PROPERTY_NAME,
        [Description("Property Type")]
        PROPERTY_TYPE,
        [Description("Property Location")]
        PROPERTY_LOCATION
    }

    public enum FollowupSearchBy
    {
        [Description("--Select--")]
        NONE,
        [Description("All")]
        All,
        [Description("Customer Name")]
        Customer_Name,
        [Description("Enquiry Name")]
        Enquiry_Name
        // [Description("Customer Name")]CUSTOMER_NAME,
    }
    public enum PromotionSearchBy
    {
        [Description("--Select--")]
        NONE,
        [Description("All Customers")]
        All,
        [Description("Customers From Enquiry")]
        ENQ_CUSTOMERS,
        [Description("Customers From Unit Sale")]
        SALE_CUSTOMERS
    }

    public enum AccountNoSearchBy
    {
        [Description("--Select--")]
        NONE,
        [Description("Account Number")]
        Account_Number
    }

    //Property  Unit Search By
    public enum PropertyUnitSearchBy
    {
        [Description("--Select--")]
        NONE,
        [Description("Unit No")]
        UNIT_NO,
        [Description("Wing")]
        WING,
        [Description("Unit Type")]
        UNIT_TYPE,
        [Description("Floor No")]
        FLOOR_NO,
        [Description("Status")]
        STATUS,
        
    }
    //Payment Voucher Search By
    public enum PaymentVoucherSearchBy
    {
        [Description("--Select--")]
        NONE,
        [Description("Voucher Type")]
        VOUCHER_TYPE,
        [Description("Action")]
        ACTION,
        [Description("Posting Status")]
        POSTING_STATUS,
    }


    /*ENUMs which are used to map DB and UI fields. NOTE: If you add/remove any value then you need to modify corresponding DB mapping in EnumDBHelper.cs*/
    public enum UserStatus { Setup, Active, InActive }
    public enum PreferredAddress { Yes, No }
    public enum MaritalStatus { Single, Married }
    public enum Gender { Male, Female }
    public enum EnquiryStatus { Open, Won, Lost, Closed}
	public enum PowerOfAtorny { Yes, No }
    public enum SystemDefined { Yes, No }
    public enum CommonParking { Yes, No }
    public enum ParkingStatus { Available, Reserved, Allotted, Deleted }
    public enum PRScheduleStageStatus { Pending, Completed }
    public enum IncludeInPymtTotal { Yes, No }
    public enum PRUnitStatus { Available, Reserved, Sold, Deleted }
    public enum PRUnitSaleStatus { Sold, Cancelled }
    public enum VoucherType { Payment, Receipt }
    public enum TallyPostingStatus {Pending, Posted }
    public enum Action { Create, Cancel }
    public enum PaymentMode{ Receivable, Payable }
    public enum FunctionName
    {
        [Description("Manage Enquiry")]
        ENQUIRY,
        [Description("Manage Sales")]
        SALE
    }
    public enum EmailSmsType
    {
        [Description("Enquiry Thanks")]
        ENQUIRYTHANKS,
        [Description("Sale Thanks")]
        SALESTHANKS,
        [Description("Sale Cancel")]
        SALESCANCEL
    }
    public enum IsPossessionDone { No, Yes }
    public enum IsAgreementDone { No, Yes }
    public enum PymtTransStatus { Pending, Paid, Deleted, Reversal }
    public enum ChequeStatus { Collected, Deposited, Cleared, Bounced, Returned }
    public enum MPTPymtStatus { Pending, Paid, Deleted }
    public enum PymtMasterStatus
    {
        [Description("Paid")]
        Paid,
        [Description("Pending")]
        Pending,
        [Description("Deleted")]
        Deleted,
        [Description("Suspended")]
        Suspended
    }
    public enum PaymentMethod
    {
        [Description("Cash")]
        CASH,
        [Description("Cheque")]
        CHEQUE,
        [Description("RTGS")]
        RTGS,
        [Description("NEFT")]
        NEFT,
        [Description("Demand Draft")]
        DD
    }
    public enum AcntTransStatus { Credit, Debit }
    public enum PromoCustomerType { ENQUIRY, SALE, CO_CUSTOMER, ONLY_CUSTOMER }
    public enum AcntDepositStatus { Deposited, Reversed }

    public enum DocumentOwner
    {
        [Description("--Select--")]
        NONE,
        [Description("Property Name")]
        PROPERTY_NAME,
        [Description("Customer Name")]
        CUSTOMER_NAME,
        [Description("Supplier Name")]
        SUPPLIER_NAME,
        [Description("Contractor Name")]
        CONTACTOR_NAME,
        [Description("Employee Name")]
        EMPLOYEE_NAME
    }

    public enum MasterDataType
    {
        [Description("--Select--")]
        NONE,
        [Description("Salutation")]
        SALUTATION,
        [Description("Address Type")]
        ADDRESS_TYPE,
        [Description("Designation")]
        DESIGNATION,
        [Description("Security Question")]
        SECURITY_QUESTION,
        [Description("Account Type")]
        ACCOUNT_TYPE,
        [Description("Property Type")]
        PROPERTY_TYPE,
        [Description("Property Location")]
        PROPERTY_LOCATION,
        [Description("Property Tax Type")]
        PR_TAX_TYPE,
        [Description("Expenses Type")]
        PR_EXPENSE_TYPE,
        [Description("Parking Type")]
        PR_PARKING_TYPE,
        [Description("Unit Facing")]
        PR_UNIT_FACING,
        [Description("Occupation")]
        OCCUPATION,
        [Description("Customer Relation")]
        CUSTOMER_RELATION,
        [Description("Unit Payment Type")]
        PR_UNIT_PYMT_TYPE,
        [Description("Purchase Item Quality")]
        PURCHASE_ITEM_QUALITY,
        [Description("Contractor Type")]
        CONTRACTOR_TYPE,
        [Description("Enquiry Source")]
        ENQUIRY_SOURCE,
        [Description("Enquiry Media Type")]
        ENQUIRY_MEDIA_TYPE,
        [Description("Document Type")]
        DOCUMENT_TYPE,
        [Description("Property Unit Type")]
        PR_UNIT_TYPE,
        [Description("Property Unit Direction")]
        PR_UNIT_DIRECTION
    }

    public enum SelectLettersName
    {
        [Description("--Select--")]
        NONE,        
        [Description("Demand Letter")]
        DEMAND_LETTER,
        [Description("Possession Letter")]
        POSSESSION,
        [Description("Mortaguage Letter")]
        MORTGUAGE
    }

    
    //AGENCY
    public enum AgencySearchBy
    {
        [Description("--Select--")]
        NONE,
        [Description("Agency Name")]
        Agency_Name,
        [Description("Owner Name")]
        Owner_Name,
        [Description("Agency Type")]
        Agency_Type
    }
    public enum DashboardEvent
    {
        [Description("Possession")]
        POSSESSION,
        [Description("Agreement")]
        AGREEMENT
    }
    public enum PageMode {ADD, VIEW, MODIFY}
}