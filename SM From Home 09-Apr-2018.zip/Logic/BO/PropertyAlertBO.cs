﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;


/// <summary>
/// Summary description for PropertyAlertBO
/// </summary>
namespace ConstroSoft
{
    public class PropertyAlertBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public PropertyAlertBO() { }

        public IList<PropertyAlertConfigDTO> fetchPropertyAlerts(long PropertyId)
        {
            ISession session = null;
            IList<PropertyAlertConfigDTO> result = new List<PropertyAlertConfigDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	PropertyAlertConfig pac = null;
                    	EmailConfig ec = null;
                    	SmsConfig sc = null;
                    	Property p = null;
                    	
                    	PropertyAlertConfigDTO pacDTO = null;
                    	var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => pac.Id).WithAlias(() => pacDTO.Id))
                                .Add(Projections.Property(() => pac.FunctionName).WithAlias(() => pacDTO.FunctionName))
                                .Add(Projections.Property(() => pac.EmailEnabled).WithAlias(() => pacDTO.EmailEnabled))
                                .Add(Projections.Property(() => pac.SmsEnabled).WithAlias(() => pacDTO.SmsEnabled))
                                .Add(Projections.Property(() => ec.Name), "EmailConfig.Name")
                                .Add(Projections.Property(() => sc.Name), "SmsConfig.Name");
	                    var query = session.QueryOver<PropertyAlertConfig>(() => pac)
                            .Inner.JoinAlias(() => pac.Property, () => p)
	                        .Left.JoinAlias(() => pac.EmailConfig, () => ec)
	                        .Left.JoinAlias(() => pac.SmsConfig, () => sc);
	                    
	                    result = query.Where(() => p.Id == PropertyId)
	                        .Select(proj)
	                        .TransformUsing(new DeepTransformer<PropertyAlertConfigDTO>()).List<PropertyAlertConfigDTO>();
                    } catch (Exception e)
                    {
                        log.Error("Exception while fetching Property Alert Configs:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public PropertyAlertConfigDTO fetchPropertyAlertDetails(long AlertId)
        {
            ISession session = null;
            PropertyAlertConfigDTO result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	PropertyAlertConfig config = session.Get<PropertyAlertConfig>(AlertId);
                    	result = DomainToDTOUtil.convertToPropertyAlertConfigDTO(config, true, true);
                    } catch (Exception e)
                    {
                        log.Error("Exception while fetching Property Alert Details:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public PropertyAlertConfigDTO fetchPropertyAlertDetailsByFunction(long PropertyId, PrAlertFunctionName FunctionName)
        {
            ISession session = null;
            PropertyAlertConfigDTO result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	PropertyAlertConfig alert = null;
                    	Property p = null;
                    	
                    	PropertyAlertConfig config = session.QueryOver<PropertyAlertConfig>(() => alert)
            					.Inner.JoinAlias(() => alert.Property, () => p)
            					.Where(() => p.Id == PropertyId && alert.FunctionName == FunctionName).SingleOrDefault<PropertyAlertConfig>();
                    	if(config != null) {
                    		result = DomainToDTOUtil.convertToPropertyAlertConfigDTO(config, true, true);
                    	}
                    } catch (Exception e)
                    {
                        log.Error("Exception while fetching Property Alert Details by function name for a property:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public byte[] fetchAttachmentContent(long Id)
        {
            ISession session = null;
            byte[] result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	PropertyAlertConfigAttachment attachment = session.Get<PropertyAlertConfigAttachment>(Id);
                    	result = attachment.Content;
                    } catch (Exception e)
                    {
                        log.Error("Exception while fetching Property Alert Config Attachment Content:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public void savePropertyAlertDetails(PropertyAlertConfigDTO configDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	PropertyAlertConfig config = session.Get<PropertyAlertConfig>(configDTO.Id);
                    	DTOToDomainUtil.populatePropertyAlertUpdateFields(config, configDTO);
                    	
                        session.Update(config);
                        tx.Commit();
                    } catch (Exception e)
                    {
                    	tx.Rollback();
                        log.Error("Exception while updaing Property Alert Details:", e);
                        throw new CustomException(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public object[] fetchEmailAndSMSDetailsForPropertyAlerts(long PropertyId, long EntityId, PrAlertFunctionName FunctionName)
        {
            ISession session = null;
            object[] tmpResult = new object[2];
        	try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	PropertyAlertConfig alert = null;
                    	Property p = null;
                        PropertyAlertConfig config = session.QueryOver<PropertyAlertConfig>(() => alert)
            					.Inner.JoinAlias(() => alert.Property, () => p)
            					.Where(() => p.Id == PropertyId && alert.FunctionName == FunctionName).SingleOrDefault<PropertyAlertConfig>();
                        
                        if(config != null && (config.EmailEnabled == EmailSmsEnabled.Yes || config.SmsEnabled == EmailSmsEnabled.Yes)) {
                        	PropertyAlertConfigDTO configDTO = DomainToDTOUtil.convertToPropertyAlertConfigDTO(config, true, true);
                        			
                        	//Fetch Owner and Co-Customer details
                        	List<string> EntityTypeList = new List<string>();
                            if (PrAlertFunctionName.ENQ_ADD_CUSTOMER == FunctionName) EntityTypeList.Add(Constants.VWCustomerEntityType.ENQUIRY);
                            else if (PrAlertFunctionName.LD_ADD_CUSTOMER == FunctionName) EntityTypeList.Add(Constants.VWCustomerEntityType.LEAD);
                            else {
                            	EntityTypeList.Add(Constants.VWCustomerEntityType.UNIT_OWNER);
                            	EntityTypeList.Add(Constants.VWCustomerEntityType.UNIT_CO_OWNER);
                            }
                        	IList<VwCustomer> customerList = session.QueryOver<VwCustomer>().Where(vw => vw.EntityId == EntityId 
                                && vw.EntityType.IsIn(EntityTypeList)).List<VwCustomer>();

                        	tmpResult[0] = configDTO;
                    		tmpResult[1] = customerList;
                        }
                    } catch (Exception e)
                    {
                        log.Error("Exception while fetching Email SMS details for Property alert function:" + FunctionName.ToString(), e);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        	return tmpResult;
        }
        public void sendEmailAndSMSForPropertyAlerts(long PropertyId, long EntityId, PrAlertFunctionName FunctionName)
        {
        	try
            {
        		object[] tmpResult = fetchEmailAndSMSDetailsForPropertyAlerts(PropertyId, EntityId, FunctionName);
        		if(tmpResult != null) {
        			PropertyAlertConfigDTO configDTO = (PropertyAlertConfigDTO)tmpResult[0];
        			IList<VwCustomer> customerList = (IList<VwCustomer>)tmpResult[1];
        			if(configDTO != null && customerList != null && customerList.Count > 0) {
        				VwCustomer tmpCustomer = null;
                    	if(PrAlertFunctionName.UNIT_BOOKING_CUSTOMER == FunctionName || PrAlertFunctionName.UNIT_CANCELLATION_CUSTOMER == FunctionName){
                            tmpCustomer = customerList.ToList<VwCustomer>().Find(x => x.EntityType == Constants.VWCustomerEntityType.UNIT_OWNER);
                    	} else {
                    		tmpCustomer = customerList[0];
                    	}
                    	
                    	if(configDTO.EmailEnabled == EmailSmsEnabled.Yes) 
                    	{
                    		EmailDTO emailDTO = new EmailDTO();
                    		emailDTO.FromEmail = configDTO.EmailConfig.Email;
                    		emailDTO.Password = configDTO.EmailConfig.Password;
                    		emailDTO.SmtpHost = configDTO.EmailConfig.SmtpHost;
                    		emailDTO.SmtpPort = configDTO.EmailConfig.SmtpPort;
                    		emailDTO.EnableSsl = (configDTO.EmailConfig.EnableSsl == EmailEnableSSL.Yes);
                    		emailDTO.Subject = configDTO.Subject;
                            emailDTO.EmailContent = EmailUtil.ReplacePlaceholders(StringUtil.getBytesAsEmailContentString(configDTO.EmailContent), tmpCustomer);
                    		emailDTO.RecipientList = new List<string>();
                    		foreach(VwCustomer vw in customerList) {
                    			if (!string.IsNullOrWhiteSpace(vw.Email)) emailDTO.RecipientList.Add(vw.Email);
                    			if (!string.IsNullOrWhiteSpace(vw.AltEmail)) emailDTO.RecipientList.Add(vw.AltEmail);
                    		}
                            if (emailDTO.RecipientList.Count > 0)
                            {
                    			emailDTO.Attachments = new List<AttachmentDTO>();
                        		if(configDTO.Attachments != null) {
                        			foreach(PropertyAlertConfigAttachmentDTO tmpDTO in configDTO.Attachments) {
                        				emailDTO.Attachments.Add(new AttachmentDTO(tmpDTO.FileName, tmpDTO.Content));
                        			}
                        		}
                        		EmailSMSUtil.SendEmail(emailDTO);
                    		}
                    	}
                    	if(configDTO.SmsEnabled == EmailSmsEnabled.Yes) {
                    		SmsDTO smsDTO = new SmsDTO();
                            smsDTO.UserId = configDTO.SmsConfig.UserId;
                            smsDTO.Password = configDTO.SmsConfig.Password;
                            smsDTO.URL = configDTO.SmsConfig.Url;
                            smsDTO.SenderId = configDTO.SmsConfig.SenderId;
                            smsDTO.RecipientList = new List<string>();
                            foreach(VwCustomer vw in customerList) {
                    			if (!string.IsNullOrWhiteSpace(vw.Contact)) smsDTO.RecipientList.Add(vw.Contact);
                    			if (!string.IsNullOrWhiteSpace(vw.AltContact)) smsDTO.RecipientList.Add(vw.AltContact);
                    		}
                            if (smsDTO.RecipientList.Count > 0)
                            {
                        		EmailSMSUtil.SendSMS(smsDTO);
                    		}
                    	}
        			}
        		}
            } catch (Exception e)
            {
                log.Error("Exception while sending email for Function:" + FunctionName.ToString(), e);
            }
        }
        /*public void sendEmailAndSMSForPropertyAlerts_old(long PropertyId, long EntityId, PrAlertFunctionName FunctionName)
        {
            ISession session = null;
        	try
            {
                List<string> EntityTypeList = new List<string>();
                if (PrAlertFunctionName.ENQ_ADD_CUSTOMER == FunctionName) EntityTypeList.Add(Constants.VWCustomerEntityType.ENQUIRY);
                else if (PrAlertFunctionName.LD_ADD_CUSTOMER == FunctionName) EntityTypeList.Add(Constants.VWCustomerEntityType.LEAD);
                else {
                	EntityTypeList.Add(Constants.VWCustomerEntityType.UNIT_OWNER);
                	EntityTypeList.Add(Constants.VWCustomerEntityType.UNIT_CO_OWNER);
                }
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	PropertyAlertConfig alert = null;
                    	Property p = null;
                        PropertyAlertConfig config = session.QueryOver<PropertyAlertConfig>(() => alert)
            					.Inner.JoinAlias(() => alert.Property, () => p)
            					.Where(() => p.Id == PropertyId && alert.FunctionName == FunctionName).SingleOrDefault<PropertyAlertConfig>();
                        
                        if(config != null && (config.EmailEnabled == EmailSmsEnabled.Yes || config.SmsEnabled == EmailSmsEnabled.Yes)) {
                        	//Fetch Owner and Co-Customer details
                        	IList<VwCustomer> customerList = session.QueryOver<VwCustomer>().Where(vw => vw.EntityId == EntityId 
                                && vw.EntityType.IsIn(EntityTypeList)).List<VwCustomer>();

                        	VwCustomer tmpCustomer = null;
                        	if(PrAlertFunctionName.UNIT_BOOKING_CUSTOMER == FunctionName || PrAlertFunctionName.UNIT_CANCELLATION_CUSTOMER == FunctionName){
                                tmpCustomer = customerList.ToList<VwCustomer>().Find(x => x.EntityType == Constants.VWCustomerEntityType.UNIT_OWNER);
                        	} else {
                        		tmpCustomer = customerList[0];
                        	}
                        	
                        	if(config.EmailEnabled == EmailSmsEnabled.Yes) 
                        	{
                        		EmailDTO emailDTO = new EmailDTO();
                        		emailDTO.FromEmail = config.EmailConfig.Email;
                        		emailDTO.Password = config.EmailConfig.Password;
                        		emailDTO.SmtpHost = config.EmailConfig.SmtpHost;
                        		emailDTO.SmtpPort = config.EmailConfig.SmtpPort;
                        		emailDTO.EnableSsl = (config.EmailConfig.EnableSsl == EmailEnableSSL.Yes);
                        		emailDTO.Subject = config.Subject;
                                emailDTO.EmailContent = EmailUtil.ReplacePlaceholders(StringUtil.getBytesAsEmailContentString(config.EmailContent), tmpCustomer);
                        		emailDTO.RecipientList = new List<string>();
                        		foreach(VwCustomer vw in customerList) {
                        			if (!string.IsNullOrWhiteSpace(vw.Email)) emailDTO.RecipientList.Add(vw.Email);
                        			if (!string.IsNullOrWhiteSpace(vw.AltEmail)) emailDTO.RecipientList.Add(vw.AltEmail);
                        		}
                                if (emailDTO.RecipientList.Count > 0)
                                {
                        			emailDTO.Attachments = new List<AttachmentDTO>();
                            		if(config.Attachments != null) {
                            			foreach(PropertyAlertConfigAttachment tmpDTO in config.Attachments) {
                            				emailDTO.Attachments.Add(new AttachmentDTO(tmpDTO.FileName, tmpDTO.Content));
                            			}
                            		}
                            		EmailSMSUtil.SendEmail(emailDTO);
                        		}
                        	}
                        	if(config.SmsEnabled == EmailSmsEnabled.Yes) {
                        		SmsDTO smsDTO = new SmsDTO();
                                smsDTO.UserId = config.SmsConfig.UserId;
                                smsDTO.Password = config.SmsConfig.Password;
                                smsDTO.URL = config.SmsConfig.Url;
                                smsDTO.SenderId = config.SmsConfig.SenderId;
                                smsDTO.RecipientList = new List<string>();
                                foreach(VwCustomer vw in customerList) {
                        			if (!string.IsNullOrWhiteSpace(vw.Contact)) smsDTO.RecipientList.Add(vw.Contact);
                        			if (!string.IsNullOrWhiteSpace(vw.AltContact)) smsDTO.RecipientList.Add(vw.AltContact);
                        		}
                                if (emailDTO.RecipientList.Count > 0)
                                {
                            		EmailSMSUtil.SendSMS(smsDTO);
                        		}
                        	}
                        }
                    } catch (Exception e)
                    {
                        log.Error("Exception while sending email for Function:" + FunctionName.ToString(), e);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }*/
    }
}