﻿using ConstroSoft.Logic.Job;
using Quartz;
using Quartz.Impl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ConstroSoft.Logic.CachingProvider;

namespace ConstroSoft.Logic.Scheduler
{
    public class JobScheduler
    {
        private static readonly log4net.ILog log =
                log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        
        public static void Start()
        {
            try
            {
                JobBO jobBO = new JobBO();
                FirmBO firmBO = new FirmBO();
                JobTrigger jobTrigger = new JobTrigger();
                IScheduler scheduler = StdSchedulerFactory.GetDefaultScheduler();
                scheduler.Start();
                //Fetch all active jobs from Job table for default firm.
                IList<JobDTO> jobList = jobBO.fetchJobs(Constants.SYSDEFAULT.DEFAULT_FIRM);
                if (jobList != null && jobList.Count > 0)
                {
                    foreach (JobDTO jobDTO in jobList)
                    {
                    	//NOTE: There will be single JOB entry for TASK_NOTIFICATION_JOB and EXOTEL_CALL_JOB which will be executed for all Firms.
                        if (jobDTO.JobName.Equals(Constants.JOBS.TASK_NOTIFICATION_JOB))
                        {
                        	if(jobDTO.JobExecutionStatus == JobExecutionStatus.Inprogress)
                        		jobBO.updateJobExecutionStatus(jobDTO.Id, DateUtil.getUserLocalDateTime(), "", JobExecutionStatus.Failed);
                        	//Set memory flags so that when jobs are scheduled, it will be executed irrespective of any new entry.
                        	NotificationCacheProvider.Instance.markNewLeadFlag();
                        	NotificationCacheProvider.Instance.markUnResolvedFlag();
                            IJobDetail notificationJob = JobBuilder.Create<TaskNotificationJob>()
                                .WithIdentity(Constants.JOBS.TASK_NOTIFICATION_JOB, Constants.JOBS.DB_SCHEDULED_JOB_GRP).Build();
                            ITrigger notificationTrigger= null;
                            if(jobDTO.JobIntervalType == JobIntervalType.WithSimpleSchedule){
                                notificationTrigger = jobTrigger.CreateSimpleSchedule(CommonUtil.appendWithSeparator(Constants.JOBS.TASK_NOTIFICATION_JOB, "Trigger", "_"),
                                		Constants.JOBS.DB_SCHEDULED_JOB_GRP);
                            }
                            scheduler.Context.Put(Constants.JOBS.TASK_NOTIFICATION_JOB, jobDTO);
                            scheduler.ScheduleJob(notificationJob, notificationTrigger);
                        }
                        if (jobDTO.JobName.Equals(Constants.JOBS.EXOTEL_CALL_JOB))
                        {
                        	if(jobDTO.JobExecutionStatus == JobExecutionStatus.Inprogress)
                        		jobBO.updateJobExecutionStatus(jobDTO.Id, DateUtil.getUserLocalDateTime(), "", JobExecutionStatus.Failed);
                            IJobDetail exoteljob = JobBuilder.Create<ExotelCallRetrivalJob>()
                                .WithIdentity(Constants.JOBS.EXOTEL_CALL_JOB, Constants.JOBS.DB_SCHEDULED_JOB_GRP).Build();
                            ITrigger exotelTrigger = null;
                            if(jobDTO.JobIntervalType == JobIntervalType.WithSimpleSchedule){
                                exotelTrigger =jobTrigger.CreateSimpleSchedule(CommonUtil.appendWithSeparator(Constants.JOBS.EXOTEL_CALL_JOB	, "Trigger", "_"),
                                		Constants.JOBS.DB_SCHEDULED_JOB_GRP);
                            }
                            scheduler.Context.Put(Constants.JOBS.EXOTEL_CALL_JOB, jobDTO);
                            scheduler.ScheduleJob(exoteljob, exotelTrigger);
                        }
                    }
                }
                //Schedule Email and SMS Campaigns
                MarketingCampaignBO campaignBO = new MarketingCampaignBO();
                IList<EmailSmsCampaignDTO> campaignList = campaignBO.fetchCampaignsToSchedule();
                if(campaignList != null && campaignList.Count > 0) {
                	foreach(EmailSmsCampaignDTO campaign in campaignList) {
                		AddEmailSMSCampaignJob(campaign.Id, campaign.ScheduledDate.Value);
                	}
                }
            }
            catch (Exception exp)
            {
            	log.Error("Unexpected error Registering jobs at startup", exp);
            }
            finally
            {

            }
        }
        public static void AddEmailSMSCampaignJob(long CampaignId, DateTime ScheduledDate)
        {
            try
            {
                IScheduler scheduler = StdSchedulerFactory.GetDefaultScheduler();
                JobTrigger jobTrigger = new JobTrigger();
                IJobDetail job = JobBuilder.Create<EmailSMSCampaignJob>()
                        .WithIdentity(CommonUtil.appendWithSeparator(Constants.JOBS.EMAIL_SMS_CAMPAIGN_JOB, CampaignId+"", "_"), Constants.JOBS.CODE_SCHEDULED_JOB_GRP)
            			.UsingJobData(Constants.JOBS.PARAM_CAMPAIGN_ID, CampaignId)
            			.Build();
            	string triggerName = CommonUtil.appendWithSeparator(Constants.JOBS.EMAIL_SMS_CAMPAIGN_JOB, "Trigger", "_");
            	ITrigger trigger = null;
            	if (ScheduledDate.CompareTo(DateUtil.getUserLocalDateTime()) <= 0) {
                    ScheduledDate = ScheduledDate.AddMinutes(1);
            	}
                trigger = jobTrigger.GetTriggerForTime(triggerName, Constants.JOBS.DB_SCHEDULED_JOB_GRP, ScheduledDate);
                scheduler.ScheduleJob(job, trigger);
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error adding new job for Email Campaign. Campaign Id:" + CampaignId, exp);
            }
        }
        public static void DeleteEmailSMSCampaignJob(long CampaignId)
        {
            try
            {
                IScheduler scheduler = StdSchedulerFactory.GetDefaultScheduler();
            	scheduler.DeleteJob(new JobKey(CommonUtil.appendWithSeparator(Constants.JOBS.EMAIL_SMS_CAMPAIGN_JOB, CampaignId+"", "_"),
                    Constants.JOBS.CODE_SCHEDULED_JOB_GRP));
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error deleting job for Email Campaign. Campaign Id:" + CampaignId, exp);
            }
        }
    }
}