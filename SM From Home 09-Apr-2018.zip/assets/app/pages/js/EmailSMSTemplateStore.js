﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initEmailTemplateGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initEmailTemplateGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#emailSMSTemplateGridBtnDiv",
        pageLength: 10,
        sorting: false
    };

    $("[id$='emailSMSTemplateSearchGrid']").CSBasicDatatable(dtOptions);
}