// Donut chart
// ------------------------------

// Initialize chart
google.load("visualization", "1", {packages:["corechart"]});
google.setOnLoadCallback(drawDonut);


// Chart settings
function drawDonut() {

    // Data
    var inputVal = $("[id$='UnitAvailableTypeWiseDataHdn']").val();
	var dataset = $.parseJSON(inputVal);
    // Data
    var data = new google.visualization.DataTable();
    data.addColumn('string', 'Unit Type');
    data.addColumn('number', 'Available Count');
    dataset.forEach(function (d) {
        data.addRow([d.UnitType, d.Count]);
    });

    // Options
    var options_donut = {
        fontName: 'Roboto',
        pieHole: 0.55,
        height: 300,
        width: 470,
        chartArea: {
            left: 50,
            width: '90%',
            height: '90%'
        }
    };
    

    // Instantiate and draw our chart, passing in some options.
    var donut = new google.visualization.PieChart($('#UnitStatsDonutChart')[0]);
    donut.draw(data, options_donut);
}