﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initAccountSummaryGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initAccountSummaryGrid() {
    var dtOptions = {
        customBtnGrpId: "#accountStatementBtnDiv",
        pageLength: 10,        
        hasActionColumn: false,
        hideSearch: false,
        sorting: false
    };
    $("[id$='acntSummaryGrid']").CSBasicDatatable(dtOptions);
}





