﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
	initTemplateGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}
function initTemplateGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        rowInfoModalTitle: "Template Details",
        customBtnGrpId: "#templateSearchBtnDiv",
        sorting: false,
        pageLength: 5,
        hideSearch: true
    };

    $("[id$='TemplateGrid']").CSBasicDatatable(dtOptions);
}