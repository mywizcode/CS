﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initMyLeadsSearchGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initMyLeadsSearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#leadSearchBtnDiv",
        pageLength: 10
    };

    $("[id$='myLeadsSearchGrid']").CSBasicDatatable(dtOptions);
}




