﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;


public partial class Login : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            (this.Master as CSLoginMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(ApplicationUtil.getLoginMsg(Request.Params["p1"])));
            Session.Remove(Constants.Session.USERNAME);
        }
        (this.Master as CSLoginMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        initBootstrapComponantsFromServer();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private void initDropdowns()
    {
    }
    private void doInit()
    {

    }
    protected void login(object sender, EventArgs e)
    {
        LoginBO loginBO = new LoginBO();
        NotificationBO notificationBO = new NotificationBO();
        try
        {
            if (validateloginFields())
            {
                BusinessOutputTO outputTO = loginBO.validateUser(txtUserName.Text, txtPassword.Text);
                if (BusinessOutputTO.Status.SUCCESS.Equals(outputTO.status))
                {
                    UserDefinitionDTO userDef = (UserDefinitionDTO)outputTO.result;
                    userDef.AssignedProperties = new List<PropertyDTO>();
                    userDef.AssignedProperties.AddRange(loginBO.getAssignedProperties(userDef.FirmMember.Id));
                    Session[Constants.Session.USERNAME] = userDef.Username;
                    Session[Constants.Session.USERDEFINITION] = userDef;
                    System.Collections.Generic.List<string> d = Application["LOGGED_IN_USERS"] as System.Collections.Generic.List<string>;
                    if (d != null)
                    {
                        lock (d)
                        {
                            if (d.Contains(txtUserName.Text))
                            {
                                Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotyErrorMsg(Resources.Messages.ERROR_LOGIN_MULTIPLE_ACTIVE_SESSION));
                            }
                            else
                            {
                                d.Add(txtUserName.Text);
                            }
                        }
                    }
                    if (userDef.Status == UserStatus.Active)
                    {
                        PropertyDTO selectedProperty = userDef.AssignedProperties.Find(c => c.isUISelected);
                        if (selectedProperty != null)
                        {
                            notificationBO.fetchAndCacheUserNotifications(userDef, selectedProperty.Id);
                        }
                        Response.Redirect(getLandingPageOnLoginSuccess(userDef), false);
                    }
                    else
                    {
                        ResetPasswordNavDTO navDTO = new ResetPasswordNavDTO();
                        navDTO.Step = ResetPasswordStep.USER_LOGIN_SETUP;
                        Session[Constants.Session.NAV_DTO] = navDTO;
                        Response.Redirect(Constants.URL.LOGIN_SETUP, true);
                    }
                }
                else
                {
                    (this.Master as CSLoginMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(outputTO.errorMessage));
                }
                txtUserName.Text = "";
                txtPassword.Text = "";
            }
        }
        catch (Exception ex)
        {
            log.Error("Unexpected error:", ex);
            (this.Master as CSLoginMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(CommonUtil.getErrorMessage(ex)));
        }
    }
    private string getLandingPageOnLoginSuccess(UserDefinitionDTO userDef)
    {
        string page = Constants.URL.DEFAULT_HOME_PAGE;
        if (CommonUtil.hasEntitlement(userDef, Constants.Entitlement.MENU_FN_CRM)) page = Constants.URL.CRM_DASHBOARD;
        else if (CommonUtil.hasEntitlement(userDef, Constants.Entitlement.MENU_FN_ACCOUNT_FINANCE)) page = Constants.URL.ACNTFINANCE_DASHBOARD;
        else if (CommonUtil.hasEntitlement(userDef, Constants.Entitlement.MENU_FIRM_PROPERTY_SETUP)) page = Constants.URL.FIRM_PROPERTY_SETUP_DASHBOARD;
        else if (CommonUtil.hasEntitlement(userDef, Constants.Entitlement.MENU_ADMINISTRATION)) page = Constants.URL.ADMINITRATION_DASHBOARD;
        return page;
    }
    private bool validateloginFields()
    {
        if (string.IsNullOrWhiteSpace(txtUserName.Text))
        {
            (this.Master as CSLoginMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please enter Username."));
            return false;
        }
        else if (string.IsNullOrWhiteSpace(txtPassword.Text))
        {
            (this.Master as CSLoginMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please enter Password."));
            return false;
        }
        return true;
    }
    protected void showForgotPasswordPage(object sender, EventArgs e)
    {
        try
        {
            LoginBO loginBO = new LoginBO();
            if (string.IsNullOrWhiteSpace(txtUserName.Text))
            {
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please enter User Name."));
            }
            else
            {
                BusinessOutputTO outputTO = loginBO.getUserDefinition(txtUserName.Text);
                if (outputTO.status == BusinessOutputTO.Status.SUCCESS)
                {
                    UserDefinitionDTO userDef = (UserDefinitionDTO)outputTO.result;
                    Session[Constants.Session.USERNAME] = userDef.Username;
                    Session[Constants.Session.USERDEFINITION] = userDef;

                    ResetPasswordNavDTO navDTO = new ResetPasswordNavDTO();
                    navDTO.Step = ResetPasswordStep.SECURITY_VALIDATION;
                    Session[Constants.Session.NAV_DTO] = navDTO;
                    Response.Redirect(Constants.URL.FP_SECURITY_VALIDATION, false);
                }
                else
                {
                    (this.Master as CSLoginMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(outputTO.errorMessage));
                }
            }
        }
        catch (Exception ex)
        {
            log.Error("Unexpected error:", ex);
            (this.Master as CSLoginMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(CommonUtil.getErrorMessage(ex)));
        }
    }
}