﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq.Expressions;
using NHibernate.Impl;
using System.Linq;

/// <summary>
/// Summary description for MasterDataBO
/// </summary>
namespace ConstroSoft
{
    public class MasterDataBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public MasterDataBO() { }
        public void saveMasterData(MasterControlDataDTO masterDataDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        MasterControlData masterData = DTOToDomainUtil.populateMasterDataAddFields(masterDataDto);
                        session.Save(masterData);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving MasterData details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void updateMasterData(MasterControlDataDTO masterDataDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        MasterControlData masterData = session.Get<MasterControlData>(masterDataDto.Id);
                        DTOToDomainUtil.populateMasterDataUpdateFields(masterData, masterDataDto);
                        session.Update(masterData);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating MasterData details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void deleteMasterData(long Id)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        MasterControlData masterData = session.Get<MasterControlData>(Id);
                        session.Delete(masterData);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while deleting MasterData details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public bool isAlreadyExist(MasterControlDataDTO masterDataDto)
        {
            ISession session = null;
            bool isExist = false;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        MasterControlData masterData = session.QueryOver<MasterControlData>()
                                .Where(x => x.FirmNumber == masterDataDto.FirmNumber && x.Type == masterDataDto.Type)
                                .WhereRestrictionOn(x => x.Name).IsInsensitiveLike(masterDataDto.Name).SingleOrDefault<MasterControlData>();
                        if (masterData != null) isExist = true;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while validating duplicate MasterData:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return isExist;
        }

        public MasterControlDataDTO getMasterDataType(string firmNumber, string mcdType, string name)
        {
            ISession session = null;
            MasterControlDataDTO result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        MasterControlData masterData = session.QueryOver<MasterControlData>()
                                .Where(x => x.FirmNumber == firmNumber && x.Type == mcdType && x.Name.IsInsensitiveLike(name))
                                .SingleOrDefault<MasterControlData>();
                        if (masterData != null) result = DomainToDTOUtil.convertToMasterControlDTO(masterData, false);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching MasterData:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public MasterControlDataDTO getAnyAddressType(string firmNumber)
        {
            ISession session = null;
            MasterControlDataDTO result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        IList<MasterControlData> masterDataList = session.QueryOver<MasterControlData>()
                                .Where(x => x.FirmNumber == firmNumber && x.Type == MasterDataType.ADDRESS_TYPE.ToString())
                                .List<MasterControlData>();
                        if (masterDataList != null && masterDataList.Count > 0) result = DomainToDTOUtil.convertToMasterControlDTO(masterDataList[0], false);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching address type MasterData:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public void saveOrUpdateMasterData(string firmNumber, string masterDataType, IList<MasterControlDataDTO> masterDataDtoList)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        MasterControlData mcd = null;
                        PropertyTower p = null;
                        IList<MasterControlData> masterControlDataList = session.QueryOver<MasterControlData>(() => mcd).Where(() => mcd.FirmNumber == firmNumber && mcd.Type == masterDataType).List<MasterControlData>();
                        if (masterDataDtoList != null)
                        {
                            if (masterControlDataList != null && masterControlDataList.Count > 0)
                            {
                                for (int i = 0; i < masterControlDataList.Count; i++)
                                {
                                    MasterControlData masterControlData = masterControlDataList.ElementAt(i);
                                    MasterControlDataDTO masterControlDataDto = masterDataDtoList.FirstOrDefault(x => x.Id == masterControlData.Id);
                                    if (masterControlDataDto == null)
                                    {
                                        session.Delete(masterControlData);
                                    }
                                    else
                                    {
                                        DTOToDomainUtil.populateMasterDataUpdateFields(masterControlData, masterControlDataDto);
                                        session.Update(masterControlData);
                                    }
                                }
                            }
                            foreach (MasterControlDataDTO masterControlDataDto in masterDataDtoList)
                            {
                                if (masterControlDataDto.Id < 1)
                                {
                                    MasterControlData masterControlData = DTOToDomainUtil.populateMasterDataAddFields(masterControlDataDto);
                                    session.Save(masterControlData);
                                }
                            }
                        }
                        else if (masterControlDataList.Count > 0)
                        {
                            foreach (MasterControlData masterControlData in masterControlDataList)
                            {
                                session.Delete(masterControlData);
                            }
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Master Control details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public List<MasterControlDataDTO> fetchMasterData(string firmNumber, string masterDataType)
        {
            ISession session = null;
            List<MasterControlDataDTO> masterControlDataList = new List<MasterControlDataDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        MasterControlData mcd = null;
                        PropertyTower p = null;
                        IList<MasterControlData> result = session.QueryOver<MasterControlData>(() => mcd).Where(() => mcd.FirmNumber == firmNumber && mcd.Type == masterDataType).List<MasterControlData>();
                        foreach (MasterControlData masterData in result)
                        {
                            masterControlDataList.Add(DomainToDTOUtil.convertToMasterControlDTO(masterData, true));
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching available property units :", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return masterControlDataList;
        }
        public MasterControlDataDTO fetchMasterData(string firmNumber, string masterDataType, string name)
        {
            ISession session = null;
            MasterControlDataDTO mcdDTO = new MasterControlDataDTO();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        MasterControlData mcd = null;
                        MasterControlData result = session.QueryOver<MasterControlData>(() => mcd).Where(() => mcd.FirmNumber == firmNumber 
                            && mcd.Type == masterDataType && mcd.Name == name).SingleOrDefault<MasterControlData>();
                        mcdDTO = DomainToDTOUtil.convertToMasterControlDTO(result, true);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching master data record :", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return mcdDTO;
        }
    }
}