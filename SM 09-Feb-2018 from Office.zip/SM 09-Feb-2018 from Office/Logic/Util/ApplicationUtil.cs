﻿using System.Web;
using System.Web.UI;
/// <summary>
/// Summary description for EmailUtil
/// </summary>

namespace ConstroSoft
{
    public static class ApplicationUtil
    {
        //Logger Instance
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        /**
         * This method checks whether Current request async call.
         */
        public static bool isAsyncPostBack(Page page)
        {
            return ScriptManager.GetCurrent(page).IsInAsyncPostBack;
        }
        /**
         * This method checks whether Current request is Post call or async call for inner page. If yes then returns true.
         */
        public static bool isSubPageRendered(Page page)
        {
            bool isAsyncCall = ScriptManager.GetCurrent(page).IsInAsyncPostBack;
            string updatePnlId = ScriptManager.GetCurrent(page).AsyncPostBackSourceElementID;
            return (!isAsyncCall || (isAsyncCall && updatePnlId.Contains("$ContentPlaceHolder1")));
        }
        /**
         * This method returns control element identifier on which bootstrap CSS will be applied. This method is called at end of the AJAX request. So when page is rendered
         * all controls inside it will be converted to bootstrap elements.
         **/
        public static string getParentToApplyCSS(Page page)
        {
            string parent = "body";
            bool isAsyncCall = ScriptManager.GetCurrent(page).IsInAsyncPostBack;
            string updatePnlId = ScriptManager.GetCurrent(page).AsyncPostBackSourceElementID;
            if (isAsyncCall)
            {
                if (updatePnlId.Contains("$ContentPlaceHolder1")) parent = "div.content-wrapper";
                else if (updatePnlId.Contains("$notificationAlertGrid") || updatePnlId.Contains("$RefreshNotificationTimer")
                		|| updatePnlId.Contains("$notificationTaskGrid")) parent = "ul.ulNotification";
            }
            return parent;
        }
        public static string getSessionNotyMsg(System.Web.SessionState.HttpSessionState Session)
        {
            string msg = "";
            if(Session[Constants.Session.NOTY_MSG] != null && (Session[Constants.Session.NOTY_MSG]).ToString().Trim() != "") {
                msg = (Session[Constants.Session.NOTY_MSG]).ToString();
                Session.Remove(Constants.Session.NOTY_MSG);
            }
            return msg;
        }
        public static bool isSessionActive(System.Web.SessionState.HttpSessionState Session)
        {
            return (Session[Constants.Session.USERNAME] != null && (Session[Constants.Session.USERNAME]).ToString().Trim() != "") ? true : false;
        }
        public static void clearSession(System.Web.SessionState.HttpSessionState Session, HttpApplicationState Application)
        {
            string userLoggedIn = Session["USERNAME"] == null ? string.Empty : (string)Session["USERNAME"];
            if (userLoggedIn.Length > 0)
            {
                System.Collections.Generic.List<string> d = Application["LOGGED_IN_USERS"] as System.Collections.Generic.List<string>;
                if (d != null)
                {
                    lock (d)
                    {
                        if (d.Contains(userLoggedIn))
                        {
                            d.Remove(userLoggedIn);
                        }
                    }
                }
            }
            HttpContext.Current.Session.Clear();
            HttpContext.Current.Session.Abandon();
            HttpContext.Current.Response.Cookies.Add(new System.Web.HttpCookie("ASP.NET_SessionId", ""));
        }
        public static string getLoginMsg(string param)
        {
            string msg = "";
            if (!string.IsNullOrWhiteSpace(param))
            {
                if ("cpsuccess".Equals(param)) msg = "Password is changed successfully. Please login with your new password.";
                else if ("ussuccess".Equals(param)) msg = "User setup is completed successfully. Please login with your new password.";
                else if ("rpsuccess".Equals(param)) msg = "Password is reset successfully. Please login with your new password.";
            }
            return msg;
        }
        public static T getPageNavDTO<T>(System.Web.SessionState.HttpSessionState Session)
        {
            object navObj = Session[Constants.Session.NAV_DTO];
            Session.Remove(Constants.Session.NAV_DTO);
            Session.Remove(Constants.Session.PAGE_DATA);
            if (navObj is T) return (T)navObj;
            else return default(T);
        }
    }
}