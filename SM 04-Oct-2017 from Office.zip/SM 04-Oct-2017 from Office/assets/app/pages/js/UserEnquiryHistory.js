﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initUserEnquiryHistorySearchGrid();
    formatFields();
    showModal();
}

function initUserEnquiryHistorySearchGrid() {
    var dtOptions = {
        tableId: "userEnquiryHistorySearchGrid",
        pageLength: 10,
        isViewOnly: false,
        hideSearch: true
    };
    var dtTable = applyActionDataTable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitHdnId");
}




