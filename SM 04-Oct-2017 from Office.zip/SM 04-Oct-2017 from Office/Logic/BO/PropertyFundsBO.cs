﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NHibernate;
using NHibernate.Criterion;

namespace ConstroSoft.Logic.BO
{
    public class PropertyFundsBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public PropertyFundsBO() { }

        public List<PropertyFundsDTO> fetchAccountDepositGridData(string firmNumber, long propertyId)
        {
            ISession session = null;
            List<PropertyFundsDTO> firmAccountDepositList = new List<PropertyFundsDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyFunds facntdeposit = null;
                        FirmAccount acnt = null;
                        Property pr = null;
                        IList<PropertyFunds> result = session.QueryOver<PropertyFunds>(() => facntdeposit).JoinAlias(() => facntdeposit.FirmAccount, () => acnt).JoinAlias(() => facntdeposit.Property, () => pr)
                            .Where(() => facntdeposit.FirmNumber == firmNumber && pr.Id == propertyId).List<PropertyFunds>();
                        foreach (PropertyFunds firmAcntDeposite in result)
                        {
                            firmAccountDepositList.Add(DomainToDTOUtil.convertToPropertyFundDTO(firmAcntDeposite, true));
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching firm account deposit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return firmAccountDepositList;
        }

        public PropertyFundsDTO fetchDeposit(long Id)
        {
            ISession session = null;
            PropertyFundsDTO accountDepositDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyFunds FirmAcntDepositDO = session.Get<PropertyFunds>(Id);
                        accountDepositDto = DomainToDTOUtil.convertToPropertyFundDTO(FirmAcntDepositDO, true);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Account Deposit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return accountDepositDto;
        }

        public void deleteDeposit(PropertyFundsDTO depositDto, AccountTransactionDTO acntTransDto)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyFunds acctDeposit = DTOToDomainUtil.populatePropertyFundsAddFields(depositDto);
                        acctDeposit.AccountTransaction = DTOToDomainUtil.populateAccountTransactionAddFields(acntTransDto);
                        session.Save(acctDeposit);
                        Id = acctDeposit.Id;
                        FirmAccount firmAccount = session.Get<FirmAccount>(depositDto.FirmAccount.Id);
                        decimal tmpvalue;
                        decimal result = 0.0M;
                        if (decimal.TryParse(depositDto.Amount.ToString(), out tmpvalue))
                            result = tmpvalue;
                        firmAccount.AccountBalance = Decimal.Subtract(firmAccount.AccountBalance, result);
                        session.Save(firmAccount);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Account Deposit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }

        public long saveDeposit(PropertyFundsDTO depositDto, AccountTransactionDTO acntTransDto)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyFunds acctDeposit = DTOToDomainUtil.populatePropertyFundsAddFields(depositDto);
                        acctDeposit.AccountTransaction = DTOToDomainUtil.populateAccountTransactionAddFields(acntTransDto);
                        session.Save(acctDeposit);
                        Id = acctDeposit.Id;
                        FirmAccount firmAccount = session.Get<FirmAccount>(depositDto.FirmAccount.Id);
                        decimal tmpvalue;
                        decimal result = 0.0M;
                        if (decimal.TryParse(depositDto.Amount.ToString(), out tmpvalue))
                            result = tmpvalue;
                        firmAccount.AccountBalance = Decimal.Add(firmAccount.AccountBalance, result);
                        session.Save(firmAccount);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Account Deposit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }

    }

}