﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using Vladsm.Web.UI.WebControls;

public partial class PropertyUserAccess : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    DropdownBO drpBO = new DropdownBO();
    PropertyUserBO propertyUserBO = new PropertyUserBO();
    PropertyBO propertyBO = new PropertyBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSubPageRendered(Page)) clearMessages();
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                PropertyUserAccessNavDTO navDto = CommonUtil.getPageNavDTO<PropertyUserAccessNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.PROPERTY_USER_ACCESS)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
        addCheckBoxAttributes();
    }
    private void renderPageFieldsWithEntitlement()
    {

    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
    }
    private void addCheckBoxAttributes()
    {
        foreach (ListViewItem item in UnassignedUserGrid.Items)
        {
            CheckBox chBox = (CheckBox)item.FindControl("cbUnassignedUser");
            if (chBox != null)
            {
                chBox.InputAttributes.Add("class", "styled cs-select-row");
                chBox.InputAttributes.Add("data-parent", "media-link");
            }
        }
        foreach (ListViewItem item in assignedUserGrid.Items)
        {
            CheckBox chBox = (CheckBox)item.FindControl("cbAssignedUser");
            if (chBox != null)
            {
                chBox.InputAttributes.Add("class", "styled cs-select-row");
                chBox.InputAttributes.Add("data-parent", "media-link");
            }
        }
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(PropertyUserAccessNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void navigateToPreviousPage()
    {
        PropertyUserAccessPageDTO PageDTO = getSessionPageData();
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is PropertySearchNavDTO)
            {
                PropertySearchNavDTO navDTO = (PropertySearchNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.PROPERTY_SEARCH, true);
            }
        }
        Response.Redirect(Constants.URL.PROPERTY_SEARCH, true);
    }
    private PropertyUserAccessPageDTO getSessionPageData()
    {
        return (PropertyUserAccessPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private void initPageAfterRedirect(PropertyUserAccessNavDTO navDto)
    {
        try
        {
            PropertyUserAccessPageDTO PageDTO = new PropertyUserAccessPageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            fetchPropertyAndUsers(navDto.PropertyId);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void fetchPropertyAndUsers(long propertyId)
    {
        PropertyUserAccessPageDTO PageDTO = getSessionPageData();
        PropertyDTO propertyDTO = propertyBO.fetchPropertySelective(propertyId);
        PageDTO.Property = propertyDTO;
        lbPropertyName.Text = propertyDTO.Name;
        lbPropertyType.Text = propertyDTO.PropertyType.Name;
        lbPropertyLocation.Text = propertyDTO.PropertyLocation.Name;
        lbReraRegNo.Text = propertyDTO.ReraRegNo;

        populateUserGrid();
    }
    private void populateUserGrid()
    {
        PropertyUserAccessPageDTO PageDTO = getSessionPageData();
        IList<FirmMemberDTO> result = propertyUserBO.fetchPropertyAccessUsers(getUserDefinitionDTO().FirmNumber, PageDTO.Property.Id);
        PageDTO.UnassignedUserList = new List<FirmMemberDTO>();
        PageDTO.AssignedUserList = new List<FirmMemberDTO>();
        PageDTO.UIUnassignedUserList = new List<FirmMemberDTO>();
        PageDTO.UIAssignedUserList = new List<FirmMemberDTO>();
        foreach (FirmMemberDTO tmpDTO in result)
        {
        	if(tmpDTO.hasPropertyAccess == PrFMAccess.Yes) PageDTO.AssignedUserList.Add(tmpDTO);
        	else PageDTO.UnassignedUserList.Add(tmpDTO);
        }
        applySearchCriteriaOnUnassignedUsers();
        applySearchCriteriaOnAssignedUsers();
    }
    private void applySearchCriteriaOnUnassignedUsers()
    {
        PropertyUserAccessPageDTO PageDTO = getSessionPageData();
        PageDTO.UIUnassignedUserList.Clear();
        string unassignedUserText = txtUnassignedUserSearch.Text.Trim();
        if (!string.IsNullOrWhiteSpace(unassignedUserText))
        {
            PageDTO.UIUnassignedUserList.AddRange(PageDTO.UnassignedUserList.FindAll(x => x.FullName.ToUpper().Contains(unassignedUserText.ToUpper())));
        }
        else
        {
            PageDTO.UIUnassignedUserList.AddRange(PageDTO.UnassignedUserList);
        }
        UnassignedUserGrid.DataSource = PageDTO.UIUnassignedUserList;
        UnassignedUserGrid.DataBind();
    }
    private void applySearchCriteriaOnAssignedUsers()
    {
        PropertyUserAccessPageDTO PageDTO = getSessionPageData();
        PageDTO.UIAssignedUserList.Clear();
        string assignedUserText = txtAssignedUserSearch.Text.Trim();
        PageDTO.UIAssignedUserList.Clear();
        if (!string.IsNullOrWhiteSpace(assignedUserText))
        {
            PageDTO.UIAssignedUserList.AddRange(PageDTO.AssignedUserList.FindAll(x => x.FullName.ToUpper().Contains(assignedUserText.ToUpper())));
        }
        else
        {
            PageDTO.UIAssignedUserList.AddRange(PageDTO.AssignedUserList);
        }
        assignedUserGrid.DataSource = PageDTO.UIAssignedUserList;
        assignedUserGrid.DataBind();
    }
    protected void searchUserInUnassignedList(object sender, EventArgs e)
    {
        try
        {
            PropertyUserAccessPageDTO PageDTO = getSessionPageData();
            applySearchCriteriaOnUnassignedUsers();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void moveAllUsersToAssignedList(object sender, EventArgs e) {
    	try
        {
    		PropertyUserAccessPageDTO PageDTO = getSessionPageData();
            if (PageDTO.UIUnassignedUserList.Count > 0)
            {
                propertyUserBO.updatePropertyAccess(PageDTO.Property.Id, PageDTO.UIUnassignedUserList, PrFMAccess.Yes);
                populateUserGrid();
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("All users are assigned to property."));
            }
            else
            {
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("No user is available for assignment."));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void moveSelectedUsersToAssignedList(object sender, EventArgs e) {
    	try
        {
    		PropertyUserAccessPageDTO PageDTO = getSessionPageData();
            List<FirmMemberDTO> selectedUsers = new List<FirmMemberDTO>();
            foreach (ListViewItem item in UnassignedUserGrid.Items)
            {
                CheckBox chBox = (CheckBox)item.FindControl("cbUnassignedUser");
                if (chBox.Checked)
                {
                    HiddenField hdnField = (HiddenField)item.FindControl("UnassignedUserIdHdn");
                    long selectedId = long.Parse(hdnField.Value);
                    FirmMemberDTO tmpDTO = PageDTO.UIUnassignedUserList.Find(x => x.Id == selectedId);
                    if (tmpDTO != null) selectedUsers.Add(tmpDTO);
                }
            }
            if (selectedUsers.Count > 0)
            {
                propertyUserBO.updatePropertyAccess(PageDTO.Property.Id, selectedUsers, PrFMAccess.Yes);
                populateUserGrid();
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("Selected users are assigned to property."));
            }
            else
            {
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please select user."));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void searchUserInAssignedList(object sender, EventArgs e)
    {
        try
        {
            PropertyUserAccessPageDTO PageDTO = getSessionPageData();
            applySearchCriteriaOnAssignedUsers();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void moveAllUsersToUnAssignedList(object sender, EventArgs e) {
    	try
        {
    		PropertyUserAccessPageDTO PageDTO = getSessionPageData();
            if (PageDTO.UIAssignedUserList.Count > 0)
            {
                propertyUserBO.updatePropertyAccess(PageDTO.Property.Id, PageDTO.UIAssignedUserList, PrFMAccess.No);
                populateUserGrid();
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("All users are removed from assigned list."));
            }
            else
            {
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("No user has access to property."));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void moveSelectedUsersToUnAssignedList(object sender, EventArgs e) {
    	try
        {
    		PropertyUserAccessPageDTO PageDTO = getSessionPageData();
    		List<FirmMemberDTO> selectedUsers = new List<FirmMemberDTO>();
        	foreach (ListViewItem item in assignedUserGrid.Items)
            {
                CheckBox chBox = (CheckBox)item.FindControl("cbAssignedUser");
                if (chBox.Checked)
                {
                	HiddenField hdnField = (HiddenField)item.FindControl("AssignedUserIdHdn");
                	long selectedId = long.Parse(hdnField.Value);
                	FirmMemberDTO tmpDTO = PageDTO.UIAssignedUserList.Find(x => x.Id == selectedId);
                    if (tmpDTO != null) selectedUsers.Add(tmpDTO);
                }
            }
        	if(selectedUsers.Count > 0) {
                propertyUserBO.updatePropertyAccess(PageDTO.Property.Id, selectedUsers, PrFMAccess.No);
            	populateUserGrid();
            	(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("Selected users are removed from assigned list."));
        	} else {
    			(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please select user."));
    		}
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
}