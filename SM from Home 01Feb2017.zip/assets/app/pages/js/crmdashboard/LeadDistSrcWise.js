﻿$(function () {

    // Set paths
    // ------------------------------

    require.config({
        paths: {
            echarts: '../assets/limitless/js/plugins/visualization/echarts'
        }
    });


    // Configuration
    // ------------------------------

    require(
        [
            'echarts',
            'echarts/theme/limitless',
            'echarts/chart/pie',
        ],


        // Charts setup
        function (ec, limitless) {
            var inputVal = $("[id$='LeadDistSrcWiseDataHdn']").val();
            var dataArray = $.parseJSON(inputVal);
            if (Object.keys(dataArray).length > 0) {
                var pieSeries = [];
                var pieData = [];
                $.each(dataArray, function (index, obj) {
                    pieSeries.push({
                        value: obj.Count,
                        name: obj.SourceName
                    });
                    pieData.push(obj.SourceName);
                });

                // Initialize charts
                // ------------------------------

                var basic_donut = ec.init(document.getElementById('leadDistChart'), limitless);


                // Charts setup
                // ------------------------------                    

                //
                // Basic donut options
                //

                basic_donut_options = {

                    // Add legend
                    legend: {
                        orient: 'vertical',
                        x: 'left',
                        data: pieData
                    },

                    // Add series
                    series: [
                        {
                            name: 'Leads',
                            type: 'pie',
                            radius: ['50%', '70%'],
                            center: ['60%', '50%'],
                            itemStyle: {
                                normal: {
                                    label: {
                                        show: true
                                    },
                                    labelLine: {
                                        show: true
                                    }
                                },
                                emphasis: {
                                    label: {
                                        show: true,
                                        formatter: '{b}' + '\n\n' + '{c} ({d}%)',
                                        position: 'center',
                                        textStyle: {
                                            fontSize: '17',
                                            fontWeight: '500'
                                        }
                                    }
                                }
                            },

                            data: pieSeries
                        }
                    ]
                };


                // Apply options
                // ------------------------------

                basic_donut.setOption(basic_donut_options);


                // Resize charts
                // ------------------------------

                window.onresize = function () {
                    setTimeout(function () {
                        basic_donut.resize();
                    }, 200);
                }
            }
        }
    );
});




