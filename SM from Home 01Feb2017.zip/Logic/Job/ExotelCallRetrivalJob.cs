﻿using ConstroSoft.Logic.CachingProvider;
using ConstroSoft.TelephonyProvider.ExotelProvider;
using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Caching;

namespace ConstroSoft.Logic.Job
{
    public class ExotelCallRetrivalJob : IJob
    {
        private static readonly log4net.ILog log =
                log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        
        public void Execute(IJobExecutionContext context)
        {
        	JobBO jobBO = new JobBO();
            CallHistoryBO callHistoryBO = new CallHistoryBO();
            ExotelClient exotelClient = new ExotelClient();
            
            string message = "Job execution is completed successfully.";
            var schedulerContext = context.Scheduler.Context;
            JobDTO tmpJobDTO = (JobDTO)schedulerContext.Get(Constants.JOBS.EXOTEL_CALL_JOB);
            InOutBoundCallResDTO outBoundCallResDTO = null;
            DateTime StartTime = DateTime.Now;
            bool isError = false;
            bool isJobStarted = false;
            try{
                JobDTO jobDTO = jobBO.fetchJobDetails(tmpJobDTO.Id);
                if (jobDTO.JobExecutionStatus != JobExecutionStatus.Inprogress && jobDTO.JobStatus == JobStatus.Active)
                {
                    jobBO.updateJobExecutionStatus(jobDTO.Id, StartTime, "", JobExecutionStatus.Inprogress);
                    isJobStarted = true;
            		//Fetch all the incoming calls for which Direction is INBOUND and Call Status is INPROGRESS.
                    IList<CallHistoryDTO> calls = callHistoryBO.fetchCallsNotInSync(jobDTO.FirmNumber);
                    //Iterate over each call & invoke ExotelClient.getCallDetails
                    //If Call Status is COMPLETED, FAILED, BUSY then update call history.
                    if (calls != null && calls.Count > 0)
                    {
                        foreach (CallHistoryDTO callHistDTO in calls)
                        {
                            outBoundCallResDTO = exotelClient.getCallDetails(callHistDTO.CallSid);
                            CallStatus callStatus = CommonUtil.getCallStatus(outBoundCallResDTO.Call.Status);
                            //Queued, Inprogress, Completed, Failed, Busy, Noanswer, Free
                            if (callStatus == CallStatus.Completed || callStatus == CallStatus.Failed || callStatus == CallStatus.Noanswer)
                            {
                                bool incoming = (callHistDTO.Direction == CallDirection.Incoming);
                                DTOToDomainUtil.populateCallHistoryDTOFromExotelCall(outBoundCallResDTO.Call, callHistDTO, incoming);
                                if (callStatus == CallStatus.Completed) callHistDTO.RecordingFile = CommonUtil.downloadRecordingFile(callHistDTO.RecordingUrl);
                                if (isCallToBeMarkedSync(callHistDTO)) 
                                    callHistoryBO.updateCallHistoryDuringSync(callHistDTO);
                            }
                        }
                    }
            	}
               
            }catch (Exception exp)
            {
            	isError = true;
                message = exp.Message;
                string sid = (outBoundCallResDTO != null) ? outBoundCallResDTO.Call.Sid : "";
                log.Error("Exception in exotel call retrival job. SID:"+sid);
                log.Error(exp.Message, exp);                
                
                //TODO - send email to administrator about job is failed.
            } finally {
	            try{
	            	JobExecutionStatus status = (isError) ? JobExecutionStatus.Failed : JobExecutionStatus.Completed;
	            	if(isError) {
	            		JobHistoryDTO jobHistoryDTO = CommonUtil.populateJobHistoryAddDTO(tmpJobDTO, message);
	            		jobBO.saveJobHistory(jobHistoryDTO);
	            	}
	            	if(isJobStarted) {
	            		jobBO.updateJobExecutionStatus(tmpJobDTO.Id, StartTime, message, status);
	            	}
	            } catch (Exception exp)
	            {
	            	log.Error("Exotel Call Job - Exception while updating job execution status", exp);
	            }
            }
        }
        private bool isCallToBeMarkedSync(CallHistoryDTO callDTO)
        {
            return (callDTO.CallStatus != CallStatus.Completed) ||
                callDTO.RecordingFile != null || (callDTO.EndTime != null && (callDTO.EndTime.Value - DateTime.Now).TotalHours > 2);
        }
    }
}