﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;


/// <summary>
/// Summary description for CallHistoryBO
/// </summary>
namespace ConstroSoft
{
    public class CallHistoryBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public CallHistoryBO() { }
        public List<UnresolvedCallGroupInfoDTO> fetchUnresolvedCallsGridData(UserDefinitionDTO userDefDTO, UnresolvedCallsFilterDTO filterDTO)
        {
            ISession session = null;
            List<UnresolvedCallGroupInfoDTO> results = new List<UnresolvedCallGroupInfoDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	CallHistory ch = null;
                        FirmMember fm = null;
                        
                        CallHistoryDTO chDto = null;
                        IList<CallHistoryDTO> tmpResult = null;
                        var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => ch.Id).WithAlias(() => chDto.Id))
                                .Add(Projections.Property(() => ch.Direction).WithAlias(() => chDto.Direction))
                                .Add(Projections.Property(() => ch.CallerNumber).WithAlias(() => chDto.CallerNumber))
                                .Add(Projections.Property(() => ch.CalleeNumber).WithAlias(() => chDto.CalleeNumber))
                                .Add(Projections.Property(() => ch.CallStatus).WithAlias(() => chDto.CallStatus))
                                .Add(Projections.Property(() => ch.CallHistoryStatus).WithAlias(() => chDto.CallHistoryStatus))
                                .Add(Projections.Property(() => ch.StartTime).WithAlias(() => chDto.StartTime));
        	            var query = session.QueryOver<CallHistory>(() => ch)
        	                .Inner.JoinAlias(() => ch.FirmMember, () => fm);
                        
        	            ICriteria criteria = query.RootCriteria;
        	            if(filterDTO == null || !filterDTO.IsAllUnresolvedCalls) {
        	            	criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<FirmMember>(() => fm, x => x.Id), userDefDTO.FirmMember.Id));
        	            }
        	            if (filterDTO != null)
                        {
                            if (!string.IsNullOrWhiteSpace(filterDTO.CustomerNumber))
                            {
                                criteria.Add(
                                	Expression.Disjunction()
                                		.Add(Expression.Conjunction()
        	                        			.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.CallerNumber), filterDTO.CustomerNumber))
        	                        			.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.Direction), CallDirection.Incoming)))
        	                        	.Add(Expression.Conjunction()
        	                        			.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.CalleeNumber), filterDTO.CustomerNumber))
        	                        			.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.Direction), CallDirection.Outgoing)))
                                	);
                            }
                        }
        	            
        	            tmpResult = query.Where(() => ch.CallHistoryStatus == CallHistoryStatus.Unresolved)
        	                    .Select(proj)
        	                    .TransformUsing(new DeepTransformer<CallHistoryDTO>()).List<CallHistoryDTO>();
        	            if(tmpResult != null) {
        	            	foreach(CallHistoryDTO tmpDTO in tmpResult){
                                string customerNumber = (tmpDTO.Direction == CallDirection.Incoming) ? tmpDTO.CallerNumber : tmpDTO.CalleeNumber;
        	            		UnresolvedCallGroupInfoDTO tmpGrpDTO = results.Find(x => x.CustomerNumber == customerNumber);
        	            		if(tmpGrpDTO == null) {
        	            			tmpGrpDTO = new UnresolvedCallGroupInfoDTO();
        	            			tmpGrpDTO.CustomerNumber = customerNumber;
                                    tmpGrpDTO.RecordingUrl = tmpDTO.RecordingUrl;
                                    tmpGrpDTO.Id =Convert.ToInt32(tmpDTO.Id);
                                    tmpGrpDTO.LastDiscussionOn = tmpDTO.StartTime;
        	            			results.Add(tmpGrpDTO);
        	            		}
                                if (tmpDTO.Direction == CallDirection.Incoming) tmpGrpDTO.IncomingCallCount++;
        	            		else tmpGrpDTO.OutgoingCallCount++;
                                if (tmpGrpDTO.LastDiscussionOn.CompareTo(tmpDTO.StartTime) < 0) tmpGrpDTO.LastDiscussionOn = tmpDTO.StartTime;
        	            		//If any of the call history for this number is in progress then show status as in progress.
        	            		if(tmpDTO.CallStatus == CallStatus.Inprogress) tmpGrpDTO.CallStatus = CallStatus.Inprogress;
        	            		else if(tmpGrpDTO.CallStatus != CallStatus.Inprogress) tmpGrpDTO.CallStatus = tmpDTO.CallStatus;
        	                }
                            results.Sort((x, y) => x.LastDiscussionOn.CompareTo(y.LastDiscussionOn));
        	            }
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while Loading Unresolved calls grid:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }
        public IList<CallHistoryDTO> fetchUnresolvedCallsForNumber(string customerNumber)
        {
            ISession session = null;
            IList<CallHistoryDTO> results = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        CallHistory ch = null;
                        FirmMember fm = null;
                        MasterControlData salutation = null;

                        CallHistoryDTO chDto = null;
                        var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => ch.Id).WithAlias(() => chDto.Id))
                                .Add(Projections.Property(() => ch.CallerNumber).WithAlias(() => chDto.CallerNumber))
                                .Add(Projections.Property(() => ch.CalleeNumber).WithAlias(() => chDto.CalleeNumber))
                                .Add(Projections.Property(() => ch.CallStatus).WithAlias(() => chDto.CallStatus))
                                .Add(Projections.Property(() => ch.CallHistoryStatus).WithAlias(() => chDto.CallHistoryStatus))
                                .Add(Projections.Property(() => ch.StartTime).WithAlias(() => chDto.StartTime))
                                .Add(Projections.Property(() => ch.Direction).WithAlias(() => chDto.Direction))
                                .Add(Projections.Property(() => salutation.Name), "FirmMember.Salutation.Name")
                                .Add(Projections.Property(() => fm.FirstName), "FirmMember.FirstName")
                                .Add(Projections.Property(() => fm.LastName), "FirmMember.LastName");
                        var query = session.QueryOver<CallHistory>(() => ch)
                            .Inner.JoinAlias(() => ch.FirmMember, () => fm)
                            .Inner.JoinAlias(() => ch.FirmMember.Salutation, () => salutation);

                        ICriteria criteria = query.RootCriteria;
                        criteria.Add(
                                    Expression.Disjunction()
                                        .Add(Expression.Conjunction()
                                                .Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.CallerNumber), customerNumber))
                                                .Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.Direction), CallDirection.Incoming)))
                                        .Add(Expression.Conjunction()
                                                .Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.CalleeNumber), customerNumber))
                                                .Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.Direction), CallDirection.Outgoing)))
                                    );

                        results = query.Where(() => ch.CallHistoryStatus == CallHistoryStatus.Unresolved)
                                .Select(proj)
                                .OrderBy(() => ch.StartTime).Desc()
                                .TransformUsing(new DeepTransformer<CallHistoryDTO>()).List<CallHistoryDTO>();
                        results.ToList<CallHistoryDTO>().ForEach(x => x.FirmMember.FullName = CommonUIConverter.getCustomerFullName(x.FirmMember.Salutation.Name,
                            x.FirmMember.FirstName, x.FirmMember.LastName));
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching unresolved calls for given customer number:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }
		public IList<CallHistoryDTO> fetchCallHistoryGridData(long propertyId, CallHistoryFilterDTO filterDTO)
        {
            ISession session = null;
            IList<CallHistoryDTO> results = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	CallHistory ch = null;
                    	Property p = null;
                        FirmMember fm = null;
                        MasterControlData sal = null;
                        
                        CallHistoryDTO chDto = null;
                        IList<CallHistoryDTO> tmpResult = null;
                        var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => ch.Id).WithAlias(() => chDto.Id))
                                .Add(Projections.Property(() => ch.CallerNumber).WithAlias(() => chDto.CallerNumber))
                                .Add(Projections.Property(() => ch.CalleeNumber).WithAlias(() => chDto.CalleeNumber))
                                .Add(Projections.Property(() => ch.CallStatus).WithAlias(() => chDto.CallStatus))
                                .Add(Projections.Property(() => ch.CallHistoryStatus).WithAlias(() => chDto.CallHistoryStatus))
                                .Add(Projections.Property(() => ch.StartTime).WithAlias(() => chDto.StartTime))
                                .Add(Projections.Property(() => ch.Direction).WithAlias(() => chDto.Direction))
                                .Add(Projections.Property(() => sal.Name), "FirmMember.Salutation.Name")
                                .Add(Projections.Property(() => fm.Id), "FirmMember.Id")
	                            .Add(Projections.Property(() => fm.FirstName), "FirmMember.FirstName")
	                            .Add(Projections.Property(() => fm.LastName), "FirmMember.LastName");
        	            var query = session.QueryOver<CallHistory>(() => ch)
        	            		.Inner.JoinAlias(() => ch.FirmMember, () => fm)
	        	                .Inner.JoinAlias(() => fm.Salutation, () => sal)
                                .Left.JoinAlias(() => ch.Property, () => p);
                        
        	            if (filterDTO != null)
                        {
        	            	ICriteria criteria = query.RootCriteria;
        	            	if(filterDTO.IsIncoming && !filterDTO.IsOutgoing) {
            	            	criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.Direction), CallDirection.Incoming));
            	            }
        	            	if(!filterDTO.IsIncoming && filterDTO.IsOutgoing) {
            	            	criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.Direction), CallDirection.Outgoing));
            	            }
                            if (!string.IsNullOrWhiteSpace(filterDTO.CustomerNumber))
                            {
                                criteria.Add(
                                	Expression.Disjunction()
                                		.Add(Expression.Conjunction()
        	                        			.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.CallerNumber), filterDTO.CustomerNumber))
        	                        			.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.Direction), CallDirection.Incoming)))
        	                        	.Add(Expression.Conjunction()
        	                        			.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.CalleeNumber), filterDTO.CustomerNumber))
        	                        			.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.Direction), CallDirection.Outgoing)))
                                	);
                            }
                            if (filterDTO.AgentId > 0)
                            {
                            	criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<FirmMember>(() => fm, x => x.Id), filterDTO.AgentId));
                            }
                        }
        	            
        	            results = query.Where(() => p.Id == propertyId)
        	                    .Select(proj)
                                .OrderBy(() => ch.StartTime).Desc()
        	                    .TransformUsing(new DeepTransformer<CallHistoryDTO>()).List<CallHistoryDTO>();
                        results.ToList<CallHistoryDTO>().ForEach(x => x.FirmMember.FullName = CommonUIConverter.getCustomerFullName(x.FirmMember.Salutation.Name, 
                            x.FirmMember.FirstName, x.FirmMember.LastName));
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while Loading Call History given Property:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }
		public IList<CallHistoryDTO> fetchCallHistoryForSoldUnit(long prUnitSaleDetailId, CallHistoryFilterDTO filterDTO)
        {
            ISession session = null;
            IList<CallHistoryDTO> results = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	CallHistory ch = null;
                    	PrUnitSaleDetail pusd = null;
                        FirmMember fm = null;
                        MasterControlData sal = null;
                        
                        CallHistoryDTO chDto = null;
                        IList<CallHistoryDTO> tmpResult = null;
                        var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => ch.Id).WithAlias(() => chDto.Id))
                                .Add(Projections.Property(() => ch.CallerNumber).WithAlias(() => chDto.CallerNumber))
                                .Add(Projections.Property(() => ch.CalleeNumber).WithAlias(() => chDto.CalleeNumber))
                                .Add(Projections.Property(() => ch.CallStatus).WithAlias(() => chDto.CallStatus))
                                .Add(Projections.Property(() => ch.CallHistoryStatus).WithAlias(() => chDto.CallHistoryStatus))
                                .Add(Projections.Property(() => ch.StartTime).WithAlias(() => chDto.StartTime))
                                .Add(Projections.Property(() => ch.Direction).WithAlias(() => chDto.Direction))
                                .Add(Projections.Property(() => sal.Name), "FirmMember.Salutation.Name")
                                .Add(Projections.Property(() => fm.Id), "FirmMember.Id")
	                            .Add(Projections.Property(() => fm.FirstName), "FirmMember.FirstName")
	                            .Add(Projections.Property(() => fm.LastName), "FirmMember.LastName");
        	            var query = session.QueryOver<CallHistory>(() => ch)
        	            		.Inner.JoinAlias(() => ch.FirmMember, () => fm)
	        	                .Inner.JoinAlias(() => fm.Salutation, () => sal)
                                .Inner.JoinAlias(() => ch.PrUnitSaleDetail, () => pusd);
                        
        	            if (filterDTO != null)
                        {
        	            	ICriteria criteria = query.RootCriteria;
        	            	if(filterDTO.IsIncoming && !filterDTO.IsOutgoing) {
            	            	criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.Direction), CallDirection.Incoming));
            	            }
        	            	if(!filterDTO.IsIncoming && filterDTO.IsOutgoing) {
            	            	criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.Direction), CallDirection.Outgoing));
            	            }
                            if (!string.IsNullOrWhiteSpace(filterDTO.CustomerNumber))
                            {
                                criteria.Add(
                                	Expression.Disjunction()
                                		.Add(Expression.Conjunction()
        	                        			.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.CallerNumber), filterDTO.CustomerNumber))
        	                        			.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.Direction), CallDirection.Incoming)))
        	                        	.Add(Expression.Conjunction()
        	                        			.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.CalleeNumber), filterDTO.CustomerNumber))
        	                        			.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.Direction), CallDirection.Outgoing)))
                                	);
                            }
                            if (filterDTO.AgentId > 0)
                            {
                            	criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<FirmMember>(() => fm, x => x.Id), filterDTO.AgentId));
                            }
                        }
        	            
        	            results = query.Where(() => pusd.Id == prUnitSaleDetailId)
        	                    .Select(proj)
                                .OrderBy(() => ch.StartTime).Desc()
        	                    .TransformUsing(new DeepTransformer<CallHistoryDTO>()).List<CallHistoryDTO>();
                        results.ToList<CallHistoryDTO>().ForEach(x => x.FirmMember.FullName = CommonUIConverter.getCustomerFullName(x.FirmMember.Salutation.Name, 
                            x.FirmMember.FirstName, x.FirmMember.LastName));
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while Loading Call History given Sold Unit:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }
        public IList<CallHistoryDTO> fetchCallsNotInSync(string firmNumber)
        {
            ISession session = null;
            IList<CallHistoryDTO> results = new List<CallHistoryDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                CallHistory ch = null;
                CallHistoryDTO chDTO = null;
                
                var proj = Projections.ProjectionList()
                        .Add(Projections.Property(() => ch.Id).WithAlias(() => chDTO.Id))
                        .Add(Projections.Property(() => ch.CallSid).WithAlias(() => chDTO.CallSid))
                        .Add(Projections.Property(() => ch.Direction).WithAlias(() => chDTO.Direction));
		        IList<CallHistory> calls = session.QueryOver<CallHistory>(() => ch)
                                .Select(proj)
                                .Where(() => ch.FirmNumber == firmNumber && ch.IsSync == IsSync.No).List<CallHistory>();
                foreach (CallHistory call in calls)
                {
                    results.Add(DomainToDTOUtil.convertToCallHistoryDTO(call, true));
                }
                results.ToList();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating call details:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }

        public long addCallHistory(CallHistoryDTO callHistoryDTO)
        {
            ISession session = null;
            long Id = 0;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        CallHistory callHistory = DTOToDomainUtil.populateCallHistoryAddFields(callHistoryDTO);
                        session.Save(callHistory);
                        Id = callHistory.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while adding Call History:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        
        public CallHistoryDTO fetchCallHistoryforCallSID(string CallSid)
        {
            ISession session = null;
            CallHistoryDTO callHistoryDTO = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                CallHistory ch = session.QueryOver<CallHistory>().Where(x => x.CallSid == CallSid).SingleOrDefault<CallHistory>();
                callHistoryDTO = DomainToDTOUtil.convertToCallHistoryDTO(ch, true);
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating call details:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return callHistoryDTO;
        }
        public FirmMemberDTO fetchAgentForCall(string Contact)
        {
            ISession session = null;
            FirmMemberDTO fmDTO = null;
            try
            {
            	string tmpContact = CommonUtil.getActualContact(Contact);
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	FirmMember fm = null;
                        ContactInfo ci = null;
                        UserDefinition UserDefinition = null;

                        var proj = Projections.ProjectionList()
                                        .Add(Projections.Property(() => fm.Id).WithAlias(() => fmDTO.Id))
                                        .Add(Projections.Property(() => ci.Contact), "ContactInfo.Contact")
                                        .Add(Projections.Property(() => ci.AltContact), "ContactInfo.AltContact")
                                        .Add(Projections.Property(() => UserDefinition.Id), "UserDefinition.Id")
                                        .Add(Projections.Property(() => UserDefinition.Username), "UserDefinition.Username")
                                        .Add(Projections.Property(() => UserDefinition.FirmNumber), "UserDefinition.FirmNumber");
                        var query = session.QueryOver<FirmMember>(() => fm)
                            .Inner.JoinAlias(() => fm.ContactInfo, () => ci)
                            .Inner.JoinAlias(() => fm.User, () => UserDefinition);
                        fmDTO = query.Select(proj).Where(() => ci.Contact.IsLike(tmpContact, MatchMode.End) || ci.AltContact.IsLike(tmpContact, MatchMode.End))
                            .TransformUsing(new DeepTransformer<FirmMemberDTO>()).SingleOrDefault<FirmMemberDTO>();   
                    }
                    catch (Exception e)
                    {
                    	log.Error("Unexpected error while fetching agent info for call intimation:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return fmDTO;
        }
        public long updateIncomingCallForIntimation(CallHistoryDTO callHistoryDTO)
        {
            ISession session = null;
            long Id = 0;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        CallHistory callHistory = session.Get<CallHistory>(callHistoryDTO.Id);
                        callHistory.PhoneNumberSid = callHistoryDTO.PhoneNumberSid;
                        callHistory.DateCreated = callHistoryDTO.DateCreated;
                        callHistory.DateUpdated = callHistoryDTO.DateUpdated;
                        callHistory.CallStatus = callHistoryDTO.CallStatus;
                        callHistory.FirmMember = DTOToDomainUtil.copyFirmMemberId(callHistory.FirmMember, callHistoryDTO.FirmMember);
                        callHistory.CalleeNumber = callHistoryDTO.CalleeNumber;
                        callHistory.UpdateDate = DateTime.Now;
                        callHistory.UpdateUser = callHistoryDTO.UpdateUser;
                        session.Update(callHistory);
                        Id = callHistory.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while incoming updating Call History details during call intimation:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        public long updateIncomingCallOnFinish(CallHistoryDTO callHistoryDTO)
        {
            ISession session = null;
            long Id = 0;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        CallHistory callHistory = session.Get<CallHistory>(callHistoryDTO.Id);
                        callHistory.CallerNumber = callHistoryDTO.CallerNumber;
                        callHistory.PhoneNumberSid = callHistoryDTO.PhoneNumberSid;
                        callHistory.DateCreated = callHistoryDTO.DateCreated;
                        callHistory.Duration = callHistoryDTO.Duration;
                        callHistory.RecordingUrl = callHistoryDTO.RecordingUrl;
                        callHistory.StartTime = callHistoryDTO.StartTime;
                        callHistory.EndTime = callHistoryDTO.EndTime;
                        callHistory.CallStatus = callHistoryDTO.CallStatus;
                        callHistory.DateUpdated = callHistoryDTO.DateUpdated;
                        callHistory.CalleeNumber = callHistoryDTO.CalleeNumber;
                        
                        session.Update(callHistory);
                        Id = callHistory.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating incoming Call History details after call is finished:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        public long updateOutgoingCallOnFinish(CallHistoryDTO callHistoryDTO)
        {
            ISession session = null;
            long Id = 0;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        CallHistory callHistory = session.QueryOver<CallHistory>().Where(x => x.CallSid == callHistoryDTO.CallSid).SingleOrDefault(); ;
                        callHistory.Duration = callHistoryDTO.Duration;
                        callHistory.RecordingUrl = callHistoryDTO.RecordingUrl;
                        callHistory.EndTime = callHistoryDTO.EndTime;
                        callHistory.CallStatus = callHistoryDTO.CallStatus;
                        callHistory.DateUpdated = callHistoryDTO.DateUpdated;
                        callHistory.UpdateUser = callHistoryDTO.UpdateUser;

                        session.Update(callHistory);
                        Id = callHistory.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating outgoing Call History details after call is finished:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        public long updateCallHistoryDuringSync(CallHistoryDTO callHistoryDTO)
        {
            ISession session = null;
            long Id = 0;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        CallHistory callHistory = session.QueryOver<CallHistory>().Where(x => x.CallSid == callHistoryDTO.CallSid).SingleOrDefault();

                        callHistory.IsSync = IsSync.Yes;
                        callHistory.ParentCallSid = callHistoryDTO.ParentCallSid;
                        callHistory.DateCreated = callHistoryDTO.DateCreated;
                        callHistory.AccountSid = callHistoryDTO.AccountSid;
                        callHistory.CalleeNumber = callHistoryDTO.CalleeNumber;
                        callHistory.CallerNumber = callHistoryDTO.CallerNumber;
                        callHistory.PhoneNumberSid = callHistoryDTO.PhoneNumberSid;    
                        callHistory.StartTime = callHistoryDTO.StartTime;
                        callHistory.EndTime = callHistoryDTO.EndTime;
                        callHistory.Uri = callHistoryDTO.Uri;
                        callHistory.CallStatus = callHistoryDTO.CallStatus;
                        callHistory.DateUpdated = callHistoryDTO.DateUpdated;
                        callHistory.Duration = callHistoryDTO.Duration;
                        callHistory.Price = callHistoryDTO.Price;
                        callHistory.AnsweredBy = callHistoryDTO.AnsweredBy;
                        callHistory.ForwardedFrom = callHistoryDTO.ForwardedFrom;
                        callHistory.CallerName = callHistoryDTO.CallerName;
                        callHistory.RecordingUrl = callHistoryDTO.RecordingUrl;
                        callHistory.RecordingFile = callHistoryDTO.RecordingFile;
                        
                        session.Update(callHistory);
                        Id = callHistory.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating Call History details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        public CallHistoryDTO fetchCallDetails(long Id)
        {
            ISession session = null;
            CallHistoryDTO callHistoryDTO = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        CallHistory callHistory = session.Get<CallHistory>(Id);
                        callHistoryDTO = DomainToDTOUtil.convertToCallHistoryDTO(callHistory, true);

                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Call details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return callHistoryDTO;
        }
        public void bindCallDetailsToUnit(List<CallHistoryDTO> unresolvedCallList, long PrUnitSaleId, UserDefinitionDTO userDefDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PrUnitSaleDetail tmpSaleDetail = session.Get<PrUnitSaleDetail>(PrUnitSaleId);
                        Property property = tmpSaleDetail.PropertyUnit.PropertyTower.Property;
                        List<long> callIds = new List<long>();
                        unresolvedCallList.ForEach(x => callIds.Add(x.Id));
                        string hqlActivityUpdate = "update CallHistory ch set ch.CallHistoryStatus = :status, ch.Property = :Property, ch.PrUnitSaleDetail = :PrUnitSaleDetail, "
                                + " ch.UpdateUser = :updateUser where ch.Id in (:callIds)";
                        session.CreateQuery(hqlActivityUpdate)
                                .SetEnum("status", CallHistoryStatus.Resolved)
                                .SetEntity("PrUnitSaleDetail", tmpSaleDetail)
                                .SetEntity("Property", property)
                                .SetString("updateUser", userDefDto.Username)
                                .SetParameterList("callIds", callIds)
                                .ExecuteUpdate();
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Call details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
    }   
}