﻿using NHibernate;
using NHibernate.Criterion;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace ConstroSoft.Logic.BO
{
    public class PaymentDueReportBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public PaymentDueReportBO() { }

        public BusinessOutputTO processPaymentDueLetter(string firmNumber, IList<PrUnitSaleDetailDTO> listPrUnitSaleDetailDto, long propertyId)
        {
            BusinessOutputTO businessOutputTO = new BusinessOutputTO();
            businessOutputTO.resultList = new List<object>();
            try
            {
                DataTable PropertyDetail = populatePropertyDetailsColumns();
                DataTable PaymentDueReport = populatePaymentDueReportColumns();
                FirmBO firmBO = new FirmBO();
                PropertyBO propertyBO = new PropertyBO();
                FirmDTO firmDto = firmBO.fetchFirmDetails(firmNumber);
                SoldPropertyUnitBO soldUnitBO = new SoldPropertyUnitBO();
                PropertyDTO propertyDTO = propertyBO.fetchProperty(propertyId);
                DataRow PropertyDetailsRow = populatePropertyReportRows(PropertyDetail, firmDto, propertyDTO, firmNumber);
                PropertyDetail.Rows.Add(PropertyDetailsRow);
                foreach (PrUnitSaleDetailDTO selectedPrUnitSaleDetailDto in listPrUnitSaleDetailDto)
                {
                    List<PropertyScheduleDTO> propertyScheduleList = propertyBO.fetchPropertySchedule(selectedPrUnitSaleDetailDto.PropertyUnit.PropertyTower.Id);
                    List<PropertyScheduleDTO> tmpStageList = propertyScheduleList.FindAll(x => x.Status == PRScheduleStageStatus.Completed);
                    string errorMessage = validateStageSetup(tmpStageList);
                    if (!string.IsNullOrWhiteSpace(errorMessage))
                    {
                        businessOutputTO.status = BusinessOutputTO.Status.FAILURE;
                        businessOutputTO.errorMessage = errorMessage;
                    }
                    else
                    {
                        
                        DataRow propertyDueRow = populatePaymentDueReportRows(PaymentDueReport, selectedPrUnitSaleDetailDto, firmDto, tmpStageList, firmNumber);
                       
                        PaymentDueReport.Rows.Add(propertyDueRow);
                        businessOutputTO.status = BusinessOutputTO.Status.SUCCESS;
                    }
                }
                businessOutputTO.resultList.Add(PropertyDetail);
                businessOutputTO.resultList.Add(PaymentDueReport);
            }
            catch (Exception e)
            {
                log.Error("Exception while generating Payment Due Report", e);
                throw new Exception(Resources.Messages.system_error);
            }
            return businessOutputTO;
        }
        public static string validateStageSetup(List<PropertyScheduleDTO> tmpStageList)
        {
            string errorMessage = "";
            if (tmpStageList == null && tmpStageList.Count == 0)
            {
                errorMessage = "Property Schedule is not set. Please set Property Schedule";
            }
            return errorMessage;
        }
        private static DataTable populatePropertyDetailsColumns()
        {
            DataTable PropertyDetails = new DataTable();
            PropertyDetails.Columns.Add("PropertyName", typeof(string));
            PropertyDetails.Columns.Add("Address", typeof(string));
            return PropertyDetails;
        }


        private static DataTable populatePaymentDueReportColumns()
        {

            DataTable PaymentDueReport = new DataTable();
            PaymentDueReport.Columns.Add("PropertyTower", typeof(string));
            PaymentDueReport.Columns.Add("PropertyUnit", typeof(string));
            PaymentDueReport.Columns.Add("CustomerName", typeof(string));
            PaymentDueReport.Columns.Add("ContctNumber", typeof(string));
            PaymentDueReport.Columns.Add("EmailId", typeof(string));
            PaymentDueReport.Columns.Add("PaymentAmount", typeof(double));
            PaymentDueReport.Columns.Add("PaidAmount", typeof(double));
            PaymentDueReport.Columns.Add("PaymentDueAmount", typeof(double));
            return PaymentDueReport;
        }

        private DataRow populatePropertyReportRows(DataTable PropertyDetails, FirmDTO firmDto, PropertyDTO propertyDTO, string firmNumber)
        {
            DataRow PropertyReportRow = PropertyDetails.NewRow();
            string BLANK_STRING = "";
            PropertyReportRow["PropertyName"] = propertyDTO.Name;
            AddressDTO addressDTO = propertyDTO.ContactInfo.Addresses.ToList()[0];
            string address = addressDTO.AddressLine1 + " ";
            address = string.Concat(address, addressDTO.AddressLine2 != null ? addressDTO.AddressLine2 : BLANK_STRING);
            address = string.Concat(address, addressDTO.Town != null ? addressDTO.Town : BLANK_STRING);
            address = string.Concat(address, " " + addressDTO.City.Name + " " + addressDTO.State.Name + " " + addressDTO.Country.Name + " " + addressDTO.Pin);
            PropertyReportRow["Address"] = address;
            return PropertyReportRow;
        }

        private DataRow populatePaymentDueReportRows(DataTable PaymentDueReport, PrUnitSaleDetailDTO selectedPrUnitSaleDetailDto, FirmDTO firmDto, List<PropertyScheduleDTO> tmpStageList, string firmNumber)
        {
            string BLANK_STRING = "";
            DataRow PaymentDueReportRow = PaymentDueReport.NewRow();

            //string customerName = selectedPrUnitSaleDetailDto.Customer.Salutation.Name + " " + selectedPrUnitSaleDetailDto.Customer.FirstName + " ";
            //customerName = string.Concat(customerName, selectedPrUnitSaleDetailDto.Customer.MiddleName != null ? selectedPrUnitSaleDetailDto.Customer.MiddleName + " " : BLANK_STRING);
            //customerName = string.Concat(customerName, selectedPrUnitSaleDetailDto.Customer.LastName != null ? selectedPrUnitSaleDetailDto.Customer.LastName + " " : BLANK_STRING);
            PaymentDueReportRow["CustomerName"] = selectedPrUnitSaleDetailDto.Customer.FirstName;
            PropertyUnitDTO propertyUnitDto = selectedPrUnitSaleDetailDto.PropertyUnit;
            PropertyTowerDTO propertyTowerDto = selectedPrUnitSaleDetailDto.PropertyUnit.PropertyTower;
            PaymentDueReportRow["PropertyUnit"] = selectedPrUnitSaleDetailDto.PropertyUnit.UnitNo;
            PaymentDueReportRow["ContctNumber"] = selectedPrUnitSaleDetailDto.Customer.ContactInfo.Contact.ToString();
            PaymentDueReportRow["EmailId"] = selectedPrUnitSaleDetailDto.Customer.ContactInfo.Email.ToString();

            PaymentDueReportRow["PropertyTower"] = selectedPrUnitSaleDetailDto.PropertyUnit.PropertyTower.Name;
            SoldPropertyUnitBO soldUnitBO = new SoldPropertyUnitBO();
            PrUnitSaleDetailDTO prUnitSaleDetailDto = soldUnitBO.fetchPrUnitSaleDetailforLetter(firmNumber, selectedPrUnitSaleDetailDto.Id,
                       selectedPrUnitSaleDetailDto.PropertyUnit.PropertyTower.Property.Id);
            decimal totalPaidAmt;
            decimal totalPaymentAmount;
            PrUnitSalePymtDTO tmpPrUnitSalePymtDTO = prUnitSaleDetailDto.PrUnitSalePymts.ToList<PrUnitSalePymtDTO>().Find(x => isSalePayment(x.PymtType.Name));
            totalPaymentAmount = tmpPrUnitSalePymtDTO.PymtAmt;
            totalPaidAmt = tmpPrUnitSalePymtDTO.PaymentMaster.TotalPaid;
            
            decimal stagePercentge;
            PropertyScheduleDTO propertyScheduleDTO = null;
            decimal actualPaymentDue = 0.0M;
            decimal totalPayblepayment = 0.0M;
            if (tmpStageList != null && tmpStageList.Count > 0)
            {
                stagePercentge = (tmpStageList.Sum(x => x.Percentage));
                decimal totalPaymentDue = (totalPaymentAmount * stagePercentge) / 100;
                actualPaymentDue = totalPaymentDue - totalPaidAmt;
                int maxZ = tmpStageList.Max(obj => obj.StageNumber);
                propertyScheduleDTO = (PropertyScheduleDTO)tmpStageList.Where(obj => obj.StageNumber == maxZ).FirstOrDefault();
                totalPayblepayment = totalPaymentDue;
            }
            PaymentDueReportRow["PaymentAmount"] = Convert.ToString(prUnitSaleDetailDto.TotalPymtAmt);
            PaymentDueReportRow["PaidAmount"] = totalPaidAmt;
            PaymentDueReportRow["PaymentDueAmount"] = actualPaymentDue;
            return PaymentDueReportRow;
        }
        private bool isSalePayment(string paymentType)
        {
            return Constants.MCD_SALE_PAYMENT.Equals(paymentType);
        }
        public IList<PrUnitSaleDetailDTO> fetchSoldPropertyUnits(string firmNumber,long propertyId, long propertyTowerId)
        {
            ISession session = null;
            IList<PrUnitSaleDetailDTO> result = new List<PrUnitSaleDetailDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Property p = null;
                        PropertyUnit pu = null;
                        PrUnitSaleDetail pus = null;
                        Customer c = null;
                        ContactInfo ci = null;
                        PropertyTower pt = null;
                        MasterControlData putype = null;
                        FirmMember fm = null;

                        PrUnitSaleDetailDTO pusdto = null;

                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => pus.Id).WithAlias(() => pusdto.Id))
                                    .Add(Projections.SqlFunction("concat",
                                                NHibernateUtil.String,
                                                Projections.Property(() => c.FirstName),
                                                Projections.Constant(" "),
                                                Projections.Property(() => c.LastName)), "Customer.FirstName")
                                    .Add(Projections.Property(() => c.Id), "Customer.Id")
                                    .Add(Projections.SqlFunction("concat",
                                                NHibernateUtil.String,
                                                Projections.Property(() => fm.FirstName),
                                                Projections.Constant(" "),
                                                Projections.Property(() => fm.LastName)), "FirmMember.FirstName")

                                    .Add(Projections.Property(() => fm.Id), "FirmMember.Id")
                                    .Add(Projections.Property(() => p.Id), "PropertyUnit.PropertyTower.Property.Id")
                                    .Add(Projections.Property(() => p.Name), "PropertyUnit.PropertyTower.Property.Name")
                                    .Add(Projections.Property(() => pt.Id), "PropertyUnit.PropertyTower.Id")
                                    .Add(Projections.Property(() => pt.Name), "PropertyUnit.PropertyTower.Name")
                                    .Add(Projections.Property(() => pu.Id), "PropertyUnit.Id")
                                    .Add(Projections.Property(() => pu.Wing), "PropertyUnit.Wing")
                                    .Add(Projections.Property(() => pu.UnitNo), "PropertyUnit.UnitNo")
                                    .Add(Projections.Property(() => putype.Name), "PropertyUnit.UnitType.Name")
                                    .Add(Projections.Property(() => ci.Contact), "Customer.ContactInfo.Contact")
                                    .Add(Projections.Property(() => ci.Email), "Customer.ContactInfo.Email");


                        var query = session.QueryOver<PrUnitSaleDetail>(() => pus)
                            .Left.JoinAlias(() => pus.PropertyUnit, () => pu)
                            .Left.JoinAlias(() => pus.PropertyUnit.UnitType, () => putype)
                            .Left.JoinAlias(() => pus.PropertyUnit.PropertyTower, () => pt)
                            .Left.JoinAlias(() => pus.PropertyUnit.PropertyTower.Property, () => p)
                            .Left.JoinAlias(() => pus.Customer, () => c)
                            .Left.JoinAlias(() => pus.Customer.ContactInfo, () => ci)
                            .Left.JoinAlias(() => pus.FirmMember, () => fm);
                        result = query.Where(() => p.Id == propertyId && pus.Status == PRUnitSaleStatus.Sold && p.FirmNumber == firmNumber && pt.Id == propertyTowerId)
                        
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<PrUnitSaleDetailDTO>()).List<PrUnitSaleDetailDTO>();
                        result.ToList().ForEach(x => x.PropertyUnit.UnitNo
                                = CommonUIConverter.getPropertyUnitFormattedNo(x.PropertyUnit.Wing, x.PropertyUnit.UnitNo));
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching sold property units :", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
    }
}