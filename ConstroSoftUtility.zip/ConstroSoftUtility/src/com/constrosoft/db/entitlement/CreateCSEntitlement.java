package com.constrosoft.db.entitlement;

import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class CreateCSEntitlement {
	static String TAB = "	";
	static String USER_ROLE_QUERY = "INSERT INTO USER_ROLES(NAME,DESCRIPTION) VALUES ('{NAME}','{DESCRIPTION}');";
	static String ENTITLEMENT_QUERY = "INSERT INTO USER_ENTITLEMENT(NAME,LEVEL,PARENT_ID,DESCRIPTION) VALUES ('{NAME}',{LEVEL},{PARENT_ID},'{DESCRIPTION}');";
	static String ENTITLEMENT_WITH_PARENT_QUERY = "INSERT INTO USER_ENTITLEMENT(NAME,LEVEL,PARENT_ID,DESCRIPTION) SELECT '{NAME}',{LEVEL},ID,'{DESCRIPTION}' FROM USER_ENTITLEMENT WHERE NAME = '{PARENT_ENTITLEMENT}';";
	static String USER_ROLE_ENTITLEMENT_QUERY = "INSERT INTO USER_ROLE_ENTITLEMENT(USER_ROLE_ID,ENTITLEMENT_ID) SELECT ID, (SELECT ID FROM USER_ENTITLEMENT WHERE NAME = '{ENTITLEMENT}') FROM USER_ROLES WHERE NAME = '{USER_ROLE}';";
	static String MCD_QUERY = "INSERT INTO MASTER_CONTROL_DATA(TYPE,NAME,DESCRIPTION,SYSTEM_DEFINED,FIRM_NUMBER,INSERT_USER,UPDATE_USER) VALUES ('{TYPE}','{NAME}','{DESCRIPTION}','{SYSTEM_DEFINED}','{FIRM_NUMBER}','CSADMIN','CSADMIN');";
	public static void main(String[] args) {
		try {
			FileInputStream file = new FileInputStream(new File("C:\\Sunil\\Other\\WizEye\\ConstroSoft\\DB\\Entitlements.xlsx"));

			// Create Workbook instance holding reference to .xlsx file
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			// Get first/desired sheet from the workbook
			XSSFSheet sheet = workbook.getSheet("ENTITLEMENT");
			Map<String, Integer> userRoleMap = getUserRolesScript(sheet);
			createEntitlementScripts(sheet);
			getUserRolesEntitlementScript(sheet, userRoleMap);
			createMasterDataScript(workbook.getSheet("MASTER_DATA"));
			file.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private static void createMasterDataScript(XSSFSheet sheet) {
        Iterator<Row> rowIterator = sheet.iterator();
        StringBuffer mcdScript = new StringBuffer();
        addScriptHeader(mcdScript, "MASTER_CONTROL_DATA");
        boolean isStart = false;
        String firmNumber = getStringValue(sheet.getRow(0).getCell(1));
        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            if(!isStart && isMCDStartRow(row)) {
                isStart = true;
                rowIterator.next();
                row = rowIterator.next();
            }
            if(isMCDEndRow(row)) {
                break;
            }
            if(isStart) {
                String type = getStringValue(row.getCell(0));
                String name = getStringValue(row.getCell(1));
                String systemDefined = getStringValue(row.getCell(2));
                String description = getStringValue(row.getCell(3));
                String query = MCD_QUERY.replace("{TYPE}", type);
                query = query.replace("{NAME}", name);
                query = query.replace("{DESCRIPTION}", description);
                query = query.replace("{SYSTEM_DEFINED}", systemDefined);
                query = query.replace("{FIRM_NUMBER}", firmNumber);
                mcdScript.append(query);
                mcdScript.append("\n");
            }
        }
        System.out.println(mcdScript.toString());
        System.out.println("");
    }
	private static void createEntitlementScripts(XSSFSheet sheet) {
	    
	    Iterator<Row> rowIterator = sheet.iterator();
        String parentEntitlement = "";
        StringBuffer entitlementScript = new StringBuffer();
        boolean isStart = false;
        addScriptHeader(entitlementScript, "ENTITLEMENTS");
        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            if(!isStart && isEntitlementStartRow(row)) {
                isStart = true;
                rowIterator.next();
                row = rowIterator.next();
            }
            if(isEntitlementEndRow(row)) {
                break;
            }
            if(isStart) {
                parentEntitlement = getEntitlementRowScript(row, entitlementScript, parentEntitlement);
            }
        }
        System.out.println(entitlementScript.toString());
        System.out.println("");
	}
	private static String getEntitlementRowScript(Row row, StringBuffer entitlementScript, String parentEntitlement) {
	    String tmpLevel = getStringValue(row.getCell(0));
	    String entitlement = getStringValue(row.getCell(1));
	    String description = getStringValue(row.getCell(2));
	    String query = "";
	    if(tmpLevel.equals("0")) {
	        entitlementScript.append("----------------MENU : "+ entitlement +" -------------------");
	        entitlementScript.append("\n");
    	    query = ENTITLEMENT_QUERY.replace("{NAME}", entitlement);
    	    query = query.replace("{LEVEL}", tmpLevel);
    	    query = query.replace("{PARENT_ID}", "NULL");
    	    query = query.replace("{DESCRIPTION}", description);
	    } else {
	        query = ENTITLEMENT_WITH_PARENT_QUERY.replace("{NAME}", entitlement);
            query = query.replace("{LEVEL}", tmpLevel);
            query = query.replace("{DESCRIPTION}", description);
            query = query.replace("{PARENT_ENTITLEMENT}", parentEntitlement);
	    }
	    entitlementScript.append(query);
	    entitlementScript.append("\n");
	    return entitlement;
	}
	private static Map<String, Integer> getUserRolesScript(XSSFSheet sheet) {
	    Iterator<Row> rowIterator = sheet.iterator();
        StringBuffer userRoleScript = new StringBuffer();
        Map<String, Integer> userRoleMap = new LinkedHashMap<String, Integer>();
        addScriptHeader(userRoleScript, "USER_ROLES");
        boolean isStart = false;
        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            if(!isStart && isUserRoleStartRow(row)) {
                isStart = true;
                rowIterator.next();
                row = rowIterator.next();
            }
            if(isUserRoleEndRow(row)) {
                break;
            }
            if(isStart) {
                String name = getStringValue(row.getCell(0));
                String description = getStringValue(row.getCell(1));
                String column = getStringValue(row.getCell(2));
                String query = USER_ROLE_QUERY.replace("{NAME}", name);
                query = query.replace("{DESCRIPTION}", description);
                userRoleScript.append(query);
                userRoleScript.append("\n");
                userRoleMap.put(name, Integer.parseInt(column));
            }
        }
        System.out.println(userRoleScript.toString());
        System.out.println("");
        return userRoleMap;
	}
	private static void getUserRolesEntitlementScript(XSSFSheet sheet, Map<String, Integer> userRoleMap) {
        
        StringBuffer userRoleScript = new StringBuffer();
        for(Map.Entry<String, Integer> entry : userRoleMap.entrySet()) {
            boolean isStart = false;
            String userRole = entry.getKey();
            Integer colIndex = entry.getValue();
            addScriptHeader(userRoleScript, userRole+" : USER_ROLE_ENTITLEMENT");
            Iterator<Row> rowIterator = sheet.iterator();
            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                if(!isStart && isEntitlementStartRow(row)) {
                    isStart = true;
                    rowIterator.next();
                    row = rowIterator.next();
                }
                if(isEntitlementEndRow(row)) {
                    break;
                }
                if(isStart) {
                    String entitlement = getStringValue(row.getCell(1));
                    String assigned = getStringValue(row.getCell(colIndex));
                    if("Y".equals(assigned)) {
                        String query = USER_ROLE_ENTITLEMENT_QUERY.replace("{ENTITLEMENT}", entitlement);
                        query = query.replace("{USER_ROLE}", userRole);
                        String tmpLevel = getStringValue(row.getCell(0));
                        if("0".equals(tmpLevel)) {
                            userRoleScript.append("----------------MENU : "+ entitlement +" -------------------");
                            userRoleScript.append("\n");
                        }
                        userRoleScript.append(query);
                        userRoleScript.append("\n");
                    }
                }
            }
        }
        
        System.out.println(userRoleScript.toString());
        System.out.println("");
    }
	private static void addScriptHeader(StringBuffer scriptBuffer, String headerName) {
	    scriptBuffer.append("--------------------------------------------------------------------------------------------------------------\n");
	    scriptBuffer.append("---------------- "+headerName+"-------------------");
	    scriptBuffer.append("\n--------------------------------------------------------------------------------------------------------------\n");
	}
	private static String getStringValue(Cell cell) {
        String result = "";
        switch (cell.getCellType()) {
        case Cell.CELL_TYPE_NUMERIC:
            result = cell.getNumericCellValue() + "";
            result = result.substring(0, result.indexOf("."));
            break;
        default:
            result = cell.getStringCellValue();
        }
        return result;
    }
	private static boolean isUserRoleStartRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "USER_ROLES_START".equalsIgnoreCase(value);
    }
	private static boolean isUserRoleEndRow(Row row) {
	    String value = getStringValue(row.getCell(0));
        return value != null && "USER_ROLES_END".equalsIgnoreCase(value);
    }
	private static boolean isEntitlementStartRow(Row row) {
	    String value = getStringValue(row.getCell(0));
        return value != null && "ENTITLEMENT_START".equalsIgnoreCase(value);
    }
    private static boolean isEntitlementEndRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "ENTITLEMENT_END".equalsIgnoreCase(value);
    }
    private static boolean isMCDStartRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "MCD_START".equalsIgnoreCase(value);
    }
    private static boolean isMCDEndRow(Row row) {
        String value = getStringValue(row.getCell(0));
        return value != null && "MCD_END".equalsIgnoreCase(value);
    }
}
