using System;
using System.Text;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Iesi.Collections.Generic;


namespace ConstroSoft {
    
    public class PdcBook {
        public PdcBook()
        {
            this.PostDatedChequesFrom = new HashSet<PostDatedCheque>();
            this.PostDatedChequesTo = new HashSet<PostDatedCheque>();
        }
        public virtual long Id { get; set; }
        public virtual string Description { get; set; }
        public virtual Customer CustomerIn { get; set; }
        public virtual Customer CustomerOut { get; set; }
        public virtual Firm FirmIn { get; set; }
        public virtual Firm FirmOut { get; set; }
        public virtual Agency AgencyIn { get; set; }
        public virtual Agency AgencyOut { get; set; }
        public virtual ISet<PostDatedCheque> PostDatedChequesFrom { get; set; }
        public virtual ISet<PostDatedCheque> PostDatedChequesTo { get; set; }
    }
}
