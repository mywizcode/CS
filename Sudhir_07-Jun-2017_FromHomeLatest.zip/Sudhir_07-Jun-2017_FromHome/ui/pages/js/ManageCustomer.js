﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initCustomerGrid();
    initAddressGrid();
    initSoldUnitGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("tab2Content");
    enableTab(true);
}

function initAddressGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "addressGrid",
        pageLength: 5,
        isViewOnly: isViewOnly,
        responsiveModalTitle: "Address Details",
        customBtnGrpId: "#addressGridBtnGrp",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToAddressHdnId");
}

function initCustomerGrid() {
    var dtOptions = {
        tableId: "customerGrid",
        pageLength: 10,
        isViewOnly: false,
        customBtnGrpId: "#custSearchBtnDiv",
        hideSearch: false
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToCustHdnId");
}
function initSoldUnitGrid() {
    var dtOptions = {
        tableId: "soldUnitsGrid",
        pageLength: 5,
        isViewOnly: false,
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
}