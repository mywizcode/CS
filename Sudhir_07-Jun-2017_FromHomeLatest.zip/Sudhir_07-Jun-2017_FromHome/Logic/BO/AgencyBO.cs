﻿using NHibernate;
using NHibernate.Criterion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ConstroSoft.Logic.BO
{
    public class AgencyBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public AgencyBO() { }

        public AgencyDTO fetchAgency(long Id)
        {
            ISession session = null;
            AgencyDTO agencyDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Agency agency = session.Get<Agency>(Id);
                        agencyDto = DomainToDTOUtil.convertToAgencyDTO(agency, true);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Agency details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return agencyDto;
        }

        public static AgencyDTO convertToAgencyDTO(Agency agency, bool allFields)
        {
            AgencyDTO agencyDto = null;
            if (agency != null)
            {
                agencyDto = new AgencyDTO();
                agencyDto.Id = agency.Id;
                agencyDto.RegistrationNo = agency.RegistrationNo;
                agencyDto.AgencyType = DomainToDTOUtil.convertToMasterControlDTO(agency.AgencyType, false);
                agencyDto.OwnerName = agency.OwnerName;
                agencyDto.AgencyName = agency.AgencyName;
                agencyDto.Description = agency.Description;
                if (allFields)
                {
                    agencyDto.ContactInfo = DomainToDTOUtil.convertToContactInfoDTO(agency.ContactInfo);
                    agencyDto.DocumentInfo = DomainToDTOUtil.convertToDocumentInfoDTO(agency.DocumentInfo);                   
                    agencyDto.InsertDate = agency.InsertDate;
                    agencyDto.UpdateDate = agency.UpdateDate;
                    agencyDto.Version = agency.Version;
                    agencyDto.InsertUser = agency.InsertUser;
                    agencyDto.UpdateUser = agency.UpdateUser;
                }
            }
            return agencyDto;
        }

        public long saveAgency(AgencyDTO agencyDto)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Agency agency = DTOToDomainUtil.populateAgencyAddFields(agencyDto);                        
                        session.Save(agency);
                        Id = agency.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Agency details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        public void updateAgency(AgencyDTO agencyDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Agency agency = session.Get<Agency>(agencyDto.Id);
                        DTOToDomainUtil.populateAgencyUpdateFields(agency, agencyDto);
                        session.Update(agency);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating Agency details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }


    
    public void deleteAgency(long Id)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Agency agncye = session.Get<Agency>(Id);
                        session.Delete(agncye);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while deleting Agency details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }

    public IList<AgencyDTO> fetchAgencyGridData(string firmNumber, AgencySearchBy searchBy, long searchByValue)
    {
        ISession session = null;
        IList<AgencyDTO> result = new List<AgencyDTO>();
        try
        {
            session = NHibertnateSession.OpenSession();
            MasterControlData agencyType = null;
            Agency cm = null;
            ContactInfo c = null;
            AgencyDTO cmDto = null;
            var proj = Projections.ProjectionList()
                       .Add(Projections.Property(() => cm.Id).WithAlias(() => cmDto.Id))
                        .Add(Projections.Property(() => cm.OwnerName).WithAlias(() => cmDto.OwnerName))
                       .Add(Projections.Property(() => cm.AgencyName).WithAlias(() => cmDto.AgencyName))
                       .Add(Projections.Property(() => agencyType.Name), "AgencyType.Name")
                       .Add(Projections.Property(() => c.Contact), "ContactInfo.Contact")
                       .Add(Projections.Property(() => c.Email), "ContactInfo.Email");
                 var query = session.QueryOver<Agency>(() => cm)
                .Left.JoinAlias(() => cm.AgencyType, () => agencyType)
                .Inner.JoinAlias(() => cm.ContactInfo, () => c);
            if (AgencySearchBy.NONE != searchBy && searchByValue != -1)
            {
                PropertyProjection prop = null;
                if (AgencySearchBy.Agency_Name == searchBy)
                {
                    prop = CommonUtil.BuildProjection<Agency>(() => cm, x => x.Id);
                }
                else if (AgencySearchBy.Agency_Type == searchBy)
                {
                    prop = CommonUtil.BuildProjection<MasterControlData>(() => agencyType, x => x.Id);
                }
                else if (AgencySearchBy.Owner_Name == searchBy)
                {
                    prop = CommonUtil.BuildProjection<Agency>(() => cm, x => x.Id);
                }
                query.Where(Restrictions.Eq(prop, searchByValue));
            }
            result = query.Where(() => cm.FirmNumber == firmNumber)
                .Select(proj)
                .TransformUsing(new DeepTransformer<AgencyDTO>()).List<AgencyDTO>();
        }
        catch (Exception exp)
        {
            log.Error("Unexpected error populating dropdown:");
            log.Error(exp.Message, exp);
        }
        finally
        {
            NHibertnateSession.closeSession(session);
        }
        return result;
    }
    }
}