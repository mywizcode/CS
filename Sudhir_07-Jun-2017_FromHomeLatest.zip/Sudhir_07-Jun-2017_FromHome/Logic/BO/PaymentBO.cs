﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq.Expressions;
using NHibernate.Impl;
using System.Linq;

/// <summary>
/// Summary description for propertyBO
/// </summary>
namespace ConstroSoft
{
    public class PaymentBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public PaymentBO() { }

        public IList<PrUnitSalePymtDTO> fetchCustomerToFromFirmPayments(string firmNumber, long propertyTowerId, PRUnitSalePymtTo pymtTo,
            PaymentSearchBy searchBy, long searchByValue)
        {
            ISession session = null;
            IList<PrUnitSalePymtDTO> result = new List<PrUnitSalePymtDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                PrUnitSalePymt pusp = null;
                Property p = null;
                PropertyUnit pu = null;
                PrUnitSaleDetail pus = null;
                Customer c = null;
                PropertyTower pt = null;
                PaymentMaster pm = null;
                FirmAccount fa = null;
                MasterControlData putype = null;
                MasterControlData pusptype = null;

                PrUnitSalePymtDTO puspdt = null;
                
                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => pusp.Id).WithAlias(() => puspdt.Id))
                            .Add(Projections.SqlFunction("concat",
                                        NHibernateUtil.String,
                                        Projections.Property(() => c.FirstName),
                                        Projections.Constant(" "),
                                        Projections.Property(() => c.LastName)), "PrUnitSaleDetail.Customer.FirstName")
                            .Add(Projections.Property(() => p.Name), "PrUnitSaleDetail.PropertyUnit.PropertyTower.Property.Name")
                            .Add(Projections.Property(() => fa.Id), "PrUnitSaleDetail.PropertyUnit.PropertyTower.Property.FirmAccount.Id")
                            .Add(Projections.Property(() => pt.Name), "PrUnitSaleDetail.PropertyUnit.PropertyTower.Name")
                            .Add(Projections.Property(() => pu.Wing), "PrUnitSaleDetail.PropertyUnit.Wing")
                            .Add(Projections.Property(() => pu.UnitNo), "PrUnitSaleDetail.PropertyUnit.UnitNo")
                            .Add(Projections.Property(() => putype.Name), "PrUnitSaleDetail.PropertyUnit.UnitType.Name")
                            .Add(Projections.Property(() => pus.BookingDate), "PrUnitSaleDetail.BookingDate")
                            .Add(Projections.Property(() => pus.SaleRate), "PrUnitSaleDetail.SaleRate")
                            .Add(Projections.Property(() => pus.AgreementAmt), "PrUnitSaleDetail.AgreementAmt")
                            .Add(Projections.Property(() => pus.Status), "PrUnitSaleDetail.Status")
                            .Add(Projections.Property(() => pusptype.Name), "PymtType.Name")
                            .Add(Projections.Property(() => pm.Id), "PaymentMaster.Id")
                            .Add(Projections.Property(() => pm.TotalAmt), "PaymentMaster.TotalAmt")
                            .Add(Projections.Property(() => pm.TotalPaid), "PaymentMaster.TotalPaid")
                            .Add(Projections.Property(() => pm.TotalPending), "PaymentMaster.TotalPending")
                            .Add(Projections.Property(() => pm.Status), "PaymentMaster.Status")
                            .Add(Projections.Property(() => pusp.Description).WithAlias(() => puspdt.Description));
                var query = session.QueryOver<PrUnitSalePymt>(() => pusp)
                    .Inner.JoinAlias(() => pusp.PaymentMaster, () => pm)
                    .Left.JoinAlias(() => pusp.PymtType, () => pusptype)
                    .Left.JoinAlias(() => pusp.PrUnitSaleDetail, () => pus)
                    .Left.JoinAlias(() => pusp.PrUnitSaleDetail.PropertyUnit, () => pu)
                    .Left.JoinAlias(() => pusp.PrUnitSaleDetail.PropertyUnit.UnitType, () => putype)
                    .Left.JoinAlias(() => pusp.PrUnitSaleDetail.PropertyUnit.PropertyTower, () => pt)
                    .Left.JoinAlias(() => pusp.PrUnitSaleDetail.PropertyUnit.PropertyTower.Property, () => p)
                    .Left.JoinAlias(() => pusp.PrUnitSaleDetail.PropertyUnit.PropertyTower.Property.FirmAccount, () => fa)
                    .Left.JoinAlias(() => pusp.PrUnitSaleDetail.Customer, () => c);
                if (PaymentSearchBy.NONE != searchBy && searchByValue != -1)
                {
                    PropertyProjection prop = null;
                    if (PaymentSearchBy.CUSTOMER_NAME == searchBy)
                    {
                        prop = CommonUtil.BuildProjection<Customer>(() => c, x => x.Id);
                    }
                    else if (PaymentSearchBy.UNIT_NO == searchBy)
                    {
                        prop = CommonUtil.BuildProjection<PropertyUnit>(() => pu, x => x.Id);
                    }
                    query.Where(Restrictions.Eq(prop, searchByValue));
                }
                result = query.Where(() => p.FirmNumber == firmNumber && pt.Id == propertyTowerId && pusp.PymtTo == pymtTo)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<PrUnitSalePymtDTO>()).List<PrUnitSalePymtDTO>();
                result.ToList().ForEach(x => x.PrUnitSaleDetail.PropertyUnit.UnitNo
                    = CommonUIConverter.getPropertyUnitFormattedNo(x.PrUnitSaleDetail.PropertyUnit.Wing, x.PrUnitSaleDetail.PropertyUnit.UnitNo));
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error fetching data for Payment search grid:");
                log.Error(exp.Message, exp);
                throw exp;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public IList<PropertyExpenseDTO> fetchFirmToAgencyPayments(string firmNumber, long propertyId, PaymentSearchBy searchBy, long searchByValue)
        {
            ISession session = null;
            IList<PropertyExpenseDTO> result = new List<PropertyExpenseDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                PropertyExpense pExp = null;
                Agency a = null;
                Property p = null;
                FirmAccount fa = null;
                PaymentMaster pm = null;
                MasterControlData exptype = null;

                PropertyExpenseDTO expdt = null;

                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => pExp.Id).WithAlias(() => expdt.Id))
                            .Add(Projections.Property(() => a.Id), "Agency.Id")
                            .Add(Projections.Property(() => a.AgencyName), "Agency.AgencyName")
                            .Add(Projections.Property(() => exptype.Id), "ExpenseType.Id")
                            .Add(Projections.Property(() => exptype.Name), "ExpenseType.Name")
                            .Add(Projections.Property(() => pExp.ExpenseDate).WithAlias(() => expdt.ExpenseDate))
                            .Add(Projections.Property(() => pm.Id), "PaymentMaster.Id")
                            .Add(Projections.Property(() => pm.TotalAmt), "PaymentMaster.TotalAmt")
                            .Add(Projections.Property(() => pm.TotalPaid), "PaymentMaster.TotalPaid")
                            .Add(Projections.Property(() => pm.TotalPending), "PaymentMaster.TotalPending")
                            .Add(Projections.Property(() => pm.Status), "PaymentMaster.Status")
                            .Add(Projections.Property(() => fa.Id), "Property.FirmAccount.Id");
                var query = session.QueryOver<PropertyExpense>(() => pExp)
                    .Inner.JoinAlias(() => pExp.Agency, () => a)
                    .Inner.JoinAlias(() => pExp.PaymentMaster, () => pm)
                    .Inner.JoinAlias(() => pExp.Property, () => p)
                    .Left.JoinAlias(() => pExp.ExpenseType, () => exptype)
                    .Left.JoinAlias(() => pExp.Property.FirmAccount, () => fa);
                if (PaymentSearchBy.NONE != searchBy && searchByValue != -1)
                {
                    PropertyProjection prop = null;
                    if (PaymentSearchBy.AGENCY == searchBy)
                    {
                        prop = CommonUtil.BuildProjection<Agency>(() => a, x => x.Id);
                    }
                    else if (PaymentSearchBy.EXPENSE_TYPE == searchBy)
                    {
                        prop = CommonUtil.BuildProjection<MasterControlData>(() => exptype, x => x.Id);
                    }
                    query.Where(Restrictions.Eq(prop, searchByValue));
                }
                result = query.Where(() => p.FirmNumber == firmNumber && p.Id == propertyId)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<PropertyExpenseDTO>()).List<PropertyExpenseDTO>();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error fetching data for Firm to Expense Payment search grid:");
                log.Error(exp.Message, exp);
                throw exp;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public PaymentMasterDTO fetchPaymentMaster(long Id)
        {
            ISession session = null;
            PaymentMasterDTO paymentMasterDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PaymentMaster paymentMaster = session.Get<PaymentMaster>(Id);
                        paymentMasterDto = DomainToDTOUtil.convertToPaymentMasterDTO(paymentMaster, true, true);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Payment Masters details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return paymentMasterDto;
        }
        public void addPymtTransaction(PaymentTransactionDTO pymtTransDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PaymentMaster pymtMaster = session.Get<PaymentMaster>(pymtTransDto.PaymentMaster.Id);
                        DTOToDomainUtil.populatePaymentMasterUpdateFields(pymtMaster, pymtTransDto.PaymentMaster);
                        PaymentTransaction pymtTransaction = DTOToDomainUtil.populatePaymentTransactionAddFields(pymtTransDto);
                        pymtMaster.PaymentTransactions.Add(pymtTransaction);
                        if (pymtTransDto.Status == PymtTransStatus.Reversal)
                        {
                            PaymentTransaction orgPymtTransaction = pymtMaster.PaymentTransactions.ToList<PaymentTransaction>()
                                .Find(p => p.Id == pymtTransDto.CancelledPaymentTransaction.Id);
                            orgPymtTransaction.Status = PymtTransStatus.Deleted;
                            orgPymtTransaction.UpdateUser = pymtTransDto.UpdateUser;
                            orgPymtTransaction.UpdateDate = DateTime.Now;
                        }
                        pymtTransaction.PaymentMaster = pymtMaster;
                        session.Update(pymtMaster);
                        FirmAccount firmAccount = session.Get<FirmAccount>(pymtTransDto.AccountTransaction.FirmAccount.Id);
                        firmAccount.AccountBalance = (pymtTransDto.AccountTransaction.TxType == AcntTransStatus.Credit)
                                    ? Decimal.Add(firmAccount.AccountBalance, pymtTransDto.Amount) : Decimal.Subtract(firmAccount.AccountBalance, pymtTransDto.Amount);
                        session.Update(firmAccount);
                        session.Flush();
                        //REF# in comment is updated with payment transaction no which is inserted above
                        AccountTransaction acntTrans = pymtTransaction.AccountTransaction;
                        acntTrans.Comments = string.Format(acntTrans.Comments, pymtTransaction.Id);
                        session.Update(acntTrans);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Adding payment transaction:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public PostDatedChequeDTO fetchPostDatedChequeDetails(long Id)
        {
            ISession session = null;
            PostDatedChequeDTO pdcDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PostDatedCheque pdc = session.Get<PostDatedCheque>(Id);
                        pdcDto = DomainToDTOUtil.convertToPDCDTO(pdc, true);
                        
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Post Dated Cheque details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return pdcDto;
        }
        public List<PdcBookDTO> getPdcBookDTO(string pymtDirection, long fromId, long toId)
        {
            ISession session = null;
            List<PdcBookDTO> pdcBookDtos = new List<PdcBookDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        if ("CUSTOMER_FIRM".Equals(pymtDirection))
                        {
                            Customer customer = session.Get<Customer>(fromId);
                            Firm firm = session.Get<Firm>(toId);
                            pdcBookDtos.Add(new PdcBookDTO());
                            pdcBookDtos.Add(new PdcBookDTO());
                            pdcBookDtos[0].Id = customer.PdcOutBook.Id;
                            pdcBookDtos[1].Id = firm.PdcInBook.Id;
                        }
                        else if ("FIRM_CUSTOMER".Equals(pymtDirection))
                        {
                            Firm firm = session.Get<Firm>(fromId);
                            Customer customer = session.Get<Customer>(toId);
                            pdcBookDtos.Add(new PdcBookDTO());
                            pdcBookDtos.Add(new PdcBookDTO());
                            pdcBookDtos[0].Id = firm.PdcOutBook.Id;
                            pdcBookDtos[1].Id = customer.PdcInBook.Id;
                        }
                        else if ("FIRM_CONTRACTOR".Equals(pymtDirection))
                        {
                        }
                        else if ("FIRM_SUPPLIER".Equals(pymtDirection))
                        {
                        }
                        else if ("FIRM_AGENCY".Equals(pymtDirection))
                        {
                            Firm firm = session.Get<Firm>(fromId);
                            Agency agency = session.Get<Agency>(toId);
                            pdcBookDtos.Add(new PdcBookDTO());
                            pdcBookDtos.Add(new PdcBookDTO());
                            pdcBookDtos[0].Id = firm.PdcOutBook.Id;
                            pdcBookDtos[1].Id = agency.PdcInBook.Id;
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching PdcBook for given payment direction:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return pdcBookDtos;
        }
        public IList<PostDatedChequeSearchDTO> fetchPdcFromCustomerToFirm(string firmNumber, long prTowerId, PdcSearchBy searchBy, string searchByValue)
        {
            ISession session = null;
            IList<PostDatedChequeSearchDTO> result = new List<PostDatedChequeSearchDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PostDatedChequeSearchDTO pdcDto = null;

                        PostDatedCheque pdc = null;
                        PdcBook pdcFrom = null;
                        PdcBook pdcTo = null;
                        PropertyTower pt = null;
                        Customer c = null;
                        Firm f = null;

                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => pdc.Id).WithAlias(() => pdcDto.Id))
                                    .Add(Projections.Property(() => c.Id).WithAlias(() => pdcDto.ChqDrawerId))
                                    .Add(Projections.SqlFunction("concat",
                                        NHibernateUtil.String,
                                        Projections.Property(() => c.FirstName),
                                        Projections.Constant(" "),
                                        Projections.Property(() => c.LastName)).WithAlias(() => pdcDto.ChqDrawerName))
                                    .Add(Projections.Property(() => f.Id).WithAlias(() => pdcDto.ChqPayeeId))
                                    .Add(Projections.Property(() => f.Name).WithAlias(() => pdcDto.ChqPayeeName))
                                    .Add(Projections.Property(() => pdc.ChequeNo).WithAlias(() => pdcDto.ChequeNo))
                                    .Add(Projections.Property(() => pdc.ChequeDate).WithAlias(() => pdcDto.ChequeDate))
                                    .Add(Projections.Property(() => pdc.BankName).WithAlias(() => pdcDto.BankName))
                                    .Add(Projections.Property(() => pdc.PymtAmt).WithAlias(() => pdcDto.PymtAmt))
                                    .Add(Projections.Property(() => pdc.ChequeStatus).WithAlias(() => pdcDto.ChequeStatus))
                                    .Add(Projections.Property(() => pdc.PymtStatus).WithAlias(() => pdcDto.PymtStatus));
                        var query = session.QueryOver<PostDatedCheque>(() => pdc)
                            .Inner.JoinAlias(() => pdc.PdcFrom, () => pdcFrom)
                            .Inner.JoinAlias(() => pdc.PdcTo, () => pdcTo)
                            .Inner.JoinAlias(() => pdc.PdcFrom.CustomerOut, () => c)
                            .Inner.JoinAlias(() => pdc.PdcTo.FirmIn, () => f)
                            .Left.JoinAlias(() => pdc.PrTower, () => pt);
                        if (PdcSearchBy.NONE != searchBy && !string.IsNullOrWhiteSpace(searchByValue))
                        {
                            PropertyProjection prop = null;
                            if (PdcSearchBy.CHQ_DRAWER == searchBy)
                            {
                                prop = CommonUtil.BuildProjection<Customer>(() => c, x => x.Id);
                                query.Where(Restrictions.Eq(prop, searchByValue));
                            } 
                            else if (PdcSearchBy.CHQ_PAYEE == searchBy)
                            {
                                prop = CommonUtil.BuildProjection<Firm>(() => f, x => x.Id);
                                query.Where(Restrictions.Eq(prop, searchByValue));
                            }
                            else if (PdcSearchBy.CHQ_NO == searchBy)
                            {
                                prop = CommonUtil.BuildProjection<PostDatedCheque>(() => pdc, x => x.ChequeNo);
                                query.Where(Restrictions.Eq(prop, searchByValue));
                            }
                            else if (PdcSearchBy.CHQ_STATUS == searchBy)
                            {
                                prop = CommonUtil.BuildProjection<PostDatedCheque>(() => pdc, x => x.ChequeStatus);
                                PdcChequeStatus status = EnumHelper.ToEnum<PdcChequeStatus>(searchByValue);
                                query.Where(Restrictions.Eq(prop, status));
                            }
                        }
                        result = query.Where(() => pdc.FirmNumber == firmNumber && pt.Id == prTowerId)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<PostDatedChequeSearchDTO>()).List<PostDatedChequeSearchDTO>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading PDC search result for Customer to Firm Payment:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public IList<PostDatedChequeSearchDTO> fetchPdcFromFirmToCustomer(string firmNumber, long prTowerId, PdcSearchBy searchBy, string searchByValue)
        {
            ISession session = null;
            IList<PostDatedChequeSearchDTO> result = new List<PostDatedChequeSearchDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PostDatedChequeSearchDTO pdcDto = null;

                        PostDatedCheque pdc = null;
                        PdcBook pdcFrom = null;
                        PdcBook pdcTo = null;
                        PropertyTower pt = null;
                        Customer c = null;
                        Firm f = null;

                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => pdc.Id).WithAlias(() => pdcDto.Id))
                                    .Add(Projections.Property(() => c.Id).WithAlias(() => pdcDto.ChqPayeeId))
                                    .Add(Projections.SqlFunction("concat",
                                        NHibernateUtil.String,
                                        Projections.Property(() => c.FirstName),
                                        Projections.Constant(" "),
                                        Projections.Property(() => c.LastName)).WithAlias(() => pdcDto.ChqPayeeName))
                                    .Add(Projections.Property(() => f.Id).WithAlias(() => pdcDto.ChqDrawerId))
                                    .Add(Projections.Property(() => f.Name).WithAlias(() => pdcDto.ChqDrawerName))
                                    .Add(Projections.Property(() => pdc.ChequeNo).WithAlias(() => pdcDto.ChequeNo))
                                    .Add(Projections.Property(() => pdc.ChequeDate).WithAlias(() => pdcDto.ChequeDate))
                                    .Add(Projections.Property(() => pdc.BankName).WithAlias(() => pdcDto.BankName))
                                    .Add(Projections.Property(() => pdc.PymtAmt).WithAlias(() => pdcDto.PymtAmt))
                                    .Add(Projections.Property(() => pdc.ChequeStatus).WithAlias(() => pdcDto.ChequeStatus))
                                    .Add(Projections.Property(() => pdc.PymtStatus).WithAlias(() => pdcDto.PymtStatus));
                        var query = session.QueryOver<PostDatedCheque>(() => pdc)
                            .Inner.JoinAlias(() => pdc.PdcFrom, () => pdcFrom)
                            .Inner.JoinAlias(() => pdc.PdcTo, () => pdcTo)
                            .Inner.JoinAlias(() => pdc.PdcFrom.FirmOut, () => f)
                            .Inner.JoinAlias(() => pdc.PdcTo.CustomerIn, () => c)
                            .Left.JoinAlias(() => pdc.PrTower, () => pt);
                        if (PdcSearchBy.NONE != searchBy && !string.IsNullOrWhiteSpace(searchByValue))
                        {
                            PropertyProjection prop = null;
                            if (PdcSearchBy.CHQ_DRAWER == searchBy)
                            {
                                prop = CommonUtil.BuildProjection<Firm>(() => f, x => x.Id);
                                query.Where(Restrictions.Eq(prop, searchByValue));
                            }
                            else if (PdcSearchBy.CHQ_PAYEE == searchBy)
                            {
                                prop = CommonUtil.BuildProjection<Customer>(() => c, x => x.Id);
                                query.Where(Restrictions.Eq(prop, searchByValue));
                            }
                            else if (PdcSearchBy.CHQ_NO == searchBy)
                            {
                                prop = CommonUtil.BuildProjection<PostDatedCheque>(() => pdc, x => x.ChequeNo);
                                query.Where(Restrictions.Eq(prop, searchByValue));
                            }
                            else if (PdcSearchBy.CHQ_STATUS == searchBy)
                            {
                                prop = CommonUtil.BuildProjection<PostDatedCheque>(() => pdc, x => x.ChequeStatus);
                                PdcChequeStatus status = EnumHelper.ToEnum<PdcChequeStatus>(searchByValue);
                                query.Where(Restrictions.Eq(prop, status));
                            }
                        }
                        result = query.Where(() => pdc.FirmNumber == firmNumber && pt.Id == prTowerId)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<PostDatedChequeSearchDTO>()).List<PostDatedChequeSearchDTO>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading PDC search result for Firm to Customer Payment:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public IList<PostDatedChequeSearchDTO> fetchPdcFromFirmToAgency(string firmNumber, long propertyId, PdcSearchBy searchBy, string searchByValue)
        {
            ISession session = null;
            IList<PostDatedChequeSearchDTO> result = new List<PostDatedChequeSearchDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PostDatedChequeSearchDTO pdcDto = null;

                        PostDatedCheque pdc = null;
                        PdcBook pdcFrom = null;
                        PdcBook pdcTo = null;
                        Property p = null;
                        Agency a = null;
                        Firm f = null;

                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => pdc.Id).WithAlias(() => pdcDto.Id))
                                    .Add(Projections.Property(() => a.Id).WithAlias(() => pdcDto.ChqPayeeId))
                                    .Add(Projections.Property(() => a.AgencyName).WithAlias(() => pdcDto.ChqPayeeName))
                                    .Add(Projections.Property(() => f.Id).WithAlias(() => pdcDto.ChqDrawerId))
                                    .Add(Projections.Property(() => f.Name).WithAlias(() => pdcDto.ChqDrawerName))
                                    .Add(Projections.Property(() => pdc.ChequeNo).WithAlias(() => pdcDto.ChequeNo))
                                    .Add(Projections.Property(() => pdc.ChequeDate).WithAlias(() => pdcDto.ChequeDate))
                                    .Add(Projections.Property(() => pdc.BankName).WithAlias(() => pdcDto.BankName))
                                    .Add(Projections.Property(() => pdc.PymtAmt).WithAlias(() => pdcDto.PymtAmt))
                                    .Add(Projections.Property(() => pdc.ChequeStatus).WithAlias(() => pdcDto.ChequeStatus))
                                    .Add(Projections.Property(() => pdc.PymtStatus).WithAlias(() => pdcDto.PymtStatus));
                        var query = session.QueryOver<PostDatedCheque>(() => pdc)
                            .Inner.JoinAlias(() => pdc.PdcFrom, () => pdcFrom)
                            .Inner.JoinAlias(() => pdc.PdcTo, () => pdcTo)
                            .Inner.JoinAlias(() => pdc.PdcFrom.FirmOut, () => f)
                            .Inner.JoinAlias(() => pdc.PdcTo.AgencyIn, () => a)
                            .Left.JoinAlias(() => pdc.Property, () => p);
                        if (PdcSearchBy.NONE != searchBy && !string.IsNullOrWhiteSpace(searchByValue))
                        {
                            PropertyProjection prop = null;
                            if (PdcSearchBy.CHQ_DRAWER == searchBy)
                            {
                                prop = CommonUtil.BuildProjection<Firm>(() => f, x => x.Id);
                                query.Where(Restrictions.Eq(prop, searchByValue));
                            }
                            else if (PdcSearchBy.CHQ_PAYEE == searchBy)
                            {
                                prop = CommonUtil.BuildProjection<Customer>(() => a, x => x.Id);
                                query.Where(Restrictions.Eq(prop, searchByValue));
                            }
                            else if (PdcSearchBy.CHQ_NO == searchBy)
                            {
                                prop = CommonUtil.BuildProjection<PostDatedCheque>(() => pdc, x => x.ChequeNo);
                                query.Where(Restrictions.Eq(prop, searchByValue));
                            }
                            else if (PdcSearchBy.CHQ_STATUS == searchBy)
                            {
                                prop = CommonUtil.BuildProjection<PostDatedCheque>(() => pdc, x => x.ChequeStatus);
                                PdcChequeStatus status = EnumHelper.ToEnum<PdcChequeStatus>(searchByValue);
                                query.Where(Restrictions.Eq(prop, status));
                            }
                        }
                        result = query.Where(() => pdc.FirmNumber == firmNumber && p.Id == propertyId)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<PostDatedChequeSearchDTO>()).List<PostDatedChequeSearchDTO>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading PDC search result for Firm to Agency Payment:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public IList<PdcPymtDTO> fetchPdcPymtFromCustomerToFromFirm(string firmNumber, long towerId, long customerId, PRUnitSalePymtTo pymtTo)
        {
            ISession session = null;
            IList<PdcPymtDTO> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PrUnitSalePymt pusp = null;
                        PropertyUnit pu = null;
                        PrUnitSaleDetail pus = null;
                        Customer c = null;
                        PropertyTower pt = null;
                        PaymentMaster pm = null;
                        MasterControlData pusptype = null;

                        PdcPymtDTO pdcPymtDto = null;
                        
                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => pm.Id).WithAlias(() => pdcPymtDto.PymtMasterId))
                                    .Add(Projections.Property(() => pm.TotalAmt).WithAlias(() => pdcPymtDto.TotalPymtAmt))
                                    .Add(Projections.Property(() => pm.TotalPaid).WithAlias(() => pdcPymtDto.TotalPaidAmt))
                                    .Add(Projections.Property(() => pm.TotalPending).WithAlias(() => pdcPymtDto.TotalPendingAmt))
                                    .Add(Projections.Property(() => pm.Status).WithAlias(() => pdcPymtDto.PymtMstStatus))
                                    .Add(Projections.Property(() => pm.Version).WithAlias(() => pdcPymtDto.PymtMasterVersion))
                                    .Add(Projections.Property(() => pu.Wing).WithAlias(() => pdcPymtDto.Wing))
                                    .Add(Projections.Property(() => pu.UnitNo).WithAlias(() => pdcPymtDto.UnitNo))
                                    .Add(Projections.Property(() => pusptype.Name), "PymtType.Name");
                        var query = session.QueryOver<PrUnitSalePymt>(() => pusp)
                            .Inner.JoinAlias(() => pusp.PaymentMaster, () => pm)
                            .Left.JoinAlias(() => pusp.PymtType, () => pusptype)
                            .Left.JoinAlias(() => pusp.PrUnitSaleDetail, () => pus)
                            .Left.JoinAlias(() => pusp.PrUnitSaleDetail.PropertyUnit, () => pu)
                            .Left.JoinAlias(() => pusp.PrUnitSaleDetail.PropertyUnit.PropertyTower, () => pt)
                            .Left.JoinAlias(() => pusp.PrUnitSaleDetail.Customer, () => c);
                        result = query.Where(() => pusp.FirmNumber == firmNumber && pt.Id == towerId
                            && c.Id == customerId && pusp.PymtTo == pymtTo)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<PdcPymtDTO>()).List<PdcPymtDTO>();                        
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Sales Payments for Customer:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public IList<PdcPymtDTO> fetchPdcPymtFromFirmToAgency(string firmNumber, long propertyId, long agencyId)
        {
            ISession session = null;
            IList<PdcPymtDTO> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyExpense pe = null;
                        Agency a = null;
                        MasterControlData exptype = null;
                        Property p = null;
                        PaymentMaster pm = null;                        

                        PdcPymtDTO pdcPymtDto = null;

                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => pe.ExpenseDate).WithAlias(() => pdcPymtDto.ExpenseDate))
                                    .Add(Projections.Property(() => pm.Id).WithAlias(() => pdcPymtDto.PymtMasterId))
                                    .Add(Projections.Property(() => pm.TotalAmt).WithAlias(() => pdcPymtDto.TotalPymtAmt))
                                    .Add(Projections.Property(() => pm.TotalPaid).WithAlias(() => pdcPymtDto.TotalPaidAmt))
                                    .Add(Projections.Property(() => pm.TotalPending).WithAlias(() => pdcPymtDto.TotalPendingAmt))
                                    .Add(Projections.Property(() => pm.Status).WithAlias(() => pdcPymtDto.PymtMstStatus))
                                    .Add(Projections.Property(() => pm.Version).WithAlias(() => pdcPymtDto.PymtMasterVersion))
                                    .Add(Projections.Property(() => a.AgencyName).WithAlias(() => pdcPymtDto.PymtFor))
                                    .Add(Projections.Property(() => exptype.Id), "PymtType.Id")
                                    .Add(Projections.Property(() => exptype.Name), "PymtType.Name");
                        var query = session.QueryOver<PropertyExpense>(() => pe)
                            .Inner.JoinAlias(() => pe.Agency, () => a)
                            .Inner.JoinAlias(() => pe.PaymentMaster, () => pm)
                            .Left.JoinAlias(() => pe.ExpenseType, () => exptype)
                            .Left.JoinAlias(() => pe.Property, () => p);
                        result = query.Where(() => pe.FirmNumber == firmNumber && p.Id == propertyId && a.Id == agencyId)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<PdcPymtDTO>()).List<PdcPymtDTO>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Sales Payments for Agency:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public long addPostDatedChequeDetails(PostDatedChequeDTO pdcDto)
        {
            ISession session = null;
            long id = 0;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PostDatedCheque pdc = DTOToDomainUtil.populatePostDatedChequeAddFields(pdcDto);
                        FirmAccount firmAccount = null;
                        foreach (PaymentTransaction pymtTras in pdc.PaymentTransactions)
                        {
                            PaymentMaster pMaster = session.Get<PaymentMaster>(pymtTras.PaymentMaster.Id);
                            if (PymtTransStatus.Pending == pymtTras.Status) pMaster.TotalPdcAmt = Decimal.Add(pMaster.TotalPdcAmt, pymtTras.Amount);
                            if (PymtTransStatus.Paid == pymtTras.Status)
                            {
                                if (firmAccount == null) firmAccount = session.Get<FirmAccount>(pdcDto.FirmAccount.Id);
                                pMaster.TotalPaid = Decimal.Add(pMaster.TotalPaid, pymtTras.Amount);
                                pMaster.TotalPending = Decimal.Subtract(pMaster.TotalAmt, pMaster.TotalPaid);
                                if (pMaster.TotalPending <= 0)
                                {
                                    pMaster.TotalPending = Decimal.Zero;
                                    pMaster.Status = PymtMasterStatus.Paid;
                                }
                                else
                                {
                                    pMaster.Status = PymtMasterStatus.Pending;
                                }
                                pMaster.UpdateUser = pdcDto.UpdateUser;
                                pMaster.UpdateDate = DateTime.Now;
                                firmAccount.AccountBalance = (pymtTras.AccountTransaction.TxType == AcntTransStatus.Credit) 
                                    ? Decimal.Add(firmAccount.AccountBalance, pymtTras.Amount) : Decimal.Subtract(firmAccount.AccountBalance, pymtTras.Amount);
                                firmAccount.UpdateUser = pdcDto.UpdateUser;
                                firmAccount.UpdateDate = DateTime.Now;
                            }
                            session.Update(pMaster);
                        }
                        if (firmAccount != null) session.Update(firmAccount);
                        session.Save(pdc);
                        session.Flush();
                        //REF# in comment is updated with payment transaction no which is inserted above
                        foreach (PaymentTransaction pymtTras in pdc.PaymentTransactions)
                        {
                            AccountTransaction acntTrans = pymtTras.AccountTransaction;
                            if (acntTrans != null)
                            {
                                acntTrans.Comments = string.Format(acntTrans.Comments, pymtTras.Id);
                                session.Update(acntTrans);
                            }
                        }
                        tx.Commit();
                        id = pdc.Id;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while adding Post Dated Cheque details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return id;
        }
        public void updatePostDatedChequeDetails(PostDatedChequeDTO pdcDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PostDatedCheque pdc = session.Get<PostDatedCheque>(pdcDto.Id);
                        FirmAccount firmAccount = session.Get<FirmAccount>(pdcDto.FirmAccount.Id);
                        //Reduce all payment transaction amounts from Payment master and account
                        List<PaymentMaster> paymentMasterList = new List<PaymentMaster>();
                        foreach (PaymentTransaction pymtTras in pdc.PaymentTransactions)
                        {
                            PaymentMaster pMaster = pymtTras.PaymentMaster;
                            if (PymtTransStatus.Pending == pymtTras.Status) pMaster.TotalPdcAmt = Decimal.Subtract(pMaster.TotalPdcAmt, pymtTras.Amount);
                            if (PymtTransStatus.Paid == pymtTras.Status) {
                                pMaster.TotalPaid = Decimal.Subtract(pMaster.TotalPaid, pymtTras.Amount);
                                pMaster.TotalPending = Decimal.Subtract(pMaster.TotalAmt, pMaster.TotalPaid);
                                if (pMaster.TotalPending <= 0)
                                {
                                    pMaster.TotalPending = Decimal.Zero;
                                    pMaster.Status = PymtMasterStatus.Paid;
                                }
                                else
                                {
                                    pMaster.Status = PymtMasterStatus.Pending;
                                }
                                pMaster.UpdateUser = pdcDto.UpdateUser;
                                pMaster.UpdateDate = DateTime.Now;
                                firmAccount.AccountBalance = (pymtTras.AccountTransaction.TxType == AcntTransStatus.Credit)
                                    ? Decimal.Subtract(firmAccount.AccountBalance, pymtTras.Amount) : Decimal.Add(firmAccount.AccountBalance, pymtTras.Amount);
                                firmAccount.UpdateUser = pdcDto.UpdateUser;
                                firmAccount.UpdateDate = DateTime.Now;
                            }
                            paymentMasterList.Add(pMaster);                            
                        }
                        DTOToDomainUtil.populatePostDatedChequeUpdateFields(pdc, pdcDto);
                        foreach (PaymentTransaction pymtTras in pdc.PaymentTransactions)
                        {
                            PaymentMaster pMaster = paymentMasterList.Find(x => x.Id == pymtTras.PaymentMaster.Id);
                            if (pMaster == null) {
                                pMaster = session.Get<PaymentMaster>(pymtTras.PaymentMaster.Id);
                                paymentMasterList.Add(pMaster);
                            }
                            if (PymtTransStatus.Pending == pymtTras.Status) pMaster.TotalPdcAmt = Decimal.Add(pMaster.TotalPdcAmt, pymtTras.Amount);
                            if (PymtTransStatus.Paid == pymtTras.Status)
                            {
                                pMaster.TotalPaid = Decimal.Add(pMaster.TotalPaid, pymtTras.Amount);
                                pMaster.TotalPending = Decimal.Subtract(pMaster.TotalAmt, pMaster.TotalPaid);
                                if (pMaster.TotalPending <= 0)
                                {
                                    pMaster.TotalPending = Decimal.Zero;
                                    pMaster.Status = PymtMasterStatus.Paid;
                                }
                                else
                                {
                                    pMaster.Status = PymtMasterStatus.Pending;
                                }
                                pMaster.UpdateUser = pdcDto.UpdateUser;
                                pMaster.UpdateDate = DateTime.Now;
                                firmAccount.AccountBalance = (pymtTras.AccountTransaction.TxType == AcntTransStatus.Credit)
                                    ? Decimal.Add(firmAccount.AccountBalance, pymtTras.Amount) : Decimal.Subtract(firmAccount.AccountBalance, pymtTras.Amount);
                                firmAccount.UpdateUser = pdcDto.UpdateUser;
                                firmAccount.UpdateDate = DateTime.Now;
                            }
                        }
                        foreach(PaymentMaster pMaster in paymentMasterList) {
                            session.Update(pMaster);
                        }
                        session.Update(firmAccount);
                        session.Update(pdc);
                        session.Flush();
                        //REF# in comment is updated with payment transaction no which is inserted above
                        foreach (PaymentTransaction pymtTras in pdc.PaymentTransactions)
                        {
                            AccountTransaction acntTrans = pymtTras.AccountTransaction;
                            if (acntTrans != null)
                            {
                                acntTrans.Comments = string.Format(acntTrans.Comments, pymtTras.Id);
                                session.Update(acntTrans);
                            }
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating Post Dated Cheque details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void deleteUnpaidPdcDetails(long Id, string userName)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PostDatedCheque pdc = session.Get<PostDatedCheque>(Id);
                        foreach (PaymentTransaction pymtTras in pdc.PaymentTransactions)
                        {
                            PaymentMaster pMaster = session.Get<PaymentMaster>(pymtTras.PaymentMaster.Id);
                            if (PymtTransStatus.Pending == pymtTras.Status) {
                                pMaster.TotalPdcAmt = Decimal.Subtract(pMaster.TotalPdcAmt, pymtTras.Amount);
                                pMaster.UpdateUser = userName;
                                pMaster.UpdateDate = DateTime.Now;
                                session.Update(pMaster);
                            }
                        }
                        session.Delete(pdc);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Deleting Post Dated Cheque details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
    }
}