﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
	initPaymentTxHistoryGrid();
	initPdcHistoryGrid();
    formatFields();
    showModal();
}
function initPaymentTxHistoryGrid() {
    var dtOptions = {
        tableId: "txHistoryGrid",
        pageLength: 5,
        responsiveModalTitle: "Payment Transaction Details",
        isViewOnly: false,
        sortColumn: 3,
        sortOrder: "desc",
        hideSearch: true
    };
    var dtTable = applyActionDataTable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitUploadHdnId");
}
function initPdcHistoryGrid() {
    var dtOptions = {
        tableId: "pdcGrid",
        pageLength: 5,
        responsiveModalTitle: "Cheque Details",
        isViewOnly: false,
        sortColumn: 2,
        sortOrder: "desc",
        hideSearch: true
    };
    var dtTable = applyActionDataTable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitUploadHdnId");
}