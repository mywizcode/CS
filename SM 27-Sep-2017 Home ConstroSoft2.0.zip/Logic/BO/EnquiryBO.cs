﻿using System;
using NHibernate;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using ConstroSoft;
using System.Collections.Generic;
using NHibernate.Criterion;
using NHibernate.Transform;
using System.Net.Mail;
using System.Net.Mime;

/// <summary>
/// Summary description for SupplierBO
/// </summary>
namespace ConstroSoft
{
    public class EnquiryBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public EnquiryBO() { }

        public IList<EnquiryDetailDTO> fetchEnquiryGridData(string firmNumber, long propertyId, long userId, EnquiryFilterDTO filterDTO)
        {
            ISession session = null;
            IList<EnquiryDetailDTO> results = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                EnquiryDetail ed = null;
                ContactInfo c = null;
                EnquiryDetailDTO enDto = null;
                MasterControlData dge = null;
                MasterControlData salutation = null;
                LeadDetail ld = null;
                FirmMember fm = null;

                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => ed.Id).WithAlias(() => enDto.Id))
                            .Add(Projections.Property(() => ed.FirstName).WithAlias(() => enDto.FirstName))
                            .Add(Projections.Property(() => ed.LastName).WithAlias(() => enDto.LastName))
                            .Add(Projections.Property(() => ed.EnquiryRefNo).WithAlias(() => enDto.EnquiryRefNo))
                            .Add(Projections.Property(() => ed.Status).WithAlias(() => enDto.Status))
                            .Add(Projections.Property(() => c.Contact), "ContactInfo.Contact")
                             .Add(Projections.Property(() => c.Contact), "ContactInfo.AltContact")
                            .Add(Projections.Property(() => c.Email), "ContactInfo.Email")
                            .Add(Projections.Property(() => dge.Name), "EnquirySource.Name")
                            .Add(Projections.Property(() => salutation.Name), "Salutation.Name")
                            .Add(Projections.Property(() => ld.LeadRefNo), "Lead.LeadRefNo");
                var query = session.QueryOver<EnquiryDetail>(() => ed)
                    .Inner.JoinAlias(() => ed.ContactInfo, () => c)
                    .Left.JoinAlias(() => ed.EnquirySource, () => dge)
                    .Left.JoinAlias(() => ed.Salutation, () => salutation)
                    .Left.JoinAlias(() => ed.Assignee, () => fm)
                    .Left.JoinAlias(() => ed.Lead, () => ld);
                if (filterDTO != null)
                {
                    ICriteria criteria = query.RootCriteria;
                    if (!string.IsNullOrWhiteSpace(filterDTO.FirstName))
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<EnquiryDetail>(() => ed, x => x.FirstName), filterDTO.FirstName));
                    }
                    if (!string.IsNullOrWhiteSpace(filterDTO.LastName))
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<EnquiryDetail>(() => ed, x => x.LastName), filterDTO.LastName));
                    }
                    if (!string.IsNullOrWhiteSpace(filterDTO.EnquiryRef))
                    {
                        criteria.Add(Restrictions.InsensitiveLike(CommonUtil.BuildProjection<EnquiryDetail>(() => ed, x => x.EnquiryRefNo), filterDTO.EnquiryRef, MatchMode.Start));
                    }
                    if (!string.IsNullOrWhiteSpace(filterDTO.ContactNo))
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<ContactInfo>(() => c, x => x.Contact), filterDTO.ContactNo));
                    }
                    if (filterDTO.EnquirySource != null)
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<MasterControlData>(() => dge, x => x.Id), filterDTO.EnquirySource.Id));
                    }
                    if (filterDTO.Status != null)
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<EnquiryDetail>(() => ed, x => x.Status), filterDTO.Status));
                    }
                }
                results = query.Where(() => ed.FirmNumber == firmNumber && ed.Property.Id == propertyId && ed.Assignee.Id == userId)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<EnquiryDetailDTO>()).List<EnquiryDetailDTO>();
                foreach (EnquiryDetailDTO enquiryDetailDTO in results)
                {
                    enquiryDetailDTO.FullName = CommonUIConverter.getCustomerFullName(enquiryDetailDTO.Salutation.Name, CommonUIConverter.getCustomerFullName(enquiryDetailDTO.FirstName,
                        enquiryDetailDTO.LastName));
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating enquiry grid:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }


        public EnquiryDetailDTO fetchEnquiryDetails(long Id, bool fetchFollowups)
        {
            ISession session = null;
            EnquiryDetailDTO enquiryDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EnquiryDetail enquiry = session.Get<EnquiryDetail>(Id);
                        enquiryDto = DomainToDTOUtil.convertToEnquiryDetailDTO(enquiry, fetchFollowups);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Enquiry details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return enquiryDto;
        }
        public long addEnquiryDetails(EnquiryDetailDTO enquiryDto)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                EnquiryDetail enquiry = null;
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        enquiry = DTOToDomainUtil.populateEnquiryDetailAddFields(enquiryDto);
                        Random rd = new Random();
                        enquiry.EnquiryRefNo = CommonUtil.getRandomRefNo();
                        session.Save(enquiry);
                        Id = enquiry.Id;
                        enquiry.EnquiryRefNo = CommonUtil.getEnquiryRefNo(Id);
                        session.Update(enquiry);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Enquiry details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
                sendSMSEmail(enquiry);
             }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        /**
         * This method will check Email & SMS configuration for Enquiry Function. 
         * If Email & SMS alerts are enabled then system will send Email & SMS to Customer.
         * */
        private static void sendSMSEmail(EnquiryDetail enquiry)
        {
            try
            {
                PropertyAlertConfig emailSmsAlertConfig = EmailUtil.loadEmailSmsAlertConfiguration(enquiry.FirmNumber,
                    FunctionName.ENQUIRY.ToString(), EmailSmsType.ENQUIRYTHANKS.ToString(), enquiry.Property.Id);
                PropertyBO propertyBO = new PropertyBO();
                PropertyDTO propertyDTO = propertyBO.fetchProperty(enquiry.Property.Id);
                if (emailSmsAlertConfig != null && emailSmsAlertConfig.Email.Equals(Constants.YES))
                {
                    emailSmsAlertConfig.EmailBody = populateBody(enquiry, emailSmsAlertConfig, propertyDTO.Name);
                    EmailUtil.sendHtmlFormattedEmail(enquiry.FirmNumber, emailSmsAlertConfig, enquiry.ContactInfo.Email);
                }
                if (emailSmsAlertConfig != null && emailSmsAlertConfig.Sms.Equals(Constants.YES))
                {
                    emailSmsAlertConfig.SmsContent = populateSMSBody(enquiry, emailSmsAlertConfig, propertyDTO.Name);
                    EmailUtil.sendSMS(enquiry.FirmNumber, emailSmsAlertConfig, enquiry.ContactInfo.Contact);
                }
            }
            catch (Exception e)
            {
                log.Error("Exception while sending Email & SMS alert for enquiry:", e);
            }
        }
        private static string populateBody(EnquiryDetail enquiry, PropertyAlertConfig emailSmsAlertConfig, string propertyName)
        {
            string body = string.Empty;
            using (StreamReader reader = new StreamReader(System.Web.HttpContext.Current.Server.MapPath(emailSmsAlertConfig.EmailTemplatePath)))
            {
                body = reader.ReadToEnd();
            }
            body = body.Replace("{UserName}", enquiry.Salutation.Name + " " + enquiry.FirstName + " " + enquiry.LastName);
            body = body.Replace("{PropertyName}", propertyName);
            return body;
        }
        private static string populateSMSBody(EnquiryDetail enquiry, PropertyAlertConfig emailSmsAlertConfig, string propertyName)
        {
            string body = string.Empty;
            body = emailSmsAlertConfig.SmsContent.Replace("{UserName}", enquiry.Salutation.Name + " " +enquiry.FirstName + " " + enquiry.LastName);
            body = emailSmsAlertConfig.SmsContent.Replace("{PropertyName}", propertyName);
            return body;
        }
        public string addEnquiryActivity(long EnquiryId, EnquiryActivityDTO activityDTO, EnqActivityMode activityMode, long parentId)
        {
            ISession session = null;
            string RefNo = "";
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EnquiryActivity activity = DTOToDomainUtil.populateEnquiryActivityAddFields(activityDTO);
                        session.Save(activity);
                        activity.RefNo = (activityDTO.RecordType == EnqActivityRecordType.Event) ? CommonUtil.getEnqEventRefNo(activity.Id) : CommonUtil.getEnqTaskRefNo(activity.Id);
                        session.Update(activity);
                        RefNo = activity.RefNo;
                        if (activityMode != EnqActivityMode.NONE && parentId > 0)
                        {
                            EnqActivityStatus status = EnqActivityStatus.Completed;
                            if (activityMode == EnqActivityMode.RESCHEDULE_EVENT || activityMode == EnqActivityMode.RESCHEDULE_TASK
                                || activityMode == EnqActivityMode.CANCEL_EVENT || activityMode == EnqActivityMode.CANCEL_TASK) {
                                    status = EnqActivityStatus.Deferred;
                            }
                            string hqlUpdate = "update EnquiryActivity ea set ea.Status = :status, ea.UpdateDate = :updateDate, ea.UpdateUser = :updateUser where ea.Id = :parentId";
                            session.CreateQuery(hqlUpdate)
                                    .SetEnum("status", status)
                                    .SetDateTime("updateDate", DateTime.Now)
                                    .SetString("updateUser", activityDTO.InsertUser)
                                    .SetInt64("parentId", parentId)
                                    .ExecuteUpdate();
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while adding Enquiry activity:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return RefNo;
        }
        public void closeEnquiry(long enquiryId, List<EnquiryActivityDTO> activityList)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        string hqlActivityUpdate = "update EnquiryActivity ea set ea.Status = :status where ea.Id in (select e.id from EnquiryActivity e where e.EnquiryDetail.Id = :EnquiryId)";
                        session.CreateQuery(hqlActivityUpdate)
                                .SetEnum("status", EnqActivityStatus.Completed)
                                .SetInt64("EnquiryId", enquiryId)
                                .ExecuteUpdate();
                        
                        string hqlEnquiryUpdate = "update EnquiryDetail ed set ed.Status = :status where ed.Id = :EnquiryId";
                        session.CreateQuery(hqlEnquiryUpdate)
                                .SetEnum("status", EnquiryStatus.Lost)
                                .SetInt64("EnquiryId", enquiryId)
                                .ExecuteUpdate();
                        foreach(EnquiryActivityDTO activityDTO in activityList) {
                            EnquiryActivity activity = DTOToDomainUtil.populateEnquiryActivityAddFields(activityDTO);
                            session.Save(activity);
                            activity.RefNo = CommonUtil.getEnqEventRefNo(activity.Id);
                            session.Update(activity);
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while making Enquiry Close:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void reOpenEnquiry(long enquiryId, List<EnquiryActivityDTO> activityList)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        string hqlEnquiryUpdate = "update EnquiryDetail ed set ed.Status = :status where ed.Id = :EnquiryId";
                        session.CreateQuery(hqlEnquiryUpdate)
                                .SetEnum("status", EnquiryStatus.Open)
                                .SetInt64("EnquiryId", enquiryId)
                                .ExecuteUpdate();
                        foreach(EnquiryActivityDTO activityDTO in activityList) {
                            EnquiryActivity activity = DTOToDomainUtil.populateEnquiryActivityAddFields(activityDTO);
                            session.Save(activity);
                            activity.RefNo = CommonUtil.getEnqEventRefNo(activity.Id);
                            session.Update(activity);
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while making Enquiry Close:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public List<AllEnquiryLeadUIDTO> fetchAllEnquiryLeadData()
        {
            ISession session = null;
            List<AllEnquiryLeadUIDTO> resultList = new List<AllEnquiryLeadUIDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        string sqlQuery = "SELECT 'LEAD' AS RD_TYPE, FM.ID, FM.FIRST_NAME, FM.LAST_NAME, CI.CONTACT, CI.EMAIL, UD.STATUS AS USER_STATUS, "
                                +" COUNT(case when LD.STATUS = 'O' then 1 end) AS OPEN_ENQ, COUNT(case when LD.STATUS = 'C' then 1 end) AS WON_EQ, "
                                +" COUNT(case when LD.STATUS = 'X' then 1 end) AS LOST_EQ FROM LEAD_DETAILS LD INNER JOIN FIRM_MEMBER FM ON LD.ASSIGNEE = FM.ID "
                                +" INNER JOIN CONTACT_INFO CI ON FM.CONTACT_INFO_ID = CI.ID INNER JOIN USER_DEFINITION UD ON UD.FIRM_MEMBER_ID = FM.ID "
                                + " GROUP BY FM.ID, FM.FIRST_NAME, FM.LAST_NAME, CI.CONTACT, CI.EMAIL, UD.STATUS "
                                +" UNION "
                                + " SELECT 'ENQUIRY', FM.ID, FM.FIRST_NAME, FM.LAST_NAME, CI.CONTACT, CI.EMAIL, UD.STATUS AS USER_STATUS,"
                                +" COUNT(case when ED.STATUS = 'O' then 1 end) AS OPEN_EQ, COUNT(case when ED.STATUS = 'W' then 1 end) AS WON_EQ,  "
                                +" COUNT(case when ED.STATUS = 'L' then 1 end) AS LOST_EQ FROM ENQUIRY_DETAILS ED INNER JOIN FIRM_MEMBER FM "
                                +" ON ED.ASSIGNEE = FM.ID INNER JOIN CONTACT_INFO CI ON FM.CONTACT_INFO_ID = CI.ID INNER JOIN USER_DEFINITION UD "
                                + " ON UD.FIRM_MEMBER_ID = FM.ID GROUP BY FM.ID, FM.FIRST_NAME, FM.LAST_NAME, CI.CONTACT, CI.EMAIL, UD.STATUS";
                        IList<object[]> resultObjList = session.CreateSQLQuery(sqlQuery).List<object[]>();
                        
                        if (resultList != null)
                        {
                            foreach (object[] row in resultObjList)
                            {
                                long Id = (long)row[1];
                                AllEnquiryLeadUIDTO tmpDTO = resultList.Find(x => x.FirmMemberId == Id);
                                if (tmpDTO == null)
                                {
                                    tmpDTO = new AllEnquiryLeadUIDTO();
                                    tmpDTO.FirmMemberId = Id;
                                    tmpDTO.FirstName = (string)row[2];
                                    tmpDTO.LastName = (string)row[3];
                                    tmpDTO.FullName = CommonUIConverter.getCustomerFullName(tmpDTO.FirstName, tmpDTO.LastName);
                                    tmpDTO.Contact = (string)row[4];
                                    tmpDTO.Email = (string)row[5];
                                    tmpDTO.Status = EnumHelper.getUserStatus((string)row[6]);
                                    resultList.Add(tmpDTO);
                                }
                                if((string)row[0] == "LEAD") {
                                    tmpDTO.LeadsOpen = tmpDTO.LeadsOpen + (int)row[7];
                                    tmpDTO.LeadsClosed = tmpDTO.LeadsClosed + (int)row[8] + (int)row[9];
                                }
                                else 
                                {
                                    tmpDTO.EnquiriesOpen = tmpDTO.LeadsOpen + (int)row[7];
                                    tmpDTO.EnquiriesWon = tmpDTO.EnquiriesWon + (int)row[8];
                                    tmpDTO.EnquiriesClosed = tmpDTO.EnquiriesClosed + (int)row[8] + (int)row[9];
                                }
                            }
                        }
                        
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching all enquiry and leqads history:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return resultList;
        }
    }
}