﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ConstroSoft;

/// <summary>
/// </summary>
namespace ConstroSoft
{
    [Serializable]
    public class AllEnquiryLeadHistoryNavDTO
    {
        public AllEnquiryLeadHistoryNavDTO() { }
    }
    [Serializable]
    public class EnquiryActivityHistoryNavDTO
    {
        public EnquiryActivityHistoryNavDTO() { }
        public long EnquiryId { get; set; }
    }
	[Serializable]
    public class EnquiryAddActivityNavDTO
    {
        public EnquiryAddActivityNavDTO() { }
        public long EnquiryId { get; set; }
    }
	[Serializable]
    public class EnquirySearchNavDTO
    {
        public EnquirySearchNavDTO() { }
        public EnquiryFilterDTO filterDTO { get; set; }
    }
    [Serializable]
    public class EnquiryDetailNavDTO
    {
        public EnquiryDetailNavDTO() { }
        public PageMode Mode { get; set; }
        public long enquiryId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class BookingFormNavDTO
    {
        public BookingFormNavDTO() { }
        public long PrUnitId { get; set; }
        public long EnquiryId { get; set; }
        public bool copyCustomerDtls { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class BookingSuccessNavDTO
    {
        public BookingSuccessNavDTO() { }
        public long PrUnitSaleDetailId { get; set; }
    }
    [Serializable]
    public class PropertyUnitNavDTO
    {
        public PropertyUnitNavDTO() { }
        public PropertyUnitFilterDTO filterDTO { get; set; }
    }
    [Serializable]
    public class SoldUnitSearchNavDTO
    {
        public SoldUnitSearchNavDTO() { }
        public SoldUnitFilterDTO filterDTO { get; set; }
    }
    [Serializable]
    public class SoldUnitDetailNavDTO
    {
        public SoldUnitDetailNavDTO() { }
        public PageMode Mode { get; set; }
        public long PrUnitId { get; set; }
        public long PrUnitSaleDetailId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class CustomerPymtSearchNavDTO
    {
        public CustomerPymtSearchNavDTO() { }
        public CustomerPymtSearchFilterDTO filterDTO { get; set; }
    }
    [Serializable]
    public class CustomerPaymentNavDTO
    {
        public CustomerPaymentNavDTO() { }
        public bool IsPdcPayment { get; set; }
        public PageMode Mode { get; set; }
        public PaymentMode? PymtMode { get; set; }
        public long PrUnitSaleDetailId { get; set; }
        public long MPTId { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class CustomerPymtHistoryNavDTO
    {
        public CustomerPymtHistoryNavDTO() { }
        public long PrUnitSaleDetailId { get; set; }
        public PaymentMode? PymtMode { get; set; }
        public bool isPdc { get; set; }
        public object PrevNavDto { get; set; }
        public CustomerPymtTxHistoryFilterDTO FilterDTO { get; set; }
    }
}