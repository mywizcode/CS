﻿using System;
using System.Web.UI.WebControls;
using ConstroSoft;

public partial class FirstLoginSetup : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
          log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    private string validationErrorGrp = "UserSetupErrorGrp";
    DropdownBO drpBO = new DropdownBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                initDropdowns();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg) {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        drpBO.drpDataBase(drpSecurityQuestion, DrpDataType.SECURITY_QUESTION, userDefDto.Id.ToString(), Constants.SEC_QUESTION_SELECT_ITEM, userDefDto.FirmNumber);
        lbWelcomeInfo.Text = "Welcome, " + CommonUIConverter.getCustomerFullName(userDefDto.FirmMember.FirstName, userDefDto.FirmMember.LastName);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
    }
    protected void SubmitSetupChanges(object sender, EventArgs e)
    {
        LoginBO loginBO = new LoginBO();
        try
        {
            if (validatePassword())
            {
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                loginBO.UpdateFirstLoginInfo(userDefDto.Username, txtNewPassword.Text, long.Parse(drpSecurityQuestion.Text), txtSecurityAnswer.Text,
                    DateUtil.getCSDateNotNull(txtDOB.Text));
                CommonUtil.clearSession(Session, Application);
                Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg("Password is changed successfully. Please login with your new Password."));
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        catch (Exception ex)
        {
            log.Error("Unexpected error:", ex);
            CommonUtil.clearSession(Session, Application);
            Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotyErrorMsg(CommonUtil.getErrorMessage(ex)));
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    protected void CancelChanges(object sender, EventArgs e)
    {
        LoginBO loginBO = new LoginBO();
        try
        {
            CommonUtil.clearSession(Session, Application);
            Response.Redirect(Constants.URL.LOGIN, false);
        }
        catch (Exception ex)
        {
            log.Error("Unexpected error:", ex);
            setErrorMessage(CommonUtil.getErrorMessage(ex), validationErrorGrp);
        }
    }
    private bool validatePassword()
    {
        Page.Validate(validationErrorGrp);
        bool result = Page.IsValid;
        if (result)
        {
            if (!txtNewPassword.Text.Equals(txtConfirmPassword.Text))
            {
                Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotyErrorMsg("New Password and Confirm Password does not match"));
                result = false;
            }
        }
        return result;
    }
}