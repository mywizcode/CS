﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;

public partial class UserAccess : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
           log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    PropertyUserBO propertyUserBO = new PropertyUserBO();
    public enum PrUserPageMode { NONE }

    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                UserDefinationNavDTO navDto = CommonUtil.getPageNavDTO<UserDefinationNavDTO>(Session);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(Constants.URL.DEFAULT_HOME_PAGE, false);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));

    }

    private void doInit(UserDefinationNavDTO navDto)
    {
        UserDefinationPageDTO PageDTO = new UserDefinationPageDTO();
        Session[Constants.Session.PAGE_DATA] = PageDTO;
        PageDTO.PrevNavDTO = navDto.PrevNavDto;
        loadSearchGridAndReSelect(navDto);
        initPageAfterRedirect(navDto);
    }

    private IList<PropertyUserAccessDTO> getCurrentPropertyUserList()
    {
        return ((UserDefinationPageDTO)Session[Constants.Session.PAGE_DATA]).SearchResult;
    }

    protected void onChangeAccessSelection(object sender, EventArgs e)
    {
        try
        {
            CheckBox cb = (CheckBox)sender;
            long selectedId = long.Parse(cb.Attributes["data-pid"]);
            new List<PropertyUserAccessDTO>(getCurrentPropertyUserList()).Find(x => x.Id == selectedId).hasAccess = (cb.Checked ? PrFMAccess.Yes : PrFMAccess.No);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void initPageAfterRedirect(UserDefinationNavDTO navDto)
    {
        try
        {
            loadAndInitPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void loadAndInitPage()
    {
        UserDefinationPageDTO PageDTO = getSessionPageData();
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();

    }
    private void preRenderInitFormElements()
    {
        addCheckBoxAttributes();
    }

    private void addCheckBoxAttributes()
    {
        foreach (ListViewItem item in UserAccessListView.Items)
        {
            CheckBox chBox = (CheckBox)item.FindControl("cbSelectAccess");
            if (chBox != null)
            {
                chBox.InputAttributes.Add("class", "styled block-ui-change");
                chBox.InputAttributes.Add("data-panel", "blockui-panel-1");
            }
        }
    }

    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }

    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private UserDefinationPageDTO getSessionPageData()
    {
        return (UserDefinationPageDTO)Session[Constants.Session.PAGE_DATA];
    }

    private void loadSearchGridAndReSelect(UserDefinationNavDTO navDto)
    {
        try
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            UserDefinationPageDTO PageDTO = getSessionPageData();
            IList<PropertyUserAccessDTO> results = propertyUserBO.fetchUserGridData(userDefDto.FirmNumber.ToString(), navDto.PropertyId);
            PageDTO.SearchResult = results;
            UserAccessListView.DataSource = results;
            UserAccessListView.DataBind();
            foreach (ListViewItem row in UserAccessListView.Items)
            {
                CheckBox chkBtn = (CheckBox)row.FindControl("cbSelectAccess");
                long selectedId = long.Parse(chkBtn.Attributes["data-pid"]);
                PropertyUserAccessDTO userDefinitionDTO = new List<PropertyUserAccessDTO>(getCurrentPropertyUserList()).Find(u => u.Id == Convert.ToInt64((selectedId)));
                chkBtn.InputAttributes.Add("class", "styled block-ui-change");
                chkBtn.InputAttributes.Add("data-panel", "blockui-panel-1");
                if (userDefinitionDTO.hasAccess.Equals(PrFMAccess.Yes))
                {
                    chkBtn.Checked = true;
                }
                else
                {
                    chkBtn.Checked = false;
                }
            }
        }

        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    protected void savePropertyUserToDB(object sender, EventArgs e)
    {
        try
        {
            UserDefinitionDTO userDef = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            UserDefinationPageDTO userDefDto = (UserDefinationPageDTO)Session[Constants.Session.PAGE_DATA];
            UserDefinationNavDTO navDto = (UserDefinationNavDTO)Session[Constants.Session.NAV_DTO];
            foreach (PropertyUserAccessDTO userfdefuserdto in userDefDto.SearchResult)
            {
                propertyUserBO.updatePropertyAccess(navDto.PropertyId, userfdefuserdto.firmMemberId, userfdefuserdto.hasAccess);
            }
            loadSearchGridAndReSelect(navDto);            
            setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.USER_ACCESS_UPDATED_SUCESSFULLY, commonError)));
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    private void navigateToPreviousPage()
    {
        UserDefinationPageDTO PageDTO = getSessionPageData();
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is PropertySearchNavDTO)
            {
                PropertySearchNavDTO navDTO = (PropertySearchNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.PROPERTY_SEARCH, true);
            }
        }
        Response.Redirect(Constants.URL.PROPERTY_SEARCH, true);
    }
    protected void cancelPropertyUserAccess(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }

}
