﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initPropertyUnitUploadGrid();
    formatFields();
    showModal();
}
function initPropertyUnitUploadGrid() {
    var dtOptions = {
        hasActionColumn: false,
        rowInfoModalTitle: "Unit Details",
        pageLength: 10
    };

    $("[id$='unitUploadGrid']").CSBasicDatatable(dtOptions);
}




