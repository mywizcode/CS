﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initEnquirySearchGrid();
    formatFields();
    showModal();
}

function initEnquirySearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#enquirySearchBtnDiv",
        pageLength: 10
    };

    $("[id$='enquirySearchGrid']").CSBasicDatatable(dtOptions);
}