﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initParkingSearchGrid();
    formatFields();
    showModal();
}

function initParkingSearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#propertyParkingSearchBtnDiv",
        pageLength: 10
    };

    $("[id$='propertyParkingSearchGrid']").CSBasicDatatable(dtOptions);
}

