﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initMyLeadsSearchGrid();
    formatFields();
    showModal();
}

function initMyLeadsSearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#leadSearchBtnDiv",
        pageLength: 10
    };

    $("[id$='myLeadsSearchGrid']").CSBasicDatatable(dtOptions);
}




