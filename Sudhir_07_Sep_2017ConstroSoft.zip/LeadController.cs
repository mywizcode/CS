﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ConstroSoft
{
    public class LeadController : ApiController
    {
        [HttpPost]
        [ActionName("PostLead")]
        public string PostLead([FromBody]LeadDetailDTO leadDetailDto)
        {
            FBIntegrationBO fBIntegrationBO = new FBIntegrationBO();
            var response = JsonConvert.SerializeObject("Failure");

            if (leadDetailDto != null)
            {
                string errorMessage = fBIntegrationBO.validateLeadMandatoryFields(leadDetailDto);
                if (errorMessage == null)
                {
                    if (fBIntegrationBO.checkTokenValidity(leadDetailDto.TokenNumber))
                    {
                        response = JsonConvert.SerializeObject(leadDetailDto.FirstName + " created successfully");
                    }
                    else
                    {
                        response = JsonConvert.SerializeObject("Authorization has been denied for this request, please login again.");
                    }
                }
                else
                {
                    response = JsonConvert.SerializeObject(errorMessage);
                }
            }
            return response;
        }
    }
}