﻿using System;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Web;

public partial class LoginMasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            
        }
    }
}