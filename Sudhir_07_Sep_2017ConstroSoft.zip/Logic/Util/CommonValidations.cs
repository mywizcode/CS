﻿using ConstroSoft;
using System.Collections.Generic;
using NHibernate.Criterion;
using System.Linq.Expressions;
using NHibernate.Impl;
using System;
using System.Web.UI.WebControls;
using System.Globalization;
namespace ConstroSoft
{
    public class CommonValidations
    {
        public CommonValidations() { }
        public static string validateUnitSaleDates(DateTime bookingDate, DateTime? possessionDate, DateTime? agreementDate, string agreementNo,
            IsAgreementDone isAgreementDone, IsPossessionDone isPossessionDone)
        {
            string errorMessage = "";
            if (IsAgreementDone.Yes == isAgreementDone)
            {
                if (agreementDate == null) return Resources.Messages.validation_agreementdate_required;
                else if (agreementDate != null && agreementDate.Value.CompareTo(DateTime.Today) > 0) return "Agreement Date cannot be in future.";
                else if (string.IsNullOrWhiteSpace(agreementNo)) return Resources.Messages.validation_agreementno_required;
            }
            if (IsPossessionDone.Yes == isPossessionDone)
            {
                if (possessionDate == null) return Resources.Messages.validation_possession_required;
                else if (possessionDate != null && possessionDate.Value.CompareTo(DateTime.Today) > 0) return "Possession Date cannot be in future.";
                else if (IsAgreementDone.No == isAgreementDone || agreementDate == null) return Resources.Messages.validation_agreement_after_possession;
            }
            if (agreementDate != null && bookingDate.CompareTo(agreementDate.Value) > 0)
            {
                return Resources.Messages.validation_booking_after_agreement;
            }
            if (possessionDate != null)
            {
                if (agreementDate == null || agreementDate.Value.CompareTo(possessionDate.Value) > 0)
                {
                    errorMessage = Resources.Messages.validation_agreement_after_possession;
                }
            }
            return errorMessage;
        }
    }
}