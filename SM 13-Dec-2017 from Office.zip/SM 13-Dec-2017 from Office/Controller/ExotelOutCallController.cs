﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace ConstroSoft.Controller
{
    public class ExotelOutCallController : ApiController
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        CallHistoryBO callHistoryBO = new CallHistoryBO();

        [HttpPost]
        [ActionName("PostOutCallDetails")]
        public string PostOutCallDetails()
        {
            var response = JsonConvert.SerializeObject("Failure");
            try
            {
                CallHistoryDTO callHistoryDTO = populateCallHistoryDTOFromCall(HttpContext.Current.Request);
                //Validate the Mandatory Fields.
                if (!string.IsNullOrEmpty(callHistoryDTO.CallSid))
                {
                    callHistoryBO.updateCallHistory(callHistoryDTO);
                    response = JsonConvert.SerializeObject("Out Call Details Recieved Successfully.");
                }else{
                    log.Error("ExotelOutCallController: CallSid is Missing");
                    response = JsonConvert.SerializeObject("CallSid is Missing");
                }
                
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while placing outbound call");
                log.Error(exp.Message, exp);
            }
            finally
            {
            }
            return response;
        }
        public static CallHistoryDTO populateCallHistoryDTOFromCall(HttpContext.Current.Request request)
        {
            CallHistoryDTO callHistoryDTO = new CallHistoryDTO();
            callHistoryDTO.CallSid = HttpContext.Current.Request.Params["CallSid"];
            callHistoryDTO.CallStatus = EnumHelper.ToEnum<CallStatus>(HttpContext.Current.Request.Params["Status"].ToString().Replace("-", ""));
            callHistoryDTO.RecordingUrl = HttpContext.Current.Request.Params["RecordingUrl"];
            callHistoryDTO.DateUpdated =  Convert.ToDateTime(HttpContext.Current.Request.Params["DateUpdated"]);
            callHistoryDTO.EndTime =  HttpContext.Current.Request.Params["EndTime"];
            callHistoryDTO.Duration =  HttpContext.Current.Request.Params["Duration"];
            callHistoryDTO.UpdateUser = Constants.EXOTEL.EXOTEL_SID;
            callHistoryDTO.CallHistoryStatus = CallHistoryStatus.Resolved;
            return callHistoryDTO;
        }
    }
    }
}