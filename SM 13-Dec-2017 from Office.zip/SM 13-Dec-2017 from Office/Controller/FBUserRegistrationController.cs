﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ConstroSoft.Controller
{
    public class FBUserRegistrationController : ApiController
    {
        [HttpPost]
        [ActionName("RegisterUser")]
        public string RegisterUser([FromBody]PortalUserDTO portalUserDTO)
        {
            FBIntegrationBO fBIntegrationBO = new FBIntegrationBO();
            var response = JsonConvert.SerializeObject("Failure");
            if (portalUserDTO != null)
            {
                string errorMessage = fBIntegrationBO.validateMandatoryFields(portalUserDTO);
                if (errorMessage == null)
                {
                    errorMessage = fBIntegrationBO.checkFirmExists(portalUserDTO);
                    if (errorMessage == null)
                    {
                        errorMessage = fBIntegrationBO.checkUserExists(portalUserDTO);
                        if (errorMessage == null)
                        {
                            fBIntegrationBO.saveFBuser(portalUserDTO);
                            response = JsonConvert.SerializeObject(portalUserDTO.UserName + " created successfully");
                        }
                        else
                        {
                            response = JsonConvert.SerializeObject(errorMessage);
                        }
                    }
                    else
                    {
                        response = JsonConvert.SerializeObject(errorMessage);
                    }
                }
                else
                {
                    response = JsonConvert.SerializeObject(errorMessage);
                }
            }
            return response;
        }

    }
}