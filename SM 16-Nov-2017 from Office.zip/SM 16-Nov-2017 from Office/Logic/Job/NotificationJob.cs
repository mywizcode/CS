﻿using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;

namespace ConstroSoft.Logic.Job
{
    public class NotificationJob : IJob
    {
        private static readonly log4net.ILog log =
                log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        JobHistoryBO jobHistoryBO = new JobHistoryBO();
        NotificationBO notificationBO = new NotificationBO();
        
        public void Execute(IJobExecutionContext context)
        {
            JobHistoryDTO jobHistoryDTO = new JobHistoryDTO();
            string message = null;
            try{
                var schedulerContext = context.Scheduler.Context;
                JobDTO jobDTO = (JobDTO)schedulerContext.Get(Constants.NOTIFICATION_JOB);
                UserDefinitionDTO userDefinitionDTO = (UserDefinitionDTO)schedulerContext.Get("UserDefinitionDTO");
                populateJobHistoryAddDto(jobHistoryDTO, jobDTO, userDefinitionDTO);
                long Id =jobHistoryBO.saveJobHistory(jobHistoryDTO);
                jobHistoryDTO.Id = Id;
                IList<NotificationDTO> notificationDtos = notificationBO.fetchNotifications(userDefinitionDTO.FirmNumber);
                //Create Dictionary with Key as UserName~PropertyID~Notification
                //Add List NotificationTO agains cache[Key]
                /*var dictionary = notificationDtos
                        .GroupBy(x => x.UserName)
                        .ToDictionary(x => x.UserName, x => x.ToList());
                foreach(KeyValuePair<string, IList<NotificationDTO>> entry in dictionary)
                {
                    cache.Remove(entry.Key"-Notification");
                    cache[entry.Key"-Notification"] = entry.Value;                   
                }*/
                
            }catch (Exception exp)
            {
                message = exp.Message;
                log.Error(exp.Message, exp);
            }finally{
                populateJobHistoryUpdateDto(jobHistoryDTO, message);
                jobHistoryBO.updatejobHistoryDetails(jobHistoryDTO);
            }
           
        }
        
        private void populateJobHistoryAddDto(JobHistoryDTO jobHistoryDTO, JobDTO jobDTO, UserDefinitionDTO userDefinitionDTO)
        {
            jobHistoryDTO.StartTime = DateTime.Now;
            jobHistoryDTO.JobRunStatus = JobRunStatus.INPROGRESS;
            jobHistoryDTO.Job = jobDTO;
            jobHistoryDTO.FirmNumber = userDefinitionDTO.FirmNumber;
            jobHistoryDTO.Version = userDefinitionDTO.Version;
            jobHistoryDTO.InsertUser = userDefinitionDTO.Username;
            jobHistoryDTO.UpdateUser = userDefinitionDTO.Username;
            jobHistoryDTO.InsertDate = DateTime.Now;
            jobHistoryDTO.UpdateDate = DateTime.Now;
        }

        private void populateJobHistoryUpdateDto(JobHistoryDTO jobHistoryDTO, string message)
        {
            jobHistoryDTO.EndTime = DateTime.Now;
            if(message != null){
                jobHistoryDTO.JobRunStatus = JobRunStatus.FAILURE;
                jobHistoryDTO.Message = message;
            }else{
                jobHistoryDTO.JobRunStatus = JobRunStatus.SUCCESS;
                jobHistoryDTO.Message = "Job execution completed successfully.";
            }
            jobHistoryDTO.UpdateDate = DateTime.Now;
        }
      }
}