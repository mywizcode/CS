﻿
/// <summary>
/// Summary description for MyENUM
/// </summary>

using System;
using System.ComponentModel;
using System.Reflection;
namespace ConstroSoft
{
    public static class FileSizeExtension
    {
        public static string ToSize(this int value, SizeUnits unit)
        {
            return ((value / (double)Math.Pow(1024, (Int64)unit)).ToString("N2")) + " " + unit.ToString();
        }
        public static string ToSize(this long value, SizeUnits unit)
        {
            return ((value / (double)Math.Pow(1024, (Int64)unit)).ToString("N2")) + " " + unit.ToString();
        }
    }
}