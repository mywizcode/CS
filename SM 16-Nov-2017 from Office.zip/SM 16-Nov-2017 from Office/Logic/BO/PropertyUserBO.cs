﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;


/// <summary>
/// Summary description for EmployeeBO
/// </summary>
namespace ConstroSoft
{
    public class PropertyUserBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public PropertyUserBO() { }

        public IList<PropertyUserAccessDTO> fetchUserGridData(string firmNumber, long propertyId)
        {
            ISession session = null;
            IList<PropertyUserAccessDTO> result = new List<PropertyUserAccessDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                UserDefinition ud = null;
                PropertyUserAccessDTO udt = null;
                PropertyFMAccess pfa = null;
                Property p = null;
                FirmMember fm = null;
                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => ud.Id).WithAlias(() => udt.Id))
                            .Add(Projections.Property(() => ud.Username).WithAlias(() => udt.Username))
                            .Add(Projections.Property(() => fm.FirstName).WithAlias(() => udt.FirstName))
                            .Add(Projections.Property(() => fm.Id).WithAlias(() => udt.firmMemberId))
                            .Add(Projections.Property(() => fm.FirstName).WithAlias(() => udt.LastName))
                            .Add(Projections.Property(() => ud.Status).WithAlias(() => udt.Status))
                            .Add(Projections.Property(() => pfa.HasAccess).WithAlias(() => udt.hasAccess));
                var query = session.QueryOver<UserDefinition>(() => ud)
                            .Inner.JoinAlias(() => ud.FirmMember, () => fm)
                            .Left.JoinAlias(() => fm.PropertyFMAccess, () => pfa)
                            .Left.JoinAlias(() => pfa.Property, () => p);
                result = query.Where(() => ud.FirmNumber == firmNumber && ud.Status == UserStatus.Active && p.Id == propertyId)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<PropertyUserAccessDTO>()).List<PropertyUserAccessDTO>();
                
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating property user access:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public long updatePropertyAccess(long propertyId, long FirmMemberId, PrFMAccess isUISelected)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyFMAccess userAccess = new PropertyFMAccess();
                        userAccess.Property = new Property();
                        userAccess.Property.Id = propertyId;
                        userAccess.FirmMember = new FirmMember();
                        userAccess.FirmMember.Id = FirmMemberId;
                        userAccess.HasAccess = isUISelected;
                        session.SaveOrUpdate(userAccess);
                        tx.Commit();
                    }

                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while assigning property to new user:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }

                }
                return Id;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }

        }
               
    }
}