﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Net;
using System.IO;
using System.Net.Mail;
using ConstroSoft;
using ConstroSoft.Logic.BO;
using OfficeOpenXml;
using OfficeOpenXml.DataValidation;
using OfficeOpenXml.Style;
using System.Drawing;
using ConstroSoft.Logic.Util;
using System.Text;
using System.Web.UI.HtmlControls;

public partial class SoldUnitDetails : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string soldUnitStep1Error = "soldUnitStep1Error";
    string soldUnitStep2Error = "soldUnitStep2Error";
    string soldUnitStep3Error = "soldUnitStep3Error";
    string addMasterDataError = "addMasterDataError";
    string addModifyPaymentError = "addModifyPaymentError";
    string addModifyCoApplicantError = "addModifyCoApplicantError";
    string addModifyAddressError = "addModifyAddressError";
    string addParkingError = "addParkingError";
    string taxDetailModalError = "taxDetailModalError";
    string addMasterDataModal = "addMasterDataModal";
    string addModifyCoApplicantModal = "addModifyCoApplicantModal";
    string addModifyAddressModal = "addModifyAddressModal";
    string addParkingModal = "addParkingModal";
    string SearchFilterModal = "SearchFilterModal";
    string addModifyPaymentModal = "addModifyPaymentModal";
    string taxDetailModal = "taxDetailModal";
    string step1 = "step1";
    string step2 = "step2";
    string step3 = "step3";
    DropdownBO drpBO = new DropdownBO();
    PropertyBO propertyBO = new PropertyBO();
    PropertyUnitManagementBO prUnitBO = new PropertyUnitManagementBO();
    SoldPropertyUnitBO soldUnitBO = new SoldPropertyUnitBO();
    CustomerBO customerBO = new CustomerBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    public enum CoApplicantAction { ADD, MODIFY }
    public enum AddressAction { ADD, MODIFY }
    public enum PaymentAction { ADD, MODIFY }
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                SoldUnitDetailNavDTO navDto = CommonUtil.getPageNavDTO<SoldUnitDetailNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_SOLD_PR_UNIT)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg) {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
    	string currentStep = activeStepHdn.Value;
        pnlSoldUnitStep1.Visible = step1.Equals(currentStep);
        pnlSoldUnitStep2.Visible = step2.Equals(currentStep);
        pnlSoldUnitStep3.Visible = step3.Equals(currentStep);
        renderPageFieldsWithEntitlement();
        setPageTitle();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        
        drpBO.drpDataBase(drpCustSalutation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.SALUTATION, null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpCustOccupation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.OCCUPATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        CommonUtil.copyDropDownItems(drpCoCustOccupation, drpCustOccupation);
        drpBO.drpEnum<MaritalStatus>(drpCustMaritalStatus, Constants.SELECT_ITEM);

        drpBO.drpDataBase(drpCoCustSalutation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.SALUTATION, null, userDefDto.FirmNumber);
        drpBO.drpEnum<Gender>(drpCoCustGender, Constants.SELECT_ITEM);
        drpBO.drpEnum<MaritalStatus>(drpCoCustMaritalStatus, Constants.SELECT_ITEM);
        drpBO.drpEnum<PowerOfAtorny>(drpPowerOfAttorney, Constants.SELECT_ITEM);
        drpBO.drpDataBase(drpRelationWithCust, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.RELATION_WITH_CUSTOMER, Constants.SELECT_ITEM, userDefDto.FirmNumber);

        drpBO.drpDataBase(drpAddressCountry, DrpDataType.COUNTRY, null, null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAddressState, DrpDataType.STATE, Constants.DEFAULT_COUNTRY, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        initCityDrp(drpAddressCity, Constants.DEFAULT_STATE);
        drpBO.drpDataBase(drpAddressType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ADDRESS_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<PreferredAddress>(drpPreferredAddress, null);

        drpBO.drpDataBase(drpAllPaymentType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_PYMT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<PaymentMode>(drpPaymentMode, null);
    }
    private void initCityDrp(DropDownList drp, string stateId)
    {
        drpBO.drpDataBase(drp, DrpDataType.CITY, stateId, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        setErrorActiveStep(group);
    }
    private void setErrorActiveStep(string group) {
        if(group.Equals(commonError) || group.Equals(soldUnitStep1Error)) activeStepHdn.Value = step1;
        if(group.Equals(soldUnitStep2Error)) activeStepHdn.Value = step2;
        if(group.Equals(soldUnitStep3Error)) activeStepHdn.Value = step3;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(SoldUnitDetailNavDTO navDto)
    {
        if (navDto != null)
        {
            setCurrentStep(step1);
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(SoldUnitDetailNavDTO navDto)
    {
        try
        {
            SoldUnitDetailPageDTO soldUnitPageDTO = new SoldUnitDetailPageDTO();
            Session[Constants.Session.PAGE_DATA] = soldUnitPageDTO;
            pageModeHdn.Value = navDto.Mode.ToString();
            soldUnitPageDTO.PrevNavDTO = navDto.PrevNavDto;
            PrUnitSaleDetailDTO prUnitSaleDetailDto = soldUnitBO.fetchPrUnitSaleDetail(getUserDefinitionDTO().FirmNumber, navDto.PrUnitSaleDetailId);
            soldUnitPageDTO.UnitDTO = propertyBO.fetchPropertyUnitWithParent(prUnitSaleDetailDto.PropertyUnit.Id, true);
            prUnitSaleDetailDto.PropertyUnit = getSoldUnit();
            prUnitSaleDetailDto.uiTaxDetails = new List<PrUnitSaleTaxDetailDTO>();
            prUnitSaleDetailDto.uiCMTaxDetails = new List<PrUnitSaleTaxDetailDTO>();
            foreach (PrUnitSaleTaxDetailDTO taxDtl in prUnitSaleDetailDto.PrUnitSaleTaxDetails)
            {
                if (IncludeInPymtTotal.Yes == taxDtl.IncludeInTotalPymt) prUnitSaleDetailDto.uiTaxDetails.Add(taxDtl);
                else prUnitSaleDetailDto.uiCMTaxDetails.Add(taxDtl);
            }
            soldUnitPageDTO.PrUnitSaleDTO = prUnitSaleDetailDto;
            populateUIFieldsFromSaleUnitDTO(getSoldUnitDetails());
            drpBO.drpDataBase(drpParking, DrpDataType.PR_AVAILABLE_PARKING, getSoldUnit().PropertyTower.Id.ToString(),
                    Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void navigateToPreviousPage() {
        SoldUnitDetailPageDTO soldUnitPageDTO = getSessionPageData();
        if (soldUnitPageDTO != null && soldUnitPageDTO.PrevNavDTO != null)
        {
            object obj = soldUnitPageDTO.PrevNavDTO;
            if (obj is CustomerPymtHistoryNavDTO)
            {
                CustomerPymtHistoryNavDTO navDTO = (CustomerPymtHistoryNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.CUSTOMER_PYMT_HISTORY, true);
            }
            else if (obj is SoldUnitSearchNavDTO)
            {
                SoldUnitSearchNavDTO navDTO = (SoldUnitSearchNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.SOLD_UNIT_SEARCH, true);
            }
            else if (obj is EnquiryDetailNavDTO)
            {
            	EnquiryDetailNavDTO navDTO = (EnquiryDetailNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.ENQUIRY_DETAILS, true);
            }
            else if (obj is UserEnquiryHistoryNavDTO)
            {
            	UserEnquiryHistoryNavDTO navDTO = (UserEnquiryHistoryNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.USER_ENQUIRY_HISTORY, true);
            }
        }
        Response.Redirect(Constants.URL.SOLD_UNIT_SEARCH, true);
    }
    private void setPageTitle()
    {
        if (isModifyMode()) lbPageTitle.Text = Constants.ICON.MODIFY + Resources.Labels.MODIFY_SOLD_UNIT;
        else if (isViewMode()) lbPageTitle.Text = Constants.ICON.VIEW_DTL + Resources.Labels.SOLD_UNIT_DETAILS;
        setSubHeaderPageTitle();
    }
    private void setSubHeaderPageTitle()
    {
        string jumpTo = activeStepHdn.Value;
        lbSubHeaderPageTitle.Text = " - ";
        if (jumpTo.Equals(step1))
        {
            lbSubHeaderPageTitle.Text += Resources.Labels.SOLD_UNIT_PAGE1_TITLE;
        }
        else if (jumpTo.Equals(step2))
        {
            lbSubHeaderPageTitle.Text += Resources.Labels.SOLD_UNIT_PAGE2_TITLE;
        }
        else if (jumpTo.Equals(step3))
        {
            lbSubHeaderPageTitle.Text += Resources.Labels.SOLD_UNIT_PAGE3_TITLE;
        }
    }
    private void renderPageFieldsWithEntitlement()
    {
    	bool modifyMode = isModifyMode();
    	bool viewMode = isViewMode();
        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
    	
    	//Page 1 Fields
        drpCustSalutation.Enabled = false;
        txtCustFirstName.ReadOnly = true;
        txtCustMiddleName.ReadOnly = true;
        txtCustLastName.ReadOnly = true;
        txtCustGender.ReadOnly = true;
        txtCustDOB.ReadOnly = viewMode;
        drpCustMaritalStatus.Enabled = !viewMode;
        txtCustContact.ReadOnly = viewMode;
        txtCustAltContact.ReadOnly = viewMode;
        txtCustEmail.ReadOnly = viewMode;
        txtCustAltEmail.ReadOnly = viewMode;
        drpCustOccupation.Enabled = !viewMode;
        txtCustPan.ReadOnly = viewMode;
        addOccupationBtn.Visible = modifyMode && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MASTER_DATA_ADD);
        addOccCoApplicant.Visible = modifyMode && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MASTER_DATA_ADD);
        lnkAddRelationWithCustomer.Visible = modifyMode && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MASTER_DATA_ADD);
        if (addPymtTypeBtn.Visible) addPymtTypeBtn.Visible = CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MASTER_DATA_ADD);
        lnkAddAddress.Visible = modifyMode;
        if (addressGrid.Items.Count > 0)
        {
            foreach (ListViewItem item in addressGrid.Items)
            {
                LinkButton modifyBtn = (LinkButton)item.FindControl("lnkModifyAddress");
                if (modifyBtn != null) modifyBtn.Visible = modifyMode;
                LinkButton deleteBtn = (LinkButton)item.FindControl("lnkDeleteAddress");
                if (deleteBtn != null) deleteBtn.Visible = modifyMode;
            }
        }
        addCoApplicantBtn.Visible = modifyMode;
        if (coApplicantGrid.Items.Count > 0)
        {
            foreach (ListViewItem item in coApplicantGrid.Items)
            {
                HtmlGenericControl modifyBtn = (HtmlGenericControl)item.FindControl("liCoApplicantBtn");
                if (modifyBtn != null) modifyBtn.Visible = modifyMode;
            }
        }
        //Page 2 Fields
        txtEmployee.ReadOnly = true;
        txtBookingDate.ReadOnly = true;
        txtBookingRate.ReadOnly = viewMode;
        txtAgreementValue.ReadOnly = viewMode;
        lnkAddTaxDetailBtn.Visible = modifyMode;
        taxDetailGrid.Columns[0].Visible = modifyMode;
        lnkAddCMTaxDetailBtn.Visible = modifyMode;
        cmTaxDetailGrid.Columns[0].Visible = modifyMode;
        cbAgreementDone.Disabled = viewMode;
        txtAgreementDate.ReadOnly = viewMode;
        txtAgreementNo.ReadOnly = viewMode;
        cbPossessionGiven.Disabled = viewMode;
        txtPossesionDate.ReadOnly = viewMode;
        //Page 3 Fields
        txtLoanBankName.ReadOnly = viewMode;
        txtLoanBankName.ReadOnly = viewMode;
        txtLoanBranch.ReadOnly = viewMode;
        addParkingBtn.Visible = modifyMode;
        if (parkingGrid.Items.Count > 0)
        {
            foreach (ListViewItem item in parkingGrid.Items)
            {
                LinkButton deleteBtn = (LinkButton)item.FindControl("lnkDeleteParkingBtn");
                if (deleteBtn != null) deleteBtn.Visible = modifyMode;
            }
        }
        addSalePaymentBtn.Visible = modifyMode;
        paymentGrid.Columns[0].Visible = modifyMode;

        btnSoldUnitSubmit.Visible = modifyMode;
        
        //SubHeader links and Other btns with Entitlement
        liModifySoldUnit.Visible = viewMode && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.SOLD_UNIT_MODIFY);
        liNavigation.Visible = CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_CUSTOMER_PAYMENTS);
    }
    private bool isModifyMode() {
        return PageMode.MODIFY.ToString().Equals(pageModeHdn.Value);
    }
    private bool isViewMode() {
        return PageMode.VIEW.ToString().Equals(pageModeHdn.Value);
    }
    private SoldUnitDetailPageDTO getSessionPageData()
    {
        return (SoldUnitDetailPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private PrUnitSaleDetailDTO getSoldUnitDetails()
    {
        return getSessionPageData().PrUnitSaleDTO;
    }
    private PropertyUnitDTO getSoldUnit()
    {
        return getSessionPageData().UnitDTO;
    }
    private IsAgreementDone getAgreementDoneUIValue()
    {
        return (cbAgreementDone.Checked) ? IsAgreementDone.Yes : IsAgreementDone.No;
    }
    private IsPossessionDone getPossessionDoneUIValue()
    {
        return (cbPossessionGiven.Checked) ? IsPossessionDone.Yes : IsPossessionDone.No;
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private PrUnitSaleTaxDetailDTO populatePrSaleTaxDetail(PropertyTaxDetailDTO propertyTaxDetailDto)
    {
        PrUnitSaleTaxDetailDTO taxDetailDto = new PrUnitSaleTaxDetailDTO();
        taxDetailDto.TaxType = propertyTaxDetailDto.TaxType;
        taxDetailDto.TaxPercentage = propertyTaxDetailDto.TaxPercentage;
        taxDetailDto.TaxAmtLimit = propertyTaxDetailDto.TaxAmtLimit;
        taxDetailDto.IncludeInTotalPymt = propertyTaxDetailDto.IncludeInTotalPymt;
        taxDetailDto.TaxAmt = Decimal.Zero;
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        taxDetailDto.FirmNumber = userDef.FirmNumber;
        taxDetailDto.InsertUser = userDef.Username;
        taxDetailDto.UpdateUser = userDef.Username;

        return taxDetailDto;
    }
    private void populateCustomerDTOFromUI(CustomerDTO customerDto)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        customerDto.ContactInfo.Dob = DateUtil.getCSDateNotNull(txtCustDOB.Text);
        customerDto.ContactInfo.MaritalStatus = EnumHelper.ToEnumNullable<MaritalStatus>(drpCustMaritalStatus.Text);
        customerDto.ContactInfo.Contact = txtCustContact.Text;
        customerDto.ContactInfo.AltContact = txtCustAltContact.Text;
        customerDto.ContactInfo.Email = txtCustEmail.Text;
        customerDto.ContactInfo.AltEmail = txtCustAltEmail.Text;
        customerDto.Occupation = CommonUIConverter.getMasterControlDTO(drpCustOccupation.Text, null);
        customerDto.Pan = txtCustPan.Text;
        customerDto.UpdateUser = userDefDto.Username;
    }
    private void populateCustomerFields(CustomerDTO customerDTO)
    {
        if (customerDTO != null && customerDTO.Salutation != null) drpCustSalutation.Text = customerDTO.Salutation.Id.ToString(); else drpCustSalutation.ClearSelection();
        if (customerDTO != null) txtCustFirstName.Text = customerDTO.FirstName; else txtCustFirstName.Text = null;
        if (customerDTO != null) txtCustMiddleName.Text = customerDTO.MiddleName; else txtCustMiddleName.Text = null;
        if (customerDTO != null) txtCustLastName.Text = customerDTO.LastName; else txtCustLastName.Text = null;
        if (customerDTO != null && customerDTO.ContactInfo.Gender != null) txtCustGender.Text = customerDTO.ContactInfo.Gender.ToString(); else txtCustGender.Text = null;
        if (customerDTO != null && customerDTO.ContactInfo.Dob != null) txtCustDOB.Text = customerDTO.ContactInfo.Dob.Value.ToString(Constants.DATE_FORMAT); else txtCustDOB.Text = null;
        if (customerDTO != null && customerDTO.ContactInfo.MaritalStatus != null) drpCustMaritalStatus.Text = customerDTO.ContactInfo.MaritalStatus.ToString(); else drpCustMaritalStatus.ClearSelection();
        if (customerDTO != null) txtCustContact.Text = customerDTO.ContactInfo.Contact; else txtCustContact.Text = null;
        if (customerDTO != null) txtCustAltContact.Text = customerDTO.ContactInfo.AltContact; else txtCustAltContact.Text = null;
        if (customerDTO != null) txtCustEmail.Text = customerDTO.ContactInfo.Email; else txtCustEmail.Text = null;
        if (customerDTO != null) txtCustAltEmail.Text = customerDTO.ContactInfo.AltEmail; else txtCustAltEmail.Text = null;
        if (customerDTO != null && customerDTO.Occupation != null) drpCustOccupation.Text = customerDTO.Occupation.Id.ToString(); else drpCustOccupation.ClearSelection();
        if (customerDTO != null) txtCustPan.Text = customerDTO.Pan; else txtCustPan.Text = null;
        lbCustomerRefNo.Text = customerDTO.CustRefNo;

        populateAddressGrid(customerDTO.ContactInfo);
    }
    private void populateUIFieldsFromSaleUnitDTO(PrUnitSaleDetailDTO prUnitSaleDetailDto)
    {
        PropertyUnitDTO propertyUnitDto = prUnitSaleDetailDto.PropertyUnit;
        PropertyTowerDTO propertyTowerDto = prUnitSaleDetailDto.PropertyUnit.PropertyTower;
        //Page 1 Details
        spEnquiryRefNo.Visible = false;
        if(prUnitSaleDetailDto.Enquiry != null) {
            spEnquiryRefNo.Visible = true;
            lbEnquiryRefNo.Text = prUnitSaleDetailDto.Enquiry.EnquiryRefNo;
        }
        
        populateCustomerFields(prUnitSaleDetailDto.Customer);
        populateCoApplicantGrid(prUnitSaleDetailDto);
        //Page 2 Details
        populateUnitInfoSection(prUnitSaleDetailDto);
        txtEmployee.Text = CommonUIConverter.getCustomerFullName(prUnitSaleDetailDto.FirmMember.FirstName, "", prUnitSaleDetailDto.FirmMember.LastName);
        txtBookingDate.Text = DateUtil.getCSDate(prUnitSaleDetailDto.BookingDate);
        txtBookingRate.Text = (propertyTowerDto.Rate != null) ? propertyTowerDto.Rate.ToString() : null;
        txtAgreementValue.Text = prUnitSaleDetailDto.AgreementAmt.ToString();
        txtBookingRefNo.Text = prUnitSaleDetailDto.BookingRefNo;
        lbBookTotalTax.Text = prUnitSaleDetailDto.TotalTaxAmt.ToString();
        lbBookTotalUnitCost.Text = prUnitSaleDetailDto.TotalPymtAmt.ToString();
        cbAgreementDone.Checked = (prUnitSaleDetailDto.IsAgreementDone == IsAgreementDone.Yes);
        txtAgreementDate.Text = DateUtil.getCSDate(prUnitSaleDetailDto.AgreementDate);
        txtAgreementNo.Text = prUnitSaleDetailDto.AgreementNo;
        cbPossessionGiven.Checked = (prUnitSaleDetailDto.IsPossessionDone == IsPossessionDone.Yes);
        txtPossesionDate.Text = DateUtil.getCSDate(prUnitSaleDetailDto.PossessionDate);
        populateTaxDetailGrid(prUnitSaleDetailDto);
        populateCMTaxDetailGrid(prUnitSaleDetailDto);
        //Page 3 Details
        txtLoanBankName.Text = prUnitSaleDetailDto.LoanBankName;
        txtLoanBranch.Text = prUnitSaleDetailDto.LoanBankBranch;
        txtLoanAmount.Text = (prUnitSaleDetailDto.LoanAmt != null) ? prUnitSaleDetailDto.LoanAmt.ToString() : null;   
        populateParkingGrid(prUnitSaleDetailDto);
        populateSalePymtGrid(prUnitSaleDetailDto);
    }
    private void populateUnitInfoSection(PrUnitSaleDetailDTO prUnitSaleDetailDto)
    {
        PropertyUnitDTO propertyUnitDto = prUnitSaleDetailDto.PropertyUnit;
        PropertyTowerDTO propertyTowerDto = prUnitSaleDetailDto.PropertyUnit.PropertyTower;
        lbBookProperty.Text = propertyTowerDto.Property.Name;
        lbBookTower.Text = propertyTowerDto.Name;
        lbBookBaseRate.Text = (propertyTowerDto.Rate != null) ? propertyTowerDto.Rate.ToString() : null;
        lbBookWing.Text = propertyUnitDto.Wing;
        lbBookUnitNo.Text = propertyUnitDto.UnitNo;
        lbBookUnitType.Text = propertyUnitDto.UnitType.Name;
        btnSoldUnitInfoHdn.Attributes["row-info"] = CommonUIConverter.getGridViewRowInfo(propertyUnitDto);
    }
    private void populateTaxDetailGrid(PrUnitSaleDetailDTO prUnitSaleDetailDTO)
    {
        taxDetailGrid.DataSource = new List<PrUnitSaleTaxDetailDTO>();
        if (prUnitSaleDetailDTO != null && prUnitSaleDetailDTO.uiTaxDetails != null)
        {
            assignUiIndexToTaxDetail(prUnitSaleDetailDTO.uiTaxDetails);
            taxDetailGrid.DataSource = prUnitSaleDetailDTO.uiTaxDetails;
        }
        taxDetailGrid.DataBind();
    }
    private void populateCMTaxDetailGrid(PrUnitSaleDetailDTO prUnitSaleDetailDTO)
    {
        cmTaxDetailGrid.DataSource = new List<PrUnitSaleTaxDetailDTO>();
        if (prUnitSaleDetailDTO != null && prUnitSaleDetailDTO.uiTaxDetails != null)
        {
            assignUiIndexToTaxDetail(prUnitSaleDetailDTO.uiCMTaxDetails);
            cmTaxDetailGrid.DataSource = prUnitSaleDetailDTO.uiCMTaxDetails;
        }
        cmTaxDetailGrid.DataBind();
    }
    private void assignUiIndexToTaxDetail(List<PrUnitSaleTaxDetailDTO> taxDetailDtos)
    {
        if (taxDetailDtos != null && taxDetailDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (PrUnitSaleTaxDetailDTO taxDetailDto in taxDetailDtos)
            {
                taxDetailDto.UiIndex = uiIndex++;
                taxDetailDto.RowInfo = CommonUIConverter.getGridViewRowInfo(taxDetailDto);
            }
        }
    }
    private void populateCoApplicantGrid(PrUnitSaleDetailDTO prSaleDetailDTO)
    {
        coApplicantGrid.DataSource = new List<CoCustomerDTO>();
        if (prSaleDetailDTO != null)
        {
            assignUiIndexToCoApplicant(prSaleDetailDTO.CoCustomers);
            coApplicantGrid.DataSource = prSaleDetailDTO.CoCustomers;
        }
        coApplicantGrid.DataBind();
        pnlSecApplicantEmpty.Visible = (prSaleDetailDTO.CoCustomers == null || prSaleDetailDTO.CoCustomers.Count == 0);
    }
    private void assignUiIndexToCoApplicant(ISet<CoCustomerDTO> CocustomerDtos)
    {
        if (CocustomerDtos != null && CocustomerDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (CoCustomerDTO cocustomerDto in CocustomerDtos)
            {
                cocustomerDto.FullName = CommonUIConverter.getCustomerFullName(cocustomerDto.SalutationId.Name, cocustomerDto.FirstName, "", cocustomerDto.LastName);
                cocustomerDto.UiIndex = uiIndex++;
                cocustomerDto.RowInfo = CommonUIConverter.getGridViewRowInfo(cocustomerDto);
            }
        }
    }
    private void populateAddressGrid(ContactInfoDTO conactInfoDto)
    {
        addressGrid.DataSource = new List<AddressDTO>();
        if (conactInfoDto != null)
        {
            assignUiIndexToAddress(conactInfoDto.Addresses);
            addressGrid.DataSource = conactInfoDto.Addresses;
        }
        addressGrid.DataBind();
        pnlAddressEmpty.Visible = (conactInfoDto.Addresses == null || conactInfoDto.Addresses.Count == 0);
    }

    private void assignUiIndexToAddress(ISet<AddressDTO> addressDtos)
    {
        if (addressDtos != null && addressDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (AddressDTO addressDto in addressDtos)
            {
                addressDto.UiIndex = uiIndex++;
                addressDto.UiFullAddress = CommonUIConverter.getUiFullAddress(addressDto);
            }
        }
    }
    private void populateParkingGrid(PrUnitSaleDetailDTO prSaleDetailDTO)
    {
        parkingGrid.DataSource = new List<AddressDTO>();
        if (prSaleDetailDTO != null)
        {
            assignUiIndexToParking(prSaleDetailDTO.PrParkings);
            parkingGrid.DataSource = prSaleDetailDTO.PrParkings;
        }
        parkingGrid.DataBind();
        pnlParkingEmpty.Visible = (prSaleDetailDTO.PrParkings == null || prSaleDetailDTO.PrParkings.Count == 0);
    }

    private void assignUiIndexToParking(ISet<PropertyParkingDTO> parkingDtos)
    {
        if (parkingDtos != null && parkingDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (PropertyParkingDTO parkingDto in parkingDtos)
            {
                parkingDto.UiIndex = uiIndex++;
                parkingDto.RowInfo = CommonUIConverter.getGridViewRowInfo(parkingDto);
            }
        }
    }
    private void populateSalePymtGrid(PrUnitSaleDetailDTO prUnitSaleDetailDTO)
    {
        paymentGrid.DataSource = new List<PrUnitSalePymtDTO>();
        if (prUnitSaleDetailDTO != null && prUnitSaleDetailDTO.PrUnitSalePymts != null)
        {
            assignUiIndexToSalePymts(prUnitSaleDetailDTO.PrUnitSalePymts);
            paymentGrid.DataSource = prUnitSaleDetailDTO.PrUnitSalePymts;
        }
        paymentGrid.DataBind();
    }
    private void assignUiIndexToSalePymts(ISet<PrUnitSalePymtDTO> salePymtDtos)
    {
        if (salePymtDtos != null && salePymtDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (PrUnitSalePymtDTO salePymtDto in salePymtDtos)
            {
                salePymtDto.UiIndex = uiIndex++;
                salePymtDto.RowInfo = CommonUIConverter.getGridViewRowInfo(salePymtDto);
            }
        }
    }
    private SoldUnitDetailNavDTO getCurrentPageNavigation()
    {
        PrUnitSaleDetailDTO prUnitSaleDTO = getSoldUnitDetails();
        SoldUnitDetailNavDTO navDTO = new SoldUnitDetailNavDTO();
        navDTO.Mode = EnumHelper.ToEnum<PageMode>(pageModeHdn.Value);
        navDTO.PrUnitSaleDetailId = prUnitSaleDTO.Id;
        return navDTO;
    }
    protected void onClickNavToPymtHistory(object sender, EventArgs e)
    {
        try
        {
            PrUnitSaleDetailDTO prUnitSaleDTO = getSoldUnitDetails();
            CustomerPymtHistoryNavDTO navDTO = new CustomerPymtHistoryNavDTO();
            navDTO.PrUnitSaleDetailId = prUnitSaleDTO.Id;
            navDTO.PymtMode = PaymentMode.Receivable;
            navDTO.PrevNavDto = getCurrentPageNavigation();
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.CUSTOMER_PYMT_HISTORY, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifySoldUnitBtn(object sender, EventArgs e)
    {
        try
        {
            PrUnitSaleDetailDTO prUnitSaleDTO = getSoldUnitDetails();
            SoldUnitDetailNavDTO navDTO = new SoldUnitDetailNavDTO();
            navDTO.Mode = PageMode.MODIFY;
            navDTO.PrUnitSaleDetailId = prUnitSaleDTO.Id;
            navDTO.PrevNavDto = getSessionPageData().PrevNavDTO;
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.SOLD_UNIT_DETAILS, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Next-Previous actions
    protected void goToStep(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            string stepToJump = rd.Attributes["data-step"];
            List<string> stepsToValidate = CommonUtil.getStepsToValidate(activeStepHdn.Value, stepToJump);
            bool isValid = true;
            foreach (string step in stepsToValidate) {
                if (!validateGoToStep(step))
                {
                    isValid = false;
                    break;
                }
            }
            if (isValid)
            {
                setCurrentStep(stepToJump);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void modifySoldUnitDetails(object sender, EventArgs e)
    {
        try
        {
            if (validateSoldUnitSubmit())
            {
                PrUnitSaleDetailDTO prUnitSaleDetailDTO = populatePropertySaleDTOFromUI(getSoldUnitDetails());
                soldUnitBO.UpdateSoldPropertyUnitDetails(prUnitSaleDetailDTO);
                Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg(string.Format("Booking #{0} details are updated successfully.", prUnitSaleDetailDTO.BookingRefNo)));
                //Navigate to same page in VIEW mode
                SoldUnitDetailNavDTO navDTO = new SoldUnitDetailNavDTO();
                navDTO.Mode = PageMode.VIEW;
                navDTO.PrUnitSaleDetailId = prUnitSaleDetailDTO.Id;
                navDTO.PrevNavDto = getSessionPageData().PrevNavDTO;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.SOLD_UNIT_DETAILS, true);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateSoldUnitSubmit()
    {
        return validateStep1() && validateStep2() && validateStep2();
    }
    private bool validateGoToStep(string jumpTo)
    {
        bool isValid = true;
        if (jumpTo.Equals(step1))
        {
            isValid = validateStep1();
        }
        else if (jumpTo.Equals(step2))
        {
            isValid = validateStep2();
        }
        else if (jumpTo.Equals(step3))
        {
            isValid = validateStep3();
        }
        return isValid;
    }
    private bool validateStep1() {
        return validateMandatoryFields(soldUnitStep1Error, step1) && validateAddressMandatory();
    }
    private bool validateStep2() {
        bool isValid = validateMandatoryFields(soldUnitStep2Error, step2);
        if(isValid) {
            decimal agreementValue = CommonUtil.getDecimaNotNulllWithoutExt(txtAgreementValue.Text);
            if (agreementValue <= 0)
            {
                setErrorMessage(Resources.Messages.AGREEMENT_AMOUNT_REQUIRED, soldUnitStep2Error);
                return false;
            }
            string errorMsg = CommonValidations.validateUnitSaleDates(DateUtil.getCSDateNotNull(txtBookingDate.Text), DateUtil.getCSDate(txtPossesionDate.Text),
                DateUtil.getCSDate(txtAgreementDate.Text), txtAgreementNo.Text, getAgreementDoneUIValue(), getPossessionDoneUIValue());
            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                setErrorMessage(errorMsg, soldUnitStep3Error);
                return false;
            }
        }
        return isValid;
    }
    private bool validateStep3() {
        return validateMandatoryFields(soldUnitStep3Error, step3);
    }
    private bool validateMandatoryFields(string valGrp, string step)
    {
        Page.Validate(valGrp);
        bool isValid = Page.IsValid;
        if (!isValid)
        {
            if (!string.IsNullOrWhiteSpace(step)) setCurrentStep(step);
        }
        return isValid;
    }
    private bool validateAddressMandatory() {
        bool isValid = true;
        List<AddressDTO> addressList = getSoldUnitDetails().Customer.ContactInfo.Addresses.ToList<AddressDTO>();
        if (addressList == null || addressList.Count == 0) {
            setErrorMessage(Resources.Messages.ADDRESS_MANDATORY, soldUnitStep1Error);
            isValid = false;
        } else {
            int preferredCount = 0;
            foreach(AddressDTO addressDto in addressList) {
                if(PreferredAddress.Yes == addressDto.PreferredAddress) preferredCount++;
            }
            if(preferredCount == 0) {
                setErrorMessage(Resources.Messages.PRIMARY_ADDRESS_MANDATORY, soldUnitStep1Error);
                isValid = false;
            } else if(preferredCount > 1) {
                setErrorMessage(Resources.Messages.PRIMARY_ADDRESS_MULTIPLE_NOT_ALLOWED, soldUnitStep1Error);
                isValid = false;
            }
        }
        return isValid;
    }
    private void setCurrentStep(string step)
    {
        activeStepHdn.Value = step;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    protected void reCalculateTotal(object sender, EventArgs e)
    {
        try
        {
            calculateAllSaleAmounts(getSoldUnitDetails());
            scrollToFieldHdn.Value = txtAgreementValue.ID;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private PrUnitSaleDetailDTO populatePropertySaleDTOFromUI(PrUnitSaleDetailDTO prUnitSaleDetailDto)
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        //Page 1 Details
        populateCustomerDTOFromUI(prUnitSaleDetailDto.Customer);
        //Page 2 Details
        prUnitSaleDetailDto.SaleRate = CommonUtil.getDecimaNotNulllWithoutExt(txtBookingRate.Text);
        prUnitSaleDetailDto.AgreementAmt = CommonUtil.getDecimaNotNulllWithoutExt(txtAgreementValue.Text);
        prUnitSaleDetailDto.TotalTaxAmt = CommonUtil.getDecimaNotNulllWithoutExt(lbBookTotalTax.Text);
        prUnitSaleDetailDto.TotalPymtAmt = CommonUtil.getDecimaNotNulllWithoutExt(lbBookTotalUnitCost.Text);
        prUnitSaleDetailDto.TotalPackageCost = prUnitSaleDetailDto.TotalPymtAmt;
        prUnitSaleDetailDto.PrUnitSaleTaxDetails = new HashSet<PrUnitSaleTaxDetailDTO>();
        prUnitSaleDetailDto.uiTaxDetails.ForEach(t => prUnitSaleDetailDto.PrUnitSaleTaxDetails.Add(t));
        prUnitSaleDetailDto.uiCMTaxDetails.ForEach(t => prUnitSaleDetailDto.PrUnitSaleTaxDetails.Add(t));
        //Page 3 Details
        prUnitSaleDetailDto.IsAgreementDone = getAgreementDoneUIValue();
        prUnitSaleDetailDto.AgreementDate = DateUtil.getCSDate(txtAgreementDate.Text);
        prUnitSaleDetailDto.AgreementNo = txtAgreementNo.Text;
        prUnitSaleDetailDto.IsPossessionDone = getPossessionDoneUIValue();
        prUnitSaleDetailDto.PossessionDate = DateUtil.getCSDate(txtPossesionDate.Text);
        prUnitSaleDetailDto.LoanBankName = txtLoanBankName.Text;
        prUnitSaleDetailDto.LoanBankBranch = txtLoanBranch.Text;
        prUnitSaleDetailDto.LoanAmt = CommonUtil.getDecimalWithoutExt(txtLoanAmount.Text);
        

        return prUnitSaleDetailDto;
    }
    //TaxDetail Combined Table actions - Start
    private bool isCMTax()
    {
        return ("CMTax").Equals(taxTypeHdnBtn.Value);
    }
    private void initTaxDetailSectionFields()
    {
        populateDrpTaxType();
        drpTaxType.ClearSelection();
        txtTaxRate.Text = "0.00";
        txtTaxLimit.Text = null;
        txtTaxAmount.Text = null;
        SetFocus(drpTaxType);
    }
    private bool populateDrpTaxType()
    {
        bool hasTax = false;
        PropertyDTO propertyDTO = getSoldUnit().PropertyTower.Property;
        drpTaxType.Items.Clear();
        drpTaxType.Items.Insert(0, new ListItem(Constants.SELECT_ITEM[0], Constants.SELECT_ITEM[1]));
        if (propertyDTO.PropertyTaxDetails != null && propertyDTO.PropertyTaxDetails.Count > 0)
        {
            PrUnitSaleDetailDTO prUnitSaleDetailDTO = getSoldUnitDetails();
            foreach (PropertyTaxDetailDTO propertyTaxDetailDto in propertyDTO.PropertyTaxDetails)
            {
                if (!(prUnitSaleDetailDTO.uiTaxDetails.Any(t => t.TaxType.Id == propertyTaxDetailDto.TaxType.Id)
                        || prUnitSaleDetailDTO.uiCMTaxDetails.Any(t => t.TaxType.Id == propertyTaxDetailDto.TaxType.Id)))
                {
                    drpTaxType.Items.Add(new ListItem(propertyTaxDetailDto.TaxType.Name, propertyTaxDetailDto.TaxType.Id.ToString()));
                    hasTax = true;
                }
            }
        }
        return hasTax;
    }
    protected void onClickAddTaxDetailBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            taxTypeHdnBtn.Value = rd.Attributes["data-taxsection"];
            if (populateDrpTaxType())
            {
                initTaxDetailSectionFields();
                activeModalHdn.Value = taxDetailModal;
            }
            else
            {
                setNotyMsg(CommonUtil.getNotyErrorMsg("Tax type not available for Add."));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void deleteTaxDetail(object sender, EventArgs e)
    {
        try
        {
            Button rd = (Button)sender;
            taxTypeHdnBtn.Value = rd.Attributes["data-taxsection"];
            long selectedIndex = getDeleteRecordHdnId();
            PrUnitSaleDetailDTO prUnitSaleDetailDTO = getSoldUnitDetails();
            PrUnitSaleTaxDetailDTO taxDetailDto = null;
            if (isCMTax())
            {
                taxDetailDto = prUnitSaleDetailDTO.uiCMTaxDetails.Find(c => c.UiIndex == selectedIndex);
                prUnitSaleDetailDTO.uiCMTaxDetails.Remove(taxDetailDto);
            }
            else
            {
                taxDetailDto = prUnitSaleDetailDTO.uiTaxDetails.Find(c => c.UiIndex == selectedIndex);
                prUnitSaleDetailDTO.uiTaxDetails.Remove(taxDetailDto);
            }
            calculateAllSaleAmounts(prUnitSaleDetailDTO);
            setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_DELETED_FROM_TABLE, "Tax Detail")));
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onTaxRateChanged(object sender, EventArgs e)
    {
        try
        {
            if(activeModalHdn.Value.Equals(step2)) activeModalHdn.Value = taxDetailModal;
            if (!(string.IsNullOrWhiteSpace(drpTaxType.Text) || string.IsNullOrWhiteSpace(txtTaxRate.Text)))
            {
                decimal agreementValue = CommonUtil.getDecimaNotNulllWithoutExt(txtAgreementValue.Text);
                decimal taxPercentage = Decimal.Divide(CommonUtil.getDecimaNotNulllWithoutExt(txtTaxRate.Text), 100);
                decimal tmpTaxLimit = CommonUtil.getDecimaNotNulllWithoutExt(txtTaxLimit.Text);
                decimal taxAmt = Math.Round(Decimal.Multiply(agreementValue, taxPercentage), 2);
                if (tmpTaxLimit > 0 && taxAmt > tmpTaxLimit) taxAmt = tmpTaxLimit;
                txtTaxAmount.Text = taxAmt.ToString();
            }
            else
            {
                txtTaxAmount.Text = null;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), taxDetailModalError);
        }
    }
    protected void onTaxTypeChanged(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = taxDetailModal;
            if (!string.IsNullOrWhiteSpace(drpTaxType.Text))
            {
                PropertyDTO propertyDTO = getSoldUnit().PropertyTower.Property;
                long selectedTaxId = long.Parse(drpTaxType.Text);
                PropertyTaxDetailDTO selectedTaxDetailDto = propertyDTO.PropertyTaxDetails.FirstOrDefault(t => t.TaxType.Id == selectedTaxId);
                decimal agreementValue = CommonUtil.getDecimaNotNulllWithoutExt(txtAgreementValue.Text);
                decimal tmpPercentage = Decimal.Divide(selectedTaxDetailDto.TaxPercentage, 100);
                decimal taxAmt = Math.Round(Decimal.Multiply(agreementValue, tmpPercentage), 2);
                if (selectedTaxDetailDto.TaxAmtLimit > 0 && taxAmt > selectedTaxDetailDto.TaxAmtLimit) taxAmt = selectedTaxDetailDto.TaxAmtLimit;
                txtTaxRate.Text = selectedTaxDetailDto.TaxPercentage.ToString();
                txtTaxLimit.Text = selectedTaxDetailDto.TaxAmtLimit.ToString();
                txtTaxAmount.Text = taxAmt.ToString();
            }
            else
            {
                txtTaxRate.Text = null;
                txtTaxLimit.Text = null;
                txtTaxAmount.Text = null;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), taxDetailModalError);
        }
    }
    protected void addNewTaxDetail(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            if (validateMandatoryFields(taxDetailModalError, ""))
            {
                PrUnitSaleDetailDTO prUnitSaleDetailDTO = getSoldUnitDetails();
                populatePropertyTaxDetailAdd(prUnitSaleDetailDTO, isCMTax());
                calculateAllSaleAmounts(prUnitSaleDetailDTO);
                setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_ADDED_TO_TABLE, "Tax Detail")));
                activeModalHdn.Value = "";
            }
            else
            {
                activeModalHdn.Value = taxDetailModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelTaxDetailModal(object sender, EventArgs e)
    {
        try
        {
            taxTypeHdnBtn.Value = "";
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void populatePropertyTaxDetailAdd(PrUnitSaleDetailDTO prUnitSaleDetailDTO, bool isCMTaxSection)
    {
        PropertyDTO propertyDTO = getSoldUnit().PropertyTower.Property;
        long selectedTaxId = long.Parse(drpTaxType.Text);
        PropertyTaxDetailDTO selectedTaxDetailDto = propertyDTO.PropertyTaxDetails.FirstOrDefault(t => t.TaxType.Id == selectedTaxId);
        PrUnitSaleTaxDetailDTO taxDetailDto = populatePrSaleTaxDetail(selectedTaxDetailDto);
        taxDetailDto.TaxPercentage = CommonUtil.getDecimaNotNulllWithoutExt(txtTaxRate.Text);
        taxDetailDto.TaxAmtLimit = CommonUtil.getDecimaNotNulllWithoutExt(txtTaxLimit.Text);
        taxDetailDto.TaxAmt = CommonUtil.getDecimaNotNulllWithoutExt(txtTaxAmount.Text);
        taxDetailDto.UpdateUser = getUserDefinitionDTO().Username;
        if (isCMTaxSection)
        {
            taxDetailDto.IncludeInTotalPymt = IncludeInPymtTotal.No;
            prUnitSaleDetailDTO.uiCMTaxDetails.Add(taxDetailDto);
        }
        else
        {
            taxDetailDto.IncludeInTotalPymt = IncludeInPymtTotal.Yes;
            prUnitSaleDetailDTO.uiTaxDetails.Add(taxDetailDto);
        }
    }
    private void calculateAllSaleAmounts(PrUnitSaleDetailDTO prUnitSaleDetailDto)
    {
        decimal agreementValue = CommonUtil.getDecimaNotNulllWithoutExt(txtAgreementValue.Text);
        decimal totalTax = Decimal.Zero;
        decimal salePymtAmt = Decimal.Zero;
        foreach (PrUnitSaleTaxDetailDTO prUnitSaleTaxDetailDto in prUnitSaleDetailDto.uiTaxDetails)
        {
            decimal tmpPercentage = Decimal.Divide(prUnitSaleTaxDetailDto.TaxPercentage, 100);
            decimal taxAmt = Math.Round(Decimal.Multiply(agreementValue, tmpPercentage), 2);
            if (prUnitSaleTaxDetailDto.TaxAmtLimit > 0 && taxAmt > prUnitSaleTaxDetailDto.TaxAmtLimit) taxAmt = prUnitSaleTaxDetailDto.TaxAmtLimit;
            prUnitSaleTaxDetailDto.TaxAmt = taxAmt;
            totalTax = totalTax + taxAmt;
        }
        salePymtAmt = totalTax + agreementValue;
        lbBookTotalTax.Text = totalTax.ToString();
        lbBookTotalUnitCost.Text = salePymtAmt.ToString();
        foreach (PrUnitSaleTaxDetailDTO prUnitSaleTaxDetailDto in prUnitSaleDetailDto.uiCMTaxDetails)
        {
            decimal tmpPercentage = Decimal.Divide(prUnitSaleTaxDetailDto.TaxPercentage, 100);
            decimal taxAmt = Math.Round(Decimal.Multiply(agreementValue, tmpPercentage), 2);
            if (prUnitSaleTaxDetailDto.TaxAmtLimit > 0 && taxAmt > prUnitSaleTaxDetailDto.TaxAmtLimit) taxAmt = prUnitSaleTaxDetailDto.TaxAmtLimit;
            prUnitSaleTaxDetailDto.TaxAmt = taxAmt;
        }
        populateTaxDetailGrid(prUnitSaleDetailDto);
        populateCMTaxDetailGrid(prUnitSaleDetailDto);
        updateSalePaymentAmount(prUnitSaleDetailDto, salePymtAmt);
    }
    private void updateSalePaymentAmount(PrUnitSaleDetailDTO prUnitSaleDetailDto, decimal salePymtAmt) {
        PrUnitSalePymtDTO prUnitSalePymtDto = prUnitSaleDetailDto.PrUnitSalePymts.ToList<PrUnitSalePymtDTO>().Find(x => isSalePayment(x.PymtType.Name));
        if(prUnitSalePymtDto.PaymentMaster.TotalPaid.CompareTo(salePymtAmt) < 0) {
            //TODO - warning -> Customer has paid more than total sale payment.
        }
        prUnitSalePymtDto.PymtAmt = salePymtAmt;
        prUnitSalePymtDto.PaymentMaster.TotalAmt = salePymtAmt;
        decimal totalPending = prUnitSalePymtDto.PaymentMaster.TotalAmt - prUnitSalePymtDto.PaymentMaster.TotalPaid;
        if(totalPending > 0) {
            prUnitSalePymtDto.PaymentMaster.TotalPending = totalPending;
            prUnitSalePymtDto.PaymentMaster.Status = PymtMasterStatus.Pending;
        } else {
            prUnitSalePymtDto.PaymentMaster.TotalPending = 0;
            prUnitSalePymtDto.PaymentMaster.Status = PymtMasterStatus.Paid;
        }
        populateSalePymtGrid(prUnitSaleDetailDto);
    }
    //Master Data Modal save logic - Start
    protected void saveMasterData(object sender, EventArgs e)
    {
        try
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (Constants.MCDType.OCCUPATION.Equals(masterDataModalTypeHdn.Value))
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.OCCUPATION, txtMasterDataInput1.Text,
                       txtMasterDataInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Occupation");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpCustOccupation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.OCCUPATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    CommonUtil.copyDropDownItems(drpCoCustOccupation, drpCustOccupation);
                }
            }
            else if (Constants.MCDType.PR_UNIT_PYMT_TYPE.Equals(masterDataModalTypeHdn.Value))
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_UNIT_PYMT_TYPE, txtMasterDataInput1.Text,
                       txtMasterDataInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Payment Type");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpAllPaymentType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_PYMT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    populateDrpPaymentType();
                }
            }
            else if (Constants.MCDType.RELATION_WITH_CUSTOMER.Equals(masterDataModalTypeHdn.Value))
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.RELATION_WITH_CUSTOMER, txtMasterDataInput1.Text,
                       txtMasterDataInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Relation With Customer");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpRelationWithCust, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.RELATION_WITH_CUSTOMER, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
            }
            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                activeModalHdn.Value = addMasterDataModal;
                setErrorMessage(errorMsg, addMasterDataError);
            }
            else
            {
                resetMasterDataModalFields();
                setParentModalFlag();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            activeModalHdn.Value = "";
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    protected void cancelMasterDataModal(object sender, EventArgs e)
    {
        try
        {
            resetMasterDataModalFields();
            setParentModalFlag();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    private void resetMasterDataModalFields()
    {
        txtMasterDataInput1.Text = "";
        txtMasterDataInput2.Text = "";
        masterDataModalTypeHdn.Value = "";
    }
    private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
    {
        string errorMsg = "";
        if (string.IsNullOrWhiteSpace(masterDataDto.Name))
        {
            errorMsg = string.Format(Resources.Messages.TEXTFIELD_REQUIRED, type);
        }
        else if (masterDataBO.isAlreadyExist(masterDataDto))
        {
            errorMsg = string.Format(Resources.Messages.ALREADY_EXIST_DB_ERROR, type);
        }
        return errorMsg;
    }
    private void setParentModalFlag()
    {
        activeModalHdn.Value = masterDataParentModalHdn.Value;
        masterDataParentModalHdn.Value = "";
    }
    //Master Data Modal save logic - End
    //Co-Applicant and POA Modal - Start
    private void initCoApplicantModalFields()
    {
        lbCoApplicantModalTitle.Text = (CoApplicantAction.ADD.ToString().Equals(coApplicantModalActionHdnBtn.Value)) 
            ? Constants.ICON.ADD + Resources.Labels.ADD_CO_APPLICANT_OR_POA : Constants.ICON.MODIFY + Resources.Labels.MODIFY_CO_APPLICANT_OR_POA;
    }
    private void initCoApplicantSectionFields(CoCustomerDTO coCustomerDTO)
    {
        if (coCustomerDTO != null && coCustomerDTO.SalutationId != null) drpCoCustSalutation.Text = coCustomerDTO.SalutationId.Id.ToString(); else drpCoCustSalutation.ClearSelection();
        if (coCustomerDTO != null) txtCoCustFirstName.Text = coCustomerDTO.FirstName; else txtCoCustFirstName.Text = null;
        if (coCustomerDTO != null) txtCoCustMiddleName.Text = coCustomerDTO.MiddleName; else txtCoCustMiddleName.Text = null;
        if (coCustomerDTO != null) txtCoCustLastName.Text = coCustomerDTO.LastName; else txtCoCustLastName.Text = null;
        if (coCustomerDTO != null && coCustomerDTO.ContactInfo.Gender != null) drpCoCustGender.Text = coCustomerDTO.ContactInfo.Gender.ToString(); else drpCoCustGender.ClearSelection();
        if (coCustomerDTO != null && coCustomerDTO.ContactInfo.Dob != null) txtCoCustDOB.Text = coCustomerDTO.ContactInfo.Dob.Value.ToString(Constants.DATE_FORMAT); else txtCoCustDOB.Text = null;
        if (coCustomerDTO != null && coCustomerDTO.ContactInfo.MaritalStatus != null) drpCoCustMaritalStatus.Text = coCustomerDTO.ContactInfo.MaritalStatus.ToString(); else drpCoCustMaritalStatus.ClearSelection();
        if (coCustomerDTO != null) txtCoCustContact.Text = coCustomerDTO.ContactInfo.Contact; else txtCoCustContact.Text = null;
        if (coCustomerDTO != null) txtCoCustAlternateContact.Text = coCustomerDTO.ContactInfo.AltContact; else txtCoCustAlternateContact.Text = null;
        if (coCustomerDTO != null) txtCoCustEmail.Text = coCustomerDTO.ContactInfo.Email; else txtCoCustEmail.Text = null;
        if (coCustomerDTO != null) txtCoCustAltEmail.Text = coCustomerDTO.ContactInfo.AltEmail; else txtCoCustAltEmail.Text = null;
        if (coCustomerDTO != null && coCustomerDTO.Occupation != null) drpCoCustOccupation.Text = coCustomerDTO.Occupation.Id.ToString(); else drpCoCustOccupation.ClearSelection();
        if (coCustomerDTO != null) txtCoCustPan.Text = coCustomerDTO.Pan; else txtCoCustPan.Text = null;
        if (coCustomerDTO != null && coCustomerDTO.RelationWhPrimCust != null) drpRelationWithCust.Text = coCustomerDTO.RelationWhPrimCust.Id.ToString(); else drpRelationWithCust.ClearSelection();
        if (coCustomerDTO != null && coCustomerDTO.IsPoa != null) drpPowerOfAttorney.Text = coCustomerDTO.IsPoa.ToString(); else drpPowerOfAttorney.ClearSelection();
    }
    private void populateCoApplicantFromUI(CoCustomerDTO coCustomerDTO)
    {
        coCustomerDTO.SalutationId = CommonUIConverter.getMasterControlDTO(drpCoCustSalutation.Text, drpCoCustSalutation.SelectedItem.Text);
        coCustomerDTO.FirstName = txtCoCustFirstName.Text;
        coCustomerDTO.MiddleName = txtCoCustMiddleName.Text;
        coCustomerDTO.LastName = txtCoCustLastName.Text;
        coCustomerDTO.FullName = CommonUIConverter.getCustomerFullName(coCustomerDTO.FirstName, coCustomerDTO.LastName);
        coCustomerDTO.ContactInfo.Gender = EnumHelper.ToEnumNullable<Gender>(drpCoCustGender.Text);
        coCustomerDTO.ContactInfo.Dob = DateUtil.getCSDateNotNull(txtCoCustDOB.Text);
        coCustomerDTO.ContactInfo.MaritalStatus = EnumHelper.ToEnumNullable<MaritalStatus>(drpCoCustMaritalStatus.Text);
        coCustomerDTO.ContactInfo.Contact = txtCoCustContact.Text;
        coCustomerDTO.ContactInfo.AltContact = txtCoCustAlternateContact.Text;
        coCustomerDTO.ContactInfo.Email = txtCoCustEmail.Text;
        coCustomerDTO.ContactInfo.AltEmail = txtCoCustAltEmail.Text;
        coCustomerDTO.Pan = txtCoCustPan.Text;
        coCustomerDTO.Occupation = CommonUIConverter.getMasterControlDTO(drpCoCustOccupation.Text, drpCoCustOccupation.SelectedItem.Text);
        coCustomerDTO.RelationWhPrimCust = CommonUIConverter.getMasterControlDTO(drpRelationWithCust.Text, drpRelationWithCust.SelectedItem.Text);
        coCustomerDTO.IsPoa = EnumHelper.ToEnumNullable<PowerOfAtorny>(drpPowerOfAttorney.Text);
    }
    private CoCustomerDTO populateCoApplicantAdd()
    {
        CoCustomerDTO coCustomerDTO = new CoCustomerDTO();
        coCustomerDTO.ContactInfo = new ContactInfoDTO();
        coCustomerDTO.FirmNumber = getUserDefinitionDTO().FirmNumber;
        return coCustomerDTO;
    }
    private void setSelectedCoApplicant(long UiIndex) {
        List<CoCustomerDTO> applicantList = getSoldUnitDetails().CoCustomers.ToList<CoCustomerDTO>();
        applicantList.ForEach(c => c.isUISelected = false);
        if (UiIndex > 0) applicantList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
    }
    private CoCustomerDTO getSelectedCoApplicant(long UiIndex)
    {
        List<CoCustomerDTO> applicantList = getSoldUnitDetails().CoCustomers.ToList<CoCustomerDTO>();
        return (UiIndex > 0) ? applicantList.Find(c => c.UiIndex == UiIndex) : applicantList.Find(c => c.isUISelected);
    }
    protected void onClickAddCoApplicantBtn(object sender, EventArgs e)
    {
        try
        {
            coApplicantModalActionHdnBtn.Value = CoApplicantAction.ADD.ToString();
            initCoApplicantModalFields();
            setSelectedCoApplicant(-1);
            initCoApplicantSectionFields(null);
            activeModalHdn.Value = addModifyCoApplicantModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyCoApplicantBtn(object sender, EventArgs e)
    {
        try
        {
            coApplicantModalActionHdnBtn.Value = CoApplicantAction.MODIFY.ToString();
            initCoApplicantModalFields();
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedCoApplicant(selectedIndex);
            initCoApplicantSectionFields(getSelectedCoApplicant(0));
            activeModalHdn.Value = addModifyCoApplicantModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void deleteCoApplicant(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            CoCustomerDTO coCustomerDTO = getSelectedCoApplicant(selectedIndex);
            getSoldUnitDetails().CoCustomers.Remove(coCustomerDTO);
            populateCoApplicantGrid(getSoldUnitDetails());
            setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECORD_DELETE_SUCCESS, (PowerOfAtorny.Yes == coCustomerDTO.IsPoa) ? "POA" : "Co-Applicant")));
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void saveCoApplicant(object sender, EventArgs e)
    {
        try
        {
            if (validateCoApplicantAddModify())
            {
                CoCustomerDTO coCustomerDTO = null;
                string msg = "";
                if (CoApplicantAction.ADD.ToString().Equals(coApplicantModalActionHdnBtn.Value))
                {
                    coCustomerDTO = populateCoApplicantAdd();
                    getSoldUnitDetails().CoCustomers.Add(coCustomerDTO);
                    msg = string.Format(Resources.Messages.RECORD_ADDED_SUCCESS, (PowerOfAtorny.Yes.ToString().Equals(drpPowerOfAttorney.Text)) ? "POA" : "Co-Applicant");
                }
                else
                {
                    coCustomerDTO = getSelectedCoApplicant(0);
                    msg = string.Format(Resources.Messages.RECORD_MODIFY_SUCCESS, (PowerOfAtorny.Yes.ToString().Equals(drpPowerOfAttorney.Text)) ? "POA" : "Co-Applicant");
                }
                populateCoApplicantFromUI(coCustomerDTO);
                populateCoApplicantGrid(getSoldUnitDetails());
                setNotyMsg(CommonUtil.getNotySuccessMsg(msg));
            }
            else
            {
                activeModalHdn.Value = addModifyCoApplicantModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelCoApplicantModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateCoApplicantAddModify()
    {
        bool isValid = true;
        Page.Validate(addModifyCoApplicantError);
        return Page.IsValid;
    }
    //Co-Applicant and POA Modal - End
    //Address Modal - Start
    protected void loadAddressCities(object sender, EventArgs e)
    {
        try
        {
            initCityDrp(drpAddressCity, drpAddressState.Text);
            SetFocus(drpAddressCity);
            activeModalHdn.Value = addModifyAddressModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void initAddressModalFields()
    {
        lbAddressModalTitle.Text = (AddressAction.ADD.ToString().Equals(addressModalActionHdnBtn.Value)) 
            ? Constants.ICON.ADD + Resources.Labels.ADD_ADDRESS : Constants.ICON.MODIFY + Resources.Labels.MODIFY_ADDRESS;
    }
    private void initAddressSectionFields(AddressDTO addressDto)
    {
        if (addressDto != null) txtAddressLine1.Text = addressDto.AddressLine1; else txtAddressLine1.Text = null;
        if (addressDto != null) txtAddressLine2.Text = addressDto.AddressLine2; else txtAddressLine2.Text = null;
        if (addressDto != null) txtTown.Text = addressDto.Town; else txtTown.Text = null;
        if (addressDto != null && addressDto.City != null) drpAddressCity.Text = addressDto.City.Id.ToString(); else drpAddressCity.ClearSelection();
        if (addressDto != null && addressDto.State != null) drpAddressState.Text = addressDto.State.Id.ToString(); else drpAddressState.ClearSelection();
        if (addressDto != null && addressDto.Country != null) drpAddressCountry.Text = addressDto.Country.Id.ToString(); else drpAddressCountry.ClearSelection();
        if (addressDto != null) txtPin.Text = addressDto.Pin; else txtPin.Text = null;
        if (addressDto != null && addressDto.AddressType != null) drpAddressType.Text = addressDto.AddressType.Id.ToString(); else drpAddressType.ClearSelection();
        if (addressDto != null && addressDto.PreferredAddress != null) drpPreferredAddress.Text = addressDto.PreferredAddress.ToString(); else drpPreferredAddress.ClearSelection();
    }
    private void populateAddressFromUI(AddressDTO addressDto)
    {
        addressDto.AddressLine1 = txtAddressLine1.Text;
        addressDto.AddressLine2 = txtAddressLine2.Text;
        addressDto.Town = txtTown.Text;
        addressDto.City = CommonUIConverter.getCityDTO(drpAddressCity.Text, drpAddressCity.SelectedItem.Text);
        addressDto.State = CommonUIConverter.getStateDTO(drpAddressState.Text, drpAddressState.SelectedItem.Text);
        addressDto.Country = CommonUIConverter.getCountryDTO(drpAddressCountry.Text, drpAddressCountry.SelectedItem.Text);
        addressDto.Pin = txtPin.Text;
        addressDto.AddressType = CommonUIConverter.getMasterControlDTO(drpAddressType.Text, drpAddressType.SelectedItem.Text);
        addressDto.PreferredAddress = EnumHelper.ToEnumNullable<PreferredAddress>(drpPreferredAddress.Text);
    }
    private AddressDTO populateAddressAdd()
    {
        AddressDTO addressDto = new AddressDTO();
        return addressDto;
    }
    private void setSelectedAddress(long UiIndex) {
        List<AddressDTO> addressList = getSoldUnitDetails().Customer.ContactInfo.Addresses.ToList<AddressDTO>();
        addressList.ForEach(c => c.isUISelected = false);
        if (UiIndex > 0) addressList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
    }
    private AddressDTO getSelectedAddress(long UiIndex)
    {
        List<AddressDTO> addressList = getSoldUnitDetails().Customer.ContactInfo.Addresses.ToList<AddressDTO>();
        return (UiIndex > 0) ? addressList.Find(c => c.UiIndex == UiIndex) : addressList.Find(c => c.isUISelected);
    }
    protected void onClickAddAddressBtn(object sender, EventArgs e)
    {
        try
        {
            addressModalActionHdnBtn.Value = AddressAction.ADD.ToString();
            initAddressModalFields();
            setSelectedAddress(-1);
            initAddressSectionFields(null);
            activeModalHdn.Value = addModifyAddressModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyAddressBtn(object sender, EventArgs e)
    {
        try
        {
            addressModalActionHdnBtn.Value = AddressAction.MODIFY.ToString();
            initAddressModalFields();
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedAddress(selectedIndex);
            initAddressSectionFields(getSelectedAddress(0));
            activeModalHdn.Value = addModifyAddressModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void deleteAddress(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            AddressDTO addressDTO = getSelectedAddress(selectedIndex);
            getSoldUnitDetails().Customer.ContactInfo.Addresses.Remove(addressDTO);
            populateAddressGrid(getSoldUnitDetails().Customer.ContactInfo);
            setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECORD_DELETE_SUCCESS, "Address")));
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void saveAddress(object sender, EventArgs e)
    {
        try
        {
            if (validateAddressAddModify())
            {
                AddressDTO addressDTO = null;
                string msg = "";
                if (AddressAction.ADD.ToString().Equals(addressModalActionHdnBtn.Value))
                {
                    addressDTO = populateAddressAdd();
                    getSoldUnitDetails().Customer.ContactInfo.Addresses.Add(addressDTO);
                    msg = string.Format(Resources.Messages.RECORD_ADDED_SUCCESS, "Address");
                }
                else
                {
                    addressDTO = getSelectedAddress(0);
                    msg = string.Format(Resources.Messages.RECORD_MODIFY_SUCCESS, "Address");
                }
                populateAddressFromUI(addressDTO);
                populateAddressGrid(getSoldUnitDetails().Customer.ContactInfo);
                setNotyMsg(CommonUtil.getNotySuccessMsg(msg));
            }
            else
            {
                activeModalHdn.Value = addModifyAddressModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelAddressModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateAddressAddModify()
    {
        bool isValid = true;
        Page.Validate(addModifyAddressError);
        return Page.IsValid;
    }
    //Address Modal - End
    //Parking Modal - Start
    private PropertyParkingDTO getSelectedParking(long UiIndex)
    {
        List<PropertyParkingDTO> parkingList = getSoldUnitDetails().PrParkings.ToList<PropertyParkingDTO>();
        return (UiIndex > 0) ? parkingList.Find(c => c.UiIndex == UiIndex) : parkingList.Find(c => c.isUISelected);
    }
    protected void onClickAddParkingBtn(object sender, EventArgs e)
    {
        try
        {
            drpParking.ClearSelection();
            activeModalHdn.Value = addParkingModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void deleteParking(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            PropertyParkingDTO parkingDTO = getSelectedParking(selectedIndex);
            getSoldUnitDetails().PrParkings.Remove(parkingDTO);
            populateParkingGrid(getSoldUnitDetails());
            setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECORD_DELETE_SUCCESS, "Parking")));
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void selectParking(object sender, EventArgs e)
    {
        try
        {
            string modal = addParkingModal;
            if (validateParkingSelection())
            {
                long selectedParking = long.Parse(drpParking.Text);
                PrUnitSaleDetailDTO soldUnitDTO = getSoldUnitDetails();
                if (soldUnitDTO.PrParkings.Any(x => x.Id == selectedParking))
                {
                    setErrorMessage("Selected Parking is already added.", addParkingError);
                }
                else
                {
                    modal = "";
                    PropertyParkingDTO parkignDTO = propertyBO.fetchPropertyParkingDetails(selectedParking);
                    soldUnitDTO.PrParkings.Add(parkignDTO);
                    populateParkingGrid(soldUnitDTO);
                    setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECORD_ADDED_SUCCESS, "Parking")));
                }
            }
            activeModalHdn.Value = modal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelParkingSelectionModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateParkingSelection()
    {
        bool isValid = true;
        Page.Validate(addParkingError);
        return Page.IsValid;
    }
    //Address Modal - End
    //Payment Modal - Start
    private bool isSalePayment(string paymentType)
    {
        return Constants.MCD_SALE_PAYMENT.Equals(paymentType);
    }
    private bool isCancellationPayment(string paymentType)
    {
        return Constants.MCD_CANCELLATION_PAYMENT.Equals(paymentType);
    }
    private void initPaymentModalFields()
    {
        lbPaymentModalTitle.Text = (PaymentAction.ADD.ToString().Equals(paymentModalActionHdnBtn.Value))
            ? Constants.ICON.ADD + Resources.Labels.ADD_PAYMENT : Constants.ICON.MODIFY + Resources.Labels.MODIFY_PAYMENT;
    }
    private void initPaymentSectionFields(PrUnitSalePymtDTO prUnitSalePymtDto)
    {
        bool isAdd = PaymentAction.ADD.ToString().Equals(paymentModalActionHdnBtn.Value);
        bool isModify = PaymentAction.MODIFY.ToString().Equals(paymentModalActionHdnBtn.Value);
        populateDrpPaymentType();
        if (prUnitSalePymtDto != null) drpPaymentType.Text = prUnitSalePymtDto.PymtType.Id.ToString(); else drpPaymentType.ClearSelection();
        if (prUnitSalePymtDto != null) txtPaymentDate.Text = DateUtil.getCSDate(prUnitSalePymtDto.PymtDate); else txtPaymentDate.Text = null;
        if (prUnitSalePymtDto != null) txtPaymentAmount.Text = prUnitSalePymtDto.PymtAmt.ToString(); else txtPaymentAmount.Text = null;
        if (prUnitSalePymtDto != null) drpPaymentMode.Text = prUnitSalePymtDto.PymtMode.ToString(); else drpPaymentMode.ClearSelection();
        if (prUnitSalePymtDto != null) txtPaymentDescription.Text = prUnitSalePymtDto.Description; else txtPaymentDescription.Text = null;

        addPymtTypeBtn.Visible = isAdd;
        drpPaymentType.Enabled = isAdd;
        txtPaymentDate.ReadOnly = !isAdd;
        drpPaymentMode.Enabled = isAdd;
        txtPaymentAmount.ReadOnly = isModify && (isSalePayment(prUnitSalePymtDto.PymtType.Name) || isCancellationPayment(prUnitSalePymtDto.PymtType.Name));
    }
    private void populatePaymentFromUI(PrUnitSalePymtDTO prUnitSalePymtDto)
    {
        bool isAdd = PaymentAction.ADD.ToString().Equals(paymentModalActionHdnBtn.Value);
        bool isModify = PaymentAction.MODIFY.ToString().Equals(paymentModalActionHdnBtn.Value);
        if (isAdd)
        {
            prUnitSalePymtDto.PymtType = CommonUIConverter.getMasterControlDTO(drpPaymentType.Text, drpPaymentType.SelectedItem.Text);
            prUnitSalePymtDto.PymtDate = DateUtil.getCSDateNotNull(txtPaymentDate.Text);
            prUnitSalePymtDto.PymtMode = EnumHelper.ToEnum<PaymentMode>(drpPaymentMode.Text);
        }
        //Can not modify Amount when Sale/Cancellation Payment
        if (isAdd || !(isSalePayment(prUnitSalePymtDto.PymtType.Name) && isCancellationPayment(prUnitSalePymtDto.PymtType.Name)))
        {
            prUnitSalePymtDto.PymtAmt = CommonUtil.getDecimaNotNulllWithoutExt(txtPaymentAmount.Text);
        }
        prUnitSalePymtDto.Description = txtPaymentDescription.Text;
        prUnitSalePymtDto.UpdateUser = getUserDefinitionDTO().Username;
    }
    private void addNewPymtMaster(PrUnitSalePymtDTO prUnitSalePymtDto)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        PaymentMasterDTO paymentMasterDto = new PaymentMasterDTO();
        paymentMasterDto.TotalAmt = Decimal.Zero;
        paymentMasterDto.TotalPaid = Decimal.Zero;
        paymentMasterDto.TotalPending = Decimal.Zero;
        paymentMasterDto.TotalPdcAmt = Decimal.Zero;
        paymentMasterDto.FirmNumber = userDefDto.FirmNumber;
        paymentMasterDto.InsertUser = userDefDto.Username;
        prUnitSalePymtDto.PaymentMaster = paymentMasterDto;
        updatePymtMaster(prUnitSalePymtDto);
    }
    private void updatePymtMaster(PrUnitSalePymtDTO prUnitSalePymtDto)
    {
        PaymentMasterDTO paymentMasterDto = prUnitSalePymtDto.PaymentMaster;
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        decimal diffAmt = Decimal.Subtract(prUnitSalePymtDto.PymtAmt, paymentMasterDto.TotalAmt);
        paymentMasterDto.TotalAmt = Decimal.Add(paymentMasterDto.TotalAmt, diffAmt);
        paymentMasterDto.TotalPending = Decimal.Subtract(paymentMasterDto.TotalAmt, paymentMasterDto.TotalPaid);
        paymentMasterDto.UpdateUser = userDefDto.Username;
        if (paymentMasterDto.TotalPending > 0) paymentMasterDto.Status = PymtMasterStatus.Pending;
        else paymentMasterDto.Status = PymtMasterStatus.Paid;
    }
    private PrUnitSalePymtDTO populatePaymentAdd()
    {
        PrUnitSalePymtDTO prUnitSalePymtDto = new PrUnitSalePymtDTO();
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        prUnitSalePymtDto.FirmNumber = userDef.FirmNumber;
        prUnitSalePymtDto.InsertUser = userDef.Username;
        return prUnitSalePymtDto;
    }
    private void setSelectedPayment(long UiIndex)
    {
        List<PrUnitSalePymtDTO> paymentList = getSoldUnitDetails().PrUnitSalePymts.ToList<PrUnitSalePymtDTO>();
        paymentList.ForEach(c => c.isUISelected = false);
        if (UiIndex > 0) paymentList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
    }
    private PrUnitSalePymtDTO getSelectedPayment(long UiIndex)
    {
        List<PrUnitSalePymtDTO> paymentList = getSoldUnitDetails().PrUnitSalePymts.ToList<PrUnitSalePymtDTO>();
        return (UiIndex > 0) ? paymentList.Find(c => c.UiIndex == UiIndex) : paymentList.Find(c => c.isUISelected);
    }
    protected void onClickAddPaymentBtn(object sender, EventArgs e)
    {
        try
        {
            paymentModalActionHdnBtn.Value = PaymentAction.ADD.ToString();
            initPaymentModalFields();
            setSelectedPayment(-1);
            initPaymentSectionFields(null);
            activeModalHdn.Value = addModifyPaymentModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyPaymentBtn(object sender, EventArgs e)
    {
        try
        {
            paymentModalActionHdnBtn.Value = PaymentAction.MODIFY.ToString();
            initPaymentModalFields();
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedPayment(selectedIndex);
            initPaymentSectionFields(getSelectedPayment(0));
            activeModalHdn.Value = addModifyPaymentModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void deletePayment(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            if (validatePaymentDelete(selectedIndex))
            {
                PrUnitSalePymtDTO prUnitSalePymtDto = getSelectedPayment(selectedIndex);
                PrUnitSaleDetailDTO prUnitSaleDetailDTO = getSoldUnitDetails();
                if (prUnitSalePymtDto.PaymentMaster.Id > 0)
                {
                    prUnitSalePymtDto.PaymentMaster.Status = PymtMasterStatus.Deleted;
                }
                else
                {
                    prUnitSaleDetailDTO.PrUnitSalePymts.Remove(prUnitSalePymtDto);
                }
                populateSalePymtGrid(prUnitSaleDetailDTO);
                setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_DELETED_FROM_TABLE, "Payment")));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void savePayment(object sender, EventArgs e)
    {
        try
        {
            if (validatePaymentAddModify())
            {
                PrUnitSalePymtDTO prUnitSalePymtDto = null;
                PrUnitSaleDetailDTO prUnitSaleDetailDTO = getSoldUnitDetails();
                if (PaymentAction.ADD.ToString().Equals(paymentModalActionHdnBtn.Value))
                {
                    prUnitSalePymtDto = populatePaymentAdd();
                    populatePaymentFromUI(prUnitSalePymtDto);
                    addNewPymtMaster(prUnitSalePymtDto);
                    prUnitSaleDetailDTO.PrUnitSalePymts.Add(prUnitSalePymtDto);
                    setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_ADDED_TO_TABLE, "Payment")));
                }
                else
                {
                    prUnitSalePymtDto = getSelectedPayment(0);
                    populatePaymentFromUI(prUnitSalePymtDto);
                    updatePymtMaster(prUnitSalePymtDto);
                    setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_MODIFIED_TO_TABLE, "Payment")));
                }
                populateSalePymtGrid(prUnitSaleDetailDTO);
            }
            else
            {
                activeModalHdn.Value = addModifyPaymentModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelPaymentModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validatePaymentAddModify()
    {
        bool isValid = true;
        Page.Validate(addModifyPaymentError);
        isValid = Page.IsValid;
        if (PaymentAction.MODIFY.ToString().Equals(paymentModalActionHdnBtn.Value))
        {
            isValid = validatePaymentUpdate(getSelectedPayment(0));
        }
        return isValid;
    }
    private bool validatePaymentDelete(long UiIndex)
    {
        bool isValid = true;
        PrUnitSalePymtDTO prUnitSalePymtDto = getSelectedPayment(UiIndex);
        string errorMsg = "";
        if (prUnitSalePymtDto.PaymentMaster.Status == PymtMasterStatus.Deleted)
        {
            errorMsg = "Payment is already deleted.";
        }
        else if (isSalePayment(prUnitSalePymtDto.PymtType.Name) || isCancellationPayment(prUnitSalePymtDto.PymtType.Name))
        {
            errorMsg = "Deletion of selected Payment type is not allowed.";
        }
        else if (prUnitSalePymtDto.PaymentMaster.TotalPaid > 0)
        {
            errorMsg = "Part of the payment has been made, can not delete selected payment.";
        }
        else if (prUnitSalePymtDto.PaymentMaster.TotalPdcAmt > 0)
        {
            errorMsg = "Post Dated Cheque payment is pending for selected Payment.";
        }
        if (!string.IsNullOrWhiteSpace(errorMsg))
        {
            setNotyMsg(CommonUtil.getNotyErrorMsg(errorMsg));
            isValid = false;
        }
        return isValid;
    }
    private bool validatePaymentUpdate(PrUnitSalePymtDTO prUnitSalePymtDto)
    {
        bool isValid = true;
        decimal pymtAmt = CommonUtil.getDecimaNotNulllWithoutExt(txtPaymentAmount.Text);
        decimal diffAmt = Decimal.Subtract(pymtAmt, prUnitSalePymtDto.PaymentMaster.TotalAmt);
        decimal effectiveAmt = Decimal.Add(prUnitSalePymtDto.PaymentMaster.TotalAmt, diffAmt);
        if (effectiveAmt.CompareTo(prUnitSalePymtDto.PaymentMaster.TotalPaid) < 0)
        {
            setNotyMsg(CommonUtil.getNotyErrorMsg("Payment amount can not be less than Total Paid amount."));
            isValid = false;
        }
        return isValid;
    }
    private void populateDrpPaymentType()
    {
        bool isModify = PaymentAction.MODIFY.ToString().Equals(paymentModalActionHdnBtn.Value);
        drpPaymentType.Items.Clear();
        foreach (ListItem item in drpAllPaymentType.Items)
        {
            if (isModify || !(isSalePayment(item.Text) || isCancellationPayment(item.Text)))
            {
                drpPaymentType.Items.Add(item);
            }
        }
    }
    //Property Charges Modal - End
}