﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initTreeActions(controlToFormat);
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initTreeActions(controlToFormat) {
    $(controlToFormat).find('span.cs-tree-checkbox').on('click', function () {
        var $this = $(this);
        $(controlToFormat).find("[id$='selectedEntitlementHdn']").val($this.attr('data-pid'));
        $(controlToFormat).find("[id$='btnSelectEntitlementHdn']").click();
    });
}