/*
This method is workaround for bug -> Row level action dropdown is clipped by container of datatable.
In this method dropdown in re-positioned at same location but it is no more child of the table.
*/
function bindActionDropdown(controlToFormat) {
	$(controlToFormat).find('.fl-drp').parent().on('shown.bs.dropdown', function () {
        var $menu = $("ul", this);
        offset = $menu.offset();
        position = $menu.position();
        $('body').append($menu);
        $menu.show();
        $menu.css('position', 'absolute');
        $menu.css('top', (offset.top) + 'px');
        $menu.css('left', (offset.left) + 'px');
        $(this).data("myDropdownMenu", $menu);
    });
	$(controlToFormat).find('.fl-drp').parent().on('hide.bs.dropdown', function () {
        $(this).append($(this).data("myDropdownMenu"));
        $(this).data("myDropdownMenu").removeAttr('style');

    });
}
/*
    This function will scoll to the given element (Id) so that it will be at top of the page OR scroller reaches at end. If 'elementId' value is 'TOP' 
    then it scrolls to top of the page.
*/
function scrollToField(elementId, removed_height) {
    var scrollTo = -1;
    if (elementId && elementId != "") {
        if (elementId == "TOP") {
            scrollTo = 0;
        } else {
            var $element = $("[id$='" + elementId + "']");
            if ($element) {
                scrollTo = $("[id$='" + elementId + "']").offset().top - removed_height;
            }
        }
    }
    if (scrollTo != -1) {
        $('html, body').animate({ scrollTop: scrollTo }, 'slow');
    }
}

/**
 * This function will take to the page where 'element' is present with attribute 'index' having value given in 'data'.
 * Usage - dtTable.api().page.jumpToIndex("6"); 
 */
jQuery.fn.dataTable.Api.register('page.jumpToIndex()', function (data) {
    var pos = -1;
    this.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var index = this.nodes().to$().find('.row-identifier').attr('row-identifier');
        if (index == data) {
            pos = rowLoop;
        }
    });
    if (pos >= 0) {
        var page = Math.floor(pos / this.page.info().length);
        this.page(page).draw(false);
    }
});

function formatAutoNumeric(modalBody) {
    var body = (modalBody != "") ? modalBody : 'body';
    //Format input fields as indian currency amount which has class csamount.
    $(body).find('input.csaddresspin').autoNumeric('init', { aSep: '', vMax: 999999, vMin: 0, wEmpty: '' });
    $(body).find('.csnumber').autoNumeric("init", { aSep: ',', aDec: '.', dGroup: 2, vMin: '0', vMax: '100', mDec: 0, aSign: ' ', pSign: 's' });
    $(body).find('.csnumber').attr('placeholder', '');
    $(body).find('.csamount').autoNumeric("init", { aSep: ',', aDec: '.', dGroup: 2, aSign: 'Rs. ' });
    $(body).find('.csamount').attr('placeholder', 'Rs.');
    $(body).find('.cspercentaged3').autoNumeric("init", { aSep: ',', aDec: '.', dGroup: 2, vMin: '0.000', vMax: '100.000', aSign: ' %', pSign: 's' });
    $(body).find('.cspercentaged3').attr('placeholder', '%');
    $(body).find('.cspercentaged0').autoNumeric("init", { aSep: ',', aDec: '.', dGroup: 2, vMin: '0', vMax: '100', mDec: 0, aSign: ' %', pSign: 's' });
    $(body).find('.cspercentaged0').attr('placeholder', '%');
    $(body).find('.cspercentaged2').autoNumeric("init", { aSep: ',', aDec: '.', dGroup: 2, vMin: '0.00', vMax: '100.00', mDec: 0, aSign: ' %', pSign: 's' });
    $(body).find('.cspercentaged2').attr('placeholder', '%');
    $(body).find('.cssqftarea').autoNumeric("init", { aSep: ',', aDec: '.', dGroup: 2, mDec: 3, aSign: ' Sq.Ft. ', pSign: 's' });
    $(body).find('.cssqftarea').attr('placeholder', 'Sq.Ft.');
    $(body).find('.cssqmtarea').autoNumeric("init", { aSep: ',', aDec: '.', dGroup: 2, mDec: 3, vMin: '0.000', vMax: '9999999.000', aSign: ' Sq.Mtr. ', pSign: 's' });
    $(body).find('.cssqmtarea').attr('placeholder', 'Sq.Mtr.');
    $(body).find('.csdocsize').autoNumeric("init", { aSep: ',', dGroup: 3, vMin: 0, mDec: 0, aSign: ' KB', pSign: 's' });
    $(body).find('.csdocsize').attr('placeholder', ' KB');
    $(body).find('td.csamountnotempty').each(function () {
        $this = $(this);
        if ($this.text().trim() != "") $this.autoNumeric("init", { aSep: ',', aDec: '.', dGroup: 2, aSign: 'Rs. ' });
    });
}
function formatFields(controlToFormat) {
    var isPageRendered = (controlToFormat == "div.content-wrapper" || controlToFormat == "body");
    //Format Notification Message
    initNotifications(controlToFormat);
    formatAutoNumeric(controlToFormat);
    //Convert fields as select picker which has class csdrp.
    initDropdown(controlToFormat);
    //Convert fields as date picker which has class csdt.
    initDate(controlToFormat);
    initDateTime(controlToFormat);
    Ladda.bind('.btn-ladda-spinner');
    $(controlToFormat).find("input:radio, .styled").uniform({
        radioClass: 'choice'
    });    
    // Styled file input
    $(controlToFormat).find('.file-styled').uniform({
        fileButtonClass: 'action btn bg-blue'
    });
    //If Inner page is rendered then execute below code specific to that page.
    if (isPageRendered == true) {
        $(controlToFormat).find('.filter-token-field').on('tokenfield:removedtoken', function (e) {
            $(controlToFormat).find("[id$='filterRemoveHdn']").val(e.attrs.value);
            $(controlToFormat).find("[id$='filterHdnBtn']").click();
        }).tokenfield({
        	delimiter: '~'
        });
        $(controlToFormat).find("[id$='-tokenfield']").attr('readonly', 'true');//Make text input readonly
        scrollToField($("[id$='scrollToFieldHdn']").val(), 10);
        $("[id$='scrollToFieldHdn']").val('');
        bindActionDropdown();
        initNotyMsg();
        initFabMenu();
    }
    bindBlockUI(controlToFormat);
    //Fix for Select2 bug -> On selection, focus should stay on select field.
    $(controlToFormat).find('select').on("select2:close", function () { $(this).focus(); });
    //If controlToFormat is section of the page and not body then call below method.
    if (controlToFormat != "body")initHeadingElements(controlToFormat);
    formatBreadcrumb(controlToFormat);
    //If UL icon list dropdown does not have li(action) element then hide them
    hideEmptyDropdownAction(controlToFormat);
    //Select Row when checkbox selected
    selectRow(controlToFormat);
    //Switchery checkbox
    initSwitchery(controlToFormat);
}

function initSwitchery(controlToFormat) {
    $(controlToFormat).find('input.switchery').each(function () {
        $this = $(this);
        var callbackid = $this.attr('data-callbackid');
        if (callbackid) {
            $this.change(function () {
                $(controlToFormat).find("[id$='" + callbackid + "']").click();
            });
        }
        new Switchery(this);
    });
}
function formatBreadcrumb(controlToFormat) {
	$(controlToFormat).find('.cs-breadcrumb').find('li.hidden').remove();
}

function hideEmptyDropdownAction(controlToFormat) {
	$(controlToFormat).find('.hide-if-no-action').each(function() {
        $this = $(this);
        if($this.find('ul.dropdown-menu:has(li)').length == 0) $this.remove();
    });
}

function jumpToTablePage(dtTable, jumpToHdnId) {
    var index = $("[id$='" + jumpToHdnId + "']").val();
    if (index && index != "") {
        dtTable.page.jumpToIndex(index);
        $("[id$='" + jumpToHdnId + "']").val('');
    }
}

function toolTipOnTable(tableId) {
    $("[id$='" + tableId + "']" + ' tbody td').each(function () {
        var $td = $(this);
        $td.attr('title', '');
        $td.attr('title', $td.text());
    });
    /* Apply the tooltips */
    $("[id$='" + tableId + "']" + 'thead th[title]').tooltip({
        "container": 'body'
    });
}

function showInfoModal(element) {
    var infoElement = $(element).parent().find('.row-info,row-info-media').eq(0);
    var tableContent = getViewInfoModalContent($(infoElement).attr('row-info'));
    BootstrapDialog.show({
        title: ICON_VIEW_DTL + $(infoElement).attr('data-info-title'),
        message: tableContent,
        nl2br: false,
        closable: false,
        buttons: [],
        onshown: function (dialogRef) {
            formatAutoNumeric(dialogRef.getModalDialog());
        }
    });
    return false;
}
function getViewInfoModalContent(info) {
    var tableContent = '<table class="table datatable-modal-table"><tbody>' + info;
    var footer = '<tfoot><tr><th style="text-align: center;" colspan=2>' +
                '<button type="button" class="btn btn-teal btn-sm" data-dismiss="modal">Close</button>' +
                '</th></tr></tfoot>';
    tableContent = tableContent + footer + '</table>';
    return tableContent;
}
function getConfirmModalMessage(element) {
    var message = $(element).attr('data-md-message');
    $(element).each(function () {
        $.each(this.attributes, function () {
            if (this.specified) {
                if (this.name.startsWith("data-md-message-opt")) {
                    var index = this.name.split('-').pop();
                    var pos = "{" + index + "}";
                    message = message.split(pos).join(this.value);
                }
            }
        });
    });
    return message;
}
function getConfirmModalHeaderIcon(action) {
    var icon = ICON_DELETE;
    if(CONFIRM == action) icon = ICON_CONFIRM;
    return icon;
}
function confirmActionModal(element) {
    var btnToClick = $(element).attr('data-md-button');
    var action = $(element).attr('data-md-action');
    var actionBtn = $("[id$=" + btnToClick + "]");
    var message = getConfirmModalMessage(element);
    var title = getConfirmModalHeaderIcon(action) + $(element).attr('data-md-title');
    BootstrapDialog.show({
        title: title,
        message: message,
        closable: false,
        buttons: [{
            label: 'Ok',
            icon: 'icon-checkmark4 mr-5 text-size-small',
            cssClass: 'btn btn-teal btn-sm btn-ok',
            action: function (dialogRef) {
                $("[id$='btnDeleteRecordHdnId']").val($(element).attr('data-pid'));
                actionBtn.click();
                dialogRef.close();
            }
        }, {
            label: 'Cancel',
            icon: 'icon-cross2 mr-5 text-size-small',
            cssClass: 'btn btn-teal btn-sm',
            action: function(dialogRef) {
                dialogRef.close();
                Ladda.stopAll();
            }
        }]
    });
    return false;
}
function showModal(controlToFormat) {
    var isPageRendered = (controlToFormat == "div.content-wrapper" || controlToFormat == "body");//Currently only page has modals
	if(isPageRendered == true) {
		$('body').removeClass('modal-open');
	    $('.modal-backdrop').remove();
	    var modalId = $("[id$='activeModalHdn']").val();
	    if (modalId) {
	        if (modalId == "addMasterDataModal") {
	            //If master data commmon modal then invoke modal again to set labels and modal title.
	            invokeMasterDataModal();
	        } else {
	            /*
                * When files are uploaded to temporary folder then they need to show again after partial postback. 'TmpUploadfileCntrlTarget' contains file upload control id.
                * Using this control files are fetched and shown at desired location on UI.
                */
                //TODO - validate whether modal has fileCntrl element present
	            var fileCntrl = $("[id$='TmpUploadfileCntrlTarget']").val();
	            if (fileCntrl && fileCntrl != "") {
	                $("#" + modalId).on('shown.bs.modal', function (e) {
	                    $("[id$='TmpUploadfileCntrlTarget']").val("");
	                    fetchTmpUploadedFiles(fileCntrl);
	                })
	            }
	            $("#" + modalId).modal('show');
	        }
	        $("[id$='activeModalHdn']").val('');
	    }
	}
}
function invokeMasterDataModal() {
    var modalType = $("[id$='masterDataModalTypeHdn']").val();
    //Master Code modals
    if (modalType == "PROPERTY_TYPE") addPropertyType("");
    else if (modalType == "PROPERTY_LOCATION") addPropertyLocation("");
    else if (modalType == "PR_TAX_TYPE") addPropertyTax("");
    else if (modalType == "PR_EXPENSE_TYPE") addExpensesType("");
    else if (modalType == "PR_UNIT_TYPE") addPropUnitType("");
    else if (modalType == "PR_UNIT_FACING") addFacing("");
    else if (modalType == "PR_UNIT_DIRECTION") addDirection("");
    else if (modalType == "OCCUPATION") addOccupation("");
    else if (modalType == "PR_UNIT_PYMT_TYPE") addSalePymtType("");
    else if (modalType == "ENQUIRY_SOURCE") addEnquirySource("");
    else if (modalType == "DOCUMENT_TYPE") addDocumentType("");
    else if (modalType == "RELATION_WITH_CUSTOMER") addRelation("");
    else if (modalType == "PROPERTY_CHARGES") addPropertyChargeType("");
    else if (modalType == "COMMUNICATION_MEDIA") addCommunicationMedia("");
    else if (modalType == "PROPERTY_PARKING_TYPE") addParkingType("");
}
function showMasterDataModal(mdOptions) {
    if (mdOptions.parentModal) {
        var parentModalId = $(mdOptions.parentModal).attr('data-parent-modal');
        $("#" + parentModalId).modal('hide');
        $("[id$='masterDataParentModalHdn']").val(parentModalId);
    }
    $("#" + mdOptions.modalId).find('.modal-title').html(mdOptions.modalTitle);
    $("[id$='lbMasterDataModalInput1']").text(mdOptions.input1Label);
    $("[id$='lbMasterDataModalInput2']").text(mdOptions.input2Label);
    $("[id$='masterDataModalTypeHdn']").val(mdOptions.modalName);
    $("#" + mdOptions.modalId).modal('show');
}
function showSingleInputModal(mdOptions) {
    if (mdOptions.parentModal) {
        var parentModalId = $(mdOptions.parentModal).attr('data-parent-modal');
        $("#" + parentModalId).modal('hide');
        $("[id$='masterDataParentModalHdn']").val(parentModalId);
    }
    $("#" + mdOptions.modalId).find('.modal-title').html(mdOptions.modalTitle);
    $("[id$='lbMasterDataModalInput2']").text(mdOptions.input2Label);
    $("[id$='masterDataModalTypeHdn']").val(mdOptions.modalName);
    $("#"+mdOptions.modalId).modal('show');
}
function addPropertyTax(element) {
    var mdOptions = {
        parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "PR_TAX_TYPE",
        modalTitle: ICON_ADD + "Add Property Tax Type",
        input1Label: "Tax Type",
        input2Label: "Description"
    };
    showMasterDataModal(mdOptions);
    return false;
}
function addPropertyType(element) {
    var mdOptions = {
        parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "PROPERTY_TYPE",
        modalTitle: ICON_ADD + "Add Property Type",
        input1Label: "Property Type",
        input2Label: "Description"
    };
    showMasterDataModal(mdOptions);
    return false;
}
function addPropertyLocation(element) {
    var mdOptions = {
        parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "PROPERTY_LOCATION",
        modalTitle: ICON_ADD + "Add Property Location",
        input1Label: "Property Location",
        input2Label: "Description"
    };
    showMasterDataModal(mdOptions);
    return false;
}
function addPropertyChargeType(element) {
    var mdOptions = {
        parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "PROPERTY_CHARGES",
        modalTitle: ICON_ADD + "Add Property Charge",
        input1Label: "Property Charge Name",
        input2Label: "Description"
    };
    showMasterDataModal(mdOptions);
    return false;
}
function addPropUnitType(element) {
    var mdOptions = {
        parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "PR_UNIT_TYPE",
        modalTitle: ICON_ADD + "Add Unit Type",
        input1Label: "Unit Type",
        input2Label: "Description"
    };
    showMasterDataModal(mdOptions);
    return false;
}
function addEnquirySource(element) {
    var mdOptions = {
        parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "ENQUIRY_SOURCE",
        modalTitle: ICON_ADD + "Add Enquiry/Lead Source",
        input1Label: "Enquiry/Lead Source",
        input2Label: "Description"
    };
    showMasterDataModal(mdOptions);
    return false;
}
function addOccupation(element) {
    var mdOptions = {
        parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "OCCUPATION",
        modalTitle: ICON_ADD + "Add Occupation",
        input1Label: "Occupation",
        input2Label: "Description"
    };
    showMasterDataModal(mdOptions);
    return false;
}
function addRelation(element) {
    var mdOptions = {
        parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "RELATION_WITH_CUSTOMER",
        modalTitle: ICON_ADD + "Add Relation With Customer",
        input1Label: "Relation With Customer",
        input2Label: "Description"
    };
    showMasterDataModal(mdOptions);
    return false;
}
function addDirection(element) {
    var mdOptions = {
        parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "PR_UNIT_DIRECTION",
        modalTitle: ICON_ADD + "Add Direction",
        input1Label: "Direction",
        input2Label: "Description"
    };
    showMasterDataModal(mdOptions);
    return false;
}
function addFacing(element) {
    var mdOptions = {
        parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "PR_UNIT_FACING",
        modalTitle: ICON_ADD + "Add Unit Facing",
        input1Label: "Facing",
        input2Label: "Description"
    };
    showMasterDataModal(mdOptions);
    return false;
}
function addCommunicationMedia(element) {
    var mdOptions = {
        parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "COMMUNICATION_MEDIA",
        modalTitle: ICON_ADD + "Add Communication Media",
        input1Label: "Communication Media",
        input2Label: "Description"
    };
    showMasterDataModal(mdOptions);
    return false;
}
function addParkingType(element) {
    var mdOptions = {
        parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "PR_PARKING_TYPE",
        modalTitle: ICON_ADD + "Add Parking Type",
        input1Label: "Parking Type",
        input2Label: "Description"
    };
    showMasterDataModal(mdOptions);
    return false;
}
function addDocumentType(element) {
    var mdOptions = {
        parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "DOCUMENT_TYPE",
        modalTitle: ICON_ADD + "Add Document Type",
        input1Label: "Document Type",
        input2Label: "Description"
    };
    showMasterDataModal(mdOptions);
    return false;
}
function addSalePymtType(element) {
    var mdOptions = {
        parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "PR_UNIT_PYMT_TYPE",
        modalTitle: ICON_ADD + "Add Sale Payment Type",
        input1Label: "Payment Type",
        input2Label: "Description"
    };
    showMasterDataModal(mdOptions);
    return false;
}
function addExpensesType(element) {
    var mdOptions = {
        parentModal: element,
        modalId: "addMasterDataModal",
        modalName: "PR_EXPENSE_TYPE",
        modalTitle: ICON_ADD + "Add Expenses Type",
        input1Label: "Expenses Type",
        input2Label: "Description"
    };
    showMasterDataModal(mdOptions);
    return false;
}
