﻿using ConstroSoft.Logic.CachingProvider;
using Newtonsoft.Json;
using System;
using System.Linq;
using System.Collections.Specialized;
using System.Web;
using System.Web.Http;
using System.IO;
using System.Net.Http;
using System.Net;
using System.Collections.Generic;
using System.Web.Hosting;

namespace ConstroSoft.Controller
{
    public class FileUploadController : ApiController
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        DocumentBO documentBO = new DocumentBO();
        /**
         * This service is called by exotel when incoming call is completed.
         */
        [HttpPost]
        [ActionName("UploadFiles")]
        public string UploadFiles()
        {
            string UserName = "";
            string errorMsg = "";
            List<FileUploadInfoDTO> uploadList = null;
            try
            {
                if (!Request.Content.IsMimeMultipartContent())
                {
                    throw new HttpResponseException(HttpStatusCode.UnsupportedMediaType);
                }
                UserName = HttpContext.Current.Request.Form["UserName"];
                string FunctionName = HttpContext.Current.Request.Form["Function"];
                string Path = HttpContext.Current.Request.Form["Path"];
                //Create Temp file upload folder if not exist
                string tmpFolder = (Constants.FILE_UPLOAD.MANAGE_DOCUMENTS.Equals(FunctionName)) ? Path 
                    :string.Format(Constants.DOCUMENT_MANAGEMENT.TMP_FILE_UPLOAD_PATH, UserName);
                documentBO.createFolderIfNotExist(tmpFolder);
                HttpFileCollection uploadedFiles = HttpContext.Current.Request.Files;
                errorMsg = validateFiles(FunctionName, uploadedFiles);
                if (string.IsNullOrWhiteSpace(errorMsg) && uploadedFiles != null && uploadedFiles.Count > 0)
                {
                    for (int i = 0; i < uploadedFiles.Count; i++)
                    {
                        HttpPostedFile userPostedFile = uploadedFiles[i];
                        if (userPostedFile.ContentLength > 0)
                        {
                            documentBO.saveDocument(userPostedFile, CommonUtil.appendNameToPath(tmpFolder, userPostedFile.FileName));
                        } 
                    }
                }
                if (!string.IsNullOrWhiteSpace(errorMsg))
                {
                    HttpResponseMessage resp = new HttpResponseMessage(HttpStatusCode.InternalServerError);
                    resp.ReasonPhrase = errorMsg;
                    throw new HttpResponseException(resp);
                }
                uploadList = fetchAllTempUploadedFiles(tmpFolder);
            }
            catch (HttpResponseException exp)
            {
                throw exp;
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while uploading files by User: " + UserName, exp);
                HttpResponseMessage resp = new HttpResponseMessage(HttpStatusCode.InternalServerError);
                resp.ReasonPhrase = "Unexpected error while uploading files, Please contact system administrator.";
                throw new HttpResponseException(resp);
            }
            return JsonConvert.SerializeObject(uploadList);
        }
        [HttpPost]
        [ActionName("DeleteFile")]
        public string DeleteFile()
        {

            string UserName = "";
            List<FileUploadInfoDTO> uploadList = null;
            try
            {
                UserName = HttpContext.Current.Request.Form["UserName"];
                string FileName = HttpContext.Current.Request.Form["FileName"];
                string tmpFolder = string.Format(Constants.DOCUMENT_MANAGEMENT.TMP_FILE_UPLOAD_PATH, UserName);
                if (!string.IsNullOrWhiteSpace(FileName))
                {
                    documentBO.deleteFile(CommonUtil.appendNameToPath(tmpFolder, FileName));
                }
                uploadList = fetchAllTempUploadedFiles(tmpFolder);
            }
            catch (HttpResponseException exp)
            {
                throw exp;
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while deleting file by User: " + UserName, exp);
                HttpResponseMessage resp = new HttpResponseMessage(HttpStatusCode.InternalServerError);
                resp.ReasonPhrase = "Unexpected error while deleting file, Please contact system administrator.";
                throw new HttpResponseException(resp);
            }
            return JsonConvert.SerializeObject(uploadList);
        }
        [HttpPost]
        [ActionName("GetFiles")]
        public string GetFiles()
        {

            string UserName = "";
            List<FileUploadInfoDTO> uploadList = null;
            try
            {
                UserName = HttpContext.Current.Request.Form["UserName"];
                string tmpFolder = string.Format(Constants.DOCUMENT_MANAGEMENT.TMP_FILE_UPLOAD_PATH, UserName);
                uploadList = fetchAllTempUploadedFiles(tmpFolder);
            }
            catch (HttpResponseException exp)
            {
                throw exp;
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while fetching files by User: " + UserName, exp);
                HttpResponseMessage resp = new HttpResponseMessage(HttpStatusCode.InternalServerError);
                resp.ReasonPhrase = "Unexpected error while fetching uploaded files, Please contact system administrator.";
                throw new HttpResponseException(resp);
            }
            return JsonConvert.SerializeObject(uploadList);
        }
        private List<FileUploadInfoDTO> fetchAllTempUploadedFiles(string sourcePath)
        {
            List<FileUploadInfoDTO> results = new List<FileUploadInfoDTO>();
            DirectoryInfo dir = new DirectoryInfo(HostingEnvironment.MapPath(sourcePath));
            FileSystemInfo[] filesAndDirs = dir.GetFileSystemInfos("*");
            foreach (FileSystemInfo foundFile in filesAndDirs)
            {
                if (foundFile.GetType() == typeof(FileInfo))
                {
                    FileInfo fileInfo = (FileInfo)foundFile;
                    FileUploadInfoDTO tmpDTO = new FileUploadInfoDTO();
                    tmpDTO.FileName = fileInfo.Name;
                    tmpDTO.Size = fileInfo.Length.ToSize(SizeUnits.KB);
                    results.Add(tmpDTO);
                }
            }
            return results;
        }
        private string validateFiles(string FunctionName, HttpFileCollection uploadedFiles)
        {
            if (FunctionName.Equals(Constants.FILE_UPLOAD.MANAGE_DOCUMENTS)) return validateFileForManageDocuments(uploadedFiles);
            if (FunctionName.Equals(Constants.FILE_UPLOAD.ACTIVITY)) return validateFileForActivity(uploadedFiles);
            if (FunctionName.Equals(Constants.FILE_UPLOAD.PYMT_RCPT)) return validateFileForPymtRcpt(uploadedFiles);
            if (FunctionName.Equals(Constants.FILE_UPLOAD.DEMAND_LETTER_UPLOAD)) return validateFileForDemandLetterUpload(uploadedFiles);
            if (FunctionName.Equals(Constants.FILE_UPLOAD.EMAIL_ATTACHMENT)) return validateEmailAttachment(uploadedFiles);
            return "Unable to find function for file upload, please contact system administrator.";
        }
        private string validateFileForManageDocuments(HttpFileCollection uploadedFiles)
        {
            string errorMsg = "";
            if (uploadedFiles != null && uploadedFiles.Count > 0)
            {
                if (uploadedFiles.Count > 3) errorMsg = string.Format("Maximum 3 files can be uploaded at once.");
                else
                {
                    for (int i = 0; i < uploadedFiles.Count; i++)
                    {
                        HttpPostedFile userPostedFile = uploadedFiles[i];
                        errorMsg = CommonUtil.IsValidSize(userPostedFile.ContentLength, Constants.MAX_MANAGE_DOCUMENT_SIZE);
                        if (!string.IsNullOrWhiteSpace(errorMsg)) break;
                    }
                }
            }   
            return errorMsg;
        }
        private string validateFileForActivity(HttpFileCollection uploadedFiles)
        {
            string errorMsg = "";
            if (uploadedFiles != null && uploadedFiles.Count > 0)
            {
                if (uploadedFiles.Count > 5) errorMsg = string.Format("Maximum 5 files can be uploaded at once.");
                else
                {
                    for (int i = 0; i < uploadedFiles.Count; i++)
                    {
                        HttpPostedFile userPostedFile = uploadedFiles[i];
                        errorMsg = CommonUtil.IsValidSize(userPostedFile.ContentLength, Constants.MAX_ACTIVITY_FILE_SIZE);
                        if (!string.IsNullOrWhiteSpace(errorMsg)) break;
                    }
                }
            }
            return errorMsg;
        }
        private string validateFileForPymtRcpt(HttpFileCollection uploadedFiles)
        {
            string errorMsg = "";
            if (uploadedFiles != null && uploadedFiles.Count > 0)
            {
                if (uploadedFiles.Count > 1) errorMsg = string.Format("Single receipt can be uploaded at once.");
                else
                {
                    for (int i = 0; i < uploadedFiles.Count; i++)
                    {
                        HttpPostedFile userPostedFile = uploadedFiles[i];
                        errorMsg = CommonUtil.IsValidSize(userPostedFile.ContentLength, Constants.MAX_MANAGE_DOCUMENT_SIZE);
                        if (!string.IsNullOrWhiteSpace(errorMsg)) break;
                    }
                }
            }
            return errorMsg;
        }
        private string validateFileForDemandLetterUpload(HttpFileCollection uploadedFiles)
        {
            string errorMsg = "";
            if (uploadedFiles != null && uploadedFiles.Count > 0)
            {
                if (uploadedFiles.Count > 1) errorMsg = string.Format("Single demand letter can be uploaded at once.");
                else
                {
                    for (int i = 0; i < uploadedFiles.Count; i++)
                    {
                        HttpPostedFile userPostedFile = uploadedFiles[i];
                        errorMsg = CommonUtil.IsValidSize(userPostedFile.ContentLength, Constants.MAX_MANAGE_DOCUMENT_SIZE);
                        if (!string.IsNullOrWhiteSpace(errorMsg)) break;
                    }
                }
            }
            return errorMsg;
        }
        private string validateEmailAttachment(HttpFileCollection uploadedFiles)
        {
        	string errorMsg = "";
            if (uploadedFiles != null && uploadedFiles.Count > 0)
            {
                if (uploadedFiles.Count > 5) errorMsg = string.Format("Maximum 5 files can be uploaded at once.");
                else
                {
                    for (int i = 0; i < uploadedFiles.Count; i++)
                    {
                        HttpPostedFile userPostedFile = uploadedFiles[i];
                        errorMsg = CommonUtil.IsValidSize(userPostedFile.ContentLength, Constants.EMAIL_ATTACHMENT_SIZE);
                        if (!string.IsNullOrWhiteSpace(errorMsg)) break;
                    }
                }
            }
            return errorMsg;
        }
    }
}