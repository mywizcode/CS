﻿
/// <summary>
/// Summary description for CommonUIConverter
/// </summary>
using ConstroSoft;
using System.Collections.Generic;
using NHibernate.Criterion;
using System.Linq.Expressions;
using NHibernate.Impl;
using System;
namespace ConstroSoft
{
    public class PaymentUtil
    {
        public PaymentUtil() { }
        public static PaymentTransaction createReversalPymtTransactionDTO(PaymentTransaction pymtTrans, MasterPymtTransactionDTO mptTxDTO)
        {
            PaymentTransaction reversalPymtTx = new PaymentTransaction();
            reversalPymtTx.TxDate = DateUtil.getUserLocalDate();
            reversalPymtTx.Status = PymtTransStatus.Reversal;
            reversalPymtTx.Comments = "Reversal Entry for Tx Ref No - " + mptTxDTO.TxRefNo;
            reversalPymtTx.Amount = pymtTrans.Amount;
            reversalPymtTx.FirmAccount = pymtTrans.FirmAccount;
            reversalPymtTx.AccountTransaction = createReversalAccountTransaction(pymtTrans, mptTxDTO);
            reversalPymtTx.PaymentVoucher =  createCancelPaymentVoucher(pymtTrans, mptTxDTO);
            reversalPymtTx.PaymentMaster = pymtTrans.PaymentMaster;
            reversalPymtTx.MasterPymtTransaction = pymtTrans.MasterPymtTransaction;
            reversalPymtTx.FirmNumber = pymtTrans.FirmNumber;
            reversalPymtTx.InsertUser = mptTxDTO.UpdateUser;
            reversalPymtTx.UpdateUser = mptTxDTO.UpdateUser;
            return reversalPymtTx;
        }
        public static AccountTransaction createReversalAccountTransaction(PaymentTransaction pymtTrans, MasterPymtTransactionDTO mptTxDTO)
        {
            AccountTransaction acntTrans = new AccountTransaction();
            acntTrans.FirmAccount = pymtTrans.FirmAccount;
            acntTrans.TxType = (pymtTrans.AccountTransaction.TxType == AcntTransStatus.Credit) ? AcntTransStatus.Debit : AcntTransStatus.Credit;
            acntTrans.Comments = getAccountTransactionRevComments(pymtTrans, mptTxDTO);
            acntTrans.TxDate = DateUtil.getUserLocalDate();
            acntTrans.Amount = pymtTrans.Amount;
            acntTrans.FirmNumber = pymtTrans.FirmNumber;
            acntTrans.InsertUser = mptTxDTO.UpdateUser;
            acntTrans.UpdateUser = mptTxDTO.UpdateUser;
            return acntTrans;
        }
        public static string getAccountTransactionRevComments(PaymentTransaction pymtTrans, MasterPymtTransactionDTO masterPymtTransDTO)
        {
            string comments = "";
            string pymtModeComment = getAcntTransCommentPymtMethod(masterPymtTransDTO.PymtMethod, masterPymtTransDTO.MediaNo);
            string customerName = CommonUIConverter.getCustomerFullName(masterPymtTransDTO.MPTBook.PrUnitSaleDetail.Customer.FirstName,
                masterPymtTransDTO.MPTBook.PrUnitSaleDetail.Customer.LastName);
            string pymtType = pymtTrans.AccountTransaction.Comments.Substring(pymtTrans.AccountTransaction.Comments.IndexOf(Constants.TX_REF));
            if (masterPymtTransDTO.PymtMode == PaymentMode.Receivable)
            {
                comments = string.Format(Constants.REV_PYMT_FROM, customerName) + "," + pymtModeComment + "," + pymtType;
            }
            else
            {
                comments = string.Format(Constants.REV_PYMT_TO, customerName) + "," + pymtModeComment + "," + pymtType;
            }
            return comments;
        }
        public static string getAcntTransCommentPymtMethod(PaymentMethod pymtMethod, string mediaNo)
        {
            string tmpComment = string.Format(Constants.PYMT_MODE, pymtMethod.ToString());
            if (pymtMethod != PaymentMethod.CASH && !string.IsNullOrWhiteSpace(mediaNo)) tmpComment += string.Format(Constants.MEDIA_NO, mediaNo);
            return tmpComment;
        }
        private static PaymentVoucher createCancelPaymentVoucher(PaymentTransaction pymtTrans, MasterPymtTransactionDTO mptTxDTO)
        {
            PaymentVoucher paymentVoucher = new PaymentVoucher();
            paymentVoucher.Action = Constants.VOUCHER_CANCEL_ACTION;
            if (mptTxDTO.PymtMode == PaymentMode.Receivable)
            {
                paymentVoucher.VoucherType = Constants.VOUCHER_TYPE_RECEIPT;
            }
            else
            {
                paymentVoucher.VoucherType = Constants.VOUCHER_TYPE_PAYMENT;
            }
            paymentVoucher.VoucherDate = pymtTrans.TxDate;
            paymentVoucher.VoucherEffectiveDate = pymtTrans.TxDate;
            paymentVoucher.VoucherNaration = getAccountTransactionRevComments(pymtTrans, mptTxDTO);
            paymentVoucher.VoucherNumber = pymtTrans.PaymentVoucher.Id.ToString();
            paymentVoucher.TallyPostingStatus = Constants.VOUCHER_PENDING;
            paymentVoucher.FirmNumber = pymtTrans.FirmNumber;
            paymentVoucher.InsertUser = pymtTrans.InsertUser;
            paymentVoucher.UpdateUser = pymtTrans.UpdateUser;
            return paymentVoucher;
        }
                
        public static PrUnitSalePymtDTO createCancellationPayment(DateTime PymtDate, UserDefinitionDTO userDefDto, decimal pymtAmt)
        {
            MasterDataBO masterDataBO = new MasterDataBO();
            PrUnitSalePymtDTO prUnitSalePymtDto = new PrUnitSalePymtDTO();
            prUnitSalePymtDto.PymtType = masterDataBO.fetchMasterData(userDefDto.FirmNumber, MasterDataType.PR_UNIT_PYMT_TYPE.ToString(), Constants.SYSDEFAULT.MCD_CANCELLATION_PAYMENT);
            prUnitSalePymtDto.PymtDate = PymtDate;
            prUnitSalePymtDto.PymtMode = PaymentMode.Payable;
            prUnitSalePymtDto.PymtAmt = pymtAmt;
            prUnitSalePymtDto.Description = "Unit Cancellation Payment.";
            prUnitSalePymtDto.UpdateUser = userDefDto.Username;
            
            prUnitSalePymtDto.FirmNumber = userDefDto.FirmNumber;
            prUnitSalePymtDto.InsertUser = userDefDto.Username;
            addNewPymtMaster(prUnitSalePymtDto, userDefDto);
            return prUnitSalePymtDto;
        }
        private static void addNewPymtMaster(PrUnitSalePymtDTO prUnitSalePymtDto, UserDefinitionDTO userDefDto)
        {
            PaymentMasterDTO paymentMasterDto = new PaymentMasterDTO();
            paymentMasterDto.TotalAmt = Decimal.Zero;
            paymentMasterDto.TotalPaid = Decimal.Zero;
            paymentMasterDto.TotalPending = Decimal.Zero;
            paymentMasterDto.TotalPdcAmt = Decimal.Zero;
            paymentMasterDto.FirmNumber = userDefDto.FirmNumber;
            paymentMasterDto.InsertUser = userDefDto.Username;
            prUnitSalePymtDto.PaymentMaster = paymentMasterDto;
            updatePymtMaster(prUnitSalePymtDto, userDefDto);
        }
        private static void updatePymtMaster(PrUnitSalePymtDTO prUnitSalePymtDto, UserDefinitionDTO userDefDto)
        {
            PaymentMasterDTO paymentMasterDto = prUnitSalePymtDto.PaymentMaster;
            decimal diffAmt = Decimal.Subtract(prUnitSalePymtDto.PymtAmt, paymentMasterDto.TotalAmt);
            paymentMasterDto.TotalAmt = Decimal.Add(paymentMasterDto.TotalAmt, diffAmt);
            paymentMasterDto.TotalPending = Decimal.Subtract(paymentMasterDto.TotalAmt, paymentMasterDto.TotalPaid);
            paymentMasterDto.UpdateUser = userDefDto.Username;
            if (paymentMasterDto.TotalPending > 0) paymentMasterDto.Status = PymtMasterStatus.Pending;
            else paymentMasterDto.Status = PymtMasterStatus.Paid;
        }
        public static bool isPymtMethodChqOrDD(PaymentMethod pymtMethod)
        {
            return (PaymentMethod.CHEQUE == pymtMethod || PaymentMethod.DD == pymtMethod);
        }
        public static AccountTransactionDTO createAccountTransaction(PaymentMethod pymtMethod, string mediaNo, DateTime TxDate, decimal Amount,
        		string acntId, UserDefinitionDTO userDefDTO, bool isDelete)
        {
            AccountTransactionDTO acntTransDto = new AccountTransactionDTO();
            acntTransDto.FirmAccount = CommonUIConverter.getFirmAccountDTO(acntId, "");
            PaymentTransactionDTO pymtTransDto = new PaymentTransactionDTO();
            string pymtMethodComment = getAcntTransCommentPymtMethod(pymtMethod, mediaNo);
            if (isDelete)
            {
                acntTransDto.TxType = AcntTransStatus.Debit;
                acntTransDto.Comments = Constants.REV_FUND_DEPOSITE + "," + pymtMethodComment;
            }
            else
            {
                acntTransDto.Comments = Constants.FUND_DEPOSITE + "," + pymtMethodComment;
                acntTransDto.TxType = AcntTransStatus.Credit;
            }

            acntTransDto.TxDate = TxDate;
            acntTransDto.Amount = Amount;
            acntTransDto.FirmNumber = userDefDTO.FirmNumber;
            acntTransDto.InsertUser = userDefDTO.Username;
            acntTransDto.UpdateUser = userDefDTO.Username;
            return acntTransDto;
        }
    }
}