﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using ConstroSoft;

public partial class EmailSMSCampaignSearch : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
            log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string SearchFilterModal = "SearchFilterModal";
    DropdownBO drpBO = new DropdownBO();
    MarketingCampaignBO marketingCampaignBO = new MarketingCampaignBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                EmailSMSCampaignSearchNavDTO navDto = ApplicationUtil.getPageNavDTO<EmailSMSCampaignSearchNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_EMAIL_SMS_CAMPAIGN)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
        * This method is called just before the page is rendered. So any change in state of the element is applied.
        **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpEnum<EmailSmsCampaignStage>(drpStageFilter, Constants.SELECT_ITEM);
        drpBO.drpEnum<EmailSmsType>(drpCampaignTypeFilter, Constants.SELECT_ITEM);
    }
    public void setErrorMessage(string message, string group)
    {
        string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }
    }
    private void doInit(EmailSMSCampaignSearchNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new EmailSMSCampaignSearchPageDTO();
        initDropdowns();
        EmailSMSCampaignFilterDTO FilterDTO = new EmailSMSCampaignFilterDTO();
        setSearchFilter(FilterDTO);
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(EmailSMSCampaignSearchNavDTO navDto)
    {
        try
        {
            if (navDto != null)
            {
                setSearchFilter(navDto.filterDTO);
            }
            loadEmailSMSCampaignGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageFieldsWithEntitlement()
    {

    }
    private EmailSMSCampaignSearchPageDTO getSessionPageData()
    {
        return (EmailSMSCampaignSearchPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<EmailSmsCampaignDTO> getEmailSMSCampaignList()
    {
        return getSessionPageData().SearchResult;
    }
    private EmailSmsCampaignDTO getEmailSmsCampaignDTO(long Id)
    {
        List<EmailSmsCampaignDTO> searchList = getEmailSMSCampaignList();
        EmailSmsCampaignDTO tmpDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            tmpDTO = searchList.Find(c => c.Id == Id);
        }
        return tmpDTO;
    }
    private void loadEmailSMSCampaignGrid()
    {
        IList<EmailSmsCampaignDTO> results = marketingCampaignBO.fetchEmailSmsCampaignGridData(getUserDefinitionDTO().FirmNumber, getSearchFilter());
        getSessionPageData().SearchResult = (results != null) ? results.ToList<EmailSmsCampaignDTO>() : new List<EmailSmsCampaignDTO>();
        setEmailSMSGrid(getSessionPageData().SearchResult);
    }
    private void setEmailSMSGrid(List<EmailSmsCampaignDTO> tmpList)
    {
        if (tmpList != null && tmpList.Count > 0)
        {
            foreach (EmailSmsCampaignDTO tmpDTO in tmpList)
            {
                tmpDTO.CreatedBy.FullName = CommonUIConverter.getCustomerFullName(tmpDTO.CreatedBy.FirstName, tmpDTO.CreatedBy.LastName);
                tmpDTO.UpdatedBy.FullName = CommonUIConverter.getCustomerFullName(tmpDTO.UpdatedBy.FirstName, tmpDTO.UpdatedBy.LastName);
                tmpDTO.TimeInfo = DateUtil.getScheduledDateTimeInfo(tmpDTO.ScheduledDate, " left");
            }
        }
        emailSMSCampaignSearchGrid.DataSource = tmpList;
        emailSMSCampaignSearchGrid.DataBind();
    }
    private void navigateToEmailCampaignDetails(long CampaignId, PageMode mode)
    {
        EmailCampaignNavDTO navDTO = new EmailCampaignNavDTO();
        navDTO.Mode = mode;
        navDTO.CampaignId = CampaignId;
        navDTO.PrevNavDto = getCurrentPageNavigation();
        Session[Constants.Session.NAV_DTO] = navDTO;
        Response.Redirect((PageMode.VIEW == mode) ? Constants.URL.EMAIL_CAMPAIGN_DETAILS : Constants.URL.EMAIL_CAMPAIGN_DETAILS, true);
    }
    private void navigateToSMSCampaignDetails(long CampaignId, PageMode mode)
    {
        SMSCampaignNavDTO navDTO = new SMSCampaignNavDTO();
        navDTO.Mode = mode;
        navDTO.CampaignId = CampaignId;
        navDTO.PrevNavDto = getCurrentPageNavigation();
        Session[Constants.Session.NAV_DTO] = navDTO;
        Response.Redirect(Constants.URL.SMS_CAMPAIGN_DETAILS, true);
    }
    protected void onClickAddEmailCampaignBtn(object sender, EventArgs e)
    {
        try
        {
            navigateToEmailCampaignDetails(0, PageMode.ADD);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickAddSMSCampaignBtn(object sender, EventArgs e)
    {
        try
        {
            navigateToSMSCampaignDetails(0, PageMode.ADD);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyCampaignBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);

            EmailSmsCampaignDTO campaignDTO = getEmailSmsCampaignDTO(selectedId);
            if (campaignDTO.RecordType == EmailSmsType.Email)
            {
                navigateToEmailCampaignDetails(campaignDTO.Id, (campaignDTO.Stage == EmailSmsCampaignStage.Draft) ? PageMode.MODIFY : PageMode.VIEW);
            }
            else
            {
                navigateToSMSCampaignDetails(campaignDTO.Id, (campaignDTO.Stage == EmailSmsCampaignStage.Draft) ? PageMode.MODIFY : PageMode.VIEW);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    protected void deleteCampaign(object sender, EventArgs e)
    {
        try
        {
            long selectedId = getDeleteRecordHdnId();
            EmailSmsCampaignDTO campaignDTO = getEmailSmsCampaignDTO(selectedId);
            if (campaignDTO.Stage == EmailSmsCampaignStage.Draft)
            {
                marketingCampaignBO.deleteEmailSmsCampaign(campaignDTO.Id);
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(string.Format("{0} campaign is deleted successfully.", campaignDTO.RecordType.ToString())));
                loadEmailSMSCampaignGrid();
            }
            else
            {
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Scheduled campaign cannot be deleted."));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private EmailSMSCampaignSearchNavDTO getCurrentPageNavigation()
    {
        EmailSMSCampaignSearchNavDTO searchNavDTO = new EmailSMSCampaignSearchNavDTO();
        searchNavDTO.filterDTO = getSearchFilter();
        return searchNavDTO;
    }
    //Filter Criteria - Email Campaign Search - Start
    private EmailSMSCampaignFilterDTO getSearchFilter()
    {
        return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            EmailSMSCampaignFilterDTO filterDTO = getSearchFilter();
            if (filterDTO.RefNo != null) txtCampaignRefNoFilter.Text = filterDTO.RefNo; else txtCampaignRefNoFilter.Text = null;
            if (filterDTO.Name != null) txtCampaignNameFilter.Text = filterDTO.Name; else txtCampaignNameFilter.Text = null;
            if (filterDTO.Type != null) drpCampaignTypeFilter.Text = filterDTO.Type.ToString(); else drpCampaignTypeFilter.ClearSelection();
            if (filterDTO.Stage != null) drpStageFilter.Text = filterDTO.Stage.ToString(); else drpStageFilter.ClearSelection();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            EmailSMSCampaignFilterDTO filterDTO = new EmailSMSCampaignFilterDTO();
            if (!string.IsNullOrWhiteSpace(txtCampaignRefNoFilter.Text))
            {
                filterDTO.RefNo = txtCampaignRefNoFilter.Text.TrimNullable();
            }
            if (!string.IsNullOrWhiteSpace(txtCampaignNameFilter.Text))
            {
                filterDTO.Name = txtCampaignNameFilter.Text.TrimNullable();
            }
            if (!string.IsNullOrWhiteSpace(drpCampaignTypeFilter.Text))
            {
                filterDTO.Type = EnumHelper.ToEnum<EmailSmsType>(drpCampaignTypeFilter.SelectedItem.Text);
            }
            if (!string.IsNullOrWhiteSpace(drpStageFilter.Text))
            {
                filterDTO.Stage = EnumHelper.ToEnum<EmailSmsCampaignStage>(drpStageFilter.SelectedItem.Text);
            }
            setSearchFilter(filterDTO);
            loadEmailSMSCampaignGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }

    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            loadEmailSMSCampaignGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(EmailSMSCampaignFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new EmailSMSCampaignFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            EmailSMSCampaignFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.REF_NO)) filterDTO.RefNo = null;
            else if (token.StartsWith(Constants.FILTER.NAME)) filterDTO.Name = null;
            else if (token.StartsWith(Constants.FILTER.TYPE)) filterDTO.Type = null;
            else if (token.StartsWith(Constants.FILTER.STAGE)) filterDTO.Stage = null;

            setSearchFilterTokens();
            loadEmailSMSCampaignGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        EmailSMSCampaignFilterDTO filterDTO = getSearchFilter();
        string filter = null;
        if (filterDTO != null)
        {
            if (filterDTO.RefNo != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.REF_NO + filterDTO.RefNo);
            if (filterDTO.Name != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.NAME + filterDTO.Name);
            if (filterDTO.Type != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.TYPE + filterDTO.Type);
            if (filterDTO.Stage != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.STAGE + filterDTO.Stage);
        }
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - Enquiry Search - End
}