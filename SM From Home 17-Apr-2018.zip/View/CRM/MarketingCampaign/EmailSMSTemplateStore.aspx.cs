﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using ConstroSoft;

public partial class EmailSMSTemplateStore : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
            log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string SearchFilterModal = "SearchFilterModal";
    DropdownBO drpBO = new DropdownBO();
    MarketingCampaignBO marketingCampaignBO = new MarketingCampaignBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                EmailSMSTemplateStoreNavDTO navDto = ApplicationUtil.getPageNavDTO<EmailSMSTemplateStoreNavDTO>(Session);
                bool isSysAdmin = CommonUtil.IsSystemAdminRole(getUserDefinitionDTO());
                if (!isSysAdmin)
                {
                    if (ApplicationUtil.IsSysAdminPage(Request)) (this.Master as CSMaster).doLogout(Constants.URL.SYS_ADMIN_LOGIN_FAILED);
                    if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_EMAIL_SMS_TEMPLATE_STORE)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                    if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) == null) Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
                }
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    protected void Page_PreInit(object sender, EventArgs e)
    {
        if (CommonUtil.IsSystemAdminRole(getUserDefinitionDTO()))
        {
            this.MasterPageFile = "~/CSAdminMaster.master";
        }
    }
    private void setNotyMsgInMaster(string msg)
    {
        if (CommonUtil.IsSystemAdminRole(getUserDefinitionDTO())) (this.Master as CSAdminMaster).setNotyMsg(msg);
        else (this.Master as CSMaster).setNotyMsg(msg);
    }
    /**
    * This method is called just before the page is rendered. So any change in state of the element is applied.
    **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                setNotyMsgInMaster(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpEnum<EmailSmsStoreStatus>(drpStatusFilter, Constants.SELECT_ITEM);
        drpBO.drpEnum<EmailSmsType>(drpTemplateTypeFilter, Constants.SELECT_ITEM);
    }
    public void setErrorMessage(string message, string group)
    {
        string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            setNotyMsgInMaster(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }
    }
    private void doInit(EmailSMSTemplateStoreNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new EmailSMSTemplateStorePageDTO();
        initDropdowns();
        EmailSmsStoreFilterDTO FilterDTO = new EmailSmsStoreFilterDTO();
        setSearchFilter(FilterDTO);
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(EmailSMSTemplateStoreNavDTO navDto)
    {
        try
        {
            if (navDto != null)
            {
                setSearchFilter(navDto.filterDTO);
            }
            loadEmailTemplateGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageFieldsWithEntitlement()
    {

    }
    private EmailSMSTemplateStorePageDTO getSessionPageData()
    {
        return (EmailSMSTemplateStorePageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<EmailSmsStoreDTO> getEmailTemplateList()
    {
        return getSessionPageData().SearchResult;
    }
    private EmailSmsStoreDTO getEmailSmsStoreDTO(long Id)
    {
        List<EmailSmsStoreDTO> searchList = getEmailTemplateList();
        EmailSmsStoreDTO tmpDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            tmpDTO = searchList.Find(c => c.Id == Id);
        }
        return tmpDTO;
    }
    private void loadEmailTemplateGrid()
    {
        IList<EmailSmsStoreDTO> results = marketingCampaignBO.fetchEmailSmsStoreGridData(getUserDefinitionDTO().FirmNumber, getSearchFilter());
        getSessionPageData().SearchResult = (results != null) ? results.ToList<EmailSmsStoreDTO>() : new List<EmailSmsStoreDTO>();
        setEmailSMSGrid(getSessionPageData().SearchResult);
    }
    private void setEmailSMSGrid(List<EmailSmsStoreDTO> tmpList)
    {
        if (tmpList != null && tmpList.Count > 0)
        {
            foreach (EmailSmsStoreDTO tmpDTO in tmpList)
            {
                tmpDTO.CreatedBy.FullName = CommonUIConverter.getCustomerFullName(tmpDTO.CreatedBy.FirstName, tmpDTO.CreatedBy.LastName);
                tmpDTO.UpdatedBy.FullName = CommonUIConverter.getCustomerFullName(tmpDTO.UpdatedBy.FirstName, tmpDTO.UpdatedBy.LastName);
            }
        }
        emailSMSTemplateSearchGrid.DataSource = tmpList;
        emailSMSTemplateSearchGrid.DataBind();
    }
    private void navigateToEmailTemplateDetails(long TemplateId, PageMode mode)
    {
        EmailTemplateNavDTO navDTO = new EmailTemplateNavDTO();
        navDTO.Mode = mode;
        navDTO.TemplateId = TemplateId;
        navDTO.PrevNavDto = getCurrentPageNavigation();
        Session[Constants.Session.NAV_DTO] = navDTO;
        Response.Redirect(CommonUtil.IsSystemAdminRole(getUserDefinitionDTO()) ? Constants.URL.ADMIN_EMAIL_TEMPLATE_DETAILS : Constants.URL.EMAIL_TEMPLATE_DETAILS, true);
    }
    private void navigateToSMSTemplateDetails(long TemplateId, PageMode mode)
    {
        SMSTemplateNavDTO navDTO = new SMSTemplateNavDTO();
        navDTO.Mode = mode;
        navDTO.TemplateId = TemplateId;
        navDTO.PrevNavDto = getCurrentPageNavigation();
        Session[Constants.Session.NAV_DTO] = navDTO;
        Response.Redirect(CommonUtil.IsSystemAdminRole(getUserDefinitionDTO()) ? Constants.URL.ADMIN_SMS_TEMPLATE_DETAILS : Constants.URL.SMS_TEMPLATE_DETAILS, true);
    }
    protected void onClickAddEmailTemplateBtn(object sender, EventArgs e)
    {
        try
        {
            navigateToEmailTemplateDetails(0, PageMode.ADD);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickAddSMSTemplateBtn(object sender, EventArgs e)
    {
        try
        {
            navigateToSMSTemplateDetails(0, PageMode.ADD);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyTemplateBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);

            EmailSmsStoreDTO templateDTO = getEmailSmsStoreDTO(selectedId);
            PageMode pageMode = PageMode.VIEW;
            if(CommonUtil.IsSystemAdminRole(getUserDefinitionDTO()) && templateDTO.Status == EmailSmsStoreStatus.Draft) pageMode = PageMode.MODIFY;
            if (templateDTO.RecordType == EmailSmsType.Email)
            {
                navigateToEmailTemplateDetails(templateDTO.Id, pageMode);
            }
            else
            {
                navigateToSMSTemplateDetails(templateDTO.Id, pageMode);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    protected void deleteTemplate(object sender, EventArgs e)
    {
        try
        {
            long selectedId = getDeleteRecordHdnId();
            EmailSmsStoreDTO templateDTO = getEmailSmsStoreDTO(selectedId);
            if (validateTemplateDelete(templateDTO))
            {
                marketingCampaignBO.deleteEmailSmsStoreTemplate(templateDTO.Id);
                setNotyMsgInMaster(CommonUtil.getNotyErrorMsg(string.Format("{0} template is deleted successfully.", templateDTO.RecordType.ToString())));
                loadEmailTemplateGrid();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateTemplateDelete(EmailSmsStoreDTO templateDTO) {
    	if (!CommonUtil.IsSystemAdminRole(getUserDefinitionDTO()) && templateDTO.SystemDefined == SystemDefined.Yes)
        {
    		setNotyMsgInMaster(CommonUtil.getNotyErrorMsg("System Defined templates cannot be deleted."));
    		return false;
        } 
    	if (templateDTO.Status == EmailSmsStoreStatus.Draft)
        {
    		setNotyMsgInMaster(CommonUtil.getNotyErrorMsg("Published templates cannot be deleted."));
    		return false;
        }
    	return true;
    }
    private EmailSMSTemplateStoreNavDTO getCurrentPageNavigation()
    {
        EmailSMSTemplateStoreNavDTO searchNavDTO = new EmailSMSTemplateStoreNavDTO();
        searchNavDTO.filterDTO = getSearchFilter();
        return searchNavDTO;
    }
    //Filter Criteria - Email Template Search - Start
    private EmailSmsStoreFilterDTO getSearchFilter()
    {
        return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            EmailSmsStoreFilterDTO filterDTO = getSearchFilter();
            if (filterDTO.RefNo != null) txtTemplateRefNoFilter.Text = filterDTO.RefNo; else txtTemplateRefNoFilter.Text = null;
            if (filterDTO.Name != null) txtTemplateNameFilter.Text = filterDTO.Name; else txtTemplateNameFilter.Text = null;
            if (filterDTO.Type != null) drpTemplateTypeFilter.Text = filterDTO.Type.ToString(); else drpTemplateTypeFilter.ClearSelection();
            if (filterDTO.Status != null) drpStatusFilter.Text = filterDTO.Status.ToString(); else drpStatusFilter.ClearSelection();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            EmailSmsStoreFilterDTO filterDTO = new EmailSmsStoreFilterDTO();
            if (!string.IsNullOrWhiteSpace(txtTemplateRefNoFilter.Text))
            {
                filterDTO.RefNo = txtTemplateRefNoFilter.Text.TrimNullable();
            }
            if (!string.IsNullOrWhiteSpace(txtTemplateNameFilter.Text))
            {
                filterDTO.Name = txtTemplateNameFilter.Text.TrimNullable();
            }
            if (!string.IsNullOrWhiteSpace(drpTemplateTypeFilter.Text))
            {
                filterDTO.Type = EnumHelper.ToEnum<EmailSmsType>(drpTemplateTypeFilter.SelectedItem.Text);
            }
            if (!string.IsNullOrWhiteSpace(drpStatusFilter.Text))
            {
                filterDTO.Status = EnumHelper.ToEnum<EmailSmsStoreStatus>(drpStatusFilter.SelectedItem.Text);
            }
            setSearchFilter(filterDTO);
            loadEmailTemplateGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }

    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            loadEmailTemplateGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(EmailSmsStoreFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new EmailSmsStoreFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            EmailSmsStoreFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.REF_NO)) filterDTO.RefNo = null;
            else if (token.StartsWith(Constants.FILTER.NAME)) filterDTO.Name = null;
            else if (token.StartsWith(Constants.FILTER.TYPE)) filterDTO.Type = null;
            else if (token.StartsWith(Constants.FILTER.STATUS)) filterDTO.Status = null;

            setSearchFilterTokens();
            loadEmailTemplateGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        EmailSmsStoreFilterDTO filterDTO = getSearchFilter();
        string filter = null;
        if (filterDTO != null)
        {
            if (filterDTO.RefNo != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.REF_NO + filterDTO.RefNo);
            if (filterDTO.Name != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.NAME + filterDTO.Name);
            if (filterDTO.Type != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.TYPE + filterDTO.Type);
            if (filterDTO.Status != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.STATUS + filterDTO.Status);
        }
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - Enquiry Search - End
}