﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq.Expressions;
using NHibernate.Impl;
using System.Linq;

/// <summary>
/// Summary description for propertyBO
/// </summary>
namespace ConstroSoft
{
    public class PaymentBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public PaymentBO() { }

        public List<CustomerPymtSearchDTO> fetchCustomerSearchPayments(string firmNumber, long prTowerId, CustomerPymtSearchFilterDTO filterDTO)
        {
                ISession session = null;
                List<CustomerPymtSearchDTO> customerPymtList = new List<CustomerPymtSearchDTO>();
                IList<PrUnitSalePymtDTO> result = null;
                try
                {
                    session = NHibertnateSession.OpenSession();
                    using (ITransaction tx = session.BeginTransaction())
                    {
                        try
                        {
                            PrUnitSalePymt pusp = null;
                            Property p = null;
                            PropertyUnit pu = null;
                            PrUnitSaleDetail pus = null;
                            Customer c = null;
                            PropertyTower pt = null;
                            PaymentMaster pm = null;

                            PrUnitSalePymtDTO puspdt = null;
                            
                            var proj = Projections.ProjectionList()
                                        .Add(Projections.Property(() => pusp.Id).WithAlias(() => puspdt.Id))
                                        .Add(Projections.Property(() => pusp.PymtMode).WithAlias(() => puspdt.PymtMode))
                                        .Add(Projections.Property(() => c.FirstName), "PrUnitSaleDetail.Customer.FirstName")
                                        .Add(Projections.Property(() => c.LastName), "PrUnitSaleDetail.Customer.LastName")
                                        .Add(Projections.Property(() => c.CustRefNo), "PrUnitSaleDetail.Customer.CustRefNo")
                                        .Add(Projections.Property(() => pt.Id), "PrUnitSaleDetail.PropertyUnit.PropertyTower.Id")
                                        .Add(Projections.Property(() => pt.Name), "PrUnitSaleDetail.PropertyUnit.PropertyTower.Name")
                                        .Add(Projections.Property(() => pu.Wing), "PrUnitSaleDetail.PropertyUnit.Wing")
                                        .Add(Projections.Property(() => pu.UnitNo), "PrUnitSaleDetail.PropertyUnit.UnitNo")
                                        .Add(Projections.Property(() => pus.Status), "PrUnitSaleDetail.Status")
                                        .Add(Projections.Property(() => pus.BookingRefNo), "PrUnitSaleDetail.BookingRefNo")
                                        .Add(Projections.Property(() => pus.Id), "PrUnitSaleDetail.Id")
                                        .Add(Projections.Property(() => pm.TotalAmt), "PaymentMaster.TotalAmt")
                                        .Add(Projections.Property(() => pm.TotalPaid), "PaymentMaster.TotalPaid")
                                        .Add(Projections.Property(() => pm.TotalPending), "PaymentMaster.TotalPending")
                                        .Add(Projections.Property(() => pm.Status), "PaymentMaster.Status");
                            var query = session.QueryOver<PrUnitSalePymt>(() => pusp)
                                .Inner.JoinAlias(() => pusp.PaymentMaster, () => pm)
                                .Left.JoinAlias(() => pusp.PrUnitSaleDetail, () => pus)
                                .Left.JoinAlias(() => pusp.PrUnitSaleDetail.PropertyUnit, () => pu)
                                .Left.JoinAlias(() => pusp.PrUnitSaleDetail.PropertyUnit.PropertyTower, () => pt)
                                .Left.JoinAlias(() => pusp.PrUnitSaleDetail.PropertyUnit.PropertyTower.Property, () => p)
                                .Left.JoinAlias(() => pusp.PrUnitSaleDetail.Customer, () => c);
                            if (filterDTO != null)
                            {
                                ICriteria criteria = query.RootCriteria;
                                if (filterDTO.UnitId > 0)
                                {
                                    criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<PropertyUnit>(() => pu, x => x.Id), filterDTO.UnitId));
                                }
                                if (filterDTO.CustomerId > 0)
                                {
                                    criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<Customer>(() => c, x => x.Id), filterDTO.CustomerId));
                                }
                                if (!string.IsNullOrWhiteSpace(filterDTO.CustRefNo))
                                {
                                    criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<Customer>(() => c, x => x.CustRefNo), filterDTO.CustRefNo));
                                }
                                if (!string.IsNullOrWhiteSpace(filterDTO.BookingRefNo))
                                {
                                    criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<PrUnitSaleDetail>(() => pus, x => x.BookingRefNo), filterDTO.BookingRefNo));
                                }
                                if (filterDTO.UnitSaleStatus != null)
                                {
                                    criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<PrUnitSaleDetail>(() => pus, x => x.Status), filterDTO.UnitSaleStatus));
                                }
                            }
                            result = query.Where(() => p.FirmNumber == firmNumber && pt.Id == prTowerId && pm.Status != PymtMasterStatus.Deleted)
                                .Select(proj)
                                .TransformUsing(new DeepTransformer<PrUnitSalePymtDTO>()).List<PrUnitSalePymtDTO>();
                            if (result != null && result.Count > 0) {
                                foreach(PrUnitSalePymtDTO salePymtDTO in result) {
                                    CustomerPymtSearchDTO tmpCustomerSearchDTO = customerPymtList.Find(x => x.UnitSaleDetailId == salePymtDTO.PrUnitSaleDetail.Id);
                                    if(tmpCustomerSearchDTO == null) {
                                        tmpCustomerSearchDTO = new CustomerPymtSearchDTO();
                                        tmpCustomerSearchDTO.UnitSaleDetailId = salePymtDTO.PrUnitSaleDetail.Id;
                                        tmpCustomerSearchDTO.BookingRefNo = salePymtDTO.PrUnitSaleDetail.BookingRefNo;
                                        tmpCustomerSearchDTO.CustomerName = CommonUIConverter.getCustomerFullName(salePymtDTO.PrUnitSaleDetail.Customer.FirstName, salePymtDTO.PrUnitSaleDetail.Customer.LastName);
                                        tmpCustomerSearchDTO.CustomerId = salePymtDTO.PrUnitSaleDetail.Customer.Id;
                                        tmpCustomerSearchDTO.CustRefNo = salePymtDTO.PrUnitSaleDetail.Customer.CustRefNo;
                                        tmpCustomerSearchDTO.PrTowerName = salePymtDTO.PrUnitSaleDetail.PropertyUnit.PropertyTower.Name;
                                        tmpCustomerSearchDTO.PrTowerId = salePymtDTO.PrUnitSaleDetail.PropertyUnit.PropertyTower.Id;
                                        tmpCustomerSearchDTO.UnitNo = CommonUIConverter.getPropertyUnitFormattedNo(salePymtDTO.PrUnitSaleDetail.PropertyUnit.Wing, salePymtDTO.PrUnitSaleDetail.PropertyUnit.UnitNo);
                                        tmpCustomerSearchDTO.UnitSaleStatus = salePymtDTO.PrUnitSaleDetail.Status;
                                        tmpCustomerSearchDTO.TotalPayablePymt = new TotalPymtDTO();
                                        tmpCustomerSearchDTO.TotalReceivablePymt = new TotalPymtDTO();
                                        customerPymtList.Add(tmpCustomerSearchDTO);
                                    }
                                    if (salePymtDTO.PymtMode == PaymentMode.Receivable)
                                    {
                                        tmpCustomerSearchDTO.TotalReceivablePymt.TotalPymtAmt = Decimal.Add(tmpCustomerSearchDTO.TotalReceivablePymt.TotalPymtAmt, salePymtDTO.PaymentMaster.TotalAmt);
                                        tmpCustomerSearchDTO.TotalReceivablePymt.TotalPaidAmt = Decimal.Add(tmpCustomerSearchDTO.TotalReceivablePymt.TotalPaidAmt, salePymtDTO.PaymentMaster.TotalPaid);
                                        tmpCustomerSearchDTO.TotalReceivablePymt.TotalPendingAmt = Decimal.Add(tmpCustomerSearchDTO.TotalReceivablePymt.TotalPendingAmt, salePymtDTO.PaymentMaster.TotalPending);
                                    }
                                    else
                                    {
                                        tmpCustomerSearchDTO.TotalPayablePymt.TotalPymtAmt = Decimal.Add(tmpCustomerSearchDTO.TotalPayablePymt.TotalPymtAmt, salePymtDTO.PaymentMaster.TotalAmt);
                                        tmpCustomerSearchDTO.TotalPayablePymt.TotalPaidAmt = Decimal.Add(tmpCustomerSearchDTO.TotalPayablePymt.TotalPaidAmt, salePymtDTO.PaymentMaster.TotalPaid);
                                        tmpCustomerSearchDTO.TotalPayablePymt.TotalPendingAmt = Decimal.Add(tmpCustomerSearchDTO.TotalPayablePymt.TotalPendingAmt, salePymtDTO.PaymentMaster.TotalPending);
                                        tmpCustomerSearchDTO.TotalPayablePymt.isUISelected = true;
                                    }
                                }
                                foreach(CustomerPymtSearchDTO tmpCustomerSearchDTO in customerPymtList) {
                                    //If Unit is cancelled and there is no return payment to Customer then show unit payment status as Suspended.
                                    if (tmpCustomerSearchDTO.UnitSaleStatus == PRUnitSaleStatus.Cancelled)
                                    {
                                        if (!tmpCustomerSearchDTO.TotalPayablePymt.isUISelected) 
                                            tmpCustomerSearchDTO.PymtStatus = PymtMasterStatus.Suspended;
                                        else
                                            tmpCustomerSearchDTO.PymtStatus = tmpCustomerSearchDTO.TotalPayablePymt.TotalPendingAmt > 0 ? PymtMasterStatus.Pending : PymtMasterStatus.Paid;
                                    }
                                    else {
                                        tmpCustomerSearchDTO.PymtStatus = (tmpCustomerSearchDTO.TotalReceivablePymt.TotalPendingAmt > 0 || tmpCustomerSearchDTO.TotalPayablePymt.TotalPendingAmt > 0) 
                                                ? PymtMasterStatus.Pending : PymtMasterStatus.Paid;
                                    }
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            tx.Rollback();
                            log.Error("Unexpected error fetching data for Customer Payment search grid:");
                            log.Error(e.Message, e);
                            throw new Exception(Resources.Messages.system_error);
                        }
                    }
                }
                finally
                {
                    NHibertnateSession.closeSession(session);
                }
                return customerPymtList;
        }
        public PrUnitSaleDetailDTO fetchPrUnitDetails(string firmNumber, long prUnitSaleId)
        {
            ISession session = null;
            PrUnitSaleDetailDTO prUnitSaleDetailDTO = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Property p = null;
                        PropertyUnit pu = null;
                        PrUnitSaleDetail pus = null;
                        Customer c = null;
                        FirmAccount fm = null;
                        PropertyTower pt = null;
                        MPTBook mptbook = null;

                        PrUnitSaleDetailDTO pusdt = null;

                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => pus.Id).WithAlias(() => pusdt.Id))
                                    .Add(Projections.Property(() => pus.Status).WithAlias(() => pusdt.Status))
                                    .Add(Projections.Property(() => pus.BookingRefNo).WithAlias(() => pusdt.BookingRefNo))
                                    .Add(Projections.Property(() => mptbook.Id), "MPTUnitBook.Id")
                                    .Add(Projections.Property(() => c.Id), "Customer.Id")
                                    .Add(Projections.Property(() => c.FirstName), "Customer.FirstName")
                                    .Add(Projections.Property(() => c.MiddleName), "Customer.MiddleName")
                                    .Add(Projections.Property(() => c.LastName), "Customer.LastName")
                                    .Add(Projections.Property(() => c.CustRefNo), "Customer.CustRefNo")
                                    .Add(Projections.Property(() => pu.Id), "PropertyUnit.Id")
                                    .Add(Projections.Property(() => pu.Wing), "PropertyUnit.Wing")
                                    .Add(Projections.Property(() => pu.UnitNo), "PropertyUnit.UnitNo")
                                    .Add(Projections.Property(() => pt.Id), "PropertyUnit.PropertyTower.Id")
                                    .Add(Projections.Property(() => pt.Name), "PropertyUnit.PropertyTower.Name")
                                    .Add(Projections.Property(() => p.Id), "PropertyUnit.PropertyTower.Property.Id")
                                    .Add(Projections.Property(() => p.Name), "PropertyUnit.PropertyTower.Property.Name")
                                    .Add(Projections.Property(() => fm.Id), "PropertyUnit.PropertyTower.Property.FirmAccount.Id")
                                    .Add(Projections.Property(() => fm.Name), "PropertyUnit.PropertyTower.Property.FirmAccount.Name");
                        var query = session.QueryOver<PrUnitSaleDetail>(() => pus)
                            .Inner.JoinAlias(() => pus.MPTUnitBook, () => mptbook)
                            .Left.JoinAlias(() => pus.PropertyUnit, () => pu)
                            .Left.JoinAlias(() => pus.PropertyUnit.PropertyTower, () => pt)
                            .Left.JoinAlias(() => pus.PropertyUnit.PropertyTower.Property, () => p)
                            .Left.JoinAlias(() => pus.PropertyUnit.PropertyTower.Property.FirmAccount, () => fm)
                            .Left.JoinAlias(() => pus.Customer, () => c);
                        prUnitSaleDetailDTO = query.Where(() => pus.FirmNumber == firmNumber && pus.Id == prUnitSaleId)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<PrUnitSaleDetailDTO>()).SingleOrDefault<PrUnitSaleDetailDTO>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Unexpected error fetching Unit Details for Payment:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return prUnitSaleDetailDTO;
        }
        public IList<PrUnitSalePymtDTO> fetchUnitPaymentHeaders(string firmNumber, long prUnitSaleId, PaymentMode? PymtMode, bool fetchDeletedPymtHeaders)
        {
            ISession session = null;
            IList<PrUnitSalePymtDTO> result = new List<PrUnitSalePymtDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PrUnitSalePymt pusp = null;
                        Property p = null;
                        PropertyUnit pu = null;
                        PrUnitSaleDetail pus = null;
                        Customer c = null;
                        FirmAccount fm = null;
                        PropertyTower pt = null;
                        PaymentMaster pm = null;
                        MasterControlData pymttype = null;
                        MPTBook mptbook = null;

                        PrUnitSalePymtDTO puspdt = null;
                        
                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => pusp.Id).WithAlias(() => puspdt.Id))
                                    .Add(Projections.Property(() => pusp.PymtMode).WithAlias(() => puspdt.PymtMode))
                                    .Add(Projections.Property(() => pymttype.Id), "PymtType.Id")
                                    .Add(Projections.Property(() => pymttype.Name), "PymtType.Name")
                                    .Add(Projections.Property(() => pm.Id), "PaymentMaster.Id")
                                    .Add(Projections.Property(() => pm.TotalAmt), "PaymentMaster.TotalAmt")
                                    .Add(Projections.Property(() => pm.TotalPaid), "PaymentMaster.TotalPaid")
                                    .Add(Projections.Property(() => pm.TotalPending), "PaymentMaster.TotalPending")
                                    .Add(Projections.Property(() => pm.Status), "PaymentMaster.Status");
                        var query = session.QueryOver<PrUnitSalePymt>(() => pusp)
                            .Inner.JoinAlias(() => pusp.PaymentMaster, () => pm)
                            .Inner.JoinAlias(() => pusp.PymtType, () => pymttype)
                            .Left.JoinAlias(() => pusp.PrUnitSaleDetail, () => pus);
                        if(!fetchDeletedPymtHeaders) {
                            ICriteria criteria = query.RootCriteria;
                            criteria.Add(Restrictions.Not(Restrictions.Eq(CommonUtil.BuildProjection<PaymentMaster>(() => pm, x => x.Status), PymtMasterStatus.Deleted)));
                        }
                        if(PymtMode != null) {
                            ICriteria criteria = query.RootCriteria;
                            criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<PrUnitSalePymt>(() => pusp, x => x.PymtMode), PymtMode));
                        }
                        result = query.Where(() => pusp.FirmNumber == firmNumber && pus.Id == prUnitSaleId)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<PrUnitSalePymtDTO>()).List<PrUnitSalePymtDTO>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Unexpected error fetching Unit Payments and Transaction:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public List<MasterPymtTransactionDTO> fetchMPTForPropertyUnit(string firmNumber, long prUnitSaleDetailId, PaymentMode pymtMode)
        {
            ISession session = null;
            List<MasterPymtTransactionDTO> mptDTOs = new List<MasterPymtTransactionDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PaymentTransactionDTO ptxDto = null;

                        MasterPymtTransaction mpt = null;
                        MPTBook mptBook = null;
                        Property p = null;
                        PrUnitSaleDetail pus = null;
                        PaymentTransaction ptx = null;
                        PaymentMaster pm = null;
                        FirmAccount fa = null;

                        var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => ptx.Id).WithAlias(() => ptxDto.Id))
                                .Add(Projections.Property(() => ptx.Amount).WithAlias(() => ptxDto.Amount))
                                .Add(Projections.Property(() => ptx.Comments).WithAlias(() => ptxDto.Comments))
                                .Add(Projections.Property(() => ptx.Status).WithAlias(() => ptxDto.Status))
                                .Add(Projections.Property(() => pm.Id), "PaymentMaster.Id")
                                .Add(Projections.Property(() => fa.Id), "FirmAccount.Id")
                                .Add(Projections.Property(() => fa.Name), "FirmAccount.Name")
                                .Add(Projections.Property(() => mpt.Id), "MasterPymtTransaction.Id")
                                .Add(Projections.Property(() => mpt.PymtMode), "MasterPymtTransaction.PymtMode")
                                .Add(Projections.Property(() => mpt.TxRefNo), "MasterPymtTransaction.TxRefNo")
                                .Add(Projections.Property(() => mpt.PymtMethod), "MasterPymtTransaction.PymtMethod")
                                .Add(Projections.Property(() => mpt.TxDate), "MasterPymtTransaction.TxDate")
                                .Add(Projections.Property(() => mpt.PymtAmt), "MasterPymtTransaction.PymtAmt")
                                .Add(Projections.Property(() => mpt.CollectionDate), "MasterPymtTransaction.CollectionDate")
                                .Add(Projections.Property(() => mpt.ChequeDate), "MasterPymtTransaction.ChequeDate")
                                .Add(Projections.Property(() => mpt.ClearanceDate), "MasterPymtTransaction.ClearanceDate")
                                .Add(Projections.Property(() => mpt.PayName), "MasterPymtTransaction.PayName")
                                .Add(Projections.Property(() => mpt.BankName), "MasterPymtTransaction.BankName")
                                .Add(Projections.Property(() => mpt.Branch), "MasterPymtTransaction.Branch")                                
                                .Add(Projections.Property(() => mpt.MediaNo), "MasterPymtTransaction.MediaNo")
                                .Add(Projections.Property(() => mpt.ChequeStatus), "MasterPymtTransaction.ChequeStatus")
                                .Add(Projections.Property(() => mpt.Comments), "MasterPymtTransaction.Comments")
                                .Add(Projections.Property(() => mpt.PymtStatus), "MasterPymtTransaction.PymtStatus")
                                .Add(Projections.Property(() => mptBook.Id), "MasterPymtTransaction.MPTBook.Id");
                        
                        var query = session.QueryOver<MasterPymtTransaction>(() => mpt)
                                .Inner.JoinAlias(() => mpt.MPTBook, () => mptBook)
                                .Inner.JoinAlias(() => mpt.MPTBook.PrUnitSaleDetail, () => pus)
                                .Left.JoinAlias(() => mpt.PaymentTransactions, () => ptx)
                                .Left.JoinAlias(() => ptx.PaymentMaster, () => pm)
                                .Left.JoinAlias(() => ptx.FirmAccount, () => fa);
                        IList<PaymentTransactionDTO> result = query.Where(() => mpt.FirmNumber == firmNumber && pus.Id == prUnitSaleDetailId
                                 && mpt.PymtMode == pymtMode)
                                .Select(proj)
                                .TransformUsing(new DeepTransformer<PaymentTransactionDTO>()).List<PaymentTransactionDTO>();
                        if(result != null && result.Count > 0) {
                            foreach (PaymentTransactionDTO ptxDTO in result) {
                                MasterPymtTransactionDTO mptDTO = mptDTOs.Find(x => x.Id == ptxDTO.MasterPymtTransaction.Id);
                                if(mptDTO == null) {
                                    mptDTO = ptxDTO.MasterPymtTransaction;
                                    mptDTO.PaymentTransactions = new HashSet<PaymentTransactionDTO>();
                                    mptDTOs.Add(mptDTO);
                                }
                                if(ptxDTO.Id > 0) mptDTO.PaymentTransactions.Add(ptxDTO);
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading MPT for Property Unit:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return mptDTOs;
        }
        public string addMasterPymtTransactionDetails(MasterPymtTransactionDTO mptDto)
        {
            ISession session = null;
            string txRefNo = "";
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        MasterPymtTransaction mpt = DTOToDomainUtil.populateMasterPymtTransactionAddFields(mptDto);
                        FirmAccount firmAccount = null;
                        foreach (PaymentTransaction pymtTras in mpt.PaymentTransactions)
                        {
                            PaymentMaster pMaster = session.Get<PaymentMaster>(pymtTras.PaymentMaster.Id);
                            if (PymtTransStatus.Pending == pymtTras.Status) pMaster.TotalPdcAmt = Decimal.Add(pMaster.TotalPdcAmt, pymtTras.Amount);
                            if (PymtTransStatus.Paid == pymtTras.Status)
                            {
                                pMaster.TotalPaid = Decimal.Add(pMaster.TotalPaid, pymtTras.Amount);
                                pMaster.TotalPending = Decimal.Subtract(pMaster.TotalAmt, pMaster.TotalPaid);
                                if (pMaster.TotalPending <= 0)
                                {
                                    pMaster.TotalPending = Decimal.Zero;
                                    pMaster.Status = PymtMasterStatus.Paid;
                                }
                                else
                                {
                                    pMaster.Status = PymtMasterStatus.Pending;
                                }
                                pMaster.UpdateUser = mptDto.UpdateUser;
                                pMaster.UpdateDate = DateTime.Now;
                                firmAccount = session.Get<FirmAccount>(pymtTras.FirmAccount.Id);
                                firmAccount.AccountBalance = (pymtTras.AccountTransaction.TxType == AcntTransStatus.Credit) 
                                    ? Decimal.Add(firmAccount.AccountBalance, pymtTras.Amount) : Decimal.Subtract(firmAccount.AccountBalance, pymtTras.Amount);
                                firmAccount.UpdateUser = mptDto.UpdateUser;
                                firmAccount.UpdateDate = DateTime.Now;
                                session.Update(firmAccount);
                            }
                            session.Update(pMaster);
                        }
                        session.Save(mpt);
                        mpt.TxRefNo = CommonUtil.getMasterTxRefNo(mpt.Id);
                        session.Update(mpt);
                        session.Flush();
                        //REF# in comment is updated with payment transaction no which is inserted above
                        foreach (PaymentTransaction pymtTras in mpt.PaymentTransactions)
                        {
                            AccountTransaction acntTrans = pymtTras.AccountTransaction;
                            if (acntTrans != null)
                            {
                                acntTrans.Comments = string.Format(acntTrans.Comments, pymtTras.Id);
                                session.Update(acntTrans);
                            }
                        }
                        tx.Commit();
                        txRefNo = mpt.TxRefNo;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while adding Master Payment Transaction details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return txRefNo;
        }
        public string updateMasterPymtTransactionDetails(MasterPymtTransactionDTO mptDto)
        {
            ISession session = null;
            string txRefNo = "";
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        MasterPymtTransaction mpt = session.Get<MasterPymtTransaction>(mptDto.Id);
                        FirmAccount firmAccount = null;
                        //Reduce all payment transaction amounts from Payment master and account
                        List<PaymentMaster> paymentMasterList = new List<PaymentMaster>();
                        foreach (PaymentTransaction pymtTras in mpt.PaymentTransactions)
                        {
                            PaymentMaster pMaster = pymtTras.PaymentMaster;
                            if (PymtTransStatus.Pending == pymtTras.Status) pMaster.TotalPdcAmt = Decimal.Subtract(pMaster.TotalPdcAmt, pymtTras.Amount);
                            if (PymtTransStatus.Paid == pymtTras.Status) {
                                pMaster.TotalPaid = Decimal.Subtract(pMaster.TotalPaid, pymtTras.Amount);
                                pMaster.TotalPending = Decimal.Subtract(pMaster.TotalAmt, pMaster.TotalPaid);
                                if (pMaster.TotalPending <= 0)
                                {
                                    pMaster.TotalPending = Decimal.Zero;
                                    pMaster.Status = PymtMasterStatus.Paid;
                                }
                                else
                                {
                                    pMaster.Status = PymtMasterStatus.Pending;
                                }
                                pMaster.UpdateUser = mptDto.UpdateUser;
                                pMaster.UpdateDate = DateTime.Now;
                                firmAccount = session.Get<FirmAccount>(pymtTras.FirmAccount.Id);
                                firmAccount.AccountBalance = (pymtTras.AccountTransaction.TxType == AcntTransStatus.Credit)
                                    ? Decimal.Subtract(firmAccount.AccountBalance, pymtTras.Amount) : Decimal.Add(firmAccount.AccountBalance, pymtTras.Amount);
                                firmAccount.UpdateUser = mptDto.UpdateUser;
                                firmAccount.UpdateDate = DateTime.Now;
                                session.Update(firmAccount);
                            }
                            paymentMasterList.Add(pMaster);                            
                        }
                        DTOToDomainUtil.populateMasterPymtTransactionUpdateFields(mpt, mptDto);
                        foreach (PaymentTransaction pymtTras in mpt.PaymentTransactions)
                        {
                            PaymentMaster pMaster = paymentMasterList.Find(x => x.Id == pymtTras.PaymentMaster.Id);
                            if (pMaster == null) {
                                pMaster = session.Get<PaymentMaster>(pymtTras.PaymentMaster.Id);
                                paymentMasterList.Add(pMaster);
                            }
                            if (PymtTransStatus.Pending == pymtTras.Status) pMaster.TotalPdcAmt = Decimal.Add(pMaster.TotalPdcAmt, pymtTras.Amount);
                            if (PymtTransStatus.Paid == pymtTras.Status)
                            {
                                pMaster.TotalPaid = Decimal.Add(pMaster.TotalPaid, pymtTras.Amount);
                                pMaster.TotalPending = Decimal.Subtract(pMaster.TotalAmt, pMaster.TotalPaid);
                                if (pMaster.TotalPending <= 0)
                                {
                                    pMaster.TotalPending = Decimal.Zero;
                                    pMaster.Status = PymtMasterStatus.Paid;
                                }
                                else
                                {
                                    pMaster.Status = PymtMasterStatus.Pending;
                                }
                                pMaster.UpdateUser = mptDto.UpdateUser;
                                pMaster.UpdateDate = DateTime.Now;
                                firmAccount = session.Get<FirmAccount>(pymtTras.FirmAccount.Id);
                                firmAccount.AccountBalance = (pymtTras.AccountTransaction.TxType == AcntTransStatus.Credit)
                                    ? Decimal.Add(firmAccount.AccountBalance, pymtTras.Amount) : Decimal.Subtract(firmAccount.AccountBalance, pymtTras.Amount);
                                firmAccount.UpdateUser = mptDto.UpdateUser;
                                firmAccount.UpdateDate = DateTime.Now;
                                session.Update(firmAccount);
                            }
                        }
                        foreach(PaymentMaster pMaster in paymentMasterList) {
                            session.Update(pMaster);
                        }
                        session.Update(mpt);
                        session.Flush();
                        //REF# in comment is updated with payment transaction no which is inserted above
                        foreach (PaymentTransaction pymtTras in mpt.PaymentTransactions)
                        {
                            AccountTransaction acntTrans = pymtTras.AccountTransaction;
                            if (acntTrans != null)
                            {
                                acntTrans.Comments = string.Format(acntTrans.Comments, pymtTras.Id);
                                session.Update(acntTrans);
                            }
                        }
                        tx.Commit();
                        txRefNo = mpt.TxRefNo;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating Master Payment Transaction details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return txRefNo;
        }
        public string deleteMasterPymtTransactionDetails(MasterPymtTransactionDTO mptDto)
        {
            ISession session = null;
            string txRefNo = "";
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        MasterPymtTransaction mpt = session.Get<MasterPymtTransaction>(mptDto.Id);
                        FirmAccount firmAccount = null;
                        //Reduce all payment transaction amounts from Payment master and account
                        List<PaymentMaster> paymentMasterList = new List<PaymentMaster>();
                        List<PaymentTransaction> reversalTxList = new List<PaymentTransaction>();
                        foreach (PaymentTransaction pymtTras in mpt.PaymentTransactions)
                        {
                            PaymentMaster pMaster = pymtTras.PaymentMaster;
                            if (PymtTransStatus.Pending == pymtTras.Status) pMaster.TotalPdcAmt = Decimal.Subtract(pMaster.TotalPdcAmt, pymtTras.Amount);
                            if (PymtTransStatus.Paid == pymtTras.Status)
                            {
                                pMaster.TotalPaid = Decimal.Subtract(pMaster.TotalPaid, pymtTras.Amount);
                                pMaster.TotalPending = Decimal.Subtract(pMaster.TotalAmt, pMaster.TotalPaid);
                                if (pMaster.TotalPending <= 0)
                                {
                                    pMaster.TotalPending = Decimal.Zero;
                                    pMaster.Status = PymtMasterStatus.Paid;
                                }
                                else
                                {
                                    pMaster.Status = PymtMasterStatus.Pending;
                                }
                                pMaster.UpdateUser = mptDto.UpdateUser;
                                pMaster.UpdateDate = DateTime.Now;
                                firmAccount = session.Get<FirmAccount>(pymtTras.FirmAccount.Id);
                                firmAccount.AccountBalance = (pymtTras.AccountTransaction.TxType == AcntTransStatus.Credit)
                                    ? Decimal.Subtract(firmAccount.AccountBalance, pymtTras.Amount) : Decimal.Add(firmAccount.AccountBalance, pymtTras.Amount);
                                firmAccount.UpdateUser = mptDto.UpdateUser;
                                firmAccount.UpdateDate = DateTime.Now;
                                session.Update(firmAccount);

                                pymtTras.Status = PymtTransStatus.Deleted;
                                pymtTras.UpdateDate = DateTime.Now;
                                pymtTras.UpdateUser = mptDto.UpdateUser;
                                reversalTxList.Add(PaymentUtil.createReversalPymtTransactionDTO(pymtTras, mptDto));
                            }
                            paymentMasterList.Add(pMaster);
                        }
                        mpt.PymtStatus = MPTPymtStatus.Deleted;
                        mpt.UpdateDate = DateTime.Now;
                        mpt.UpdateUser = mptDto.UpdateUser;
                        reversalTxList.ForEach(x => mpt.PaymentTransactions.Add(x));
                        foreach (PaymentMaster pMaster in paymentMasterList)
                        {
                            session.Update(pMaster);
                        }
                        session.Update(mpt);
                        session.Flush();
                        //REF# in comment is updated with payment transaction no which is inserted above
                        foreach (PaymentTransaction pymtTras in mpt.PaymentTransactions)
                        {
                            AccountTransaction acntTrans = pymtTras.AccountTransaction;
                            if (acntTrans != null)
                            {
                                acntTrans.Comments = string.Format(acntTrans.Comments, pymtTras.Id);
                                session.Update(acntTrans);
                            }
                        }
                        tx.Commit();
                        txRefNo = mpt.TxRefNo;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while deleting Master Payment Transaction details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return txRefNo;
        }
        public MasterPymtTransactionDTO fetchMasterPymtTransactionDetails(long Id)
        {
            ISession session = null;
            MasterPymtTransactionDTO mptDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        MasterPymtTransaction mpt = session.Get<MasterPymtTransaction>(Id);
                        mptDto = DomainToDTOUtil.convertToMPTDTO(mpt, true);
                        
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Post Dated Cheque details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return mptDto;
        }
        public PaymentMasterDTO fetchPaymentMaster(long Id)
        {
            ISession session = null;
            PaymentMasterDTO paymentMasterDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PaymentMaster paymentMaster = session.Get<PaymentMaster>(Id);
                        paymentMasterDto = DomainToDTOUtil.convertToPaymentMasterDTO(paymentMaster, true, true);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Payment Masters details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return paymentMasterDto;
        }
        public void addPymtTransaction(PaymentTransactionDTO pymtTransDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PaymentMaster pymtMaster = session.Get<PaymentMaster>(pymtTransDto.PaymentMaster.Id);
                        DTOToDomainUtil.populatePaymentMasterUpdateFields(pymtMaster, pymtTransDto.PaymentMaster);
                        PaymentTransaction pymtTransaction = DTOToDomainUtil.populatePaymentTransactionAddFields(pymtTransDto);
                        pymtMaster.PaymentTransactions.Add(pymtTransaction);
                        if (pymtTransDto.Status == PymtTransStatus.Reversal)
                        {
                            PaymentTransaction orgPymtTransaction = pymtMaster.PaymentTransactions.ToList<PaymentTransaction>()
                                .Find(p => p.Id == pymtTransDto.CancelledPaymentTransaction.Id);
                            orgPymtTransaction.Status = PymtTransStatus.Deleted;
                            orgPymtTransaction.UpdateUser = pymtTransDto.UpdateUser;
                            orgPymtTransaction.UpdateDate = DateTime.Now;
                        }
                        pymtTransaction.PaymentMaster = pymtMaster;
                        session.Update(pymtMaster);
                        FirmAccount firmAccount = session.Get<FirmAccount>(pymtTransDto.AccountTransaction.FirmAccount.Id);
                        firmAccount.AccountBalance = (pymtTransDto.AccountTransaction.TxType == AcntTransStatus.Credit)
                                    ? Decimal.Add(firmAccount.AccountBalance, pymtTransDto.Amount) : Decimal.Subtract(firmAccount.AccountBalance, pymtTransDto.Amount);
                        session.Update(firmAccount);
                        session.Flush();
                        //REF# in comment is updated with payment transaction no which is inserted above
                        AccountTransaction acntTrans = pymtTransaction.AccountTransaction;
                        acntTrans.Comments = string.Format(acntTrans.Comments, pymtTransaction.Id);
                        session.Update(acntTrans);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Adding payment transaction:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void deleteUnpaidPdcDetails(long Id, string userName)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        MasterPymtTransaction mpt = session.Get<MasterPymtTransaction>(Id);
                        foreach (PaymentTransaction pymtTras in mpt.PaymentTransactions)
                        {
                            PaymentMaster pMaster = session.Get<PaymentMaster>(pymtTras.PaymentMaster.Id);
                            if (PymtTransStatus.Pending == pymtTras.Status) {
                                pMaster.TotalPdcAmt = Decimal.Subtract(pMaster.TotalPdcAmt, pymtTras.Amount);
                                pMaster.UpdateUser = userName;
                                pMaster.UpdateDate = DateTime.Now;
                                session.Update(pMaster);
                            }
                        }
                        session.Delete(mpt);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Deleting Unpaid Post Dated Cheque details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
    }
}