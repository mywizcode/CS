﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
	initPaymentTxHistoryGrid();
	initPdcHistoryGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}
function initPaymentTxHistoryGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        rowInfoModalTitle: "Payment Transaction Details",
        pageLength: 5,
        sortColumn: 3,
        sortOrder: "desc",
        hideSearch: true
    };

    $("[id$='txHistoryGrid']").CSBasicDatatable(dtOptions);
}
function initPdcHistoryGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        rowInfoModalTitle: "Cheque Details",
        pageLength: 5,
        sortColumn: 2,
        sortOrder: "desc",
        hideSearch: true
    };

    $("[id$='pdcGrid']").CSBasicDatatable(dtOptions);
}