﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initParkingSearchGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initParkingSearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#propertyParkingSearchBtnDiv",
        pageLength: 10
    };

    $("[id$='propertyParkingSearchGrid']").CSBasicDatatable(dtOptions);
}

