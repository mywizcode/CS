﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initDLHistoryGrid();
	formatFields(controlToFormat);
    showModal(controlToFormat);
}
function initDLHistoryGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        hideSearch: true,
        pageLength: 10
    };

    $("[id$='dlHistoryGrid']").CSBasicDatatable(dtOptions);
}