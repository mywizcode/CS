﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
	initUserRoleGrid();
	formatFields(controlToFormat);
    showModal(controlToFormat);
}
function initUserRoleGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#UserRoleSearchBtnDiv",
        pageLength: 5,
        hideSearch: true
    };

    $("[id$='UserRoleGrid']").CSBasicDatatable(dtOptions);
}