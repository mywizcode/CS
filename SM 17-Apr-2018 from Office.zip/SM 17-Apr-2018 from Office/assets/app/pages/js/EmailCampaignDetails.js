﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initPersonalizationGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
    var isViewMode =  $("[id$='pageModeHdn']").val() == "VIEW";
    initSummernote(controlToFormat, isViewMode);
}

function initPersonalizationGrid() {
    var dtOptions = {
        hasActionColumn: false,
        hideSearch: true,
        pagination: false,
        sorting: false
    };

    $("[id$='personalizationGrid']").CSBasicDatatable(dtOptions);
}