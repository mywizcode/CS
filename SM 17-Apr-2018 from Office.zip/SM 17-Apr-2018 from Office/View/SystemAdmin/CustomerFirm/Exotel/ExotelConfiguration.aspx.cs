﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using ConstroSoft;

public partial class ExotelConfiguration : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifyExotelConfigError = "addModifyExotelConfigError";
    string addModifyExotelConfigModal = "addModifyExotelConfigModal";
    DropdownBO drpBO = new DropdownBO();
    FirmBO firmBO = new FirmBO();
    public enum ExotelConfigModalAction { ADD, MODIFY }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                ExotelConfigurationNavDTO navDto = ApplicationUtil.getPageNavDTO<ExotelConfigurationNavDTO>(Session);
                if (!CommonUtil.IsSystemAdminRole(getUserDefinitionDTO())) (this.Master as CSAdminMaster).doLogout(Constants.URL.SYS_ADMIN_LOGIN_FAILED);
                if (CommonUtil.getCurrentFirmDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToSystemDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSAdminMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
        addCheckBoxAttributes();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private void addCheckBoxAttributes()
    {
        cbExotelConfigEnable.InputAttributes.Add("class", "styled");
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];

    }
    public void setErrorMessage(string message, string group)
    {
        string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }
    }
    private void doInit(ExotelConfigurationNavDTO navDTO)
    {
        Session[Constants.Session.PAGE_DATA] = new ExotelConfigurationPageDTO();
        initDropdowns();
        loadExotelConfigGrid();
    }
    private void renderPageFieldsWithEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
    }
    private ExotelConfigurationPageDTO getSessionPageData()
    {
        return (ExotelConfigurationPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private void loadExotelConfigGrid()
    {
        ExotelConfigurationPageDTO PageDTO = getSessionPageData();
        IList<ExotelDTO> result = firmBO.fetchExotelConfigs(CommonUtil.getCurrentFirmDTO(getUserDefinitionDTO()).FirmNumber);
        PageDTO.ExotelConfigList = (result != null) ? result.ToList<ExotelDTO>() : new List<ExotelDTO>();

        populateExotelConfigGrid(PageDTO.ExotelConfigList);
    }
    private void populateExotelConfigGrid(List<ExotelDTO> tmpList)
    {
        ExotelConfigGrid.DataSource = new List<ExotelDTO>();
        if (tmpList != null)
        {
            assignUiIndexToExotelConfig(tmpList);
            ExotelConfigGrid.DataSource = tmpList;
        }
        ExotelConfigGrid.DataBind();
    }
    private void assignUiIndexToExotelConfig(List<ExotelDTO> tmpList)
    {
        if (tmpList != null && tmpList.Count > 0)
        {
            foreach (ExotelDTO tmpDTO in tmpList)
            {
                tmpDTO.RowInfo = CommonUIConverter.getGridViewRowInfo(tmpDTO);
            }
        }
    }
    protected void onClickDeleteExotelConfigBtn(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            ExotelDTO selectedDTO = getSelectedExotelConfig(selectedIndex);
            firmBO.deleteExotelConfig(selectedDTO.Id);
            (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(CommonUtil.getRecordDeleteSuccessMsg("Exotel Configuration")));
            loadExotelConfigGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //ExotelConfig Modal - Start
    private bool isExotelConfigAddMode()
    {
        return (ExotelConfigModalAction.ADD.ToString().Equals(ExotelConfigModalActionHdnBtn.Value));
    }
    private void initExotelConfigModalFields()
    {
        lbExotelConfigModalTitle.Text = (ExotelConfigModalAction.ADD.ToString().Equals(ExotelConfigModalActionHdnBtn.Value))
            ? Constants.ICON.ADD + "Add Configuration" : Constants.ICON.MODIFY + "Modify Configuration";
    }
    private void initExotelConfigSectionFields(ExotelDTO tmpDTO)
    {
        if (tmpDTO != null) txtExotelConfigSid.Text = tmpDTO.Sid; else txtExotelConfigSid.Text = null;
        if (tmpDTO != null) txtExotelConfigToken.Text = tmpDTO.Token; else txtExotelConfigToken.Text = null;
        if (tmpDTO != null) txtExotelConfigOutCallBackURL.Text = tmpDTO.OutCallBackURL; else txtExotelConfigOutCallBackURL.Text = null;
        if (tmpDTO != null) txtExotelConfigOutCallURL.Text = tmpDTO.OutCallURL; else txtExotelConfigOutCallURL.Text = null;
        if (tmpDTO != null) txtExotelConfigCallType.Text = tmpDTO.CallType; else txtExotelConfigCallType.Text = null;
        if (tmpDTO != null) txtExotelConfigCallDetailsURL.Text = tmpDTO.CallDetailsURL; else txtExotelConfigCallDetailsURL.Text = null;
        
        cbExotelConfigEnable.Checked = (tmpDTO != null && tmpDTO.IsEnabled == IsEnabled.Yes);
    }
    private void populateExotelConfigFromUI(ExotelDTO tmpDTO)
    {
        tmpDTO.Sid = txtExotelConfigSid.Text.TrimNullable();
        tmpDTO.Token = txtExotelConfigToken.Text.TrimNullable();
        tmpDTO.OutCallBackURL = txtExotelConfigOutCallBackURL.Text.TrimNullable();
        tmpDTO.OutCallURL = txtExotelConfigOutCallURL.Text.TrimNullable();
        tmpDTO.CallType = txtExotelConfigCallType.Text.TrimNullable();
        tmpDTO.CallDetailsURL = txtExotelConfigCallDetailsURL.Text.TrimNullable();
        tmpDTO.IsEnabled = (cbExotelConfigEnable.Checked) ? IsEnabled.Yes : IsEnabled.No;
        tmpDTO.UpdateUser = getUserDefinitionDTO().Username;
    }
    private ExotelDTO populateExotelConfigAdd()
    {
        ExotelDTO tmpDTO = new ExotelDTO();
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        tmpDTO.Firm = CommonUtil.getCurrentFirmDTO(userDef);
        tmpDTO.InsertUser = userDef.Username;
        return tmpDTO;
    }
    private void setSelectedExotelConfig(long Id)
    {
        List<ExotelDTO> tmpList = getSessionPageData().ExotelConfigList;
        tmpList.ForEach(c => c.isUISelected = false);
        if (Id > 0) tmpList.Find(c => c.Id == Id).isUISelected = true;
    }
    private ExotelDTO getSelectedExotelConfig(long Id)
    {
        List<ExotelDTO> tmpList = getSessionPageData().ExotelConfigList;
        return (Id > 0) ? tmpList.Find(c => c.Id == Id) : tmpList.Find(c => c.isUISelected);
    }
    protected void onClickAddExotelConfigBtn(object sender, EventArgs e)
    {
        try
        {
            ExotelConfigModalActionHdnBtn.Value = ExotelConfigModalAction.ADD.ToString();
            initExotelConfigModalFields();
            setSelectedExotelConfig(-1);
            initExotelConfigSectionFields(null);
            activeModalHdn.Value = addModifyExotelConfigModal;
            SetFocus(txtExotelConfigSid);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyExotelConfigBtn(object sender, EventArgs e)
    {
        try
        {
            ExotelConfigModalActionHdnBtn.Value = ExotelConfigModalAction.MODIFY.ToString();
            initExotelConfigModalFields();
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedExotelConfig(selectedIndex);
            initExotelConfigSectionFields(getSelectedExotelConfig(0));
            activeModalHdn.Value = addModifyExotelConfigModal;
            SetFocus(txtExotelConfigSid);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void saveExotelConfig(object sender, EventArgs e)
    {
        try
        {
            if (validateExotelConfigAddModify())
            {
                ExotelDTO tmpDTO = null;
                string msg = "";
                if (isExotelConfigAddMode())
                {
                    tmpDTO = populateExotelConfigAdd();
                    msg = CommonUtil.getNotySuccessMsg(CommonUtil.getRecordAddSuccessMsg("Exotel Configuration"));
                }
                else
                {
                    tmpDTO = getSelectedExotelConfig(0);
                    msg = CommonUtil.getNotySuccessMsg(CommonUtil.getRecordModifySuccessMsg("Exotel Configuration"));
                }
                populateExotelConfigFromUI(tmpDTO);
                firmBO.saveOrUpdateExotelConfig(tmpDTO);
                (this.Master as CSAdminMaster).setNotyMsg(msg);
                loadExotelConfigGrid();
            }
            else
            {
                activeModalHdn.Value = addModifyExotelConfigModal;
                SetFocus(txtExotelConfigSid);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelExotelConfigModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateExotelConfigAddModify()
    {
        Page.Validate(addModifyExotelConfigError);
        bool IsValid = Page.IsValid;
        if (IsValid)
        {
            if (isExotelConfigAddMode() && cbExotelConfigEnable.Checked)
            {
                if (getSessionPageData().ExotelConfigList.Any(x => x.IsEnabled == IsEnabled.Yes))
                {
                    setErrorMessage("Another exotel configuration is already enabled.", addModifyExotelConfigError);
                }
            }
            else if (!isExotelConfigAddMode() && cbExotelConfigEnable.Checked)
            {
                ExotelDTO tmpDTO = getSelectedExotelConfig(0);
                if (getSessionPageData().ExotelConfigList.Any(x => x.IsEnabled == IsEnabled.Yes && x.Id != tmpDTO.Id))
                {
                    setErrorMessage("Another exotel configuration is already enabled.", addModifyExotelConfigError);
                }
            }
        }
        return IsValid;
    }
    //ExotelConfig Modal - End
}