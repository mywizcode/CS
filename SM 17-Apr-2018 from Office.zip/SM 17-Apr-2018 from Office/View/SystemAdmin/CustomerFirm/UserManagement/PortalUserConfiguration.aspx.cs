﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using ConstroSoft;

public partial class PortalUserConfiguration : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifyPortalUserConfigError = "addModifyPortalUserConfigError";
    string addModifyPortalUserConfigModal = "addModifyPortalUserConfigModal";
    DropdownBO drpBO = new DropdownBO();
    SystemAdminstrationBO sysAdminBO = new SystemAdminstrationBO();
    public enum PortalUserConfigModalAction { ADD, MODIFY }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                PortalUserConfigurationNavDTO navDto = ApplicationUtil.getPageNavDTO<PortalUserConfigurationNavDTO>(Session);
                if (!CommonUtil.IsSystemAdminRole(getUserDefinitionDTO())) (this.Master as CSAdminMaster).doLogout(Constants.URL.SYS_ADMIN_LOGIN_FAILED);
                if (CommonUtil.getCurrentFirmDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToSystemDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSAdminMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
        addCheckBoxAttributes();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private void addCheckBoxAttributes()
    {
        cbPortalUserConfigEnable.InputAttributes.Add("class", "styled");
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];

    }
    public void setErrorMessage(string message, string group)
    {
        string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }
    }
    private void doInit(PortalUserConfigurationNavDTO navDTO)
    {
        Session[Constants.Session.PAGE_DATA] = new PortalUserConfigurationPageDTO();
        initDropdowns();
        loadPortalUserConfigGrid();
    }
    private void renderPageFieldsWithEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
    }
    private PortalUserConfigurationPageDTO getSessionPageData()
    {
        return (PortalUserConfigurationPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private void loadPortalUserConfigGrid()
    {
        PortalUserConfigurationPageDTO PageDTO = getSessionPageData();
        IList<PortalUserDTO> result = sysAdminBO.fetchPortalUsers(CommonUtil.getCurrentFirmDTO(getUserDefinitionDTO()).FirmNumber);
        PageDTO.PortalUserConfigList = (result != null) ? result.ToList<PortalUserDTO>() : new List<PortalUserDTO>();

        populatePortalUserConfigGrid(PageDTO.PortalUserConfigList);
    }
    private void populatePortalUserConfigGrid(List<PortalUserDTO> tmpList)
    {
        PortalUserConfigGrid.DataSource = new List<PortalUserDTO>();
        if (tmpList != null)
        {
            assignUiIndexToPortalUserConfig(tmpList);
            PortalUserConfigGrid.DataSource = tmpList;
        }
        PortalUserConfigGrid.DataBind();
    }
    private void assignUiIndexToPortalUserConfig(List<PortalUserDTO> tmpList)
    {

    }
    protected void onClickDeletePortalUserConfigBtn(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            PortalUserDTO selectedDTO = getSelectedPortalUserConfig(selectedIndex);
            sysAdminBO.deletePortalUser(selectedDTO.Id);
            (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(CommonUtil.getRecordDeleteSuccessMsg("Portal User")));
            loadPortalUserConfigGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //PortalUserConfig Modal - Start
    private bool isPortalUserConfigAddMode()
    {
        return (PortalUserConfigModalAction.ADD.ToString().Equals(PortalUserConfigModalActionHdnBtn.Value));
    }
    private void initPortalUserConfigModalFields()
    {
        lbPortalUserConfigModalTitle.Text = (PortalUserConfigModalAction.ADD.ToString().Equals(PortalUserConfigModalActionHdnBtn.Value))
            ? Constants.ICON.ADD + "Add Portal User" : Constants.ICON.MODIFY + "Modify Portal User";
    }
    private void initPortalUserConfigSectionFields(PortalUserDTO tmpDTO)
    {
        if (tmpDTO != null) txtPortalUserName.Text = tmpDTO.UserName; else txtPortalUserName.Text = null;
        if (tmpDTO != null) txtPortalUserPassword.Text = tmpDTO.Password; else txtPortalUserPassword.Text = null;
        if (tmpDTO != null) txtPortalUserDescription.Text = tmpDTO.Description; else txtPortalUserDescription.Text = null;
        
        cbPortalUserConfigEnable.Checked = (tmpDTO != null && tmpDTO.IsEnabled == IsEnabled.Yes);
    }
    private void populatePortalUserConfigFromUI(PortalUserDTO tmpDTO)
    {
        tmpDTO.UserName = txtPortalUserName.Text.TrimNullable();
        tmpDTO.Password = txtPortalUserPassword.Text.TrimNullable();
        tmpDTO.Description = txtPortalUserDescription.Text.TrimNullable();
        tmpDTO.IsEnabled = (cbPortalUserConfigEnable.Checked) ? IsEnabled.Yes : IsEnabled.No;
        tmpDTO.UpdateUser = getUserDefinitionDTO().Username;
    }
    private PortalUserDTO populatePortalUserConfigAdd()
    {
        PortalUserDTO tmpDTO = new PortalUserDTO();
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        tmpDTO.FirmNumber = CommonUtil.getCurrentFirmDTO(userDef).FirmNumber;
        tmpDTO.InsertUser = userDef.Username;
        return tmpDTO;
    }
    private void setSelectedPortalUserConfig(long Id)
    {
        List<PortalUserDTO> tmpList = getSessionPageData().PortalUserConfigList;
        tmpList.ForEach(c => c.isUISelected = false);
        if (Id > 0) tmpList.Find(c => c.Id == Id).isUISelected = true;
    }
    private PortalUserDTO getSelectedPortalUserConfig(long Id)
    {
        List<PortalUserDTO> tmpList = getSessionPageData().PortalUserConfigList;
        return (Id > 0) ? tmpList.Find(c => c.Id == Id) : tmpList.Find(c => c.isUISelected);
    }
    protected void onClickAddPortalUserConfigBtn(object sender, EventArgs e)
    {
        try
        {
            PortalUserConfigModalActionHdnBtn.Value = PortalUserConfigModalAction.ADD.ToString();
            initPortalUserConfigModalFields();
            setSelectedPortalUserConfig(-1);
            initPortalUserConfigSectionFields(null);
            activeModalHdn.Value = addModifyPortalUserConfigModal;
            SetFocus(txtPortalUserName);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyPortalUserConfigBtn(object sender, EventArgs e)
    {
        try
        {
            PortalUserConfigModalActionHdnBtn.Value = PortalUserConfigModalAction.MODIFY.ToString();
            initPortalUserConfigModalFields();
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedPortalUserConfig(selectedIndex);
            initPortalUserConfigSectionFields(getSelectedPortalUserConfig(0));
            activeModalHdn.Value = addModifyPortalUserConfigModal;
            SetFocus(txtPortalUserName);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void savePortalUserConfig(object sender, EventArgs e)
    {
        try
        {
            if (validatePortalUserConfigAddModify())
            {
                PortalUserDTO tmpDTO = null;
                string msg = "";
                if (isPortalUserConfigAddMode())
                {
                    tmpDTO = populatePortalUserConfigAdd();
                    msg = CommonUtil.getNotySuccessMsg(CommonUtil.getRecordAddSuccessMsg("Portal User"));
                }
                else
                {
                    tmpDTO = getSelectedPortalUserConfig(0);
                    msg = CommonUtil.getNotySuccessMsg(CommonUtil.getRecordModifySuccessMsg("Portal User"));
                }
                populatePortalUserConfigFromUI(tmpDTO);
                sysAdminBO.saveOrUpdatePortalUser(tmpDTO);
                (this.Master as CSAdminMaster).setNotyMsg(msg);
                loadPortalUserConfigGrid();
            }
            else
            {
                activeModalHdn.Value = addModifyPortalUserConfigModal;
                SetFocus(txtPortalUserName);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelPortalUserConfigModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validatePortalUserConfigAddModify()
    {
        Page.Validate(addModifyPortalUserConfigError);
        bool IsValid = Page.IsValid;
        return IsValid;
    }
    //PortalUserConfig Modal - End
}