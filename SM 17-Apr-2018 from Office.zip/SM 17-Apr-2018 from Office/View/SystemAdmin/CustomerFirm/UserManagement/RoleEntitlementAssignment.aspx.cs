﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using ConstroSoft;

public partial class RoleEntitlementAssignment : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    DropdownBO drpBO = new DropdownBO();
    FirmBO firmBO = new FirmBO();
    SystemAdminstrationBO sysAdminBO = new SystemAdminstrationBO();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                RoleEntitlementAssignementNavDTO navDto = ApplicationUtil.getPageNavDTO<RoleEntitlementAssignementNavDTO>(Session);
                if (!CommonUtil.IsSystemAdminRole(getUserDefinitionDTO())) (this.Master as CSAdminMaster).doLogout(Constants.URL.SYS_ADMIN_LOGIN_FAILED);
                if (CommonUtil.getCurrentFirmDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToSystemDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSAdminMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
        setPageTitle();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];

    }
    public void setErrorMessage(string message, string group)
    {
        string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }
    }
    private void doInit(RoleEntitlementAssignementNavDTO navDto)
    {
        if (navDto != null)
        {
            RoleEntitlementAssignementPageDTO PageDTO = new RoleEntitlementAssignementPageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            PageDTO.RoleDTO = sysAdminBO.fetchUserRole(navDto.RoleId);
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            pageModeHdn.Value = navDto.Mode.ToString();
            initDropdowns();
            loadEntitlementGrid();
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void setPageTitle()
    {
        if (isModifyMode()) lbPageTitle.Text = Constants.ICON.MODIFY + "Modify Entitlement Assignment";
        else if (isViewMode()) lbPageTitle.Text = Constants.ICON.VIEW_DTL + "Entitlements";
    }
    private void renderPageFieldsWithEntitlement()
    {
        bool modifyMode = isModifyMode();
        bool viewMode = isViewMode();

        //Fields
        
        lnkModifyAssignment.Visible = viewMode;
        fabMenuRight.Visible = modifyMode;
    }
    private bool isModifyMode()
    {
        return PageMode.MODIFY.ToString().Equals(pageModeHdn.Value);
    }
    private bool isViewMode()
    {
        return PageMode.VIEW.ToString().Equals(pageModeHdn.Value);
    }
    private RoleEntitlementAssignementPageDTO getSessionPageData()
    {
        return (RoleEntitlementAssignementPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private void navigateToPreviousPage()
    {
        RoleEntitlementAssignementPageDTO PageDTO = getSessionPageData();
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is ManageUserRolePageDTO)
            {
                ManageUserRolePageDTO navDTO = (ManageUserRolePageDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.USER_ROLE_SEARCH, true);
            }
        }
        Response.Redirect(Constants.URL.USER_ROLE_SEARCH, true);
    }
    private void navigateToCurrentPage()
    {
        RoleEntitlementAssignementNavDTO navDTO = new RoleEntitlementAssignementNavDTO();
        navDTO.Mode = PageMode.VIEW;
        navDTO.RoleId = getSessionPageData().RoleDTO.Id;
        Session[Constants.Session.NAV_DTO] = navDTO;
        Response.Redirect(Constants.URL.ROLE_ENTITLEMENT_ASSIGNMENT, true);
    }
    private void loadEntitlementGrid()
    {
        selectedEntitlementHdn.Value = "";
        RoleEntitlementAssignementPageDTO PageDTO = getSessionPageData();
        List<UserEntitlementDTO> finalList = new List<UserEntitlementDTO>();
        IList<UserEntitlementDTO> result = firmBO.fetchRoleEntitlements(PageDTO.RoleDTO.Id);
        if (result != null)
        {
            List<UserEntitlementDTO> RootNodes = CommonUtil.BuildTree(result.ToList<UserEntitlementDTO>());
            RootNodes.ForEach(x => finalList.AddRange(CommonUtil.DepthFirstTraversal(x)));
        }
        PageDTO.EntitlementList = finalList;
        lbRoleName.Text = getSessionPageData().RoleDTO.Name;
        populateEntitlementGrid(PageDTO.EntitlementList);
    }
    private void populateEntitlementGrid(List<UserEntitlementDTO> tmpList)
    {
        lbNoOfEntitlementAssigned.Text = "";
        EntitlementGrid.DataSource = new List<UserEntitlementDTO>();
        if (tmpList != null)
        {
            assignUiIndexToEntitlement(tmpList);
            EntitlementGrid.DataSource = tmpList;
        }
        EntitlementGrid.DataBind();
    }
    private void assignUiIndexToEntitlement(List<UserEntitlementDTO> tmpList)
    {
        if (tmpList != null && tmpList.Count > 0)
        {
            int cnt = 0;
            foreach (UserEntitlementDTO tmpDTO in tmpList)
            {
                tmpDTO.IsModifyMode = isModifyMode();
                tmpDTO.NodeClass = "level" + tmpDTO.Level;
                if (tmpDTO.isUISelected) {
                    tmpDTO.NodeClass += " selected";
                    cnt++;
                }
            }
            lbNoOfEntitlementAssigned.Text = cnt.ToString();
        }
    }
    private UserEntitlementDTO getUISelectedDTO()
    {
        UserEntitlementDTO tmpDTO = null;
        if (!string.IsNullOrWhiteSpace(selectedEntitlementHdn.Value))
        {
            long selectedId = long.Parse(selectedEntitlementHdn.Value);
            tmpDTO = getSessionPageData().EntitlementList.Find(x => x.Id == selectedId);
        }
        selectedEntitlementHdn.Value = "";
        return tmpDTO;
    }
    protected void onClickSelectEntitlementBtn(object sender, EventArgs e)
    {
        try
        {
            UserEntitlementDTO selectedDTO = getUISelectedDTO();
            if (selectedDTO != null)
            {
                bool NewSelectionFlag = !selectedDTO.isUISelected;
                EnableOrDisableChildEntitlement(selectedDTO, NewSelectionFlag);
                EnableOrDisableParentEntitlement(selectedDTO, NewSelectionFlag);
                populateEntitlementGrid(getSessionPageData().EntitlementList);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void EnableOrDisableChildEntitlement(UserEntitlementDTO tmpDTO, bool Flag)
    {
        tmpDTO.isUISelected = Flag;
        if (tmpDTO.Children != null && tmpDTO.Children.Count > 0)
        {
            foreach (UserEntitlementDTO child in tmpDTO.Children)
            {
                EnableOrDisableChildEntitlement(child, Flag);
            }
        }
    }
    private void EnableOrDisableParentEntitlement(UserEntitlementDTO tmpDTO, bool Flag)
    {
        tmpDTO.isUISelected = Flag;
        if (tmpDTO.Parent != null)
        {
            UserEntitlementDTO parentDTO = getSessionPageData().EntitlementList.Find(x => x.Id == tmpDTO.Parent.Id);
            if(!Flag) {
                bool isAnyChildEnabled = false;
                if (parentDTO.Children != null && parentDTO.Children.Count > 0)
                {
                    foreach (UserEntitlementDTO child in parentDTO.Children)
                    {
                        isAnyChildEnabled = child.isUISelected;
                        if(isAnyChildEnabled) break;
                    }
                }
                if (!isAnyChildEnabled) EnableOrDisableParentEntitlement(parentDTO, Flag);
            }
            else EnableOrDisableParentEntitlement(parentDTO, Flag);            
        }
    }
    protected void onClickModifyAssignmentBtn(object sender, EventArgs e)
    {
        try
        {
            pageModeHdn.Value = PageMode.MODIFY.ToString();
            loadEntitlementGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickSaveChangesBtn(object sender, EventArgs e)
    {
        try
        {
            RoleEntitlementAssignementPageDTO PageDTO = getSessionPageData();
            List<UserEntitlementDTO> AssignedList = PageDTO.EntitlementList.FindAll(x => x.isUISelected);
            firmBO.updateRoleEntitlementAssignment(PageDTO.RoleDTO.Id, AssignedList);
            (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("Entitlement assignment changes are saved successfully."));
            pageModeHdn.Value = PageMode.VIEW.ToString();
            loadEntitlementGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickCancelChangesBtn(object sender, EventArgs e)
    {
        try
        {
            pageModeHdn.Value = PageMode.VIEW.ToString();
            loadEntitlementGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
}