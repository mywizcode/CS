﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;

public partial class SubscriptionPlanDetails : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifyStep1Error = "addModifyStep1Error";
    DropdownBO drpBO = new DropdownBO();
    FirmBO firmBO = new FirmBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                SubscriptionPlanDetailNavDTO navDto = ApplicationUtil.getPageNavDTO<SubscriptionPlanDetailNavDTO>(Session);
                if (!CommonUtil.IsSystemAdminRole(getUserDefinitionDTO())) (this.Master as CSAdminMaster).doLogout(Constants.URL.SYS_ADMIN_LOGIN_FAILED);
                if (CommonUtil.getCurrentFirmDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToSystemDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSAdminMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        setPageTitle();
        renderPageFieldsWithEntitlement();
        addCheckBoxAttributes();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        drpBO.drpEnum<SubPlanPurchaseType>(drpPurchaseType, Constants.SELECT_ITEM);
        drpBO.drpEnum<SubscriptionPlanStatus>(drpPlanStatus, Constants.SELECT_ITEM);
    }
    private void setPageTitle()
    {
        if (isAddMode()) lbPageTitle.Text = Constants.ICON.ADD + "Add Plan";
        else if (isModifyMode()) lbPageTitle.Text = Constants.ICON.MODIFY + "Modify Plan";
        else lbPageTitle.Text = Constants.ICON.VIEW_DTL + "Plan Details";
    }
    public void setErrorMessage(string message, string group)
    {
        string[] pageErrorGrp = { commonError, addModifyStep1Error };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else CommonUtil.getCustomValidator(Page, message, group);
    }
    private void renderPageFieldsWithEntitlement()
    {
        bool modifyMode = isModifyMode();
        bool viewMode = isViewMode();
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        //Fields
        txtPlanName.ReadOnly = viewMode;
        txtPurchaseDate.ReadOnly = viewMode;
        txtStartDate.ReadOnly = viewMode;
        txtEndDate.ReadOnly = viewMode;
        txtNoOfUsers.ReadOnly = viewMode;
        drpPurchaseType.Enabled = !viewMode;
        drpPlanStatus.Enabled = modifyMode;
        txtComments.ReadOnly = viewMode;
        
        //User Assignment
        divUnassignedUserSearch.Visible = IsAssignmentEnabled();
        divAssignedUserSearch.Visible = IsAssignmentEnabled();
        divUnassignedActions.Visible = IsAssignmentEnabled();
        divAssignedActions.Visible = IsAssignmentEnabled();
        //Buttons
        btnAddModifyPlanSubmit.Visible = !viewMode;

        liModifySubscriptionPlan.Visible = viewMode;
    }
    private void addCheckBoxAttributes()
    {
        foreach (ListViewItem item in UnassignedUserGrid.Items)
        {
            CheckBox chBox = (CheckBox)item.FindControl("cbUnassignedUser");
            if (chBox != null)
            {
                chBox.InputAttributes.Add("class", "styled cs-select-row");
                chBox.InputAttributes.Add("data-parent", "media-link");
            }
        }
        foreach (ListViewItem item in assignedUserGrid.Items)
        {
            CheckBox chBox = (CheckBox)item.FindControl("cbAssignedUser");
            if (chBox != null)
            {
                chBox.InputAttributes.Add("class", "styled cs-select-row");
                chBox.InputAttributes.Add("data-parent", "media-link");
            }
        }
    }
    private void doInit(SubscriptionPlanDetailNavDTO navDto)
    {
        initDropdowns();
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(SubscriptionPlanDetailNavDTO navDto)
    {
        if (navDto != null)
        {
            SubscriptionPlanDetailPageDTO PageDTO = new SubscriptionPlanDetailPageDTO();
            pageModeHdn.Value = navDto.Mode.ToString();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            if (isAddMode())
            {
                PageDTO.PlanDTO = populateSubscriptionPlanDTOAdd();
                populateUIFieldsFromDTO(null);
            }
            else
            {
                PageDTO.PlanDTO = firmBO.fetchSubscriptionPlanDetails(navDto.PlanId);
                populateUIFieldsFromDTO(PageDTO.PlanDTO);
            }
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void navigateToPreviousPage()
    {
        SubscriptionPlanDetailPageDTO PageDTO = getSessionPageData();
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is SubscriptionPlanSearchNavDTO)
            {
                SubscriptionPlanSearchNavDTO navDTO = (SubscriptionPlanSearchNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.SUBSCRIPTION_PLAN_SEARCH, true);
            }
        }
        Response.Redirect(Constants.URL.SUBSCRIPTION_PLAN_SEARCH, true);
    }
    protected bool IsAssignmentEnabled()
    {
    	SubscriptionPlanDetailPageDTO PageDTO = getSessionPageData();
        return (!isViewMode() && PageDTO.PlanDTO.Status != SubscriptionPlanStatus.Consumed);
    }
    private bool isViewMode()
    {
        return PageMode.VIEW.ToString().Equals(pageModeHdn.Value);
    }
    private bool isAddMode()
    {
        return PageMode.ADD.ToString().Equals(pageModeHdn.Value);
    }
    private bool isModifyMode()
    {
        return PageMode.MODIFY.ToString().Equals(pageModeHdn.Value);
    }
    private SubscriptionPlanDetailPageDTO getSessionPageData()
    {
        return (SubscriptionPlanDetailPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    protected void addOrModifySubscriptionPlan(object sender, EventArgs e)
    {
        try
        {
            if (validateSubscriptionPlanAddOrModify())
            {
                SubscriptionPlanDetailPageDTO PageDTO = getSessionPageData();
                SubscriptionPlanDTO tmpDTO = PageDTO.PlanDTO;
                populateSubscriptionPlanDTOFromUI(tmpDTO);
                string msg = (isAddMode()) ? string.Format("Subscription Plan '{0}' is added successfully.", tmpDTO.Name)
                        : string.Format("Subscription Plan '{0}' is modified successfully.", tmpDTO.Name);
                firmBO.saveOrUpdateSubscriptionPlan(tmpDTO, (tmpDTO.Status != SubscriptionPlanStatus.Consumed));
                Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg(msg));
                navigateToPreviousPage();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addModifyStep1Error);
        }
    }
    protected void onClickModifySubscriptionPlanBtn(object sender, EventArgs e)
    {
        try
        {
            SubscriptionPlanDetailPageDTO PageDTO = getSessionPageData();
            SubscriptionPlanDTO PlanDTO = PageDTO.PlanDTO;
            SubscriptionPlanDetailNavDTO navDTO = new SubscriptionPlanDetailNavDTO();
            navDTO.Mode = PageMode.MODIFY;
            if (PlanDTO != null) navDTO.PlanId = PlanDTO.Id;
            navDTO.PrevNavDto = PageDTO.PrevNavDTO;
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.SUBSCRIPTION_PLAN_DETAILS, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelSubscriptionPlan(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    /**
     * Define all validation which will be done before add or Modify property.
     * */
    private bool validateSubscriptionPlanAddOrModify()
    {
        bool isValid = validateAllStep1Group();
        return isValid;
    }
    private bool validateAllStep1Group()
    {
        bool isValid = true;
        Page.Validate(addModifyStep1Error);
        isValid = Page.IsValid;
        if (!isValid)
        {
            (this.Master as CSAdminMaster).setPageErrorInNotyMsg(Page.Validators);
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        if (isValid) isValid = validateUnitAddOrModifyOther();
        return isValid;
    }
    private bool validateUnitAddOrModifyOther()
    {
        //TODO - Validate only one plan can be Active at a time
        SubscriptionPlanStatus Status = EnumHelper.ToEnum<SubscriptionPlanStatus>(drpPlanStatus.Text);
        DateTime StartDate = DateUtil.getCSDate(txtStartDate.Text).Value;
        DateTime EndDate = DateUtil.getCSDate(txtEndDate.Text).Value;
        if (StartDate.CompareTo(EndDate) > 0)
        {
            (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Start cannot be greater than End date."));
            return false;
        }
        if (Status == SubscriptionPlanStatus.Active)
        {
            if (StartDate.CompareTo(DateUtil.getUserLocalDateTime()) > 0 || EndDate.CompareTo(DateUtil.getUserLocalDateTime()) < 0)
            {
                (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Start and End Dates are not valid to start subscription plan."));
                return false;
            }
        }
        if (Status == SubscriptionPlanStatus.Consumed)
        {
            if (EndDate.CompareTo(DateUtil.getUserLocalDateTime()) > 0)
            {
                (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("End Date is in future. Please update End Date to mark plan as consumed."));
                return false;
            }
        }
        if (Status == SubscriptionPlanStatus.Upcoming)
        {
            if (StartDate.CompareTo(DateUtil.getUserLocalDateTime()) < 0)
            {
                (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("For upcoming plans, Start date can not be past date."));
                return false;
            }
        }
        return true;
    }
    private SubscriptionPlanDTO populateSubscriptionPlanDTOAdd()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        SubscriptionPlanDTO tmpDTO = new SubscriptionPlanDTO();
        tmpDTO.Firm = CommonUtil.getCurrentFirmDTO(userDefDto);
        tmpDTO.InsertUser = userDefDto.Username;
        return tmpDTO;
    }
    private void populateSubscriptionPlanDTOFromUI(SubscriptionPlanDTO tmpDTO)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        tmpDTO.Name = txtPlanName.Text.TrimNullable();
        tmpDTO.PurchaseDate = DateUtil.getCSDate(txtPurchaseDate.Text).Value;
        tmpDTO.StartDate = DateUtil.getCSDate(txtStartDate.Text).Value;
        tmpDTO.EndDate = DateUtil.getCSDate(txtEndDate.Text).Value;
        tmpDTO.NoOfUsers = Convert.ToInt32(txtNoOfUsers.Text);
        tmpDTO.PurchaseType = EnumHelper.ToEnum<SubPlanPurchaseType>(drpPurchaseType.Text);
        tmpDTO.Status = EnumHelper.ToEnum<SubscriptionPlanStatus>(drpPlanStatus.Text);
        tmpDTO.Comments = txtComments.Text.TrimNullable();
        tmpDTO.Version = userDefDto.Version;
        tmpDTO.UpdateUser = userDefDto.Username;
        
        tmpDTO.Users = new List<FirmMemberDTO>();
        tmpDTO.Users.AddRange(getSessionPageData().AssignedUserList);
    }
    private void populateUIFieldsFromDTO(SubscriptionPlanDTO tmpDTO)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        if (tmpDTO != null) txtPlanName.Text = tmpDTO.Name; else txtPlanName.Text = null;
        if (tmpDTO != null) txtPurchaseDate.Text = DateUtil.getCSDate(tmpDTO.PurchaseDate); else txtPurchaseDate.Text = null;
        if (tmpDTO != null) txtStartDate.Text = DateUtil.getCSDate(tmpDTO.StartDate); else txtStartDate.Text = null;
        if (tmpDTO != null) txtEndDate.Text = DateUtil.getCSDate(tmpDTO.EndDate); else txtEndDate.Text = null;
        if (tmpDTO != null) txtNoOfUsers.Text = tmpDTO.NoOfUsers + ""; else txtNoOfUsers.Text = null;
        if (tmpDTO != null) drpPurchaseType.Text = tmpDTO.PurchaseType.ToString(); else drpPurchaseType.ClearSelection();
        if (tmpDTO != null) drpPlanStatus.Text = tmpDTO.Status.ToString(); else drpPlanStatus.Text = SubscriptionPlanStatus.Upcoming.ToString();
        if (tmpDTO != null) txtComments.Text = tmpDTO.Comments; else txtComments.Text = null;
        
        fetchUsersForPlan(tmpDTO.Id);
    }
    private void fetchUsersForPlan(long planId)
    {
        SubscriptionPlanDetailPageDTO PageDTO = getSessionPageData();
        IList<FirmMemberDTO> result = firmBO.fetchUsersForSubscriptionPlan(PageDTO.PlanDTO.Id, CommonUtil.getCurrentFirmDTO(getUserDefinitionDTO()).FirmNumber);
        PageDTO.UnassignedUserList = new List<FirmMemberDTO>();
        PageDTO.AssignedUserList = new List<FirmMemberDTO>();
        PageDTO.UIUnassignedUserList = new List<FirmMemberDTO>();
        PageDTO.UIAssignedUserList = new List<FirmMemberDTO>();
        foreach (FirmMemberDTO tmpDTO in result)
        {
        	if(tmpDTO.IsSelectedForPlan) PageDTO.AssignedUserList.Add(tmpDTO);
        	else PageDTO.UnassignedUserList.Add(tmpDTO);
        }
        applySearchCriteriaOnUnassignedUsers();
        applySearchCriteriaOnAssignedUsers();
    }
    private void applySearchCriteriaOnUnassignedUsers()
    {
        SubscriptionPlanDetailPageDTO PageDTO = getSessionPageData();
        PageDTO.UIUnassignedUserList.Clear();
        string unassignedUserText = txtUnassignedUserSearch.Text.Trim();
        if (!string.IsNullOrWhiteSpace(unassignedUserText))
        {
            PageDTO.UIUnassignedUserList.AddRange(PageDTO.UnassignedUserList.FindAll(x => x.FullName.ToUpper().Contains(unassignedUserText.ToUpper())));
        }
        else
        {
            PageDTO.UIUnassignedUserList.AddRange(PageDTO.UnassignedUserList);
        }
        UnassignedUserGrid.DataSource = PageDTO.UIUnassignedUserList;
        UnassignedUserGrid.DataBind();
    }
    private void applySearchCriteriaOnAssignedUsers()
    {
        SubscriptionPlanDetailPageDTO PageDTO = getSessionPageData();
        PageDTO.UIAssignedUserList.Clear();
        string assignedUserText = txtAssignedUserSearch.Text.Trim();
        if (!string.IsNullOrWhiteSpace(assignedUserText))
        {
            PageDTO.UIAssignedUserList.AddRange(PageDTO.AssignedUserList.FindAll(x => x.FullName.ToUpper().Contains(assignedUserText.ToUpper())));
        }
        else
        {
            PageDTO.UIAssignedUserList.AddRange(PageDTO.AssignedUserList);
        }
        assignedUserGrid.DataSource = PageDTO.UIAssignedUserList;
        assignedUserGrid.DataBind();
    }
    protected void searchUserInUnassignedList(object sender, EventArgs e)
    {
        try
        {
        	applySearchCriteriaOnUnassignedUsers();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void moveAllUsersToAssignedList(object sender, EventArgs e) {
    	try
        {
    		SubscriptionPlanDetailPageDTO PageDTO = getSessionPageData();
    		SubscriptionPlanDTO tmpPlanDTO = PageDTO.PlanDTO;
    		if(tmpPlanDTO != null) {
    			if(PageDTO.UIUnassignedUserList.Count > 0) {
    				PageDTO.AssignedUserList.AddRange(PageDTO.UIUnassignedUserList);
                    PageDTO.UIUnassignedUserList.ForEach(x => PageDTO.UnassignedUserList.Remove(x));
    				applySearchCriteriaOnUnassignedUsers();
    		        applySearchCriteriaOnAssignedUsers();
        		} else {
        			(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("No user is available for assignment."));
        		}
    		}
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void moveSelectedUsersToAssignedList(object sender, EventArgs e) {
    	try
        {
    		SubscriptionPlanDetailPageDTO PageDTO = getSessionPageData();
    		SubscriptionPlanDTO tmpPlanDTO = PageDTO.PlanDTO;
    		if(tmpPlanDTO != null) {
    			List<FirmMemberDTO> selectedUsers = new List<FirmMemberDTO>();
            	foreach (ListViewItem item in UnassignedUserGrid.Items)
                {
                    CheckBox chBox = (CheckBox)item.FindControl("cbUnassignedUser");
                    if (chBox.Checked)
                    {
                    	HiddenField hdnField = (HiddenField)item.FindControl("UnassignedUserIdHdn");
                    	long selectedId = long.Parse(hdnField.Value);
                        FirmMemberDTO tmpDTO = PageDTO.UIUnassignedUserList.Find(x => x.Id == selectedId);
                        if (tmpDTO != null) selectedUsers.Add(tmpDTO);
                    }
                }
            	if(selectedUsers.Count > 0) {
            		PageDTO.AssignedUserList.AddRange(selectedUsers);
    				selectedUsers.ForEach(x => PageDTO.UnassignedUserList.Remove(x));
    				applySearchCriteriaOnUnassignedUsers();
    		        applySearchCriteriaOnAssignedUsers();
            	} else {
        			(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please select user."));
        		}
    		}
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void searchUserInAssignedList(object sender, EventArgs e)
    {
        try
        {
            SubscriptionPlanDetailPageDTO PageDTO = getSessionPageData();
            SubscriptionPlanDTO tmpPlanDTO = PageDTO.PlanDTO;
            if (tmpPlanDTO != null)
            {
            	applySearchCriteriaOnAssignedUsers();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void moveAllUsersToUnAssignedList(object sender, EventArgs e) {
    	try
        {
    		SubscriptionPlanDetailPageDTO PageDTO = getSessionPageData();
    		SubscriptionPlanDTO tmpPlanDTO = PageDTO.PlanDTO;
    		if(tmpPlanDTO != null) {
    			if(PageDTO.UIAssignedUserList.Count > 0) {
    				PageDTO.UnassignedUserList.AddRange(PageDTO.UIAssignedUserList);
                    PageDTO.UIAssignedUserList.ForEach(x => PageDTO.AssignedUserList.Remove(x));
    				applySearchCriteriaOnUnassignedUsers();
    		        applySearchCriteriaOnAssignedUsers();
        		} else {
        			(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("No user has access to virtual number."));
        		}
    		}
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void moveSelectedUsersToUnAssignedList(object sender, EventArgs e) {
    	try
        {
    		SubscriptionPlanDetailPageDTO PageDTO = getSessionPageData();
    		SubscriptionPlanDTO tmpPlanDTO = PageDTO.PlanDTO;
    		List<FirmMemberDTO> selectedUsers = new List<FirmMemberDTO>();
        	foreach (ListViewItem item in assignedUserGrid.Items)
            {
                CheckBox chBox = (CheckBox)item.FindControl("cbAssignedUser");
                if (chBox.Checked)
                {
                	HiddenField hdnField = (HiddenField)item.FindControl("AssignedUserIdHdn");
                	long selectedId = long.Parse(hdnField.Value);
                	FirmMemberDTO tmpDTO = PageDTO.UIAssignedUserList.Find(x => x.Id == selectedId);
                    if (tmpDTO != null) selectedUsers.Add(tmpDTO);
                }
            }
        	if(selectedUsers.Count > 0) {
        		PageDTO.UnassignedUserList.AddRange(selectedUsers);
                selectedUsers.ForEach(x => PageDTO.AssignedUserList.Remove(x));
				applySearchCriteriaOnUnassignedUsers();
		        applySearchCriteriaOnAssignedUsers();
        	} else {
    			(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please select user."));
    		}
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
}