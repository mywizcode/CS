﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;

public partial class SubscriptionPlanSearch : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    DropdownBO drpBO = new DropdownBO();
    FirmBO firmBO = new FirmBO();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                SubscriptionPlanSearchNavDTO navDto = ApplicationUtil.getPageNavDTO<SubscriptionPlanSearchNavDTO>(Session);
                if (!CommonUtil.IsSystemAdminRole(getUserDefinitionDTO())) (this.Master as CSAdminMaster).doLogout(Constants.URL.SYS_ADMIN_LOGIN_FAILED);
                if (CommonUtil.getCurrentFirmDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToSystemDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSAdminMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];

    }
    public void setErrorMessage(string message, string group)
    {
        string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }
    }
    private void doInit(SubscriptionPlanSearchNavDTO navDTO)
    {
        Session[Constants.Session.PAGE_DATA] = new SubscriptionPlanSearchPageDTO();
        initDropdowns();
        loadSubscriptionPlanGrid();
    }
    private void renderPageFieldsWithEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
    }
    private SubscriptionPlanSearchPageDTO getSessionPageData()
    {
        return (SubscriptionPlanSearchPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private void loadSubscriptionPlanGrid()
    {
        SubscriptionPlanSearchPageDTO PageDTO = getSessionPageData();
        IList<SubscriptionPlanDTO> result = firmBO.fetchSubscriptionPlans(CommonUtil.getCurrentFirmDTO(getUserDefinitionDTO()).FirmNumber);
        PageDTO.PlanList = (result != null) ? result.ToList<SubscriptionPlanDTO>() : new List<SubscriptionPlanDTO>();

        populateSubscriptionPlanGrid(PageDTO.PlanList);
    }
    private SubscriptionPlanDTO getSelectedSubscriptionPlan(long Id)
    {
        SubscriptionPlanSearchPageDTO PageDTO = getSessionPageData();
        return PageDTO.PlanList.Find(x => x.Id == Id);
    }
    private void populateSubscriptionPlanGrid(List<SubscriptionPlanDTO> tmpList)
    {
        SubscriptionPlanGrid.DataSource = new List<SubscriptionPlanDTO>();
        if (tmpList != null)
        {
            assignUiIndexToSubscriptionPlan(tmpList);
            SubscriptionPlanGrid.DataSource = tmpList;
        }
        SubscriptionPlanGrid.DataBind();
    }
    private void assignUiIndexToSubscriptionPlan(List<SubscriptionPlanDTO> tmpList)
    {
        if (tmpList != null && tmpList.Count > 0)
        {
            foreach (SubscriptionPlanDTO tmpDTO in tmpList)
            {

            }
        }
    }
    private void navigateToSubscriptionPlanDetail(long selectedId, PageMode mode)
    {
        SubscriptionPlanDetailNavDTO navDTO = new SubscriptionPlanDetailNavDTO();
        navDTO.Mode = mode;
        if (mode != PageMode.ADD)
        {
            navDTO.PlanId = selectedId;
        }

        navDTO.PrevNavDto = new SubscriptionPlanSearchNavDTO();
        Session[Constants.Session.NAV_DTO] = navDTO;
        Response.Redirect(Constants.URL.SUBSCRIPTION_PLAN_DETAILS, true);
    }
    protected void onClickAddSubscriptionPlanBtn(object sender, EventArgs e)
    {
        try
        {
            navigateToSubscriptionPlanDetail(0, PageMode.ADD);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifySubscriptionPlanBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            navigateToSubscriptionPlanDetail(selectedId, PageMode.VIEW);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickDeleteSubscriptionPlanBtn(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            SubscriptionPlanDTO selectedDTO = getSelectedSubscriptionPlan(selectedIndex);
            if (selectedDTO.Status == SubscriptionPlanStatus.Upcoming)
            {
                //firmBO.deleteSubscriptionPlan(selectedDTO.Id);
                (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(CommonUtil.getRecordDeleteSuccessMsg("Subscription Plan")));
                loadSubscriptionPlanGrid();
            }
            else
            {
                (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Only Upcoming subscription plan can be deleted."));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
}