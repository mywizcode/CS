﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.BO;

public partial class ReportTemplateMaster : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifyTemplateError = "addModifyTemplateError";
    string addModifyTemplateModal = "addModifyTemplateModal";
    DropdownBO drpBO = new DropdownBO();
    ReportConfigBO reportConfigBO = new ReportConfigBO();
    public enum TemplateModalAction { ADD, MODIFY }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                ReportTemplateMasterNavDTO navDto = ApplicationUtil.getPageNavDTO<ReportTemplateMasterNavDTO>(Session);
                if (!CommonUtil.IsSystemAdminRole(getUserDefinitionDTO())) (this.Master as CSAdminMaster).doLogout(Constants.URL.SYS_ADMIN_LOGIN_FAILED);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSAdminMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpEnum<ReportTemplateType>(drpTemplateType, Constants.SELECT_ITEM);
    }
    public void setErrorMessage(string message, string group)
    {
        string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }
    }
    private void doInit(ReportTemplateMasterNavDTO navDTO)
    {
        Session[Constants.Session.PAGE_DATA] = new ReportTemplateMasterPageDTO();
        initDropdowns();
        loadReportTemplateGrid();
    }
    private void renderPageFieldsWithEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
    }
    private ReportTemplateMasterPageDTO getSessionPageData()
    {
        return (ReportTemplateMasterPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private bool IsDefaultFirmTemplate() {
    	string[] fnAndPageName = ApplicationUtil.getFunctionAndPageName(HttpContext.Current.Request, 1);
        return Constants.Function.DEFAULT_FIRM.Equals(fnAndPageName[0]);
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private void loadReportTemplateGrid()
    {
        ReportTemplateMasterPageDTO PageDTO = getSessionPageData();
        IsCustomReport isCustomReport = IsDefaultFirmTemplate() ? IsCustomReport.No : IsCustomReport.Yes;
        IList<ReportTemplateMasterDTO> result = reportConfigBO.fetchReportTemplateMasters(isCustomReport);
        PageDTO.TemplateList = (result != null) ? result.ToList<ReportTemplateMasterDTO>() : new List<ReportTemplateMasterDTO>();

        populateTemplateGrid(PageDTO.TemplateList);
    }
    private void populateTemplateGrid(List<ReportTemplateMasterDTO> tmpList)
    {
        TemplateGrid.DataSource = new List<ReportTemplateMasterDTO>();
        if (tmpList != null)
        {
            assignUiIndexToTemplate(tmpList);
            TemplateGrid.DataSource = tmpList;
        }
        TemplateGrid.DataBind();
    }
    private void assignUiIndexToTemplate(List<ReportTemplateMasterDTO> tmpList)
    {
        if (tmpList != null && tmpList.Count > 0)
        {
            foreach (ReportTemplateMasterDTO tmpDTO in tmpList)
            {
                tmpDTO.RowInfo = CommonUIConverter.getGridViewRowInfo(tmpDTO);
            }
        }
    }
    protected string getTemplateDesc(string Type)
    {
        return EnumHelper.ToEnum<ReportTemplateType>(Type).GetDescription();
    }
    protected bool IsTemplateLetterType(string Type)
    {
        return CommonUIConverter.IsTemplateLetterType(EnumHelper.ToEnum<ReportTemplateType>(Type));
    }
    protected void onClickDeleteTemplateBtn(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            ReportTemplateMasterDTO selectedDTO = getSelectedTemplate(selectedIndex);
            reportConfigBO.deleteReportTemplateMaster(selectedDTO.Id);
            (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(CommonUtil.getRecordDeleteSuccessMsg(selectedDTO.TemplateType.GetDescription())));
            loadReportTemplateGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Template Modal - Start
    private bool isTemplateAddMode()
    {
        return (TemplateModalAction.ADD.ToString().Equals(TemplateModalActionHdnBtn.Value));
    }
    private void initTemplateModalFields()
    {
        lbTemplateModalTitle.Text = (TemplateModalAction.ADD.ToString().Equals(TemplateModalActionHdnBtn.Value))
            ? Constants.ICON.ADD + "Add Template" : Constants.ICON.MODIFY + "Modify Template";
        drpTemplateType.Enabled = isTemplateAddMode();
    }
    private void initTemplateSectionFields(ReportTemplateMasterDTO tmpDTO)
    {
        if (tmpDTO != null) drpTemplateType.Text = tmpDTO.TemplateType.ToString(); else drpTemplateType.ClearSelection();
        if (tmpDTO != null) txtTemplateName.Text = tmpDTO.Name; else txtTemplateName.Text = null;
        if (tmpDTO != null) txtTemplatePath.Text = tmpDTO.Path; else txtTemplatePath.Text = null;
        if (tmpDTO != null) txtTemplateDescription.Text = tmpDTO.Decription; else txtTemplateDescription.Text = null;
    }
    private void populateTemplateFromUI(ReportTemplateMasterDTO tmpDTO)
    {
        if (isTemplateAddMode()) tmpDTO.TemplateType = EnumHelper.ToEnum<ReportTemplateType>(drpTemplateType.Text);
        tmpDTO.Name = txtTemplateName.Text.TrimNullable();
        tmpDTO.Path = txtTemplatePath.Text.TrimNullable();
        tmpDTO.Decription = txtTemplateDescription.Text.TrimNullable();
        tmpDTO.UpdateUser = getUserDefinitionDTO().Username;
    }
    private ReportTemplateMasterDTO populateTemplateAdd()
    {
        ReportTemplateMasterDTO tmpDTO = new ReportTemplateMasterDTO();
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        if (IsDefaultFirmTemplate())
        {
            tmpDTO.FirmNumber = Constants.SYSDEFAULT.DEFAULT_FIRM;
            tmpDTO.IsCustomReport = IsCustomReport.No;
        }
        else
        {
            tmpDTO.FirmNumber = CommonUtil.getCurrentFirmDTO(userDef).FirmNumber;
            tmpDTO.IsCustomReport = IsCustomReport.Yes;
        }
        tmpDTO.InsertUser = userDef.Username;
        return tmpDTO;
    }
    private void setSelectedTemplate(long Id)
    {
        List<ReportTemplateMasterDTO> tmpList = getSessionPageData().TemplateList;
        tmpList.ForEach(c => c.isUISelected = false);
        if (Id > 0) tmpList.Find(c => c.Id == Id).isUISelected = true;
    }
    private ReportTemplateMasterDTO getSelectedTemplate(long Id)
    {
        List<ReportTemplateMasterDTO> tmpList = getSessionPageData().TemplateList;
        return (Id > 0) ? tmpList.Find(c => c.Id == Id) : tmpList.Find(c => c.isUISelected);
    }
    protected void onClickAddTemplateBtn(object sender, EventArgs e)
    {
        try
        {
            TemplateModalActionHdnBtn.Value = TemplateModalAction.ADD.ToString();
            initTemplateModalFields();
            setSelectedTemplate(-1);
            initTemplateSectionFields(null);
            activeModalHdn.Value = addModifyTemplateModal;
            SetFocus(drpTemplateType);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyTemplateBtn(object sender, EventArgs e)
    {
        try
        {
            TemplateModalActionHdnBtn.Value = TemplateModalAction.MODIFY.ToString();
            initTemplateModalFields();
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedTemplate(selectedIndex);
            initTemplateSectionFields(getSelectedTemplate(0));
            activeModalHdn.Value = addModifyTemplateModal;
            SetFocus(drpTemplateType);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void saveTemplate(object sender, EventArgs e)
    {
        try
        {
            if (validateTemplateAddModify())
            {
                ReportTemplateMasterDTO tmpDTO = null;
                string msg = "";
                if (isTemplateAddMode())
                {
                    tmpDTO = populateTemplateAdd();
                    msg = CommonUtil.getNotySuccessMsg(CommonUtil.getRecordAddSuccessMsg(tmpDTO.TemplateType.GetDescription()));
                }
                else
                {
                    tmpDTO = getSelectedTemplate(0);
                    msg = CommonUtil.getNotySuccessMsg(CommonUtil.getRecordModifySuccessMsg(tmpDTO.TemplateType.GetDescription()));
                }
                populateTemplateFromUI(tmpDTO);
                reportConfigBO.saveOrUpdateReportTemplateMaster(tmpDTO);
                (this.Master as CSAdminMaster).setNotyMsg(msg);
                loadReportTemplateGrid();
            }
            else
            {
                activeModalHdn.Value = addModifyTemplateModal;
                SetFocus(txtTemplateName);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelTemplateModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateTemplateAddModify()
    {
        Page.Validate(addModifyTemplateError);
        bool IsValid = Page.IsValid;
        if (IsValid)
        {
            if (isTemplateAddMode())
            {
                ReportTemplateMasterPageDTO PageDTO = getSessionPageData();
                ReportTemplateType TemplateType = EnumHelper.ToEnum<ReportTemplateType>(drpTemplateType.Text);
                if (PageDTO.TemplateList.Any(x => x.Name.Equals(txtTemplateName.Text.TrimNullable())))
                {
                    setErrorMessage("Template with same name already exist.", addModifyTemplateError);
                    IsValid = false;
                }
                else if (IsDefaultFirmTemplate() && PageDTO.TemplateList.Any(x => x.TemplateType == TemplateType && x.IsCustomReport == IsCustomReport.No))
                {
                    setErrorMessage(string.Format("{0} template is already exist.", TemplateType.GetDescription()), addModifyTemplateError);
                    IsValid = false;
                }
            }
        }
        return IsValid;
    }
    //Template Modal - End
}