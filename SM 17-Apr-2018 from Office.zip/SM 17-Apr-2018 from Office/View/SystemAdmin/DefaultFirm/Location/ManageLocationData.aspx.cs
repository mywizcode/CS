﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using Vladsm.Web.UI.WebControls;

public partial class ManageLocationData : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifyLocationModal = "addModifyLocationModal";
    string addModifyLocationModalError = "addModifyLocationModalError";
    DropdownBO drpBO = new DropdownBO();
    SystemAdminstrationBO sysAdminBO = new SystemAdminstrationBO();
    public enum LocationModalAction { ADD, MODIFY }
    public enum LocationModalType { COUNTRY, STATE, CITY }
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Form.Attributes.Add("enctype", "multipart/form-data");
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                ManageLocationDataNavDTO navDto = ApplicationUtil.getPageNavDTO<ManageLocationDataNavDTO>(Session);
                if (!CommonUtil.IsSystemAdminRole(getUserDefinitionDTO())) (this.Master as CSAdminMaster).doLogout(Constants.URL.SYS_ADMIN_LOGIN_FAILED);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSAdminMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    public void setErrorMessage(string message, string group)
    {
        string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else CommonUtil.getCustomValidator(Page, message, group);
    }
    private void doInit(ManageLocationDataNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new ManageLocationDataPageDTO();
        initDropdowns();
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(ManageLocationDataNavDTO navDto)
    {
        try
        {
            loadAllCountries(0, 0, 0, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageFieldsWithEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();

    }
    private ManageLocationDataPageDTO getSessionPageData()
    {
        return (ManageLocationDataPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private void loadAllCountries(long countryId, long stateId, long cityId, bool setDefault)
    {
        ManageLocationDataPageDTO PageDTO = getSessionPageData();
        IList<CountryDTO> results = sysAdminBO.fetchAllCountries();
        PageDTO.CountryList = (results != null) ? results.ToList<CountryDTO>() : new List<CountryDTO>();
        setSelectedCountry(countryId, setDefault);
        CountryGrid.DataSource = PageDTO.CountryList;
        CountryGrid.DataBind();

        loadAllStates(stateId, cityId, setDefault);
    }
    private void loadAllStates(long stateId, long cityId, bool setDefault)
    {
        ManageLocationDataPageDTO PageDTO = getSessionPageData();
        PageDTO.StateList = new List<StateDTO>();
        CountryDTO tmpCountryDTO = getSelectedCountry(0);
        if (tmpCountryDTO != null)
        {
            IList<StateDTO> results = sysAdminBO.fetchAllStates(tmpCountryDTO.Id);
            if (results != null) PageDTO.StateList.AddRange(results);
            setSelectedState(stateId, setDefault);
        }
        StateGrid.DataSource = PageDTO.StateList;
        StateGrid.DataBind();
        loadAllCities(cityId, setDefault);
    }
    private void loadAllCities(long cityId, bool setDefault)
    {
        ManageLocationDataPageDTO PageDTO = getSessionPageData();
        PageDTO.CityList = new List<CityDTO>();
        StateDTO tmpStateDTO = getSelectedState(0);
        if (tmpStateDTO != null)
        {
            IList<CityDTO> results = sysAdminBO.fetchAllCities(tmpStateDTO.Id);
            if (results != null) PageDTO.CityList.AddRange(results);
            setSelectedCity(cityId, setDefault);
        }
        CityGrid.DataSource = PageDTO.CityList;
        CityGrid.DataBind();
    }
    private void setSelectedCountry(long countryId, bool setDefault) {
    	ManageLocationDataPageDTO PageDTO = getSessionPageData();
    	PageDTO.CountryList.ForEach(x => x.isUISelected = false);
    	if(PageDTO.CountryList.Count > 0) {
    		CountryDTO tmpDTO = PageDTO.CountryList.Find(x => x.Id == countryId);
    		if(tmpDTO != null) tmpDTO.isUISelected = true;
    		else if(setDefault) PageDTO.CountryList[0].isUISelected = true;
    	}
    	CountryDTO tmpDTO1 = getSelectedCountry(0);
    	lbSelectedCountry.Text = (tmpDTO1 != null) ? tmpDTO1.Name : "";
    }
    private CountryDTO getSelectedCountry(long Id)
    {
        List<CountryDTO> tmpList = getSessionPageData().CountryList;
        return (Id > 0) ? tmpList.Find(c => c.Id == Id) : tmpList.Find(c => c.isUISelected);
    }
    private void setSelectedState(long stateId, bool setDefault) {
    	ManageLocationDataPageDTO PageDTO = getSessionPageData();
    	PageDTO.StateList.ForEach(x => x.isUISelected = false);
    	if(PageDTO.StateList.Count > 0) {
    		StateDTO tmpDTO = PageDTO.StateList.Find(x => x.Id == stateId);
    		if(tmpDTO != null) tmpDTO.isUISelected = true;
    		else if(setDefault) PageDTO.StateList[0].isUISelected = true;
    	}
    	StateDTO tmpDTO1 = getSelectedState(0);
    	lbSelectedState.Text = (tmpDTO1 != null) ? tmpDTO1.Name : "";
    }
    private StateDTO getSelectedState(long Id)
    {
        List<StateDTO> tmpList = getSessionPageData().StateList;
        return (Id > 0) ? tmpList.Find(c => c.Id == Id) : tmpList.Find(c => c.isUISelected);
    }
    private void setSelectedCity(long cityId, bool setDefault) {
    	ManageLocationDataPageDTO PageDTO = getSessionPageData();
    	PageDTO.CityList.ForEach(x => x.isUISelected = false);
    	if(PageDTO.CityList.Count > 0) {
    		CityDTO tmpDTO = PageDTO.CityList.Find(x => x.Id == cityId);
    		if(tmpDTO != null) tmpDTO.isUISelected = true;
    		else if(setDefault) PageDTO.CityList[0].isUISelected = true;
    	}
    	CityDTO tmpDTO1 = getSelectedCity(0);
    	lbSelectedCity.Text = (tmpDTO1 != null) ? tmpDTO1.Name : "";
    }
    private CityDTO getSelectedCity(long Id)
    {
        List<CityDTO> tmpList = getSessionPageData().CityList;
        return (Id > 0) ? tmpList.Find(c => c.Id == Id) : tmpList.Find(c => c.isUISelected);
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    protected void onSelectCountry(object sender, EventArgs e)
    {
        try
        {
        	 GroupRadioButton rd = (GroupRadioButton)sender;
             if (rd.Checked)
             {
                 Button tmpBtn = (Button)(((ListViewDataItem)rd.NamingContainer).FindControl("btnCountryRowIdentifier"));
                 long Id = long.Parse(tmpBtn.Attributes["row-identifier"]);
                 setSelectedCountry(Id, false);
                 loadAllStates(0, 0, false);
             }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onSelectState(object sender, EventArgs e)
    {
        try
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            if (rd.Checked)
            {
                Button tmpBtn = (Button)(((ListViewDataItem)rd.NamingContainer).FindControl("btnStateRowIdentifier"));
                long Id = long.Parse(tmpBtn.Attributes["row-identifier"]);
                setSelectedState(Id, false);
                loadAllCities(0, false);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onSelectCity(object sender, EventArgs e)
    {
        try
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            if (rd.Checked)
            {
                Button tmpBtn = (Button)(((ListViewDataItem)rd.NamingContainer).FindControl("btnCityRowIdentifier"));
                long Id = long.Parse(tmpBtn.Attributes["row-identifier"]);
                setSelectedCity(Id, false);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickDeleteCountryBtn(object sender, EventArgs e)
    {
        try
        {
        	if(IsCountrySelected()) {
            	CountryDTO tmpDTO = getSelectedCountry(0);
            	sysAdminBO.deleteCountry(tmpDTO.Id);
            	(this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(CommonUtil.getRecordDeleteSuccessMsg("Country")));
            	loadAllCountries(0, 0, 0, false);
        	}
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickDeleteStateBtn(object sender, EventArgs e)
    {
        try
        {
        	if(IsStateSelected()) {
        		StateDTO tmpDTO = getSelectedState(0);
            	sysAdminBO.deleteState(tmpDTO.Id);
            	(this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(CommonUtil.getRecordDeleteSuccessMsg("State")));
            	loadAllStates(0, 0, false);
        	}
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickDeleteCityBtn(object sender, EventArgs e)
    {
    	try
    	{
    		if(IsCitySelected()) {
    			CityDTO tmpDTO = getSelectedCity(0);
    			sysAdminBO.deleteCity(tmpDTO.Id);
    			(this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(CommonUtil.getRecordDeleteSuccessMsg("City")));
    			loadAllCities(0, false);
    		}
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    //Location Modal  - Start
    private bool IsAddLocationModal() {
    	return LocationModalAction.ADD.ToString().Equals(LocationModalActionHdnBtn.Value);
    }
    private bool IsModifyLocationModal() {
    	return LocationModalAction.MODIFY.ToString().Equals(LocationModalActionHdnBtn.Value);
    }
    private bool IsCountryModal() {
    	return LocationModalType.COUNTRY.ToString().Equals(LocationModalTypeHdnBtn.Value);
    }
    private bool IsStateModal() {
    	return LocationModalType.STATE.ToString().Equals(LocationModalTypeHdnBtn.Value);
    }
    private bool IsCityModal() {
    	return LocationModalType.CITY.ToString().Equals(LocationModalTypeHdnBtn.Value);
    }
    private void initLocationModalFields()
    {
        string title = "City";
        string icon = IsAddLocationModal() ? Constants.ICON.ADD + "Add " : Constants.ICON.MODIFY + "Modify ";
        if (IsCountryModal()) title = "Country";
        else if (IsStateModal()) title = "State";
        lbLocationModalTitle.Text = icon + title;
    }
    private void initLocationSectionFields(string Name, string Abbr)
    {
        txtLocationName.Text = Name;
        txtLocationAbbr.Text = Abbr;
    }
    private CountryDTO populateCountryAdd()
    {
        CountryDTO tmpDTO = new CountryDTO();
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        tmpDTO.FirmNumber = Constants.SYSDEFAULT.DEFAULT_FIRM;
        tmpDTO.InsertUser = userDef.Username;
        return tmpDTO;
    }
    private StateDTO populateStateAdd()
    {
        StateDTO tmpDTO = new StateDTO();
        tmpDTO.Country = getSelectedCountry(0);
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        tmpDTO.FirmNumber = Constants.SYSDEFAULT.DEFAULT_FIRM;
        tmpDTO.InsertUser = userDef.Username;
        return tmpDTO;
    }
    private CityDTO populateCityAdd()
    {
        CityDTO tmpDTO = new CityDTO();
        tmpDTO.State = getSelectedState(0);
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        tmpDTO.FirmNumber = Constants.SYSDEFAULT.DEFAULT_FIRM;
        tmpDTO.InsertUser = userDef.Username;
        return tmpDTO;
    }
    protected void onClickAddCountryBtn(object sender, EventArgs e)
    {
        try
        {
            initForAddLocation(LocationModalType.COUNTRY, LocationModalAction.ADD);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickAddStateBtn(object sender, EventArgs e)
    {
        try
        {
            if (IsCountrySelected()) initForAddLocation(LocationModalType.STATE, LocationModalAction.ADD);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickAddCityBtn(object sender, EventArgs e)
    {
        try
        {
            if (IsStateSelected()) initForAddLocation(LocationModalType.CITY, LocationModalAction.ADD);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool IsCountrySelected()
    {
        CountryDTO tmpDTO = getSelectedCountry(0);
        if (tmpDTO == null)
        {
            (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please select Country."));
            return false;
        }
        return true;
    }
    private bool IsStateSelected()
    {
        StateDTO tmpDTO = getSelectedState(0);
        if (tmpDTO == null)
        {
            (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please select State."));
            return false;
        }
        return true;
    }
    private bool IsCitySelected()
    {
        CityDTO tmpDTO = getSelectedCity(0);
        if (tmpDTO == null)
        {
            (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please select City."));
            return false;
        }
        return true;
    }
    private void initForAddLocation(LocationModalType Type, LocationModalAction Action)
    {
        LocationModalActionHdnBtn.Value = Action.ToString();
        LocationModalTypeHdnBtn.Value = Type.ToString();
        initLocationModalFields();
        initLocationSectionFields("", "");
        activeModalHdn.Value = addModifyLocationModal;
        SetFocus(txtLocationName);
    }
    private void initForModifyLocation(LocationModalType Type, LocationModalAction Action, string Name, string Abbreviation)
    {
        LocationModalActionHdnBtn.Value = Action.ToString();
        LocationModalTypeHdnBtn.Value = Type.ToString();
        initLocationModalFields();
        initLocationSectionFields(Name, Abbreviation);
        activeModalHdn.Value = addModifyLocationModal;
        SetFocus(txtLocationName);
    }
    protected void onClickModifyCountryBtn(object sender, EventArgs e)
    {
        try
        {
            if (IsCountrySelected())
            {
                CountryDTO tmpDTO = getSelectedCountry(0);
                initForModifyLocation(LocationModalType.COUNTRY, LocationModalAction.MODIFY, tmpDTO.Name, tmpDTO.Abbreviation);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyStateBtn(object sender, EventArgs e)
    {
        try
        {
            if (IsStateSelected())
            {
                StateDTO tmpDTO = getSelectedState(0);
                initForModifyLocation(LocationModalType.STATE, LocationModalAction.MODIFY, tmpDTO.Name, tmpDTO.Abbreviation);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyCityBtn(object sender, EventArgs e)
    {
        try
        {
            if (IsCitySelected())
            {
                CityDTO tmpDTO = getSelectedCity(0);
                initForModifyLocation(LocationModalType.CITY, LocationModalAction.MODIFY, tmpDTO.Name, tmpDTO.Abbreviation);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void saveLocation(object sender, EventArgs e)
    {
        try
        {
            if (validateLocationAddModify())
            {
                if (IsCountryModal())
                {
                    CountryDTO tmpDTO = null;
                    string msg = CommonUtil.getNotySuccessMsg(CommonUtil.getRecordAddSuccessMsg("Country"));
                    if (IsAddLocationModal()) tmpDTO = populateCountryAdd();
                    else
                    {
                        tmpDTO = getSelectedCountry(0);
                        msg = CommonUtil.getNotySuccessMsg(CommonUtil.getRecordModifySuccessMsg("Country"));
                    }
                    tmpDTO.Name = txtLocationName.Text.TrimNullable();
                    tmpDTO.Abbreviation = txtLocationAbbr.Text.TrimNullable();
                    tmpDTO.UpdateUser = getUserDefinitionDTO().Username;
                    sysAdminBO.saveOrUpdateCountry(tmpDTO);
                    loadAllCountries(tmpDTO.Id, 0, 0, false);
                    (this.Master as CSAdminMaster).setNotyMsg(msg);
                }
                else if (IsStateModal())
                {
                    StateDTO tmpDTO = null;
                    string msg = CommonUtil.getNotySuccessMsg(CommonUtil.getRecordAddSuccessMsg("State"));
                    if (IsAddLocationModal()) tmpDTO = populateStateAdd();
                    else
                    {
                        tmpDTO = getSelectedState(0);
                        msg = CommonUtil.getNotySuccessMsg(CommonUtil.getRecordModifySuccessMsg("State"));
                    }
                    tmpDTO.Name = txtLocationName.Text.TrimNullable();
                    tmpDTO.Abbreviation = txtLocationAbbr.Text.TrimNullable();
                    tmpDTO.UpdateUser = getUserDefinitionDTO().Username;
                    sysAdminBO.saveOrUpdateState(tmpDTO);
                    loadAllStates(tmpDTO.Id, 0, false);
                    (this.Master as CSAdminMaster).setNotyMsg(msg);
                }
                else
                {
                    CityDTO tmpDTO = null;
                    string msg = CommonUtil.getNotySuccessMsg(CommonUtil.getRecordAddSuccessMsg("City"));
                    if (IsAddLocationModal()) tmpDTO = populateCityAdd();
                    else
                    {
                        tmpDTO = getSelectedCity(0);
                        msg = CommonUtil.getNotySuccessMsg(CommonUtil.getRecordModifySuccessMsg("City"));
                    }
                    tmpDTO.Name = txtLocationName.Text.TrimNullable();
                    tmpDTO.Abbreviation = txtLocationAbbr.Text.TrimNullable();
                    tmpDTO.UpdateUser = getUserDefinitionDTO().Username;
                    sysAdminBO.saveOrUpdateCity(tmpDTO);
                    loadAllCities(tmpDTO.Id, false);
                    (this.Master as CSAdminMaster).setNotyMsg(msg);
                }
            }
            else
            {
                activeModalHdn.Value = addModifyLocationModal;
                SetFocus(txtLocationName);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelLocationModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateLocationAddModify()
    {
        Page.Validate(addModifyLocationModalError);
        bool IsValid = Page.IsValid;
        if (IsValid)
        {
            string Name = txtLocationName.Text.TrimNullable();
            string Abbreviation = txtLocationAbbr.Text.TrimNullable();
            if (IsCountryModal())
            {
                if (IsAddLocationModal())
                {
                    if (getSessionPageData().CountryList.Any(x => x.Name.Equals(Name)))
                    {
                        setErrorMessage("Country already exist with same Name.", addModifyLocationModalError);
                        IsValid = false;
                    }
                }
                else
                {
                    CountryDTO tmpDTO = getSelectedCountry(0);
                    if (getSessionPageData().CountryList.Any(x => x.Abbreviation.Equals(Abbreviation)))
                    {
                        setErrorMessage("Country already exist with same Abbreviation.", addModifyLocationModalError);
                        IsValid = false;
                    }
                }
            }
            else if (IsStateModal())
            {
                if (IsAddLocationModal())
                {
                    if (getSessionPageData().StateList.Any(x => x.Name.Equals(Name)))
                    {
                        setErrorMessage("State already exist with same Name.", addModifyLocationModalError);
                        IsValid = false;
                    }
                }
                else
                {
                    StateDTO tmpDTO = getSelectedState(0);
                    if (getSessionPageData().StateList.Any(x => x.Abbreviation.Equals(Abbreviation)))
                    {
                        setErrorMessage("State already exist with same Abbreviation.", addModifyLocationModalError);
                        IsValid = false;
                    }
                }
            }
            else if (IsCityModal())
            {
                if (IsAddLocationModal())
                {
                    if (getSessionPageData().CityList.Any(x => x.Name.Equals(Name)))
                    {
                        setErrorMessage("City already exist with same Name.", addModifyLocationModalError);
                        IsValid = false;
                    }
                }
                else
                {
                    CityDTO tmpDTO = getSelectedCity(0);
                    if (getSessionPageData().CityList.Any(x => x.Abbreviation.Equals(Abbreviation)))
                    {
                        setErrorMessage("City already exist with same Abbreviation.", addModifyLocationModalError);
                        IsValid = false;
                    }
                }
            }
        }
        return IsValid;
    }
    //Location Modal  - End
}