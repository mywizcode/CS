﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using ConstroSoft;

public partial class ManageEntitlements : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifyEntitlementError = "addModifyEntitlementError";
    string addModifyEntitlementModal = "addModifyEntitlementModal";
    DropdownBO drpBO = new DropdownBO();
    FirmBO firmBO = new FirmBO();
    public enum EntitlementModalAction { ADD, MODIFY }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                UserEntitlementNavDTO navDto = ApplicationUtil.getPageNavDTO<UserEntitlementNavDTO>(Session);
                if (!CommonUtil.IsSystemAdminRole(getUserDefinitionDTO())) (this.Master as CSAdminMaster).doLogout(Constants.URL.SYS_ADMIN_LOGIN_FAILED);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSAdminMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
        setPageTitle();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];

    }
    public void setErrorMessage(string message, string group)
    {
        string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }
    }
    private void doInit(UserEntitlementNavDTO navDTO)
    {
        pageModeHdn.Value = PageMode.VIEW.ToString();
        Session[Constants.Session.PAGE_DATA] = new UserEntitlementPageDTO();
        initDropdowns();
        loadEntitlementGrid();
    }
    private void setPageTitle()
    {
        if (isModifyMode()) lbPageTitle.Text = Constants.ICON.MODIFY + "Modify Entitlements";
        else if (isViewMode()) lbPageTitle.Text = Constants.ICON.VIEW_DTL + "Entitlements";
    }
    private void renderPageFieldsWithEntitlement()
    {
        bool modifyMode = isModifyMode();
        bool viewMode = isViewMode();

        //Fields

        lnkModifyEntitlementPage.Visible = viewMode;
        fabMenuRight.Visible = modifyMode;
    }
    private bool isModifyMode()
    {
        return PageMode.MODIFY.ToString().Equals(pageModeHdn.Value);
    }
    private bool isViewMode()
    {
        return PageMode.VIEW.ToString().Equals(pageModeHdn.Value);
    }
    private UserEntitlementPageDTO getSessionPageData()
    {
        return (UserEntitlementPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private void loadEntitlementGrid()
    {
    	selectedEntitlementHdn.Value = "";
        UserEntitlementPageDTO PageDTO = getSessionPageData();
        List<UserEntitlementDTO> finalList = new List<UserEntitlementDTO>();
        IList<UserEntitlementDTO> result = firmBO.fetchEntitlements();
        if(result != null) {
            List<UserEntitlementDTO> RootNodes = CommonUtil.BuildTree(result.ToList<UserEntitlementDTO>());
            RootNodes.ForEach(x => finalList.AddRange(CommonUtil.DepthFirstTraversal(x)));
        }
        PageDTO.EntitlementList = finalList;
        populateEntitlementGrid(PageDTO.EntitlementList);
    }
    private void populateEntitlementGrid(List<UserEntitlementDTO> tmpList)
    {
        EntitlementGrid.DataSource = new List<UserEntitlementDTO>();
        if (tmpList != null)
        {
            assignUiIndexToEntitlement(tmpList);
            EntitlementGrid.DataSource = tmpList;
        }
        EntitlementGrid.DataBind();
    }
    private void assignUiIndexToEntitlement(List<UserEntitlementDTO> tmpList)
    {
        if (tmpList != null && tmpList.Count > 0)
        {
            foreach (UserEntitlementDTO tmpDTO in tmpList)
            {
                tmpDTO.NodeClass = "level" + tmpDTO.Level;
                if (tmpDTO.isUISelected) tmpDTO.NodeClass += " selected"; 
            }
        }
    }
    private long getUISelectedId()
    {
        long selectedId = 0;
        if (!string.IsNullOrWhiteSpace(selectedEntitlementHdn.Value))
        {
            selectedId = getSessionPageData().EntitlementList.Find(x => x.Name.Equals(selectedEntitlementHdn.Value)).Id;
        }
        return selectedId;
    }
    protected void onClickModifyEntitlementPageBtn(object sender, EventArgs e)
    {
        try
        {
            pageModeHdn.Value = PageMode.MODIFY.ToString();
            loadEntitlementGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickSelectEntitlementBtn(object sender, EventArgs e)
    {
        try
        {
            setSelectedEntitlement(getUISelectedId());
            populateEntitlementGrid(getSessionPageData().EntitlementList);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickClearSelectionBtn(object sender, EventArgs e)
    {
        try
        {
            selectedEntitlementHdn.Value = "";
            setSelectedEntitlement(getUISelectedId());
            populateEntitlementGrid(getSessionPageData().EntitlementList);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickDeleteEntitlementBtn(object sender, EventArgs e)
    {
        try
        {
            UserEntitlementDTO selectedDTO = getSelectedEntitlement(0);
            if (selectedDTO != null)
            {
                List<UserEntitlementDTO> tmpList = new List<UserEntitlementDTO>();
                FinalAllChildEntitlement(selectedDTO, tmpList);
                firmBO.deleteUserEntitlements(tmpList);
                (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(CommonUtil.getRecordDeleteSuccessMsg("Entitlement")));
                loadEntitlementGrid();
            }
            else
            {
                (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please select Entitlement."));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void FinalAllChildEntitlement(UserEntitlementDTO tmpDTO, List<UserEntitlementDTO> tmpList)
    {
        if (tmpDTO.Children != null && tmpDTO.Children.Count > 0)
        {
            foreach (UserEntitlementDTO child in tmpDTO.Children)
            {
                FinalAllChildEntitlement(child, tmpList);
            }
        }
        tmpList.Add(tmpDTO);
    }
    //Entitlement Modal - Start
    private bool isEntitlementAddMode()
    {
        return (EntitlementModalAction.ADD.ToString().Equals(EntitlementModalActionHdnBtn.Value));
    }
    private void initEntitlementModalFields()
    {
        lbEntitlementModalTitle.Text = (EntitlementModalAction.ADD.ToString().Equals(EntitlementModalActionHdnBtn.Value))
            ? Constants.ICON.ADD + "Add Entitlement" : Constants.ICON.MODIFY + "Modify Entitlement";
    }
    private void initEntitlementSectionFields(UserEntitlementDTO tmpDTO)
    {
        UserEntitlementDTO selectedDTO = getSelectedEntitlement(0);
        txtParentEntitlementName.Text = "";
        divParentEntitlement.Visible = false;
        if(isEntitlementAddMode() && selectedDTO != null) {
            txtParentEntitlementName.Text = selectedDTO.Name;
            divParentEntitlement.Visible = true;
        }
        if (tmpDTO != null) txtEntitlementName.Text = tmpDTO.Name; else txtEntitlementName.Text = null;
        if (tmpDTO != null) txtEntitlementDescription.Text = tmpDTO.Description; else txtEntitlementDescription.Text = null;
    }
    private void populateEntitlementFromUI(UserEntitlementDTO tmpDTO)
    {
        tmpDTO.Name = txtEntitlementName.Text.TrimNullable();
        tmpDTO.Description = txtEntitlementDescription.Text.TrimNullable();
        tmpDTO.UpdateUser = getUserDefinitionDTO().Username;
    }
    private UserEntitlementDTO populateEntitlementAdd()
    {
        UserEntitlementDTO selectedDTO = getSelectedEntitlement(0);
        UserEntitlementDTO tmpDTO = new UserEntitlementDTO();
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        tmpDTO.Level = 0;
        if (selectedDTO != null)
        {
            tmpDTO.Parent = new UserEntitlementDTO();
            tmpDTO.Parent.Id = selectedDTO.Id;
            tmpDTO.Level = selectedDTO.Level + 1;
        }
        tmpDTO.FirmNumber = Constants.SYSDEFAULT.DEFAULT_FIRM;
        tmpDTO.InsertUser = userDef.Username;
        return tmpDTO;
    }
    private void setSelectedEntitlement(long Id)
    {
        List<UserEntitlementDTO> tmpList = getSessionPageData().EntitlementList;
        tmpList.ForEach(c => c.isUISelected = false);
        if (Id > 0) tmpList.Find(c => c.Id == Id).isUISelected = true;
    }
    private UserEntitlementDTO getSelectedEntitlement(long Id)
    {
        List<UserEntitlementDTO> tmpList = getSessionPageData().EntitlementList;
        return (Id > 0) ? tmpList.Find(c => c.Id == Id) : tmpList.Find(c => c.isUISelected);
    }
    protected void onClickAddEntitlementBtn(object sender, EventArgs e)
    {
        try
        {
            EntitlementModalActionHdnBtn.Value = EntitlementModalAction.ADD.ToString();
            initEntitlementModalFields();
            initEntitlementSectionFields(null);
            activeModalHdn.Value = addModifyEntitlementModal;
            SetFocus(txtEntitlementName);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyEntitlementBtn(object sender, EventArgs e)
    {
        try
        {
            UserEntitlementDTO selectedDTO = getSelectedEntitlement(0);
            if (selectedDTO != null)
            {
                EntitlementModalActionHdnBtn.Value = EntitlementModalAction.MODIFY.ToString();
                initEntitlementModalFields();
                initEntitlementSectionFields(selectedDTO);
                activeModalHdn.Value = addModifyEntitlementModal;
                SetFocus(txtEntitlementName);
            }
            else
            {
                (this.Master as CSAdminMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please select Entitlement."));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void saveEntitlement(object sender, EventArgs e)
    {
        try
        {
            if (validateEntitlementAddModify())
            {
                UserEntitlementDTO tmpDTO = null;
                string msg = "";
                if (isEntitlementAddMode())
                {
                    tmpDTO = populateEntitlementAdd();
                    msg = CommonUtil.getNotySuccessMsg(CommonUtil.getRecordAddSuccessMsg("Entitlement"));
                }
                else
                {
                    tmpDTO = getSelectedEntitlement(0);
                    msg = CommonUtil.getNotySuccessMsg(CommonUtil.getRecordModifySuccessMsg("Entitlement"));
                }
                populateEntitlementFromUI(tmpDTO);
                firmBO.saveOrUpdateUserEntitlement(tmpDTO);
                (this.Master as CSAdminMaster).setNotyMsg(msg);
                loadEntitlementGrid();
            }
            else
            {
                activeModalHdn.Value = addModifyEntitlementModal;
                SetFocus(txtEntitlementName);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelEntitlementModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateEntitlementAddModify()
    {
        Page.Validate(addModifyEntitlementError);
        bool IsValid = Page.IsValid;
        if (IsValid)
        {
            if (isEntitlementAddMode())
            {
                if (getSessionPageData().EntitlementList.Any(x => x.Name.Equals(txtEntitlementName.Text.TrimNullable())))
                {
                    setErrorMessage("Entitlement with same name already exist.", addModifyEntitlementError);
                    IsValid = false;
                }
            }
        }
        return IsValid;
    }
    //Entitlement Modal - End
}