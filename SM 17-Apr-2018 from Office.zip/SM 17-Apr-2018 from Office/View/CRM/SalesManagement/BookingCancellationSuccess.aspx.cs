﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.BO;

public partial class BookingCancellationSuccess : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";

    SoldPropertyUnitBO soldUnitBO = new SoldPropertyUnitBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                BookingCancelSuccessNavDTO navDto = ApplicationUtil.getPageNavDTO<BookingCancelSuccessNavDTO>(Session);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {

    }
    public void initBootstrapComponantsFromServer()
    {
    	 ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {

    }
    public void setErrorMessage(string message, string group)
    {
    	string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        } else CommonUtil.getCustomValidator(Page, message, group);
    }
    private void doInit(BookingCancelSuccessNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new BookingCancelSuccessPageDTO();
        if (navDto != null)
        {
            initPageAfterRedirect(navDto);
        }
        else
        {
            Response.Redirect(Constants.URL.AVAILABLE_UNIT_SEARCH, true);
        }
    }
    private void initPageAfterRedirect(BookingCancelSuccessNavDTO navDto)
    {
        try
        {
            PrUnitSaleDetailDTO saleDetailDTO = soldUnitBO.fetchBookingSuccessDetails(navDto.PrUnitSaleDetailId);
            PropertyUnitDTO unitDto = saleDetailDTO.PropertyUnit;
            getSessionPageData().UnitSaleDetailDTO = saleDetailDTO;
            lbBookingRefNo.Text = saleDetailDTO.BookingRefNo;

            lbCustomer.Text = CommonUIConverter.getCustomerFullName(saleDetailDTO.Customer.Salutation.Name, saleDetailDTO.Customer.FirstName,
                "", saleDetailDTO.Customer.LastName);

            lbContact.Text = saleDetailDTO.Customer.ContactInfo.Contact;
            
            lbTower.Text = unitDto.PropertyTower.Name;
            lbUnitNo.Text = CommonUIConverter.getPropertyUnitFormattedNo(unitDto.Wing, unitDto.UnitNo);
            lbBookUnitType.Text = unitDto.UnitType.Name;
            
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private BookingCancelSuccessPageDTO getSessionPageData()
    {
        return (BookingCancelSuccessPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private void initPageInfo()
    {

    }
    protected void goToCancelledUnitPage(object sender, EventArgs e)
    {
        try
        {
            PrUnitSaleDetailDTO saleDetailDTO = getSessionPageData().UnitSaleDetailDTO;
            CancelledUnitDetailNavDTO navDTO = new CancelledUnitDetailNavDTO();
            navDTO.Mode = PageMode.VIEW;
            navDTO.PrUnitSaleDetailId = saleDetailDTO.Id;
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.CANCELLED_UNIT_DETAILS, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void goToAddPaymentPage(object sender, EventArgs e)
    {
        try
        {
            CustomerPaymentNavDTO navDTO = new CustomerPaymentNavDTO();
            navDTO.IsPdcPayment = false;
            navDTO.Mode = PageMode.ADD;
            navDTO.PymtMode = PaymentMode.Payable;
            navDTO.PrUnitSaleDetailId = getSessionPageData().UnitSaleDetailDTO.Id;
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.CUSTOMER_PYMT_ADD, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
}