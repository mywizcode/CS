﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using ConstroSoft;
using ConstroSoft.Logic.CachingProvider;

public partial class CSMaster : System.Web.UI.MasterPage
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            try
            {
                if (ApplicationUtil.isSessionActive(Session) && ApplicationUtil.IsSessionKeyExistInCache(Session))
                {
                    UserDefinitionDTO userDef = getUserDefinitionDTO();
                    lbUserName.Text = userDef.Username;
                    hdnUserName.Value = userDef.Username;
                    imgProfilePic.ImageUrl = userDef.ProfileImagePath;

                    setFunctionName();
                    initSidebar();
                    initPropertyGrid();
                    //Init Notifications
                    initNotificationGrid();
                }
                else
                {
                	doLogout(Constants.URL.LOGIN);
                }
            }
            catch (Exception ex)
            {
            }
        }
    }
    public void setPageErrorInNotyMsg(ValidatorCollection collection)
    {
        List<string> tmpList = new List<string>();
        if (collection != null)
        {
            List<IValidator> validatorList = collection.Cast<IValidator>().Where(v => !v.IsValid).ToList();
            if (validatorList != null && validatorList.Count > 0)
            {
                foreach (IValidator validator in validatorList)
                {
                    tmpList.Add(CommonUtil.getNotyErrorMsg(validator.ErrorMessage));
                    validator.IsValid = true;
                }
            }
        }
        if (tmpList.Count > 0) setNotyMsg(tmpList);
    }
    public void setNotyMsg(string msg)
    {
    	if(!string.IsNullOrWhiteSpace(msg)) {
	        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
	        upNotyMsg.Update();
    	}
    }
    public void setNotyMsg(List<string> msgList)
    {
        msgList.ForEach(x => btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, x));
        upNotyMsg.Update();
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void setFunctionName()
    {
        string[] fnAndPageName = ApplicationUtil.getFunctionAndPageName(HttpContext.Current.Request, 0);
        functionName.Value = fnAndPageName[0].ToUpper();
        pageName.Value = fnAndPageName[1].ToUpper();
    }
    private bool isCRM()
    {
        return (Constants.Function.CRM.ToUpper().Equals(functionName.Value));
    }
    private bool isERP()
    {
        return (Constants.Function.ERP.ToUpper().Equals(functionName.Value));
    }
    private bool isAcntFianance()
    {
        return (Constants.Function.ACNT_FINANCE.ToUpper().Equals(functionName.Value));
    }
    private bool isFirmPropertySetup()
    {
        return (Constants.Function.FIRM_PROPERTY_SETUP.ToUpper().Equals(functionName.Value));
    }
    private bool isAdministration()
    {
        return (Constants.Function.ADMINISTRATION.ToUpper().Equals(functionName.Value));
    }
    private void initSidebar()
    {
        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        CrmMenu.Visible = CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_FN_CRM);
        ErpMenu.Visible = false;
        AcntFinanceMenu.Visible = CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_FN_ACCOUNT_FINANCE);
        FirmPropertySetupMenu.Visible = CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_FIRM_PROPERTY_SETUP);
        AdministrationMenu.Visible = CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_ADMINISTRATION);
        bool isCRMEnabled = isCRM() && CrmMenu.Visible;
        bool isERPEnabled = isERP() && ErpMenu.Visible;
        bool isAcntFinanceEnabled = isAcntFianance() && AcntFinanceMenu.Visible;
        bool isPropertySetupEnabled = isFirmPropertySetup() && FirmPropertySetupMenu.Visible;
        bool isAdministrationEnabled = isAdministration() && AdministrationMenu.Visible;
        //CRM Functional Menu
        CRMDashboard.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_FN_CRM);
        //Call Management
        CallManagementMenu.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_CALL_MANAGEMENT);
        CallHistory.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_CALL_HISTORY);
        UnresolvedCalls.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_UNRESOLVED_CALLS);
        //Enquiry Management
        EnquiryManagementMenu.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_ENQUIRY_MANAGEMENT);
        AllEnquiryLeadSearch.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_ALL_ENQ_LEADS);
        LeadAssignment.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_LEAD_ASSIGNMENT);
        MyLeads.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_MY_LEADS);
        MyEnquiry.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_MY_ENQUIRIES);
        //Marketing Campaign Management
        MarketingCampaignMenu.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_MARKETING_CAMPAIGN_MANAGEMENT);
        liEmailSMSTemplateStore.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_EMAIL_SMS_TEMPLATE_STORE);
        EmailSMSCampaignSearch.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_EMAIL_SMS_CAMPAIGN);
        PreSaleMenuHeader.Visible = EnquiryManagementMenu.Visible || MarketingCampaignMenu.Visible;
        //Sale Management
        SaleManagementMenu.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_SALE_MANAGEMENT);
        AvailablePropertyUnit.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_AVAILABLE_PR_UNIT);
        SoldPropertyUnit.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_SOLD_PR_UNIT);
        CancelledPropertyUnit.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_CANCELLED_PR_UNIT);
        Customer.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_CUSTOMER);
        PostSaleMenuHeader.Visible = SaleManagementMenu.Visible;
        //CRM analytics and Report Management
        CRMSReportsAnalyticsMenu.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_CRM_REPORT_AND_ANALYTICS);
        EnquiryLeadAnalytics.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.LEAD_ENQUIRY_ANALYTICS_REPORT);
        EnquiryLeadUserAnalytics.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.LEAD_ENQUIRY_USER_ANALYTICS_REPORT);
        CRMReportsandAnalyticsHeader.Visible = CRMSReportsAnalyticsMenu.Visible;
        //ERP Functional Menu
        ERPDashboard.Visible = isERP();
        //Account and Finance Functional Menu
        AcntFinanceDashboard.Visible = isAcntFinanceEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_FN_ACCOUNT_FINANCE);
        //Account Management
        AccountManagementMenu.Visible = isAcntFinanceEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_ACCOUNT_MANAGEMENT);
        ManageAccounts.Visible = isAcntFinanceEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_ACCOUNTS);
        TallyManagement.Visible = isAcntFinanceEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_TALLY_MANAGEMENT);
        //Payment Management
        PaymentManagementMenu.Visible = isAcntFinanceEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_PAYMENT_MANAGEMENT);
        CustomerPayment.Visible = isAcntFinanceEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_CUSTOMER_PAYMENTS);
        AgencyPayment.Visible = false;
        //Property Funds
        PropertyFund.Visible = isAcntFinanceEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_PROPERTY_FUND_MANAGEMENT);
        AcntFinanceMenuHeader.Visible = AccountManagementMenu.Visible || PaymentManagementMenu.Visible || PropertyFund.Visible;
        //Expense Management
        ExpenseManagementMenu.Visible = false;
        Agency.Visible = false;
        PropertyExpense.Visible = false;
        ExpensesMenuHeader.Visible = false;
        //Account and Finance Reports
        AcntFinanceReportMenu.Visible = isAcntFinanceEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_ACNTFN_REPORT_AND_ANALYTICS);
        PymtDueReport.Visible = isAcntFinanceEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.PAYMENT_DUE_REPORT);
        PymtScheduleReort.Visible = isAcntFinanceEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.PAYMENT_SHEDULE_REPORT);
        AcntFinanceReportMenuHeader.Visible = AcntFinanceReportMenu.Visible;
        //Firm and Property Setup functional menu
        FirmSetup.Visible = isPropertySetupEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_FIRM); ;
        FirmMenuHeader.Visible = FirmSetup.Visible;
        Property.Visible = isPropertySetupEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_PROPERTY); ;
        PropertyUnit.Visible = isPropertySetupEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_PROPERTY_UNIT); ;
        PymtSchedule.Visible = isPropertySetupEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_PROPERTY_PARKING);
        PropertyParking.Visible = isPropertySetupEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_PROPERTY_PYMT_SCHEDULE);
        PropertySetupMenuHeader.Visible = Property.Visible || PropertyUnit.Visible || PymtSchedule.Visible || PropertyParking.Visible;
        //Adminitstration Functional menu
        MasterData.Visible = isAdministrationEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_MANAGE_MASTER);
        EmailSMSProvider.Visible = isAdministrationEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_EMAIL_SMS_PROVIDER);

        //Set sidebar menu header
        setSidebarMenuText();
    }
    private void setSidebarMenuText()
    {
    	divSiderbar.Visible = true;
        if (isCRM() && CrmMenu.Visible)
        {
            lbSidebarMenuIcon.Text = Constants.ICON.CRM_FN_MENU;
            lbSidebarMenuText.Text = Resources.Labels.CRM_MENU;
            lbSidebarMenuDesc.Text = "Pre and Post Sale";
        }
        else if (isERP() && ErpMenu.Visible)
        {
            lbSidebarMenuIcon.Text = Constants.ICON.ERP_FN_MENU;
            lbSidebarMenuText.Text = Resources.Labels.ERP_MENU;
            lbSidebarMenuDesc.Text = "Enterprise Resource Planning";
        }
        else if (isAcntFianance() && AcntFinanceMenu.Visible)
        {
            lbSidebarMenuIcon.Text = Constants.ICON.ACNTFINANCE_FN_MENU;
            lbSidebarMenuText.Text = Resources.Labels.ACCNT_FINANCE_MENU;
            lbSidebarMenuDesc.Text = "Account and Payments";
        }
        else if (isFirmPropertySetup() && FirmPropertySetupMenu.Visible)
        {
            lbSidebarMenuIcon.Text = Constants.ICON.PR_SETUP_FN_MENU;
            lbSidebarMenuText.Text = Resources.Labels.FIRM_PROPERTY_SETUP_MENU;
            lbSidebarMenuDesc.Text = "Firm and Property settings";
        }
        else if (isAdministration() && AdministrationMenu.Visible)
        {
            lbSidebarMenuIcon.Text = Constants.ICON.ADMIN_FN_MENU;
            lbSidebarMenuText.Text = Resources.Labels.ADMINISTRATION_MENU;
            lbSidebarMenuDesc.Text = "Application settings";
        } else {
        	divSiderbar.Visible = false;
        }
    }
    public void logoutUser(object sender, EventArgs e)
    {
        doLogout(Constants.URL.LOGIN);
    }
    public void doLogout(string url)
    {
    	//bool IsLoggedInWithOtherSession = ApplicationUtil.IsUserLoggedInWithOtherSession(Session);
        ApplicationUtil.clearSession(Session, Application);
        //TODO - IsLoggedInWithOtherSession use to show warning message for user. This requires understanding of session time out.
        Response.Redirect(url, true);
    }
    public void initPropertyGrid()
    {
        UserDefinitionDTO userDTO = getUserDefinitionDTO();
        propertySelectionGrid.DataSource = userDTO.AssignedProperties;
        propertySelectionGrid.DataBind();
        long defaultPropertyId = 0;
        if (userDTO.AssignedProperties.Count > 0)
        {
            PropertyDTO selectedProperty = userDTO.AssignedProperties.Find(c => c.isUISelected);
            if(selectedProperty == null) {
            	selectedProperty = userDTO.AssignedProperties[0];
            	//When user logs in default selected property will be null, fetch notifications and keep them in memory.
            	NotificationBO notificationBO = new NotificationBO();
            	notificationBO.fetchAndCacheUserNotifications(userDTO, selectedProperty.Id);
            }
            defaultPropertyId = selectedProperty.Id;
        }
         
        selectHeaderProperty(defaultPropertyId);
    }
    protected void onClickSelectNavbarProperty(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            selectHeaderProperty(selectedIndex);
            NotificationBO notificationBO = new NotificationBO();
            //Fetch Notifications on change of the property.
        	notificationBO.fetchAndCacheUserNotifications(getUserDefinitionDTO(), selectedIndex);
            Response.Redirect(Constants.URL.CRM_DASHBOARD, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
        }
    }
    private void selectHeaderProperty(long selectedIndex)
    {
        UserDefinitionDTO userDTO = getUserDefinitionDTO();
        userDTO.AssignedProperties.ForEach(x => x.isUISelected = false);
        foreach (PropertyDTO propertyDTO in userDTO.AssignedProperties)
        {
            if (propertyDTO.Id == selectedIndex)
            {
                propertyDTO.isUISelected = true;
                lbHeaderPropertyName.Text = propertyDTO.Name;
                lbHeaderMobilePropertyName.Text = propertyDTO.Name;
                break;
            }
        }
    }
    protected string getTimeInfo(string subType, DateTime? scheduledDate)
    {
        string timeInfo = "";
        if (scheduledDate != null)
        {
            NotificationSubType tmpSubType = EnumHelper.ToEnum<NotificationSubType>(subType);
            if (tmpSubType == NotificationSubType.NEW_LEAD_ASSIGNED || tmpSubType == NotificationSubType.LEAD_REASSIGNED_SELF
                    || tmpSubType == NotificationSubType.LEAD_REASSIGNED_USER || tmpSubType == NotificationSubType.LEAD_CLOSED_USER
                    || tmpSubType == NotificationSubType.LEAD_ACTIVITY_LOGGED_BY_USER || tmpSubType == NotificationSubType.LEAD_ACTIVITY_LOGGED_BY_FACEBOOK
                    || tmpSubType == NotificationSubType.ENQUIRY_REASSIGNED_SELF || tmpSubType == NotificationSubType.ENQUIRY_ACTIVITY_LOGGED_BY_FACEBOOK
                    || tmpSubType == NotificationSubType.ENQUIRY_REASSIGNED_USER || tmpSubType == NotificationSubType.ENQUIRY_CLOSED_USER
                    || tmpSubType == NotificationSubType.ENQUIRY_REOPEN_USER || tmpSubType == NotificationSubType.ENQUIRY_ACTIVITY_LOGGED_BY_USER
                    || tmpSubType == NotificationSubType.LEAD_CONVERTED_BY_USER || tmpSubType == NotificationSubType.ENQUIRY_USED_FOR_BOOKING)
            {
                TimeSpan span = (DateUtil.getUserLocalDateTime() - scheduledDate.Value);
                if (span.Days == 0 && span.Hours == 0 && span.Minutes <= 1) timeInfo = "Just Now";
                else if (span.Days == 0 && span.Hours == 0 && span.Minutes >= 2) timeInfo = span.Minutes + " minutes ago";
                else if (span.Days == 0 && span.Hours > 0) timeInfo = span.Hours + " hours and " + span.Minutes + " minutes ago";
                else if (span.Days == 1) timeInfo = "Yesterday";
                else if (span.Days > 1) timeInfo = span.Days + " days ago";
            } else if(tmpSubType == NotificationSubType.ENQUIRY_REMINDER || tmpSubType == NotificationSubType.LEAD_REMINDER){
            	timeInfo = DateUtil.getScheduledDateTimeInfo(scheduledDate.Value, " to go");
            }
        }

        return timeInfo;
    }
    public void initNotificationGrid()
    {
        UserDefinitionDTO userDTO = getUserDefinitionDTO();
        List<NotificationDTO> alertNotificationsList = new List<NotificationDTO>();
        NotificationDTO callIntimationNotificationDTO = null;
        List<NotificationDTO> taskNotificationsList = new List<NotificationDTO>();
        //If default property is set then only show notifications
        if(CommonUtil.getCurrentPropertyDTO(userDTO) != null) {
            List<NotificationDTO> allNotificationList = NotificationCacheProvider.Instance.getAllNotifications(NotificationUtil.getAllKeysForNotification(userDTO));
            if(allNotificationList != null && allNotificationList.Count > 0) {
            	foreach(NotificationDTO tmpNotification in allNotificationList) {
            		NotificationUtil.setNotyTypeIcon(tmpNotification);//Set notification icon
                	if(tmpNotification.Type == NotificationType.ALERT) {
                		//Ideally there would be only one call intimation NotificationDTO.
                		if(tmpNotification.SubType == NotificationSubType.INCOMING_CALL_INTIMATION) callIntimationNotificationDTO = tmpNotification;
                		else alertNotificationsList.Add(tmpNotification);
                	}
                	else taskNotificationsList.Add(tmpNotification);
                }
                alertNotificationsList.Sort(new Comparison<NotificationDTO>((x, y) => -DateTime.Compare(x.ScheduledDate ?? DateTime.MaxValue, y.ScheduledDate ?? DateTime.MaxValue)));
                taskNotificationsList.Sort(new Comparison<NotificationDTO>((x, y) => -DateTime.Compare(x.ScheduledDate ?? DateTime.MaxValue, y.ScheduledDate ?? DateTime.MaxValue)));
            }
        }
        updateNotifications(alertNotificationsList, taskNotificationsList, callIntimationNotificationDTO);
    }
    protected void autoRefreshNotifications(object sender, EventArgs e)
    {
    	reloadAllNotifications();
    }
    private void reloadAllNotifications() {
    	initNotificationGrid();
    	upNotificationTaskCountUpdatePanel.Update();
    	upNotificationAlertCountUpdatePanel.Update();
    	upNotificationTaskUpdatePanel.Update();
    	upNotificationAlertUpdatePanel.Update();
        upClearAllNotificationAlertUpdatePanel.Update();
    }
    protected void onClickClearAllAlertNotificationsBtn(object sender, EventArgs e)
    {
        try
        {
        	List<long> notificationIdList = new List<long>();
        	List<string> notificationList = new List<string>();
        	UserDefinitionDTO userDTO = getUserDefinitionDTO();
        	long propertyId = CommonUtil.getCurrentPropertyDTO(userDTO).Id;
        	foreach (ListViewItem item in notificationAlertGrid.Items)
            {
        		Button btn = (Button)item.FindControl("btnNotificationAction");
                if (btn != null)
                {
                    long selectedId = long.Parse(btn.Attributes["data-pid"]);
                    string selectedUniqueId = btn.Attributes["data-uniqueid"];
                    notificationIdList.Add(selectedId);
                    notificationList.Add(selectedUniqueId);
                }
            }
        	
        	NotificationBO notificationBO = new NotificationBO();
            //Mark notification closed in DB
            if (notificationIdList.Count > 0) notificationBO.markNotificationClosed(notificationIdList.ToArray());
            //Remove Notification from Cache
            if (notificationList.Count > 0) 
                NotificationCacheProvider.Instance.removeAllNotification(NotificationUtil.getNotificationUserKey(userDTO.Username, propertyId), notificationList);
            reloadAllNotifications();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            //TODO set Noty msg
        }
    }
    protected void onClickAlertNotification(object sender, EventArgs e)
    {
        try
        {
            Button rd = (Button)sender;
            UserDefinitionDTO userDTO = getUserDefinitionDTO();
            long propertyId = CommonUtil.getCurrentPropertyDTO(userDTO).Id;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            string selectedEntityRefNo = rd.Attributes["data-entityrefinfo"];
            string selectedUniqueId = rd.Attributes["data-uniqueid"];
            NotificationSubType selectedSubType  = EnumHelper.ToEnum<NotificationSubType>((string)rd.Attributes["data-notification-subtype"]);
            NotificationBO notificationBO = new NotificationBO();
            //Mark notification closed in DB
            notificationBO.markNotificationClosed(selectedId);
            //Remove Notification from Cache
            NotificationCacheProvider.Instance.removeNotification(NotificationUtil.getNotificationUserKey(userDTO.Username, propertyId), selectedUniqueId);
            //Navigate to Page of Notification entity
            navigateToPage(selectedSubType, selectedEntityRefNo);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            //TODO set Noty msg
        }
    }
    protected void onClickCallIntimationNotification(object sender, EventArgs e)
    {
        try
        {
            Button rd = (Button)sender;
            UserDefinitionDTO userDTO = getUserDefinitionDTO();
            long selectedId = long.Parse(rd.Attributes["data-pid"]);//Notification DB Id
            string selectedEntityRefNo = rd.Attributes["data-entityrefinfo"];//Entity Ref Info used to navigate to corresponding page
            string selectedUniqueId = rd.Attributes["data-uniqueid"];//UI unique Id used to remove from memory. In case alert notification it is Notification DB Id
            NotificationBO notificationBO = new NotificationBO();
            //Mark notification closed in DB
            notificationBO.markNotificationClosed(selectedId);
            //Remove Notification from Cache
            NotificationCacheProvider.Instance.removeNotification(NotificationUtil.getNotificationUserKey(userDTO.Username, 0), selectedUniqueId);
            //Navigate to Page of Notification entity
            navigateToPage(NotificationSubType.INCOMING_CALL_INTIMATION, selectedEntityRefNo);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            //TODO set Noty msg
        }
    }
    protected void onClickTaskNotification(object sender, EventArgs e)
    {
        try
        {
            Button rd = (Button)sender;
            UserDefinitionDTO userDTO = getUserDefinitionDTO();
            long propertyId = CommonUtil.getCurrentPropertyDTO(userDTO).Id;
            string selectedEntityRefNo = rd.Attributes["data-entityrefinfo"];
            NotificationSubType selectedSubType  = EnumHelper.ToEnum<NotificationSubType>((string)rd.Attributes["data-notification-subtype"]);
            //Navigate to Page of Notification entity
            navigateToPage(selectedSubType, selectedEntityRefNo);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            //TODO set Noty msg
        }
    }
    private void updateNotifications(List<NotificationDTO> alertNotificationsList, List<NotificationDTO> taskNotificationsList, NotificationDTO callIntimationDTO)
    {
    	lbNotificationTaskCount.Text = taskNotificationsList.Count.ToString();
        spNotificationTaskBadge.Visible = taskNotificationsList.Count > 0;
        notificationTaskGrid.DataSource = taskNotificationsList;
        notificationTaskGrid.DataBind();
        
        lbNotificationAlertCount.Text = alertNotificationsList.Count.ToString();
        spNotificationAlertBadge.Visible = alertNotificationsList.Count > 0;
        notificationAlertGrid.DataSource = alertNotificationsList;
        notificationAlertGrid.DataBind();
        lnkClearAllAlertNotifications.Visible = alertNotificationsList.Count > 0;
        
        //Set Info of Call Intimation
        btnCallIntimationPresentHdn.Value = "N";
        if(callIntimationDTO != null) {
        	btnCallIntimationPresentHdn.Value = "Y";
        	btnCallIntimationNotificationAction.Attributes["data-pid"] = callIntimationDTO.Id.ToString();
            btnCallIntimationNotificationAction.Attributes["data-entityrefinfo"] = callIntimationDTO.RefEntityInfo;
            btnCallIntimationNotificationAction.Attributes["data-uniqueid"] = callIntimationDTO.UIUniqueKey;
            btnCallIntimationNotificationAction.Attributes["data-message"] = callIntimationDTO.Message;
        }
    }
    private void navigateToPage(NotificationSubType subType, string EntityRefInfo) {
        if (subType == NotificationSubType.NEW_LEAD_ASSIGNED || subType == NotificationSubType.LEAD_REASSIGNED_SELF
            || subType == NotificationSubType.LEAD_REASSIGNED_USER || subType == NotificationSubType.LEAD_CLOSED_USER
            || subType == NotificationSubType.LEAD_ACTIVITY_LOGGED_BY_USER || subType == NotificationSubType.LEAD_REMINDER
            || subType == NotificationSubType.LEAD_ACTIVITY_LOGGED_BY_FACEBOOK || subType == NotificationSubType.LEAD_CONVERTED_BY_USER)
        {
        	long Id = long.Parse(EntityRefInfo);
    		LeadActivityHistoryNavDTO navDTO = new LeadActivityHistoryNavDTO();
            navDTO.LeadId = Id;
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.LEAD_ACTIVITY_HISTORY, true);
    	} else if (subType == NotificationSubType.ENQUIRY_REASSIGNED_SELF || subType == NotificationSubType.ENQUIRY_REASSIGNED_USER
    			 || subType == NotificationSubType.ENQUIRY_CLOSED_USER || subType == NotificationSubType.ENQUIRY_REOPEN_USER
    			 || subType == NotificationSubType.ENQUIRY_ACTIVITY_LOGGED_BY_USER || subType == NotificationSubType.ENQUIRY_REMINDER
    			 || subType == NotificationSubType.ENQUIRY_ACTIVITY_LOGGED_BY_FACEBOOK || subType == NotificationSubType.ENQUIRY_USED_FOR_BOOKING) {
    		long Id = long.Parse(EntityRefInfo);
    		EnquiryActivityHistoryNavDTO navDTO = new EnquiryActivityHistoryNavDTO();
            navDTO.EnquiryId = Id;
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.ENQUIRY_ACTIVITY_HISTORY, true);
    	} else if(subType == NotificationSubType.UNASSIGNED_LEADS) {
            Session[Constants.Session.NAV_DTO] = new LeadAssignmentNavDTO();
            Response.Redirect(Constants.URL.LEAD_ASSIGNMENT, true);
    	} else if(subType == NotificationSubType.INCOMING_CALL_INTIMATION) {
            ResolveCallNavDTO navDTO = new ResolveCallNavDTO();
            navDTO.CustomerNumber = EntityRefInfo;
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.RESOLVE_CALL, true);
    	} else if(subType == NotificationSubType.UNRESOLVED_CALLS) {
    		UnresolvedCallsNavDTO navDTO = new UnresolvedCallsNavDTO();
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.UNRESOLVED_CALLS, true);
    	}
    }
}
