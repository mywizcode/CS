﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initPaymentGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initPaymentGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        pageLength: 10
    };

    $("[id$='paymentSearchGrid']").CSBasicDatatable(dtOptions);
}




