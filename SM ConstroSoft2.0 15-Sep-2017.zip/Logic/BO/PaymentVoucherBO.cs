﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NHibernate;
using NHibernate.Criterion;

namespace ConstroSoft.Logic.BO
{

    public class PaymentVoucherBO
    {
        private static readonly log4net.ILog log =
             log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public PaymentVoucherBO() { }


        public IList<PaymentVoucherDTO> fetchPaymentVoucherGridData(string firmNumber, object searchByValue)
        {
            ISession session = null;
            IList<PaymentVoucherDTO> results = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                PaymentVoucherDTO pvDto = null;
                PaymentVoucher pv = null;
                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => pv.Id).WithAlias(() => pvDto.Id))
                            .Add(Projections.Property(() => pv.VoucherType).WithAlias(() => pvDto.VoucherType))
                            .Add(Projections.Property(() => pv.Action).WithAlias(() => pvDto.Action))
                            .Add(Projections.Property(() => pv.VoucherDate).WithAlias(() => pvDto.VoucherDate))
                            .Add(Projections.Property(() => pv.VoucherNumber).WithAlias(() => pvDto.VoucherNumber))
                            .Add(Projections.Property(() => pv.VoucherNaration).WithAlias(() => pvDto.VoucherNaration))
                            .Add(Projections.Property(() => pv.PartyLedgerName).WithAlias(() => pvDto.PartyLedgerName))
                            .Add(Projections.Property(() => pv.TallyPostingStatus).WithAlias(() => pvDto.PostingStatus));
                var query = session.QueryOver<PaymentVoucher>(() => pv);
                results = query.Where(() => pv.FirmNumber == firmNumber)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<PaymentVoucherDTO>()).List<PaymentVoucherDTO>();
                results.ToList();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating Voucher grid:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }
        public void updatePaymentVoucher(PaymentVoucherDTO paymentVoucherDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PaymentVoucher paymentVoucher = session.Get<PaymentVoucher>(paymentVoucherDTO.Id);
                        DTOToDomainUtil.populatePaymentVoucherUpdateFields(paymentVoucher, paymentVoucherDTO);
                        session.Update(paymentVoucher);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating Payment Voucher details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public PaymentVoucherDTO fetchPaymentVoucher(long Id)
        {
            ISession session = null;
            PaymentVoucherDTO paymentVoucherDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PaymentVoucher paymentVoucher = session.Get<PaymentVoucher>(Id);
                        paymentVoucherDto = DomainToDTOUtil.convertToPaymentVoucherDTO(paymentVoucher, true);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Payment Voucher details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return paymentVoucherDto;
        }

    }
}