﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ConstroSoft;

/// <summary>
/// Summary description for UserDefinitionDTO
/// </summary>
namespace ConstroSoft
{
    //Page DTO START
    [Serializable]
    public class PropertyPageDTO
    {
        public PropertyPageDTO() { }
        public List<PropertyDTO> SearchResult { get; set; }
        public PropertyDTO SelectedProperty { get; set; }
        public PropertyFilterDTO FilterDTO { get; set; }
    }
    [Serializable]
    public class PropertyUnitPageDTO
    {
        public PropertyUnitPageDTO() { }
        public List<PropertyUnitDTO> SearchResult { get; set; }
        public PropertyUnitDTO SelectedUnit { get; set; }
        public List<PropertyUnitDTO> UploadFailedResult { get; set; }
        public List<PropertyUnitDTO> UploadSuccessResult { get; set; }
        public PropertyUnitFilterDTO FilterDTO { get; set; }
    }
    [Serializable]
    public class PropertyParkingPageDTO
    {
        public PropertyParkingPageDTO() { }
        public List<PropertyParkingDTO> SearchResult { get; set; }
        public PropertyParkingDTO SelectedParking { get; set; }
        public List<PropertyParkingDTO> UploadFailedResult { get; set; }
        public List<PropertyParkingDTO> UploadSuccessResult { get; set; }
        public PropertyParkingFilterDTO FilterDTO { get; set; }
    }
    [Serializable]
    public class CustomerPageDTO
    {
        public CustomerPageDTO() { }
        public List<CustomerDTO> SearchResult { get; set; }
        public CustomerDTO SelectedCustomer { get; set; }
        public CustomerFilterDTO FilterDTO { get; set; }
    }
    [Serializable]
    public class AvailableUnitSearchPageDTO
    {
        public AvailableUnitSearchPageDTO() { }
        public List<PropertyUnitDTO> SearchResult { get; set; }
        public PropertyUnitFilterDTO FilterDTO { get; set; }
    }
    [Serializable]
    public class SoldUnitSearchPageDTO
    {
        public SoldUnitSearchPageDTO() { }
        public List<PrUnitSaleDetailDTO> SearchResult { get; set; }
        public SoldUnitFilterDTO FilterDTO { get; set; }
    }
    [Serializable]
    public class SoldUnitDetailPageDTO
    {
        public SoldUnitDetailPageDTO() { }
        public PrUnitSaleDetailDTO PrUnitSaleDTO { get; set; }
        public PropertyUnitDTO UnitDTO { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class BookingFormPageDTO
    {
        public BookingFormPageDTO() { }
        public PrUnitSaleDetailDTO PrUnitSaleDetail { get; set; }
        public PropertyUnitDTO UnitDTO { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class BookingSuccessPageDTO
    {
        public BookingSuccessPageDTO() { }
        public BookingSuccessNavDTO NavDTO { get; set; }
    }
    [Serializable]
    public class CustomerPymtSearchPageDTO
    {
        public CustomerPymtSearchPageDTO() { }
        public List<CustomerPymtSearchDTO> SearchResult {get; set;}
        public CustomerPymtSearchFilterDTO FilterDTO {get; set;}
    }
    [Serializable]
    public class CustomerPaymentHistoryPageDTO
    {
        public CustomerPaymentHistoryPageDTO() { }
        public PrUnitSaleDetailDTO PrUnitSaleDetail { get; set; }
        public PaymentMode PymtMode { get; set; }
        public string isMultiplePymts { get; set; }
        public TotalPymtDTO TotalPymtDTO { get; set; }
        public List<PrUnitSalePymtDTO> PymtHeaders { get; set; }
        public List<MasterPymtTransactionDTO> MasterPymtTransDTOs { get; set; }
        public List<MPTHistoryUIDTO> PymtTransHistoryUIDTOs { get; set; }
        public List<MPTHistoryUIDTO> PdcUIDTOs { get; set; }
        public object PrevNavDTO { get; set; }
        public CustomerPymtTxHistoryFilterDTO FilterDTO { get; set; }
    }
    [Serializable]
    public class CustomerPaymentPageDTO
    {
        public CustomerPaymentPageDTO() { }
        public PrUnitSaleDetailDTO PrUnitSaleDetail { get; set; }
        public bool IsPdcPayment { get; set; }
        public PaymentMode PymtMode { get; set; }
        public string isMultiplePymts { get; set; }
        public TotalPymtDTO TotalPymtDTO { get; set; }
        public List<PrUnitSalePymtDTO> PymtHeaders { get; set; }
        public MasterPymtTransactionDTO MasterPymtTxDTO { get; set; }
        public object PrevNavDTO { get; set; }
    }
    //Page DTO END
    [Serializable]
    public class CustomerPymtSearchDTO
    {
        public CustomerPymtSearchDTO() { }
        public long UnitSaleDetailId {get; set;}
        public string BookingRefNo {get; set;}
        public string CustomerName {get; set;}
        public string CustRefNo {get; set;}
        public long CustomerId {get; set;}
        public string PrTowerName {get; set;}
        public long PrTowerId {get; set;}
        public string UnitNo {get; set;}
        public PRUnitSaleStatus UnitSaleStatus {get; set;}
        public TotalPymtDTO TotalReceivablePymt { get; set; }
        public TotalPymtDTO TotalPayablePymt { get; set; }
        public PymtMasterStatus PymtStatus { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class TotalPymtDTO
    {
        public TotalPymtDTO() { }
        public decimal TotalPymtAmt { get; set; }
        public decimal TotalPaidAmt { get; set; }
        public decimal TotalPendingAmt { get; set; }
        public PymtMasterStatus PymtStatus { get; set; }
        public bool isUISelected { get; set; }
    }
    [Serializable]
    public class MPTHistoryUIDTO
    {
        public MPTHistoryUIDTO() { }
        public long Id { get; set; }
        public string TxRefNo { get; set; }
        public string PymtType { get; set; }
        public bool ShowSplit { get; set; }
        public string AccountName { get; set; }
        public PaymentMethod PymtMethod { get; set; }
        public System.DateTime TxDate { get; set; }
        public decimal PymtAmt { get; set; }
        public System.Nullable<System.DateTime> CollectionDate { get; set; }
        public System.Nullable<System.DateTime> ChequeDate { get; set; }
        public System.Nullable<System.DateTime> ClearanceDate { get; set; }
        public string PayName { get; set; }
        public string BankName { get; set; }
        public string Branch { get; set; }        
        public string MediaNo { get; set; }
        public ChequeStatus? ChequeStatus { get; set; }
        public string Comments { get; set; }
        public MPTPymtStatus PymtStatus { get; set; }     
        public bool ReceiptDelivered {get; set;}
        public List<MPTDistributionDTO> PymtDistributions {get; set;}
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class MPTDistributionDTO
    {
        public MPTDistributionDTO() { }
        public long PymtTxId { get; set; }
        public MasterControlDataDTO PymtType { get; set; }
        public FirmAccountDTO FirmAccount { get; set; }
        public decimal Amount { get; set; }
        public string Comments { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
    }
}