﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;

public partial class AvailableUnitSearch : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string SearchFilterModal = "SearchFilterModal";
    DropdownBO drpBO = new DropdownBO();
    AvailablePropertyUnitBO availableUnitBO = new AvailablePropertyUnitBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                PropertyUnitNavDTO navDto = (PropertyUnitNavDTO)Session[Constants.Session.NAV_DTO];
                Session.Remove(Constants.Session.NAV_DTO);
                Session.Remove(Constants.Session.PAGE_DATA);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(Constants.URL.DEFAULT_HOME_PAGE, false);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg) {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();

    }
    private void preRenderInitFormElements()
    {
        renderPageLayout();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpTowerFilter, DrpDataType.PROPERTY_TOWER, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(), null, userDefDto.FirmNumber);
        drpTowerFilter.Text = CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Id.ToString();
        drpBO.drpDataBase(drpUnitTypeFilter, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpUnitNoFilter, DrpDataType.AVAIL_UNIT_SEARCH_BY_PR_UNIT, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(PropertyUnitNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new AvailableUnitSearchPageDTO();
        initDropdowns();
        setSearchFilter(null);
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(PropertyUnitNavDTO navDto)
    {
        try
        {
            if (navDto != null)
            {
                setSearchFilter(navDto.filterDTO);
            }
            loadAvailableUnitSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageLayout()
    {
    }
    private void setSearchGrid(IList<PropertyUnitDTO> tmpList)
    {
        getSessionPageData().SearchResult = (tmpList != null) ? tmpList.ToList<PropertyUnitDTO>() : new List<PropertyUnitDTO>();
        assignUiIndexToUnit(getSearchPrUnitList());
        availableUnitSearchGrid.DataSource = getSearchPrUnitList();
        availableUnitSearchGrid.DataBind();
    }
    private void assignUiIndexToUnit(List<PropertyUnitDTO> unitDtos)
    {
        if (unitDtos != null && unitDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (PropertyUnitDTO unitDTO in unitDtos)
            {
                unitDTO.UiIndex = uiIndex++;
                unitDTO.RowInfo = CommonUIConverter.getGridViewRowInfo(unitDTO);
            }
        }
    }
    private AvailableUnitSearchPageDTO getSessionPageData()
    {
        return (AvailableUnitSearchPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<PropertyUnitDTO> getSearchPrUnitList()
    {
        return getSessionPageData().SearchResult;
    }
    private PropertyUnitDTO getSearchPropertyUnitDTO(long Id)
    {
        List<PropertyUnitDTO> searchList = getSearchPrUnitList();
        PropertyUnitDTO selectedUnitDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            selectedUnitDTO = searchList.Find(c => c.Id == Id);
        }
        return selectedUnitDTO;
    }
    private void loadAvailableUnitSearchGrid()
    {
        IList<PropertyUnitDTO> results = availableUnitBO.fetchAvailablePropertyUnits(getUserDefinitionDTO().FirmNumber, long.Parse(drpTowerFilter.Text), getSearchFilter());
        setSearchGrid(results);
    }
    protected void onClickBookAvailableUnitBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            BookingFormNavDTO navDTO = new BookingFormNavDTO();
            navDTO.PrUnitId = selectedId;
            PropertyUnitNavDTO unitNavDto = new PropertyUnitNavDTO();
            unitNavDto.filterDTO = getSearchFilter();
            navDTO.PrevNavDto = unitNavDto;
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.BOOKING_FORM, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Filter Criteria - Property Search - Start
    private PropertyUnitFilterDTO getSearchFilter()
    {
        return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            PropertyUnitFilterDTO filterDTO = getSearchFilter();
            drpBO.drpDataBase(drpUnitNoFilter, DrpDataType.PR_UNIT_SEARCH_BY_UNITNO, drpTowerFilter.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            if (filterDTO.UnitId > 0) drpUnitNoFilter.Text = filterDTO.UnitId.ToString(); else drpUnitNoFilter.ClearSelection();
            if (filterDTO.UnitType != null) drpUnitTypeFilter.Text = filterDTO.UnitType.Id.ToString(); else drpUnitTypeFilter.ClearSelection();
            if (filterDTO.Wing != null) txtWingFilter.Text = filterDTO.Wing; else txtWingFilter.Text = null;
            if (filterDTO.FloorNo != null) txtFloorNoFilter.Text = filterDTO.FloorNo; else txtFloorNoFilter.Text = null;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onSelectFilterTower(object sender, EventArgs e)
    {
        try
        {
            drpBO.drpDataBase(drpUnitNoFilter, DrpDataType.PR_UNIT_SEARCH_BY_UNITNO, drpTowerFilter.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            activeModalHdn.Value = SearchFilterModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            CommonUtil.setStickyPrTowerDTO(getUserDefinitionDTO(), long.Parse(drpTowerFilter.Text), drpTowerFilter.SelectedItem.Text);
            PropertyUnitFilterDTO filterDTO = new PropertyUnitFilterDTO();
            if (!string.IsNullOrWhiteSpace(drpUnitNoFilter.Text))
            {
                filterDTO.UnitId = long.Parse(drpUnitNoFilter.Text);
                filterDTO.UnitNo = drpUnitNoFilter.SelectedItem.Text;
            }
            if (!string.IsNullOrWhiteSpace(drpUnitTypeFilter.Text))
            {
                filterDTO.UnitType = CommonUIConverter.getMasterControlDTO(drpUnitTypeFilter.Text, drpUnitTypeFilter.SelectedItem.Text);
            }
            if (!string.IsNullOrWhiteSpace(txtWingFilter.Text))
            {
                filterDTO.Wing = txtWingFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(txtFloorNoFilter.Text))
            {
                filterDTO.FloorNo = txtFloorNoFilter.Text;
            }
            setSearchFilter(filterDTO);
            loadAvailableUnitSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            loadAvailableUnitSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(PropertyUnitFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new PropertyUnitFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {
            drpTowerFilter.Text = CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Id.ToString();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            PropertyUnitFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.UNIT_NO))
            {
                filterDTO.UnitId = 0;
                filterDTO.UnitNo = "";
            }
            else if (token.StartsWith(Constants.FILTER.UNIT_TYPE)) filterDTO.UnitType = null;
            else if (token.StartsWith(Constants.FILTER.WING)) filterDTO.Wing = null;
            else if (token.StartsWith(Constants.FILTER.FLOOR_NO)) filterDTO.FloorNo = null;
            else if (token.StartsWith(Constants.FILTER.TOWER_NAME)) setNotyMsg(CommonUtil.getNotyInfoMsg(Resources.Messages.TOWER_FILTER_DEFAULT));

            setSearchFilterTokens();
            loadAvailableUnitSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        PropertyUnitFilterDTO filterDTO = getSearchFilter();
        string filter = CommonUtil.addFilterToken("", Constants.FILTER.TOWER_NAME + CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Name);
        if (filterDTO != null)
        {
            if (filterDTO.UnitId > 0) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.UNIT_NO + filterDTO.UnitNo);
            if (filterDTO.UnitType != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.UNIT_TYPE + filterDTO.UnitType.Name);
            if (filterDTO.Wing != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.WING + filterDTO.Wing);
            if (filterDTO.FloorNo != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.FLOOR_NO + filterDTO.FloorNo);
        }
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - PropertyUnit Search - End
}
