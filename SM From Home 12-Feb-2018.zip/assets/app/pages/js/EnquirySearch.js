﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initEnquirySearchGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initEnquirySearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#enquirySearchBtnDiv",
        pageLength: 10
    };

    $("[id$='enquirySearchGrid']").CSBasicDatatable(dtOptions);
}