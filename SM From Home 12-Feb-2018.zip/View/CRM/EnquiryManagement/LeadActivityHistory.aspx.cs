﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.TelephonyProvider;

public partial class LeadActivityHistory : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string selectUserAssigneeModalError = "selectUserAssigneeModalError";
    string addReminderModalError = "addReminderModalError";
    string addReminderModalError1 = "addReminderModalError1";
    string addCommentModalError = "addCommentModalError";

    string selectUserAssigneeModal = "selectUserAssigneeModal";
    string addReminderModal = "addReminderModal";
    string addCommentModal = "addCommentModal";
    string ClickToCallModal = "ClickToCallModal";
    string clickToCallModalError = "clickToCallModalError";
    string closeLeadModal = "closeLeadModal";
    string closeLeadModalError = "closeLeadModalError";
    DropdownBO drpBO = new DropdownBO();
    EnquiryBO enquiryBO = new EnquiryBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    PropertyUserBO propertyUserBO = new PropertyUserBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                LeadActivityHistoryNavDTO navDto = ApplicationUtil.getPageNavDTO<LeadActivityHistoryNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_MY_LEADS)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
    	renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
    }
    public void setErrorMessage(string message, string group)
    {
    	string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
	        CustomValidator val = new CustomValidator();
	        val.IsValid = false;
	        val.ErrorMessage = message;
	        val.ValidationGroup = group;
	        this.Page.Validators.Add(val);
        }
    }
    private void doInit(LeadActivityHistoryNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(LeadActivityHistoryNavDTO navDto)
    {
        try
        {
            LeadActivityHistoryPageDTO PageDTO = new LeadActivityHistoryPageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            fetchLeadAndInitHistory(navDto.LeadId);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageFieldsWithEntitlement()
    {
    	LeadDetailDTO leadDTO = getLeadDetailDTO();
        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        liCicktoCall.Visible = (leadDTO.Status == LeadStatus.Open && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.LEAD_CLICK_TO_CALL));
    }
    private LeadActivityHistoryPageDTO getSessionPageData()
    {
        return (LeadActivityHistoryPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private LeadDetailDTO getLeadDetailDTO()
    {
        return getSessionPageData().LeadDTO;
    }
    private void navigateToPreviousPage()
    {
        LeadActivityHistoryPageDTO pageDTO = getSessionPageData();
        if (pageDTO != null && pageDTO.PrevNavDTO != null)
        {
            object obj = pageDTO.PrevNavDTO;
            if (obj is MyLeadsNavDTO)
            {
                MyLeadsNavDTO navDTO = (MyLeadsNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.MY_LEADS, true);
            }
            else if (obj is UserLeadHistoryNavDTO)
            {
                UserLeadHistoryNavDTO navDTO = (UserLeadHistoryNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.USER_LEAD_HISTORY, true);
            }
        }
        Response.Redirect(Constants.URL.MY_LEADS, true);
    }
    private void fetchLeadAndInitHistory(long LeadId)
    {
        LeadDetailDTO leadDTO = enquiryBO.fetchLeadDetails(LeadId, true);
        LeadActivityHistoryPageDTO pageDTO = getSessionPageData();
        pageDTO.LeadDTO = leadDTO;
        initPageInfo(leadDTO);
        initContactDrp(leadDTO);
    }
    private void initPageInfo(LeadDetailDTO leadDTO)
    {
        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        leadDTO.Assignee.FullName = CommonUIConverter.getCustomerFullName(leadDTO.Assignee.FirstName, leadDTO.Assignee.LastName);
        if (leadDTO.LeadActivities != null && leadDTO.LeadActivities.Count > 0)
        {
            List<LeadActivityDTO> list = new List<LeadActivityDTO>(leadDTO.LeadActivities);
            leadDTO.LeadActivities.Clear();
            leadDTO.LeadActivities = new HashSet<LeadActivityDTO>(list.OrderByDescending(x => x.DateLogged).ThenByDescending(x => x.InsertDate));
        }
        //Lead Detail Panel
        ulLeadDetailOptions.Visible = (leadDTO.Status == LeadStatus.Open);
        lbCustomerName.Text = CommonUIConverter.getCustomerFullName(leadDTO.Salutation.Name, leadDTO.FirstName, "", leadDTO.LastName);
        lbCustomerContact.Text = leadDTO.ContactInfo.Contact;
        btnLeadInfoHdn.Attributes["row-info"] = CommonUIConverter.getGridViewRowInfo(leadDTO);
        lbLeadAssignee.Text = leadDTO.Assignee.FullName;
        lbLeadRefNo.Text = leadDTO.LeadRefNo;
        lbEnquiryRefNo.Text = (leadDTO.EnquiryDetail != null) ? leadDTO.EnquiryDetail.EnquiryRefNo : null;
        pnlEnquiryRefNo.Visible = leadDTO.EnquiryDetail != null;
        lbLeadSource.Text = (leadDTO.Source != null) ? leadDTO.Source.Name : null;
        lbLeadBudget.Text = (leadDTO.Budget != null) ? leadDTO.Budget.ToString() : null;
        lbLeadStatus.Text = leadDTO.Status.ToString();
        //Populate Activity History
        populateActivityGrid(leadDTO);
        //Upcoming Reminder Panel
        populateUpcomingReminders(leadDTO);
    }
    private void populateUpcomingReminders(LeadDetailDTO leadDTO)
    {
        leadDTO.UpcomingEvents = new List<LeadActivityDTO>();
        ISet<LeadActivityDTO> activities = leadDTO.LeadActivities;
        if (activities != null && activities.Count > 0)
        {
            foreach (LeadActivityDTO activityDTO in activities)
            {
                if (activityDTO.RecordType == EnqActivityRecordType.Reminder && activityDTO.Status == EnqLeadActivityStatus.Open)
                {
                    leadDTO.UpcomingEvents.Add(activityDTO);
                }
            }
        }
        ulUpcomingReminderOptions.Visible = (leadDTO.Status == LeadStatus.Open);
        pnlUpcomingReminderEmpty.Visible = leadDTO.UpcomingEvents.Count == 0;
        upcomingReminderGrid.Visible = leadDTO.UpcomingEvents.Count > 0;
        upcomingReminderGrid.DataSource = leadDTO.UpcomingEvents;
        upcomingReminderGrid.DataBind();
    }
    private void initContactDrp(LeadDetailDTO leadDetailDTO)
    {
        drpCustomerContact.Items.Clear();
        if (!String.IsNullOrEmpty(leadDetailDTO.ContactInfo.Contact))
        {
            drpCustomerContact.Items.Add(new ListItem("Primary Contact: " + leadDetailDTO.ContactInfo.Contact, 
            		leadDetailDTO.ContactInfo.Contact));
        }
        if (!String.IsNullOrEmpty(leadDetailDTO.ContactInfo.AltContact))
        {
            drpCustomerContact.Items.Add(new ListItem("Alternate Contact: " + leadDetailDTO.ContactInfo.AltContact, 
            		leadDetailDTO.ContactInfo.AltContact));
        }
    }
    private void initVirtualPhoneDrp(IList<VirtualPhoneDTO> phoneDTOList) {
    	drpVirtualPhone.Items.Clear();
    	foreach(VirtualPhoneDTO tmpDTO in phoneDTOList) {
    		drpVirtualPhone.Items.Add(new ListItem(tmpDTO.PhoneNumber, tmpDTO.PhoneNumber));
    	}
    }
    private void populateActivityGrid(LeadDetailDTO leadDTO)
    {
        activityHistoryGrid.DataSource = new List<LeadActivityDTO>();
        if (leadDTO != null && leadDTO.LeadActivities != null && leadDTO.LeadActivities.Count > 0)
        {
            assignUiIndexToActivity(leadDTO);
            activityHistoryGrid.DataSource = leadDTO.LeadActivities;
        }
        activityHistoryGrid.DataBind();
    }
    private void assignUiIndexToActivity(LeadDetailDTO leadDTO)
    {
        ISet<LeadActivityDTO> activities = leadDTO.LeadActivities;
        if (activities != null && activities.Count > 0)
        {
            long uiIndex = 1;
            foreach (LeadActivityDTO activityDTO in activities)
            {
                activityDTO.UiIndex = uiIndex++;
                activityDTO.RowInfo = CommonUIConverter.getGridViewRowInfo(activityDTO);
                activityDTO.LoggedBy.FullName = CommonUIConverter.getCustomerFullName(activityDTO.LoggedBy.FirstName, activityDTO.LoggedBy.LastName);
                activityDTO.LeadDetail = leadDTO;
                if (activityDTO.RecordType == EnqActivityRecordType.Reminder && !string.IsNullOrWhiteSpace(activityDTO.RevRefNo))
                {
                    LeadActivityDTO tmpDTO = activities.ToList<LeadActivityDTO>().Find(x => !string.IsNullOrWhiteSpace(x.RefNo) && x.RefNo == activityDTO.RevRefNo);
                    activityDTO.PrevScheduledDate = tmpDTO.ScheduledDate;
                }
            }
        }
    }
    private LeadActivityHistoryNavDTO getCurrentPageNavigation()
    {
        LeadActivityHistoryPageDTO PageDTO = getSessionPageData();
        LeadActivityHistoryNavDTO navDTO = new LeadActivityHistoryNavDTO();
        navDTO.LeadId = PageDTO.LeadDTO.Id;
        navDTO.PrevNavDto = PageDTO.PrevNavDTO;
        return navDTO;
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickReassignLeadBtn(object sender, EventArgs e)
    {
        try
        {
            LeadDetailDTO leadDTO = getLeadDetailDTO();
            if (leadDTO.Status == LeadStatus.Open)
            {
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                drpBO.drpDataBase(drpUserAssignee, DrpDataType.ACTIVE_USERS_WITH_PR_ACCESS, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(),
                    Constants.SELECT_ITEM, userDefDto.FirmNumber);
                drpBO.removeSelectedItem(drpUserAssignee, leadDTO.Assignee.Id.ToString());
                activeModalHdn.Value = selectUserAssigneeModal;
            }
            else
            {
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(Resources.Messages.ERROR_LEAD_REASSIGN_NOT_OPEN));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickConvertToEnquiryBtn(object sender, EventArgs e)
    {
        try
        {
            LeadDetailDTO leadDTO = getLeadDetailDTO();
            if (validateConvertToEnquiry(leadDTO))
            {
                EnquiryDetailNavDTO navDTO = new EnquiryDetailNavDTO();
                navDTO.Mode = PageMode.ADD;
                navDTO.ConvertedLeadId = leadDTO.Id;
                navDTO.PrevNavDto = getCurrentPageNavigation();
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.ENQUIRY_DETAILS, true);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateConvertToEnquiry(LeadDetailDTO leadDTO)
    {
        if (leadDTO.Status != LeadStatus.Open)
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(Resources.Messages.ERROR_LEAD_CONVERT_NOT_OPEN));
            return false;
        }
        return true;
    }
    private void selectUpcomingReminder(long Id)
    {
        LeadDetailDTO leadDetailDTO = getLeadDetailDTO();
        leadDetailDTO.UpcomingEvents.ForEach(x => x.isUISelected = false);
        if (Id > 0)
        {
            leadDetailDTO.UpcomingEvents.Find(x => x.Id == Id).isUISelected = true;
        }
    }
    private EnqActivityMode getEnqActivityMode()
    {
        return EnumHelper.ToEnum<EnqActivityMode>(leadActivityModeHdn.Value);
    }
    private void setEnqActivityMode(EnqActivityMode action)
    {
        leadActivityModeHdn.Value = action.ToString();
    }
    protected string getActivityDesc(string activityType)
    {
        return EnumHelper.ToEnum<EnqActivityType>(activityType).GetDescription();
    }

    //Add Reminder Modal - Start
    private LeadActivityDTO getSelectedUpcomingReminder()
    {
        List<LeadActivityDTO> upcomingReminderList = getLeadDetailDTO().UpcomingEvents.ToList<LeadActivityDTO>();
        return upcomingReminderList.Find(c => c.isUISelected);
    }
    private void resetReminderModalFields()
    {
        txtReminderScheduledDate.Text = null;
        txtReminderComments.Text = null;
        pnlReminderInfo.Visible = false;
        divScheduledDate.Visible = true;
        EnqActivityMode mode = getEnqActivityMode();
        if (mode == EnqActivityMode.ADD_REMINDER)
        {
            lbReminderModalHeader.Text = Constants.ICON.ADD_REMINDER + Resources.Labels.ADD_REMINDER;
        }
        else if (mode == EnqActivityMode.RESCHEDULE_REMINDER)
        {
            LeadActivityDTO eventDTO = getSelectedUpcomingReminder();
            lbReminderModalHeader.Text = Constants.ICON.RESCHEDULE_REMINDER + Resources.Labels.RESCHEDULE_REMINDER;
            pnlReminderInfo.Visible = true;
            lbReminderInfoLabel.Text = "Current Scheduled Date: ";
            lbReminderInfoValue.Text = DateUtil.getCSDateTime(eventDTO.ScheduledDate);
        }
    }
    private void initReminderModalAction(EnqActivityMode mode, long selectedIndex)
    {
        setEnqActivityMode(mode);
        selectUpcomingReminder(selectedIndex);
        resetReminderModalFields();
        activeModalHdn.Value = addReminderModal;
    }
    protected void onClickAddReminderBtn(object sender, EventArgs e)
    {
        try
        {
            initReminderModalAction(EnqActivityMode.ADD_REMINDER, 0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickRescheduleReminderBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            initReminderModalAction(EnqActivityMode.RESCHEDULE_REMINDER, selectedIndex);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void addReminder(object sender, EventArgs e)
    {
        try
        {
            if (validateAddReminder())
            {
                LeadDetailDTO leadDTO = getLeadDetailDTO();
                EnqActivityRecordType recordType = EnqActivityRecordType.Reminder;
                LeadActivityDTO reminderDTO = CommonUtil.createNewLeadActivityDTO(leadDTO.Id, recordType, getUserDefinitionDTO());
                reminderDTO.ReminderMode = getReminderMode();
                reminderDTO.DateLogged = DateUtil.getUserLocalDateTime();
                reminderDTO.LoggedBy = getUserDefinitionDTO().FirmMember;
                reminderDTO.ActivityType = EnqActivityType.REMINDER;
                reminderDTO.ScheduledDate = DateUtil.getCSDateTime(txtReminderScheduledDate.Text); ;
                reminderDTO.Comments = txtReminderComments.Text.TrimNullable();
                reminderDTO.Status = (getEnqActivityMode() == EnqActivityMode.CANCEL_REMINDER || getEnqActivityMode() == EnqActivityMode.COMPLETE_REMINDER) ?
                                        EnqLeadActivityStatus.Completed : EnqLeadActivityStatus.Open;

                long parentId = 0;
                LeadActivityDTO parentReminderDTO = getSelectedUpcomingReminder();
                if (parentReminderDTO != null)
                {
                    parentId = parentReminderDTO.Id;
                    reminderDTO.RevRefNo = parentReminderDTO.RefNo;
                }

                reminderDTO.RefNo = enquiryBO.addLeadActivity(reminderDTO, getEnqActivityMode(), parentId, getUserDefinitionDTO());
                setReminderModalSuccessMsg(reminderDTO);
                setEnqActivityMode(EnqActivityMode.NONE);
                fetchLeadAndInitHistory(leadDTO.Id);
            }
            else
            {
                activeModalHdn.Value = addReminderModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setReminderModalSuccessMsg(LeadActivityDTO reminderDTO)
    {
        string msg = "";
        EnqActivityMode mode = getEnqActivityMode();
        if (mode == EnqActivityMode.ADD_REMINDER) msg = string.Format("Reminder# {0} is scheduled successfully.", reminderDTO.RefNo);
        else if (mode == EnqActivityMode.RESCHEDULE_REMINDER) msg = string.Format("Reminder# {0} is rescheduled successfully.", reminderDTO.RevRefNo);
        else if (mode == EnqActivityMode.COMPLETE_REMINDER) msg = string.Format("Reminder# {0} is completed successfully.", reminderDTO.RevRefNo);
        else if (mode == EnqActivityMode.CANCEL_REMINDER) msg = string.Format("Reminder# {0} is cancelled successfully.", reminderDTO.RevRefNo);

        (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(msg));
    }
    private ReminderMode getReminderMode()
    {
        ReminderMode reminderMode = ReminderMode.None;
        EnqActivityMode mode = getEnqActivityMode();
        if (mode == EnqActivityMode.ADD_REMINDER) reminderMode = ReminderMode.Scheduled;
        else if (mode == EnqActivityMode.RESCHEDULE_REMINDER) reminderMode = ReminderMode.Rescheduled;
        else if (mode == EnqActivityMode.COMPLETE_REMINDER) reminderMode = ReminderMode.None;
        else if (mode == EnqActivityMode.CANCEL_REMINDER) reminderMode = ReminderMode.Cancelled;

        return reminderMode;
    }
    protected void cancelAddReminderModal(object sender, EventArgs e)
    {
        try
        {
            setEnqActivityMode(EnqActivityMode.NONE);
            selectUpcomingReminder(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateAddReminder()
    {
        string valGrp = addReminderModalError;
        EnqActivityMode activityMode = getEnqActivityMode();
        if (activityMode == EnqActivityMode.CANCEL_REMINDER || activityMode == EnqActivityMode.COMPLETE_REMINDER) valGrp = addReminderModalError1;
        Page.Validate(valGrp);
        return Page.IsValid;
    }
    //Add Reminder Modal - End
    //Close Reminder Modal - Start
    private void resetAddCommentModalFields()
    {
    	txtAddComments.Text = null;
        EnqActivityMode mode = getEnqActivityMode();
        divCommentInfoModalRow.Visible = true;
        if (mode == EnqActivityMode.ADD_NOTE)
        {
            LeadActivityDTO eventDTO = getSelectedUpcomingReminder();
            lbAddCommentModalHeader.Text = Constants.ICON.ADD_NOTE + Resources.Labels.ADD_NOTE;
            divCommentInfoModalRow.Visible = false;
        } 
        else if (mode == EnqActivityMode.COMPLETE_REMINDER)
        {
            LeadActivityDTO eventDTO = getSelectedUpcomingReminder();
            lbAddCommentModalHeader.Text = Constants.ICON.COMPLETE_REMINDER + Resources.Labels.MARK_AS_COMPLETED;
            lbAddCommentInfoLabel.Text = "Reminder:";
            lbAddCommentInfoValue.Text = eventDTO.Comments;
        }
        else if (mode == EnqActivityMode.CANCEL_REMINDER)
        {
            LeadActivityDTO eventDTO = getSelectedUpcomingReminder();
            lbAddCommentModalHeader.Text = Constants.ICON.CANCEL_REMINDER + Resources.Labels.CANCEL_REMINDER;
            lbAddCommentInfoLabel.Text = "Reminder:";
            lbAddCommentInfoValue.Text = eventDTO.Comments;
        }
    }
    private void initAddCommentModalAction(EnqActivityMode mode, long selectedIndex)
    {
        setEnqActivityMode(mode);
        selectUpcomingReminder(selectedIndex);
        resetAddCommentModalFields();
        activeModalHdn.Value = addCommentModal;
    }
    protected void onClickAddNoteBtn(object sender, EventArgs e)
    {
        try
        {
        	initAddCommentModalAction(EnqActivityMode.ADD_NOTE, 0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickCompleteReminderBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            initAddCommentModalAction(EnqActivityMode.COMPLETE_REMINDER, selectedIndex);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickCancelReminderBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            initAddCommentModalAction(EnqActivityMode.CANCEL_REMINDER, selectedIndex);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void addComment(object sender, EventArgs e)
    {
        try
        {
            if (validateAddComment())
            {
                LeadDetailDTO leadDTO = getLeadDetailDTO();
                EnqActivityMode enqActivityMode = getEnqActivityMode();
                EnqActivityRecordType recordType = (enqActivityMode == EnqActivityMode.ADD_NOTE) ? EnqActivityRecordType.Note : EnqActivityRecordType.Reminder;
                LeadActivityDTO reminderDTO = CommonUtil.createNewLeadActivityDTO(leadDTO.Id, recordType, getUserDefinitionDTO());
                reminderDTO.ReminderMode = getReminderMode();
                reminderDTO.DateLogged = DateUtil.getUserLocalDateTime();
                reminderDTO.LoggedBy = getUserDefinitionDTO().FirmMember;
                reminderDTO.ActivityType = (enqActivityMode == EnqActivityMode.ADD_NOTE) ? EnqActivityType.NOTE : EnqActivityType.REMINDER;
                reminderDTO.Comments = txtAddComments.Text.TrimNullable();
                reminderDTO.Status = EnqLeadActivityStatus.Completed;

                long parentId = 0;
                LeadActivityDTO parentReminderDTO = getSelectedUpcomingReminder();
                if (parentReminderDTO != null)
                {
                    parentId = parentReminderDTO.Id;
                    reminderDTO.RevRefNo = parentReminderDTO.RefNo;
                }

                reminderDTO.RefNo = enquiryBO.addLeadActivity(reminderDTO, enqActivityMode, parentId, getUserDefinitionDTO());
                setReminderModalSuccessMsg(reminderDTO);
                setEnqActivityMode(EnqActivityMode.NONE);
                fetchLeadAndInitHistory(leadDTO.Id);
            }
            else
            {
                activeModalHdn.Value = addCommentModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelAddCommentModal(object sender, EventArgs e)
    {
        try
        {
            setEnqActivityMode(EnqActivityMode.NONE);
            selectUpcomingReminder(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateAddComment()
    {
        Page.Validate(addCommentModalError);
        return Page.IsValid;
    }
    //Close Reminder Modal - End
    //User Assignee Selection logic - start
    protected void ReassignLead(object sender, EventArgs e)
    {
        try
        {
            Page.Validate(selectUserAssigneeModalError);
            bool isValid = Page.IsValid;
            if (isValid)
            {
                long AssigneeId = long.Parse(drpUserAssignee.Text);
                LeadDetailDTO LeadDTO = getLeadDetailDTO();
                enquiryBO.ReAssignLead(LeadDTO.Id, AssigneeId, DateUtil.getUserLocalDateTime(), getUserDefinitionDTO());
                fetchLeadAndInitHistory(LeadDTO.Id);
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format("Lead# {0} is reassigneed successfully.", LeadDTO.LeadRefNo)));
            }
            else
            {
                activeModalHdn.Value = selectUserAssigneeModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelUserAssigneeModal(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }  
    //User Assignee Selection logic - end
    //Close Lead Modal - start
    protected void onClickCloseLeadBtn(object sender, EventArgs e)
    {
        try
        {
        	activeModalHdn.Value = closeLeadModal;
        	txtLeadCloseReason.Text = null;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void closeLead(object sender, EventArgs e)
    {
        try
        {
        	if(validateCloseLead()) {
        		LeadDetailDTO leadDTO = getLeadDetailDTO();
                if (leadDTO.Status == LeadStatus.Open)
                {
                    enquiryBO.closeLead(leadDTO.Id, txtLeadCloseReason.Text.TrimNullable(), getUserDefinitionDTO());
                    fetchLeadAndInitHistory(leadDTO.Id);
                    (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format("Lead# {0} is closed successfully.", leadDTO.LeadRefNo)));
                }
                else
                {
                    (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(Resources.Messages.ERROR_LEAD_CLOSE_NOT_OPEN));
                }
        	} else {
        		activeModalHdn.Value = closeLeadModal;
        	}
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelLeadLostReasonModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateCloseLead() {
    	Page.Validate(closeLeadModalError);
        return Page.IsValid;
    }
    //Close Enquiry Modal - end
    //Click to Call modal - start
    protected void onClickConnectCall(object sender, EventArgs e)
    {
    	try
        {
    		UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
    		IList<VirtualPhoneDTO> vPhoneList = propertyUserBO.fetchOutgoingVitualPhonesAllocattedToUser(userDefDTO.FirmMember.Id, CommonUtil.getCurrentPropertyDTO(userDefDTO).Id);
    		if(vPhoneList != null && vPhoneList.Count > 0) {
    			if (drpCustomerContact.Items.Count == 1 && vPhoneList.Count == 1) {
    				makeCallToCustomer(userDefDTO.FirmMember.ContactInfo.Contact, drpCustomerContact.Text, vPhoneList[0].PhoneNumber);
    			} else {
    				drpCustomerContact.ClearSelection();
    				initVirtualPhoneDrp(vPhoneList);
    				
    				divCustomerNumber.Visible = (drpCustomerContact.Items.Count > 1);
    				lbCustomerNumberField.Visible = !divCustomerNumber.Visible;
    				lbCustomerNumber.Text = drpCustomerContact.Text;
    				
    				divVirtualPhone.Visible = (vPhoneList.Count > 1);
    				lbVirtualPhoneField.Visible = !divVirtualPhone.Visible;
    				lbVirtualPhone.Text = vPhoneList[0].PhoneNumber;
    				
    				activeModalHdn.Value = ClickToCallModal;
    			}    			
    		} else {
    			(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Virtual Phone is not assigned to you. Please contact your supervisor."));
    		}
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void makeCallToCustomer(string agentNumber, string customerNumber, string virtualPhone) {
    	UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        OutboundCallDialDTO callDialDTO = new OutboundCallDialDTO();
        callDialDTO.AgentNumber = agentNumber;
        callDialDTO.CustomerNumber = customerNumber;
        callDialDTO.VirtualPhone = virtualPhone;
        callDialDTO.PropertyId = CommonUtil.getCurrentPropertyDTO(userDefDTO).Id;

        CallClient callClient = new CallClient();
        CallHistoryDTO callHistoryDTO = callClient.placeOutBoundCall(callDialDTO, userDefDTO);
        //Add Call Activity
        LeadDetailDTO leadDTO = getLeadDetailDTO();
        LeadActivityDTO activityDTO = CommonUtil.createNewCallLeadActivityDTO(leadDTO.Id, EnqActivityRecordType.Call, userDefDTO, callHistoryDTO);
        enquiryBO.addLeadActivity(activityDTO, EnqActivityMode.MAKE_CALL, 0, getUserDefinitionDTO());
        setEnqActivityMode(EnqActivityMode.NONE);
        (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("Call is placed and New activity is added successfully."));
        fetchLeadAndInitHistory(leadDTO.Id);
    }
    protected void connectToCall(object sender, EventArgs e)
    {
        try
        {
            Page.Validate(clickToCallModalError);
            bool isValid = Page.IsValid;
            if (isValid)
            {
            	UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
            	makeCallToCustomer(userDefDTO.FirmMember.ContactInfo.Contact, drpCustomerContact.Text, drpVirtualPhone.Text);
            }
            else
            {
                activeModalHdn.Value = ClickToCallModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelCall(object sender, EventArgs e)
    {
    }   
    //Click to Call modal - end
}