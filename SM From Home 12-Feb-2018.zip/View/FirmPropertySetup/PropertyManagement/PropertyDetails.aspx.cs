﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.BO;

public partial class PropertyDetails : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifyStep1Error = "addModifyStep1Error";
    string addModifyPrTowerError = "addModifyPrTowerError";
    string addModifyTaxDetailError = "addModifyTaxDetailError";
    string addModifyPropertyChargeError = "addModifyPropertyChargeError";
    string addMasterDataError = "addMasterDataError";
    string addAccountError = "addAccountError";
    string step1 = "step1";
    string step2 = "step2";
    string addMasterDataModal = "addMasterDataModal";
    string addModifyPrTowerModal = "addModifyPrTowerModal";
    string addModifyTaxDetailModal = "addModifyTaxDetailModal";
    string addModifyPropertyChargeModal = "addModifyPropertyChargeModal";
    string SearchFilterModal = "SearchFilterModal";
    string addAccountModal = "addAccountModal";
    DropdownBO drpBO = new DropdownBO();
    PropertyBO propertyBO = new PropertyBO();
    PropertyUserBO propertyUserBO = new PropertyUserBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    LoginBO loginBO = new LoginBO();
    FirmBO firmBO = new FirmBO();
    public enum PropertyPageMode { ADD, MODIFY, VIEW, NONE }
    public enum PrTowerAction { ADD, MODIFY }
    public enum TaxDetailAction { ADD, MODIFY }
    public enum PropertyChargeAction { ADD, MODIFY }
    public enum AccountAction { ADD }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                PropertyDetailNavDTO navDto = ApplicationUtil.getPageNavDTO<PropertyDetailNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_PROPERTY)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        setPageTitle();
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
    	ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpPropertytype, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.PROPERTY_TYPE.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpPropertyLocation, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.PROPERTY_LOCATION.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAccount, DrpDataType.FIRM_ACCOUNT, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAddressCountry, DrpDataType.COUNTRY, null, null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAddressState, DrpDataType.STATE, Constants.DEFAULT_COUNTRY, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpPropertyChargesType, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.PROPERTY_CHARGES.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpTaxType, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.PR_TAX_TYPE.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpAddressState.Text = Constants.DEFAULT_STATE;
        initCityDrp(drpAddressCity, Constants.DEFAULT_STATE);
        drpBO.drpDataBase(drpAcntType, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.ACCOUNT_TYPE.ToString(), null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAcntCountry, DrpDataType.COUNTRY, null, null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAcntState, DrpDataType.STATE, Constants.DEFAULT_COUNTRY, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpAcntState.Text = Constants.DEFAULT_STATE;
        initCityDrp(drpAcntCity, Constants.DEFAULT_STATE);
        drpBO.drpEnum<IncludeInPymtTotal>(drpTaxIncludeInPymt, null);
    }
    private void initCityDrp(DropDownList drp, string stateId)
    {
        drpBO.drpDataBase(drp, DrpDataType.CITY, stateId, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
    }
    public void setErrorMessage(string message, string group)
    {
    	string[] pageErrorGrp = { commonError, addModifyStep1Error };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        } else CommonUtil.getCustomValidator(Page, message, group);
    }
    private void renderPageFieldsWithEntitlement()
    {
        bool modifyMode = isModifyMode();
        bool viewMode = isViewMode();
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        //Enable Current active page
        string currentStep = activeStepHdn.Value;
        propDetailsPage1.Visible = step1.Equals(currentStep);
        propDetailsPage2.Visible = step2.Equals(currentStep);
        //Enable/Disable fields
        txtPropertyName.ReadOnly = viewMode || modifyMode;
        txtReraNo.ReadOnly = viewMode;
        drpPropertytype.Enabled = !viewMode;
        drpPropertyLocation.Enabled = !viewMode;
        txtPropertyArea.ReadOnly = viewMode;
        txtTotalEstimation.ReadOnly = viewMode;
        drpAccount.Enabled = !viewMode;
        txtAddressLine1.ReadOnly = viewMode;
        txtAddressLine2.ReadOnly = viewMode;
        txtTown.ReadOnly = viewMode;
        drpAddressCountry.Enabled = !viewMode;
        drpAddressState.Enabled = !viewMode;
        drpAddressCity.Enabled = !viewMode;
        txtPin.ReadOnly = viewMode;
        //Enable/disable buttons
        addPropertyTypeBtn.Visible = !viewMode && CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_MANAGE_MASTER);
        addPropertyLocationBtn.Visible = !viewMode && CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_MANAGE_MASTER);
        addPropertyTaxType.Visible = !viewMode && CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_MANAGE_MASTER);
        addPropertyChargeType.Visible = !viewMode && CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_MANAGE_MASTER);

        lnkAddPrTowerBtn.Visible = !viewMode;
        propertyTowerGrid.Columns[0].Visible = !viewMode;

        lnkAddTaxDetailsBtn.Visible = !viewMode;
        taxDetailGrid.Columns[0].Visible = !viewMode;

        lnkAddPropertyChargeBtn.Visible = !viewMode;
        propertyChargesGrid.Columns[0].Visible = !viewMode;

        liModifyProperty.Visible = viewMode && CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_MODIFY);
    }
    private void setPageTitle()
    {
        if (isAddMode()) lbPageTitle.Text = Constants.ICON.ADD + Resources.Labels.ADD_PROPERTY;
        else if (isModifyMode()) lbPageTitle.Text = Constants.ICON.MODIFY + Resources.Labels.MODIFY_PROPERTY;
        else if (isViewMode()) lbPageTitle.Text = Constants.ICON.VIEW_DTL + Resources.Labels.PROPERTY_DETAILS;
        setSubHeaderPageTitle();
    }
    private void setSubHeaderPageTitle()
    {
        string jumpTo = activeStepHdn.Value;
        lbSubHeaderPageTitle.Text = "";
        if (jumpTo.Equals(step1))
        {
            lbSubHeaderPageTitle.Text = " - " + Resources.Labels.PROPERTY_PAGE1_TITLE;
        }
        else if (jumpTo.Equals(step2))
        {
            lbSubHeaderPageTitle.Text = " - " + Resources.Labels.PROPERTY_PAGE2_TITLE;
        }
    }
    private void doInit(PropertyDetailNavDTO navDto)
    {
        initDropdowns();
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(PropertyDetailNavDTO navDto)
    {
        if (navDto != null)
        {
            PropertyDetailPageDTO PageDTO = new PropertyDetailPageDTO();
            pageModeHdn.Value = navDto.Mode.ToString();
            activeStepHdn.Value = step1;
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            if (isAddMode())
            {
                PageDTO.PropertyDTO = populatePropertyDTOAdd();
                populateUIFieldsFromDTO(null);
            }
            else
            {
                PageDTO.PropertyDTO = propertyBO.fetchProperty(navDto.PropertyId);
                populateUIFieldsFromDTO(PageDTO.PropertyDTO);
            }
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void navigateToPreviousPage()
    {
        PropertyDetailPageDTO PageDTO = getSessionPageData();
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is PropertySearchNavDTO)
            {
                PropertySearchNavDTO navDTO = (PropertySearchNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.PROPERTY_SEARCH, true);
            }
        }
        Response.Redirect(Constants.URL.PROPERTY_SEARCH, true);
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private bool isViewMode()
    {
        return PageMode.VIEW.ToString().Equals(pageModeHdn.Value);
    }
    private bool isAddMode()
    {
        return PageMode.ADD.ToString().Equals(pageModeHdn.Value);
    }
    private bool isModifyMode()
    {
        return PageMode.MODIFY.ToString().Equals(pageModeHdn.Value);
    }
    private PropertyDetailPageDTO getSessionPageData()
    {
        return (PropertyDetailPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    protected void addOrModifyProperty(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyAddOrModify())
            {
                PropertyDTO propertyDTO = getSessionPageData().PropertyDTO;
                populatePropertyDTOFromUI(propertyDTO);
                long Id = propertyDTO.Id;
                if (isAddMode())
                {
                    Id = propertyBO.saveProperty(propertyDTO);
                    List<FirmMemberDTO> firmMemberList = new List<FirmMemberDTO>();
                    firmMemberList.Add(getUserDefinitionDTO().FirmMember);
                    propertyUserBO.updatePropertyAccess(Id, firmMemberList, PrFMAccess.Yes);
                    UserDefinitionDTO userDef = getUserDefinitionDTO();
                    userDef.AssignedProperties = new List<PropertyDTO>();
                    userDef.AssignedProperties.AddRange(loginBO.getAssignedProperties(userDef.FirmMember.Id));
                    userDef.AssignedProperties.ForEach(x => x.isUISelected = (x.Id == Id));
                    Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg(CommonUtil.getRecordAddSuccessMsg("Property")));
                }
                else if (isModifyMode())
                {
                    propertyBO.updateProperty(propertyDTO);
                    Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg(CommonUtil.getRecordModifySuccessMsg("Property")));
                }
                navigateToPreviousPage();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addModifyStep1Error);
        }
    }
    protected void onClickModifyPropertyBtn(object sender, EventArgs e)
    {
        try
        {
            PropertyDetailPageDTO PageDTO = getSessionPageData();
            PropertyDTO propertyDTO = PageDTO.PropertyDTO;
            PropertyDetailNavDTO navDTO = new PropertyDetailNavDTO();
            navDTO.Mode = PageMode.MODIFY;
            navDTO.PropertyId = propertyDTO.Id;
            navDTO.PrevNavDto = PageDTO.PrevNavDTO;
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.PROPERTY_DETAILS, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelProperty(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void goToStep(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            string stepToJump = rd.Attributes["data-step"];
            List<string> stepsToValidate = CommonUtil.getStepsToValidate(activeStepHdn.Value, stepToJump);
            bool isValid = true;
            foreach (string step in stepsToValidate)
            {
                if (!validateGoToStep(step))
                {
                    isValid = false;
                    break;
                }
            }
            if (isValid)
            {
                setCurrentStep(stepToJump);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    /**
     * Define all validation which will be done before add or Modify property.
     * */
    private bool validatePropertyAddOrModify()
    {
        return validateStep1();
    }
    private bool validateGoToStep(string jumpTo)
    {
        bool isValid = true;
        if (!isViewMode())
        {
            if (jumpTo.Equals(step1))
            {
                isValid = validateStep1();
            }
            else if (jumpTo.Equals(step2))
            {
                isValid = validateStep2();
            }
        }
        return isValid;
    }
    private bool validateStep1()
    {
        bool isValid = validateMandatoryFields(addModifyStep1Error, step1);
        PropertyDTO propertyDTO = getSessionPageData().PropertyDTO;
        if (isAddMode() && isValid && propertyBO.validatePropertyExist(getUserDefinitionDTO().FirmNumber, txtPropertyName.Text.TrimNullable()))
        {
            setErrorMessage("Property with same already exist.", addModifyStep1Error);
        	isValid = false;
        }
        if (isValid && (propertyDTO.PropertyTowers == null || propertyDTO.PropertyTowers.Count == 0))
        {
            setErrorMessage(Resources.Messages.ATLEAST_ONE_TOWER_REQUIRED, addModifyStep1Error);
            isValid = false;
        }
        if (!isValid)
        {
            activeStepHdn.Value = step1;
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    private bool validateStep2()
    {
        return true;
    }
    private bool validateMandatoryFields(string valGrp, string step)
    {
        Page.Validate(valGrp);
        bool isValid = Page.IsValid;
        if (!isValid)
        {
        	(this.Master as CSMaster).setPageErrorInNotyMsg(Page.Validators);
            if (!string.IsNullOrWhiteSpace(step)) setCurrentStep(step);
        }
        return isValid;
    }
    private void setCurrentStep(string step)
    {
        activeStepHdn.Value = step;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    protected void loadAddressCities(object sender, EventArgs e)
    {
        try
        {
            initCityDrp(drpAddressCity, drpAddressState.Text);
            SetFocus(drpAddressCity);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private PropertyDTO populatePropertyDTOAdd()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        PropertyDTO propertyDTO = new PropertyDTO();
        propertyDTO.ContactInfo = new ContactInfoDTO();
        propertyDTO.ContactInfo.Contact = "0";
        propertyDTO.ContactInfo.Addresses = new HashSet<AddressDTO>();
        AddressDTO addressDto = new AddressDTO();
        addressDto.PreferredAddress = PreferredAddress.Yes;
        addressDto.AddressType = masterDataBO.getAnyAddressType(userDefDto.FirmNumber);
        propertyDTO.ContactInfo.Addresses.Add(addressDto);
        propertyDTO.PropertyTowers = new HashSet<PropertyTowerDTO>();
        propertyDTO.PropertyTaxDetails = new HashSet<PropertyTaxDetailDTO>();
        propertyDTO.PropertyCharges = new HashSet<PropertyChargeDTO>();
        propertyDTO.FirmNumber = userDefDto.FirmNumber;
        propertyDTO.InsertUser = userDefDto.Username;
        return propertyDTO;
    }
    private void populatePropertyDTOFromUI(PropertyDTO propertyDTO)
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        if (isAddMode()) propertyDTO.Name = txtPropertyName.Text.TrimNullable();
        propertyDTO.PropertyType = CommonUIConverter.getMasterControlDTO(drpPropertytype.Text, null);
        propertyDTO.PropertyLocation = CommonUIConverter.getMasterControlDTO(drpPropertyLocation.Text, null);
        propertyDTO.PropertyArea = CommonUtil.getDecimalWithoutExt(txtPropertyArea.Text);
        propertyDTO.EstimatedAmt = CommonUtil.getDecimalWithoutExt(txtTotalEstimation.Text);
        propertyDTO.ReraRegNo = txtReraNo.Text.TrimNullable();
        propertyDTO.FirmAccount = CommonUIConverter.getFirmAccountDTO(drpAccount.Text, null);
        AddressDTO addressDto = propertyDTO.ContactInfo.Addresses.First();
        addressDto.AddressLine1 = txtAddressLine1.Text.TrimNullable();
        addressDto.AddressLine2 = txtAddressLine2.Text.TrimNullable();
        addressDto.Town = txtTown.Text.TrimNullable();
        addressDto.City = CommonUIConverter.getCityDTO(drpAddressCity.Text, null);
        addressDto.State = CommonUIConverter.getStateDTO(drpAddressState.Text, null);
        addressDto.Country = CommonUIConverter.getCountryDTO(drpAddressCountry.Text, null);
        addressDto.Pin = txtPin.Text.TrimNullable();
        propertyDTO.UpdateUser = userDefDto.Username;
    }
    private void populateUIFieldsFromDTO(PropertyDTO propertyDTO)
    {
        if (propertyDTO != null) txtPropertyName.Text = propertyDTO.Name; else txtPropertyName.Text = null;
        if (propertyDTO != null && propertyDTO.PropertyType != null) drpPropertytype.Text = propertyDTO.PropertyType.Id.ToString(); else drpPropertytype.ClearSelection();
        if (propertyDTO != null && propertyDTO.PropertyLocation != null) drpPropertyLocation.Text = propertyDTO.PropertyLocation.Id.ToString(); else drpPropertyLocation.ClearSelection();
        if (propertyDTO != null && propertyDTO.PropertyArea != null) txtPropertyArea.Text = propertyDTO.PropertyArea.ToString(); else txtPropertyArea.Text = null;
        if (propertyDTO != null && propertyDTO.EstimatedAmt != null) txtTotalEstimation.Text = propertyDTO.EstimatedAmt.ToString(); else txtTotalEstimation.Text = null;
        if (propertyDTO != null && propertyDTO.FirmAccount != null) drpAccount.Text = propertyDTO.FirmAccount.Id.ToString(); else drpAccount.ClearSelection();
        if (propertyDTO != null && propertyDTO.ReraRegNo != null) txtReraNo.Text = propertyDTO.ReraRegNo.ToString(); else txtReraNo.Text=null;
        txtAddressLine1.Text = null;
        txtAddressLine2.Text = null;
        txtTown.Text = null;
        drpAddressCountry.ClearSelection();
        drpAddressState.ClearSelection();
        drpAddressCity.ClearSelection();
        txtPin.Text = null;
        if (propertyDTO != null)
        {
            ISet<AddressDTO> addresses = propertyDTO.ContactInfo.Addresses;
            if (addresses.Count > 0)
            {
                foreach (AddressDTO addressDto in addresses)
                {
                    txtAddressLine1.Text = addressDto.AddressLine1;
                    txtAddressLine2.Text = addressDto.AddressLine2;
                    txtTown.Text = addressDto.Town;
                    drpAddressCountry.Text = addressDto.Country.Id.ToString();
                    drpAddressState.Text = addressDto.State.Id.ToString();
                    initCityDrp(drpAddressCity, drpAddressState.Text);
                    drpAddressCity.Text = addressDto.City.Id.ToString();
                    txtPin.Text = addressDto.Pin;
                }
            }
        }
        populatePropertyTowerGrid(propertyDTO);
        populateTaxDetailGrid(propertyDTO);
        populateChargesDetailGrid(propertyDTO);
    }
    private void populatePropertyTowerGrid(PropertyDTO propertyDTO)
    {
        propertyTowerGrid.DataSource = new List<PropertyTowerDTO>();
        if (propertyDTO != null)
        {
            assignUiIndexToPropertyTower(propertyDTO.PropertyTowers);
            propertyTowerGrid.DataSource = propertyDTO.PropertyTowers;
        }
        propertyTowerGrid.DataBind();
    }
    private void assignUiIndexToPropertyTower(ISet<PropertyTowerDTO> propertyTowerDtos)
    {
        if (propertyTowerDtos != null && propertyTowerDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (PropertyTowerDTO propertyTower in propertyTowerDtos)
            {
                propertyTower.UiIndex = uiIndex++;
                propertyTower.RowInfo = CommonUIConverter.getGridViewRowInfo(propertyTower);
            }
        }
    }
    private void populateTaxDetailGrid(PropertyDTO propertyDTO)
    {
        taxDetailGrid.DataSource = new List<PropertyTaxDetailDTO>();
        if (propertyDTO != null)
        {
            assignUiIndexToTaxDetail(propertyDTO.PropertyTaxDetails);
            taxDetailGrid.DataSource = propertyDTO.PropertyTaxDetails;
        }
        taxDetailGrid.DataBind();
    }

    private void populateChargesDetailGrid(PropertyDTO propertyDTO)
    {
        propertyChargesGrid.DataSource = new List<PropertyChargeDTO>();
        if (propertyDTO != null)
        {
            assignUiIndexToChargesDetail(propertyDTO.PropertyCharges);
            propertyChargesGrid.DataSource = propertyDTO.PropertyCharges;
        }
        propertyChargesGrid.DataBind();
    }

    private void assignUiIndexToTaxDetail(ISet<PropertyTaxDetailDTO> taxDetailDtos)
    {
        if (taxDetailDtos != null && taxDetailDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (PropertyTaxDetailDTO taxDetailDto in taxDetailDtos)
            {
                taxDetailDto.UiIndex = uiIndex++;
                taxDetailDto.RowInfo = CommonUIConverter.getGridViewRowInfo(taxDetailDto);
            }
        }
    }
    private void assignUiIndexToChargesDetail(ISet<PropertyChargeDTO> chargesDetailDtos)
    {
        if (chargesDetailDtos != null && chargesDetailDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (PropertyChargeDTO chargeDetailDto in chargesDetailDtos)
            {
                chargeDetailDto.UiIndex = uiIndex++;
                chargeDetailDto.RowInfo = CommonUIConverter.getGridViewRowInfo(chargeDetailDto);
            }
        }
    }
    //Master Data Modal save logic - Start
    protected void saveMasterData(object sender, EventArgs e)
    {
        try
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (MasterDataType.PROPERTY_TYPE.ToString().Equals(masterDataModalTypeHdn.Value))
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(MasterDataType.PROPERTY_TYPE.ToString(), txtMasterDataInput1.Text.TrimNullable(),
                       txtMasterDataInput2.Text.TrimNullable(), userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Property Type");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpPropertytype, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.PROPERTY_TYPE.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
            }
            else if (MasterDataType.PROPERTY_LOCATION.ToString().Equals(masterDataModalTypeHdn.Value))
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(MasterDataType.PROPERTY_LOCATION.ToString(), txtMasterDataInput1.Text.TrimNullable(),
                       txtMasterDataInput2.Text.TrimNullable(), userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Property Location");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpPropertyLocation, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.PROPERTY_LOCATION.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
            }
            else if (MasterDataType.PR_TAX_TYPE.ToString().Equals(masterDataModalTypeHdn.Value))
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(MasterDataType.PR_TAX_TYPE.ToString(), txtMasterDataInput1.Text.TrimNullable(),
                       txtMasterDataInput2.Text.TrimNullable(), userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Tax Type");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpTaxType, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.PR_TAX_TYPE.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
            }
            else if (MasterDataType.PROPERTY_CHARGES.ToString().Equals(masterDataModalTypeHdn.Value))
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(MasterDataType.PROPERTY_CHARGES.ToString(), txtMasterDataInput1.Text.TrimNullable(),
                       txtMasterDataInput2.Text.TrimNullable(), userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Property Charge Name");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpPropertyChargesType, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.PROPERTY_CHARGES.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
            }

            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                activeModalHdn.Value = addMasterDataModal;
                SetFocus(txtMasterDataInput2);
                setErrorMessage(errorMsg, addMasterDataError);
            }
            else
            {
                resetMasterDataModalFields();
                setParentModalFlag();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            activeModalHdn.Value = "";
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    protected void cancelMasterDataModal(object sender, EventArgs e)
    {
        try
        {
            resetMasterDataModalFields();
            setParentModalFlag();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    private void resetMasterDataModalFields()
    {
        txtMasterDataInput1.Text = "";
        txtMasterDataInput2.Text = "";
        masterDataModalTypeHdn.Value = "";
    }
    private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
    {
        string errorMsg = "";
        if (string.IsNullOrWhiteSpace(masterDataDto.Name))
        {
            errorMsg = string.Format(Resources.Messages.TEXTFIELD_REQUIRED, type);
        }
        else if (masterDataBO.isAlreadyExist(masterDataDto))
        {
            errorMsg = string.Format(Resources.Messages.ALREADY_EXIST_DB_ERROR, type);
        }
        return errorMsg;
    }
    private void setParentModalFlag()
    {
        activeModalHdn.Value = masterDataParentModalHdn.Value;
        masterDataParentModalHdn.Value = "";
    }
    //Master Data Modal save logic - End
    //Property Tower Modal - start
    private void initPropertyTowerModalFields()
    {
        lbPrTowerModalTitle.Text = (PrTowerAction.ADD.ToString().Equals(prTowerModalActionHdnBtn.Value))
            ? Constants.ICON.ADD + Resources.Labels.ADD_TOWER : Constants.ICON.MODIFY + Resources.Labels.MODIFY_TOWER;
    }
    private void initPropertyTowerSectionFields(PropertyTowerDTO propertyTowerDto)
    {
        if (propertyTowerDto != null) txtTowerName.Text = propertyTowerDto.Name; else txtTowerName.Text = null;
        if (propertyTowerDto != null) txtTowerLaunchDate.Text = DateUtil.getCSDate(propertyTowerDto.LaunchDate); else txtTowerLaunchDate.Text = null;
        if (propertyTowerDto != null && propertyTowerDto.Rate != null) txtTowerRate.Text = propertyTowerDto.Rate.ToString(); else txtTowerRate.Text = null;
        if (propertyTowerDto != null) txtTowerDescription.Text = propertyTowerDto.Description; else txtTowerDescription.Text = null;
        if (propertyTowerDto != null) txtTowerPossession.Text = DateUtil.getCSDate(propertyTowerDto.Possession); else txtTowerPossession.Text = null;
    }
    private void populatePropertyTowerFromUI(PropertyTowerDTO propertyTowerDto)
    {
        propertyTowerDto.Name = txtTowerName.Text.TrimNullable();
        propertyTowerDto.LaunchDate = DateUtil.getCSDate(txtTowerLaunchDate.Text);
        propertyTowerDto.Rate = CommonUtil.getDecimalWithoutExt(txtTowerRate.Text);
        propertyTowerDto.Possession = DateUtil.getCSDate(txtTowerPossession.Text);
        propertyTowerDto.Description = txtTowerDescription.Text.TrimNullable();
        propertyTowerDto.UpdateUser = getUserDefinitionDTO().Username;
    }
    private PropertyTowerDTO populatePropertyTowerAdd()
    {
        PropertyTowerDTO propertyTowerDto = new PropertyTowerDTO();
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        propertyTowerDto.FirmNumber = userDef.FirmNumber;
        propertyTowerDto.InsertUser = userDef.Username;
        return propertyTowerDto;
    }
    private void setSelectedPrTower(long UiIndex)
    {
        List<PropertyTowerDTO> towerList = getSessionPageData().PropertyDTO.PropertyTowers.ToList<PropertyTowerDTO>();
        towerList.ForEach(c => c.isUISelected = false);
        if (UiIndex > 0) towerList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
    }
    private PropertyTowerDTO getSelectedPrTower(long UiIndex)
    {
        List<PropertyTowerDTO> towerList = getSessionPageData().PropertyDTO.PropertyTowers.ToList<PropertyTowerDTO>();
        return (UiIndex > 0) ? towerList.Find(c => c.UiIndex == UiIndex) : towerList.Find(c => c.isUISelected);
    }
    protected void onClickAddPrTowerBtn(object sender, EventArgs e)
    {
        try
        {
            prTowerModalActionHdnBtn.Value = PrTowerAction.ADD.ToString();
            initPropertyTowerModalFields();
            setSelectedPrTower(-1);
            initPropertyTowerSectionFields(null);
            activeModalHdn.Value = addModifyPrTowerModal;
            SetFocus(txtTowerName);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyPrTowerBtn(object sender, EventArgs e)
    {
        try
        {
            prTowerModalActionHdnBtn.Value = PrTowerAction.MODIFY.ToString();
            initPropertyTowerModalFields();
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedPrTower(selectedIndex);
            initPropertyTowerSectionFields(getSelectedPrTower(0));
            activeModalHdn.Value = addModifyPrTowerModal;
            SetFocus(txtTowerName);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void deletePrTower(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            PropertyTowerDTO propertyTowerDto = getSelectedPrTower(selectedIndex);
            PropertyDTO propertyDTO = getSessionPageData().PropertyDTO;
            propertyDTO.PropertyTowers.Remove(propertyTowerDto);
            populatePropertyTowerGrid(propertyDTO);
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_DELETED_FROM_TABLE, "Property Tower")));
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void savePrTower(object sender, EventArgs e)
    {
        try
        {
            if (validatePrTowerAddModify())
            {
                PropertyTowerDTO propertyTowerDto = null;
                PropertyDTO propertyDTO = getSessionPageData().PropertyDTO;
                if (PrTowerAction.ADD.ToString().Equals(prTowerModalActionHdnBtn.Value))
                {
                    propertyTowerDto = populatePropertyTowerAdd();
                    propertyDTO.PropertyTowers.Add(propertyTowerDto);
                    (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_ADDED_TO_TABLE, "Property Tower")));
                }
                else
                {
                    propertyTowerDto = getSelectedPrTower(0);
                    (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_MODIFIED_TO_TABLE, "Property Tower")));
                }
                populatePropertyTowerFromUI(propertyTowerDto);
                populatePropertyTowerGrid(propertyDTO);
            }
            else
            {
                activeModalHdn.Value = addModifyPrTowerModal;
                SetFocus(txtTowerName);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelPrTowerModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validatePrTowerAddModify()
    {
        Page.Validate(addModifyPrTowerError);
        return Page.IsValid;
    }
    //Property Tower Modal - End
    //Tax Details Modal - Start
    private void initTaxDetailModalFields()
    {
        lbTaxDetailModalTitle.Text = (TaxDetailAction.ADD.ToString().Equals(taxDetailModalActionHdnBtn.Value))
            ? Constants.ICON.ADD + Resources.Labels.ADD_TAX : Constants.ICON.MODIFY + Resources.Labels.MODIFY_TAX;
    }
    private void initTaxDetailSectionFields(PropertyTaxDetailDTO taxDetailDto)
    {
        if (taxDetailDto != null) drpTaxType.Text = taxDetailDto.TaxType.Id.ToString(); else drpTaxType.ClearSelection();
        if (taxDetailDto != null) txtTaxRate.Text = taxDetailDto.TaxPercentage.ToString(); else txtTaxRate.Text = null;
        if (taxDetailDto != null) txtTaxLimit.Text = taxDetailDto.TaxAmtLimit.ToString(); else txtTaxLimit.Text = null;
        if (taxDetailDto != null) drpTaxIncludeInPymt.Text = taxDetailDto.IncludeInTotalPymt.ToString(); else drpTaxIncludeInPymt.ClearSelection();
    }
    private void populateTaxDetailFromUI(PropertyTaxDetailDTO taxDetailDto)
    {
        taxDetailDto.TaxType = CommonUIConverter.getMasterControlDTO(drpTaxType.Text, drpTaxType.SelectedItem.Text);
        taxDetailDto.TaxPercentage = CommonUtil.getDecimaNotNulllWithoutExt(txtTaxRate.Text);
        taxDetailDto.TaxAmtLimit = CommonUtil.getDecimaNotNulllWithoutExt(txtTaxLimit.Text);
        taxDetailDto.IncludeInTotalPymt = EnumHelper.ToEnum<IncludeInPymtTotal>(drpTaxIncludeInPymt.Text);
        taxDetailDto.UpdateUser = getUserDefinitionDTO().Username;
    }
    private PropertyTaxDetailDTO populatePropertyTaxDetailAdd()
    {
        PropertyTaxDetailDTO taxDetailDto = new PropertyTaxDetailDTO();
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        taxDetailDto.FirmNumber = userDef.FirmNumber;
        taxDetailDto.InsertUser = userDef.Username;
        return taxDetailDto;
    }
    private void setSelectedTaxDetail(long UiIndex)
    {
        List<PropertyTaxDetailDTO> taxDetailList = getSessionPageData().PropertyDTO.PropertyTaxDetails.ToList<PropertyTaxDetailDTO>();
        taxDetailList.ForEach(c => c.isUISelected = false);
        if (UiIndex > 0) taxDetailList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
    }
    private PropertyTaxDetailDTO getSelectedTaxDetail(long UiIndex)
    {
        List<PropertyTaxDetailDTO> taxDetailList = getSessionPageData().PropertyDTO.PropertyTaxDetails.ToList<PropertyTaxDetailDTO>();
        return (UiIndex > 0) ? taxDetailList.Find(c => c.UiIndex == UiIndex) : taxDetailList.Find(c => c.isUISelected);
    }
    protected void onClickAddTaxDetailBtn(object sender, EventArgs e)
    {
        try
        {
            taxDetailModalActionHdnBtn.Value = TaxDetailAction.ADD.ToString();
            initTaxDetailModalFields();
            setSelectedTaxDetail(-1);
            initTaxDetailSectionFields(null);
            activeModalHdn.Value = addModifyTaxDetailModal;
            SetFocus(drpTaxType);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyTaxDetailBtn(object sender, EventArgs e)
    {
        try
        {
            taxDetailModalActionHdnBtn.Value = TaxDetailAction.MODIFY.ToString();
            initTaxDetailModalFields();
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedTaxDetail(selectedIndex);
            initTaxDetailSectionFields(getSelectedTaxDetail(0));
            activeModalHdn.Value = addModifyTaxDetailModal;
            SetFocus(drpTaxType);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void deleteTaxDetail(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            PropertyTaxDetailDTO taxDetailDTO = getSelectedTaxDetail(selectedIndex);
            PropertyDTO propertyDTO = getSessionPageData().PropertyDTO;
            propertyDTO.PropertyTaxDetails.Remove(taxDetailDTO);
            populateTaxDetailGrid(propertyDTO);
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_DELETED_FROM_TABLE, "Tax Detail")));
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void saveTaxDetail(object sender, EventArgs e)
    {
        try
        {
            if (validateTaxDetailAddModify())
            {
                PropertyTaxDetailDTO taxDetailDTO = null;
                PropertyDTO propertyDTO = getSessionPageData().PropertyDTO;
                if (TaxDetailAction.ADD.ToString().Equals(taxDetailModalActionHdnBtn.Value))
                {
                    taxDetailDTO = populatePropertyTaxDetailAdd();
                    propertyDTO.PropertyTaxDetails.Add(taxDetailDTO);
                    (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_ADDED_TO_TABLE, "Tax Detail")));
                }
                else
                {
                    taxDetailDTO = getSelectedTaxDetail(0);
                    (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_MODIFIED_TO_TABLE, "Tax Detail")));
                }
                populateTaxDetailFromUI(taxDetailDTO);
                populateTaxDetailGrid(propertyDTO);
            }
            else
            {
                activeModalHdn.Value = addModifyTaxDetailModal;
                SetFocus(drpTaxType);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelTaxDetailModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateTaxDetailAddModify()
    {
        Page.Validate(addModifyTaxDetailError);
        return Page.IsValid;
    }
    //Tax Details Modal - End
    //Property Charges Modal - Start
    private void initPropertyChargeModalFields()
    {
        lbPropertyChargeModalTitle.Text = (PropertyChargeAction.ADD.ToString().Equals(propertyChargeModalActionHdnBtn.Value))
            ? Constants.ICON.ADD + Resources.Labels.ADD_CHARGE : Constants.ICON.MODIFY + Resources.Labels.MODIFY_CHARGE;
    }
    private void initPropertyChargeSectionFields(PropertyChargeDTO propertyChargeDto)
    {
        if (propertyChargeDto != null) drpPropertyChargesType.Text = propertyChargeDto.ChargeType.Id.ToString(); else drpPropertyChargesType.ClearSelection();
        if (propertyChargeDto != null) txtChargesValue.Text = propertyChargeDto.ChargeValue.ToString(); else txtChargesValue.Text = null;
    }
    private void populatePropertyChargeFromUI(PropertyChargeDTO propertyChargeDto)
    {
        propertyChargeDto.ChargeType = CommonUIConverter.getMasterControlDTO(drpPropertyChargesType.Text, drpPropertyChargesType.SelectedItem.Text);
        propertyChargeDto.ChargeValue = CommonUtil.getDecimaNotNulllWithoutExt(txtChargesValue.Text);
        propertyChargeDto.UpdateUser = getUserDefinitionDTO().Username;
    }
    private PropertyChargeDTO populatePropertyChargeAdd()
    {
        PropertyChargeDTO propertyChargeDto = new PropertyChargeDTO();
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        propertyChargeDto.FirmNumber = userDef.FirmNumber;
        propertyChargeDto.InsertUser = userDef.Username;
        return propertyChargeDto;
    }
    private void setSelectedPropertyCharge(long UiIndex)
    {
        List<PropertyChargeDTO> propertyChargeList = getSessionPageData().PropertyDTO.PropertyCharges.ToList<PropertyChargeDTO>();
        propertyChargeList.ForEach(c => c.isUISelected = false);
        if (UiIndex > 0) propertyChargeList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
    }
    private PropertyChargeDTO getSelectedPropertyCharge(long UiIndex)
    {
        List<PropertyChargeDTO> propertyChargeList = getSessionPageData().PropertyDTO.PropertyCharges.ToList<PropertyChargeDTO>();
        return (UiIndex > 0) ? propertyChargeList.Find(c => c.UiIndex == UiIndex) : propertyChargeList.Find(c => c.isUISelected);
    }
    protected void onClickAddPropertyChargeBtn(object sender, EventArgs e)
    {
        try
        {
            propertyChargeModalActionHdnBtn.Value = PropertyChargeAction.ADD.ToString();
            initPropertyChargeModalFields();
            setSelectedPropertyCharge(-1);
            initPropertyChargeSectionFields(null);
            activeModalHdn.Value = addModifyPropertyChargeModal;
            SetFocus(txtChargesValue);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyPropertyChargeBtn(object sender, EventArgs e)
    {
        try
        {
            propertyChargeModalActionHdnBtn.Value = PropertyChargeAction.MODIFY.ToString();
            initPropertyChargeModalFields();
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedPropertyCharge(selectedIndex);
            initPropertyChargeSectionFields(getSelectedPropertyCharge(0));
            activeModalHdn.Value = addModifyPropertyChargeModal;
            SetFocus(txtChargesValue);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void deletePropertyCharge(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            PropertyChargeDTO propertyChargeDTO = getSelectedPropertyCharge(selectedIndex);
            PropertyDTO propertyDTO = getSessionPageData().PropertyDTO;
            propertyDTO.PropertyCharges.Remove(propertyChargeDTO);
            populateChargesDetailGrid(propertyDTO);
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_DELETED_FROM_TABLE, "Property Charge")));
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void savePropertyCharge(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyChargeAddModify())
            {
                PropertyChargeDTO propertyChargeDTO = null;
                PropertyDTO propertyDTO = getSessionPageData().PropertyDTO;
                if (PropertyChargeAction.ADD.ToString().Equals(propertyChargeModalActionHdnBtn.Value))
                {
                    propertyChargeDTO = populatePropertyChargeAdd();
                    propertyDTO.PropertyCharges.Add(propertyChargeDTO);
                    (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_ADDED_TO_TABLE, "Property Charge")));
                }
                else
                {
                    propertyChargeDTO = getSelectedPropertyCharge(0);
                    (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_MODIFIED_TO_TABLE, "Property Charge")));
                }
                populatePropertyChargeFromUI(propertyChargeDTO);
                populateChargesDetailGrid(propertyDTO);
            }
            else
            {
                activeModalHdn.Value = addModifyPropertyChargeModal;
                SetFocus(txtChargesValue);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelPropertyChargeModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validatePropertyChargeAddModify()
    {
        Page.Validate(addModifyPropertyChargeError);
        return Page.IsValid;
    }
    //Property Charges Modal - End
    //Add Account Modal - Start
    private void initAccountModalFields()
    {
        lbAccountModalTitle.Text = (AccountAction.ADD.ToString().Equals(accountModalActionHdnBtn.Value)) ? Constants.ICON.ADD + Resources.Labels.ADD_ACCOUNT : "";
    }
    private void initAccountSectionFields(FirmAccountDTO accountDto)
    {
        if (accountDto != null) txtAcntName.Text = accountDto.Name; else txtAcntName.Text = null;
        if (accountDto != null) drpAcntType.Text = accountDto.AccountType.Id.ToString(); else drpAcntType.ClearSelection();
        if (accountDto != null) txtAcntNumber.Text = accountDto.AccountNo; else txtAcntNumber.Text = null;
        if (accountDto != null) txtAcntIFSCCode.Text = accountDto.IfscCode; else txtAcntIFSCCode.Text = null;
        if (accountDto != null) txtAcntBankName.Text = accountDto.BankName; else txtAcntBankName.Text = null;
        if (accountDto != null) txtAcntBranch.Text = accountDto.Branch; else txtAcntBranch.Text = null;
        if (accountDto != null && accountDto.City != null) drpAcntCity.Text = accountDto.City.Id.ToString(); else drpAcntCity.ClearSelection();
        if (accountDto != null && accountDto.State != null) drpAcntState.Text = accountDto.State.Id.ToString(); else drpAcntState.ClearSelection();
        if (accountDto != null && accountDto.Country != null) drpAcntCountry.Text = accountDto.Country.Id.ToString(); else drpAcntCountry.ClearSelection();
        drpAcntState.Text = Constants.DEFAULT_STATE;
        initCityDrp(drpAcntCity, Constants.DEFAULT_STATE);
    }
    private void populateAccountFromUI(FirmAccountDTO accountDto)
    {
        accountDto.Name = txtAcntName.Text.TrimNullable();
        accountDto.AccountType = CommonUIConverter.getMasterControlDTO(drpAcntType.Text, drpAcntType.SelectedItem.Text);
        accountDto.AccountNo = txtAcntNumber.Text.TrimNullable();
        accountDto.IfscCode = txtAcntIFSCCode.Text.TrimNullable();
        accountDto.BankName = txtAcntBankName.Text.TrimNullable();
        accountDto.Branch = txtAcntBranch.Text.TrimNullable();
        accountDto.City = CommonUIConverter.getCityDTO(drpAcntCity.Text, drpAcntCity.SelectedItem.Text);
        accountDto.State = CommonUIConverter.getStateDTO(drpAcntState.Text, drpAcntState.SelectedItem.Text);
        accountDto.Country = CommonUIConverter.getCountryDTO(drpAcntCountry.Text, drpAcntCountry.SelectedItem.Text);
        accountDto.UpdateUser = getUserDefinitionDTO().Username;
    }
    private FirmAccountDTO populateAccountAdd()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        FirmAccountDTO accountDto = new FirmAccountDTO();
        populateAccountFromUI(accountDto);
        accountDto.FirmNumber = userDefDto.FirmNumber;
        accountDto.InsertUser = userDefDto.Username;
        return accountDto;
    }
    protected void onClickAddAccountBtn(object sender, EventArgs e)
    {
        try
        {
            accountModalActionHdnBtn.Value = AccountAction.ADD.ToString();
            initAccountModalFields();
            initAccountSectionFields(null);
            activeModalHdn.Value = addAccountModal;
            SetFocus(txtAcntName);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void addNewAccount(object sender, EventArgs e)
    {
        try
        {
            if (validateAccountAdd())
            {
                FirmAccountDTO accountDTO = populateAccountAdd();
                firmBO.saveFirmAccount(accountDTO);
                drpBO.drpDataBase(drpAccount, DrpDataType.FIRM_ACCOUNT, null, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECORD_ADDED_DB_SUCCESS, "Account")));
            }
            else
            {
                activeModalHdn.Value = addAccountModal;
                SetFocus(txtAcntName);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelAccountModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void loadAcntCities(object sender, EventArgs e)
    {
        try
        {
            initCityDrp(drpAcntCity, drpAcntState.Text);
            activeModalHdn.Value = addAccountModal;
            SetFocus(drpAcntCity);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateAccountAdd()
    {
        Page.Validate(addAccountError);
        return Page.IsValid;
    }
    //Add Account Modal - End
}