﻿using System;
using NHibernate;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using ConstroSoft;
using System.Collections.Generic;
using NHibernate.Criterion;
using NHibernate.Transform;
using System.Web.Hosting;
using System.Net;
using System.Web;

/// <summary>
/// Summary description for DocumentBO
/// </summary>
namespace ConstroSoft
{
    public class DocumentBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public DocumentBO() { }
        public List<FileUIDTO> fetchFileList(string sourcePath)
        {
            List<FileUIDTO> results = new List<FileUIDTO>();
            try
            {
                DirectoryInfo dir = new DirectoryInfo(HostingEnvironment.MapPath(sourcePath));
                FileSystemInfo[] filesAndDirs = dir.GetFileSystemInfos("*");
                foreach (FileSystemInfo foundFile in filesAndDirs)
                {
                    results.Add(createFileUIDTO(foundFile));
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error retriving file list:" ,exp);
                throw new Exception(Resources.Messages.system_error);
            }
            finally
            {

            }
            return results;
        }
        private FileUIDTO createFileUIDTO(FileSystemInfo foundFile)
        {
            FileUIDTO FileUIDTO = new FileUIDTO();
            if (foundFile.GetType() == typeof(FileInfo))
            {
                FileInfo fileInfo = (FileInfo)foundFile;
                FileUIDTO.FullPath = CommonUtil.getVirtualPath(fileInfo.FullName);
                FileUIDTO.ParentPath = CommonUtil.getVirtualPath(fileInfo.DirectoryName);
                FileUIDTO.Name = fileInfo.Name;
                FileUIDTO.size = fileInfo.Length.ToSize(SizeUnits.KB);
                FileUIDTO.CreateDate = fileInfo.CreationTime;
                FileUIDTO.DocumentType = "Document";
                FileUIDTO.FileType = FileType.File;
            }
            else
            {
                DirectoryInfo directoryInfo = (DirectoryInfo)foundFile;
                FileUIDTO.FullPath = CommonUtil.getVirtualPath(directoryInfo.FullName);
                FileUIDTO.ParentPath = CommonUtil.getVirtualPath(directoryInfo.Parent.FullName);
                FileUIDTO.Name = directoryInfo.Name;
                FileUIDTO.CreateDate = directoryInfo.CreationTime;
                FileUIDTO.DocumentType = "File Folder";
                FileUIDTO.FileType = FileType.Folder;
            }
            return FileUIDTO;
        }
        public FileUIDTO fetchFolderInfo(string sourcePath)
        {
            FileUIDTO folderInfo = new FileUIDTO();
            try
            {
                DirectoryInfo dir = new DirectoryInfo(HostingEnvironment.MapPath(sourcePath));
                folderInfo.FullPath = CommonUtil.getVirtualPath(dir.FullName);
                folderInfo.Name = dir.Name;
                folderInfo.CreateDate = dir.CreationTime;
                folderInfo.DocumentType = "File Folder";
                folderInfo.FileType = FileType.Folder;
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error retriving Folder Info:", exp);
                throw new Exception(Resources.Messages.system_error);
            }
            finally
            {

            }
            return folderInfo;
        }
        public string getProfileImagePath(string userProfileImageFolder)
        {
            string imgPath = "";
            try
            {
                DirectoryInfo dir = new DirectoryInfo(HostingEnvironment.MapPath(userProfileImageFolder));
                if (dir.Exists)
                {
                    FileSystemInfo[] filesAndDirs = dir.GetFileSystemInfos("*");
                    foreach (FileSystemInfo foundFile in filesAndDirs)
                    {
                         if (foundFile.GetType() == typeof(FileInfo))
                        {
                            FileInfo image = (FileInfo)foundFile;
                            imgPath = image.FullName;
                            break;
                        }
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while fetching profile image path:", exp);
            }
            finally
            {

            }
            return imgPath;
        }
        public void createFolderIfNotExist(string fullPath)
        {
            try
            {
                DirectoryInfo dir = new DirectoryInfo(HostingEnvironment.MapPath(fullPath));
                if (!dir.Exists)
                {
                    Directory.CreateDirectory(HostingEnvironment.MapPath(fullPath));
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error creating folder if not exist:", exp);
                throw new Exception(Resources.Messages.system_error);
            }
            finally
            {

            }
        }
        public void saveDocument(HttpPostedFile file, string fullPath)
        {
            try
            {
                file.SaveAs(HostingEnvironment.MapPath(fullPath));
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error creating file:", exp);
                throw new Exception(Resources.Messages.system_error);
            }
            finally
            {

            }
        }
        public byte[] downloadFile(string filePath)
        {
            byte[] data = null;
            try
            {
                FileInfo file = new FileInfo(HostingEnvironment.MapPath(filePath));
                if (file.Exists)
                {
                	WebClient req = new WebClient();
                    data = req.DownloadData(HostingEnvironment.MapPath(filePath));
                } else {
                	log.Error("Demand letter not found for download. File: "+ filePath);
                	throw new CustomException("Requested demand letter not found.");
                }
            }
            catch (CustomException e)
            {
                throw e;
            }  
            catch (Exception exp)
            {
                log.Error("Unexpected error creating dowloading file:", exp);
                throw new Exception(Resources.Messages.system_error);
            }
            finally
            {

            }
            return data;
        }
        public void deleteFile(FileUIDTO fileDTO)
        {
            try
            {
                if (fileDTO.FileType == FileType.Folder)
                {
                    DirectoryInfo dir = new DirectoryInfo(HostingEnvironment.MapPath(fileDTO.FullPath));
                    if (dir.Exists)
                    {
                        dir.Delete();
                    }
                }
                else
                {
                    FileInfo file = new FileInfo(HostingEnvironment.MapPath(fileDTO.FullPath));
                    if (file.Exists)
                    {
                        file.Delete();
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error deleting file:", exp);
                throw new Exception(Resources.Messages.system_error);
            }
            finally
            {

            }
        }
        public List<FileUIDTO> searchFileInDirectory(string folderPath, string searchText)
        {
            List<FileUIDTO> matchingList = new List<FileUIDTO>();
            try
            {
                getMatchingFileOrFolder(folderPath, searchText, matchingList);
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error deleting file:", exp);
                throw new Exception(Resources.Messages.system_error);
            }
            finally
            {

            }
            return matchingList;
        }
        public bool getMatchingFileOrFolder(string folderPath, string searchText, List<FileUIDTO> matchingList)
        {
            bool isFilePresent = false;
            DirectoryInfo dir = new DirectoryInfo(HostingEnvironment.MapPath(folderPath));
            FileSystemInfo[] filesAndDirs = dir.GetFileSystemInfos("*");
            foreach (FileSystemInfo foundFile in filesAndDirs)
            {
                if (foundFile.GetType() == typeof(DirectoryInfo))
                {
                    DirectoryInfo dirInfo = (DirectoryInfo)foundFile;
                    if(dirInfo.Name.ToUpper().StartsWith(searchText.ToUpper())) {
                        matchingList.Add(createFileUIDTO(foundFile));
                    }
                    getMatchingFileOrFolder(CommonUtil.getVirtualPath(foundFile.FullName), searchText, matchingList);
                }
                else if (foundFile.GetType() == typeof(FileInfo))
                {
                    FileInfo fileInfo = (FileInfo)foundFile;
                    if (fileInfo.Name.ToUpper().StartsWith(searchText.ToUpper()))
                    {
                        matchingList.Add(createFileUIDTO(foundFile));
                    }
                }
            }
            return isFilePresent;
        }
        public bool isDocumentExistInFolder(string sourcePath)
        {
            bool isFilePresent = false;
            DirectoryInfo dir = new DirectoryInfo(HostingEnvironment.MapPath(sourcePath));
            FileSystemInfo[] filesAndDirs = dir.GetFileSystemInfos("*");
            foreach (FileSystemInfo foundFile in filesAndDirs)
            {
                if (foundFile.GetType() == typeof(DirectoryInfo))
                {
                    isDocumentExistInFolder(CommonUtil.getVirtualPath(foundFile.FullName));
                }
                else if (foundFile.GetType() == typeof(FileInfo))
                {
                    isFilePresent = true;
                    break;
                }
            }
            return isFilePresent;
        }
    }
}