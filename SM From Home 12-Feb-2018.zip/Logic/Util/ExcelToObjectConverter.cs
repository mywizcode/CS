﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Web;
using OfficeOpenXml;

namespace ConstroSoft.Logic.Util
{
    [AttributeUsage(AttributeTargets.All)]
    public class Column : System.Attribute
    {
        public int ColumnIndex { get; set; }
        
        public Column(int column)
        {
            ColumnIndex = column;
        }
    }
    [Serializable]
    public class PropertyUnitMapperDTO
    {
        public PropertyUnitMapperDTO() { }
        [Column(1)]
        [Required]
        public string PropertyName { get; set; }
        [Column(2)]
        [Required]
        public string TowerName { get; set; }
        [Column(3)]
        [Required]
        public string Wing { get; set; }
        [Column(4)]
        [Required]
        public string FloorNo { get; set; }
        [Column(5)]
        [Required]
        public string UnitNo { get; set; }
        [Column(6)]
        [Required]
        public string UnitType { get; set; }
        [Column(7)]
        [Required]
        public string BuildupArea { get; set; }
        [Column(8)]
        [Required]
        public string CarpetArea { get; set; }
        [Column(9)]
        [Required]
        public string BalconyArea { get; set; }
        [Column(10)]
        [Required]
        public string NoOfBalcony { get; set; }
        [Column(11)]
        [Required]
        public string Facing { get; set; }
        [Column(12)]
        [Required]
        public string Direction { get; set; }
        [Column(13)]
        [Required]
        public string Status { get; set; }
        public int RowNumber { get; set; }
        public string RowInfo { get; set; }
        public bool IsError { get; set; }
        public string ErrorMessage { get; set; }
        public List<string> AllErrorMessage { get; set; }
    }
    [Serializable]
    public class PropertyParkingMapperDTO
    {
        public PropertyParkingMapperDTO() { }
        [Column(1)]
        [Required]
        public string PropertyName { get; set; }
        [Column(2)]
        [Required]
        public string TowerName { get; set; }
        [Column(3)]
        [Required]
        public string ParkingNumber { get; set; }
        [Column(4)]
        [Required]
        public string ParkingType { get; set; }
        [Column(5)]
        [Required]
        public string ParkingArea { get; set; }
        [Column(6)]
        [Required]
        public string CommonParking { get; set; }
        [Column(7)]
        [Required]
        public string Status { get; set; }
        public int RowNumber { get; set; }
        public string RowInfo { get; set; }
        public bool IsError { get; set; }
        public string ErrorMessage { get; set; }
        public List<string> AllErrorMessage { get; set; }
    }
    [Serializable]
    public class LeadMapperDTO
    {
        public LeadMapperDTO() { }
        [Column(1)]
        [Required]
        public string PropertyName { get; set; }
        [Column(2)]
        [Required]
        public string Salutation { get; set; }
        [Column(3)]
        [Required]
        public string FirstName { get; set; }
        [Column(4)]
        [Required]
        public string MiddleName { get; set; }
        [Column(5)]
        [Required]
        public string LastName { get; set; }
        [Column(6)]
        [Required]
        public System.DateTime LeadDate { get; set; }
        [Column(7)]
        [Required]
        public string Contact { get; set; }
        [Column(8)]
        [Required]
        public string AltContact { get; set; }
        [Column(9)]
        [Required]
        public string Email { get; set; }
        [Column(10)]
        [Required]
        public string Budget { get; set; }
        [Column(11)]
        [Required]
        public string LeadSource { get; set; }
        public int RowNumber { get; set; }
        public string RowInfo { get; set; }
        public bool IsError { get; set; }
        public string ErrorMessage { get; set; }
        public List<string> AllErrorMessage { get; set; }                
    }
    public static class ExcelToObjectConverter
    {
        public static IEnumerable<T> ConvertSheetToObjects<T>(this ExcelWorksheet worksheet) where T : new()
        {
            Func<CustomAttributeData, bool> columnOnly = y => y.AttributeType == typeof(Column);
            var columns = typeof(T)
                    .GetProperties()
                    .Where(x => x.CustomAttributes.Any(columnOnly))
            .Select(p => new
            {
                Property = p,
                Column = p.GetCustomAttributes<Column>().First().ColumnIndex //safe because if where above
            }).ToList();

            var rows = worksheet.Cells
                .Select(cell => cell.Start.Row)
                .Distinct()
                .OrderBy(x => x);


            //Create the collection container
            var collection = rows.Skip(1)
                .Select(row =>
                {
                    var tnew = new T();
                    columns.ForEach(col =>
                    {
                        //This is the real wrinkle to using reflection - Excel stores all numbers as double including int
                        var val = worksheet.Cells[row, col.Column];
                        //If it is numeric it is a double since that is how excel stores all numbers
                        if (val.Value == null)
                        {
                            col.Property.SetValue(tnew, null);
                            return;
                        }
                        if (col.Property.PropertyType == typeof(Int32))
                        {
                            col.Property.SetValue(tnew, val.GetValue<int>());
                            return;
                        }
                        if (col.Property.PropertyType == typeof(decimal))
                        {
                            col.Property.SetValue(tnew, val.GetValue<decimal>());
                            return;
                        }
                        if (col.Property.PropertyType == typeof(Decimal))
                        {
                            col.Property.SetValue(tnew, val.GetValue<Decimal>());
                            return;
                        }
                        if (col.Property.PropertyType == typeof(DateTime))
                        {
                            col.Property.SetValue(tnew, val.GetValue<DateTime>());
                            return;
                        }
                        //Its a string
                        col.Property.SetValue(tnew, val.GetValue<string>());
                    });

                    return tnew;
                });
            //Send it back
            return collection;
        }
    }
}