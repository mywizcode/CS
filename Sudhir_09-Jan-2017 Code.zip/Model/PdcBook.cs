using System;
using System.Text;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Iesi.Collections.Generic;


namespace ConstroSoft {
    
    public class PdcBook {
        public PdcBook()
        {
            this.CustomerIn = new HashSet<Customer>();
            this.CustomerOut = new HashSet<Customer>();
            this.FirmIn = new HashSet<Firm>();
            this.FirmOut = new HashSet<Firm>();
            this.PostDatedCheques = new HashSet<PrPostDatedCheque>();
        }
        public virtual long Id { get; set; }
        public virtual string Description { get; set; }
        public virtual ISet<Customer> CustomerIn { get; set; }
        public virtual ISet<Customer> CustomerOut { get; set; }
        public virtual ISet<Firm> FirmIn { get; set; }
        public virtual ISet<Firm> FirmOut { get; set; }
        public virtual ISet<PrPostDatedCheque> PostDatedCheques { get; set; }
    }
}
