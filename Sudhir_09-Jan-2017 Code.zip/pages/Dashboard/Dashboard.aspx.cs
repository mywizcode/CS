﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Net;
using System.IO;
using System.Windows.Forms;
using System.Net.Mail;
using ConstroSoft;

public partial class Dashboard : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    EmployeeBO employeeBO = new EmployeeBO();
    string tab1ValidationGrp = "tab1Error";
    protected void Page_Load(object sender, EventArgs e)
    {
        loadSearchGridAndReSelect();
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
    }
    private void loadSearchGridAndReSelect()
    {
        try
        {
            EmployeeSearchBy searchBy = EmployeeSearchBy.EMPLOYEE_ID;
            long searchByValId = -1;
            IList<FirmMemberDTO> results = employeeBO.fetchEmployeeGridData(getUserDefinitionDTO().FirmNumber, searchBy, searchByValId);
            employeeGrid.DataSource = results;
            employeeGrid.DataBind();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void selectEmployee(object sender, EventArgs e)
    {
    }
}