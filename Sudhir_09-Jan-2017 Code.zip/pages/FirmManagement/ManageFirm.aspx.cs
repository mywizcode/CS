﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using Vladsm.Web.UI.WebControls;

public partial class ManageFirm : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string tab1ValidationGrp = "tab1Error";
    string tab2ValidationGrp = "tab2Error";
    string VS_FIRM = "FIRM";
    string VS_SELECTED_ACNT = "SELECTED_ACNT";
    DropdownBO drpBO = new DropdownBO();
    FirmBO firmBO = new FirmBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                resetAccountDetailFormWithSelection();
                initDropdowns();
                populateFirmDetails();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = getUserInfoDto();
        drpBO.drpDataBase(drpAcntType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ACCOUNT_TYPE, null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAddressCountry, DrpDataType.COUNTRY, null, null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAddressState, DrpDataType.STATE, Constants.DEFAULT_COUNTRY, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        initCityDrp(drpAddressCity, Constants.DEFAULT_STATE);
    }
    private void initCityDrp(DropDownList drp, string stateId)
    {
        drpBO.drpDataBase(drp, DrpDataType.CITY, stateId, Constants.SELECT_ITEM, getUserInfoDto().FirmNumber);
    }
    private UserDefinitionDTO getUserInfoDto()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        applyEntitlement();
        initBootstrapComponantsFromServer();
    }
    private bool isViewOnlyUser()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        bool isViewOnlyUser = !CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.FIRM_ACCOUNT_ADD_UPDATE);
        return isViewOnlyUser;
    }
    private void applyEntitlement()
    {
        if (isViewOnlyUser())
        {
            //TODO - Hide buttons when read only user
            btnUpdate.Visible = false;
            viewOnlyTableHdn.Value = "true";
            accountGrid.Columns[0].Visible = false;
            addAccountBtn.Visible = false;
        }
    }
    private void clearMessages()
    {
        tab1SuccessPanel.Visible = false;
        lbTab1Success.Text = "";
        tab2SuccessPanel.Visible = false;
        lbTab2Success.Text = "";
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
    }

    public void setSuccessMessage(string msg, string tabId)
    {
        activeTabHdn.Value = tabId;
        if (tab1Anchor.ID.Equals(tabId))
        {
            lbTab1Success.Text = msg;
            tab1SuccessPanel.Visible = true;
        }
        else if (tab2Anchor.ID.Equals(tabId))
        {
            lbTab2Success.Text = msg;
            tab2SuccessPanel.Visible = true;
        }
    }

    public void resetAllFormInputs()
    {
        resetAccountDetailFormWithSelection();
    }

    public void resetAccountDetailForm()
    {
        txtAcntName.Text = null;
        txtAcntNumber.Text = null;
        drpAcntType.ClearSelection();
        txtAcntBalance.Text = Decimal.Zero.ToString();
        txtAcntIFSCCode.Text = null;
        txtAcntBankName.Text = null;
        txtAcntBranch.Text = null;
        drpAcntCity.ClearSelection();
        drpAcntState.ClearSelection();
        drpAcntCountry.ClearSelection();
        pnlAccountAdd.Visible = false;
    }
    public void resetAccountDetailFormWithSelection()
    {
        resetAccountDetailForm();
        if (accountGrid.Rows.Count > 0)
        {
            foreach (GridViewRow row in accountGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdAccountSelect");
                if (radioBtn != null) radioBtn.Checked = false;
            }
        }
        ViewState[VS_SELECTED_ACNT] = null;
    }
    private void initAccountAddUpdateSection(bool isAdd)
    {
        lbAcntAction.Text = (isAdd) ? Resources.Labels.label_sectionheader_addaccount : Resources.Labels.label_sectionheader_updateaccount;
        pnlAccountAdd.Visible = true;
        btnAcntSave.Visible = isAdd;
        btnAcntUpdate.Visible = !isAdd;
        drpBO.drpDataBase(drpAcntCountry, DrpDataType.COUNTRY, null, null, getUserInfoDto().FirmNumber);
        drpBO.drpDataBase(drpAcntState, DrpDataType.STATE, Constants.DEFAULT_COUNTRY, Constants.SELECT_ITEM, getUserInfoDto().FirmNumber);
        drpBO.drpDataBase(drpAcntCity, DrpDataType.CITY, Constants.DEFAULT_STATE, Constants.SELECT_ITEM, getUserInfoDto().FirmNumber);
        drpAcntState.Text = Constants.DEFAULT_STATE;
    }

    private void setTabInfo(PageMode pageMode, string activeTabValue)
    {
        if (PageMode.ADD == pageMode)
        {
            tab2Anchor.Text = Resources.Labels.firm_sm_firm_dtls_tab_manage_acnt;
        }
        else if (PageMode.MODIFY == pageMode)
        {
        }
        else
        {
        }
        activeTabHdn.Value = activeTabValue;
    }
    
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private void populateFirmDetails()
    {
        try
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            FirmDTO firmDto = firmBO.fetchFirmDetails(userDefDto.FirmNumber);
            ViewState[VS_FIRM] = null;
            ViewState[VS_FIRM] = firmDto;
            if (firmDto != null)
            {
                txtFirmName.Text = firmDto.Name;
                txtRegistrationNo.Text = firmDto.RegistrationNo;
                txtContact.Text = firmDto.ContactInfo.Contact;
                txtDescription.Text = firmDto.Description;
                txtEmail.Text = firmDto.ContactInfo.Email;
                txtWebSite.Text = firmDto.WebSite;
                ISet<AddressDTO> addresses = firmDto.ContactInfo.Addresses;
                if (addresses.Count > 0)
                {
                    foreach(AddressDTO addressDto in addresses) {
                        txtAddressLine1.Text = addressDto.AddressLine1;
                        txtAddressLine2.Text = addressDto.AddressLine2;
                        txtTown.Text = addressDto.Town;
                        drpAddressCountry.Text = addressDto.Country.Id.ToString();
                        drpAddressState.Text = addressDto.State.Id.ToString();
                        initCityDrp(drpAddressCity, drpAddressState.Text);
                        drpAddressCity.Text = addressDto.City.Id.ToString();
                        txtPin.Text = addressDto.Pin;
                        break;
                    }
                }
                accountGrid.DataSource = firmDto.FirmAccounts;
                accountGrid.DataBind();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void loadCities(object sender, EventArgs e)
    {
        initCityDrp(drpAddressCity, drpAddressState.Text);
    }
    protected void loadAcntCities(object sender, EventArgs e)
    {
        initCityDrp(drpAcntCity, drpAcntState.Text);
    }
    /*
     * This method is called on click of ADD button in datatable top bar.
     */
    protected void onClickAddAccountBtn(object sender, EventArgs e)
    {
        resetAccountDetailFormWithSelection();
        initAccountAddUpdateSection(true);
        SetFocus(txtAcntName);
    }
    protected void selectAccount(object sender, EventArgs e)
    {
        GroupRadioButton rd = (GroupRadioButton)sender;
        resetAccountDetailForm();
        if (rd.Checked)
        {
            string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("acntRowIndBtn"))).Attributes["row-identifier"];
            FirmAccountDTO accountDto = getAccountDto(strId);
            ViewState[VS_SELECTED_ACNT] = accountDto;
        }
    }
    protected void editSelectedAccount(object sender, EventArgs e)
    {
        if (validateAccountSelected())
        {
            initAccountAddUpdateSection(false);
            FirmAccountDTO accountDto = (FirmAccountDTO)ViewState[VS_SELECTED_ACNT];
            txtAcntName.Text = accountDto.Name;
            drpAcntType.Text = accountDto.AccountType.Id.ToString();
            txtAcntNumber.Text = accountDto.AccountNo;
            txtAcntBalance.Text = accountDto.AccountBalance.ToString();
            txtAcntIFSCCode.Text = accountDto.IfscCode;
            txtAcntBankName.Text = accountDto.BankName;
            txtAcntBranch.Text = accountDto.Branch;
            drpAcntCity.Text = (accountDto.City != null) ? accountDto.City.Id.ToString() : "";
            drpAcntState.Text = (accountDto.State != null) ? accountDto.State.Id.ToString() : "";
            drpAcntCountry.Text = (accountDto.Country != null) ? accountDto.Country.Id.ToString() : "";
            SetFocus(txtAcntName);
        }
    }
    private bool validateAccountSelected()
    {
        bool isSelected = true;
        FirmAccountDTO accountDto = (FirmAccountDTO)ViewState[VS_SELECTED_ACNT];
        if (accountDto == null)
        {
            isSelected = false;
            resetAccountDetailFormWithSelection();
            setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Account"), tab2ValidationGrp);
        }
        return isSelected;
    }
    private FirmAccountDTO getAccountDto(string accountId)
    {
        FirmDTO firmDto = (FirmDTO)ViewState[VS_FIRM];
        long acntId = long.Parse(accountId);
        FirmAccountDTO selectedAccountDto = null;
        foreach (FirmAccountDTO accountDto in firmDto.FirmAccounts)
        {
            if (acntId == accountDto.Id)
            {
                selectedAccountDto = accountDto;
                break;
            }
        }
        return selectedAccountDto;
    }
    protected void deleteAccount(object sender, EventArgs e)
    {
        try
        {
            if (validateAccountSelected())
            {
                FirmAccountDTO accountDto = (FirmAccountDTO)ViewState[VS_SELECTED_ACNT];
                firmBO.deleteFirmAccount(accountDto.Id);
                resetAccountDetailFormWithSelection();
                populateFirmDetails();
                setSuccessMessage(Resources.Messages.firm_success_acnt_delete, tab2Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message);
            setErrorMessage(exp.Message, tab2ValidationGrp);
        }
    }
    protected void addNewAccount(object sender, EventArgs e)
    {
        try
        {
            FirmAccountDTO firmAccountDto = populateAccountDTO();
            firmBO.saveFirmAccount(firmAccountDto);
            resetAccountDetailFormWithSelection();
            populateFirmDetails();
            setSuccessMessage(Resources.Messages.firm_success_acnt_add, tab2Anchor.ID);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message);
            setErrorMessage(exp.Message, tab2ValidationGrp);
        }
    }
    protected void updateAccount(object sender, EventArgs e)
    {
        try
        {
            if (validateAccountSelected())
            {
                FirmAccountDTO accountDto = (FirmAccountDTO)ViewState[VS_SELECTED_ACNT];
                UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
                populateAccountFromUI(accountDto, userDefDto);
                firmBO.updateFirmAccount(accountDto);
                resetAccountDetailFormWithSelection();
                populateFirmDetails();
                setSuccessMessage(Resources.Messages.firm_success_acnt_update, tab2Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message);
            setErrorMessage(exp.Message, tab2ValidationGrp);
        }
    }
    protected void cancelAccount(object sender, EventArgs e)
    {
        resetAccountDetailFormWithSelection();
    }
    protected void updateFirmDetails(object sender, EventArgs e)
    {
        try
        {
            FirmDTO firmDto = (FirmDTO)ViewState[VS_FIRM];
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            populateFirmFromUI(firmDto, userDefDto);
            firmBO.updateFirm(firmDto);
            resetAccountDetailFormWithSelection();
            populateFirmDetails();
            setSuccessMessage(Resources.Messages.firm_success_firm_update, tab1Anchor.ID);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message);
            setErrorMessage(exp.Message, tab1ValidationGrp);
            populateFirmDetails();
        }
    }
    private void populateFirmFromUI(FirmDTO firmDto, UserDefinitionDTO userDefDto)
    {
        firmDto.RegistrationNo = txtRegistrationNo.Text;
        firmDto.ContactInfo.Contact = txtContact.Text;
        firmDto.Description = txtDescription.Text;
        firmDto.ContactInfo.Email = txtEmail.Text;
        firmDto.WebSite = txtWebSite.Text;
        AddressDTO addressDto = firmDto.ContactInfo.Addresses.First<AddressDTO>();
        firmDto.ContactInfo.Addresses.Clear();
        firmDto.ContactInfo.Addresses.Add(addressDto);
        addressDto.AddressLine1 = txtAddressLine1.Text;
        addressDto.AddressLine2 = txtAddressLine2.Text;
        addressDto.Town = txtTown.Text;
        addressDto.City = CommonUIConverter.getCityDTO(drpAddressCity.Text, drpAddressCity.SelectedItem.Text);
        addressDto.State = CommonUIConverter.getStateDTO(drpAddressState.Text, drpAddressState.SelectedItem.Text);
        addressDto.Country = CommonUIConverter.getCountryDTO(drpAddressCountry.Text, drpAddressCountry.SelectedItem.Text);
        addressDto.Pin = txtPin.Text;
        firmDto.UpdateUser = userDefDto.Username;
    }
    private FirmAccountDTO populateAccountDTO()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        FirmDTO firmDto = (FirmDTO)ViewState[VS_FIRM];
        FirmAccountDTO accountDto = new FirmAccountDTO();
        populateAccountFromUI(accountDto, userDefDto);
        accountDto.FirmNumber = userDefDto.FirmNumber;
        accountDto.InsertUser = userDefDto.Username;
        accountDto.Firm = firmDto;
        return accountDto;
    }
    private void populateAccountFromUI(FirmAccountDTO accountDto, UserDefinitionDTO userDefDto)
    {
        accountDto.Name = txtAcntName.Text;
        accountDto.AccountType = CommonUIConverter.getMasterControlDTO(drpAcntType.Text, drpAcntType.SelectedItem.Text);
        accountDto.AccountNo = txtAcntNumber.Text;
        accountDto.IfscCode = txtAcntIFSCCode.Text;
        accountDto.BankName = txtAcntBankName.Text;
        accountDto.Branch = txtAcntBranch.Text;
        accountDto.City = CommonUIConverter.getCityDTO(drpAcntCity.Text, drpAcntCity.SelectedItem.Text);
        accountDto.State = CommonUIConverter.getStateDTO(drpAcntState.Text, drpAcntState.SelectedItem.Text);
        accountDto.Country = CommonUIConverter.getCountryDTO(drpAcntCountry.Text, drpAcntCountry.SelectedItem.Text);
        accountDto.UpdateUser = userDefDto.Username;
    }
}
