﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft.DataSetContainer;
using CrystalDecisions.CrystalReports.Engine;

namespace ConstroSoft.pages.Reports
{
    public partial class DemoReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            PropertyBO propertyBO = new PropertyBO();
            FirmBO firmBO = new FirmBO();
            //TODO : Add property unit value for selected unit
            PropertyUnitDTO propertyUnitDto = propertyBO.fetchPropertyUnitWithParent(1, true);
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            FirmDTO firmDto = firmBO.fetchFirmDetails(userDefDto.FirmNumber);
            PropertyDTO  propertyDTO = propertyBO.fetchProperty(propertyUnitDto.PropertyTower.Property.Id);

            DataTable PropertyUnit = new DataTable();
            DataRow prUnitRow = PropertyUnit.NewRow();
            populatePropertyUnit(propertyUnitDto, firmDto, propertyDTO, PropertyUnit, prUnitRow);

            DataTable PropertyTax = new DataTable();
            PropertyDTO propertyDto = populatePropertyTax(propertyUnitDto, PropertyTax);

            DataTable PropertyPymtSchd = new DataTable();
            populatePropertySchd(propertyUnitDto, PropertyPymtSchd);

            DataTable PropertyCharge = new DataTable();
            populatePropertyCharges(propertyDto, PropertyCharge);

            ReportDocument quotationReportDocument = new ReportDocument();
            string reportPath = Server.MapPath("REPORTS//UnitQuotation.rpt");
            quotationReportDocument.Load(reportPath);
            quotationReportDocument.Database.Tables["PropertyUnit"].SetDataSource(PropertyUnit);
            quotationReportDocument.Subreports["PropertyCharges"].SetDataSource(PropertyCharge);
            quotationReportDocument.Subreports["PropertyTaxes"].SetDataSource(PropertyTax);
            quotationReportDocument.Subreports["PROPERTYPAYSCHD"].SetDataSource(PropertyPymtSchd);
            Session["QuotationReport"] = quotationReportDocument;
            CrystalReportViewer1.ReportSource = quotationReportDocument;
            CrystalReportViewer1.Zoom(75);
        }

        private static void populatePropertyCharges(PropertyDTO propertyDto, DataTable PropertyCharge)
        {
            PropertyCharge.Columns.Add("ChargeType", typeof(string));
            PropertyCharge.Columns.Add("ChargeValue", typeof(string));

            if (propertyDto.PropertyCharges != null && propertyDto.PropertyCharges.Count > 0)
            {
                foreach (PropertyChargeDTO propertyChargeDTO in propertyDto.PropertyCharges)
                {
                    DataRow chargeRow = PropertyCharge.NewRow();
                    chargeRow["ChargeType"] = propertyChargeDTO.ChargeType.Name;
                    chargeRow["ChargeValue"] = Convert.ToDecimal(propertyChargeDTO.ChargeValue);
                    PropertyCharge.Rows.Add(chargeRow);
                }
            }
            else
            {
                DataRow chargeRow = PropertyCharge.NewRow();
                PropertyCharge.Rows.Add(chargeRow);
            }
        }

        private static void populatePropertySchd(PropertyUnitDTO propertyUnitDto, DataTable PropertyPymtSchd)
        {
            List<PropertyScheduleDTO> propertySchdList = null;
            PropertyPymtSchd.Columns.Add("STAGE", typeof(string));
            PropertyPymtSchd.Columns.Add("PERCENTAGE", typeof(decimal));
            PropertyPymtSchd.Columns.Add("STATUS", typeof(string));
            PropertyPymtSchd.Columns.Add("STAGE_NUMBER", typeof(Int32));
            if (propertyUnitDto.PropertyTower.PropertySchedules != null)
            {
                propertySchdList = propertyUnitDto.PropertyTower.PropertySchedules.ToList();
            }
            if (propertySchdList != null && propertySchdList.Count() > 0)
            {
                foreach (PropertyScheduleDTO propertySchdDto in propertySchdList)
                {
                    DataRow stageRow = PropertyPymtSchd.NewRow();
                    stageRow["STAGE"] = propertySchdDto.Stage.ToString();
                    stageRow["PERCENTAGE"] = propertySchdDto.Percentage;
                    stageRow["STATUS"] = propertySchdDto.Status.ToString();
                    stageRow["STAGE_NUMBER"] = propertySchdDto.StageNumber;
                    PropertyPymtSchd.Rows.Add(stageRow);
                }

            }
            else
            {
                DataRow stageRow = PropertyPymtSchd.NewRow();
                PropertyPymtSchd.Rows.Add(stageRow);
            }
        }

        private static PropertyDTO populatePropertyTax(PropertyUnitDTO propertyUnitDto, DataTable PropertyTax)
        {
            PropertyTax.Columns.Add("TaxType", typeof(string));
            PropertyTax.Columns.Add("TaxPercentage", typeof(string));
            PropertyDTO propertyDto = propertyUnitDto.PropertyTower.Property;
            if (propertyDto.PropertyTaxDetails != null && propertyDto.PropertyTaxDetails.Count > 0)
            {
                foreach (PropertyTaxDetailDTO propertyTaxDetailDto in propertyDto.PropertyTaxDetails)
                {
                    if (IncludeInPymtTotal.Yes == propertyTaxDetailDto.IncludeInTotalPymt)
                    {
                        DataRow taxRow = PropertyTax.NewRow();

                        taxRow["TaxType"] = propertyTaxDetailDto.TaxType.Name;
                        taxRow["TaxPercentage"] = propertyTaxDetailDto.TaxPercentage.ToString();
                        PropertyTax.Rows.Add(taxRow);
                    }
                }
            }
            return propertyDto;
        }

        private static void populatePropertyUnit(PropertyUnitDTO propertyUnitDto, FirmDTO firmDto, PropertyDTO propertyDTO, DataTable PropertyUnit, DataRow prUnitRow)
        {
            PropertyUnit.Columns.Add("PropertyName", typeof(string));
            PropertyUnit.Columns.Add("PropertyAddress", typeof(string));
            PropertyUnit.Columns.Add("PrTowerName", typeof(string));
            PropertyUnit.Columns.Add("PrWing", typeof(string));
            PropertyUnit.Columns.Add("PrFloorNo", typeof(string));
            PropertyUnit.Columns.Add("PrFlatNo", typeof(string));
            PropertyUnit.Columns.Add("BuiltupArea", typeof(decimal));
            PropertyUnit.Columns.Add("CarpetArea", typeof(decimal));
            PropertyUnit.Columns.Add("BookingRate", typeof(decimal));
            PropertyUnit.Columns.Add("FirmName", typeof(string));

            prUnitRow["PropertyName"] = propertyUnitDto.PropertyTower.Property.Name;
            prUnitRow["PrTowerName"] = propertyUnitDto.PropertyTower.Name;
            string address = null;
            if (propertyDTO.ContactInfo.Addresses != null)
            {
                List<AddressDTO> addressList = propertyDTO.ContactInfo.Addresses.ToList();
                AddressDTO addressDTO = addressList[0];
                address = addressDTO.AddressLine1 + " " + addressDTO.AddressLine2 + " " + addressDTO.Town + " "
                    + addressDTO.City.Name + " " + addressDTO.State.Name + " " + addressDTO.Country.Name;
            }
            prUnitRow["PropertyAddress"] = address;
            prUnitRow["PrWing"] = propertyUnitDto.Wing;
            prUnitRow["PrFloorNo"] = propertyUnitDto.FloorNo;
            prUnitRow["PrFlatNo"] = propertyUnitDto.UnitNo;
            prUnitRow["BuiltupArea"] = propertyUnitDto.BuildupArea;
            prUnitRow["CarpetArea"] = propertyUnitDto.CarpetArea;
            prUnitRow["BookingRate"] = propertyUnitDto.PropertyTower.Rate;
            prUnitRow["FirmName"] = firmDto.Name;

            PropertyUnit.Rows.Add(prUnitRow);
        }

    }
}