$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initPropertyGrid();
    initTowerGrid();
    initTaxGrid();
    initPropertyChargesGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("tab2Content");
    //This script will enable tabs which was last active even after postback call.
    enableTab(true);
}

function initTowerGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "propertyTowerGrid",
        isViewOnly: isViewOnly,
        pageLength: 5,
        responsiveModalTitle: "Property Tower Details",
        customBtnGrpId: "#propTowerGridBtnGrp",
        hasRowInfo: true,
        hideSearch: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPropertyTowerHdnId");
}
function initTaxGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "taxDetailGrid",
        isViewOnly: isViewOnly,
        pageLength: 5,
        responsiveModalTitle: "Tax Details",
        customBtnGrpId: "#taxDetailGridBtnGrp",
        hasRowInfo: true,
        hideSearch: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToTaxDetailHdnId");
}

function initPropertyGrid() {
    var dtOptions = {
        tableId: "propertyGrid",
        isViewOnly: false,
        pageLength: 10,
        responsiveModalTitle: "Property Details",
        customBtnGrpId: "#propSearchBtnDiv",
        hasRowInfo: false
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPropertyHdnId");
}
function initPropertyChargesGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "PropertyChargesGrid",
        isViewOnly: isViewOnly,
        pageLength: 10,
        responsiveModalTitle: "Property Charges Details",
        customBtnGrpId: "#chargesDetailGridBtnGrp",
        hasRowInfo: true,
        hideSearch: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToChargesDetailHdnId");
}

