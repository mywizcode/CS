﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initCustomerGrid();
    initCocustomerGrid();
    initAddressGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("tab2Content");
    enableTab(true);
}

function initAddressGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "addressGrid",
        isViewOnly: isViewOnly,
        pageLength: 5,
        responsiveModalTitle: "Address Details",
        customBtnGrpId: "#addressGridBtnGrp",
        hasRowInfo: true,
        defaultColToOrder: 6,
        defaultOrderDesc: true,
        hideSearch: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToAddressHdnId");
}

function initCustomerGrid() {
    var dtOptions = {
        tableId: "customerGrid",
        isViewOnly: false,
        pageLength: 10,
        responsiveModalTitle: "Customer Details",
        customBtnGrpId: "#custSearchBtnDiv",
        hasRowInfo: false
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToCustHdnId");
}
function initCocustomerGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "coCustomerGrid",
        isViewOnly: isViewOnly,
        pageLength: 5,
        responsiveModalTitle: "Address Details",
        customBtnGrpId: "#cocustomerGridBtnGrp",
        hasRowInfo: true,
        hideSearch: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToCoCustHdnId");
}
