﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initExpencessGrid();
    initDocumentGrid();
    initExpencessDetailsGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("tab2Content");
    //This script will enable tabs which was last active even after postback call.
    enableTab(false);
}

function initDocumentGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "expencessmentDocuGrid",
        isViewOnly: isViewOnly,
        pageLength: 5,
        responsiveModalTitle: "Document Details",
        customBtnGrpId: "#expencessSearchBtnDiv",
        hasRowInfo: true,
        defaultColToOrder: 3,
        defaultOrderDesc: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToExpencessHdnId");
}

function initExpencessGrid() {
    var dtOptions = {
        tableId: "propertyexpencessGrid",
        isViewOnly: false,
        pageLength: 10,
        responsiveModalTitle: "Expencess Details",
        customBtnGrpId: "#expSearchBtnDiv",
        hasRowInfo: false
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPropertyExpencessHdnId");
}

function initExpencessDetailsGrid() {
    var dtOptions = {
        tableId: "GridViewExpencessDetails",
        isViewOnly: false,
        pageLength: 10,
        responsiveModalTitle: "Expencess Details",
        customBtnGrpId: "#expencessDetailsbtnDiv",
        hasRowInfo: false
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "hdnExpencessDetailsHDN");
}
