﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initSoldeUnitsGrid();
    initTaxGrid();
    initCMTaxGrid();
    initPaymentGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("tab2Content");
    //This script will enable tabs which was last active even after postback call.
    enableTab(true);

    //makeReadOnlySection("pnlTab2UnitInfo");
    var isModify = ($("[id$='pageModeHdn']").val() == 'MODIFY');
    if (isModify) {
        makeReadOnlySection("pnlTab2BzStep1");
    }
    /*if (!($("[id$='addPymtTypeBtn']").is(":visible"))) {
        makeReadOnlySection("pnlPaymentAdd");
    }*/
}

function initSoldeUnitsGrid() {
    var dtOptions = {
        tableId: "soldUnitsGrid",
        isViewOnly: false,
        pageLength: 10,
        responsiveModalTitle: "Unit Details",
        customBtnGrpId: "#soldUnitsSearchBtnDiv"
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToSoldUnitsHdnId");
}
function initTaxGrid() {
    var isViewOnly = true;
    var dtOptions = {
        tableId: "taxDetailGrid",
        isViewOnly: isViewOnly,
        pageLength: 5,
        responsiveModalTitle: "Tax Details",
        hasRowInfo: true,
        hideSearch: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToTaxDetailHdnId");
}
function initCMTaxGrid() {
    var isViewOnly = true;
    var dtOptions = {
        tableId: "cmTaxDetailGrid",
        isViewOnly: isViewOnly,
        pageLength: 5,
        responsiveModalTitle: "Tax Details",
        hasRowInfo: true,
        hideSearch: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToCMTaxDetailHdnId");
}
function initPaymentGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "paymentGrid",
        isViewOnly: isViewOnly,
        pageLength: 5,
        responsiveModalTitle: "Payment Details",
        customBtnGrpId: "#paymentGridBtnGrp",
        hasRowInfo: true,
        hideSearch: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPaymentHdnId");
}