$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initPymtSearchGrid();
    initPymtHistoryGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    //This script will enable tabs which was last active even after postback call.
    enableTab(false);
    makeReadOnlySection("pnlPaymentInfo");
}

function initPymtHistoryGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'PYMT_HISTORY_READONLY');
    var dtOptions = {
        tableId: "pymtHistoryGrid",
        isViewOnly: isViewOnly,
        pageLength: 5,
        responsiveModalTitle: "Payment Transaction Details",
        customBtnGrpId: "#pymtHistoryGridBtnGrp",
        hasRowInfo: true,
        hideSearch: true,
        defaultColToOrder: 2,
        defaultOrderDesc: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPymtHistoryHdnId");
}

function initPymtSearchGrid() {
    var dtOptions = {
        tableId: "custToFromBuilderPymtGrid",
        isViewOnly: false,
        pageLength: 10,
        responsiveModalTitle: "Payment Details",
        customBtnGrpId: "#pymtMatserSearchBtnDiv",
        hasRowInfo: false
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToCustToFromBuilderHdnId");
}