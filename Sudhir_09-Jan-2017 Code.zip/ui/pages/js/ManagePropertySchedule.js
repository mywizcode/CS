$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initPaymentScheduleGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("tab2Content");
    //This script will enable tabs which was last active even after postback call.
    enableTab(true);
}

function initPaymentScheduleGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "propertyScheduleGrid",
        isViewOnly: isViewOnly,
        pageLength: 5,
        responsiveModalTitle: "Stage Details",
        customBtnGrpId: "#propertyScheduleGridBtnDiv",
        hasRowInfo: true,
        hideSearch: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPropertyScheduleHdnId");
}