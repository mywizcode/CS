﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initEnquiryGrid();
    initFollowUpGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    makeReadOnlySection("pnlEnquiryInfo");
    enableTab(false);
    //This script will enable tabs which was last active even after postback call.
    if ($("[id$='activeTabHdn']").val() != "") {
        $('a[id$="' + $("[id$='activeTabHdn']").val() + '"]').tab('show');
    }
}

function initFollowUpGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "followUpGrid",
        isViewOnly: isViewOnly,
        pageLength: 5,
        responsiveModalTitle: "Follow-Up Details",
        customBtnGrpId: "#followUpHistoryGridBtnGrp",
        hasRowInfo: true,
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToFollowUpHdnId");
}

function initEnquiryGrid() {
    var dtOptions = {
        tableId: "enquiryGrid",
        isViewOnly: false,
        pageLength: 10,
        responsiveModalTitle: "Enquiry Details",
        customBtnGrpId: "#enqSearchBtnDiv",
        hasRowInfo: false
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToEnquiryHdnId");
}