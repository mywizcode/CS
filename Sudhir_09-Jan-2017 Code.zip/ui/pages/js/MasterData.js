﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initMasterDataGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("tab1Content");
    //This script will enable tabs which was last active even after postback call.
    enableTab(true);
}

function initMasterDataGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "masterControlGrid",
        isViewOnly: isViewOnly,
        pageLength: 5,
        responsiveModalTitle: "Master Data",
        customBtnGrpId: "#masSearchBtnDiv",
        hasRowInfo: true,
        hideSearch: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToMasterDataHdnId");
}