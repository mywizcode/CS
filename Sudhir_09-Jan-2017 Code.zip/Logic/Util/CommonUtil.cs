﻿
/// <summary>
/// Summary description for CommonUtil
/// </summary>
using ConstroSoft;
using System.Collections.Generic;
using NHibernate.Criterion;
using System.Linq.Expressions;
using NHibernate.Impl;
using System;
using System.Web.UI.WebControls;
using System.Globalization;
namespace ConstroSoft
{
    public class CommonUtil
    {
        public CommonUtil() { }
        public static bool hasEntitlement(UserDefinitionDTO userDefDto, string entitlement)
        {
            return userDefDto != null && userDefDto.UserRole.entitlements != null && userDefDto.UserRole.entitlements.Contains(entitlement);
        }
        public static PropertyProjection BuildProjection<T>(Expression<Func<object>> aliasExpression, Expression<Func<T, object>> propertyExpression)
        {
            string alias = ExpressionProcessor.FindMemberExpression(aliasExpression.Body);
            string property = ExpressionProcessor.FindMemberExpression(propertyExpression.Body);

            return Projections.Property(string.Format("{0}.{1}", alias, property));
        }
        public static string removeAppenders(string strTemp)
        {
            string result = "";
            if (!string.IsNullOrWhiteSpace(strTemp))
            {
                foreach(string appender in Constants.APPENDERS) {
                    strTemp = strTemp.Replace(appender, "");
                }
                result = strTemp.Trim();
            }
            return result;
        }
        public static decimal? getDecimalWithoutExt(string strVal)
        {
            return getDecimal(removeAppenders(strVal));
        }
        public static decimal? getDecimal(string strVal)
        {
            decimal? result = null;
            if (!string.IsNullOrWhiteSpace(strVal)) result = decimal.Parse(strVal);
            return result;
        }
        public static decimal getDecimaNotNulllWithoutExt(string strVal)
        {
            return getNotNullDecimal(removeAppenders(strVal));
        }
        public static decimal getNotNullDecimal(string strVal)
        {
            decimal result = decimal.Zero;
            if (!string.IsNullOrWhiteSpace(strVal)) result = decimal.Parse(strVal);
            return result;
        }
        public static string getCSDate(DateTime? date)
        {
            return (date != null) ? date.Value.ToString(Constants.DATE_FORMAT) : null;
        }
        public static DateTime? getCSDate(string strDate) {
            DateTime? date = null;
            if (!string.IsNullOrWhiteSpace(strDate)) date = DateTime.ParseExact(strDate, Constants.DATE_FORMAT, CultureInfo.InvariantCulture);
            return date;
        }
        public static DateTime getCSDateNotNull(string strDate)
        {
            DateTime date = DateTime.Today;
            if (!string.IsNullOrWhiteSpace(strDate)) date = DateTime.ParseExact(strDate, Constants.DATE_FORMAT, CultureInfo.InvariantCulture);
            return date;
        }
        public static string getTodayDate()
        {
            return DateTime.Today.ToString(Constants.DATE_FORMAT);
        }
    }
}