﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Constants.
/// </summary>
namespace ConstroSoft
{
    public static class Constants
    {
        //Page Constants
        public class URL
        {
            public const string HOME = "Home";
            public const string LOGIN = "Login";
        }
        public class Session
        {
            public const string USERDEFINITION = "USERDEFINITION";
            public const string USERNAME = "USERNAME";
        }
        public class Entitlement
        {
            public const string MENU_DASHBOARD = "MENU_DASHBOARD";
            public const string MENU_ENQUIRY_MANAGEMENT = "MENU_ENQUIRY_MANAGEMENT";
            public const string MENU_FIRM_MANAGEMENT = "MENU_FIRM_MANAGEMENT";
            public const string MENU_PROPERTY_MANAGEMENT = "MENU_PROPERTY_MANAGEMENT";
            public const string MENU_CUSTOMER_MANAGEMENT = "MENU_CUSTOMER_MANAGEMENT";
            public const string MENU_SALES_MANAGEMENT = "MENU_SALES_MANAGEMENT";
            public const string MENU_PAYMENT_MANAGEMENT = "MENU_PAYMENT_MANAGEMENT";
            public const string MENU_PURCHASE_MANAGEMENT = "MENU_PURCHASE_MANAGEMENT";
            public const string MENU_CONTRACTOR_MANAGEMENT = "MENU_CONTRACTOR_MANAGEMENT";
            public const string MENU_EMPLOYEE_MANAGEMENT = "MENU_EMPLOYEE_MANAGEMENT";
            public const string MENU_REPORTS_AND_ANALYTICS = "MENU_REPORTS_AND_ANALYTICS";
            public const string MENU_PROMOTION_MANAGEMENT = "MENU_PROMOTION_MANAGEMENT";
            public const string MENU_BACKGROUND_MANAGEMENT = "MENU_BACKGROUND_MANAGEMENT";
            public const string MENU_DAILY_PLANNER = "MENU_DAILY_PLANNER";
            public const string MENU_MASTER_CONTROL_DATA = "MENU_MASTER_CONTROL_DATA";
            //Sub-Menu : Start
            //Enquiry
            public const string MENU_MANAGE_ENQUIRY = "MENU_MANAGE_ENQUIRY";
            public const string MENU_ENQUIRY_FOLLOWUP = "MENU_ENQUIRY_FOLLOWUP";
            //Firm
            public const string MENU_FIRM_DETAILS = "MENU_FIRM_DETAILS";
            public const string MENU_ACCOUNT_BALANCE = "MENU_ACCOUNT_BALANCE";
            public const string MENU_ACCOUNT_DEPOSITS = "MENU_ACCOUNT_DEPOSITS";
            //Property
            public const string MENU_MANAGE_PROPERTY = "MENU_MANAGE_PROPERTY";
            public const string MENU_PAYMENT_SCHEDULES = "MENU_PAYMENT_SCHEDULES";
            public const string MENU_PROPERTY_CHARGES = "MENU_PROPERTY_CHARGES";
            public const string MENU_PROPERTY_UNITS = "MENU_PROPERTY_UNITS";
            public const string MENU_PROPERTY_EXPENSES = "MENU_PROPERTY_EXPENSES";
            public const string MENU_PROPERTY_DOCUMENTS = "MENU_PROPERTY_DOCUMENTS";
            //Customer
            public const string MENU_MANAGE_CUSTOMERS = "MENU_MANAGE_CUSTOMERS";
            public const string MENU_CUSTOMER_DOCUMENTS = "MENU_CUSTOMER_DOCUMENTS";
            //Sale
            public const string MENU_AVAILABLE_PROPERTY_UNITS = "MENU_AVAILABLE_PROPERTY_UNITS";
            public const string MENU_BOOK_PROPERTY_UNIT = "MENU_BOOK_PROPERTY_UNIT";
            public const string MENU_SOLD_PROPERTY_UNITS = "MENU_SOLD_PROPERTY_UNITS";
            public const string MENU_CANCELLED_PROPERTY_UNITS = "MENU_CANCELLED_PROPERTY_UNITS";
            public const string MENU_LETTER_GENERATION = "MENU_LETTER_GENERATION";
            //Payment
            public const string MENU_PAYMENTS = "MENU_PAYMENTS";
            public const string MENU_CUSTOMER_PAYMENT_SCHEDULE = "MENU_CUSTOMER_PAYMENT_SCHEDULE";
            //Purchase
            public const string MENU_MANAGE_SUPPLIER = "MENU_MANAGE_SUPPLIER";
            public const string MENU_MANAGE_PURCHASE = "MENU_MANAGE_PURCHASE";
            public const string MENU_TRACK_STOCK_USAGE = "MENU_TRACK_STOCK_USAGE";
            public const string MENU_SUPPLIER_DOCUMENTS = "MENU_SUPPLIER_DOCUMENTS";
            //Contractor
            public const string MENU_MANAGE_CONTRACTOR = "MENU_MANAGE_CONTRACTOR";
            public const string MENU_CONTRACTOR_PAYMENT = "MENU_CONTRACTOR_PAYMENT";
            public const string MENU_CONTRACTOR_DOCUMENTS = "MENU_CONTRACTOR_DOCUMENTS";
            //Employee
            public const string MENU_MANAGE_EMPLOYEE = "MENU_MANAGE_EMPLOYEE";
            //Sub-Menu : End
            //Firm Page
            public const string FIRM_ACCOUNT_ADD_UPDATE = "FIRM_ACCOUNT_ADD_UPDATE";
            public const string FIRM_MEMBER_ADD_UPDATE = "FIRM_MEMBER_ADD_UPDATE";
            //Customer Page
            public const string CUSTOMER_ADD_UPDATE = "CUSTOMER_ADD_UPDATE";
            //Enquiry Page
            public const string ENQUIRY_ADD_UPDATE = "ENQUIRY_ADD_UPDATE";
        }
        public class MCDType
        {
            public const string SALUTATION = "SALUTATION";
            public const string DESIGNATION = "DESIGNATION";
            public const string SECURITY_QUESTION = "SECURITY_QUESTION";
            public const string ACCOUNT_TYPE = "ACCOUNT_TYPE";
            public const string ADDRESS_TYPE = "ADDRESS_TYPE";
            public const string PROPERTY_TYPE = "PROPERTY_TYPE";
            public const string PROPERTY_LOCATION = "PROPERTY_LOCATION";
            public const string PR_TAX_TYPE = "PR_TAX_TYPE";
            public const string PR_EXPENSE_TYPE = "PR_EXPENSE_TYPE";
            public const string PR_UNIT_TYPE = "PR_UNIT_TYPE";
            public const string PR_UNIT_PARKING_TYPE = "PR_UNIT_PARKING_TYPE";
            public const string PR_UNIT_FACING = "PR_UNIT_FACING";
            public const string PR_UNIT_DIRECTION = "PR_UNIT_DIRECTION";
            public const string OCCUPATION = "OCCUPATION";
            public const string CUSTOMER_RELATION = "CUSTOMER_RELATION";
            public const string PR_UNIT_PYMT_TYPE = "PR_UNIT_PYMT_TYPE";
            public const string PURCHASE_ITEM_QUALITY = "PURCHASE_ITEM_QUALITY";
            public const string CONTRACTOR_TYPE = "CONTRACTOR_TYPE";
            public const string ENQUIRY_SOURCE = "ENQUIRY_SOURCE";
            public const string ENQUIRY_MEDIA_TYPE = "ENQUIRY_MEDIA_TYPE";
            public const string DOCUMENT_TYPE = "DOCUMENT_TYPE";
            public const string RELATION_WITH_CUSTOMER = "RELATION_WITH_CUSTOMER";
			public const string TOWER = "TOWER";
            public const string UNIT_TYPE = "UNIT_TYPE";
            public const string DIRECTION = "DIRECTION";
            public const string FACING = "FACING";
            public const string PROPERTY_NAME = "PROPERTY_NAME";
            public const string PR_PARKING_TYPE = "PROPERTY_PARKING_TYPE";
			  public const string AGENCY = "AGENCY";
              public const string PROPERTY_CHARGES = "PROPERTY_CHARGES";
        }
        public class FUNCTIONNAME
        {
            public const string ENQUIRY = "MANAGE ENQUIRY";

        }
        public class EMAILSMSTYPE
        {
            public const string ENQUIRYTHANKS = "ENQUIRY THANKS";

        }
        public const string DATE_FORMAT = "dd-MMM-yyyy";
        public const string DEFAULT_COUNTRY = "1";
        public const string DEFAULT_STATE = "21";
        public const string SCROLL_TOP = "TOP";
        public const string MCD_SALE_PAYMENT = "SALE PAYMENT";
        public const string MCD_CANCELLATION_PAYMENT = "CANCELLATION PAYMENT";
        public static readonly string[] SELECT_ITEM = { Resources.Labels.label_drpselect, "" };
        public static readonly string[] APPENDERS = { "Rs.", "%", "Sq.Ft.", "Sq.Mtr." };
        public const string YES = "Y";

    }
}