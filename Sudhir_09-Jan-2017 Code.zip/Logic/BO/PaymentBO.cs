﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq.Expressions;
using NHibernate.Impl;
using System.Linq;

/// <summary>
/// Summary description for propertyBO
/// </summary>
namespace ConstroSoft
{
    public class PaymentBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public PaymentBO() { }

        public IList<PrUnitSalePymtDTO> fetchCustomerToFromFirmPayments(string firmNumber, long propertyTowerId, PRUnitSalePymtTo pymtTo,
            PaymentSearchBy searchBy, long searchByValue)
        {
            ISession session = null;
            IList<PrUnitSalePymtDTO> result = new List<PrUnitSalePymtDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                PrUnitSalePymt pusp = null;
                Property p = null;
                PropertyUnit pu = null;
                PrUnitSaleDetail pus = null;
                Customer c = null;
                PropertyTower pt = null;
                PaymentMaster pm = null;
                FirmAccount fa = null;
                MasterControlData putype = null;
                MasterControlData pusptype = null;

                PrUnitSalePymtDTO puspdt = null;
                
                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => pusp.Id).WithAlias(() => puspdt.Id))
                            .Add(Projections.SqlFunction("concat",
                                        NHibernateUtil.String,
                                        Projections.Property(() => c.FirstName),
                                        Projections.Constant(" "),
                                        Projections.Property(() => c.LastName)), "PrUnitSaleDetail.Customer.FirstName")
                            .Add(Projections.Property(() => p.Name), "PrUnitSaleDetail.PropertyUnit.PropertyTower.Property.Name")
                            .Add(Projections.Property(() => fa.Id), "PrUnitSaleDetail.PropertyUnit.PropertyTower.Property.FirmAccount.Id")
                            .Add(Projections.Property(() => pt.Name), "PrUnitSaleDetail.PropertyUnit.PropertyTower.Name")
                            .Add(Projections.Property(() => pu.Wing), "PrUnitSaleDetail.PropertyUnit.Wing")
                            .Add(Projections.Property(() => pu.UnitNo), "PrUnitSaleDetail.PropertyUnit.UnitNo")
                            .Add(Projections.Property(() => putype.Name), "PrUnitSaleDetail.PropertyUnit.UnitType.Name")
                            .Add(Projections.Property(() => pus.BookingDate), "PrUnitSaleDetail.BookingDate")
                            .Add(Projections.Property(() => pus.SaleRate), "PrUnitSaleDetail.SaleRate")
                            .Add(Projections.Property(() => pus.AgreementAmt), "PrUnitSaleDetail.AgreementAmt")
                            .Add(Projections.Property(() => pus.Status), "PrUnitSaleDetail.Status")
                            .Add(Projections.Property(() => pusptype.Name), "PymtType.Name")
                            .Add(Projections.Property(() => pm.Id), "PaymentMaster.Id")
                            .Add(Projections.Property(() => pm.TotalAmt), "PaymentMaster.TotalAmt")
                            .Add(Projections.Property(() => pm.TotalPaid), "PaymentMaster.TotalPaid")
                            .Add(Projections.Property(() => pm.TotalPending), "PaymentMaster.TotalPending")
                            .Add(Projections.Property(() => pm.Status), "PaymentMaster.Status")
                            .Add(Projections.Property(() => pusp.Description).WithAlias(() => puspdt.Description));
                var query = session.QueryOver<PrUnitSalePymt>(() => pusp)
                    .Inner.JoinAlias(() => pusp.PaymentMaster, () => pm)
                    .Left.JoinAlias(() => pusp.PymtType, () => pusptype)
                    .Left.JoinAlias(() => pusp.PrUnitSaleDetail, () => pus)
                    .Left.JoinAlias(() => pusp.PrUnitSaleDetail.PropertyUnit, () => pu)
                    .Left.JoinAlias(() => pusp.PrUnitSaleDetail.PropertyUnit.UnitType, () => putype)
                    .Left.JoinAlias(() => pusp.PrUnitSaleDetail.PropertyUnit.PropertyTower, () => pt)
                    .Left.JoinAlias(() => pusp.PrUnitSaleDetail.PropertyUnit.PropertyTower.Property, () => p)
                    .Left.JoinAlias(() => pusp.PrUnitSaleDetail.PropertyUnit.PropertyTower.Property.FirmAccount, () => fa)
                    .Left.JoinAlias(() => pusp.PrUnitSaleDetail.Customer, () => c);
                if (PaymentSearchBy.NONE != searchBy && searchByValue != -1)
                {
                    PropertyProjection prop = null;
                    if (PaymentSearchBy.CUSTOMER_NAME == searchBy)
                    {
                        prop = CommonUtil.BuildProjection<Customer>(() => c, x => x.Id);
                    }
                    else if (PaymentSearchBy.UNIT_NO == searchBy)
                    {
                        prop = CommonUtil.BuildProjection<PropertyUnit>(() => pu, x => x.Id);
                    }
                    query.Where(Restrictions.Eq(prop, searchByValue));
                }
                result = query.Where(() => p.FirmNumber == firmNumber && pt.Id == propertyTowerId && pusp.PymtTo == pymtTo)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<PrUnitSalePymtDTO>()).List<PrUnitSalePymtDTO>();
                result.ToList().ForEach(x => x.PrUnitSaleDetail.PropertyUnit.UnitNo
                    = CommonUIConverter.getPropertyUnitFormattedNo(x.PrUnitSaleDetail.PropertyUnit.Wing, x.PrUnitSaleDetail.PropertyUnit.UnitNo));
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error fetching data for Payment search grid:");
                log.Error(exp.Message, exp);
                throw exp;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public PaymentMasterDTO fetchPaymentMaster(long Id)
        {
            ISession session = null;
            PaymentMasterDTO paymentMasterDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PaymentMaster paymentMaster = session.Get<PaymentMaster>(Id);
                        paymentMasterDto = DomainToDTOUtil.convertToPaymentMasterDTO(paymentMaster, true, true);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Payment Masters details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return paymentMasterDto;
        }
        public void addPymtTransaction(PaymentTransactionDTO pymtTransDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PaymentMaster pymtMaster = session.Get<PaymentMaster>(pymtTransDto.PaymentMaster.Id);
                        DTOToDomainUtil.populatePaymentMasterUpdateFields(pymtMaster, pymtTransDto.PaymentMaster);
                        PaymentTransaction pymtTransaction = DTOToDomainUtil.populatePaymentTransactionAddFields(pymtTransDto);
                        pymtMaster.PaymentTransactions.Add(pymtTransaction);
                        if (pymtTransDto.Status == PymtTransStatus.Reversal)
                        {
                            PaymentTransaction orgPymtTransaction = pymtMaster.PaymentTransactions.ToList<PaymentTransaction>()
                                .Find(p => p.Id == pymtTransDto.CancelledPaymentTransaction.Id);
                            orgPymtTransaction.Status = PymtTransStatus.Deleted;
                        }
                        pymtTransaction.PaymentMaster = pymtMaster;
                        session.Update(pymtMaster);
                        FirmAccount firmAccount = session.Get<FirmAccount>(pymtTransDto.AccountTransaction.FirmAccount.Id);
                        if (pymtTransDto.Status == PymtTransStatus.Paid)
                        {
                            firmAccount.AccountBalance = Decimal.Add(firmAccount.AccountBalance, pymtTransaction.Amount);
                        }
                        else
                        {
                            firmAccount.AccountBalance = Decimal.Subtract(firmAccount.AccountBalance, pymtTransaction.Amount);
                        }
                        session.Update(firmAccount);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Adding payment transaction:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
    }
}