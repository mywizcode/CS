﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;


public partial class ResetPassword : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    LoginBO loginBO = new LoginBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                ResetPasswordNavDTO navDto = ApplicationUtil.getPageNavDTO<ResetPasswordNavDTO>(Session);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSLoginMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    private void renderPageFieldsWithEntitlement()
    {

    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
    }
    private void doInit(ResetPasswordNavDTO navDto)
    {
        if (navDto == null || navDto.Step != ResetPasswordStep.RESET_PASSWORD)
        {
            ApplicationUtil.clearSession(Session, Application);
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    protected void resetPassword(object sender, EventArgs e)
    {
        try
        {
            if (validateResetPassword())
            {
                loginBO.resetPassword(getUserDefinitionDTO().Username, txtNewPassword.Text);
                ApplicationUtil.clearSession(Session, Application);
                Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg("Password is reset successfully. Please login with your new password."));
                //TODO - We may need to remove entry from Application context if user has logged in already from somewhere else.
                Response.Redirect(Constants.URL.FP_RESET_PASSWORD_SUCCESS, true);
            }
        }
        catch (Exception ex)
        {
            log.Error("Unexpected error:", ex);
            Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotyErrorMsg(CommonUtil.getErrorMessage(ex)));
        }
    }
    private bool validateResetPassword()
    {
        if (string.IsNullOrWhiteSpace(txtNewPassword.Text))
        {
            (this.Master as CSLoginMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please enter New Password."));
            return false;
        }
        if (string.IsNullOrWhiteSpace(txtConfirmPassword.Text))
        {
            (this.Master as CSLoginMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please enter Confirm Password."));
            return false;
        }
        if (!txtNewPassword.Text.Equals(txtConfirmPassword.Text))
        {
            (this.Master as CSLoginMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("New Password and Confirm New Password does not match."));
            return false;
        }
        string erroMsg = PasswordPolicy.IsValid(getUserDefinitionDTO().Username, txtNewPassword.Text);
        if (!string.IsNullOrWhiteSpace(erroMsg))
        {
            (this.Master as CSLoginMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(erroMsg));
            return false;
        }
        return true;
    }
}