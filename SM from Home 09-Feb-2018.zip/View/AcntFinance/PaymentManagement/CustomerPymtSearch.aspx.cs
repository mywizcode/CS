﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using ConstroSoft.Logic.BO;
using System.Web.UI.HtmlControls;

public partial class CustomerPymtSearch : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string SearchFilterModal = "SearchFilterModal";
    DropdownBO drpBO = new DropdownBO();
    PaymentBO paymentBO = new PaymentBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                CustomerPymtSearchNavDTO navDto = ApplicationUtil.getPageNavDTO<CustomerPymtSearchNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_CUSTOMER_PAYMENTS)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
    	renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
    	ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpTowerFilter, DrpDataType.PROPERTY_TOWER, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(), null, userDefDto.FirmNumber);
        drpTowerFilter.Text = CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Id.ToString();
        drpBO.drpDataBase(drpCustomerFilter, DrpDataType.CUSTOMER_SEARCH_BY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpUnitNoFilter, DrpDataType.PR_TOWER_UNITS, drpTowerFilter.Text, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<PRUnitSaleStatus>(drpUnitSaleStatusFilter, Constants.SELECT_ITEM);
    }
    public void setErrorMessage(string message, string group)
    {
    	string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
	        CustomValidator val = new CustomValidator();
	        val.IsValid = false;
	        val.ErrorMessage = message;
	        val.ValidationGroup = group;
	        this.Page.Validators.Add(val);
        }
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(CustomerPymtSearchNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new CustomerPymtSearchPageDTO();
        initDropdowns();
        setSearchFilter(null);
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(CustomerPymtSearchNavDTO navDto)
    {
        try
        {
            if (navDto != null)
            {
                setSearchFilter(navDto.filterDTO);
            }
            loadPaymentSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageFieldsWithEntitlement()
    {
    	UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        if (paymentSearchGrid.Rows.Count > 0)
        {
            for (var i = 0; i < paymentSearchGrid.Rows.Count; i++)
            {
                HtmlGenericControl tmpBtn = (HtmlGenericControl)paymentSearchGrid.Rows[i].FindControl("liMakePaymentBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PAYMENT_ADD);
                tmpBtn = (HtmlGenericControl)paymentSearchGrid.Rows[i].FindControl("liAddPdcBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PDC_ADD);
            }
        }
    }
    private CustomerPymtSearchPageDTO getSessionPageData()
    {
        return (CustomerPymtSearchPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<CustomerPymtSearchDTO> getSearchPaymentList()
    {
        return getSessionPageData().SearchResult;
    }
    private CustomerPymtSearchDTO getSearchPaymentDTO(long Id)
    {
        List<CustomerPymtSearchDTO> searchList = getSearchPaymentList();
        CustomerPymtSearchDTO selectedPymtDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            selectedPymtDTO = searchList.Find(x => x.UnitSaleDetailId == Id);
        }
        return selectedPymtDTO;
    }
    private void loadPaymentSearchGrid()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        List<CustomerPymtSearchDTO> results = paymentBO.fetchCustomerSearchPayments(userDefDto.FirmNumber, long.Parse(drpTowerFilter.Text), getSearchFilter());
        getSessionPageData().SearchResult = (results != null) ? results : new List<CustomerPymtSearchDTO>();
        paymentSearchGrid.DataSource = results;
        paymentSearchGrid.DataBind();
    }
    protected void onClickViewPymtHistoryBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            CustomerPymtSearchDTO custPymtSearchDTO = getSearchPaymentDTO(selectedId);
            CustomerPymtHistoryNavDTO navDTO = new CustomerPymtHistoryNavDTO();
            navDTO.PrUnitSaleDetailId = custPymtSearchDTO.UnitSaleDetailId;
            navDTO.PymtMode = PaymentMode.Receivable;
            CustomerPymtSearchNavDTO searchNavDTO = new CustomerPymtSearchNavDTO();
            searchNavDTO.filterDTO = getSearchFilter();
            navDTO.PrevNavDto = searchNavDTO;
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.CUSTOMER_PYMT_HISTORY, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickAddPaymentBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            navigateToPaymentAdd(false, selectedId);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickAddPdcBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            navigateToPaymentAdd(true, selectedId);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }

    private void navigateToPaymentAdd(bool isPdc, long selectedId)
    {
        CustomerPymtSearchDTO custPymtSearchDTO = getSearchPaymentDTO(selectedId);
        CustomerPaymentNavDTO navDTO = new CustomerPaymentNavDTO();
        navDTO.IsPdcPayment = isPdc;
        navDTO.Mode = PageMode.ADD;
        navDTO.PymtMode = PaymentMode.Receivable;//TODO - need to have logic to set mode. If Receivable is Suspended then select Payable Mode
        navDTO.PrUnitSaleDetailId = custPymtSearchDTO.UnitSaleDetailId;
        CustomerPymtSearchNavDTO searchNavDTO = new CustomerPymtSearchNavDTO();
        searchNavDTO.filterDTO = getSearchFilter();
        navDTO.PrevNavDto = searchNavDTO;
        Session[Constants.Session.NAV_DTO] = navDTO;
        Response.Redirect((isPdc) ? Constants.URL.CUSTOMER_PYMT_ADDPDC : Constants.URL.CUSTOMER_PYMT_ADD, true);
    }
    
    //Filter Criteria - Property Search - Start
    private CustomerPymtSearchFilterDTO getSearchFilter()
    {
        return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            CustomerPymtSearchFilterDTO filterDTO = getSearchFilter();
            drpBO.drpDataBase(drpUnitNoFilter, DrpDataType.PR_TOWER_UNITS, drpTowerFilter.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            if (filterDTO.CustomerId > 0) drpCustomerFilter.Text = filterDTO.CustomerId.ToString(); else drpCustomerFilter.ClearSelection();
            if (filterDTO.CustRefNo != null) txtCustRefNoFilter.Text = filterDTO.CustRefNo; else txtCustRefNoFilter.Text = null;
            if (filterDTO.UnitId > 0) drpUnitNoFilter.Text = filterDTO.UnitId.ToString(); else drpUnitNoFilter.ClearSelection();
            if (filterDTO.BookingRefNo != null) txtBookingRefNoFilter.Text = filterDTO.BookingRefNo; else txtBookingRefNoFilter.Text = null;
            if (filterDTO.UnitSaleStatus != null) drpUnitSaleStatusFilter.Text = filterDTO.UnitSaleStatus.ToString(); else drpUnitSaleStatusFilter.ClearSelection();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onSelectFilterTower(object sender, EventArgs e)
    {
        try
        {
            drpBO.drpDataBase(drpUnitNoFilter, DrpDataType.PR_TOWER_UNITS, drpTowerFilter.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            activeModalHdn.Value = SearchFilterModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            CommonUtil.setStickyPrTowerDTO(getUserDefinitionDTO(), long.Parse(drpTowerFilter.Text), drpTowerFilter.SelectedItem.Text);
            CustomerPymtSearchFilterDTO filterDTO = new CustomerPymtSearchFilterDTO();
            if (!string.IsNullOrWhiteSpace(drpCustomerFilter.Text))
            {
                filterDTO.CustomerId = long.Parse(drpCustomerFilter.Text);
                filterDTO.CustomerName = drpCustomerFilter.SelectedItem.Text;
            }
            if (!string.IsNullOrWhiteSpace(txtCustRefNoFilter.Text))
            {
                filterDTO.CustRefNo = txtCustRefNoFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(drpUnitNoFilter.Text))
            {
                filterDTO.UnitId = long.Parse(drpUnitNoFilter.Text);
                filterDTO.UnitNo = drpUnitNoFilter.SelectedItem.Text;
            }
            if (!string.IsNullOrWhiteSpace(drpUnitSaleStatusFilter.Text))
            {
                filterDTO.BookingRefNo = drpUnitSaleStatusFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(drpUnitSaleStatusFilter.Text))
            {
                filterDTO.UnitSaleStatus = EnumHelper.ToEnum<PRUnitSaleStatus>(drpUnitSaleStatusFilter.Text);
            }
            setSearchFilter(filterDTO);
            loadPaymentSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            loadPaymentSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(CustomerPymtSearchFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new CustomerPymtSearchFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {
            drpTowerFilter.Text = CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Id.ToString();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            CustomerPymtSearchFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.CUSTOMER))
            {
                filterDTO.CustomerId = 0;
                filterDTO.CustomerName = "";
            }
            else if (token.StartsWith(Constants.FILTER.CUST_REF_NO)) filterDTO.CustRefNo = null;
            else if (token.StartsWith(Constants.FILTER.UNIT_NO))
            {
                filterDTO.UnitId = 0;
                filterDTO.UnitNo = "";
            }
            else if (token.StartsWith(Constants.FILTER.BOOKING_REF_NO)) filterDTO.BookingRefNo = null;
            else if (token.StartsWith(Constants.FILTER.STATUS)) filterDTO.UnitSaleStatus = null;
            else if (token.StartsWith(Constants.FILTER.TOWER_NAME)) (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyInfoMsg(Resources.Messages.TOWER_FILTER_DEFAULT));

            setSearchFilterTokens();
            loadPaymentSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        CustomerPymtSearchFilterDTO filterDTO = getSearchFilter();
        string filter = CommonUtil.addFilterToken("", Constants.FILTER.TOWER_NAME + CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Name);
        if (filterDTO != null)
        {
            if (filterDTO.CustomerId > 0) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.CUSTOMER + filterDTO.CustomerName);
            if (filterDTO.CustRefNo != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.CUST_REF_NO + filterDTO.CustRefNo);
            if (filterDTO.UnitId > 0) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.UNIT_NO + filterDTO.UnitNo);
            if (filterDTO.BookingRefNo != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.BOOKING_REF_NO + filterDTO.BookingRefNo);
            if (filterDTO.UnitSaleStatus != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.STATUS + filterDTO.UnitSaleStatus.ToString());
        }
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - PropertyUnit Search - End
}
