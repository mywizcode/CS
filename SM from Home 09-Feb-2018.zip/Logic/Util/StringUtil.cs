﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Mail;
/// <summary>
/// Summary description for EmailUtil
/// </summary>
using ConstroSoft;
using NHibernate;

namespace ConstroSoft
{
    public static class StringUtil
    {
        //Logger Instance
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public static string getActualValue(string str)
        {
            return (str != null) ? str.Trim() : null;
        }
        public static bool isValidLength(string str, int length)
        {
        	string tmpVal = getActualValue(str);
            return (tmpVal == null || tmpVal.Length <= length);
        }
        public static bool isValidDecimalNullable(string str)
        {
        	Decimal tmpVal;
            return (string.IsNullOrWhiteSpace(str) || Decimal.TryParse(str, out tmpVal));
        }
        public static bool isValidIntNullable(string str)
        {
        	int tmpVal;
            return (string.IsNullOrWhiteSpace(str) || int.TryParse(str, out tmpVal));
        }
        public static int getIntValue(string str)
        {
        	int tmpVal;
        	if(!string.IsNullOrWhiteSpace(str) && int.TryParse(str.Trim(), out tmpVal)) return tmpVal;
            return 0;
        }
    }
}