﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI.WebControls;
using ConstroSoft.Logic.Util;

/// <summary>
/// Summary description for UserDefinitionDTO
/// </summary>
namespace ConstroSoft
{
    //Page DTO START
	[Serializable]
    public class UserProfilePageDTO
    {
        public UserProfilePageDTO() { }
        public FirmMemberDTO FirmMember { get; set; }
    }
	[Serializable]
    public class CRMDashboardPageDTO
    {
        public CRMDashboardPageDTO() { }
        public int NoOfMonths { get; set; }
        public long TowerId { get; set; }
    }
    [Serializable]
    public class AvailableUnitPageDTO
    {
        public AvailableUnitPageDTO() { }
        public List<PropertyUnitDTO> SearchResult { get; set; }
        public PropertyUnitFilterDTO FilterDTO { get; set; }
    }
    [Serializable]
    public class PrPymtSchedulePageDTO
    {
        public PrPymtSchedulePageDTO() { }
        public List<PropertyScheduleDTO> SearchResult { get; set; }
    }
    [Serializable]
    public class CustomerSearchPageDTO
    {
        public CustomerSearchPageDTO() { }
        public List<CustomerDTO> SearchResult { get; set; }
        public CustomerFilterDTO FilterDTO { get; set; }
    }
    [Serializable]
    public class CustomerDetailPageDTO
    {
        public CustomerDetailPageDTO() { }
        public CustomerDTO CustomerDTO { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class FirmPageDTO
    {
        public FirmPageDTO() { }
        public FirmDTO SelectedFirm { get; set; }
    }
    [Serializable]
    public class PropertySearchPageDTO
    {
        public PropertySearchPageDTO() { }
        public List<PropertyDTO> SearchResult { get; set; }
        public PropertyFilterDTO FilterDTO { get; set; }
    }
    [Serializable]
    public class PropertyDetailPageDTO
    {
        public PropertyDetailPageDTO() { }
        public PropertyDTO PropertyDTO { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class VirtualPhoneUserAccessPageDTO
    {
        public VirtualPhoneUserAccessPageDTO() { }
        public PropertyDTO Property { get; set; }
        public List<VirtualPhoneDTO> VirtualPhoneList { get; set; }
        public List<FirmMemberDTO> UnassignedUserList { get; set; }
        public List<FirmMemberDTO> AssignedUserList { get; set; }
        public List<FirmMemberDTO> UIUnassignedUserList { get; set; }
        public List<FirmMemberDTO> UIAssignedUserList { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class PropertyUserAccessPageDTO
    {
        public PropertyUserAccessPageDTO() { }
        public PropertyDTO Property { get; set; }
        public List<FirmMemberDTO> UnassignedUserList { get; set; }
        public List<FirmMemberDTO> AssignedUserList { get; set; }
        public List<FirmMemberDTO> UIUnassignedUserList { get; set; }
        public List<FirmMemberDTO> UIAssignedUserList { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class PropertyUnitSearchPageDTO
    {
        public PropertyUnitSearchPageDTO() { }
        public List<PropertyUnitDTO> SearchResult { get; set; }
        public PropertyUnitFilterDTO FilterDTO { get; set; }
    }
    [Serializable]
    public class PropertyUnitDetailPageDTO
    {
        public PropertyUnitDetailPageDTO() { }
        public PropertyUnitDTO UnitDTO { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class PropertyUnitUploadPageDTO
    {
        public PropertyUnitUploadPageDTO() { }
        public List<PropertyUnitMapperDTO> UploadFailedResult { get; set; }
        public List<PropertyUnitMapperDTO> UploadSuccessResult { get; set; }
        public DropDownList drpUnitType { get; set; }
        public DropDownList drpDirection { get; set; }
        public DropDownList drpFacing { get; set; }
        public DropDownList drpTower { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class PropertyParkingSearchPageDTO
    {
        public PropertyParkingSearchPageDTO() { }
        public List<PropertyParkingDTO> SearchResult { get; set; }
        public PropertyParkingFilterDTO FilterDTO { get; set; }
    }
    [Serializable]
    public class PropertyParkingDetailPageDTO
    {
        public PropertyParkingDetailPageDTO() { }
        public PropertyParkingDTO ParkingDTO { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class PropertyParkingUploadPageDTO
    {
        public PropertyParkingUploadPageDTO() { }
        public List<PropertyParkingMapperDTO> UploadFailedResult { get; set; }
        public List<PropertyParkingMapperDTO> UploadSuccessResult { get; set; }
        public DropDownList drpParkingType { get; set; }
        public DropDownList drpTower { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class AvailableUnitSearchPageDTO
    {
        public AvailableUnitSearchPageDTO() { }
        public List<PropertyUnitDTO> SearchResult { get; set; }
        public PropertyUnitFilterDTO FilterDTO { get; set; }
    }
    [Serializable]
    public class SoldUnitSearchPageDTO
    {
        public SoldUnitSearchPageDTO() { }
        public List<PrUnitSaleDetailDTO> SearchResult { get; set; }
        public SoldUnitFilterDTO FilterDTO { get; set; }
    }
    
    [Serializable]
    public class CancelledUnitSearchPageDTO
    {
        public CancelledUnitSearchPageDTO() { }
        public List<PrUnitSaleDetailDTO> SearchResult { get; set; }
        public SoldUnitFilterDTO FilterDTO { get; set; }
    }
    [Serializable]
    public class SoldUnitDetailPageDTO
    {
        public SoldUnitDetailPageDTO() { }
        public PrUnitSaleDetailDTO PrUnitSaleDTO { get; set; }
        public PropertyUnitDTO UnitDTO { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class CancelledUnitDetailPageDTO
    {
        public CancelledUnitDetailPageDTO() { }
        public PrUnitSaleDetailDTO PrUnitSaleDTO { get; set; }
        public PropertyUnitDTO UnitDTO { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class LetterGenerationPageDTO
    {
        public LetterGenerationPageDTO() { }
        public PrUnitSaleDetailDTO PrUnitSaleDTO { get; set; }
        public PropertyUnitDTO UnitDTO { get; set; }
        public PropertyScheduleDTO StageDTO { get; set; }
        public List<DemandLetterHistoryDTO> dlHistoryList { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class CustomerCallHistoryPageDTO
    {
        public CustomerCallHistoryPageDTO() { }
        public PrUnitSaleDetailDTO PrUnitSaleDTO { get; set; }
        public List<CallHistoryDTO> CallHistoryList { get; set; }
        public CallHistoryFilterDTO FilterDTO { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class ManageBookingUnitDocsPageDTO
    {
        public ManageBookingUnitDocsPageDTO() { }
        public PrUnitSaleDetailDTO PrUnitSaleDTO { get; set; }
        public string BookedUnitHomePath { get; set; }
        public string CustomerHomePath { get; set; }
        public string CurrentAbsPath { get; set; }
        public List<FileUIDTO> FileList { get; set; }
        public List<FilePathBreadCrumbDTO> PathList { get; set; }
        public List<DemandLetterHistoryDTO> dlHistoryList { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class PaymentReceiptDocsPageDTO
    {
        public PaymentReceiptDocsPageDTO() { }
        public PrUnitSaleDetailDTO PrUnitSaleDTO { get; set; }
        public string BookedUnitHomePath { get; set; }
        public string CustomerHomePath { get; set; }
        public string CurrentAbsPath { get; set; }
        public List<FileUIDTO> FileList { get; set; }
        public List<FilePathBreadCrumbDTO> PathList { get; set; }
        public List<PaymentReceiptHistoryDTO> dlHistoryList { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class BookingFormPageDTO
    {
        public BookingFormPageDTO() { }
        public PrUnitSaleDetailDTO PrUnitSaleDetail { get; set; }
        public PropertyUnitDTO UnitDTO { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class BookingSuccessPageDTO
    {
        public BookingSuccessPageDTO() { }
        public PrUnitSaleDetailDTO UnitSaleDetailDTO { get; set; }
    }
    [Serializable]
    public class BookingCancellationPageDTO
    {
        public BookingCancellationPageDTO() { }
        public BookingCancellatonUIDTO PrUnitSaleDTO { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class BookingCancelSuccessPageDTO
    {
        public BookingCancelSuccessPageDTO() { }
        public PrUnitSaleDetailDTO UnitSaleDetailDTO { get; set; }
    }
    [Serializable]
    public class CustomerPymtSearchPageDTO
    {
        public CustomerPymtSearchPageDTO() { }
        public List<CustomerPymtSearchDTO> SearchResult {get; set;}
        public CustomerPymtSearchFilterDTO FilterDTO {get; set;}
    }
    [Serializable]
    public class CustomerPaymentHistoryPageDTO
    {
        public CustomerPaymentHistoryPageDTO() { }
        public PrUnitSaleDetailDTO PrUnitSaleDetail { get; set; }
        public PaymentMode PymtMode { get; set; }
        public string isMultiplePymts { get; set; }
        public TotalPymtDTO TotalPymtDTO { get; set; }
        public List<PrUnitSalePymtDTO> PymtHeaders { get; set; }
        public List<MasterPymtTransactionDTO> MasterPymtTransDTOs { get; set; }
        public List<MPTHistoryUIDTO> PymtTransHistoryUIDTOs { get; set; }
        public List<MPTHistoryUIDTO> PdcUIDTOs { get; set; }
        public object PrevNavDTO { get; set; }
        public string CurrentAbsPath { get; set; }
        public CustomerPymtTxHistoryFilterDTO FilterDTO { get; set; }
    }
    [Serializable]
    public class CustomerPaymentPageDTO
    {
        public CustomerPaymentPageDTO() { }
        public PrUnitSaleDetailDTO PrUnitSaleDetail { get; set; }
        public bool IsPdcPayment { get; set; }
        public PaymentMode PymtMode { get; set; }
        public string isMultiplePymts { get; set; }
        public TotalPymtDTO TotalPymtDTO { get; set; }
        public List<PrUnitSalePymtDTO> PymtHeaders { get; set; }
        public MasterPymtTransactionDTO MasterPymtTxDTO { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class EnquirySearchPageDTO
    {
        public EnquirySearchPageDTO() { }
        public List<EnquiryDetailDTO> SearchResult { get; set; }
        public EnquiryFilterDTO FilterDTO { get; set; }
    }
    [Serializable]
    public class EnquiryDetailPageDTO
    {
        public EnquiryDetailPageDTO() { }
        public EnquiryDetailDTO EnquiryDTO { get; set; }
        public LeadDetailDTO LeadDTO { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class EnquiryActivityHistoryPageDTO
    {
        public EnquiryActivityHistoryPageDTO() { }
        public EnquiryDetailDTO EnquiryDTO { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class LeadActivityHistoryPageDTO
    {
        public LeadActivityHistoryPageDTO() { }
        public LeadDetailDTO LeadDTO { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class AllEnquiryLeadHistoryPageDTO
    {
        public AllEnquiryLeadHistoryPageDTO() { }
        public List<AllEnquiryLeadUIDTO> SearchResult { get; set; }
    }
    [Serializable]
    public class UserEnquiryHistoryPageDTO
    {
        public UserEnquiryHistoryPageDTO() { }
        public long FirmMemberId { get; set; }
        public List<UserEnquiryHistoryUIDTO> SearchResult { get; set; }
        public AllEnquiryLeadUIDTO EnquirySummary { get; set; }
        public EnquiryFilterDTO FilterDTO { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class UserLeadHistoryPageDTO
    {
        public UserLeadHistoryPageDTO() { }
        public long FirmMemberId { get; set; }
        public List<UserLeadHistoryUIDTO> SearchResult { get; set; }
        public AllEnquiryLeadUIDTO LeadSummary { get; set; }
        public LeadFilterDTO FilterDTO { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class LeadAssignmentPageDTO
    {
        public LeadAssignmentPageDTO() { }
        public List<AllEnquiryLeadUIDTO> SearchResult { get; set; }
        public List<UserLeadHistoryUIDTO> NewLeads { get; set; }
        public List<UserLeadHistoryUIDTO> AssignedLeads { get; set; }
    }
	[Serializable]
    public class CallHistoryPageDTO
    {
        public CallHistoryPageDTO() { }
        public List<CallHistoryDTO> SearchResult { get; set; }
        public CallHistoryFilterDTO FilterDTO { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class UnresolvedCallsPageDTO
    {
        public UnresolvedCallsPageDTO() { }
        public List<UnresolvedCallGroupInfoDTO> SearchResult { get; set; }
        public UnresolvedCallsFilterDTO FilterDTO { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class ResolveCallPageDTO
    {
        public ResolveCallPageDTO() { }
        public string CustomerNumber { get; set; }
        public List<CallHistoryDTO> SearchResult { get; set; }
        public List<VwCustomer> MatchingEntityList { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class MyLeadsPageDTO
    {
        public MyLeadsPageDTO() { }
        public List<LeadDetailDTO> SearchResult { get; set; }
        public LeadFilterDTO FilterDTO { get; set; }
        public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class PropertyFundSearchPageDTO
    {
        public PropertyFundSearchPageDTO() { }
        public List<PropertyFundsDTO> SearchResult { get; set; }
        public PropertyFundFilterDTO FilterDTO { get; set; }
    }
    [Serializable]
    public class PropertyFundPageDTO
    {
          public PropertyFundPageDTO() { }
          public bool IsPdcPayment { get; set; }
          public PaymentMode PymtMode { get; set; }
          public PropertyFundsDTO PropertyFundsDTO { get; set; }
          public object PrevNavDTO { get; set; }
    }
    [Serializable]
    public class MasterDataSetupPageDTO
    {
          public MasterDataSetupPageDTO() { }
          public List<MasterControlDataDTO> SearchResult { get; set; }
          public object PrevNavDTO { get; set; }
    }
    
    //Page DTO END
    [Serializable]
    public class CustomerPymtSearchDTO
    {
        public CustomerPymtSearchDTO() { }
        public long UnitSaleDetailId {get; set;}
        public string BookingRefNo {get; set;}
        public string CustomerName {get; set;}
        public string CustRefNo {get; set;}
        public long CustomerId {get; set;}
        public string PrTowerName {get; set;}
        public long PrTowerId {get; set;}
        public string UnitNo {get; set;}
        public PRUnitSaleStatus UnitSaleStatus {get; set;}
        public TotalPymtDTO TotalReceivablePymt { get; set; }
        public TotalPymtDTO TotalPayablePymt { get; set; }
        public PymtMasterStatus PymtStatus { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class TotalPymtDTO
    {
        public TotalPymtDTO() { }
        public decimal TotalPymtAmt { get; set; }
        public decimal TotalPaidAmt { get; set; }
        public decimal TotalPendingAmt { get; set; }
        public PymtMasterStatus PymtStatus { get; set; }
        public bool isUISelected { get; set; }
    }
    [Serializable]
    public class MPTHistoryUIDTO
    {
        public MPTHistoryUIDTO() { }
        public long Id { get; set; }
        public string TxRefNo { get; set; }
        public string PymtType { get; set; }
        public bool ShowSplit { get; set; }
        public string AccountName { get; set; }
        public PaymentMethod PymtMethod { get; set; }
        public System.DateTime TxDate { get; set; }
        public decimal PymtAmt { get; set; }
        public System.Nullable<System.DateTime> CollectionDate { get; set; }
        public System.Nullable<System.DateTime> ChequeDate { get; set; }
        public System.Nullable<System.DateTime> ClearanceDate { get; set; }
        public string PayName { get; set; }
        public string BankName { get; set; }
        public string Branch { get; set; }        
        public string MediaNo { get; set; }
        public ChequeStatus? ChequeStatus { get; set; }
        public string Comments { get; set; }
        public MPTPymtStatus PymtStatus { get; set; }     
        public bool ReceiptDelivered {get; set;}
        public List<MPTDistributionDTO> PymtDistributions {get; set;}
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class MPTDistributionDTO
    {
        public MPTDistributionDTO() { }
        public long PymtTxId { get; set; }
        public MasterControlDataDTO PymtType { get; set; }
        public FirmAccountDTO FirmAccount { get; set; }
        public decimal Amount { get; set; }
        public string Comments { get; set; }
        public long UiIndex { get; set; }
        public bool isUISelected { get; set; }
        public string RowInfo { get; set; }
    }
    [Serializable]
    public class AllEnquiryLeadUIDTO
    {
        public AllEnquiryLeadUIDTO() { }
        public long FirmMemberId { get; set; }
        public string Salutation { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FullName { get; set; }
        public string UserName { get; set; }
        public string ProfileImgPath { get; set; }
        public string Contact { get; set; }
        public string Email { get; set; }
        public UserStatus Status { get; set; }
        public PrFMAccess PropertyFMAccess { get; set; }
        public int LeadsOpen { get; set; }
        public int LeadsConverted { get; set; }
        public int LeadsLost { get; set; }
        public int LeadsClosed { get; set; }
        public int EnquiriesOpen { get; set; }
        public int EnquiriesLost { get; set; }
        public int EnquiriesWon { get; set; }
        public int EnquiriesClosed { get; set; }
        public bool isUISelected { get; set; }
    }
    [Serializable]
    public class UserEnquiryHistoryUIDTO
    {
        public UserEnquiryHistoryUIDTO() { }
        public long EnquiryId { get; set; }
        public string Salutation { get; set; }
        public string CustFirstName { get; set; }
        public string CustMiddleName { get; set; }
        public string CustLastName { get; set; }
        public string CustFullName { get; set; }
        public string Contact { get; set; }
        public string Email { get; set; }
        public System.Nullable<decimal> Budget { get; set; }
        public string EnquiryRefNo { get; set; }
        public long LeadId { get; set; }
        public string LeadRefNo { get; set; }
        public long PrUnitSaleId { get; set; }
        public PRUnitSaleStatus UnitSaleStatus { get; set; }
        public DateTime EnquiryDate { get; set; }
        public DateTime AssignedDate { get; set; }
        public String Source { get; set; }
        public int NoOfDaysAssgined { get; set; }
        public DateTime? LastActivity { get; set; }
        public EnquiryStatus Status { get; set; }
        public CallHistoryDTO callHistory { get; set; }
        public bool isUISelected { get; set; }
    }
    [Serializable]
    public class UserLeadHistoryUIDTO
    {
        public UserLeadHistoryUIDTO() { }
        public long LeadId { get; set; }
        public string Salutation { get; set; }
        public string CustFirstName { get; set; }
        public string CustMiddleName { get; set; }
        public string CustLastName { get; set; }
        public string CustFullName { get; set; }
        public string EnquiryRefNo { get; set; }
        public string LeadRefNo { get; set; }
        public string Contact { get; set; }
        public string Email { get; set; }
        public System.Nullable<decimal> Budget { get; set; }
        public long EnquiryId { get; set; }
        public DateTime LeadDate { get; set; }
        public DateTime AssignedDate { get; set; }
        public String Source { get; set; }
        public int NoOfDaysAssgined { get; set; }
        public int NoOfDaysCreated { get; set; }
        public DateTime? LastActivity { get; set; }
        public LeadStatus Status { get; set; }
        public bool isUISelected { get; set; }
    }
    [Serializable]
    public class BookingCancellatonUIDTO
    {
        public BookingCancellatonUIDTO() { }
        public long SaleDetailId { get; set; }
        public string BookingRefNo { get; set; }
        public System.DateTime BookingDate { get; set; }
        public IsAgreementDone IsAgreementDone { get; set; }
        public System.Nullable<System.DateTime> AgreementDate { get; set; }
        public IsPossessionDone IsPossessionDone { get; set; }
        public System.Nullable<System.DateTime> PossessionDate { get; set; }
        public decimal AgreementAmt { get; set; }
        public PropertyUnitDTO PropertyUnit { get; set; }
        public CustomerDTO Customer { get; set; }
        public TotalPymtDTO TotalReceivablePymt { get; set; }
        public TotalPymtDTO TotalPayablePymt { get; set; }
        public List<PrUnitSalePymtDTO> ReceivablePymts { get; set; }
        public List<PrUnitSalePymtDTO> PayablePymts { get; set; }
        public PrUnitSalePymtDTO TmpSalePymtDTO { get; set; }
    }
    [Serializable]
    public class FilePathBreadCrumbDTO
    {
        public FilePathBreadCrumbDTO() { }
        public string FullPath { get; set; }
        public string Name { get; set; }
        public bool isUISelected { get; set; }
        public long UiIndex { get; set; }
    }
    [Serializable]
    public class FileUIDTO
    {
        public FileUIDTO() { }
        public string FullPath { get; set; }
        public string ParentPath { get; set; }
        public string Name { get; set; }
        public System.Nullable<System.DateTime> CreateDate { get; set; }
        public string size { get; set; }
        public string DocumentType { get; set; }
        public string AdditionalInfo { get; set; }
        public bool IsMarked { get; set; }
        public string ExtraMarkedInfo { get; set; }
        public FileType FileType { get; set; }
        public HttpPostedFile userPostedFile { get; set; }
        public List<FileUIDTO> FileList { get; set; }
        public bool isUISelected { get; set; }
        public long UiIndex { get; set; }
    }
    [Serializable]
    public class EnquiryLeadSourceWiseCountDTO
    {
        public EnquiryLeadSourceWiseCountDTO() { }
        public string SourceName { get; set; }
        public int Count { get; set; }
    }
    [Serializable]
    public class LeadsOpenedGadgetDTO
    {
        public LeadsOpenedGadgetDTO() { }
        public int TotalCount { get; set; }
        public decimal AverageOpened { get; set; }
        public List<LeadsOpenedCountDTO> LeadsOpenedList { get; set; }
    }
    [Serializable]
    public class LeadsNewOpenWeekDTO
    {
        public LeadsNewOpenWeekDTO() { }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public LeadsOpenedCountDTO CountDTO { get; set; }
    }
    [Serializable]
    public class LeadsOpenedCountDTO
    {
        public LeadsOpenedCountDTO() { }
        public string Date { get; set; }
        public string FromDate { get; set; }
        public int Count { get; set; }
    }
    [Serializable]
    public class LeadsProcessedCountDTO
    {
        public LeadsProcessedCountDTO() { }
        public int TotalProcessed { get; set; }
        public int TotalConverted { get; set; }
        public int TotalLost { get; set; }
    }
    [Serializable]
    public class EnquiryNewOpenAndCloseWeekDTO
    {
        public EnquiryNewOpenAndCloseWeekDTO() { }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public EnquiryNewOpenAndCloseCountDTO CountDTO { get; set; }
    }
    [Serializable]
    public class EnquiryNewOpenAndCloseCountDTO
    {
        public EnquiryNewOpenAndCloseCountDTO() { }
        public string Date { get; set; }
        public string FromDate { get; set; }
        public int OpenCount { get; set; }
        public int CloseCount { get; set; }
    }
    [Serializable]
    public class EnquiryCurrentOpenCountDTO
    {
        public EnquiryCurrentOpenCountDTO() { }
        public string Date { get; set; }
        public int OpenCount { get; set; }
    }
    [Serializable]
    public class EnquiryCountStatsDTO
    {
        public EnquiryCountStatsDTO() { }
        public int TotalLogged { get; set; }
        public int TotalClosed { get; set; }
        public int TotalOpen { get; set; }
    }
    [Serializable]
    public class PropertyUnitStatsDTO
    {
        public PropertyUnitStatsDTO() { }
        public int Available { get; set; }
        public int Sold { get; set; }
        public int Reserved { get; set; }
        public List<AvailableUnitTypeCountDTO> UnitTypeCountList { get; set; }
    }
    [Serializable]
    public class AvailableUnitTypeCountDTO
    {
        public AvailableUnitTypeCountDTO() { }
        public string UnitType { get; set; }
        public int Count { get; set; }
    }
    [Serializable]
    public class ManageCustomerDocsPageDTO
    {
        public ManageCustomerDocsPageDTO() { }
        public CustomerDTO CustomerDTO { get; set; }
        public string BookedUnitHomePath { get; set; }
        public string CustomerHomePath { get; set; }
        public string CurrentAbsPath { get; set; }
        public List<FileUIDTO> FileList { get; set; }
        public List<FilePathBreadCrumbDTO> PathList { get; set; }
        public object PrevNavDTO { get; set; }
   }
   [Serializable]
   public class ManagePropertyDocsPageDTO
   {
       public ManagePropertyDocsPageDTO() { }
       public PropertyDTO PropertyDTO { get; set; }
       public string PropertyHomePath { get; set; }
       public string CurrentAbsPath { get; set; }
       public List<FileUIDTO> FileList { get; set; }
       public List<FilePathBreadCrumbDTO> PathList { get; set; }
       public object PrevNavDTO { get; set; }
   }
   [Serializable]
   public class VoucherSearchPageDTO
   {
       public VoucherSearchPageDTO() { }
       public List<PaymentVoucherDTO> SearchResult { get; set; }
       public VoucherFilterDTO FilterDTO { get; set; }
   }
   [Serializable]
   public class PaymentDueReportPageDTO
   {
        public PaymentDueReportPageDTO() { }
        public object PrevNavDTO { get; set; }
   }
   [Serializable]
   public class FirmAccountPageDTO
   {
        public FirmAccountPageDTO() { }
        public List<FirmAccountDTO> SearchResult { get; set; }
        public FirmAccountDTO SelectedAccount { get; set; }
   }
   [Serializable]
   public class FirmAccountStatementPageDTO
   {
       public FirmAccountStatementPageDTO() { }
       public List<AccountTransactionDTO> AccountTransactions { get; set; }
       public FirmAccountDTO SelectedAccount { get; set; }
       public object PrevNavDTO { get; set; }
   }
}