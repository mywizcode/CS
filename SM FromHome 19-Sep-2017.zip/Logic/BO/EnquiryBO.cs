﻿using System;
using NHibernate;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using ConstroSoft;
using System.Collections.Generic;
using NHibernate.Criterion;
using NHibernate.Transform;
using System.Net.Mail;
using System.Net.Mime;

/// <summary>
/// Summary description for SupplierBO
/// </summary>
namespace ConstroSoft
{
    public class EnquiryBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public EnquiryBO() { }
        public EnquiryDetailDTO fetchEnquiryDetails(long Id, bool fetchFollowups)
        {
            ISession session = null;
            EnquiryDetailDTO enquiryDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EnquiryDetail enquiry = session.Get<EnquiryDetail>(Id);
                        enquiryDto = DomainToDTOUtil.convertToEnquiryDetailDTO(enquiry, fetchFollowups);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Enquiry details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return enquiryDto;
        }
        public long addEnquiryDetails(EnquiryDetailDTO enquiryDto)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                EnquiryDetail enquiry = null;
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        enquiry = DTOToDomainUtil.populateEnquiryDetailAddFields(enquiryDto);
                        Random rd = new Random();
                        enquiry.EnquiryRefNo = CommonUtil.getRandomRefNo();
                        session.Save(enquiry);
                        Id = enquiry.Id;
                        enquiry.EnquiryRefNo = CommonUtil.getEnquiryRefNo(Id);
                        session.Update(enquiry);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Enquiry details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
                sendSMSEmail(enquiry);
             }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        /**
         * This method will check Email & SMS configuration for Enquiry Function. 
         * If Email & SMS alerts are enabled then system will send Email & SMS to Customer.
         * */
        private static void sendSMSEmail(EnquiryDetail enquiry)
        {
            try
            {
                PropertyAlertConfig emailSmsAlertConfig = EmailUtil.loadEmailSmsAlertConfiguration(enquiry.FirmNumber,
                    FunctionName.ENQUIRY.ToString(), EmailSmsType.ENQUIRYTHANKS.ToString(), enquiry.Property.Id);
                PropertyBO propertyBO = new PropertyBO();
                PropertyDTO propertyDTO = propertyBO.fetchProperty(enquiry.Property.Id);
                if (emailSmsAlertConfig != null && emailSmsAlertConfig.Email.Equals(Constants.YES))
                {
                    emailSmsAlertConfig.EmailBody = populateBody(enquiry, emailSmsAlertConfig, propertyDTO.Name);
                    EmailUtil.sendHtmlFormattedEmail(enquiry.FirmNumber, emailSmsAlertConfig, enquiry.ContactInfo.Email);
                }
                if (emailSmsAlertConfig != null && emailSmsAlertConfig.Sms.Equals(Constants.YES))
                {
                    emailSmsAlertConfig.SmsContent = populateSMSBody(enquiry, emailSmsAlertConfig, propertyDTO.Name);
                    EmailUtil.sendSMS(enquiry.FirmNumber, emailSmsAlertConfig, enquiry.ContactInfo.Contact);
                }
            }
            catch (Exception e)
            {
                log.Error("Exception while sending Email & SMS alert for enquiry:", e);
            }
        }
        private static string populateBody(EnquiryDetail enquiry, PropertyAlertConfig emailSmsAlertConfig, string propertyName)
        {
            string body = string.Empty;
            using (StreamReader reader = new StreamReader(System.Web.HttpContext.Current.Server.MapPath(emailSmsAlertConfig.EmailTemplatePath)))
            {
                body = reader.ReadToEnd();
            }
            body = body.Replace("{UserName}", enquiry.Salutation.Name + " " + enquiry.FirstName + " " + enquiry.LastName);
            body = body.Replace("{PropertyName}", propertyName);
            return body;
        }
        private static string populateSMSBody(EnquiryDetail enquiry, PropertyAlertConfig emailSmsAlertConfig, string propertyName)
        {
            string body = string.Empty;
            body = emailSmsAlertConfig.SmsContent.Replace("{UserName}", enquiry.Salutation.Name + " " +enquiry.FirstName + " " + enquiry.LastName);
            body = emailSmsAlertConfig.SmsContent.Replace("{PropertyName}", propertyName);
            return body;
        }
        public void closeEnquiry(long enquiryId, String closeReason)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        string hqlUpdate = "update EnquiryDetail ed set ed.Status = :status, ed.CloseReason = :closeReason where ed.Id = :Id";
                        session.CreateQuery(hqlUpdate)
                                .SetEnum("status", EnquiryStatus.Lost)
                                .SetString("closeReason", closeReason)
                                .SetString("Id", enquiryId.ToString())
                                .ExecuteUpdate();
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while making Enquiry Close:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }

        }
        public void openEnquiry(long enquiryId, String reason)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        string hqlUpdate = "update EnquiryDetail ed set ed.Status = :status, ed.CloseReason = :closeReason where ed.Id = :Id";
                        session.CreateQuery(hqlUpdate)
                                .SetEnum("status", EnquiryStatus.Open)
                                .SetString("closeReason", reason)
                                .SetString("Id", enquiryId.ToString())
                                .ExecuteUpdate();
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while making Enquiry Close:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }

        }
    }
}