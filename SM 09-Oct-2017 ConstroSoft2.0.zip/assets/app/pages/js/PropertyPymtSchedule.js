﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initPymtScheduleGrid();
    formatFields();
    showModal();
}

function initPymtScheduleGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "pymtScheduleGrid",
        pageLength: 10,
        isViewOnly: isViewOnly,
        customBtnGrpId: "#pymtScheduleGridBtnDiv",
        hideSearch: true,
        sortable: false
    };
    var dtTable = applyActionDataTable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitHdnId");
}




