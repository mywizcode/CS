﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
	formatFields();
    showModal();
}
