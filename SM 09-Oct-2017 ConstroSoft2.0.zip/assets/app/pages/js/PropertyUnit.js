﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initUnitSearchGrid();
    initPropertyUnitUploadGrid();
    formatFields();
    showModal();
}

function initUnitSearchGrid() {
    var dtOptions = {
        tableId: "propertyUnitSearchGrid",
        pageLength: 10,
        isViewOnly: false,
        customBtnGrpId: "#propertyUnitSearchBtnDiv",
        hideSearch: false
    };
    var dtTable = applyActionDataTable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitHdnId");
}
function initPropertyUnitUploadGrid() {
    var dtOptions = {
        tableId: "unitUploadGrid",
        pageLength: 10,
        responsiveModalTitle: "Unit Details",
        isViewOnly: true,
        hideSearch: false,
        allSortable: true
    };
    var dtTable = applyActionDataTable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitUploadHdnId");
}
function unblockUI() {
    alert("Hi");
    $.unblock();
}




