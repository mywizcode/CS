﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using ConstroSoft.Logic.BO;

public partial class BookingCancellation : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    DropdownBO drpBO = new DropdownBO();
    SoldPropertyUnitBO soldUnitBO = new SoldPropertyUnitBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                BookingCancellationNavDTO navDto = (BookingCancellationNavDTO)Session[Constants.Session.NAV_DTO];
                Session.Remove(Constants.Session.NAV_DTO);
                Session.Remove(Constants.Session.PAGE_DATA);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(Constants.URL.DEFAULT_HOME_PAGE, false);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();

    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
       
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(BookingCancellationNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(BookingCancellationNavDTO navDto)
    {
        try
        {
            BookingCancellationPageDTO PageDTO = new BookingCancellationPageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            PageDTO.PrUnitSaleDTO = soldUnitBO.fetchPrUnitDetailsForCancellation(navDto.PrUnitSaleDetailId);
            fetchAndInitPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageFieldsWithEntitlement()
    {
        

    }
    private void navigateToPreviousPage()
    {
        BookingCancellationPageDTO PageDTO = getSessionPageData();
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is SoldUnitSearchPageDTO)
            {
                SoldUnitSearchPageDTO navDTO = (SoldUnitSearchPageDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.SOLD_UNIT_SEARCH, true);
            }
        }
        Response.Redirect(Constants.URL.SOLD_UNIT_SEARCH, true);
    }
    private BookingCancellationPageDTO getSessionPageData()
    {
        return (BookingCancellationPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private BookingCancellatonUIDTO getSaleDetailDTO()
    {
        return getSessionPageData().PrUnitSaleDTO;
    }
    private void fetchAndInitPage() {
    	BookingCancellatonUIDTO saleDetailDTO = getSaleDetailDTO();
    	lbCustomerName.Text = CommonUIConverter.getCustomerFullName(saleDetailDTO.Customer.Salutation.Name, saleDetailDTO.Customer.FirstName, "", saleDetailDTO.Customer.LastName);
    	lbCustomerContact.Text = saleDetailDTO.Customer.ContactInfo.Contact;
    	lbUnitNo.Text = CommonUIConverter.getPropertyUnitFormattedNo(saleDetailDTO.PropertyUnit.Wing, saleDetailDTO.PropertyUnit.UnitNo);
    	lbPrTower.Text = saleDetailDTO.PropertyUnit.PropertyTower.Name;
    	lbBookingRefNo.Text = saleDetailDTO.BookingRefNo;
    	lbBookingDate.Text = CommonUtil.getCSDate(saleDetailDTO.BookingDate);
    	lbAgreementAmount.Text = saleDetailDTO.AgreementAmt.ToString();
    	
    	List<PrUnitSalePymtDTO> tmpList = new List<PrUnitSalePymtDTO>();
    	tmpList.AddRange(saleDetailDTO.ReceivablePymts);
    	tmpList.AddRange(saleDetailDTO.PayablePymts);
    	PymtDetailGrid.DataSource = tmpList;
        PymtDetailGrid.DataBind();
    	
    	bool isPayableExist = saleDetailDTO.PayablePymts.Count > 0;
        pnlSummaryWithoutPayable.Visible = !isPayableExist;
        pnlSummaryWithPayable.Visible = isPayableExist;
    	if(!isPayableExist) {
            lbTotalRecPymtAmt.Text = saleDetailDTO.TotalReceivablePymt.TotalPymtAmt.ToString();
    		lbTotalRecPaidAmt.Text = saleDetailDTO.TotalReceivablePymt.TotalPaidAmt.ToString();
    	} else {
    		lbTotalRecPymtAmt1.Text = saleDetailDTO.TotalReceivablePymt.TotalPymtAmt.ToString();
    		lbTotalRecPaidAmt1.Text = saleDetailDTO.TotalReceivablePymt.TotalPaidAmt.ToString();
    		lbTotalPayPymtAmt1.Text = saleDetailDTO.TotalPayablePymt.TotalPymtAmt.ToString();
    		lbTotalPayPaidAmt1.Text = saleDetailDTO.TotalPayablePymt.TotalPaidAmt.ToString();
    	}
        calculateAndSetTotalPymtToCustomer();
        
    	txtCancellationDate.Text = CommonUtil.getTodayDate();
    }
    private void calculateAndSetTotalPymtToCustomer()
    {
        BookingCancellatonUIDTO saleDetailDTO = getSaleDetailDTO();
        decimal PymtToCustomer = calculateTotalPymtToCustomer();
        if (saleDetailDTO.PayablePymts.Count > 0) lbTotalPymtToCustomer1.Text = PymtToCustomer.ToString();
        else lbTotalPymtToCustomer.Text = PymtToCustomer.ToString();
    }
    private decimal calculateTotalPymtToCustomer() {
    	BookingCancellatonUIDTO saleDetailDTO = getSaleDetailDTO();
    	decimal cancellationCharge = CommonUtil.getDecimaNotNulllWithoutExt(txtCancellationCharge.Text);
    	decimal PymtToCustomer = Decimal.Subtract(saleDetailDTO.TotalReceivablePymt.TotalPaidAmt, saleDetailDTO.TotalPayablePymt.TotalPaidAmt);
    	PymtToCustomer = Decimal.Subtract(PymtToCustomer, cancellationCharge);
    	PymtToCustomer = (PymtToCustomer > 0) ? PymtToCustomer : decimal.Zero;
        return PymtToCustomer;
    }
    protected void reCalculatePymtToCustomer(object sender, EventArgs e)
    {
        try
        {
            calculateAndSetTotalPymtToCustomer();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void CancelPropertyUnit(object sender, EventArgs e)
    {
        try
        {
            if(validateBookingCancellation()) {
            	PrUnitSaleDetailDTO cancellationDTO = populatePrUnitSaleDetilFromUI();
                soldUnitBO.cancelPropertyUnitBooking(cancellationDTO, getUserDefinitionDTO());
                navigateToPreviousPage();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateBookingCancellation() {
        return validateMandatoryFields(commonError);
    }
    private bool validateMandatoryFields(string valGrp)
    {
        Page.Validate(valGrp);
        bool isValid = Page.IsValid;
        if (!isValid)
        {
        	scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    private PrUnitSaleDetailDTO populatePrUnitSaleDetilFromUI()
    {
        BookingCancellatonUIDTO tmpUIDTO = getSaleDetailDTO();
        PrUnitSaleDetailDTO saleDetailDTO = new PrUnitSaleDetailDTO();
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        saleDetailDTO.Id = tmpUIDTO.SaleDetailId;
        saleDetailDTO.PropertyUnit = tmpUIDTO.PropertyUnit;
        saleDetailDTO.Customer = tmpUIDTO.Customer;
        saleDetailDTO.CanellationDate = CommonUtil.getCSDate(txtCancellationDate.Text);
        saleDetailDTO.CancellationFee = CommonUtil.getDecimalWithoutExt(txtCancellationCharge.Text);
        saleDetailDTO.CancellationReason = txtCancellationComments.Text;
        saleDetailDTO.CancellationFirmMember = userDefDto.FirmMember;
        saleDetailDTO.UpdateUser = userDefDto.Username;
        saleDetailDTO.Status = PRUnitSaleStatus.Cancelled;
        saleDetailDTO.PrUnitSalePymts = new HashSet<PrUnitSalePymtDTO>();
        decimal pymtToCustomer = calculateTotalPymtToCustomer();

        if (pymtToCustomer > 0)
        {
            PrUnitSalePymtDTO prUnitSalePymtDto = new PrUnitSalePymtDTO();
            prUnitSalePymtDto.PymtType = masterDataBO.fetchMasterData(userDefDto.FirmNumber, Constants.MCDType.PR_UNIT_PYMT_TYPE, Constants.MCD_CANCELLATION_PAYMENT);
            prUnitSalePymtDto.PymtDate = saleDetailDTO.CanellationDate.Value;
            prUnitSalePymtDto.PymtMode = PaymentMode.Payable;
            prUnitSalePymtDto.PymtAmt = calculateTotalPymtToCustomer();
            prUnitSalePymtDto.Description = "Unit Cancellation Payment.";
            prUnitSalePymtDto.UpdateUser = userDefDto.Username;
            saleDetailDTO.PrUnitSalePymts.Add(prUnitSalePymtDto);

            prUnitSalePymtDto.FirmNumber = userDefDto.FirmNumber;
            prUnitSalePymtDto.InsertUser = userDefDto.Username;
            addNewPymtMaster(prUnitSalePymtDto);
        }

        return saleDetailDTO;
    }
    private void addNewPymtMaster(PrUnitSalePymtDTO prUnitSalePymtDto)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        PaymentMasterDTO paymentMasterDto = new PaymentMasterDTO();
        paymentMasterDto.TotalAmt = Decimal.Zero;
        paymentMasterDto.TotalPaid = Decimal.Zero;
        paymentMasterDto.TotalPending = Decimal.Zero;
        paymentMasterDto.TotalPdcAmt = Decimal.Zero;
        paymentMasterDto.FirmNumber = userDefDto.FirmNumber;
        paymentMasterDto.InsertUser = userDefDto.Username;
        prUnitSalePymtDto.PaymentMaster = paymentMasterDto;
        updatePymtMaster(prUnitSalePymtDto);
    }
    private void updatePymtMaster(PrUnitSalePymtDTO prUnitSalePymtDto)
    {
        PaymentMasterDTO paymentMasterDto = prUnitSalePymtDto.PaymentMaster;
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        decimal diffAmt = Decimal.Subtract(prUnitSalePymtDto.PymtAmt, paymentMasterDto.TotalAmt);
        paymentMasterDto.TotalAmt = Decimal.Add(paymentMasterDto.TotalAmt, diffAmt);
        paymentMasterDto.TotalPending = Decimal.Subtract(paymentMasterDto.TotalAmt, paymentMasterDto.TotalPaid);
        paymentMasterDto.UpdateUser = userDefDto.Username;
        if (paymentMasterDto.TotalPending > 0) paymentMasterDto.Status = PymtMasterStatus.Pending;
        else paymentMasterDto.Status = PymtMasterStatus.Paid;
    }
}