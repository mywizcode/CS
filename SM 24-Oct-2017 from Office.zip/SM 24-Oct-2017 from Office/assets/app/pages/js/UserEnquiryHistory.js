﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initUserEnquiryHistorySearchGrid();
    formatFields();
    showModal();
}

function initUserEnquiryHistorySearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        pageLength: 10,
        hideSearch: true
    };

    $("[id$='userEnquiryHistorySearchGrid']").CSBasicDatatable(dtOptions);
}




