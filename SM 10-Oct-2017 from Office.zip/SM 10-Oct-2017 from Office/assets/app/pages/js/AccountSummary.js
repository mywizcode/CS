﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initAccountSummarySearchGrid();
    formatFields();
    showModal();
}

function initAccountSummarySearchGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "AccountSummarySearchGrid",
        pageLength: 10,
        responsiveModalTitle: "Account Details",
        isViewOnly: false,
        hideSearch: false
    };
    var dtTable = applyActionDataTable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitHdnId");
}





