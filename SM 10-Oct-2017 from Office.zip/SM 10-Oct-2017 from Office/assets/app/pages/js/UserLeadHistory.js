﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initUserLeadHistorySearchGrid();
    formatFields();
    showModal();
}

function initUserLeadHistorySearchGrid() {
    var dtOptions = {
        tableId: "userLeadHistorySearchGrid",
        pageLength: 10,
        isViewOnly: false,
        hideSearch: true
    };
    var dtTable = applyActionDataTable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitHdnId");
}




