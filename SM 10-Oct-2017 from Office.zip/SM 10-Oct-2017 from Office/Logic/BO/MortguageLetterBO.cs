﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq.Expressions;
using NHibernate.Impl;
using System.Linq;
using System.Data;
using CrystalDecisions.CrystalReports.Engine;

namespace ConstroSoft.Logic.BO
{

    public class MortguageLetterBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public MortguageLetterBO() { }

        public BusinessOutputTO processMortguageLetter(string firmNumber, PrUnitSaleDetailDTO selectedPrUnitSaleDetailDto)
        {
            BusinessOutputTO businessOutputTO = new BusinessOutputTO();
            string BLANK_STRING = "";
            try
            {
                DataTable MortguageLetter = populateMortguageLetterColumns();
                FirmBO firmBO = new FirmBO();
                PropertyBO propertyBO = new PropertyBO();
                SoldPropertyUnitBO soldUnitBO = new SoldPropertyUnitBO();
                PrUnitSaleDetailDTO prUnitSaleDetailDto = soldUnitBO.fetchPrUnitSaleDetailforLetter(firmNumber, selectedPrUnitSaleDetailDto.Id,
                        selectedPrUnitSaleDetailDto.PropertyUnit.PropertyTower.Property.Id);
                FirmDTO firmDto = firmBO.fetchFirmDetails(firmNumber);
                PropertyDTO propertyDTO = propertyBO.fetchProperty(selectedPrUnitSaleDetailDto.PropertyUnit.PropertyTower.Property.Id);
                string errorMessage = validateAggreementNumber(prUnitSaleDetailDto.AgreementNo);
                if (!string.IsNullOrWhiteSpace(errorMessage))
                {
                    businessOutputTO.status = BusinessOutputTO.Status.FAILURE;
                    businessOutputTO.errorMessage = errorMessage;
                }
                else
                {
                    DataRow possessionLetterRow = populateMortguageLetterRows(MortguageLetter, prUnitSaleDetailDto, selectedPrUnitSaleDetailDto,
                        firmDto, propertyDTO, firmNumber);
                    MortguageLetter.Rows.Add(possessionLetterRow);
                    businessOutputTO.status = BusinessOutputTO.Status.SUCCESS;
                    businessOutputTO.result = MortguageLetter;
                    string customerName = prUnitSaleDetailDto.Customer.Salutation.Name + " " + prUnitSaleDetailDto.Customer.FirstName + " ";
                    customerName = string.Concat(customerName, prUnitSaleDetailDto.Customer.MiddleName != null ? prUnitSaleDetailDto.Customer.MiddleName + " " : BLANK_STRING);
                    customerName = string.Concat(customerName, prUnitSaleDetailDto.Customer.LastName != null ? prUnitSaleDetailDto.Customer.LastName + " " : BLANK_STRING);
                    businessOutputTO.successMessage = "Mortgage Letter for "+ customerName;
                }
            }
            catch (Exception e)
            {
                log.Error("Exception while generating Mortguage Letter", e);
                throw new Exception(Resources.Messages.system_error);
            }
            return businessOutputTO;
        }
        private DataRow populateMortguageLetterRows(DataTable DemandLetter, PrUnitSaleDetailDTO prUnitSaleDetailDto,
            PrUnitSaleDetailDTO selectedPrUnitSaleDetailDto, FirmDTO firmDto, PropertyDTO propertyDTO, string firmNumber)
        {
            DataRow DemandLetterRow = DemandLetter.NewRow();
            string BLANK_STRING = "";
            DemandLetterRow["Loanbankname"] = prUnitSaleDetailDto.LoanBankName != null ? prUnitSaleDetailDto.LoanBankName : BLANK_STRING;
            DemandLetterRow["Loanbankbranch"] = prUnitSaleDetailDto.LoanBankBranch != null ? prUnitSaleDetailDto.LoanBankBranch : BLANK_STRING;

            string customerName = prUnitSaleDetailDto.Customer.Salutation.Name + " " + prUnitSaleDetailDto.Customer.FirstName + " ";
            customerName = string.Concat(customerName, prUnitSaleDetailDto.Customer.MiddleName != null ? prUnitSaleDetailDto.Customer.MiddleName + " " : BLANK_STRING);
            customerName = string.Concat(customerName, prUnitSaleDetailDto.Customer.LastName != null ? prUnitSaleDetailDto.Customer.LastName + " " : BLANK_STRING);
            DemandLetterRow["Customername"] = customerName;
            string coCustomerName = null;
            if (prUnitSaleDetailDto.CoCustomers != null && prUnitSaleDetailDto.CoCustomers.Count > 0)
            {
                List<CoCustomerDTO> coCustomerDTOs = prUnitSaleDetailDto.CoCustomers.ToList();
                coCustomerName = coCustomerDTOs[0].SalutationId.Name + " " + coCustomerDTOs[0].FirstName + " ";
                coCustomerName = string.Concat(coCustomerName, coCustomerDTOs[0].MiddleName != null ? coCustomerDTOs[0].MiddleName + " " : BLANK_STRING);
                coCustomerName = string.Concat(coCustomerName, coCustomerDTOs[0].LastName != null ? coCustomerDTOs[0].LastName + " " : BLANK_STRING);
            }*/
            DemandLetterRow["CoCustomername"] = coCustomerName != null ? coCustomerName : BLANK_STRING;

            PropertyUnitDTO propertyUnitDto = prUnitSaleDetailDto.PropertyUnit;
            PropertyTowerDTO propertyTowerDto = prUnitSaleDetailDto.PropertyUnit.PropertyTower;
            DemandLetterRow["Flatnumber"] = prUnitSaleDetailDto.PropertyUnit.UnitNo;
            DemandLetterRow["Floornumber"] = propertyUnitDto.FloorNo;
            DemandLetterRow["Carpetarea"] = propertyUnitDto.CarpetArea.ToString();
            DemandLetterRow["Builtuparea"] = propertyUnitDto.BuildupArea.ToString();
            DemandLetterRow["Balconyarea"] = propertyUnitDto.BalconyArea.ToString();
            DemandLetterRow["Flatnumber"] = prUnitSaleDetailDto.PropertyUnit.UnitNo;
            DemandLetterRow["Propertyname"] = propertyDTO.Name;
            AddressDTO addressDTO = propertyDTO.ContactInfo.Addresses.ToList()[0];

            string address = addressDTO.AddressLine1 + " ";
            address = string.Concat(address, addressDTO.AddressLine2 != null ? addressDTO.AddressLine2 : BLANK_STRING);
            address = string.Concat(address, addressDTO.Town != null ? addressDTO.Town : BLANK_STRING);
            address = string.Concat(address, " " + addressDTO.City.Name + " " + addressDTO.State.Name + " " + addressDTO.Country.Name + " " + addressDTO.Pin);
            DemandLetterRow["Propertyaddress"] = address;

            DemandLetterRow["Firmname"] = firmDto.Name;
            DemandLetterRow["Towername"] = selectedPrUnitSaleDetailDto.PropertyUnit.PropertyTower.Name;
            DemandLetterRow["UnitType"] = prUnitSaleDetailDto.PropertyUnit.UnitType.Name;
            DemandLetterRow["AggreementNumber"] = prUnitSaleDetailDto.AgreementNo != null ? prUnitSaleDetailDto.AgreementNo : BLANK_STRING;

            decimal totalPaidAmt;
            decimal totalPaymentAmount;
            PrUnitSalePymtDTO tmpPrUnitSalePymtDTO = prUnitSaleDetailDto.PrUnitSalePymts.ToList<PrUnitSalePymtDTO>().Find(x => isSalePayment(x.PymtType.Name));
            totalPaymentAmount = tmpPrUnitSalePymtDTO.PymtAmt;
            totalPaidAmt = tmpPrUnitSalePymtDTO.PaymentMaster.TotalPaid;

           
            DemandLetterRow["TotalPaidAmount"] = totalPaymentAmount;
            return DemandLetterRow;
        }
        private static DataTable populateMortguageLetterColumns()
        {
            DataTable MortguageLetter = new DataTable();
            MortguageLetter.Columns.Add("Loanbankname", typeof(string));
            MortguageLetter.Columns.Add("Loanbankbranch", typeof(string));
            MortguageLetter.Columns.Add("Customername", typeof(string));
            MortguageLetter.Columns.Add("CoCustomername", typeof(string));
            MortguageLetter.Columns.Add("Flatnumber", typeof(string));
            MortguageLetter.Columns.Add("Floornumber", typeof(string));
            MortguageLetter.Columns.Add("Carpetarea", typeof(string));
            MortguageLetter.Columns.Add("Builtuparea", typeof(string));
            MortguageLetter.Columns.Add("Balconyarea", typeof(string));
            MortguageLetter.Columns.Add("Propertyname", typeof(string));
            MortguageLetter.Columns.Add("Propertyaddress", typeof(string));
            MortguageLetter.Columns.Add("Firmname", typeof(string));
            MortguageLetter.Columns.Add("Towername", typeof(string));
            MortguageLetter.Columns.Add("UnitType", typeof(string));
            MortguageLetter.Columns.Add("TotalPaidAmount", typeof(string));
            MortguageLetter.Columns.Add("AggreementNumber", typeof(string));
            return MortguageLetter;
        }
        public static string validateAggreementNumber(string aggreementNumber)
        {
            string errorMessage = "";
            if (aggreementNumber == null || aggreementNumber.Equals(""))
            {
                errorMessage = "Aggreement Number of Property Unit not given. Please set Aggreement Number.";
            }
            return errorMessage;
        }
        private bool isSalePayment(string paymentType)
        {
            return Constants.MCD_SALE_PAYMENT.Equals(paymentType);
        }
    }
}
