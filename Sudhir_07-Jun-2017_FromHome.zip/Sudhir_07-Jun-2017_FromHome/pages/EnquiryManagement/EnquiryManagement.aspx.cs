﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using NHibernate;
using Vladsm.Web.UI.WebControls;

namespace ConstroSoft.pages.EnquiryManagement
{
    public partial class EnquiryManagement : System.Web.UI.Page
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string tab1ValidationGrp = "tab1Error";
        string tab2ValidationGrp = "tab2Error";
        string tab3ValidationGrp = "tab3Error";
        string bookingModalValidationGrp = "bookUnitError";
        string VS_ENQUIRY_LIST = "ENQUIRY_LIST";
        string VS_SELECTED_ENQUIRY = "SELECTED_ENQUIRY";
        DropdownBO drpBO = new DropdownBO();
        EnquiryBO enquiryBO = new EnquiryBO();
        MasterDataBO masterDataBO = new MasterDataBO();
        EmployeeBO firmMemberBO = new EmployeeBO();
        public enum EnquiryPageMode { ADD, MODIFY, VIEW, FOLLOWUP, NONE }
        protected void Page_Load(object sender, EventArgs e)
        {
            clearMessages();
            if (!IsPostBack)
            {
                if (CommonUtil.isSessionActive(Session))
                {
                    resetTabInfo(EnquiryPageMode.NONE);
                    initDropdowns();
                    loadSearchGridAndReSelect(0);
                    Page.MaintainScrollPositionOnPostBack = false;
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
        }
        private void initDropdowns()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            drpBO.drpDataBase(drpSalutation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.SALUTATION, null, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpPropertyType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpPropertyLocation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_LOCATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpPropertyUnitType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpEnquirySource, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ENQUIRY_SOURCE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpOccupation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.OCCUPATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpEnum<EnquirySearchBy>(drpSearchBy, null);
            drpBO.drpEnum<Gender>(drpGender, Constants.SELECT_ITEM);
            drpBO.drpEnum<MaritalStatus>(drpMaritalStatus, Constants.SELECT_ITEM);
            drpBO.drpEnum<EnquiryStatus>(drpStatus, Constants.SELECT_ITEM);
            drpBO.drpDataBase(drpProperty, DrpDataType.PROPERTY_NAME, userDefDto.Id.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpFirmMember, DrpDataType.EMPLOYEE_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpAddressCountry, DrpDataType.COUNTRY, null, null, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpAddressState, DrpDataType.STATE, Constants.DEFAULT_COUNTRY, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            initCityDrp(drpAddressCity, Constants.DEFAULT_STATE);
            drpBO.drpDataBase(drpAddressType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ADDRESS_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpEnum<PreferredAddress>(drpPreferredAddress, null);
            drpBO.drpDataBase(drpEmployeeName, DrpDataType.EMPLOYEE_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpContactType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ENQUIRY_MEDIA_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        }
        /**
         * This method is called just before the page is rendered. So any change in state of the element is applied.
         **/
        protected void Page_PreRender(object sender, EventArgs e)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                applyEntitlement();
                preRenderInitFormElements();
                initBootstrapComponantsFromServer();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        private void applyEntitlement()
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            addEnquiryBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.ENQUIRY_ADD);
            modifyEnquiryBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.ENQUIRY_MODIFY);
            deleteEnquiryBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.ENQUIRY_DELETE);
            btnBookUnit.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_UNIT_BOOK);
        }
        private void preRenderInitFormElements()
        {
            EnquiryDetailDTO selectedEnquiry = getCurrentEnquiry();
            jumpToEnquiryHdnId.Value = null;
            jumpToAddressHdnId.Value = null;
            if (selectedEnquiry != null)
            {
                jumpToEnquiryHdnId.Value = selectedEnquiry.Id.ToString();
                List<AddressDTO> addressList = selectedEnquiry.ContactInfo.Addresses.ToList<AddressDTO>();
                if (addressList != null && addressList.Count > 0)
                {
                    AddressDTO selectedAddress = addressList.Find(a => a.isUISelected);
                    if (selectedAddress != null) jumpToAddressHdnId.Value = selectedAddress.UiIndex.ToString();
                }
            }
            if (EnquiryPageMode.FOLLOWUP.ToString() == pageModeHdn.Value && selectedEnquiry != null)
            {
                populateEnquiryInfoSection(selectedEnquiry);
                if (followupModifyHdn.Value == "true")
                {
                    initFollowupFirstSection(getSelectedFollowUp(), selectedEnquiry);
                }
            }
        }
        public void setErrorMessage(string message, string group)
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            this.Page.Validators.Add(val);
        }

        public void setSuccessMessage(string msg, string tabId)
        {
            activeTabHdn.Value = tabId;
            if (tabId.Equals(tab1Anchor.ID))
            {
                lbTab1Success.Text = msg;
                tab1SuccessPanel.Visible = true;
            }
            else if (tabId.Equals(tab2Anchor.ID))
            {
                lbTab2Success.Text = msg;
                tab2SuccessPanel.Visible = true;
            }
            else if (tabId.Equals(tab3Anchor.ID))
            {
                lbTab3Success.Text = msg;
                tab3SuccessPanel.Visible = true;
            }
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        public void initBootstrapComponantsFromServer()
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
        }
        private void clearMessages()
        {
            tab1SuccessPanel.Visible = false;
            lbTab1Success.Text = "";
            tab2SuccessPanel.Visible = false;
            lbTab2Success.Text = "";
            tab3SuccessPanel.Visible = false;
            lbTab3Success.Text = "";
        }
        private UserDefinitionDTO getUserDefinitionDTO()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }

        private void resetTabInfo(EnquiryPageMode pageMode)
        {
            tab2Anchor.Visible = false;
            tab3Anchor.Visible = false;
            activeTabHdn.Value = tab1Anchor.ID;
            pageModeHdn.Value = pageMode.ToString();
            initFormFields();
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            pnlAddressAdd.Visible = false;
            txtEnquiryRefNo.Visible = false;
            EnquiryRefNo.Visible = false;
            if (EnquiryPageMode.ADD == pageMode)
            {
                tab2Anchor.Visible = true;
                tab2Anchor.Text = Resources.Labels.enqm_sm_manage_enq_tab2_add_name;
                activeTabHdn.Value = tab2Anchor.ID;
                initFormFields();
            }
            else if (EnquiryPageMode.FOLLOWUP == pageMode)
            {
                tab3Anchor.Visible = true;
                activeTabHdn.Value = tab3Anchor.ID;
                tab3Anchor.Text = Resources.Labels.enqm_sm_manage_enq_tab2_followup_name;
                pnlFollowUpAddModify.Visible = false;
                pnlFollowupPageCancel.Visible = true;
                initFormFields();
            }
            else if (EnquiryPageMode.MODIFY == pageMode)
            {
                tab2Anchor.Visible = true;
                activeTabHdn.Value = tab2Anchor.ID;
                tab2Anchor.Text = Resources.Labels.enqm_sm_manage_enq_tab2_update_name;
                txtEnquiryRefNo.Visible = true;
                EnquiryRefNo.Visible = true;
                initFormFields();
            }
            else if (EnquiryPageMode.VIEW == pageMode)
            {
                tab2Anchor.Visible = true;
                activeTabHdn.Value = tab2Anchor.ID;
                tab2Anchor.Text = Resources.Labels.enqm_sm_manage_enq_tab2_view_name;
                txtEnquiryRefNo.Visible = true;
                EnquiryRefNo.Visible = true;
                initFormFields();
            }
            else
            {
                activeTabHdn.Value = tab1Anchor.ID;
                ViewState[VS_SELECTED_ENQUIRY] = null;
            }
        }
        private void initFormFields()
        {
            bool isReadOnly = (EnquiryPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            bool visible = !(EnquiryPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            //Buttons
            btnAddSubmit.Visible = visible;
            addPropertyTypeBtn.Visible = visible;
            lnlPropertyUnitType.Visible = visible;
            addPropertyLocationBtn.Visible = visible;
            addPropertyLocationBtn.Visible = visible;
            addOccupationBtn.Visible = visible;
            addEnquirySource.Visible = visible;
            addressBtnGrp.Visible = visible;
            addressGrid.Columns[0].Visible = visible;
        }
        private EnquiryDetailDTO getCurrentEnquiry()
        {
            return (EnquiryDetailDTO)ViewState[VS_SELECTED_ENQUIRY];
        }
        private void setSelectedEnquiry(long selectedId)
        {
            List<EnquiryDetailDTO> enquiryList = (List<EnquiryDetailDTO>)ViewState[VS_ENQUIRY_LIST];
            if (enquiryList != null)
            {
                enquiryList.ForEach(c => c.isUISelected = false);
                enquiryList.Find(c => c.Id == selectedId).isUISelected = true;
            }
        }
        private bool validateEnquirySelected()
        {
            bool isSelected = true;
            List<EnquiryDetailDTO> enquiryList = (List<EnquiryDetailDTO>)ViewState[VS_ENQUIRY_LIST];
            if (enquiryList != null)
            {
                isSelected = enquiryList.Any(c => c.isUISelected);
                if (!isSelected)
                {
                    resetTabInfo(EnquiryPageMode.NONE);
                    setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Enquiry"), tab1ValidationGrp);
                }
            }
            return isSelected;
        }
        private void selectEnquiryGridRdBtn(long Id)
        {
            if (enquiryGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in enquiryGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdEnquirySelect");
                    Button rowIdenBtn = (Button)row.FindControl("btnEnqRowIdentifier");
                    if (radioBtn != null)
                    {
                        radioBtn.Checked = false;
                        if (rowIdenBtn != null && Id > 0 && Id.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                        {
                            radioBtn.Checked = true;
                        }
                    }
                }
            }
        }
        private void loadSearchGridAndReSelect(long Id)
        {
            try
            {
                EnquirySearchBy searchBy = EnumHelper.ToEnum<EnquirySearchBy>(drpSearchBy.Text);
                long searchByValId = -1;
                if (!string.IsNullOrWhiteSpace(drpSearchByValue.Text)) searchByValId = long.Parse(drpSearchByValue.Text);
                IList<EnquiryDetailDTO> results = enquiryBO.fetchEnquiryGridData(getUserDefinitionDTO().FirmNumber, searchBy, searchByValId);
                ViewState[VS_ENQUIRY_LIST] = results;
                enquiryGrid.DataSource = results;
                enquiryGrid.DataBind();
                if (Id > 0)
                {
                    selectEnquiryGridRdBtn(Id);
                    setSelectedEnquiry(Id);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void fetchSelectedEnquiry(bool fetchFollowups)
        {
            try
            {
                EnquiryDetailDTO enquiryDetailDto = null;
                if (EnquiryPageMode.ADD.ToString().Equals(pageModeHdn.Value))
                {
                    enquiryDetailDto = populateEnquiryDTOAdd();
                    selectEnquiryGridRdBtn(0);
                }
                else if (EnquiryPageMode.MODIFY.ToString().Equals(pageModeHdn.Value) || EnquiryPageMode.VIEW.ToString().Equals(pageModeHdn.Value)
                    || EnquiryPageMode.FOLLOWUP.ToString().Equals(pageModeHdn.Value))
                {
                    long Id = ((List<EnquiryDetailDTO>)ViewState[VS_ENQUIRY_LIST]).Find(c => c.isUISelected).Id;
                    enquiryDetailDto = enquiryBO.fetchEnquiryDetails(Id, fetchFollowups);
                }
                ViewState[VS_SELECTED_ENQUIRY] = enquiryDetailDto;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void doViewModifyAction(EnquiryPageMode pageMode)
        {
            resetTabInfo(pageMode);
            fetchSelectedEnquiry(false);
            populateUIFieldsFromDTO((EnquiryDetailDTO)ViewState[VS_SELECTED_ENQUIRY]);
        }
        protected void onSearchBy(object sender, EventArgs e)
        {
            try
            {
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                EnquirySearchBy searchBy = EnumHelper.ToEnum<EnquirySearchBy>(drpSearchBy.Text);
                drpSearchByValue.Visible = true;
                lbSearchByValue.Visible = true;
                lbSearchByValue.Text = EnumHelper.GetEnumDescription<EnquirySearchBy>(searchBy.ToString());
                if (EnquirySearchBy.CUSTOMER_NAME == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.ENQUIRY_CUSTOMER_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (EnquirySearchBy.PROP_LOCATION == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_LOCATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (EnquirySearchBy.PROP_TYPE == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (EnquirySearchBy.PROP_UNIT_TYPE == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (EnquirySearchBy.ENQUIRY_SOURCE == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ENQUIRY_SOURCE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (EnquirySearchBy.PROP_NAME == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.PROPERTY_NAME, userDefDto.Id.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (EnquirySearchBy.EMPLOYEE_NAME == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.EMPLOYEE_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else
                {
                    drpSearchByValue.ClearSelection();
                    drpSearchByValue.Visible = false;
                    lbSearchByValue.Visible = false;
                }
                loadSearchGridAndReSelect(0);
                resetTabInfo(EnquiryPageMode.NONE);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onSearchByValue(object sender, EventArgs e)
        {
            loadSearchGridAndReSelect(0);
            resetTabInfo(EnquiryPageMode.NONE);
        }
        protected void selectEnquiry(object sender, EventArgs e)
        {
            try
            {
                GroupRadioButton rd = (GroupRadioButton)sender;
                resetTabInfo(EnquiryPageMode.NONE);
                if (rd.Checked)
                {
                    string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnEnqRowIdentifier"))).Attributes["row-identifier"];
                    setSelectedEnquiry(long.Parse(strId));
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        /*
         * This method is called on click of ADD button in datatable top bar.
         */
        protected void onClickAddEnquiryBtn(object sender, EventArgs e)
        {
            try
            {
                resetTabInfo(EnquiryPageMode.ADD);
                fetchSelectedEnquiry(false);
                populateUIFieldsFromDTO(null);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickViewEnquiryBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateEnquirySelected())
                {
                    doViewModifyAction(EnquiryPageMode.VIEW);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickManageFollowupBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateEnquirySelected())
                {
                	goToManageFollowup();                  
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void goToManageFollowup() {
        	resetTabInfo(EnquiryPageMode.FOLLOWUP);
            fetchSelectedEnquiry(true);
            populateEnquiryInfoSection((EnquiryDetailDTO)ViewState[VS_SELECTED_ENQUIRY]);
            populateFollowUpGrid((EnquiryDetailDTO)ViewState[VS_SELECTED_ENQUIRY], true);
            pnlFollowUpAddModify.Visible = false;
            pnlFollowupPageCancel.Visible = true;
        }
        protected void onClickModifyEnquiryBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateEnquirySelected())
                {
                    doViewModifyAction(EnquiryPageMode.MODIFY);
                    EnquiryStatus dbEnquiryStatus = (EnquiryStatus)getCurrentEnquiry().Status;
                    if (dbEnquiryStatus == EnquiryStatus.Won) {
                        drpStatus.Enabled = false;
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void deleteEnquiry(object sender, EventArgs e)
        {
            try
            {
                if (validateEnquirySelected())
                {
                    long Id = ((List<EnquiryDetailDTO>)ViewState[VS_ENQUIRY_LIST]).Find(c => c.isUISelected).Id;
                    BusinessOutputTO businessOutputTO = enquiryBO.deleteEnquiryDetails(Id);
                    if (businessOutputTO.status == BusinessOutputTO.Status.SUCCESS)
                    {
                        loadSearchGridAndReSelect(0);
                        resetTabInfo(EnquiryPageMode.NONE);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_delete, "Enquiry"), tab1Anchor.ID);
                    }
                    else
                    {
                        setErrorMessage(businessOutputTO.errorMessage, tab1ValidationGrp);
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void addOrModifyEnquiry(object sender, EventArgs e)
        {
            try
            {
                EnquiryDetailDTO enquirydetailDTO = getCurrentEnquiry();
                if (validateEnquiry())
                {
                    if (validateEnquiryStatus(enquirydetailDTO))
                    {
                        long Id = enquirydetailDTO.Id;
                        populateEnquiryDTOFromUI(enquirydetailDTO);
                        if (EnquiryPageMode.ADD.ToString().Equals(pageModeHdn.Value))
                        {
                            Id = enquiryBO.saveEnquiryDetails(enquirydetailDTO);
                            setSuccessMessage(string.Format(Resources.Messages.success_record_add, "Enquiry"), tab1Anchor.ID);
                        }
                        else if (EnquiryPageMode.MODIFY.ToString().Equals(pageModeHdn.Value))
                        {
                            enquiryBO.updateEnquiryDetails(enquirydetailDTO);
                            setSuccessMessage(string.Format(Resources.Messages.success_record_update, "Enquiry"), tab1Anchor.ID);
                        }
                        resetTabInfo(EnquiryPageMode.NONE);
                        loadSearchGridAndReSelect(Id);
                    }
                    else
                    {
                        setErrorMessage(Resources.Messages.validation_Enquiry_status, tab2ValidationGrp);
                    }
                }

            }catch (StaleStateException staleStateException) {
                setErrorMessage(Resources.Messages.stalestate_error, tab2ValidationGrp);
            }
           catch (Exception exp)
           {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
           }
        }
        
        private bool validateEnquiry()
        {
            bool isValid = true;
            Page.Validate("tab2Error");
            isValid = Page.IsValid;
            if (!isValid) {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        private bool validateEnquiryStatus(EnquiryDetailDTO enquirydetailDTO)
        {
            bool isValid = true;
            EnquiryStatus enquiryStatus = EnumHelper.ToEnum<EnquiryStatus>(drpStatus.Text);
            if (enquirydetailDTO.Status == null  && enquiryStatus == EnquiryStatus.Won)
            {
                isValid = false;
            }
            else if (enquirydetailDTO.Status != null && (EnquiryStatus)enquirydetailDTO.Status != EnquiryStatus.Won 
                && enquiryStatus == EnquiryStatus.Won)
            {
                isValid = false;
            }
            return isValid;
        }
        protected void cancelEnquiry(object sender, EventArgs e)
        {
            EnquiryDetailDTO emquiryDetailDto = getCurrentEnquiry();
            resetTabInfo(EnquiryPageMode.NONE);
            loadSearchGridAndReSelect(emquiryDetailDto.Id);
        }

        private EnquiryDetailDTO populateEnquiryDTOAdd()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            EnquiryDetailDTO enquiryDTO = new EnquiryDetailDTO();
            enquiryDTO.ContactInfo = new ContactInfoDTO();
            enquiryDTO.ContactInfo.Addresses = new HashSet<AddressDTO>();
            enquiryDTO.FirmNumber = userDefDto.FirmNumber;
            enquiryDTO.InsertUser = userDefDto.Username;
            return enquiryDTO;
        }
        private void populateEnquiryDTOFromUI(EnquiryDetailDTO enquiryDetailDTo)
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            enquiryDetailDTo.Salutation = CommonUIConverter.getMasterControlDTO(drpSalutation.Text, null);
            enquiryDetailDTo.EnquiryRefNo = txtEnquiryRefNo.Text;
            enquiryDetailDTo.FirstName = txtFirstName.Text;
            enquiryDetailDTo.MiddleName = txtMiddleName.Text;
            enquiryDetailDTo.LastName = txtLastName.Text;
            enquiryDetailDTo.ContactInfo.Gender = EnumHelper.ToEnumNullable<Gender>(drpGender.Text);
            enquiryDetailDTo.ContactInfo.Dob = DateTime.ParseExact(txtDOB.Text, Constants.DATE_FORMAT, CultureInfo.InvariantCulture);
            enquiryDetailDTo.ContactInfo.MaritalStatus = EnumHelper.ToEnumNullable<MaritalStatus>(drpMaritalStatus.Text);
            enquiryDetailDTo.ContactInfo.Contact = txtContact.Text;
            enquiryDetailDTo.ContactInfo.AltContact = txtAltContact.Text;
            enquiryDetailDTo.ContactInfo.Email = txtEmail.Text;
            enquiryDetailDTo.Occupation = CommonUIConverter.getMasterControlDTO(drpOccupation.Text, null);
            enquiryDetailDTo.FirmMember = CommonUIConverter.getFirmMemberDTO(drpFirmMember.Text, null);
            if (!string.IsNullOrWhiteSpace(txtDOE.Text)) enquiryDetailDTo.EnquiryDate = DateTime.ParseExact(txtDOE.Text, Constants.DATE_FORMAT, CultureInfo.InvariantCulture); else enquiryDetailDTo.EnquiryDate = null;
            if (!string.IsNullOrWhiteSpace(txtNextFollowupDate.Text)) enquiryDetailDTo.FollowupDate = DateTime.ParseExact(txtNextFollowupDate.Text, Constants.DATE_FORMAT, CultureInfo.InvariantCulture); else enquiryDetailDTo.FollowupDate = null;
            enquiryDetailDTo.PropertyType = CommonUIConverter.getMasterControlDTO(drpPropertyType.Text, null);
            enquiryDetailDTo.Comments = txtDescription.Text;
            enquiryDetailDTo.PropertyLocation = CommonUIConverter.getMasterControlDTO(drpPropertyLocation.Text, null);
            enquiryDetailDTo.UpdateUser = userDefDto.Username;
            enquiryDetailDTo.PrUnitType = CommonUIConverter.getMasterControlDTO(drpPropertyUnitType.Text, null);
            enquiryDetailDTo.Property = CommonUIConverter.getPropertyDTO(drpProperty.Text, null);
            enquiryDetailDTo.Status = EnumHelper.ToEnum<EnquiryStatus>(drpStatus.Text);
            if (!string.IsNullOrWhiteSpace(txtBudget.Text)) enquiryDetailDTo.Budget = CommonUtil.getDecimalWithoutExt(txtBudget.Text);
            else enquiryDetailDTo.Budget = null;
            enquiryDetailDTo.EnquirySource = CommonUIConverter.getMasterControlDTO(drpEnquirySource.Text, null);
            enquiryDetailDTo.CloseReason = txtCloseReason.Text;
        }
        private void populateUIFieldsFromDTO(EnquiryDetailDTO enquiryDetailDTO)
        {
            if (enquiryDetailDTO != null && enquiryDetailDTO.Salutation != null) drpSalutation.Text = enquiryDetailDTO.Salutation.Id.ToString(); else drpSalutation.ClearSelection();
            if (enquiryDetailDTO != null) txtFirstName.Text = enquiryDetailDTO.FirstName; else txtFirstName.Text = null;
            if (enquiryDetailDTO != null) txtMiddleName.Text = enquiryDetailDTO.MiddleName; else txtMiddleName.Text = null;
            if (enquiryDetailDTO != null) txtLastName.Text = enquiryDetailDTO.LastName; else txtLastName.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.ContactInfo.Gender != null) drpGender.Text = enquiryDetailDTO.ContactInfo.Gender.ToString(); else drpGender.ClearSelection();
            if (enquiryDetailDTO != null && enquiryDetailDTO.ContactInfo.Dob != null) txtDOB.Text = enquiryDetailDTO.ContactInfo.Dob.Value.ToString(Constants.DATE_FORMAT); else txtDOE.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.ContactInfo.MaritalStatus != null) drpMaritalStatus.Text = enquiryDetailDTO.ContactInfo.MaritalStatus.ToString(); else drpMaritalStatus.ClearSelection();
            if (enquiryDetailDTO != null) txtContact.Text = enquiryDetailDTO.ContactInfo.Contact; else txtContact.Text = null;
            if (enquiryDetailDTO != null) txtAltContact.Text = enquiryDetailDTO.ContactInfo.AltContact; else txtAltContact.Text = null;
            if (enquiryDetailDTO != null) txtEmail.Text = enquiryDetailDTO.ContactInfo.Email; else txtEmail.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.EnquirySource != null) drpEnquirySource.Text = enquiryDetailDTO.EnquirySource.Id.ToString(); else drpEnquirySource.ClearSelection();
            if (enquiryDetailDTO != null && enquiryDetailDTO.PropertyLocation != null) drpPropertyLocation.Text = enquiryDetailDTO.PropertyLocation.Id.ToString(); else drpPropertyLocation.ClearSelection();
            if (enquiryDetailDTO != null && enquiryDetailDTO.PropertyType != null) drpPropertyType.Text = enquiryDetailDTO.PropertyType.Id.ToString(); else drpPropertyType.ClearSelection();
            if (enquiryDetailDTO != null && enquiryDetailDTO.PrUnitType != null) drpPropertyUnitType.Text = enquiryDetailDTO.PrUnitType.Id.ToString(); else drpPropertyUnitType.ClearSelection();
            if (enquiryDetailDTO != null && enquiryDetailDTO.Property != null) drpProperty.Text = enquiryDetailDTO.Property.Id.ToString(); else drpProperty.ClearSelection();
            if (enquiryDetailDTO != null && enquiryDetailDTO.EnquiryDate != null) txtDOE.Text = enquiryDetailDTO.EnquiryDate.Value.ToString(Constants.DATE_FORMAT); else txtDOE.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.FollowupDate != null) txtNextFollowupDate.Text = enquiryDetailDTO.FollowupDate.Value.ToString(Constants.DATE_FORMAT); else txtNextFollowupDate.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.CloseReason != null) txtCloseReason.Text = enquiryDetailDTO.CloseReason; else txtCloseReason.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.Occupation != null) drpOccupation.Text = enquiryDetailDTO.Occupation.Id.ToString(); else drpOccupation.ClearSelection();
            if (enquiryDetailDTO != null && enquiryDetailDTO.PropertyLocation != null) drpPropertyLocation.Text = enquiryDetailDTO.PropertyLocation.Id.ToString(); else drpPropertyLocation.ClearSelection();
            if (enquiryDetailDTO != null) txtDescription.Text = enquiryDetailDTO.Comments; else txtDescription.Text = null;
            if (enquiryDetailDTO != null) txtBudget.Text = Convert.ToDecimal(enquiryDetailDTO.Budget).ToString(); else txtBudget.Text = null;
            if (enquiryDetailDTO != null) txtEnquiryRefNo.Text = enquiryDetailDTO.EnquiryRefNo.ToString(); else txtEnquiryRefNo.Text = null;
            if (enquiryDetailDTO != null) drpFirmMember.Text = enquiryDetailDTO.FirmMember.Id.ToString(); else drpFirmMember.ClearSelection();
            if (enquiryDetailDTO != null) drpStatus.Text = enquiryDetailDTO.Status.ToString(); else drpStatus.Text = null;

            populateAddressGrid(enquiryDetailDTO);
        }
        private void populateAddressGrid(EnquiryDetailDTO enquiryDetailDto)
        {
            addressGrid.DataSource = new List<AddressDTO>();
            if (enquiryDetailDto != null)
            {
                assignUiIndexToAddress(enquiryDetailDto.ContactInfo.Addresses);
                addressGrid.DataSource = enquiryDetailDto.ContactInfo.Addresses;
            }
            addressGrid.DataBind();
        }
        private void assignUiIndexToAddress(ISet<AddressDTO> addressDtos)
        {
            if (addressDtos != null && addressDtos.Count > 0)
            {
                long uiIndex = 1;
                foreach (AddressDTO addressDto in addressDtos)
                {
                    addressDto.UiIndex = uiIndex++;
                    addressDto.RowInfo = CommonUIConverter.getGridViewRowInfo(addressDto);
                }
            }
        }

        private void populateEnquiryInfoSection(EnquiryDetailDTO enquiryDetailDTO)
        {
            if (enquiryDetailDTO != null && enquiryDetailDTO.Salutation != null) txtMESalutation.Text = enquiryDetailDTO.Salutation.Name; else txtMESalutation.Text = null;
            if (enquiryDetailDTO != null) txtMEFirstName.Text = enquiryDetailDTO.FirstName; else txtMEFirstName.Text = null;
            if (enquiryDetailDTO != null) txtMEMiddleName.Text = enquiryDetailDTO.MiddleName; else txtMEMiddleName.Text = null;
            if (enquiryDetailDTO != null) txtMELastName.Text = enquiryDetailDTO.LastName; else txtMELastName.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.ContactInfo.Gender != null) txtMEGender.Text = enquiryDetailDTO.ContactInfo.Gender.ToString(); else txtMEGender.Text = null;
            if (enquiryDetailDTO != null) txtMEContact.Text = enquiryDetailDTO.ContactInfo.Contact; else txtMEContact.Text = null;
            if (enquiryDetailDTO != null) txtMEAltContact.Text = enquiryDetailDTO.ContactInfo.AltContact; else txtMEAltContact.Text = null;
            if (enquiryDetailDTO != null) txtMEEmail.Text = enquiryDetailDTO.ContactInfo.Email; else txtMEEmail.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.EnquirySource != null) txtMEEnquirySource.Text = enquiryDetailDTO.EnquirySource.Name; else txtMEEnquirySource.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.PropertyType != null) txtMEPropertyType.Text = enquiryDetailDTO.PropertyType.Name; else txtMEPropertyType.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.PrUnitType != null) txtMEPropertyUnitType.Text = enquiryDetailDTO.PrUnitType.Name; else txtMEPropertyUnitType.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.EnquiryDate != null) txtMEEnquiryDate.Text = enquiryDetailDTO.EnquiryDate.Value.ToString(Constants.DATE_FORMAT); else txtMEEnquiryDate.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.FollowupDate != null) txtMENextFollowupDate.Text = enquiryDetailDTO.FollowupDate.Value.ToString(Constants.DATE_FORMAT); else txtMENextFollowupDate.Text = null;
            if (enquiryDetailDTO != null) txtMEBudget.Text = Convert.ToDecimal(enquiryDetailDTO.Budget).ToString(); else txtMEBudget.Text = null;
            if (enquiryDetailDTO != null) txtMEEnquiryRefNo.Text = enquiryDetailDTO.EnquiryRefNo; else txtMEEnquiryRefNo.Text = null;
            if (enquiryDetailDTO != null) txtMEFirmMember.Text = enquiryDetailDTO.FirmMember.FirstName + " " + enquiryDetailDTO.FirmMember.LastName; else txtMEFirmMember.Text = null;
            if (enquiryDetailDTO != null) txtMEStatus.Text = enquiryDetailDTO.Status.ToString(); else txtMEStatus.Text = null;
            pnlEnqCloseReason.Visible = false;
            followupBtnGrp.Visible = true;
            followUpGrid.Columns[0].Visible = true;
            followupReadonlyHdn.Value = "false";
            if (enquiryDetailDTO.Status == EnquiryStatus.Closed)
            {
                pnlEnqCloseReason.Visible = true;
                txtMEEnqCloseReason.Text = enquiryDetailDTO.CloseReason;
                followupBtnGrp.Visible = false;
                followUpGrid.Columns[0].Visible = false;
                followupReadonlyHdn.Value = "true";
            }
            btnCloseEnq.Visible = (enquiryDetailDTO.Status == EnquiryStatus.Open);
            btnOpenEnq.Visible = (enquiryDetailDTO.Status == EnquiryStatus.Closed);
            btnBookUnit.Visible = (enquiryDetailDTO.Status == EnquiryStatus.Open);
        }

        private void populateFollowUpGrid(EnquiryDetailDTO enquiryDetailDto, bool appendName)
        {
            followUpGrid.DataSource = new List<EnquiryDetailDTO>();
            if (enquiryDetailDto != null && enquiryDetailDto.EnquiryFollowups != null)
            {
                assignUiIndexToFollowUp(enquiryDetailDto.EnquiryFollowups, appendName);
                followUpGrid.DataSource = enquiryDetailDto.EnquiryFollowups;
            }
            followUpGrid.DataBind();
        }
        private void assignUiIndexToFollowUp(ISet<EnquiryFollowupDTO> enquiryFollowupDTO, bool appendName)
        {
            if (enquiryFollowupDTO != null && enquiryFollowupDTO.Count > 0)
            {
                long uiIndex = 1;
                foreach (EnquiryFollowupDTO enqFollowupDTO in enquiryFollowupDTO)
                {
                    enqFollowupDTO.UiIndex = uiIndex++;
                    enqFollowupDTO.RowInfo = CommonUIConverter.getGridViewRowInfo(enqFollowupDTO);
                    if (appendName) enqFollowupDTO.FirmMember.FirstName = enqFollowupDTO.FirmMember.FirstName + " " + enqFollowupDTO.FirmMember.LastName;
                }
            }
        }
        //Followup Page
        private void initFollowUpAddUpdateSection(bool isAdd)
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            lbAddUpdateFollowupSectionHeader.Text = (isAdd) ? Resources.Labels.label_sectionheader_add_followup : Resources.Labels.label_sectionheader_modify_followup;
            pnlFollowUpAddModify.Visible = true;
            pnlFollowupPageCancel.Visible = false;
            addContactTyp.Visible = isAdd;
            followupModifyHdn.Value = (isAdd) ? "false" : "true";
            if (isAdd) clearFollowUpViewState();
        }
        private void initFollowUpSectionFields(EnquiryFollowupDTO enquiryFollowupDTO, EnquiryDetailDTO enquiryDetailDTO)
        {
            initFollowupFirstSection(enquiryFollowupDTO, enquiryDetailDTO);
            if (enquiryFollowupDTO != null) txtComment.Text = enquiryFollowupDTO.Comments; else txtComment.Text = null;
        }
        private void initFollowupFirstSection(EnquiryFollowupDTO enquiryFollowupDTO, EnquiryDetailDTO enquiryDetailDTO)
        {
            if (enquiryFollowupDTO != null) drpEmployeeName.Text = enquiryFollowupDTO.FirmMember.Id.ToString(); else drpEmployeeName.ClearSelection();
            //TODO - Populate Next followup date as tommarrow.
            if (enquiryFollowupDTO != null && enquiryFollowupDTO.FollowupDate != null)
            {
                txtFollowUpDate.Text = CommonUtil.getCSDate(enquiryFollowupDTO.FollowupDate);
                txtEnqNextFollowUpDate.Text = CommonUtil.getCSDate(enquiryDetailDTO.FollowupDate);
            }
            else
            {
                txtFollowUpDate.Text = CommonUtil.getCSDate(enquiryDetailDTO.FollowupDate);
                txtEnqNextFollowUpDate.Text = null;
            }
            if (enquiryFollowupDTO != null && enquiryFollowupDTO.CommunicationMedia != null) drpContactType.Text = enquiryFollowupDTO.CommunicationMedia.Id.ToString(); else drpContactType.ClearSelection();
        }
        private void clearFollowUpViewState()
        {
            if (followUpGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in followUpGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdfollowUpSelect");
                    if (radioBtn != null) radioBtn.Checked = false;
                }
            }
            getCurrentEnquiry().EnquiryFollowups.ToList<EnquiryFollowupDTO>().ForEach(c => c.isUISelected = false);
        }
        private EnquiryFollowupDTO getSelectedFollowUp()
        {
            return getCurrentEnquiry().EnquiryFollowups.ToList<EnquiryFollowupDTO>().Find(c => c.isUISelected);
        }
        private bool validateFollowUpSelected()
        {
            bool isSelected = true;
            EnquiryFollowupDTO enquiryFollowupDTO = getSelectedFollowUp();
            if (enquiryFollowupDTO == null)
            {
                isSelected = false;
                pnlFollowUpAddModify.Visible = false;
                pnlFollowupPageCancel.Visible = true;
                clearFollowUpViewState();
                setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Follow-Up"), tab3ValidationGrp);
            }
            return isSelected;
        }
        protected void selectFollowUp(object sender, EventArgs e)
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            
            if (rd.Checked)
            {
                long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnFollowUpRowIdentifier"))).Attributes["row-identifier"]);
                List<EnquiryFollowupDTO> followUpList = getCurrentEnquiry().EnquiryFollowups.ToList<EnquiryFollowupDTO>();
                followUpList.ForEach(c => c.isUISelected = false);
                followUpList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
            }
        }
        protected void onClickAddFollowUpBtn(object sender, EventArgs e)
        {
            try
            {
                EnquiryDetailDTO enquiryDetailDTO = getCurrentEnquiry();
                initFollowUpAddUpdateSection(true);
                initFollowUpSectionFields(null, enquiryDetailDTO);
                SetFocus(drpEmployeeName);
                scrollToFieldHdn.Value = pnlFollowUpAddModify.ID;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab3ValidationGrp);
            }
        }
        protected void onClickModifyFollowUpBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateFollowUpSelected())
                {
                    initFollowUpAddUpdateSection(false);
                    initFollowUpSectionFields(getSelectedFollowUp(), getCurrentEnquiry());
                    SetFocus(drpEmployeeName);
                    scrollToFieldHdn.Value = pnlFollowUpAddModify.ID;
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab3ValidationGrp);
            }
        }
        protected void addOrModifyFollowUp(object sender, EventArgs e)
        {
        	try
            {
                if(validateFollowUp()) {
                    EnquiryDetailDTO enquiryDetailDto = getCurrentEnquiry();
                    EnquiryFollowupDTO enquiryFollowupDTO = populateFollowUpFromUI(enquiryDetailDto);
                	if(enquiryFollowupDTO.Id > 0) {
                		enquiryBO.updateEnquiryFollowup(enquiryFollowupDTO);
                		setSuccessMessage(string.Format(Resources.Messages.success_record_update, "Enquiry Follow-Up"), tab3Anchor.ID);
                	} else {
                		enquiryBO.addNewFollowup(enquiryFollowupDTO);
                		setSuccessMessage(string.Format(Resources.Messages.success_record_add, "Enquiry Follow-Up"), tab3Anchor.ID);
                	}
                	resetTabInfo(EnquiryPageMode.NONE);
                    loadSearchGridAndReSelect(enquiryDetailDto.Id);
                    goToManageFollowup();
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                resetTabInfo(EnquiryPageMode.NONE);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void cancelFollowUp(object sender, EventArgs e)
        {
        	try
            {
        		resetTabInfo(EnquiryPageMode.FOLLOWUP);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void cancelFollowUpPage(object sender, EventArgs e)
        {
            try
            {
                resetTabInfo(EnquiryPageMode.NONE);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void showBookUnitModal(object sender, EventArgs e)
        {
            try
            {
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                drpBO.drpDataBase(drpBookProperty, DrpDataType.PROPERTY_NAME, userDefDto.Id.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
                drpBookPropertyTower.ClearSelection();
                drpBookPropertyTower.Items.Clear();
                drpBookPropertyUnit.ClearSelection();
                drpBookPropertyUnit.Items.Clear();
                EnquiryDetailDTO enquiry = getCurrentEnquiry();
                if (enquiry.Property != null && enquiry.Property.Id > 0)
                {
                    drpBookProperty.Text = enquiry.Property.Id.ToString();
                    drpBO.drpDataBase(drpBookPropertyTower, DrpDataType.PROPERTY_TOWER, drpBookProperty.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
                }
                showBookUnitModalHdnBtn.Value = "true";
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                resetTabInfo(EnquiryPageMode.NONE);
                setErrorMessage(Resources.Messages.system_error, tab3ValidationGrp);
            }
        }
        protected void loadBookTowers(object sender, EventArgs e)
        {
            showBookUnitModalHdnBtn.Value = "true";
            try
            {
                drpBookPropertyTower.ClearSelection();
                drpBookPropertyTower.Items.Clear();
                drpBookPropertyUnit.ClearSelection();
                drpBookPropertyUnit.Items.Clear();
                if (!String.IsNullOrWhiteSpace(drpBookProperty.Text))
                {
                    UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                    drpBO.drpDataBase(drpBookPropertyTower, DrpDataType.PROPERTY_TOWER, drpBookProperty.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
                }
                else
                {
                    setErrorMessage("Please select Property.", bookingModalValidationGrp);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                resetTabInfo(EnquiryPageMode.NONE);
                setErrorMessage(Resources.Messages.system_error, bookingModalValidationGrp);
            }
        }
        protected void loadAvailableUnitsForBooking(object sender, EventArgs e)
        {
            showBookUnitModalHdnBtn.Value = "true";
            try
            {
                drpBookPropertyUnit.ClearSelection();
                drpBookPropertyUnit.Items.Clear();
                if (!String.IsNullOrWhiteSpace(drpBookPropertyTower.Text))
                {
                    UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                    drpBO.drpDataBase(drpBookPropertyUnit, DrpDataType.PR_AVAILABLE_UNIT, drpBookPropertyTower.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
                }
                else
                {
                    setErrorMessage("Please select Property Tower.", bookingModalValidationGrp);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                resetTabInfo(EnquiryPageMode.NONE);
                setErrorMessage(Resources.Messages.system_error, bookingModalValidationGrp);
            }
        }

        protected void goToBookingPage(object sender, EventArgs e)
        {
            try
            {
                if (validateBookingFields())
                {
                    EnquiryToBookingPageNavDTO navDto = new EnquiryToBookingPageNavDTO();
                    navDto.PrUnitId = long.Parse(drpBookPropertyUnit.Text);
                    navDto.PrTowerId = long.Parse(drpBookPropertyTower.Text);
                    navDto.PropertyId = long.Parse(drpBookProperty.Text);
                    navDto.copyCustomerDtls = cbCopyCustomerDetails.Checked;
                    navDto.EnquiryId = getCurrentEnquiry().Id;
                    Session[Constants.Session.FROM_ENQ_BOOKING] = navDto;
                    Response.Redirect(Constants.URL.AVAILABLE_UNITS, true);
                }
                else
                {
                    showBookUnitModalHdnBtn.Value = "true";
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                resetTabInfo(EnquiryPageMode.NONE);
                showBookUnitModalHdnBtn.Value = "true";
                setErrorMessage(Resources.Messages.system_error, bookingModalValidationGrp);
            }
        }

        protected void cancelBookingModal(object sender, EventArgs e)
        {
            try
            {
                
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                resetTabInfo(EnquiryPageMode.NONE);
                setErrorMessage(Resources.Messages.system_error, bookingModalValidationGrp);
            }
        }

        private bool validateBookingFields()
        {
            bool isValid = true;
            if (string.IsNullOrWhiteSpace(drpBookProperty.Text))
            {
                setErrorMessage("Please select Property.", bookingModalValidationGrp);
                isValid = false;
            }
            else if (string.IsNullOrWhiteSpace(drpBookPropertyTower.Text))
            {
                setErrorMessage("Please select Property Tower.", bookingModalValidationGrp);
                isValid = false;
            }
            else if (string.IsNullOrWhiteSpace(drpBookPropertyUnit.Text))
            {
                setErrorMessage("Please select Property Unit.", bookingModalValidationGrp);
                isValid = false;
            }
            return isValid;
        }

        private bool validateFollowUp()
        {
            bool isValid = true;
            if (followupModifyHdn.Value == "false")
            {
                Page.Validate(tab3ValidationGrp);
                isValid = Page.IsValid;
            }
            else
            {
                if (string.IsNullOrWhiteSpace(txtComment.Text))
                {
                    setErrorMessage(Resources.Messages.validation_comment_required, tab3ValidationGrp);
                    isValid = false;
                }
            }
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        private EnquiryFollowupDTO populateFollowUpFromUI(EnquiryDetailDTO enquiryDetailDTO)
        {
        	EnquiryFollowupDTO enquiryFollowupDTO = getSelectedFollowUp();
        	UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        	if(enquiryFollowupDTO == null) {
        		enquiryFollowupDTO = new EnquiryFollowupDTO();
        		enquiryFollowupDTO.FirmNumber = userDefDto.FirmNumber;
                enquiryFollowupDTO.InsertUser = userDefDto.Username;
                enquiryFollowupDTO.EnquiryDetail = enquiryDetailDTO;
                enquiryFollowupDTO.FirmMember = CommonUIConverter.getFirmMemberDTO(drpEmployeeName.Text, drpEmployeeName.SelectedItem.Text);
                enquiryFollowupDTO.FollowupDate = DateTime.ParseExact(txtFollowUpDate.Text, Constants.DATE_FORMAT, CultureInfo.InvariantCulture);
                enquiryFollowupDTO.CommunicationMedia = CommonUIConverter.getMasterControlDTO(drpContactType.Text, drpContactType.SelectedItem.Text);
                enquiryDetailDTO.FollowupDate = DateTime.ParseExact(txtEnqNextFollowUpDate.Text, Constants.DATE_FORMAT, CultureInfo.InvariantCulture);
        	}
            enquiryFollowupDTO.Comments = txtComment.Text;
            enquiryFollowupDTO.UpdateUser = userDefDto.Username;
            return enquiryFollowupDTO;
        }
        //Modal save logic
        protected void saveModalData(object sender, EventArgs e)
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();

            if (modalHdnType.Value == "PROPERTY_TYPE")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PROPERTY_TYPE, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "PROPERTY_TYPE");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpPropertyType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }

            else if (modalHdnType.Value == "PROPERTY_LOCATION")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PROPERTY_LOCATION, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "PROPERTY_LOCATION");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpPropertyLocation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_LOCATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }

            else if (modalHdnType.Value == "PROPERTY_UNIT_TYPE")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_UNIT_TYPE, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "PROPERTY_UNIT_TYPE");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpPropertyUnitType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            else if (modalHdnType.Value == "ENQUIRY_SOURCE")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.ENQUIRY_SOURCE, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "ENQUIRY_SOURCE");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpEnquirySource, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ENQUIRY_SOURCE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            else if (modalHdnType.Value == "OCCUPATION")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.OCCUPATION, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "OCCUPATION");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpOccupation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.OCCUPATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            else if (modalHdnType.Value == "COMMUNICATION_MEDIA")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.ENQUIRY_MEDIA_TYPE, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "COMMUNICATION_MEDIA");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpContactType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ENQUIRY_MEDIA_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            else if (modalHdnType.Value == "CLOSE_ENQUIRY")
            {
                EnquiryDetailDTO enquiryDetailDTO = getCurrentEnquiry();
                enquiryBO.closeEnquiry(enquiryDetailDTO.Id, modalInput2.Text);
                long Id = enquiryDetailDTO.Id;
                setSuccessMessage(string.Format(Resources.Messages.success_record_update, "Enquiry"), tab3Anchor.ID);
                loadSearchGridAndReSelect(Id);
                btnOpenEnq.Visible = false;
                btnCloseEnq.Visible = false;
                goToManageFollowup();
            }
            else if (modalHdnType.Value == "OPEN_ENQUIRY")
            {
                EnquiryDetailDTO enquiryDetailDTO = getCurrentEnquiry();
                enquiryBO.openEnquiry(enquiryDetailDTO.Id, modalInput2.Text);
                long Id = enquiryDetailDTO.Id;
                setSuccessMessage(string.Format(Resources.Messages.success_record_update, "Enquiry"), tab3Anchor.ID);
                loadSearchGridAndReSelect(Id);
                btnOpenEnq.Visible = false;
                btnCloseEnq.Visible = false;
                goToManageFollowup();
            }
            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                modalErrorMsg.Value = errorMsg;
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "setModalErrorMsg", "setModalErrorMsg()", true);
            }
            else
            {
                //Reset the modal fields
                modalInput1.Text = "";
                modalInput2.Text = "";
                modalHdnType.Value = "";
                modalActionHdn.Value = "";
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "closeDialogClient", "closeDialogClient()", true);
            }
        }

        private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
        {
            string errorMsg = "";
            if (string.IsNullOrWhiteSpace(masterDataDto.Name))
            {
                errorMsg = Resources.Messages.validation_designationname_required;
            }
            else if (masterDataBO.isAlreadyExist(masterDataDto))
            {
                errorMsg = string.Format(Resources.Messages.validation_same_name_exist, type);
            }
            return errorMsg;
        }
        //Address Table actions - Start
        private void initAddressAddUpdateSection(bool isAdd)
        {
            lbAddUpdateSectionHeader.Text = (isAdd) ? Resources.Labels.label_sectionheader_add_address : Resources.Labels.label_sectionheader_modify_address;
            pnlAddressAdd.Visible = true;
            btnAddressAddToGrid.Visible = isAdd;
            btnAddressUpdateToGrid.Visible = !isAdd;
            drpAddressState.Text = Constants.DEFAULT_STATE;
        }
        private void setDefaultOnAddAddress()
        {
            drpAddressState.Text = Constants.DEFAULT_STATE;
            drpPreferredAddress.Text = PreferredAddress.No.ToString();
        }
        private void initAddressSectionFields(AddressDTO addressDto)
        {
            if (addressDto != null) txtAddressLine1.Text = addressDto.AddressLine1; else txtAddressLine1.Text = null;
            if (addressDto != null) txtAddressLine2.Text = addressDto.AddressLine2; else txtAddressLine2.Text = null;
            if (addressDto != null) txtTown.Text = addressDto.Town; else txtTown.Text = null;
            if (addressDto != null && addressDto.City != null) drpAddressCity.Text = addressDto.City.Id.ToString(); else drpAddressCity.ClearSelection();
            if (addressDto != null && addressDto.State != null) drpAddressState.Text = addressDto.State.Id.ToString(); else drpAddressState.ClearSelection();
            if (addressDto != null && addressDto.Country != null) drpAddressCountry.Text = addressDto.Country.Id.ToString(); else drpAddressCountry.ClearSelection();
            if (addressDto != null) txtPin.Text = addressDto.Pin; else txtPin.Text = null;
            if (addressDto != null && addressDto.AddressType != null) drpAddressType.Text = addressDto.AddressType.Id.ToString(); else drpAddressType.ClearSelection();
            if (addressDto != null && addressDto.PreferredAddress != null) drpPreferredAddress.Text = addressDto.PreferredAddress.ToString(); else drpPreferredAddress.ClearSelection();
        }
        private void clearAddressViewState()
        {
            if (addressGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in addressGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdAddressSelect");
                    if (radioBtn != null) radioBtn.Checked = false;
                }
            }
            getCurrentEnquiry().ContactInfo.Addresses.ToList<AddressDTO>().ForEach(c => c.isUISelected = false);
        }
        private AddressDTO getSelectedAddress()
        {
            return getCurrentEnquiry().ContactInfo.Addresses.ToList<AddressDTO>().Find(c => c.isUISelected);
        }
        private void initCityDrp(DropDownList drp, string stateId)
        {
            drpBO.drpDataBase(drp, DrpDataType.CITY, stateId, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
        }
        private bool validateAddressSelected()
        {
            bool isSelected = true;
            AddressDTO addressDto = getSelectedAddress();
            if (addressDto == null)
            {
                isSelected = false;
                pnlAddressAdd.Visible = false;
                clearAddressViewState();
                setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Address"), tab2ValidationGrp);
            }
            return isSelected;
        }

        private void populateAddressFromUI(AddressDTO addressDto)
        {
            addressDto.AddressLine1 = txtAddressLine1.Text;
            addressDto.AddressLine2 = txtAddressLine2.Text;
            addressDto.Town = txtTown.Text;
            addressDto.City = CommonUIConverter.getCityDTO(drpAddressCity.Text, drpAddressCity.SelectedItem.Text);
            addressDto.State = CommonUIConverter.getStateDTO(drpAddressState.Text, drpAddressState.SelectedItem.Text);
            addressDto.Country = CommonUIConverter.getCountryDTO(drpAddressCountry.Text, drpAddressCountry.SelectedItem.Text);
            addressDto.Pin = txtPin.Text;
            addressDto.AddressType = CommonUIConverter.getMasterControlDTO(drpAddressType.Text, drpAddressType.SelectedItem.Text);
            addressDto.PreferredAddress = EnumHelper.ToEnumNullable<PreferredAddress>(drpPreferredAddress.Text);
        }
        protected void loadCities(object sender, EventArgs e)
        {
            initCityDrp(drpAddressCity, drpAddressState.Text);
            SetFocus(drpAddressCity);
        }
        protected void selectAddress(object sender, EventArgs e)
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            pnlAddressAdd.Visible = false;
            if (rd.Checked)
            {
                long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnAddressRowIdentifier"))).Attributes["row-identifier"]);
                List<AddressDTO> addressList = getCurrentEnquiry().ContactInfo.Addresses.ToList<AddressDTO>();
                addressList.ForEach(c => c.isUISelected = false);
                addressList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
            }
        }
        protected void onClickAddAddressBtn(object sender, EventArgs e)
        {
            try
            {
                initAddressAddUpdateSection(true);
                initAddressSectionFields(null);
                setDefaultOnAddAddress();
                SetFocus(txtAddressLine1);
                scrollToFieldHdn.Value = pnlAddressAdd.ID;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void onClickModifyAddressBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateAddressSelected())
                {
                    initAddressAddUpdateSection(false);
                    initAddressSectionFields(getSelectedAddress());
                    SetFocus(txtAddressLine1);
                    scrollToFieldHdn.Value = pnlAddressAdd.ID;
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void deleteAddress(object sender, EventArgs e)
        {
            try
            {
                if (validateAddressSelected())
                {
                    EnquiryDetailDTO firmMemberDto = getCurrentEnquiry();
                    AddressDTO addressDto = getSelectedAddress();
                    firmMemberDto.ContactInfo.Addresses.Remove(addressDto);
                    pnlAddressAdd.Visible = false;
                    clearAddressViewState();
                    populateAddressGrid(firmMemberDto);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, "Address"), tab2Anchor.ID);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void addNewAddress(object sender, EventArgs e)
        {
            try
            {
                if (validateAddress())
                {
                    EnquiryDetailDTO enquiryDetailDto = getCurrentEnquiry();
                    AddressDTO addressDto = new AddressDTO();
                    populateAddressFromUI(addressDto);
                    enquiryDetailDto.ContactInfo.Addresses.Add(addressDto);
                    pnlAddressAdd.Visible = false;
                    clearAddressViewState();
                    populateAddressGrid(enquiryDetailDto);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, "Address"), tab2Anchor.ID);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void updateAddress(object sender, EventArgs e)
        {
            try
            {
                if (validateAddress())
                {
                    EnquiryDetailDTO enquiryDetailDTO = getCurrentEnquiry();
                    AddressDTO addressDto = getSelectedAddress();
                    populateAddressFromUI(addressDto);
                    pnlAddressAdd.Visible = false;
                    clearAddressViewState();
                    populateAddressGrid(enquiryDetailDTO);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_updatedtotable, "Address"), tab2Anchor.ID);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void cancelAddress(object sender, EventArgs e)
        {
            pnlAddressAdd.Visible = false;
            clearAddressViewState();
        }
        private bool validateAddress()
        {
            bool isValid = true;
            Page.Validate("tab2ErrorGrid1");
            isValid = Page.IsValid;
            if (drpPreferredAddress.Text.Equals(PreferredAddress.Yes.ToString()) && isValid)
            {
                List<AddressDTO> addressList = getCurrentEnquiry().ContactInfo.Addresses.ToList<AddressDTO>();
                bool isPreferred = addressList.Any(c => (c.PreferredAddress == PreferredAddress.Yes && !c.isUISelected));
                if (isPreferred)
                {
                    isValid = false;
                    setErrorMessage(Resources.Messages.validation_address_one_preferred, tab2ValidationGrp);
                }
            }
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        //Address Table actions - END
    }
}