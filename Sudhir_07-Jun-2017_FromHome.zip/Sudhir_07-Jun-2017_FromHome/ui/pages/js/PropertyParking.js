﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initPropertyParkingGrid();
    initPropertyParkingUploadGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("tab2Content");
    //This script will enable tabs which was last active even after postback call.
    enableTab(true);
}

function initPropertyParkingGrid() {
    var isViewOnly = ($("[id$='viewOnlyTableHdn']").val() == 'true');
    var dtOptions = {
        tableId: "propertyParkingGrid",
        pageLength: 10,
        isViewOnly: isViewOnly,
        responsiveModalTitle: "Property Parking",
        customBtnGrpId: "#propertyParkingGridBtnDiv",
        hideSearch: false
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPropertyParkingHdnId");
}
function initPropertyParkingUploadGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "parkingUploadGrid",
        pageLength: 10,
        isViewOnly: false,
        hideSearch: false
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPropertyparkingUploadHdnId");
}