﻿
/// <summary>
/// Summary description for MyENUM
/// </summary>

using System;
namespace ConstroSoft
{
    public class UserStatusStringType : NHibernate.Type.EnumStringType
    {
        public UserStatusStringType(): base(typeof(UserStatus), 1){}
        public override object GetValue(object enm)
        {
            if (null == enm)return String.Empty;
            switch ((UserStatus)enm)
            {
                case UserStatus.Setup: return "S";
                case UserStatus.Active: return "A";
                case UserStatus.InActive: return "I";
                default: throw new ArgumentException("Invalid UserStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("S".Equals(code)) return UserStatus.Setup;
            else if ("A".Equals(code)) return UserStatus.Active;
            else if ("I".Equals(code)) return UserStatus.InActive;
            throw new ArgumentException("Cannot convert value '" + code + "' to UserStatus.");
        }
    }
    public class PreferredAddressStringType : NHibernate.Type.EnumStringType
    {
        public PreferredAddressStringType(): base(typeof(PreferredAddress), 1){}
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PreferredAddress)enm)
            {
                case PreferredAddress.Yes: return "Y";
                case PreferredAddress.No: return "N";
                default: return null;
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return PreferredAddress.Yes;
            else if ("N".Equals(code)) return PreferredAddress.No;
            return null;
        }
    }
    public class GenderStringType : NHibernate.Type.EnumStringType
    {
        public GenderStringType() : base(typeof(Gender), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((Gender)enm)
            {
                case Gender.Male: return "M";
                case Gender.Female: return "F";
                default: return null;
            }
        }
        public override object GetInstance(object code)
        {
            if ("M".Equals(code)) return Gender.Male;
            else if ("F".Equals(code)) return Gender.Female;
            return null;
        }
    }

        public class MaritalStatusStringType : NHibernate.Type.EnumStringType
    {
        public MaritalStatusStringType() : base(typeof(MaritalStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((MaritalStatus)enm)
            {
                case MaritalStatus.Single: return "S";
                case MaritalStatus.Married: return "M";
                default: return null;
            }
        }
        public override object GetInstance(object code)
        {
            if ("S".Equals(code)) return MaritalStatus.Single;
            else if ("M".Equals(code)) return MaritalStatus.Married;
            return null;
        }
    }
        public class SystemDefinedStringType : NHibernate.Type.EnumStringType
        {
            public SystemDefinedStringType() : base(typeof(SystemDefined), 1) { }
            public override object GetValue(object enm)
            {
                if (null == enm) return String.Empty;
                switch ((SystemDefined)enm)
                {
                    case SystemDefined.Yes: return "Y";
                    case SystemDefined.No: return "N";
                    default: return null;
                }
            }
            public override object GetInstance(object code)
            {
                if ("Y".Equals(code)) return SystemDefined.Yes;
                else if ("N".Equals(code)) return SystemDefined.No;
                return null;
            }
        }
    public class EnquiryStatusStringType : NHibernate.Type.EnumStringType
    {
        public EnquiryStatusStringType() : base(typeof(EnquiryStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((EnquiryStatus)enm)
            {
                case EnquiryStatus.Open: return "O";
                case EnquiryStatus.Won: return "P";
                case EnquiryStatus.Lost: return "L";
                case EnquiryStatus.Closed: return "C";
                default: throw new ArgumentException("Invalid EnquiryStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("O".Equals(code)) return EnquiryStatus.Open;
            else if ("C".Equals(code)) return EnquiryStatus.Closed;
            else if ("P".Equals(code)) return EnquiryStatus.Won;
            else if ("L".Equals(code)) return EnquiryStatus.Lost;
            throw new ArgumentException("Cannot convert value '" + code + "' to EnquiryStatus.");
        }
    }
    public class CommonParkingStringType : NHibernate.Type.EnumStringType
    {
        public CommonParkingStringType() : base(typeof(CommonParking), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((CommonParking)enm)
            {
                case CommonParking.Yes: return "Y";
                case CommonParking.No: return "N";
                default: throw new ArgumentException("Invalid CommonParking.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return CommonParking.Yes;
            else if ("N".Equals(code)) return CommonParking.No;
            throw new ArgumentException("Cannot convert value '" + code + "' to CommonParking.");
        }
    }
   
    public class ParkingStatusStringType : NHibernate.Type.EnumStringType
    {
        public ParkingStatusStringType() : base(typeof(ParkingStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((ParkingStatus)enm)
            {
                case ParkingStatus.Available: return "A";
                case ParkingStatus.Reserved: return "R";
                case ParkingStatus.Allotted: return "X";
                default: throw new ArgumentException("Invalid ParkingStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("A".Equals(code)) return ParkingStatus.Available;
            else if ("R".Equals(code)) return ParkingStatus.Reserved;
            else if ("X".Equals(code)) return ParkingStatus.Allotted;
            throw new ArgumentException("Cannot convert value '" + code + "' to ParkingStatus.");
        }
    }
    public class PRScheduleStageStatusStringType : NHibernate.Type.EnumStringType
    {
        public PRScheduleStageStatusStringType() : base(typeof(PRScheduleStageStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PRScheduleStageStatus)enm)
            {
                case PRScheduleStageStatus.Pending: return "P";
                case PRScheduleStageStatus.Completed: return "C";
                default: throw new ArgumentException("Invalid PRScheduleStageStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("P".Equals(code)) return PRScheduleStageStatus.Pending;
            else if ("C".Equals(code)) return PRScheduleStageStatus.Completed;
            throw new ArgumentException("Cannot convert value '" + code + "' to PRScheduleStageStatus.");
        }
    }
    public class IncludeInPymtTotalStringType : NHibernate.Type.EnumStringType
    {
        public IncludeInPymtTotalStringType() : base(typeof(IncludeInPymtTotal), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((IncludeInPymtTotal)enm)
            {
                case IncludeInPymtTotal.Yes: return "Y";
                case IncludeInPymtTotal.No: return "N";
                default: throw new ArgumentException("Invalid IncludeInPymtTotal.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return IncludeInPymtTotal.Yes;
            else if ("N".Equals(code)) return IncludeInPymtTotal.No;
            throw new ArgumentException("Cannot convert value '" + code + "' to IncludeInPymtTotal.");
        }
    }
    public class PaymentFromSearchByStringType : NHibernate.Type.EnumStringType
    {
        public PaymentFromSearchByStringType() : base(typeof(PaymentFromSearchBy), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PaymentFromSearchBy)enm)
            {
                case PaymentFromSearchBy.FIRM: return "FIRM";
                case PaymentFromSearchBy.CUSTOMER: return "CUSTOMER";
                default: throw new ArgumentException("Invalid PaymentFromSearchBy.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("FIRM".Equals(code)) return PaymentFromSearchBy.FIRM;
            else if ("CUSTOMER".Equals(code)) return PaymentFromSearchBy.CUSTOMER;
            throw new ArgumentException("Cannot convert value '" + code + "' to PaymentFromSearchBy.");
        }
    }
    public class PaymentToSearchByStringType : NHibernate.Type.EnumStringType
    {
        public PaymentToSearchByStringType() : base(typeof(PaymentToSearchBy), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PaymentToSearchBy)enm)
            {
                case PaymentToSearchBy.FIRM: return "FIRM";
                case PaymentToSearchBy.CUSTOMER: return "CUSTOMER";
                case PaymentToSearchBy.AGENCY: return "AGENCY";
                case PaymentToSearchBy.CONTRACTOR: return "CONTRACTOR";
                case PaymentToSearchBy.SUPPLIER: return "SUPPLIER";
                default: throw new ArgumentException("Invalid PaymentToSearchBy.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("FIRM".Equals(code)) return PaymentToSearchBy.FIRM;
            else if ("CUSTOMER".Equals(code)) return PaymentToSearchBy.CUSTOMER;
            else if ("AGENCY".Equals(code)) return PaymentToSearchBy.AGENCY;
            else if ("CONTRACTOR".Equals(code)) return PaymentToSearchBy.CONTRACTOR;
            else if ("SUPPLIER".Equals(code)) return PaymentToSearchBy.SUPPLIER;
            throw new ArgumentException("Cannot convert value '" + code + "' to PaymentToSearchBy.");
        }
    }
    public class PRUnitStatusStringType : NHibernate.Type.EnumStringType
    {
        public PRUnitStatusStringType() : base(typeof(PRUnitStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PRUnitStatus)enm)
            {
                case PRUnitStatus.Available: return "A";
                case PRUnitStatus.Reserved: return "R";
                case PRUnitStatus.Sold: return "S";
                case PRUnitStatus.Deleted: return "D";
                default: throw new ArgumentException("Invalid PRUnitStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("A".Equals(code)) return PRUnitStatus.Available;
            else if ("R".Equals(code)) return PRUnitStatus.Reserved;
            else if ("S".Equals(code)) return PRUnitStatus.Sold;
            else if ("D".Equals(code)) return PRUnitStatus.Deleted;
            throw new ArgumentException("Cannot convert value '" + code + "' to PRUnitStatus.");
        }
    }
    public class IsPoaStringType : NHibernate.Type.EnumStringType
    {
        public IsPoaStringType() : base(typeof(PowerOfAtorny), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PowerOfAtorny)enm)
            {
                case PowerOfAtorny.Yes: return "Y";
                case PowerOfAtorny.No: return "N";
                default: return null;
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return PowerOfAtorny.Yes;
            else if ("N".Equals(code)) return PowerOfAtorny.No;
            return null;
        }
    }
    public class PRUnitSaleStatusStringType : NHibernate.Type.EnumStringType
    {
        public PRUnitSaleStatusStringType() : base(typeof(PRUnitSaleStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PRUnitSaleStatus)enm)
            {
                case PRUnitSaleStatus.Sold: return "S";
                case PRUnitSaleStatus.Cancelled: return "C";
                default: throw new ArgumentException("Invalid PRUnitSaleStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("S".Equals(code)) return PRUnitSaleStatus.Sold;
            else if ("C".Equals(code)) return PRUnitSaleStatus.Cancelled;
            throw new ArgumentException("Cannot convert value '" + code + "' to PRUnitSaleStatus.");
        }
    }
    public class IsPossessionDoneStringType : NHibernate.Type.EnumStringType
    {
        public IsPossessionDoneStringType() : base(typeof(IsPossessionDone), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((IsPossessionDone)enm)
            {
                case IsPossessionDone.Yes: return "Y";
                case IsPossessionDone.No: return "N";
                default: throw new ArgumentException("Invalid IsPossessionDone.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return IsPossessionDone.Yes;
            else if ("N".Equals(code)) return IsPossessionDone.No;
            throw new ArgumentException("Cannot convert value '" + code + "' to IsPossessionDone.");
        }
    }
    public class IsAgreementDoneStringType : NHibernate.Type.EnumStringType
    {
        public IsAgreementDoneStringType() : base(typeof(IsAgreementDone), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((IsAgreementDone)enm)
            {
                case IsAgreementDone.Yes: return "Y";
                case IsAgreementDone.No: return "N";
                default: throw new ArgumentException("Invalid IsAgreementDone.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("Y".Equals(code)) return IsAgreementDone.Yes;
            else if ("N".Equals(code)) return IsAgreementDone.No;
            throw new ArgumentException("Cannot convert value '" + code + "' to IsAgreementDone.");
        }
    }
    public class PRUnitSalePymtToStringType : NHibernate.Type.EnumStringType
    {
        public PRUnitSalePymtToStringType() : base(typeof(PRUnitSalePymtTo), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PRUnitSalePymtTo)enm)
            {
                case PRUnitSalePymtTo.Builder: return "B";
                case PRUnitSalePymtTo.Customer: return "C";
                default: throw new ArgumentException("Invalid PRUnitSalePymtTo.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("B".Equals(code)) return PRUnitSalePymtTo.Builder;
            else if ("C".Equals(code)) return PRUnitSalePymtTo.Customer;
            throw new ArgumentException("Cannot convert value '" + code + "' to PRUnitSalePymtTo.");
        }
    }
    public class PymtMasterStatusStringType : NHibernate.Type.EnumStringType
    {
        public PymtMasterStatusStringType() : base(typeof(PymtMasterStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PymtMasterStatus)enm)
            {
                case PymtMasterStatus.Paid: return "P";
                case PymtMasterStatus.Pending: return "X";
                case PymtMasterStatus.Deleted: return "D";
                case PymtMasterStatus.Suspended: return "S";
                default: throw new ArgumentException("Invalid PymtMasterStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("P".Equals(code)) return PymtMasterStatus.Paid;
            else if ("X".Equals(code)) return PymtMasterStatus.Pending;
            else if ("D".Equals(code)) return PymtMasterStatus.Deleted;
            else if ("S".Equals(code)) return PymtMasterStatus.Suspended;
            throw new ArgumentException("Cannot convert value '" + code + "' to PymtMasterStatus.");
        }
    }
    public class PaymentModeStringType : NHibernate.Type.EnumStringType
    {
        public PaymentModeStringType() : base(typeof(PaymentMode), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PaymentMode)enm)
            {
                case PaymentMode.CASH: return "CASH";
                case PaymentMode.CHEQUE: return "CHQ";
                case PaymentMode.DD: return "DD";
                case PaymentMode.NEFT: return "NEFT";
                case PaymentMode.RTGS: return "RTGS";
                default: throw new ArgumentException("Invalid PaymentMode.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("CASH".Equals(code)) return PaymentMode.CASH;
            else if ("CHQ".Equals(code)) return PaymentMode.CHEQUE;
            else if ("DD".Equals(code)) return PaymentMode.DD;
            else if ("NEFT".Equals(code)) return PaymentMode.NEFT;
            else if ("RTGS".Equals(code)) return PaymentMode.RTGS;
            throw new ArgumentException("Cannot convert value '" + code + "' to PaymentMode.");
        }
    }
    public class PymtTransStatusStringType : NHibernate.Type.EnumStringType
    {
        public PymtTransStatusStringType() : base(typeof(PymtTransStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PymtTransStatus)enm)
            {
                case PymtTransStatus.Pending: return "X";
                case PymtTransStatus.Paid: return "P";
                case PymtTransStatus.Deleted: return "D";
                case PymtTransStatus.Reversal: return "R";
                default: throw new ArgumentException("Invalid PymtTransStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("X".Equals(code)) return PymtTransStatus.Pending;
            else if ("P".Equals(code)) return PymtTransStatus.Paid;
            else if ("D".Equals(code)) return PymtTransStatus.Deleted;
            else if ("R".Equals(code)) return PymtTransStatus.Reversal;
            throw new ArgumentException("Cannot convert value '" + code + "' to PymtTransStatus.");
        }
    }
    public class PdcChequeStatusStringType : NHibernate.Type.EnumStringType
    {
        public PdcChequeStatusStringType() : base(typeof(PdcChequeStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PdcChequeStatus)enm)
            {
                case PdcChequeStatus.Collected: return "C";
                case PdcChequeStatus.Deposited: return "D";
                case PdcChequeStatus.Cleared: return "P";
                case PdcChequeStatus.Bounced: return "B";
                default: throw new ArgumentException("Invalid PdcChequeStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("C".Equals(code)) return PdcChequeStatus.Collected;
            else if ("D".Equals(code)) return PdcChequeStatus.Deposited;
            else if ("P".Equals(code)) return PdcChequeStatus.Cleared;
            else if ("B".Equals(code)) return PdcChequeStatus.Bounced;
            throw new ArgumentException("Cannot convert value '" + code + "' to PdcChequeStatus.");
        }
    }
    public class PdcPymtStatusStringType : NHibernate.Type.EnumStringType
    {
        public PdcPymtStatusStringType() : base(typeof(PdcPymtStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((PdcPymtStatus)enm)
            {
                case PdcPymtStatus.Pending: return "X";
                case PdcPymtStatus.Paid: return "P";
                case PdcPymtStatus.Deleted: return "D";
                default: throw new ArgumentException("Invalid PdcPymtStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("X".Equals(code)) return PdcPymtStatus.Pending;
            else if ("P".Equals(code)) return PdcPymtStatus.Paid;
            else if ("D".Equals(code)) return PdcPymtStatus.Deleted;
            throw new ArgumentException("Cannot convert value '" + code + "' to PdcPymtStatus.");
        }
    }
    public class AcntTransStatusStringType : NHibernate.Type.EnumStringType
    {
        public AcntTransStatusStringType() : base(typeof(AcntTransStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((AcntTransStatus)enm)
            {
                case AcntTransStatus.Credit: return "C";
                case AcntTransStatus.Debit: return "D";
                default: throw new ArgumentException("Invalid AcntTransStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("C".Equals(code)) return AcntTransStatus.Credit;
            else if ("D".Equals(code)) return AcntTransStatus.Debit;
            throw new ArgumentException("Cannot convert value '" + code + "' to AcntTransStatus.");
        }
    }
    public class AcntDepositStatusStringType : NHibernate.Type.EnumStringType
    {
        public AcntDepositStatusStringType() : base(typeof(AcntDepositStatus), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((AcntDepositStatus)enm)
            {
                case AcntDepositStatus.Deposited: return "C";
                case AcntDepositStatus.Reversed: return "D";
                default: throw new ArgumentException("Invalid AcntDepositStatus.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("C".Equals(code)) return AcntDepositStatus.Deposited;
            else if ("D".Equals(code)) return AcntDepositStatus.Reversed;
            throw new ArgumentException("Cannot convert value '" + code + "' to AcntDepositStatus.");
        }
    }
    
    public class FunctionNameStringType : NHibernate.Type.EnumStringType
    {
        public FunctionNameStringType() : base(typeof(FunctionName), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((FunctionName)enm)
            {
                case FunctionName.ENQUIRY: return "ENQ";
                case FunctionName.SALE: return "SAL";
                default: throw new ArgumentException("Invalid FunctionName.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("ENQ".Equals(code)) return FunctionName.ENQUIRY;
            else if ("SAL".Equals(code)) return FunctionName.SALE;
            throw new ArgumentException("Cannot convert value '" + code + "' to FunctionName.");
        }
    }
    public class EmailSmsTypeStringType : NHibernate.Type.EnumStringType
    {
        public EmailSmsTypeStringType() : base(typeof(EmailSmsType), 1) { }
        public override object GetValue(object enm)
        {
            if (null == enm) return String.Empty;
            switch ((EmailSmsType)enm)
            {
                case EmailSmsType.ENQUIRYTHANKS: return "ENT";
                case EmailSmsType.SALESTHANKS: return "SAT";
                case EmailSmsType.SALESCANCEL: return "SAC";
                default: throw new ArgumentException("Invalid EmailSmsType.");
            }
        }
        public override object GetInstance(object code)
        {
            if ("ENT".Equals(code)) return EmailSmsType.ENQUIRYTHANKS;
            else if ("SAT".Equals(code)) return EmailSmsType.SALESTHANKS;
            else if ("SAC".Equals(code)) return EmailSmsType.SALESCANCEL;
            throw new ArgumentException("Cannot convert value '" + code + "' to EmailSmsType.");
        }
    }

}