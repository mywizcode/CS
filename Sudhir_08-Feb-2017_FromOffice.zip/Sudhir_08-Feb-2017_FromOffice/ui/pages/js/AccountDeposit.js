﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initDepositGrid();
    formatFields();
    initViewMode("tab2Content");
    //This script will enable tabs which was last active even after postback call.
    enableTab(true);
}

function initDepositGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "DepositGrid",
        isViewOnly: isViewOnly,
        pageLength: 10,
        responsiveModalTitle: "Deposit Details",
        customBtnGrpId: "#DepositSearchBtnDiv",
        hasRowInfo: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToDepositHdnId");
}