﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initPropertyUnitManagement();
   
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("tab2Content");
    enableTab(true);
}

function initPropertyUnitManagement1() {
    var dtOptions = {
        tableId: "proprtyunitGrid",
        isViewOnly: false,
        pageLength: 5,
        responsiveModalTitle: "Property Unit Details",
        customBtnGrpId: "#propunitSearchBtnDiv",
        hasRowInfo: false
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPropertyUnitHdnId");
}

function initPropertyUnitManagement() {
    var tableId = "proprtyunitGrid";
    $("[id$='" + tableId + "']").prepend($("<thead></thead>").append($("[id$='" + tableId + "']").find("tr:first")));
    var dtTable = $("[id$='" + tableId + "']").DataTable({
        autoWidth: false,
        dom: "<'row'<'col-md-6 col-sm-6 col-xs-3 tmpCustomBtn'l><'col-md-6 col-sm-6 col-xs-9'f>>" +
               "<'row'<'col-sm-12'<'datatable-scroll'tr>>>" +
               "<'row'<'col-sm-5'i><'col-sm-7'p>>",
        pageLength: 10,
        ordering: false
    });
    $("[id$='" + tableId + "_wrapper']").find('.tmpCustomBtn').html($('#propunitSearchBtnDiv').html());
    $('#propunitSearchBtnDiv').html('')
    dtTable.on('draw.dt', function () { formatAutoNumeric(""); });
}



