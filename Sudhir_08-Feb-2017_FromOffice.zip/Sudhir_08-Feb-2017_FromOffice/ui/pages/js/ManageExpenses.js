﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initExpencessGrid();
    initDocumentGrid();    
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("tab2Content");
    //This script will enable tabs which was last active even after postback call.
    enableTab(false);
}

function initDocumentGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "documentGrid",
        isViewOnly: isViewOnly,
        pageLength: 5,
        responsiveModalTitle: "Document Details",
        customBtnGrpId: "#documentGridBtnDiv",
        hasRowInfo: true,
        hideSearch: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToDocumentHdnId");
}

function initExpencessGrid() {
    var dtOptions = {
        tableId: "propertyexpencessGrid",
        isViewOnly: false,
        pageLength: 10,
        responsiveModalTitle: "Expencess Details",
        customBtnGrpId: "#expSearchBtnDiv",
        hasRowInfo: false
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPropertyExpencessHdnId");
}

