$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initAccountGrid();
    formatFields();
    initViewMode("tab1Content");
    enableTab(false);
}

function initAccountGrid() {
    var dtOptions = {
        tableId: "accountGrid",
        isViewOnly: false,
        pageLength: 5,
        responsiveModalTitle: "Account Details",
        customBtnGrpId: "#customBtnDiv",
        hasRowInfo: true
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToAcntHdnId");
}