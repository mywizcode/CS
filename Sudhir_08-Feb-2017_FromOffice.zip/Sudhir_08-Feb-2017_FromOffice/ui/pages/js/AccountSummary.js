$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initAccountSummaryGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    makeReadOnlySection("pnlAcntSummaryInfo");
}

function initAccountSummaryGrid() {
    var tableId = "acntSummaryGrid";
    $("[id$='" + tableId + "']").prepend($("<thead></thead>").append($("[id$='" + tableId + "']").find("tr:first")));
    var dtTable = $("[id$='" + tableId + "']").DataTable({
        autoWidth: false,
        dom: "<'row'<'col-sm-6 col-xs-3 tmpCustomBtn'l><'col-sm-6 col-xs-9'>>" +
               "<'row'<'col-sm-12'<'datatable-scroll'tr>>>" +
               "<'row'<'col-sm-5'i><'col-sm-7'p>>",
        pageLength: 10,
        ordering: false
    });
    $("[id$='" + tableId + "_wrapper']").find('.tmpCustomBtn').html($('#acntSummaryGridBtnGrp').html());
    $('#acntSummaryGridBtnGrp').html('')
    dtTable.on('draw.dt', function () { formatAutoNumeric(""); });
}