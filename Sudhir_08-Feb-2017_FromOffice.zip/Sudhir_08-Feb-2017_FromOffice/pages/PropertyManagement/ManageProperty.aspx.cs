﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;

public partial class ManageProperty : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string tab1ValidationGrp = "tab1Error";
    string tab2BzStep1Error = "tab2BzStep1Error";
    string tab2BzStep2Error = "tab2BzStep2ErrorGrid1";
    string tab2BzStep1 = "bzstep1";
    string tab2BzStep2 = "bzstep2";
    string VS_PROPERTY_LIST = "PROPERTY_LIST";
    string VS_SELECTED_EMPLOYEE = "SELECTED_PROPERTY";
    DropdownBO drpBO = new DropdownBO();
    PropertyBO propertyBO = new PropertyBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    DepartmentBO departmentBO = new DepartmentBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (Session[Constants.Session.USERNAME] != null)
            {
                resetTabInfo(PageMode.NONE);
                initDropdowns();
                loadSearchGridAndReSelect(0);
                Page.MaintainScrollPositionOnPostBack = false;
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpPropertytype, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpPropertyLocation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_LOCATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAccount, DrpDataType.FIRM_ACCOUNT, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<PropertySearchBy>(drpSearchBy, null);
        drpBO.drpDataBase(drpAddressCountry, DrpDataType.COUNTRY, null, null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAddressState, DrpDataType.STATE, Constants.DEFAULT_COUNTRY, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpPropertyChargesType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_CHARGES, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpTaxType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_TAX_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpAddressState.Text = Constants.DEFAULT_STATE;
        initCityDrp(drpAddressCity, Constants.DEFAULT_STATE);
        drpBO.drpEnum<IncludeInPymtTotal>(drpTaxIncludeInPymt, null);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        applyEntitlement();
        preRenderInitFormElements();
        initBootstrapComponantsFromServer();
    }
    private bool isViewOnlyUser()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        bool isViewOnlyUser = !CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.FIRM_MEMBER_ADD_UPDATE);
        return isViewOnlyUser;
    }
    private void applyEntitlement()
    {
        if (isViewOnlyUser())
        {
            btnAddProperty.Visible = false;
            btnModifyProperty.Visible = false;
            btnDeleteProperty.Visible = false;
        }
    }
    private void preRenderInitFormElements()
    {
        PropertyDTO selectedProperty = getCurrentProperty();
        jumpToPropertyHdnId.Value = "";
        jumpToPropertyTowerHdnId.Value = "";
        jumpToTaxDetailHdnId.Value = "";
        jumpToChargesDetailHdnId.Value = "";
        if (selectedProperty != null)
        {
            jumpToPropertyHdnId.Value = selectedProperty.Id.ToString();
            if (selectedProperty.PropertyTowers != null && selectedProperty.PropertyTowers.Count > 0)
            {
                List<PropertyTowerDTO> propertyTowerList = selectedProperty.PropertyTowers.ToList<PropertyTowerDTO>();
                PropertyTowerDTO selectedTower = propertyTowerList.Find(a => a.isUISelected);
                if (selectedTower != null) jumpToPropertyTowerHdnId.Value = selectedTower.UiIndex.ToString();
            }
            if (selectedProperty.PropertyTaxDetails != null && selectedProperty.PropertyTaxDetails.Count > 0)
            {
                List<PropertyTaxDetailDTO> taxDetailList = selectedProperty.PropertyTaxDetails.ToList<PropertyTaxDetailDTO>();
                PropertyTaxDetailDTO taxDetail = taxDetailList.Find(a => a.isUISelected);
                if (taxDetail != null) jumpToTaxDetailHdnId.Value = taxDetail.UiIndex.ToString();
            }
            if (selectedProperty.PropertyCharges != null && selectedProperty.PropertyCharges.Count > 0)
            {
                List<PropertyChargeDTO> ChargesDetailList = selectedProperty.PropertyCharges.ToList<PropertyChargeDTO>();
                PropertyChargeDTO chargeDetail = ChargesDetailList.Find(a => a.isUISelected);
                if (chargeDetail != null) jumpToTaxDetailHdnId.Value = chargeDetail.UiIndex.ToString();
            }
        }
        if (PageMode.VIEW.ToString() == pageModeHdn.Value)
        {
            populateUIFieldsFromDTO((PropertyDTO)ViewState[VS_SELECTED_EMPLOYEE]);
        }
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        if (group.Equals(tab2BzStep1Error)) tab2ContentBzHdn.Value = tab2BzStep1;
        else if (group.Equals(tab2BzStep2Error)) tab2ContentBzHdn.Value = tab2BzStep2;
    }

    public void setSuccessMessage(string msg, string tabId, string bzStep)
    {
        activeTabHdn.Value = tabId;
        if (tabId.Equals(tab1Anchor.ID))
        {
            lbTab1Success.Text = msg;
            tab1SuccessPanel.Visible = true;
        }
        else if (tabId.Equals(tab2Anchor.ID))
        {
            if (tab2BzStep1.Equals(bzStep))
            {
                lbTab2BzStep1Success.Text = msg;
                tab2BzStep1SuccessPanel.Visible = true;
                tab2ContentBzHdn.Value = tab2BzStep1;
            }
            else
            {
                lbTab2BzStep2Success.Text = msg;
                tab2BzStep2SuccessPanel.Visible = true;
                tab2ContentBzHdn.Value = tab2BzStep2;
            }
        }
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private void clearMessages()
    {
        tab1SuccessPanel.Visible = false;
        lbTab1Success.Text = "";
        tab2BzStep1SuccessPanel.Visible = false;
        lbTab2BzStep1Success.Text = "";
        tab2BzStep2SuccessPanel.Visible = false;
        lbTab2BzStep2Success.Text = "";
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }

    private void resetTabInfo(PageMode pageMode)
    {
        tab2Anchor.Visible = true;
        activeTabHdn.Value = tab2Anchor.ID;
        pageModeHdn.Value = pageMode.ToString();
        initFormFields();
        pnlPropertyTowerAdd.Visible = false;
        pnlTaxDetailAdd.Visible = false;
        pnlChargesDetailAdd.Visible = false;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        tab2ContentBzHdn.Value = tab2BzStep1;
        if (PageMode.ADD == pageMode)
        {
            tab2Anchor.Text = Resources.Labels.prpm_sm_manage_prop_tab2_add_name;
            initFormFields();
        }
        else if (PageMode.MODIFY == pageMode)
        {
            tab2Anchor.Text = Resources.Labels.prpm_sm_manage_prop_tab2_modify_name;
            initFormFields();
        }
        else if (PageMode.VIEW == pageMode)
        {
            tab2Anchor.Text = Resources.Labels.prpm_sm_manage_prop_tab2_view_name;
            initFormFields();
        }
        else
        {
            activeTabHdn.Value = tab1Anchor.ID;
            tab2Anchor.Visible = false;
            ViewState[VS_SELECTED_EMPLOYEE] = null;
        }
    }
    private void initFormFields()
    {
        bool isReadOnly = (PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
        bool visible = !(PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
        //Buttons
        btnAddSubmit.Visible = visible;
        addPropertyTypeBtn.Visible = visible;
        addPropertyLocationBtn.Visible = visible;
        btnAddPropTower.Visible = visible;
        btnModifyPropTower.Visible = visible;
        btnDeletePropTower.Visible = visible;
        propertyTowerGrid.Columns[0].Visible = visible;
        
        btnAddTaxDetail.Visible = visible;
        btnModifyTaxDetail.Visible = visible;
        btnDeleteTaxDetail.Visible = visible;
        taxDetailGrid.Columns[0].Visible = visible;

        btnAddCharges.Visible = visible;
        btnModifyCharges.Visible = visible;
        btnDeleteChargeDetail.Visible = visible;
        PropertyChargesGrid.Columns[0].Visible = visible;
    }
    private PropertyDTO getCurrentProperty()
    {
        return (PropertyDTO)ViewState[VS_SELECTED_EMPLOYEE];
    }
    private void setSelectedProperty(long selectedId)
    {
        List<PropertyDTO> PropertyList = (List<PropertyDTO>)ViewState[VS_PROPERTY_LIST];
        if (PropertyList != null)
        {
            PropertyList.ForEach(c => c.isUISelected = false);
            if (selectedId > 0) PropertyList.Find(c => c.Id == selectedId).isUISelected = true;
        }
    }
    private bool validatePropertySelected()
    {
        bool isSelected = true;
        List<PropertyDTO> PropertyList = (List<PropertyDTO>)ViewState[VS_PROPERTY_LIST];
        if (PropertyList != null)
        {
            isSelected = PropertyList.Any(c => c.isUISelected);
            if (!isSelected)
            {
                resetTabInfo(PageMode.NONE);
                setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Property"), tab1ValidationGrp);
            }
        }
        return isSelected;
    }
    private void selectPropertyGridRdBtn(long Id)
    {
        if (propertyGrid.Rows.Count > 0)
        {
            setSelectedProperty(0);
            foreach (GridViewRow row in propertyGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdPropertySelect");
                Button rowIdenBtn = (Button)row.FindControl("btnPropRowIdentifier");
                if (radioBtn != null)
                {
                    radioBtn.Checked = false;
                    if (rowIdenBtn != null && Id > 0 && Id.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                    {
                        radioBtn.Checked = true;
                        setSelectedProperty(Id);
                    }
                }
            }
        }
    }
    private void loadSearchGridAndReSelect(long Id)
    {
        try
        {
            PropertySearchBy searchBy = EnumHelper.ToEnum<PropertySearchBy>(drpSearchBy.Text);
            long searchByValId = -1;
            if (!string.IsNullOrWhiteSpace(drpSearchByValue.Text)) searchByValId = long.Parse(drpSearchByValue.Text);
            IList<PropertyDTO> results = propertyBO.fetchPropertyGridData(getUserDefinitionDTO().FirmNumber, searchBy, searchByValId);
            ViewState[VS_PROPERTY_LIST] = results;
            propertyGrid.DataSource = results;
            propertyGrid.DataBind();
            if (Id > 0)
            {
                selectPropertyGridRdBtn(Id);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private void fetchSelectedProperty()
    {
        try
        {
            PropertyDTO propertyDTO = null;
            if (PageMode.ADD.ToString().Equals(pageModeHdn.Value))
            {
                propertyDTO = populatepropertyDTOAdd();
                selectPropertyGridRdBtn(0);
            }
            else if (PageMode.MODIFY.ToString().Equals(pageModeHdn.Value) || PageMode.VIEW.ToString().Equals(pageModeHdn.Value))
            {
                long Id = ((List<PropertyDTO>)ViewState[VS_PROPERTY_LIST]).Find(c => c.isUISelected).Id;
                propertyDTO = propertyBO.fetchProperty(Id);
            }
            ViewState[VS_SELECTED_EMPLOYEE] = propertyDTO;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private void doViewModifyAction(PageMode pageMode)
    {
        resetTabInfo(pageMode);
        fetchSelectedProperty();
        populateUIFieldsFromDTO((PropertyDTO)ViewState[VS_SELECTED_EMPLOYEE]);
    }
    protected void onSearchBy(object sender, EventArgs e)
    {
        try
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            PropertySearchBy searchBy = EnumHelper.ToEnum<PropertySearchBy>(drpSearchBy.Text);
            drpSearchByValue.Visible = true;
            lbSearchByValue.Visible = true;
            lbSearchByValue.Text = EnumHelper.GetEnumDescription<PropertySearchBy>(searchBy.ToString());
            if (PropertySearchBy.PROPERTY_NAME == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.PROPERTY_SEARCH_BY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else if (PropertySearchBy.PROPERTY_TYPE == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else if (PropertySearchBy.PROPERTY_LOCATION == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_LOCATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else
            {
                drpSearchByValue.ClearSelection();
                drpSearchByValue.Visible = false;
                lbSearchByValue.Visible = false;
            }
            loadSearchGridAndReSelect(0);
            resetTabInfo(PageMode.NONE);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSearchByValue(object sender, EventArgs e)
    {
        loadSearchGridAndReSelect(0);
        resetTabInfo(PageMode.NONE);
    }
    protected void selectProperty(object sender, EventArgs e)
    {
        try
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            resetTabInfo(PageMode.NONE);
            if (rd.Checked)
            {
                string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnPropRowIdentifier"))).Attributes["row-identifier"];
                setSelectedProperty(long.Parse(strId));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    /*
     * This method is called on click of ADD button in datatable top bar.
     */
    protected void onClickAddPropertyBtn(object sender, EventArgs e)
    {
        try
        {
            resetTabInfo(PageMode.ADD);
            fetchSelectedProperty();
            populateUIFieldsFromDTO(null);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickViewPropertyBtn(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertySelected())
            {
                doViewModifyAction(PageMode.VIEW);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickModifyPropertyBtn(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertySelected())
            {
                doViewModifyAction(PageMode.MODIFY);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void deleteProperty(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertySelected())
            {
                long Id = ((List<PropertyDTO>)ViewState[VS_PROPERTY_LIST]).Find(c => c.isUISelected).Id;
                propertyBO.deleteProperty(Id);
                loadSearchGridAndReSelect(0);
                resetTabInfo(PageMode.NONE);
                setSuccessMessage(string.Format(Resources.Messages.success_record_delete, "Property"), tab1Anchor.ID, tab2BzStep1);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void addOrModifyProperty(object sender, EventArgs e)
    {
        try
        {
            if (validateAddUpdateProperty())
            {
                PropertyDTO propertyDTO = getCurrentProperty();
                long Id = propertyDTO.Id;
                populatePropertyDTOFromUI(propertyDTO);
                if (PageMode.ADD.ToString().Equals(pageModeHdn.Value))
                {
                    Id = propertyBO.saveProperty(propertyDTO);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_add, "Property"), tab2Anchor.ID, tab2BzStep1);
                }
                else if (PageMode.MODIFY.ToString().Equals(pageModeHdn.Value))
                {
                    propertyBO.updateProperty(propertyDTO);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_update, "Property"), tab2Anchor.ID, tab2BzStep1);
                }
                loadSearchGridAndReSelect(Id);
                doViewModifyAction(PageMode.VIEW);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2BzStep1Error);
        }
    }
    protected void cancelProperty(object sender, EventArgs e)
    {
        PropertyDTO propertyDTO = getCurrentProperty();
        resetTabInfo(PageMode.NONE);
        loadSearchGridAndReSelect(propertyDTO.Id);
    }
    protected void gotoTab2StepyWizard(object sender, EventArgs e)
    {
        bool isValid = validateTab2Step(tab2ContentBzHdn.Value);
        if (isValid)
        {
            setCurrentStep(goToStepHdn.Value);
        }
    }
    /**
     * Define all validation which will be done before add or update property.
     * */
    private bool validateAddUpdateProperty()
    {
        bool isValid = validateTab2Step(tab2BzStep1);
        return isValid;
    }
    /**
     * Validates given step.
     * */
    private bool validateTab2Step(string step)
    {
        bool isValid = true;
        if (!PageMode.VIEW.ToString().Equals(pageModeHdn.Value))
        {
            if (step.Equals(tab2BzStep1))
            {
                isValid = validateAllStep1Group();
            }
            else if (step.Equals(tab2BzStep2))
            {

            }
        }
        return isValid;
    }
    private bool validateAllStep1Group()
    {
        Page.Validate(tab2BzStep1Error);
        bool isValid = Page.IsValid;
        PropertyDTO propertyDTO = getCurrentProperty();
        if (propertyDTO.PropertyTowers == null || propertyDTO.PropertyTowers.Count == 0)
        {
            setErrorMessage("Please add atleast one Property Tower", tab2BzStep1Error);
            isValid = false;
        }
        if (!isValid)
        {
            tab2ContentBzHdn.Value = tab2BzStep1;
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    private void setCurrentStep(string step)
    {
        tab2ContentBzHdn.Value = step;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    protected void loadCities(object sender, EventArgs e)
    {
        initCityDrp(drpAddressCity, drpAddressState.Text);
        SetFocus(drpAddressCity);
    }
    private PropertyDTO populatepropertyDTOAdd()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        PropertyDTO propertyDTO = new PropertyDTO();
        propertyDTO.ContactInfo = new ContactInfoDTO();
        propertyDTO.ContactInfo.Contact = "0";
        propertyDTO.ContactInfo.Addresses = new HashSet<AddressDTO>();
        AddressDTO addressDto = new AddressDTO();
        addressDto.PreferredAddress = PreferredAddress.Yes;
        addressDto.AddressType = masterDataBO.getAnyAddressType(userDefDto.FirmNumber);
        propertyDTO.ContactInfo.Addresses.Add(addressDto);
        propertyDTO.PropertyTowers = new HashSet<PropertyTowerDTO>();
        propertyDTO.PropertyTaxDetails = new HashSet<PropertyTaxDetailDTO>();
        propertyDTO.PropertyCharges = new HashSet<PropertyChargeDTO>();
        propertyDTO.DocumentInfo = new DocumentInfoDTO();
        propertyDTO.FirmNumber = userDefDto.FirmNumber;
        propertyDTO.InsertUser = userDefDto.Username;
        return propertyDTO;
    }
    private void populatePropertyDTOFromUI(PropertyDTO propertyDTO)
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        propertyDTO.Name = txtPropertyName.Text;
        propertyDTO.PropertyType = CommonUIConverter.getMasterControlDTO(drpPropertytype.Text, null);
        propertyDTO.PropertyLocation = CommonUIConverter.getMasterControlDTO(drpPropertyLocation.Text, null);
        propertyDTO.PropertyArea = CommonUtil.getDecimalWithoutExt(txtPropertyArea.Text);
        propertyDTO.EstimatedAmt = CommonUtil.getDecimalWithoutExt(txtTotalEstimation.Text);
        propertyDTO.FirmAccount = CommonUIConverter.getFirmAccountDTO(drpAccount.Text, null);
        AddressDTO addressDto = propertyDTO.ContactInfo.Addresses.First();
        addressDto.AddressLine1 = txtAddressLine1.Text;
        addressDto.AddressLine2 = txtAddressLine2.Text;
        addressDto.Town = txtTown.Text;
        addressDto.City = CommonUIConverter.getCityDTO(drpAddressCity.Text, null);
        addressDto.State = CommonUIConverter.getStateDTO(drpAddressState.Text, null);
        addressDto.Country = CommonUIConverter.getCountryDTO(drpAddressCountry.Text, null);
        addressDto.Pin = txtPin.Text;
        propertyDTO.UpdateUser = userDefDto.Username;
        propertyDTO.DocumentInfo.Description = "Property Documents of :" + propertyDTO.Name;
    }
    private void populateUIFieldsFromDTO(PropertyDTO propertyDTO)
    {
        if (propertyDTO != null) txtPropertyName.Text = propertyDTO.Name; else txtPropertyName.Text = null;
        if (propertyDTO != null && propertyDTO.PropertyType != null) drpPropertytype.Text = propertyDTO.PropertyType.Id.ToString(); else drpPropertytype.ClearSelection();
        if (propertyDTO != null && propertyDTO.PropertyLocation != null) drpPropertyLocation.Text = propertyDTO.PropertyLocation.Id.ToString(); else drpPropertyLocation.ClearSelection();
        if (propertyDTO != null && propertyDTO.PropertyArea != null) txtPropertyArea.Text = propertyDTO.PropertyArea.ToString(); else txtPropertyArea.Text = null;
        if (propertyDTO != null && propertyDTO.EstimatedAmt != null) txtTotalEstimation.Text = propertyDTO.EstimatedAmt.ToString(); else txtTotalEstimation.Text = null;
        if (propertyDTO != null && propertyDTO.FirmAccount != null) drpAccount.Text = propertyDTO.FirmAccount.Id.ToString(); else drpAccount.ClearSelection();
        if (propertyDTO != null)
        {
            ISet<AddressDTO> addresses = propertyDTO.ContactInfo.Addresses;
            if (addresses.Count > 0)
            {
                foreach (AddressDTO addressDto in addresses)
                {
                    txtAddressLine1.Text = addressDto.AddressLine1;
                    txtAddressLine2.Text = addressDto.AddressLine2;
                    txtTown.Text = addressDto.Town;
                    drpAddressCountry.Text = addressDto.Country.Id.ToString();
                    drpAddressState.Text = addressDto.State.Id.ToString();
                    initCityDrp(drpAddressCity, drpAddressState.Text);
                    drpAddressCity.Text = addressDto.City.Id.ToString();
                    txtPin.Text = addressDto.Pin;
                }
            }
        }
        populatePropertyTowerGrid(propertyDTO);
        populateTaxDetailGrid(propertyDTO);
        populateChargesDetailGrid(propertyDTO);
    }
    private void initCityDrp(DropDownList drp, string stateId)
    {
        drpBO.drpDataBase(drp, DrpDataType.CITY, stateId, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
    }
    private void populatePropertyTowerGrid(PropertyDTO propertyDTO)
    {
        propertyTowerGrid.DataSource = new List<PropertyTowerDTO>();
        if (propertyDTO != null)
        {
            assignUiIndexToPropertyTower(propertyDTO.PropertyTowers);
            propertyTowerGrid.DataSource = propertyDTO.PropertyTowers;
        }
        propertyTowerGrid.DataBind();
    }
    private void assignUiIndexToPropertyTower(ISet<PropertyTowerDTO> propertyTowerDtos)
    {
        if (propertyTowerDtos != null && propertyTowerDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (PropertyTowerDTO propertyTower in propertyTowerDtos)
            {
                propertyTower.UiIndex = uiIndex++;
                propertyTower.RowInfo = CommonUIConverter.getGridViewRowInfo(propertyTower);
            }
        }
    }
    private void populateTaxDetailGrid(PropertyDTO propertyDTO)
    {
        taxDetailGrid.DataSource = new List<PropertyTaxDetailDTO>();
        if (propertyDTO != null)
        {
            assignUiIndexToTaxDetail(propertyDTO.PropertyTaxDetails);
            taxDetailGrid.DataSource = propertyDTO.PropertyTaxDetails;
        }
        taxDetailGrid.DataBind();
    }

    private void populateChargesDetailGrid(PropertyDTO propertyDTO)
    {
        PropertyChargesGrid.DataSource = new List<PropertyChargeDTO>();
        if (propertyDTO != null)
        {
            assignUiIndexToChargesDetail(propertyDTO.PropertyCharges);            
            PropertyChargesGrid.DataSource = propertyDTO.PropertyCharges;
        }
        PropertyChargesGrid.DataBind();
    }

    private void assignUiIndexToTaxDetail(ISet<PropertyTaxDetailDTO> taxDetailDtos)
    {
        if (taxDetailDtos != null && taxDetailDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (PropertyTaxDetailDTO taxDetailDto in taxDetailDtos)
            {
                taxDetailDto.UiIndex = uiIndex++;
                taxDetailDto.RowInfo = CommonUIConverter.getGridViewRowInfo(taxDetailDto);
            }
        }
    }
    private void assignUiIndexToChargesDetail(ISet<PropertyChargeDTO> chargesDetailDtos)
    {
        if (chargesDetailDtos != null && chargesDetailDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (PropertyChargeDTO chargeDetailDto in chargesDetailDtos)
            {
                chargeDetailDto.UiIndex = uiIndex++;
                chargeDetailDto.RowInfo = CommonUIConverter.getGridViewRowInfo(chargeDetailDto);
            }
        }
    }

    //Modal save logic
    protected void saveModalData(object sender, EventArgs e)
    {
        String errorMsg = "";
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        if (modalHdnType.Value == "PROPERTY_TYPE")
        {
            MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PROPERTY_TYPE, modalInput1.Text,
                   modalInput2.Text, userDefDto);
            errorMsg = validateMasterDataModalInput(masterDataDto, "Property Type");
            if (string.IsNullOrWhiteSpace(errorMsg))
            {
                masterDataBO.saveMasterData(masterDataDto);
                drpBO.drpDataBase(drpPropertytype, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                modalIdentifierHdn.Value = "";
            }
        }
        else if (modalHdnType.Value == "PROPERTY_LOCATION")
        {
            MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PROPERTY_LOCATION, modalInput1.Text,
                   modalInput2.Text, userDefDto);
            errorMsg = validateMasterDataModalInput(masterDataDto, "Property Location");
            if (string.IsNullOrWhiteSpace(errorMsg))
            {
                masterDataBO.saveMasterData(masterDataDto);
                drpBO.drpDataBase(drpPropertyLocation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_LOCATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                modalIdentifierHdn.Value = "";
            }
        }
        else if (modalHdnType.Value == "PROPERTY_TAX")
        {
            MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_TAX_TYPE, modalInput1.Text,
                   modalInput2.Text, userDefDto);
            errorMsg = validateMasterDataModalInput(masterDataDto, "Tax Type");
            if (string.IsNullOrWhiteSpace(errorMsg))
            {
                masterDataBO.saveMasterData(masterDataDto);
                drpBO.drpDataBase(drpTaxType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_TAX_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                modalIdentifierHdn.Value = "";
            }
        }
        else if (modalHdnType.Value == "PROPERTYCHARGE")
        {
            MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PROPERTY_CHARGES, modalInput1.Text,
                   modalInput2.Text, userDefDto);
            errorMsg = validateMasterDataModalInput(masterDataDto, "Property Charge Name");
            if (string.IsNullOrWhiteSpace(errorMsg))
            {
                masterDataBO.saveMasterData(masterDataDto);
                drpBO.drpDataBase(drpPropertyChargesType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_CHARGES, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                modalIdentifierHdn.Value = "";
            }
        }
      
        if (!string.IsNullOrWhiteSpace(errorMsg))
        {
            modalErrorMsg.Value = errorMsg;
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "setModalErrorMsg", "setModalErrorMsg()", true);
        }
        else
        {
            //Reset the modal fields
            modalInput1.Text = "";
            modalInput2.Text = "";
            modalHdnType.Value = "";
            modalActionHdn.Value = "";
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "closeDialogClient", "closeDialogClient()", true);
        }
    }
    private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
    {
        string errorMsg = "";
        if (string.IsNullOrWhiteSpace(masterDataDto.Name))
        {
            errorMsg = string.Format(Resources.Messages.validation_txtfield_required, type);
        }
        else if (masterDataBO.isAlreadyExist(masterDataDto))
        {
            errorMsg = string.Format(Resources.Messages.validation_same_name_exist, type);
        }
        return errorMsg;
    }
    //PropertyTower Table actions - Start
    private void initPropertyTowerAddUpdateSection(bool isAdd)
    {
        lbPropTowerAddUpdateSectionHeader.Text = (isAdd) ? Resources.Labels.label_sectionheader_propertytower_add : Resources.Labels.label_sectionheader_propertytower_modify;
        pnlPropertyTowerAdd.Visible = true;
        btnPropertyTowerAddToGrid.Visible = isAdd;
        btnPropertyTowerUpdateToGrid.Visible = !isAdd;
    }
    private void setDefaultOnAddPropertyTower()
    {
        
    }
    private void initPropertyTowerSectionFields(PropertyTowerDTO propertyTowerDto)
    {
        if (propertyTowerDto != null) txtTowerName.Text = propertyTowerDto.Name; else txtTowerName.Text = null;
        if (propertyTowerDto != null) txtTowerLaunchDate.Text = CommonUtil.getCSDate(propertyTowerDto.LaunchDate); else txtTowerLaunchDate.Text = null;
        if (propertyTowerDto != null && propertyTowerDto.Rate != null) txtTowerRate.Text = propertyTowerDto.Rate.ToString(); else txtTowerRate.Text = null;
        if (propertyTowerDto != null) txtTowerDescription.Text = propertyTowerDto.Description; else txtTowerDescription.Text = null;
        if (propertyTowerDto != null) txtTowerPossession.Text = CommonUtil.getCSDate(propertyTowerDto.Possession); else txtTowerPossession.Text = null;
    }
    private void clearPropertyTowerViewState()
    {
        if (propertyTowerGrid.Rows.Count > 0)
        {
            foreach (GridViewRow row in propertyTowerGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdPropertyTowerSelect");
                if (radioBtn != null) radioBtn.Checked = false;
            }
        }
        PropertyDTO propertyDto = getCurrentProperty();
        if (propertyDto.PropertyTowers != null) propertyDto.PropertyTowers.ToList<PropertyTowerDTO>().ForEach(c => c.isUISelected = false);
    }
    private void selectPropertyTower(PropertyTowerDTO propertyTowerDto)
    {
        if (propertyTowerGrid.Rows.Count > 0)
        {
            propertyTowerDto.isUISelected = true;
            foreach (GridViewRow row in propertyTowerGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdPropertyTowerSelect");
                Button rowIdenBtn = (Button)row.FindControl("btnTowerRowIdentifier");
                radioBtn.Checked = false;
                if (rowIdenBtn != null && propertyTowerDto.UiIndex.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                {
                    radioBtn.Checked = true;
                }
            }
        }
    }
    private PropertyTowerDTO getSelectedPropertyTower()
    {
        return getCurrentProperty().PropertyTowers.ToList<PropertyTowerDTO>().Find(c => c.isUISelected);
    }
    
    private bool validatePropertyTowerSelected()
    {
        bool isSelected = true;
        PropertyTowerDTO propertyTowerDto = getSelectedPropertyTower();
        if (propertyTowerDto == null)
        {
            isSelected = false;
            pnlPropertyTowerAdd.Visible = false;
            clearPropertyTowerViewState();
            setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Property Tower"), tab2BzStep1Error);
        }
        return isSelected;
    }
    private PropertyTowerDTO populatePropertyTowerAdd()
    {
        PropertyTowerDTO propertyTowerDto = new PropertyTowerDTO();
        UserDefinitionDTO userDef =  getUserDefinitionDTO();
        propertyTowerDto.FirmNumber = userDef.FirmNumber;
        propertyTowerDto.InsertUser = userDef.Username;
        return propertyTowerDto;
    }
    private void populatePropertyTowerFromUI(PropertyTowerDTO propertyTowerDto)
    {
        propertyTowerDto.Name = txtTowerName.Text;
        propertyTowerDto.LaunchDate = CommonUtil.getCSDate(txtTowerLaunchDate.Text);
        propertyTowerDto.Rate = CommonUtil.getDecimalWithoutExt(txtTowerRate.Text);
        propertyTowerDto.Possession = CommonUtil.getCSDate(txtTowerPossession.Text);
        propertyTowerDto.Description = txtTowerDescription.Text;
        propertyTowerDto.UpdateUser = getUserDefinitionDTO().Username;
    }
    
    protected void onSelectPropertyTower(object sender, EventArgs e)
    {
        GroupRadioButton rd = (GroupRadioButton)sender;
        pnlPropertyTowerAdd.Visible = false;
        if (rd.Checked)
        {
            long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnTowerRowIdentifier"))).Attributes["row-identifier"]);
            List<PropertyTowerDTO> towerList = getCurrentProperty().PropertyTowers.ToList<PropertyTowerDTO>();
            towerList.ForEach(c => c.isUISelected = false);
            towerList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
        }
    }
    
    protected void onSelectChargesDetail(object sender, EventArgs e)
    {
        GroupRadioButton rd = (GroupRadioButton)sender;
        pnlChargesDetailAdd.Visible = false;
        if (rd.Checked)
        {
            long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnChargeDetailRowIdentifier"))).Attributes["row-identifier"]);
            List<PropertyChargeDTO> chargesList = getCurrentProperty().PropertyCharges.ToList<PropertyChargeDTO>();
            chargesList.ForEach(c => c.isUISelected = false);
            chargesList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
        }
    }

    protected void onClickAddPropertyTowerBtn(object sender, EventArgs e)
    {
        try
        {
            clearPropertyTowerViewState();
            initPropertyTowerAddUpdateSection(true);
            initPropertyTowerSectionFields(null);
            setDefaultOnAddPropertyTower();
            SetFocus(txtTowerName);
            scrollToFieldHdn.Value = pnlPropertyTowerAdd.ID;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2BzStep1Error);
        }
    }
    protected void onClickModifyPropertyTowerBtn(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyTowerSelected())
            {
                initPropertyTowerAddUpdateSection(false);
                initPropertyTowerSectionFields(getSelectedPropertyTower());
                SetFocus(txtTowerName);
                scrollToFieldHdn.Value = pnlPropertyTowerAdd.ID;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2BzStep1Error);
        }
    }
    protected void deletePropertyTower(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyTowerSelected())
            {
                PropertyDTO propertyDTO = getCurrentProperty();
                PropertyTowerDTO propertyTowerDto = getSelectedPropertyTower();
                propertyDTO.PropertyTowers.Remove(propertyTowerDto);
                pnlPropertyTowerAdd.Visible = false;
                clearPropertyTowerViewState();
                populatePropertyTowerGrid(propertyDTO);
                setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, "Property Tower"), tab2Anchor.ID, tab2BzStep1);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2BzStep1Error);
        }
    }
    protected void addNewPropertyTower(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyTower())
            {
                PropertyDTO propertyDTO = getCurrentProperty();
                PropertyTowerDTO propertyTowerDto = populatePropertyTowerAdd();
                populatePropertyTowerFromUI(propertyTowerDto);
                propertyDTO.PropertyTowers.Add(propertyTowerDto);
                pnlPropertyTowerAdd.Visible = false;
                clearPropertyTowerViewState();
                populatePropertyTowerGrid(propertyDTO);
                selectPropertyTower(propertyTowerDto);
                setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, "Property Tower"), tab2Anchor.ID, tab2BzStep1);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2BzStep1Error);
        }
    }
    protected void updatePropertyTower(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyTower())
            {
                PropertyDTO propertyDTO = getCurrentProperty();
                PropertyTowerDTO propertyTowerDto = getSelectedPropertyTower();
                populatePropertyTowerFromUI(propertyTowerDto);
                pnlPropertyTowerAdd.Visible = false;
                clearPropertyTowerViewState();
                populatePropertyTowerGrid(propertyDTO);
                selectPropertyTower(propertyTowerDto);
                setSuccessMessage(string.Format(Resources.Messages.success_record_updatedtotable, "Property Tower"), tab2Anchor.ID, tab2BzStep1);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2BzStep1Error);
        }
    }
    protected void cancelPropertyTower(object sender, EventArgs e)
    {
        pnlPropertyTowerAdd.Visible = false;
        clearPropertyTowerViewState();
    }
    private bool validatePropertyTower()
    {
        bool isValid = true;
        Page.Validate("tab2BzStep1ErrorGrid1");
        isValid = Page.IsValid;
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    //PropertyTower Table actions - END
    //TaxDetail Table actions - Start
    private void initTaxDetailAddUpdateSection(bool isAdd)
    {
        lbTaxDetailAddUpdateSectionHeader.Text = (isAdd) ? Resources.Labels.label_sectionheader_taxdetail_add : Resources.Labels.label_sectionheader_taxdetail_modify;
        pnlTaxDetailAdd.Visible = true;
        btnTaxDetailAddToGrid.Visible = isAdd;
        btnTaxDetailUpdateToGrid.Visible = !isAdd;
    }
    private void setDefaultOnAddTaxDetail()
    {

    }
    private void initTaxDetailSectionFields(PropertyTaxDetailDTO taxDetailDto)
    {
        if (taxDetailDto != null) drpTaxType.Text = taxDetailDto.TaxType.Id.ToString(); else drpTaxType.ClearSelection();
        if (taxDetailDto != null) txtTaxRate.Text = taxDetailDto.TaxPercentage.ToString(); else txtTaxRate.Text = null;
        if (taxDetailDto != null) txtTaxLimit.Text = taxDetailDto.TaxAmtLimit.ToString(); else txtTaxLimit.Text = null;
        if (taxDetailDto != null) drpTaxIncludeInPymt.Text = taxDetailDto.IncludeInTotalPymt.ToString(); else drpTaxIncludeInPymt.ClearSelection();
    }
    private void clearTaxDetailViewState()
    {
        if (taxDetailGrid.Rows.Count > 0)
        {
            foreach (GridViewRow row in taxDetailGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdTaxDetailSelect");
                if (radioBtn != null) radioBtn.Checked = false;
            }
        }
        PropertyDTO propertyDto = getCurrentProperty();
        if (propertyDto.PropertyTaxDetails != null) propertyDto.PropertyTaxDetails.ToList<PropertyTaxDetailDTO>().ForEach(c => c.isUISelected = false);
    }
    
    private void selectTaxDetail(PropertyTaxDetailDTO taxDetailDto)
    {
        if (taxDetailGrid.Rows.Count > 0)
        {
            taxDetailDto.isUISelected = true;
            foreach (GridViewRow row in taxDetailGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdTaxDetailSelect");
                Button rowIdenBtn = (Button)row.FindControl("btnTaxDetailRowIdentifier");
                radioBtn.Checked = false;
                if (rowIdenBtn != null && taxDetailDto.UiIndex.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                {
                    radioBtn.Checked = true;
                }
            }
        }
    }
    private PropertyTaxDetailDTO getSelectedTaxDetail()
    {
        return getCurrentProperty().PropertyTaxDetails.ToList<PropertyTaxDetailDTO>().Find(c => c.isUISelected);
    }
    
    private bool validateTaxDetailSelected()
    {
        bool isSelected = true;
        PropertyTaxDetailDTO taxDetailDto = getSelectedTaxDetail();
        if (taxDetailDto == null)
        {
            isSelected = false;
            pnlTaxDetailAdd.Visible = false;
            clearTaxDetailViewState();
            setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Tax Detail"), tab2BzStep2Error);
        }
        return isSelected;
    }
    private PropertyTaxDetailDTO populatePropertyTaxDetailAdd()
    {
        PropertyTaxDetailDTO taxDetailDto = new PropertyTaxDetailDTO();
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        taxDetailDto.FirmNumber = userDef.FirmNumber;
        taxDetailDto.InsertUser = userDef.Username;
        return taxDetailDto;
    }
    
    private void populateTaxDetailFromUI(PropertyTaxDetailDTO taxDetailDto)
    {
        taxDetailDto.TaxType = CommonUIConverter.getMasterControlDTO(drpTaxType.Text, drpTaxType.SelectedItem.Text);
        taxDetailDto.TaxPercentage = CommonUtil.getDecimaNotNulllWithoutExt(txtTaxRate.Text);
        taxDetailDto.TaxAmtLimit = CommonUtil.getDecimaNotNulllWithoutExt(txtTaxLimit.Text);
        taxDetailDto.IncludeInTotalPymt = EnumHelper.ToEnum<IncludeInPymtTotal>(drpTaxIncludeInPymt.Text);
        taxDetailDto.UpdateUser = getUserDefinitionDTO().Username;
    }
    
    protected void onSelectTaxDetail(object sender, EventArgs e)
    {
        GroupRadioButton rd = (GroupRadioButton)sender;
        pnlTaxDetailAdd.Visible = false;
        if (rd.Checked)
        {
            long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnTaxDetailRowIdentifier"))).Attributes["row-identifier"]);
            List<PropertyTaxDetailDTO> towerList = getCurrentProperty().PropertyTaxDetails.ToList<PropertyTaxDetailDTO>();
            towerList.ForEach(c => c.isUISelected = false);
            towerList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
        }
    }
    protected void onClickAddTaxDetailBtn(object sender, EventArgs e)
    {
        try
        {
            clearTaxDetailViewState();
            initTaxDetailAddUpdateSection(true);
            initTaxDetailSectionFields(null);
            setDefaultOnAddTaxDetail();
            SetFocus(drpTaxType);
            scrollToFieldHdn.Value = pnlTaxDetailAdd.ID;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2BzStep2Error);
        }
    }
    protected void onClickModifyTaxDetailBtn(object sender, EventArgs e)
    {
        try
        {
            if (validateTaxDetailSelected())
            {
                initTaxDetailAddUpdateSection(false);
                initTaxDetailSectionFields(getSelectedTaxDetail());
                SetFocus(drpTaxType);
                scrollToFieldHdn.Value = pnlTaxDetailAdd.ID;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2BzStep2Error);
        }
    }

    protected void deleteTaxDetail(object sender, EventArgs e)
    {
        try
        {
            if (validateTaxDetailSelected())
            {
                PropertyDTO propertyDTO = getCurrentProperty();
                PropertyTaxDetailDTO taxDetailDto = getSelectedTaxDetail();
                propertyDTO.PropertyTaxDetails.Remove(taxDetailDto);
                pnlTaxDetailAdd.Visible = false;
                clearTaxDetailViewState();
                populateTaxDetailGrid(propertyDTO);
                setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, "Tax Detail"), tab2Anchor.ID, tab2BzStep2);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2BzStep2Error);
        }
    }
    protected void addNewTaxDetail(object sender, EventArgs e)
    {
        try
        {
            if (validateTaxDetail())
            {
                PropertyDTO propertyDTO = getCurrentProperty();
                PropertyTaxDetailDTO taxDetailDto = populatePropertyTaxDetailAdd();
                populateTaxDetailFromUI(taxDetailDto);
                propertyDTO.PropertyTaxDetails.Add(taxDetailDto);
                pnlTaxDetailAdd.Visible = false;
                clearTaxDetailViewState();
                populateTaxDetailGrid(propertyDTO);
                selectTaxDetail(taxDetailDto);
                setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, "Tax Detail"), tab2Anchor.ID, tab2BzStep2);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2BzStep2Error);
        }
    }
    protected void updateTaxDetail(object sender, EventArgs e)
    {
        try
        {
            if (validateTaxDetail())
            {
                PropertyDTO propertyDTO = getCurrentProperty();
                PropertyTaxDetailDTO taxDetailDto = getSelectedTaxDetail();
                populateTaxDetailFromUI(taxDetailDto);
                pnlTaxDetailAdd.Visible = false;
                clearTaxDetailViewState();
                populateTaxDetailGrid(propertyDTO);
                selectTaxDetail(taxDetailDto);
                setSuccessMessage(string.Format(Resources.Messages.success_record_updatedtotable, "Tax Detail"), tab2Anchor.ID, tab2BzStep2);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2BzStep2Error);
        } 
    }
    protected void cancelTaxDetail(object sender, EventArgs e)
    {
        pnlTaxDetailAdd.Visible = false;
        clearTaxDetailViewState();
    }
    
    private bool validateTaxDetail()
    {
        bool isValid = true;
        Page.Validate("tab2BzStep2ErrorGrid2");
        isValid = Page.IsValid;
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    //TaxDetail Table actions - END
    //Charges Table actions - Start
    private void initChargeDetailSectionFields(PropertyChargeDTO chargeDetailDto)
    {
        if (chargeDetailDto != null) drpPropertyChargesType.Text = chargeDetailDto.ChargeType.Id.ToString(); else drpPropertyChargesType.ClearSelection();
        if (chargeDetailDto != null) txtChargesValue.Text = chargeDetailDto.ChargeValue.ToString(); else txtChargesValue.Text = null;
    }
    private void initChargesAddUpdateSection(bool isAdd)
    {
        //lbChargesAddUpdateSectionHeader.Text = (isAdd) ? Resources.Labels.label_sectionheader_chargedetail_add : Resources.Labels.label_sectionheader_chargesdetail_modify;
        pnlChargesDetailAdd.Visible = true;
        btnChargeDetailAddToGrid.Visible = isAdd;
        btnChargeDetailUpdateToGrid.Visible = !isAdd;
    }
    private void populateChargesDetailFromUI(PropertyChargeDTO chargeDetailDto)
    {
        chargeDetailDto.ChargeType = CommonUIConverter.getMasterControlDTO(drpPropertyChargesType.Text, drpPropertyChargesType.SelectedItem.Text);
        chargeDetailDto.ChargeValue = CommonUtil.getDecimaNotNulllWithoutExt(txtChargesValue.Text);
        chargeDetailDto.UpdateUser = getUserDefinitionDTO().Username;
    }
    private PropertyChargeDTO getSelectedChargesDetail()
    {
        return getCurrentProperty().PropertyCharges.ToList<PropertyChargeDTO>().Find(c => c.isUISelected);
    }
    private PropertyChargeDTO populatePropertyChargesDetailAdd()
    {
        PropertyChargeDTO chargeDetailDto = new PropertyChargeDTO();
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        chargeDetailDto.FirmNumber = userDef.FirmNumber;
        chargeDetailDto.InsertUser = userDef.Username;
        return chargeDetailDto;
    }
    private void clearChargesDetailViewState()
    {
        if (PropertyChargesGrid.Rows.Count > 0)
        {
            foreach (GridViewRow row in PropertyChargesGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdChargesDetailSelect");
                if (radioBtn != null) radioBtn.Checked = false;
            }
        }
        PropertyDTO propertyDto = getCurrentProperty();
        if (propertyDto.PropertyCharges != null) propertyDto.PropertyCharges.ToList<PropertyChargeDTO>().ForEach(c => c.isUISelected = false);
    }
    private void selectChargesDetail(PropertyChargeDTO chargeDetailDto)
    {
        if (PropertyChargesGrid.Rows.Count > 0)
        {
            chargeDetailDto.isUISelected = true;
            foreach (GridViewRow row in PropertyChargesGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdChargesDetailSelect");
                Button rowIdenBtn = (Button)row.FindControl("btnChargeDetailRowIdentifier");
                radioBtn.Checked = false;
                if (rowIdenBtn != null && chargeDetailDto.UiIndex.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                {
                    radioBtn.Checked = true;
                }
            }
        }
    }
    public void onClickAddChargesDetailBtn(object sender, EventArgs e)
    {
        try
        {
            clearChargesDetailViewState();
            initChargesAddUpdateSection(true);
            initChargeDetailSectionFields(null);
            setDefaultOnAddTaxDetail();
            SetFocus(drpPropertyChargesType);
            scrollToFieldHdn.Value = pnlChargesDetailAdd.ID;
            
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2BzStep2Error);
        }
    }

    public void onClickModifyChargesDetailBtn(object sender, EventArgs e)
    {
        try
        {
            if (validateChargeDetailSelected())
            {
                initChargesAddUpdateSection(false);
                initChargeDetailSectionFields(getSelectedChargesDetail());
                SetFocus(drpPropertyChargesType);
                scrollToFieldHdn.Value = pnlChargesDetailAdd.ID;

            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2BzStep2Error);
        }
    }
    protected void addNewChargeDetail(object sender, EventArgs e)
    {
        try
        {
            if (validateChargesDetail())
            {
                PropertyDTO propertyDTO = getCurrentProperty();
                PropertyChargeDTO chargeDetailDto = populatePropertyChargesDetailAdd();
                populateChargesDetailFromUI(chargeDetailDto);
                propertyDTO.PropertyCharges.Add(chargeDetailDto);
                pnlChargesDetailAdd.Visible = false;

                populateChargesDetailGrid(propertyDTO);
                selectChargesDetail(chargeDetailDto);
                setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, "Charges Detail"), tab2Anchor.ID, tab2BzStep2);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2BzStep2Error);
        }
    }
    protected void updateChargeDetail(object sender, EventArgs e)
    {
        try
        {
            if (validateChargesDetail())
            {
                PropertyDTO propertyDTO = getCurrentProperty();
                PropertyChargeDTO chargeDetailDto = getSelectedChargesDetail();
                populateChargesDetailFromUI(chargeDetailDto);
                pnlChargesDetailAdd.Visible = false;
                clearChargesDetailViewState();
                populateChargesDetailGrid(propertyDTO);
                selectChargesDetail(chargeDetailDto);
                setSuccessMessage(string.Format(Resources.Messages.success_record_updatedtotable, "Charges Detail"), tab2Anchor.ID, tab2BzStep2);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2BzStep2Error);
        }
    }
    protected void cancelChargeDetail(object sender, EventArgs e)
    {
        pnlChargesDetailAdd.Visible = false;
        clearChargesDetailViewState();
    }
    
    protected void deleteChargesDetail(object sender, EventArgs e)
    {
        try
        {
            if (validateChargeDetailSelected())
            {
                PropertyDTO propertyDTO = getCurrentProperty();
                PropertyChargeDTO chargesDetailDto = getSelectedChargesDetail();
                propertyDTO.PropertyCharges.Remove(chargesDetailDto);
                pnlChargesDetailAdd.Visible = false;
                clearChargesDetailViewState();
                populateChargesDetailGrid(propertyDTO);
                setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, "Charges Detail"), tab2Anchor.ID, tab2BzStep2);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2BzStep2Error);
        }
    }
    private bool validateChargesDetail()
    {
        bool isValid = true;
        Page.Validate("tab2BzStep2ErrorGrid2");
        isValid = Page.IsValid;
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    private bool validateChargeDetailSelected()
    {
        bool isSelected = true;
        PropertyChargeDTO chargeDetailDto = getSelectedChargesDetail();
        if (chargeDetailDto == null)
        {
            isSelected = false;
            pnlChargesDetailAdd.Visible = false;
            clearChargesDetailViewState();
            setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Charge Detail"), tab2BzStep2Error);
        }
        return isSelected;
    }
    //Charges Table actions - Start
}
