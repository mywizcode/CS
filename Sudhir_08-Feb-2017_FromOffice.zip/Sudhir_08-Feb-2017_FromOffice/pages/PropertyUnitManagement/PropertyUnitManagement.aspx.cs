﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft.Logic.BO;
using NHibernate;
using Vladsm.Web.UI.WebControls;

namespace ConstroSoft.pages.PropertyUnitManagement
{
    public partial class PropertyUnitManagement : System.Web.UI.Page
    {
        private static readonly log4net.ILog log =
              log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string tab1ValidationGrp = "tab1Error";
        string tab2ValidationGrp = "tab2Error";
        string VS_PROPERTYUNIT_LIST = "PROPERTYUNIT_LIST";
        string VS_SELECTED_PROPERTYUNIT = "SELECTED_PROPERTYUNIT";
        DropdownBO drpBO = new DropdownBO();
        PropertyUnitManagementBO propertyUnitManagementBO = new PropertyUnitManagementBO();
        MasterDataBO masterDataBO = new MasterDataBO();
        public enum PrUnitPageMode { ADD, MODIFY, VIEW, NONE }
        protected void Page_Load(object sender, EventArgs e)
        {
            clearMessages();
            if (!IsPostBack)
            {
                if (Session[Constants.Session.USERNAME] != null)
                {
                    resetTabInfo(PrUnitPageMode.NONE);
                    initDropdowns();

                    Page.MaintainScrollPositionOnPostBack = false;
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
        }
        private void initDropdowns()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            drpBO.drpDataBase(drpSearchProperty, DrpDataType.PROPERTY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpSearchTower, DrpDataType.PROPERTY_TOWER, drpSearchProperty.Text, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpUnitType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpDirection, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_DIRECTION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpfacing, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_FACING, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpEnum<PRUnitStatus>(drpStatus, Constants.SELECT_ITEM);
            drpBO.drpEnum<PropertyUnitSearchBy>(drpSearchBy, null);
        }
        /**
         * This method is called just before the page is rendered. So any change in state of the element is applied.
         **/
        protected void Page_PreRender(object sender, EventArgs e)
        {
            if (Session[Constants.Session.USERNAME] != null)
            {
                applyEntitlement();
                preRenderInitFormElements();
                initBootstrapComponantsFromServer();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        private bool isViewOnlyUser()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            bool isViewOnlyUser = !CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.FIRM_MEMBER_ADD_UPDATE);
            return isViewOnlyUser;
        }
        private void applyEntitlement()
        {
            if (isViewOnlyUser())
            {
                btnAddPropertyUnit.Visible = false;
                btnModifyPropertyUnit.Visible = false;
                btnDeletePropertyUnit.Visible = false;
            }
        }
        private void preRenderInitFormElements()
        {
            PropertyUnitDTO selectedPropertyUnit = getCurrentPropertyUnit();
            jumpToPropertyUnitHdnId.Value = null;
        }
        public void setErrorMessage(string message, string group)
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }

        public void setSuccessMessage(string msg, string tabId)
        {
            activeTabHdn.Value = tabId;
            if (tabId.Equals(tab1Anchor.ID))
            {
                lbTab1Success.Text = msg;
                tab1SuccessPanel.Visible = true;
            }
            else if (tabId.Equals(tab2Anchor.ID))
            {
                lbTab2Success.Text = msg;
                tab2SuccessPanel.Visible = true;
            }
        }
        public void initBootstrapComponantsFromServer()
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
        }
        private void clearMessages()
        {
            tab1SuccessPanel.Visible = false;
            lbTab1Success.Text = "";
            tab2SuccessPanel.Visible = false;
            lbTab2Success.Text = "";
        }
        private UserDefinitionDTO getUserDefinitionDTO()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }

        private void resetTabInfo(PrUnitPageMode pageMode)
        {
            tab2Anchor.Visible = true;
            activeTabHdn.Value = tab2Anchor.ID;
            pageModeHdn.Value = pageMode.ToString();
            initFormFields();

            if (PrUnitPageMode.ADD == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.empm_sm_manage_propertyUnit_tab2_add_name;
                initFormFields();
            }
            else if (PrUnitPageMode.MODIFY == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.empm_sm_manage_propertyUnit_tab2_update_name;
                initFormFields();
            }
            else if (PrUnitPageMode.VIEW == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.empm_sm_manage_propertyUnit_tab2_view_name;
                initFormFields();
            }
            else
            {
                activeTabHdn.Value = tab1Anchor.ID;
                tab2Anchor.Visible = false;
                ViewState[VS_SELECTED_PROPERTYUNIT] = null;
            }
        }
        private void initFormFields()
        {
            bool isReadOnly = (PrUnitPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            bool visible = !(PrUnitPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            //Buttons
            btnAddSubmit.Visible = visible;
            addUnitTypeBtn.Visible = visible;
            addDirectionBtn.Visible = visible;
            addFacingBtn.Visible = visible;

            bool isAdd = (PrUnitPageMode.ADD.ToString().Equals(pageModeHdn.Value));
            txtWing.ReadOnly = !isAdd;
            txtFloorNo.ReadOnly = !isAdd;
            txtunitNo.ReadOnly = !isAdd;
        }
        private List<PropertyUnitDTO> getPropertyUnitList()
        {
            return (List<PropertyUnitDTO>)ViewState[VS_PROPERTYUNIT_LIST];
        }
        private PropertyUnitDTO getCurrentPropertyUnit()
        {
            return (PropertyUnitDTO)ViewState[VS_SELECTED_PROPERTYUNIT];
        }
        private void setSelectedPropertyUnit(long selectedId)
        {
            List<PropertyUnitDTO> propertyUnitList = getPropertyUnitList();
            if (propertyUnitList != null && propertyUnitList.Count != 0)
            {
                propertyUnitList.ForEach(c => c.isUISelected = false);
                if (selectedId > 0) propertyUnitList.Find(c => c.Id == selectedId).isUISelected = true;
            }
        }
        private void selectPropertyUnitGridRdBtn(long uiIndex)
        {
            if (proprtyunitGrid.Rows.Count > 0)
            {
                setSelectedPropertyUnit(0);
                foreach (GridViewRow row in proprtyunitGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdPropertyUnitSelect");
                    radioBtn.Checked = false;
                    if (uiIndex > 0)
                    {
                        Button rowIdenBtn = (Button)row.FindControl("btnPropUnitRowIdentifier");
                        if (rowIdenBtn != null && uiIndex.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                        {
                            radioBtn.Checked = true;
                            setSelectedPropertyUnit(uiIndex);
                        }
                    }
                }
            }
        }
        private void assignUiIndexToPropertyUnit(List<PropertyUnitDTO> prUnitDtos)
        {
            if (prUnitDtos != null && prUnitDtos.Count > 0)
            {
                prUnitDtos.ForEach(c => c.isUISelected = false);
                long uiIndex = 1;
                foreach (PropertyUnitDTO prUnitDto in prUnitDtos)
                {
                    prUnitDto.UiIndex = uiIndex++;
                    prUnitDto.RowInfo = CommonUIConverter.getGridViewRowInfo(prUnitDto);
                }
            }
        }
        private void loadSearchGridAndReSelect(long Id)
        {
            try
            {
                PropertyUnitSearchBy searchBy = EnumHelper.ToEnum<PropertyUnitSearchBy>(drpSearchBy.Text);
                object searchByValue = null;
                if (!string.IsNullOrWhiteSpace(drpSearchByValue.Text))
                {
                    if (PropertyUnitSearchBy.STATUS == searchBy) searchByValue = EnumHelper.ToEnum<PRUnitStatus>(drpSearchByValue.Text);
                    else searchByValue = drpSearchByValue.Text;
                }
                IList<PropertyUnitDTO> results = propertyUnitManagementBO.fetchPropertyUnitGridData(getUserDefinitionDTO().FirmNumber, 
                        searchBy, searchByValue, long.Parse(drpSearchTower.Text));
                ViewState[VS_PROPERTYUNIT_LIST] = results;
                proprtyunitGrid.DataSource = results;
                proprtyunitGrid.DataBind();
                if (Id > 0)
                {
                    selectPropertyUnitGridRdBtn(Id);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void fetchSelectedPropertyUnitList()
        {
            try
            {
                PropertyUnitDTO propertyUnitDto = null;
                if (PrUnitPageMode.ADD.ToString().Equals(pageModeHdn.Value))
                {
                    propertyUnitDto = populatePropertyUnitDTOAdd();
                    selectPropertyUnitGridRdBtn(0);
                }
                else if (PrUnitPageMode.MODIFY.ToString().Equals(pageModeHdn.Value) || PrUnitPageMode.VIEW.ToString().Equals(pageModeHdn.Value))
                {
                    long Id = getPropertyUnitList().Find(c => c.isUISelected).Id;
                    propertyUnitDto = propertyUnitManagementBO.fetchPropertyUnitDetails(Id);
                }
                ViewState[VS_SELECTED_PROPERTYUNIT] = propertyUnitDto;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void doViewModifyAction(PrUnitPageMode pageMode)
        {
            resetTabInfo(pageMode);
            fetchSelectedPropertyUnitList();
            PropertyUnitDTO prUnitDto = getCurrentPropertyUnit();
            populateUIFieldsFromDTO(prUnitDto);
        }
        protected void onSearchByProperty(object sender, EventArgs e)
        {
            try
            {
                resetTabInfo(PrUnitPageMode.NONE);
                pnlUnitGrid.Visible = false;
                if (!string.IsNullOrWhiteSpace(drpSearchProperty.Text))
                {
                    UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                    drpBO.drpDataBase(drpSearchTower, DrpDataType.PROPERTY_TOWER, drpSearchProperty.Text, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    if (drpSearchTower.Items.Count == 2)
                    {
                        drpSearchTower.Items[1].Selected = true;
                        loadSearchGridAndReSelect(0);
                    }
                    pnlUnitGrid.Visible = true;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }

        }

        protected void onSearchByTower(object sender, EventArgs e)
        {
            try
            {
                pnlUnitGrid.Visible = false;
                if (!string.IsNullOrWhiteSpace(drpSearchTower.Text))
                {
                    pnlUnitGrid.Visible = true;
                    loadSearchGridAndReSelect(0);
                }
                else resetTabInfo(PrUnitPageMode.NONE);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onSearchBy(object sender, EventArgs e)
        {
            try
            {
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                PropertyUnitSearchBy searchBy = EnumHelper.ToEnum<PropertyUnitSearchBy>(drpSearchBy.Text);
                drpSearchByValue.Visible = true;
                lbSearchByValue.Visible = true;
                lbSearchByValue.Text = EnumHelper.GetEnumDescription<PropertyUnitSearchBy>(searchBy.ToString());
                if (PropertyUnitSearchBy.UNIT_NO == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.PR_UNIT_SEARCH_BY_UNITNO, drpSearchTower.Text, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (PropertyUnitSearchBy.UNIT_TYPE == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (PropertyUnitSearchBy.FLOOR_NO == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.PR_UNIT_SEARCH_BY_FLOORNO, drpSearchTower.Text, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (PropertyUnitSearchBy.STATUS == searchBy)
                {
                    drpBO.drpEnum<PRUnitStatus>(drpSearchByValue, Constants.SELECT_ITEM);
                }
                else if (PropertyUnitSearchBy.WING == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.PR_UNIT_SEARCH_BY_WING, drpSearchTower.Text, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }

                else
                {
                    drpSearchByValue.ClearSelection();
                    drpSearchByValue.Visible = false;
                    lbSearchByValue.Visible = false;
                }
                loadSearchGridAndReSelect(0);
                resetTabInfo(PrUnitPageMode.NONE);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onSearchByValue(object sender, EventArgs e)
        {
            loadSearchGridAndReSelect(0);
            resetTabInfo(PrUnitPageMode.NONE);
        }
        protected void selectPropertyUnit(object sender, EventArgs e)
        {
            try
            {
                GroupRadioButton rd = (GroupRadioButton)sender;
                resetTabInfo(PrUnitPageMode.NONE);
                if (rd.Checked)
                {
                    string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnPropUnitRowIdentifier"))).Attributes["row-identifier"];
                    setSelectedPropertyUnit(long.Parse(strId));
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        /*
         * This method is called on click of ADD button in datatable top bar.
         */
        protected void onClickAddPropertyUnitBtn(object sender, EventArgs e)
        {
            try
            {
                resetTabInfo(PrUnitPageMode.ADD);
                fetchSelectedPropertyUnitList();
                populateUIFieldsFromDTO(null);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickViewPropertyUnitBtn(object sender, EventArgs e)
        {
            try
            {
                if (validatePrUnitSelected())
                {
                    doViewModifyAction(PrUnitPageMode.VIEW);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickModifyPropertyUnitBtn(object sender, EventArgs e)
        {
            try
            {
                if (validatePrUnitSelected() && validatePrUnitModify())
                {
                    doViewModifyAction(PrUnitPageMode.MODIFY);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void deletePropertyUnit(object sender, EventArgs e)
        {
            try
            {
                if (validatePrUnitSelected() && validatePrUnitDelete())
                {
                    long Id = getPropertyUnitList().Find(c => c.isUISelected).Id;
                    BusinessOutputTO outputTO = propertyUnitManagementBO.deletePropertyUnitDetails(Id);
                    if (outputTO.status == BusinessOutputTO.Status.SUCCESS)
                    {
                        loadSearchGridAndReSelect(0);
                        resetTabInfo(PrUnitPageMode.NONE);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_delete, "Property Unit"), tab1Anchor.ID);
                    }
                    else
                    {
                        propertyUnitManagementBO.updateUnitAsDeleted(Id);
                        resetTabInfo(PrUnitPageMode.NONE);
                        loadSearchGridAndReSelect(Id);
                        setSuccessMessage(Resources.Messages.success_prunit_delete_update, tab1Anchor.ID);
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void addOrModifyPropertyUnit(object sender, EventArgs e)
        {
            try
            {
                if (validateUnitAddOrModify())
                {
                    PropertyUnitDTO propertyUnitDTO = getCurrentPropertyUnit();
                    long Id = propertyUnitDTO.Id;
                    populatePropertyUnitDTOFromUI(propertyUnitDTO);
                    if (PrUnitPageMode.ADD.ToString().Equals(pageModeHdn.Value))
                    {
                        Id = propertyUnitManagementBO.savePropertyUnitDetails(propertyUnitDTO);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_add, "Property Unit"), tab2Anchor.ID);
                    }
                    else if (PrUnitPageMode.MODIFY.ToString().Equals(pageModeHdn.Value))
                    {
                        propertyUnitManagementBO.updatePropertyUnitDetails(propertyUnitDTO);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_update, "Property Unit"), tab2Anchor.ID);
                    }
                    loadSearchGridAndReSelect(Id);
                    doViewModifyAction(PrUnitPageMode.VIEW);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        private bool validatePrUnitSelected()
        {
            bool isSelected = true;
            List<PropertyUnitDTO> propertyUnitList = getPropertyUnitList();
            if (propertyUnitList != null)
            {
                isSelected = propertyUnitList.Any(c => c.isUISelected);
                if (!isSelected)
                {
                    resetTabInfo(PrUnitPageMode.NONE);
                    setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Property Unit"), tab1ValidationGrp);
                }
            }
            return isSelected;
        }
        private bool validatePrUnitModify()
        {
            bool isValid = true;
            PropertyUnitDTO propertyUnitDto = getPropertyUnitList().Find(x => x.isUISelected);
            if (propertyUnitDto.Status == PRUnitStatus.Deleted)
            {
                isValid = false;
                resetTabInfo(PrUnitPageMode.NONE);
                setErrorMessage("Selected Property Unit is deleted, cannot be modified.", tab1ValidationGrp);
            }
            else if (propertyUnitDto.Status == PRUnitStatus.Sold)
            {
                isValid = false;
                resetTabInfo(PrUnitPageMode.NONE);
                setErrorMessage("Selected Property Unit is Sold, cannot be modified.", tab1ValidationGrp);
            }
            return isValid;
        }
        private bool validatePrUnitDelete()
        {
            bool isValid = true;
            PropertyUnitDTO propertyUnitDTO = getPropertyUnitList().Find(x => x.isUISelected);
            if (propertyUnitDTO.Status != PRUnitStatus.Available)
            {
                isValid = false;
                setErrorMessage("Only Available property units can be deleted.", tab1ValidationGrp);
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        private bool validateUnitAddOrModify()
        {
            bool isValid = true;
            Page.Validate("tab2Error");
            isValid = Page.IsValid;
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            if (isValid) isValid = validateUnitAddOrModifyOther();
            return isValid;
        }
        private bool validateUnitAddOrModifyOther()
        {
            bool isValid = true;
            PRUnitStatus status = EnumHelper.ToEnum<PRUnitStatus>(drpStatus.Text);
            if (!(PRUnitStatus.Available == status || PRUnitStatus.Reserved == status))
            {
                isValid = false;
                setErrorMessage("Please select Status as 'Available' or 'Reserved'.", tab2ValidationGrp);
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            if (PRUnitStatus.Reserved == status && string.IsNullOrWhiteSpace(txtReserveComments.Text))
            {
                isValid = false;
                setErrorMessage("Please enter Reserve Comments.", tab2ValidationGrp);
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            if (PrUnitPageMode.ADD.ToString().Equals(pageModeHdn.Value))
            {
                if(propertyUnitManagementBO.validateUnitExist(getUserDefinitionDTO().FirmNumber, long.Parse(drpSearchTower.Text), txtWing.Text,
                    txtFloorNo.Text, txtunitNo.Text)) {
                        setErrorMessage("Property Unit already exist.", tab2ValidationGrp);
                        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
                        isValid = false;
                }
            }
            return isValid;
        }
        protected void cancelPropertyUnit(object sender, EventArgs e)
        {
            PropertyUnitDTO firmMemberDto = getCurrentPropertyUnit();
            resetTabInfo(PrUnitPageMode.NONE);
            loadSearchGridAndReSelect(firmMemberDto.Id);
        }

        private PropertyUnitDTO populatePropertyUnitDTOAdd()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            PropertyUnitDTO propertyUnitDto = new PropertyUnitDTO();
            propertyUnitDto.PropertyTower = new PropertyTowerDTO();
            propertyUnitDto.PropertyTower.Id = long.Parse(drpSearchTower.Text);
            propertyUnitDto.FirmNumber = userDefDto.FirmNumber;
            propertyUnitDto.InsertUser = userDefDto.Username;
            return propertyUnitDto;
        }
        private void populatePropertyUnitDTOFromUI(PropertyUnitDTO propertyUnitDTO)
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            if (propertyUnitDTO.Status == PRUnitStatus.Available)
            {
                propertyUnitDTO.Wing = txtWing.Text;
                propertyUnitDTO.FloorNo = txtFloorNo.Text;
                propertyUnitDTO.UnitNo = txtunitNo.Text;
            }
            propertyUnitDTO.UnitType = CommonUIConverter.getMasterControlDTO(drpUnitType.Text, null);
            propertyUnitDTO.BuildupArea = CommonUtil.getDecimalWithoutExt(txtBuiltupArea.Text);
            propertyUnitDTO.CarpetArea = CommonUtil.getDecimalWithoutExt(txtCarpetArea.Text);
            propertyUnitDTO.BalconyArea = CommonUtil.getDecimalWithoutExt(txtBalconyArea.Text);
            propertyUnitDTO.Facing = CommonUIConverter.getMasterControlDTO(drpfacing.Text, null);
            propertyUnitDTO.Status = EnumHelper.ToEnum<PRUnitStatus>(drpStatus.Text);
            propertyUnitDTO.Direction = CommonUIConverter.getMasterControlDTO(drpDirection.Text, null);
            propertyUnitDTO.ReserveComments = (propertyUnitDTO.Status == PRUnitStatus.Reserved) ? txtReserveComments.Text : "";
            propertyUnitDTO.NoOfBalcony = Convert.ToInt32(txtNoOfBalcony.Text);
            propertyUnitDTO.FirmNumber = userDefDto.FirmNumber;
            propertyUnitDTO.Version = userDefDto.Version;
            propertyUnitDTO.UpdateUser = userDefDto.Username;
        }
        private void populateUIFieldsFromDTO(PropertyUnitDTO propertyUnitDto)
        {

            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            txtProperty.Text = drpSearchProperty.SelectedItem.Text;
            txtTower.Text = drpSearchTower.SelectedItem.Text;
            if (propertyUnitDto != null) drpUnitType.Text = propertyUnitDto.UnitType.Id.ToString(); else drpUnitType.Text = null;
            if (propertyUnitDto != null) txtWing.Text = propertyUnitDto.Wing; else txtWing.Text = null;
            if (propertyUnitDto != null) txtReserveComments.Text = propertyUnitDto.ReserveComments; else txtReserveComments.Text = null;
            if (propertyUnitDto != null) txtNoOfBalcony.Text = Convert.ToDecimal(propertyUnitDto.NoOfBalcony).ToString(); else txtNoOfBalcony.Text = null;
            if (propertyUnitDto != null) txtFloorNo.Text = Convert.ToDecimal(propertyUnitDto.FloorNo).ToString(); else txtFloorNo.Text = null;
            if (propertyUnitDto != null && propertyUnitDto.UnitNo != null) txtunitNo.Text = propertyUnitDto.UnitNo; else txtunitNo.Text = null;
            if (propertyUnitDto != null && propertyUnitDto.BuildupArea != null) txtBuiltupArea.Text = propertyUnitDto.BuildupArea.ToString(); else txtBuiltupArea.Text = null;
            if (propertyUnitDto != null && propertyUnitDto.CarpetArea != null) txtCarpetArea.Text = propertyUnitDto.CarpetArea.ToString(); else txtCarpetArea.Text = null;
            if (propertyUnitDto != null && propertyUnitDto.BalconyArea != null) txtBalconyArea.Text = propertyUnitDto.BalconyArea.ToString(); else txtBalconyArea.Text = null;
            if (propertyUnitDto != null && propertyUnitDto.Facing != null) drpfacing.Text = propertyUnitDto.Facing.Id.ToString(); else drpfacing.Text = null;
            if (propertyUnitDto != null) drpStatus.Text = propertyUnitDto.Status.ToString(); else drpStatus.Text = PRUnitStatus.Available.ToString();
            if (propertyUnitDto != null && propertyUnitDto.Direction != null) drpDirection.Text = propertyUnitDto.Direction.Id.ToString(); else drpDirection.ClearSelection();

        }
        //Modal save logic
        protected void saveModalData(object sender, EventArgs e)
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (modalHdnType.Value == "UNIT_TYPE")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_UNIT_TYPE, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Unit_Type");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpUnitType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            else if (modalHdnType.Value == "DIRECTION")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_UNIT_DIRECTION, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "DIRECTION");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpDirection, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_DIRECTION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            else if (modalHdnType.Value == "FACING")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_UNIT_FACING, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "FACING");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpfacing, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_FACING, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                modalErrorMsg.Value = errorMsg;
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "setModalErrorMsg", "setModalErrorMsg()", true);
            }
            else
            {
                //Reset the modal fields
                modalInput1.Text = "";
                modalInput2.Text = "";
                modalHdnType.Value = "";
                modalActionHdn.Value = "";
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "closeDialogClient", "closeDialogClient()", true);
            }
        }

        private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
        {
            string errorMsg = "";
            if (string.IsNullOrWhiteSpace(masterDataDto.Name))
            {
                errorMsg = Resources.Messages.validation_designationname_required;
            }
            else if (masterDataBO.isAlreadyExist(masterDataDto))
            {
                errorMsg = string.Format(Resources.Messages.validation_same_name_exist, type);
            }
            return errorMsg;
        }


        private string validateUnitNoInput(PropertyUnitDTO propertyunitDto)
        {
            string errorMsg = "";
            if (string.IsNullOrWhiteSpace(propertyunitDto.UnitNo))
            {
                errorMsg = Resources.Messages.validation_unitno_required;
            }
            else if (propertyUnitManagementBO.isAlreadyExist(propertyunitDto))
            {
                errorMsg = string.Format(Resources.Messages.validation_same_name_exist, propertyunitDto.UnitNo);
            }
            return errorMsg;
        }
    }
}