﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Vladsm.Web.UI.WebControls;

namespace ConstroSoft.pages.EnquiryManagement
{
    public partial class EnquiryManagement : System.Web.UI.Page
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string tab1ValidationGrp = "tab1Error";
        string tab2ValidationGrp = "tab2Error";
        string VS_ENQUIRY_LIST = "ENQUIRY_LIST";
        string VS_SELECTED_ENQUIRY = "SELECTED_ENQUIRY";
        DropdownBO drpBO = new DropdownBO();
        EnquiryBO enquiryBO = new EnquiryBO();
        MasterDataBO masterDataBO = new MasterDataBO();
        EmployeeBO firmMemberBO = new EmployeeBO();
        protected void Page_Load(object sender, EventArgs e)
        {
            clearMessages();
            if (!IsPostBack)
            {
                if (Session[Constants.Session.USERNAME] != null)
                {
                    resetTabInfo(PageMode.NONE);
                    initDropdowns();
                    loadSearchGridAndReSelect(0);
                    Page.MaintainScrollPositionOnPostBack = false;
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
        }
        private void initDropdowns()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            drpBO.drpDataBase(drpSalutation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.SALUTATION, null, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpPropertyType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpPropertyLocation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_LOCATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpPropertyUnitType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpEnquirySource, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ENQUIRY_SOURCE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpOccupation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.OCCUPATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpEnum<EnquirySearchBy>(drpSearchBy, null);
            drpBO.drpEnum<Gender>(drpGender, Constants.SELECT_ITEM);
            drpBO.drpEnum<MaritalStatus>(drpMaritalStatus, Constants.SELECT_ITEM);
            drpBO.drpEnum<EnquiryStatus>(drpStatus, Constants.SELECT_ITEM);
            drpBO.drpDataBase(drpProperty, DrpDataType.PROPERTY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpFirmMember, DrpDataType.EMPLOYEE_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpAddressCountry, DrpDataType.COUNTRY, null, null, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpAddressState, DrpDataType.STATE, Constants.DEFAULT_COUNTRY, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            initCityDrp(drpAddressCity, Constants.DEFAULT_STATE);
            drpBO.drpDataBase(drpAddressType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ADDRESS_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpEnum<PreferredAddress>(drpPreferredAddress, null);
        }
        /**
         * This method is called just before the page is rendered. So any change in state of the element is applied.
         **/
        protected void Page_PreRender(object sender, EventArgs e)
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        private bool isViewOnlyUser()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            bool isViewOnlyUser = !CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.FIRM_ACCOUNT_ADD_UPDATE);
            return isViewOnlyUser;
        }
        private void applyEntitlement()
        {
            if (isViewOnlyUser())
            {
                btnAddEnquiry.Visible = false;
                btnModifyEnquiry.Visible = false;
                btnDeleteEnquiry.Visible = false;
            }
        }
        private void preRenderInitFormElements()
        {
            EnquiryDetailDTO selectedEnquiry = getCurrentEnquiry();
            jumpToEnquiryHdnId.Value = null;
            jumpToAddressHdnId.Value = null;
            if (selectedEnquiry != null)
            {
                jumpToEnquiryHdnId.Value = selectedEnquiry.Id.ToString();
                List<AddressDTO> addressList = selectedEnquiry.ContactInfo.Addresses.ToList<AddressDTO>();
                if (addressList != null && addressList.Count > 0)
                {
                    AddressDTO selectedAddress = addressList.Find(a => a.isUISelected);
                    if (selectedAddress != null) jumpToAddressHdnId.Value = selectedAddress.UiIndex.ToString();
                }
            }
        }
        public void setErrorMessage(string message, string group)
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            this.Page.Validators.Add(val);
        }

        public void setSuccessMessage(string msg, string tabId)
        {
            activeTabHdn.Value = tabId;
            if (tabId.Equals(tab1Anchor.ID))
            {
                lbTab1Success.Text = msg;
                tab1SuccessPanel.Visible = true;
            }
            else if (tabId.Equals(tab2Anchor.ID))
            {
                lbTab2Success.Text = msg;
                tab2SuccessPanel.Visible = true;
            }
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        public void initBootstrapComponantsFromServer()
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
        }
        private void clearMessages()
        {
            tab1SuccessPanel.Visible = false;
            lbTab1Success.Text = "";
            tab2SuccessPanel.Visible = false;
            lbTab2Success.Text = "";
        }
        private UserDefinitionDTO getUserDefinitionDTO()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }

        private void resetTabInfo(PageMode pageMode)
        {
            tab2Anchor.Visible = true;
            activeTabHdn.Value = tab2Anchor.ID;
            pageModeHdn.Value = pageMode.ToString();
            initFormFields();
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            pnlAddressAdd.Visible = false;
            if (PageMode.ADD == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.enqm_sm_manage_enq_tab2_add_name;
                initFormFields();
            }
            else if (PageMode.MODIFY == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.enqm_sm_manage_enq_tab2_update_name;
                initFormFields();
            }
            else if (PageMode.VIEW == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.enqm_sm_manage_enq_tab2_view_name;
                initFormFields();
            }
            else
            {
                activeTabHdn.Value = tab1Anchor.ID;
                tab2Anchor.Visible = false;
                ViewState[VS_SELECTED_ENQUIRY] = null;
            }
        }
        private void initFormFields()
        {
            bool isReadOnly = (PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            bool visible = !(PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            //Buttons
            btnAddSubmit.Visible = visible;
            addPropertyTypeBtn.Visible = visible;
            lnlPropertyUnitType.Visible = visible;
            addPropertyLocationBtn.Visible = visible;
            addPropertyLocationBtn.Visible = visible;
            addOccupationBtn.Visible = visible;
            addEnquirySource.Visible = visible;
            btnAddAddress.Visible = visible;
            btnModifyAddress.Visible = visible;
            btnDeleteAddress.Visible = visible;
            addressGrid.Columns[0].Visible = visible;
        }
        private EnquiryDetailDTO getCurrentEnquiry()
        {
            return (EnquiryDetailDTO)ViewState[VS_SELECTED_ENQUIRY];
        }
        private void setSelectedEnquiry(long selectedId)
        {
            List<EnquiryDetailDTO> enquiryList = (List<EnquiryDetailDTO>)ViewState[VS_ENQUIRY_LIST];
            if (enquiryList != null)
            {
                enquiryList.ForEach(c => c.isUISelected = false);
                enquiryList.Find(c => c.Id == selectedId).isUISelected = true;
            }
        }
        private bool validateEnquirySelected()
        {
            bool isSelected = true;
            List<EnquiryDetailDTO> enquiryList = (List<EnquiryDetailDTO>)ViewState[VS_ENQUIRY_LIST];
            if (enquiryList != null)
            {
                isSelected = enquiryList.Any(c => c.isUISelected);
                if (!isSelected)
                {
                    resetTabInfo(PageMode.NONE);
                    setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Enquiry"), tab1ValidationGrp);
                }
            }
            return isSelected;
        }
        private void selectEnquiryGridRdBtn(long Id)
        {
            if (enquiryGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in enquiryGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdEnquirySelect");
                    Button rowIdenBtn = (Button)row.FindControl("btnEnqRowIdentifier");
                    if (radioBtn != null)
                    {
                        radioBtn.Checked = false;
                        if (rowIdenBtn != null && Id > 0 && Id.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                        {
                            radioBtn.Checked = true;
                        }
                    }
                }
            }
        }
        private void loadSearchGridAndReSelect(long Id)
        {
            try
            {
                EnquirySearchBy searchBy = EnumHelper.ToEnum<EnquirySearchBy>(drpSearchBy.Text);
                long searchByValId = -1;
                if (!string.IsNullOrWhiteSpace(drpSearchByValue.Text)) searchByValId = long.Parse(drpSearchByValue.Text);
                IList<EnquiryDetailDTO> results = enquiryBO.fetchEnquiryGridData(getUserDefinitionDTO().FirmNumber, searchBy, searchByValId);
                ViewState[VS_ENQUIRY_LIST] = results;
                enquiryGrid.DataSource = results;
                enquiryGrid.DataBind();
                if (Id > 0)
                {
                    selectEnquiryGridRdBtn(Id);
                    setSelectedEnquiry(Id);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void fetchSelectedEnquiry()
        {
            try
            {
                EnquiryDetailDTO enquiryDetailDto = null;
                if (PageMode.ADD.ToString().Equals(pageModeHdn.Value))
                {
                    enquiryDetailDto = populateEnquiryDTOAdd();
                    selectEnquiryGridRdBtn(0);
                }
                else if (PageMode.MODIFY.ToString().Equals(pageModeHdn.Value) || PageMode.VIEW.ToString().Equals(pageModeHdn.Value))
                {
                    long Id = ((List<EnquiryDetailDTO>)ViewState[VS_ENQUIRY_LIST]).Find(c => c.isUISelected).Id;
                    enquiryDetailDto = enquiryBO.fetchEnquiryDetails(Id);
                }
                ViewState[VS_SELECTED_ENQUIRY] = enquiryDetailDto;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void doViewModifyAction(PageMode pageMode)
        {
            resetTabInfo(pageMode);
            fetchSelectedEnquiry();
            populateUIFieldsFromDTO((EnquiryDetailDTO)ViewState[VS_SELECTED_ENQUIRY]);
        }
        protected void onSearchBy(object sender, EventArgs e)
        {
            try
            {
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                EnquirySearchBy searchBy = EnumHelper.ToEnum<EnquirySearchBy>(drpSearchBy.Text);
                drpSearchByValue.Visible = true;
                lbSearchByValue.Visible = true;
                lbSearchByValue.Text = EnumHelper.GetEnumDescription<EnquirySearchBy>(searchBy.ToString());
                if (EnquirySearchBy.CUSTOMER_NAME == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.ENQUIRY_CUSTOMER_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (EnquirySearchBy.PROP_LOCATION == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_LOCATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (EnquirySearchBy.PROP_TYPE == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (EnquirySearchBy.PROP_UNIT_TYPE == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (EnquirySearchBy.ENQUIRY_SOURCE == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ENQUIRY_SOURCE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (EnquirySearchBy.PROP_NAME == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.PROPERTY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (EnquirySearchBy.EMPLOYEE_NAME == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.EMPLOYEE_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else
                {
                    drpSearchByValue.ClearSelection();
                    drpSearchByValue.Visible = false;
                    lbSearchByValue.Visible = false;
                }
                loadSearchGridAndReSelect(0);
                resetTabInfo(PageMode.NONE);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onSearchByValue(object sender, EventArgs e)
        {
            loadSearchGridAndReSelect(0);
            resetTabInfo(PageMode.NONE);
        }
        protected void selectEnquiry(object sender, EventArgs e)
        {
            try
            {
                GroupRadioButton rd = (GroupRadioButton)sender;
                resetTabInfo(PageMode.NONE);
                if (rd.Checked)
                {
                    string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnEnqRowIdentifier"))).Attributes["row-identifier"];
                    setSelectedEnquiry(long.Parse(strId));
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        /*
         * This method is called on click of ADD button in datatable top bar.
         */
        protected void onClickAddEnquiryBtn(object sender, EventArgs e)
        {
            try
            {
                resetTabInfo(PageMode.ADD);
                fetchSelectedEnquiry();
                populateUIFieldsFromDTO(null);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickViewEnquiryBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateEnquirySelected())
                {
                    doViewModifyAction(PageMode.VIEW);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickModifyEnquiryBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateEnquirySelected())
                {
                    doViewModifyAction(PageMode.MODIFY);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void deleteEnquiry(object sender, EventArgs e)
        {
            try
            {
                if (validateEnquirySelected())
                {
                    long Id = ((List<EnquiryDetailDTO>)ViewState[VS_ENQUIRY_LIST]).Find(c => c.isUISelected).Id;
                    BusinessOutputTO businessOutputTO = enquiryBO.deleteEnquiryDetails(Id);
                    if (businessOutputTO.status == BusinessOutputTO.Status.SUCCESS)
                    {
                        loadSearchGridAndReSelect(0);
                        resetTabInfo(PageMode.NONE);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_delete, "Enquiry"), tab1Anchor.ID);
                    }
                    else
                    {
                        setErrorMessage(businessOutputTO.errorMessage, tab1ValidationGrp);
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void addOrModifyEnquiry(object sender, EventArgs e)
        {
            try
            {
                if (validateEnquiry())
                {
                    EnquiryDetailDTO enquirydetailDTO = getCurrentEnquiry();
                    long Id = enquirydetailDTO.Id;
                    populateEnquiryDTOFromUI(enquirydetailDTO);
                    if (PageMode.ADD.ToString().Equals(pageModeHdn.Value))
                    {
                        Id = enquiryBO.saveEnquiryDetails(enquirydetailDTO);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_add, "Enquiry"), tab2Anchor.ID);
                    }
                    else if (PageMode.MODIFY.ToString().Equals(pageModeHdn.Value))
                    {
                        enquiryBO.updateEnquiryDetails(enquirydetailDTO);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_update, "Enquiry"), tab2Anchor.ID);
                    }
                    loadSearchGridAndReSelect(Id);
                    doViewModifyAction(PageMode.VIEW);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        private bool validateEnquiry()
        {
            bool isValid = true;
            Page.Validate("tab2Error");
            isValid = Page.IsValid;
            if (!isValid) {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        protected void cancelEnquiry(object sender, EventArgs e)
        {
            EnquiryDetailDTO emquiryDetailDto = getCurrentEnquiry();
            resetTabInfo(PageMode.NONE);
            loadSearchGridAndReSelect(emquiryDetailDto.Id);
        }

        private EnquiryDetailDTO populateEnquiryDTOAdd()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            EnquiryDetailDTO enquiryDTO = new EnquiryDetailDTO();
            enquiryDTO.ContactInfo = new ContactInfoDTO();
            enquiryDTO.ContactInfo.Addresses = new HashSet<AddressDTO>();
            enquiryDTO.FirmNumber = userDefDto.FirmNumber;
            enquiryDTO.InsertUser = userDefDto.Username;
            return enquiryDTO;
        }
        private void populateEnquiryDTOFromUI(EnquiryDetailDTO enquiryDetailDTo)
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            enquiryDetailDTo.Salutation = CommonUIConverter.getMasterControlDTO(drpSalutation.Text, null);
            enquiryDetailDTo.FirstName = txtFirstName.Text;
            enquiryDetailDTo.MiddleName = txtMiddleName.Text;
            enquiryDetailDTo.LastName = txtLastName.Text;
            enquiryDetailDTo.ContactInfo.Gender = EnumHelper.ToEnumNullable<Gender>(drpGender.Text);
            enquiryDetailDTo.ContactInfo.Dob = DateTime.ParseExact(txtDOB.Text, Constants.DATE_FORMAT, CultureInfo.InvariantCulture);
            enquiryDetailDTo.ContactInfo.MaritalStatus = EnumHelper.ToEnumNullable<MaritalStatus>(drpMaritalStatus.Text);
            enquiryDetailDTo.ContactInfo.Contact = txtContact.Text;
            enquiryDetailDTo.ContactInfo.AltContact = txtAltContact.Text;
            enquiryDetailDTo.ContactInfo.Email = txtEmail.Text;
            enquiryDetailDTo.Occupation = CommonUIConverter.getMasterControlDTO(drpOccupation.Text, null);
            enquiryDetailDTo.FirmMember = CommonUIConverter.getFirmMemberDTO(drpFirmMember.Text, null);
            if (!string.IsNullOrWhiteSpace(txtDOE.Text)) enquiryDetailDTo.EnquiryDate = DateTime.ParseExact(txtDOE.Text, Constants.DATE_FORMAT, CultureInfo.InvariantCulture); else enquiryDetailDTo.EnquiryDate = null;
            if (!string.IsNullOrWhiteSpace(txtNextFollowupDate.Text)) enquiryDetailDTo.FollowupDate = DateTime.ParseExact(txtNextFollowupDate.Text, Constants.DATE_FORMAT, CultureInfo.InvariantCulture); else enquiryDetailDTo.FollowupDate = null;
            enquiryDetailDTo.PropertyType = CommonUIConverter.getMasterControlDTO(drpPropertyType.Text, null);
            enquiryDetailDTo.Comments = txtDescription.Text;
            enquiryDetailDTo.PropertyLocation = CommonUIConverter.getMasterControlDTO(drpPropertyLocation.Text, null);
            enquiryDetailDTo.UpdateUser = userDefDto.Username;
            enquiryDetailDTo.PrUnitType = CommonUIConverter.getMasterControlDTO(drpPropertyUnitType.Text, null);
            enquiryDetailDTo.Property = CommonUIConverter.getPropertyDTO(drpProperty.Text, null);
            enquiryDetailDTo.Status = EnumHelper.ToEnumNullable<EnquiryStatus>(drpStatus.Text);
            if (!string.IsNullOrWhiteSpace(txtBudget.Text)) enquiryDetailDTo.Budget = CommonUtil.getDecimalWithoutExt(txtBudget.Text);
            else enquiryDetailDTo.Budget = null;
            enquiryDetailDTo.EnquirySource = CommonUIConverter.getMasterControlDTO(drpEnquirySource.Text, null);
            enquiryDetailDTo.CloseReason = txtCloseReason.Text;
        }
        private void populateUIFieldsFromDTO(EnquiryDetailDTO enquiryDetailDTO)
        {
            if (enquiryDetailDTO != null && enquiryDetailDTO.Salutation != null) drpSalutation.Text = enquiryDetailDTO.Salutation.Id.ToString(); else drpSalutation.ClearSelection();
            if (enquiryDetailDTO != null) txtFirstName.Text = enquiryDetailDTO.FirstName; else txtFirstName.Text = null;
            if (enquiryDetailDTO != null) txtMiddleName.Text = enquiryDetailDTO.MiddleName; else txtMiddleName.Text = null;
            if (enquiryDetailDTO != null) txtLastName.Text = enquiryDetailDTO.LastName; else txtLastName.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.ContactInfo.Gender != null) drpGender.Text = enquiryDetailDTO.ContactInfo.Gender.ToString(); else drpGender.ClearSelection();
            if (enquiryDetailDTO != null && enquiryDetailDTO.ContactInfo.Dob != null) txtDOB.Text = enquiryDetailDTO.ContactInfo.Dob.Value.ToString(Constants.DATE_FORMAT); else txtDOE.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.ContactInfo.MaritalStatus != null) drpMaritalStatus.Text = enquiryDetailDTO.ContactInfo.MaritalStatus.ToString(); else drpMaritalStatus.ClearSelection();
            if (enquiryDetailDTO != null) txtContact.Text = enquiryDetailDTO.ContactInfo.Contact; else txtContact.Text = null;
            if (enquiryDetailDTO != null) txtAltContact.Text = enquiryDetailDTO.ContactInfo.AltContact; else txtAltContact.Text = null;
            if (enquiryDetailDTO != null) txtEmail.Text = enquiryDetailDTO.ContactInfo.Email; else txtEmail.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.EnquirySource != null) drpEnquirySource.Text = enquiryDetailDTO.EnquirySource.Id.ToString(); else drpEnquirySource.ClearSelection();
            if (enquiryDetailDTO != null && enquiryDetailDTO.PropertyLocation != null) drpPropertyLocation.Text = enquiryDetailDTO.PropertyLocation.Id.ToString(); else drpPropertyLocation.ClearSelection();
            if (enquiryDetailDTO != null && enquiryDetailDTO.PropertyType != null) drpPropertyType.Text = enquiryDetailDTO.PropertyType.Id.ToString(); else drpPropertyType.ClearSelection();
            if (enquiryDetailDTO != null && enquiryDetailDTO.PrUnitType != null) drpPropertyUnitType.Text = enquiryDetailDTO.PrUnitType.Id.ToString(); else drpPropertyUnitType.ClearSelection();
            if (enquiryDetailDTO != null && enquiryDetailDTO.Property != null) drpProperty.Text = enquiryDetailDTO.Property.Id.ToString(); else drpProperty.ClearSelection();
            if (enquiryDetailDTO != null && enquiryDetailDTO.EnquiryDate != null) txtDOE.Text = enquiryDetailDTO.EnquiryDate.Value.ToString(Constants.DATE_FORMAT); else txtDOE.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.FollowupDate != null) txtNextFollowupDate.Text = enquiryDetailDTO.FollowupDate.Value.ToString(Constants.DATE_FORMAT); else txtNextFollowupDate.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.CloseReason != null) txtCloseReason.Text = enquiryDetailDTO.CloseReason; else txtCloseReason.Text = null;
            if (enquiryDetailDTO != null && enquiryDetailDTO.Occupation != null) drpOccupation.Text = enquiryDetailDTO.Occupation.Id.ToString(); else drpOccupation.ClearSelection();
            if (enquiryDetailDTO != null && enquiryDetailDTO.PropertyLocation != null) drpPropertyLocation.Text = enquiryDetailDTO.PropertyLocation.Id.ToString(); else drpPropertyLocation.ClearSelection();
            if (enquiryDetailDTO != null) txtDescription.Text = enquiryDetailDTO.Comments; else txtDescription.Text = null;
            if (enquiryDetailDTO != null) txtBudget.Text = Convert.ToDecimal(enquiryDetailDTO.Budget).ToString(); else txtBudget.Text = null;
            if (enquiryDetailDTO != null) drpFirmMember.Text = enquiryDetailDTO.FirmMember.Id.ToString(); else drpFirmMember.ClearSelection();
            if (enquiryDetailDTO != null && enquiryDetailDTO.Status != null) drpStatus.Text = enquiryDetailDTO.Status.ToString(); else drpStatus.Text = null;

            populateAddressGrid(enquiryDetailDTO);
        }
        private void populateAddressGrid(EnquiryDetailDTO enquiryDetailDto)
        {
            addressGrid.DataSource = new List<AddressDTO>();
            if (enquiryDetailDto != null)
            {
                assignUiIndexToAddress(enquiryDetailDto.ContactInfo.Addresses);
                addressGrid.DataSource = enquiryDetailDto.ContactInfo.Addresses;
            }
            addressGrid.DataBind();
        }
        private void assignUiIndexToAddress(ISet<AddressDTO> addressDtos)
        {
            if (addressDtos != null && addressDtos.Count > 0)
            {
                long uiIndex = 1;
                foreach (AddressDTO addressDto in addressDtos)
                {
                    addressDto.UiIndex = uiIndex++;
                    addressDto.RowInfo = CommonUIConverter.getGridViewRowInfo(addressDto);
                }
            }
        }
       
        //Modal save logic
        protected void saveModalData(object sender, EventArgs e)
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();

            if (modalHdnType.Value == "PROPERTY_TYPE")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PROPERTY_TYPE, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "PROPERTY_TYPE");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpPropertyType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }

            else if (modalHdnType.Value == "PROPERTY_LOCATION")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PROPERTY_LOCATION, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "PROPERTY_LOCATION");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpPropertyLocation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_LOCATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }

            else if (modalHdnType.Value == "PROPERTY_UNIT_TYPE")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_UNIT_TYPE, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "PROPERTY_UNIT_TYPE");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpPropertyUnitType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            else if (modalHdnType.Value == "ENQUIRY_SOURCE")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.ENQUIRY_SOURCE, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "ENQUIRY_SOURCE");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpEnquirySource, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ENQUIRY_SOURCE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            else if (modalHdnType.Value == "OCCUPATION")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.OCCUPATION, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "OCCUPATION");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpOccupation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.OCCUPATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                modalErrorMsg.Value = errorMsg;
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "setModalErrorMsg", "setModalErrorMsg()", true);
            }
            else
            {
                //Reset the modal fields
                modalInput1.Text = "";
                modalInput2.Text = "";
                modalHdnType.Value = "";
                modalActionHdn.Value = "";
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "closeDialogClient", "closeDialogClient()", true);
            }
        }

        private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
        {
            string errorMsg = "";
            if (string.IsNullOrWhiteSpace(masterDataDto.Name))
            {
                errorMsg = Resources.Messages.validation_designationname_required;
            }
            else if (masterDataBO.isAlreadyExist(masterDataDto))
            {
                errorMsg = string.Format(Resources.Messages.validation_same_name_exist, type);
            }
            return errorMsg;
        }
        //Address Table actions - Start
        private void initAddressAddUpdateSection(bool isAdd)
        {
            lbAddUpdateSectionHeader.Text = (isAdd) ? Resources.Labels.label_sectionheader_add_address : Resources.Labels.label_sectionheader_modify_address;
            pnlAddressAdd.Visible = true;
            btnAddressAddToGrid.Visible = isAdd;
            btnAddressUpdateToGrid.Visible = !isAdd;
            drpAddressState.Text = Constants.DEFAULT_STATE;
        }
        private void setDefaultOnAddAddress()
        {
            drpAddressState.Text = Constants.DEFAULT_STATE;
            drpPreferredAddress.Text = PreferredAddress.No.ToString();
        }
        private void initAddressSectionFields(AddressDTO addressDto)
        {
            if (addressDto != null) txtAddressLine1.Text = addressDto.AddressLine1; else txtAddressLine1.Text = null;
            if (addressDto != null) txtAddressLine2.Text = addressDto.AddressLine2; else txtAddressLine2.Text = null;
            if (addressDto != null) txtTown.Text = addressDto.Town; else txtTown.Text = null;
            if (addressDto != null && addressDto.City != null) drpAddressCity.Text = addressDto.City.Id.ToString(); else drpAddressCity.ClearSelection();
            if (addressDto != null && addressDto.State != null) drpAddressState.Text = addressDto.State.Id.ToString(); else drpAddressState.ClearSelection();
            if (addressDto != null && addressDto.Country != null) drpAddressCountry.Text = addressDto.Country.Id.ToString(); else drpAddressCountry.ClearSelection();
            if (addressDto != null) txtPin.Text = addressDto.Pin; else txtPin.Text = null;
            if (addressDto != null && addressDto.AddressType != null) drpAddressType.Text = addressDto.AddressType.Id.ToString(); else drpAddressType.ClearSelection();
            if (addressDto != null && addressDto.PreferredAddress != null) drpPreferredAddress.Text = addressDto.PreferredAddress.ToString(); else drpPreferredAddress.ClearSelection();
        }
        private void clearAddressViewState()
        {
            if (addressGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in addressGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdAddressSelect");
                    if (radioBtn != null) radioBtn.Checked = false;
                }
            }
            getCurrentEnquiry().ContactInfo.Addresses.ToList<AddressDTO>().ForEach(c => c.isUISelected = false);
        }
        private AddressDTO getSelectedAddress()
        {
            return getCurrentEnquiry().ContactInfo.Addresses.ToList<AddressDTO>().Find(c => c.isUISelected);
        }
        private void initCityDrp(DropDownList drp, string stateId)
        {
            drpBO.drpDataBase(drp, DrpDataType.CITY, stateId, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
        }
        private bool validateAddressSelected()
        {
            bool isSelected = true;
            AddressDTO addressDto = getSelectedAddress();
            if (addressDto == null)
            {
                isSelected = false;
                pnlAddressAdd.Visible = false;
                clearAddressViewState();
                setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Address"), tab2ValidationGrp);
            }
            return isSelected;
        }

        private void populateAddressFromUI(AddressDTO addressDto)
        {
            addressDto.AddressLine1 = txtAddressLine1.Text;
            addressDto.AddressLine2 = txtAddressLine2.Text;
            addressDto.Town = txtTown.Text;
            addressDto.City = CommonUIConverter.getCityDTO(drpAddressCity.Text, drpAddressCity.SelectedItem.Text);
            addressDto.State = CommonUIConverter.getStateDTO(drpAddressState.Text, drpAddressState.SelectedItem.Text);
            addressDto.Country = CommonUIConverter.getCountryDTO(drpAddressCountry.Text, drpAddressCountry.SelectedItem.Text);
            addressDto.Pin = txtPin.Text;
            addressDto.AddressType = CommonUIConverter.getMasterControlDTO(drpAddressType.Text, drpAddressType.SelectedItem.Text);
            addressDto.PreferredAddress = EnumHelper.ToEnumNullable<PreferredAddress>(drpPreferredAddress.Text);
        }
        protected void loadCities(object sender, EventArgs e)
        {
            initCityDrp(drpAddressCity, drpAddressState.Text);
            SetFocus(drpAddressCity);
        }
        protected void selectAddress(object sender, EventArgs e)
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            pnlAddressAdd.Visible = false;
            if (rd.Checked)
            {
                long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnAddressRowIdentifier"))).Attributes["row-identifier"]);
                List<AddressDTO> addressList = getCurrentEnquiry().ContactInfo.Addresses.ToList<AddressDTO>();
                addressList.ForEach(c => c.isUISelected = false);
                addressList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
            }
        }
        protected void onClickAddAddressBtn(object sender, EventArgs e)
        {
            try
            {
                initAddressAddUpdateSection(true);
                initAddressSectionFields(null);
                setDefaultOnAddAddress();
                SetFocus(txtAddressLine1);
                scrollToFieldHdn.Value = pnlAddressAdd.ID;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void onClickModifyAddressBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateAddressSelected())
                {
                    initAddressAddUpdateSection(false);
                    initAddressSectionFields(getSelectedAddress());
                    SetFocus(txtAddressLine1);
                    scrollToFieldHdn.Value = pnlAddressAdd.ID;
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void deleteAddress(object sender, EventArgs e)
        {
            try
            {
                if (validateAddressSelected())
                {
                    EnquiryDetailDTO firmMemberDto = getCurrentEnquiry();
                    AddressDTO addressDto = getSelectedAddress();
                    firmMemberDto.ContactInfo.Addresses.Remove(addressDto);
                    pnlAddressAdd.Visible = false;
                    clearAddressViewState();
                    populateAddressGrid(firmMemberDto);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, "Address"), tab2Anchor.ID);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void addNewAddress(object sender, EventArgs e)
        {
            try
            {
                if (validateAddress())
                {
                    EnquiryDetailDTO enquiryDetailDto = getCurrentEnquiry();
                    AddressDTO addressDto = new AddressDTO();
                    populateAddressFromUI(addressDto);
                    enquiryDetailDto.ContactInfo.Addresses.Add(addressDto);
                    pnlAddressAdd.Visible = false;
                    clearAddressViewState();
                    populateAddressGrid(enquiryDetailDto);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, "Address"), tab2Anchor.ID);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void updateAddress(object sender, EventArgs e)
        {
            try
            {
                if (validateAddress())
                {
                    EnquiryDetailDTO enquiryDetailDTO = getCurrentEnquiry();
                    AddressDTO addressDto = getSelectedAddress();
                    populateAddressFromUI(addressDto);
                    pnlAddressAdd.Visible = false;
                    clearAddressViewState();
                    populateAddressGrid(enquiryDetailDTO);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_updatedtotable, "Address"), tab2Anchor.ID);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void cancelAddress(object sender, EventArgs e)
        {
            pnlAddressAdd.Visible = false;
            clearAddressViewState();
        }
        private bool validateAddress()
        {
            bool isValid = true;
            Page.Validate("tab2ErrorGrid1");
            isValid = Page.IsValid;
            if (drpPreferredAddress.Text.Equals(PreferredAddress.Yes.ToString()) && isValid)
            {
                List<AddressDTO> addressList = getCurrentEnquiry().ContactInfo.Addresses.ToList<AddressDTO>();
                bool isPreferred = addressList.Any(c => (c.PreferredAddress == PreferredAddress.Yes && !c.isUISelected));
                if (isPreferred)
                {
                    isValid = false;
                    setErrorMessage(Resources.Messages.validation_address_one_preferred, tab2ValidationGrp);
                }
            }
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        //Address Table actions - END
    }
}