﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq.Expressions;
using NHibernate.Impl;
using System.Linq;

/// <summary>
/// Summary description for propertyBO
/// </summary>
namespace ConstroSoft
{
    public class AvailablePropertyUnitBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public AvailablePropertyUnitBO() { }

        public List<PropertyUnitDTO> fetchAvailablePropertyUnits(string firmNumber, long propertyTowerId)
        {
            ISession session = null;
            List<PropertyUnitDTO> propertyUnitList = new List<PropertyUnitDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit ps = null;
                        PropertyTower p = null;
                        IList<PropertyUnit> result = session.QueryOver<PropertyUnit>(() => ps).JoinAlias(() => ps.PropertyTower, () => p)
                            .Where(() => ps.FirmNumber == firmNumber && p.Id == propertyTowerId && ps.Status == PRUnitStatus.Available).List<PropertyUnit>();
                        foreach(PropertyUnit prUnit in result) {
                            propertyUnitList.Add(DomainToDTOUtil.convertToPropertyUnitDTO(prUnit, true));
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching available property units :", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return propertyUnitList;
        }
        public long bookPropertyUnitDetails(PrUnitSaleDetailDTO prUnitSaleDetailDto)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit propertyUnit = session.Get<PropertyUnit>(prUnitSaleDetailDto.PropertyUnit.Id);
                        propertyUnit.Status = PRUnitStatus.Sold;
                        session.Update(propertyUnit);
                        
                        PrUnitSaleDetail prUnitSaleDetail = DTOToDomainUtil.populatePrUnitSaleDetailAddFields(prUnitSaleDetailDto);
                        session.Save(prUnitSaleDetail);
                        Id = prUnitSaleDetail.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Booking Property Unit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
                sendSMSEmail(prUnitSaleDetail);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        /**
         * This method will check Email & SMS configuration for Sales Function. 
         * If Email & SMS alerts are enabled then system will send Email & SMS to Customer.
         * */
        private static void sendSMSEmail(PrUnitSaleDetail prUnitSaleDetail)
        {
            EmailSmsAlertConfig emailSmsAlertConfig = EmailUtil.loadEmailSmsAlertConfiguration(prUnitSaleDetail.FirmNumber,
                ConstroSoft.Constants.FUNCTIONNAME.SALE, ConstroSoft.Constants.EMAILSMSTYPE.SALESTHANKS);
            if (emailSmsAlertConfig != null && emailSmsAlertConfig.Email.Equals(Constants.YES))
            {
                emailSmsAlertConfig.EmailBody = populateBody(prUnitSaleDetail, emailSmsAlertConfig);
                LinkedResource inline = new LinkedResource(System.Web.HttpContext.Current.Server.MapPath("~/ui/common/img/3D-Thank-You-HD-Wallpapers.jpg"), MediaTypeNames.Image.Jpeg);
                inline.ContentId = Guid.NewGuid().ToString();
                EmailUtil.sendHtmlFormattedEmail(prUnitSaleDetail.FirmNumber, emailSmsAlertConfig, prUnitSaleDetail.Customer.ContactInfo.Email, inline);
            }
            if (emailSmsAlertConfig != null && emailSmsAlertConfig.Sms.Equals(Constants.YES))
            {
                EmailUtil.sendSMS(propertyUnit.FirmNumber, emailSmsAlertConfig,  prUnitSaleDetail.Customer.ContactInfo.Contact);
            }
        }
        private static string populateBody(PrUnitSaleDetail prUnitSaleDetail, EmailSmsAlertConfig emailSmsAlertConfig)
        {
        	PropertyDTO propertyDTO = propertyBO.fetchProperty(prUnitSaleDetail.PropertyUnit.PropertyTower.Property.Id);
        	string body = string.Empty;
            using (StreamReader reader = new StreamReader(System.Web.HttpContext.Current.Server.MapPath(emailSmsAlertConfig.EmailTemplatePath)))
            {
                body = reader.ReadToEnd();
            }
            body = body.Replace("{UserName}", prUnitSaleDetail.Customer.FirstName + " " + prUnitSaleDetail.Customer..LastName);
            body = body.Replace("{UnitNumber}",  CommonUIConverter.getPropertyUnitFormattedNo(prUnitSaleDetail.PropertyUnit.Wing, prUnitSaleDetail.PropertyUnit.UnitNo));
            body = body.Replace("{ProjectName}",  propertyDTO.Name.);
            return body;
        }
    }
}