﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Web.Mail;
/// <summary>
/// Summary description for EmailUtil
/// </summary>
using ConstroSoft;
using NHibernate;

namespace ConstroSoft
{
    public class EmailUtil
    {
        //Logger Instance
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public EmailUtil() { }

        /**
         * This Method will load the EMAIL Configuration for Firm Number.
         * */
        public static EmailConfig loadEmailConfiguration(String firmNumber)
        {
            ISession session = null;
            EmailConfig emailConfig = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        emailConfig = session.QueryOver<EmailConfig>(() => emailConfig).Where(() => emailConfig.FirmNumber == firmNumber).SingleOrDefault<EmailConfig>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Email Configuration:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return emailConfig;
        }
        /**
         * This Method will load the SMS Configuration for Firm Number.
         * */
        public static SmsConfig loadSmsConfiguration(String firmNumber)
        {
            ISession session = null;
            SmsConfig smsConfig = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        smsConfig = session.QueryOver<SmsConfig>(() => smsConfig).Where(() => smsConfig.FirmNumber == firmNumber).SingleOrDefault<SmsConfig>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading SMS Configuration:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return smsConfig;
        }
        /**
         * This method check if internet connection working.
         * */
        public static bool checkInternetConnection()
        {
            try
            {
                using (var client = new WebClient())
                using (var stream = client.OpenRead("http://www.google.com"))
                {
                    return true;
                }

            }
            catch
            {
                return false;
            }
        }
        /**
        * This Method will load the EMAIL & SMS alert Configuration for Firm Number.
        * */
        public static EmailSmsAlertConfig loadEmailSmsAlertConfiguration(String firmNumber, String functionName, String emailSmsType)
        {
            ISession session = null;
            EmailSmsAlertConfig emailSmsAlertConfig = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        emailSmsAlertConfig = session.QueryOver<EmailSmsAlertConfig>(() => emailSmsAlertConfig).Where(() => emailSmsAlertConfig.FirmNumber == firmNumber
                            && emailSmsAlertConfig.FunctionName == functionName && emailSmsAlertConfig.EmailSmsType == emailSmsType).SingleOrDefault<EmailSmsAlertConfig>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Email SMS Alert Configuration:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return emailSmsAlertConfig;
        }
        /**
         * This method will load Email configuration & Send Email.
         * */
        public static void sendEmail(String firmNumber, EmailSmsAlertConfig emailSmsAlertConfig, String toAddress)
        {
            try
            {
                if (checkInternetConnection())
                {
                    EmailConfig emailConfig = loadEmailConfiguration(firmNumber);
                    if (emailConfig != null && emailSmsAlertConfig != null)
                    {
                        var client = new System.Net.Mail.SmtpClient(emailConfig.SmtpHost, Convert.ToInt32(emailConfig.SmtpPort))
                        {
                            Credentials = new NetworkCredential(emailConfig.FromAddress, emailConfig.Password),
                            EnableSsl = true
                        };
                        client.Send(emailSmsAlertConfig.FromAddress, toAddress, emailSmsAlertConfig.Subject, emailSmsAlertConfig.EmailContent);
                        log.Info("Email Sent Successfully to : " + toAddress);
                    }
                    else
                    {
                        log.Error("Error in loading Email Configuration.");
                    }
                }
                else
                {
                    log.Error("Please check your internet connection or try again later.");
                }

            }
            catch (Exception ex)
            {
                log.Error("Error in sending Email", ex);
            }
        }
        /**
         * This method will load SMS configuration & Send SMS.
         * */
        public static void sendSMS(String firmNumber, EmailSmsAlertConfig emailSmsAlertConfig, String toNumbers)
        {
            if (checkInternetConnection())
            {
                SmsConfig smsConfig = loadSmsConfiguration(firmNumber);
                if (smsConfig != null && emailSmsAlertConfig != null)
                {
                    string strUrl = smsConfig.Url + smsConfig.UserId + ":" + smsConfig.Password +
                        "&senderID=" + smsConfig.SenderId + "&receipientno=" + toNumbers + "&msgtxt=" + emailSmsAlertConfig.SmsContent + "&state=4";
                    WebRequest request = HttpWebRequest.Create(strUrl);
                    HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                    Stream s = (Stream)response.GetResponseStream();
                    StreamReader readStream = new StreamReader(s);
                    string dataString = readStream.ReadToEnd();
                    response.Close();
                    s.Close();
                    readStream.Close();
                    if (dataString.StartsWith("Status=0"))
                    {
                        log.Info("SMS Sent Successfully to : " + toNumbers);
                    }
                }
                else
                {
                    log.Error("Error in loading SMS Configuration.");
                }
            }
            else
            {
                log.Error("Please check your internet connection or try again later.");
            }
        }

        public static void sendHtmlFormattedEmail(String firmNumber, EmailSmsAlertConfig emailSmsAlertConfig, String toAddress, LinkedResource inline)
        {
            if (checkInternetConnection())
            {
                EmailConfig emailConfig = loadEmailConfiguration(firmNumber);
                if (emailConfig != null && emailSmsAlertConfig != null)
                {
                    using (System.Net.Mail.MailMessage mailMessage = new System.Net.Mail.MailMessage())
                    {
                        mailMessage.From = new MailAddress(emailConfig.FromAddress);
                        mailMessage.Subject = emailSmsAlertConfig.Subject;
                        string body = String.Format(emailSmsAlertConfig.EmailBody, inline.ContentId);
                        mailMessage.IsBodyHtml = true;
                        AlternateView avHtml = AlternateView.CreateAlternateViewFromString(body, null, MediaTypeNames.Text.Html);
                        avHtml.LinkedResources.Add(inline);
                        mailMessage.AlternateViews.Add(avHtml);
                        mailMessage.To.Add(new MailAddress(toAddress));
                        SmtpClient smtp = new SmtpClient();
                        smtp.Host = emailConfig.SmtpHost;
                        smtp.EnableSsl = true;
                        System.Net.NetworkCredential NetworkCred = new System.Net.NetworkCredential();
                        NetworkCred.UserName = emailConfig.FromAddress;
                        NetworkCred.Password = emailConfig.Password;
                        smtp.UseDefaultCredentials = true;
                        smtp.Credentials = NetworkCred;
                        smtp.Port = int.Parse(emailConfig.SmtpPort);
                        smtp.Send(mailMessage);
                    }
                }
                else
                {
                    log.Error("Error in loading Email Configuration.");
                }
            }
            else
            {
                log.Error("Please check your internet connection or try again later.");
            }
        }
    }
}