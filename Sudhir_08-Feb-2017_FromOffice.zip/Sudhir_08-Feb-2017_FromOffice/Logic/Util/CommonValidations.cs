﻿using ConstroSoft;
using System.Collections.Generic;
using NHibernate.Criterion;
using System.Linq.Expressions;
using NHibernate.Impl;
using System;
using System.Web.UI.WebControls;
using System.Globalization;
namespace ConstroSoft
{
    public class CommonValidations
    {
        public CommonValidations() { }
        public static string validateUnitSaleDates(DateTime bookingDate, DateTime? possessionDate, DateTime? agreementDate, string agreementNo)
        {
            string errorMessage = "";
            if (agreementDate != null)
            {
                if (bookingDate.CompareTo(agreementDate.Value) > 0)
                {
                    errorMessage = Resources.Messages.validation_booking_after_agreement;
                } 
                else if (string.IsNullOrWhiteSpace(agreementNo))
                {
                    errorMessage = Resources.Messages.validation_agreementno_required;
                }
            }
            if (possessionDate != null)
            {
                if (agreementDate == null || agreementDate.Value.CompareTo(possessionDate.Value) > 0)
                {
                    errorMessage = Resources.Messages.validation_agreement_after_possession;
                }
            }
            return errorMessage;
        }
    }
}