﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
	initEnquiryLeadSearchGrid();
    formatFields();
}

function initEnquiryLeadSearchGrid() {
    var dtOptions = {
        tableId: "allEnquiryLeadSearchGrid",
        pageLength: 10,
        isViewOnly: false,
        hideSearch: true
    };
    var dtTable = applyActionDataTable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitHdnId");
}




