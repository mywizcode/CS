﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
	initTaxGrid();
	initCMTaxGrid();
	initPaymentGrid();
    formatFields();
    showModal();
}

function initTaxGrid() {
    var dtOptions = {
        tableId: "taxDetailGrid",
        isViewOnly: false
    };
    var dtTable = applySimpleDataTable(dtOptions);
}
function initCMTaxGrid() {
    var dtOptions = {
        tableId: "cmTaxDetailGrid",
        isViewOnly: false
    };
    var dtTable = applySimpleDataTable(dtOptions);
}
function initPaymentGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "paymentGrid",
        pageLength: 5,
        responsiveModalTitle: "Payment Details",
        isViewOnly: isViewOnly,
        customBtnGrpId: "#paymentGridBtnGrp",
        sortColumn: 2,
        hideSearch: true
    };
    var dtTable = applyActionDataTable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitUploadHdnId");
}



