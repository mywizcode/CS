﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initParkingSearchGrid();
    initPropertyParkingUploadGrid();
    formatFields();
    showModal();
}

function initParkingSearchGrid() {
    var dtOptions = {
        tableId: "propertyParkingSearchGrid",
        pageLength: 10,
        isViewOnly: false,
        customBtnGrpId: "#propertyParkingSearchBtnDiv",
        hideSearch: false
    };
    var dtTable = applyActionDataTable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitHdnId");
}
function initPropertyParkingUploadGrid() {
    var dtOptions = {
        tableId: "parkingUploadGrid",
        pageLength: 10,
        responsiveModalTitle: "Parking Details",
        isViewOnly: true,
        hideSearch: false,
        allSortable: true
    };
    var dtTable = applyActionDataTable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitUploadHdnId");
}
function unblockUI() {
    alert("Hi");
    $.unblock();
}




