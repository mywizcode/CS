﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using ConstroSoft.Logic.BO;

public partial class PropertyFundSearch : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string SearchFilterModal = "SearchFilterModal";
    DropdownBO drpBO = new DropdownBO();
    PropertyFundsBO propertyFundsBO = new PropertyFundsBO();

    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                PropertyFundSearchNavDTO navDto = (PropertyFundSearchNavDTO)Session[Constants.Session.NAV_DTO];
                Session.Remove(Constants.Session.NAV_DTO);
                Session.Remove(Constants.Session.PAGE_DATA);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(Constants.URL.DEFAULT_HOME_PAGE, false);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();

    }
    private void preRenderInitFormElements()
    {
        renderPageLayout();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpEnum<PaymentMethod>(drpPaymentMethodFilter, null);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(PropertyFundSearchNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new PropertyFundSearchPageDTO();
        initDropdowns();
        setSearchFilter(null);
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(PropertyFundSearchNavDTO navDto)
    {
        try
        {
            if (navDto != null)
            {
                setSearchFilter(navDto.filterDTO);
            }
            loadPropertyFundSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageLayout()
    {
    }
    private void setSearchGrid(IList<PropertyFundsDTO> tmpList)
    {
        getSessionPageData().SearchResult = (tmpList != null) ? tmpList.ToList<PropertyFundsDTO>() : new List<PropertyFundsDTO>();
        propertyFundSearchGrid.DataSource = getSearchPropertyFundList();
        propertyFundSearchGrid.DataBind();
    }
    private PropertyFundSearchPageDTO getSessionPageData()
    {
        return (PropertyFundSearchPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<PropertyFundsDTO> getSearchPropertyFundList()
    {
        return getSessionPageData().SearchResult;
    }
    private PropertyFundsDTO getSearchPropertyFundDTO(long Id)
    {
        List<PropertyFundsDTO> searchList = getSearchPropertyFundList();
        PropertyFundsDTO selectedPropertyFundDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            selectedPropertyFundDTO = searchList.Find(c => c.Id == Id);
        }
        return selectedPropertyFundDTO;
    }
    private void loadPropertyFundSearchGrid()
    {
        PropertyDTO property = CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO());
        IList<PropertyFundsDTO> results = propertyFundsBO.fetchAccountDepositGridData(getUserDefinitionDTO().FirmNumber, property.Id);
        setSearchGrid(results);
    }
    private void navigateToPropertyFundDetails(long selectedId, PageMode mode)
    {
        //PropertyFundsDTO propertyFundsDTO = getSearchPropertyFundDTO(selectedId);
        //PropertyFundDetailNavDTO navDTO = new PropertyFundDetailNavDTO();
        //navDTO.Mode = mode;
        //navDTO.propertyFundId = propertyFundsDTO.Id;
        //PropertyFundSearchNavDTO searchNavDTO = new PropertyFundSearchNavDTO();
        //searchNavDTO.filterDTO = getSearchFilter();
        //navDTO.PrevNavDto = searchNavDTO;
        //Session[Constants.Session.NAV_DTO] = navDTO;
        //Response.Redirect(Constants.URL.SOLD_UNIT_DETAILS, true);
    }
    protected void onClickViewPropertyFundBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            navigateToPropertyFundDetails(selectedId, PageMode.VIEW);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyPropertyFundBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            navigateToPropertyFundDetails(selectedId, PageMode.MODIFY);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickCancelBookingBtn(object sender, EventArgs e)
    {
        try
        {
            EnquiryActivityHistoryNavDTO navDTO = new EnquiryActivityHistoryNavDTO();
            navDTO.EnquiryId = 2;
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.ENQUIRY_ACTIVITY_HISTORY, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickAddPropertyFundBtn(object sender, EventArgs e)
    {
        try
        {
            
            PropertyFundDetailNavDTO navDTO = new PropertyFundDetailNavDTO();
            navDTO.Mode = PageMode.ADD;
            navDTO.PrevNavDto = getCurrentPageNavigation();
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.PROPERTY_FUND_DETAIL, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private EnquirySearchNavDTO getCurrentPageNavigation()
    {
        PropertyFundSearchNavDTO propertyFundSearchNavDTO = new PropertyFundSearchNavDTO();
        propertyFundSearchNavDTO.filterDTO = getSearchFilter();
        return propertyFundSearchNavDTO;
    }
   
    protected void deletePropertyFund(object sender, EventArgs e)
    {
        try
        {
                long selectedId = getDeleteRecordHdnId();
                PropertyFundDTO depositDto = propertyFundBO.fetchDeposit(Id);
                if (!validateDepositStatus(depositDto))
                {
                    depositDto.DepositeDate = DateTime.Now;
                    depositDto.Status = AcntDepositStatus.Reversed;
                    AccountTransactionDTO acntTransDto = createAccountTransaction(depositDto, true);
                    accountdepositBO.deleteDeposit(depositDto, acntTransDto);
                    loadPropertyFundSearchGrid();
                    setSuccessMessage(string.Format(Resources.Messages.success_record_delete, "Deposit"));
                }
         }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private AccountTransactionDTO createAccountTransaction(PropertyFundsDTO propertyFundsDTO, bool isDelete)
    {
        AccountTransactionDTO acntTransDto = new AccountTransactionDTO();
        acntTransDto.FirmAccount = CommonUIConverter.getFirmAccountDTO(propertyFundsDTO.FirmAccount.Id.ToString(), propertyFundsDTO.FirmAccount.Name);
        PaymentTransactionDTO pymtTransDto = new PaymentTransactionDTO();
        PaymentMode paymentMode = EnumHelper.ToEnum<PaymentMode>(depositDto.PymtMode);
        pymtTransDto.PymtMode = paymentMode;
        pymtTransDto.ChequeNo = depositDto.ChequeNo;
        string pymtModeComment = CommonUtil.getAcntTransCommentPymtMode(pymtTransDto);
        if (isDelete) {
            acntTransDto.TxType = AcntTransStatus.Debit;
            acntTransDto.Comments = string.Format(Constants.REV_PYMT_FROM, "SELF") + "," + pymtModeComment;
        }
        else
        {
            acntTransDto.Comments = string.Format(Constants.PYMT_FROM, "SELF") + "," + pymtModeComment; 
            acntTransDto.TxType = AcntTransStatus.Credit;
        }
       
        acntTransDto.TxDate = propertyFundsDTO.DepositeDate;
        decimal tmpvalue;
        decimal result = 0.0M;
        if (decimal.TryParse(propertyFundsDTO.Amount.ToString(), out tmpvalue))
            result = tmpvalue;
        acntTransDto.Amount = result;
        acntTransDto.FirmNumber = propertyFundsDTO.FirmNumber;
        acntTransDto.InsertUser = propertyFundsDTO.InsertUser;
        acntTransDto.UpdateUser = propertyFundsDTO.UpdateUser;
        return acntTransDto;
        
    }
    private bool validateDepositStatus(PropertyFundDTO depositDto)
    {
        bool isReversed = false;
        if (depositDto.Status == AcntDepositStatus.Reversed)
            {
                setErrorMessage(Resources.Messages.validation_deposit_reversed, commonError);
                isReversed = true;
            }
        return isReversed;
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    //Filter Criteria - Property Search - Start
    private PropertyFundFilterDTO getSearchFilter()
    {
        return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            PropertyFundFilterDTO filterDTO = getSearchFilter();
            if (filterDTO.AccountName != null) txtAccountNameFilter.Text = filterDTO.AccountName; else txtAccountNameFilter.Text = null;
            if (filterDTO.PymtMethod != null) drpPaymentMethodFilter.Text = filterDTO.PymtMethod.ToString(); else drpPaymentMethodFilter.ClearSelection();
            if (filterDTO.MediaNo != null) txtMediaNoFilter.Text = filterDTO.MediaNo; else txtMediaNoFilter.Text = null;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            PropertyFundFilterDTO filterDTO = new PropertyFundFilterDTO();
            if (!string.IsNullOrWhiteSpace(txtAccountNameFilter.Text))
            {
                filterDTO.AccountName = txtAccountNameFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(drpPaymentMethodFilter.Text))
            {
                filterDTO.PymtMethod = EnumHelper.ToEnum<PaymentMethod>(drpPaymentMethodFilter.SelectedItem.Text);
            }
            if (!string.IsNullOrWhiteSpace(txtMediaNoFilter.Text))
            {
                filterDTO.MediaNo = txtMediaNoFilter.Text;
            }
            setSearchFilter(filterDTO);
            loadPropertyFundSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            loadPropertyFundSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(PropertyFundFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new PropertyFundFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {
           // drpTowerFilter.Text = CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Id.ToString();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            PropertyFundFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.ACCOUNT_NAME))  filterDTO.AccountName = null;
            else if (token.StartsWith(Constants.FILTER.PYMT_METHOD)) filterDTO.PymtMethod = null;
            else if (token.StartsWith(Constants.FILTER.MEDIA_NO)) filterDTO.PymtMethod = null;
            setSearchFilterTokens();
            loadPropertyFundSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        PropertyFundFilterDTO filterDTO = getSearchFilter();
        string filter = null;
        if (filterDTO != null)
        {
            if (filterDTO.AccountName != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.ACCOUNT_NAME + filterDTO.AccountName);
            if (filterDTO.PymtMethod != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.PYMT_METHOD + filterDTO.PymtMethod);
            if (filterDTO.MediaNo != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.MEDIA_NO + filterDTO.MediaNo);
        }
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - Property Fund Search - End
}
