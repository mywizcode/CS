﻿/* ------------------------------------------------------------------------------
 *
 *  # Google Visualization - 3D pie
 *
 *  Google Visualization 3D pie chart demonstration
 *
 *  Version: 1.0
 *  Latest update: August 1, 2015
 *
 * ---------------------------------------------------------------------------- */


// 3D pie chart
// ------------------------------

// Initialize chart
google.load("visualization", "1", { packages: ["corechart"] });
google.setOnLoadCallback(drawPie3d);


// Chart settings
function drawPie3d() {

	var inputVal = $("[id$='EnqDistSrcWiseDataHdn']").val();
	var dataset = $.parseJSON(inputVal);
    // Data
    var data = new google.visualization.DataTable();
    data.addColumn('string', 'Source');
    data.addColumn('number', 'Enquiry Count');
    dataset.forEach(function (d) {
        data.addRow([d.SourceName, d.Count]);
    });


    // Options
    var options_pie_3d = {
        fontName: 'Roboto',
        is3D: true,
        height: 395,
        width: 470,
        chartArea: {
            left: 50,
            width: '95%',
            height: '95%'
        }
    };


    // Instantiate and draw our chart, passing in some options.
    var pie_3d = new google.visualization.PieChart($('#google-pie-3d')[0]);
    pie_3d.draw(data, options_pie_3d);
}