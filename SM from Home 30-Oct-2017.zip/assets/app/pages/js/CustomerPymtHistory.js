﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
	initPaymentTxHistoryGrid();
	initPdcHistoryGrid();
    formatFields();
    showModal();
}
function initPaymentTxHistoryGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        rowInfoModalTitle: "Payment Transaction Details",
        pageLength: 5,
        sortColumn: 3,
        sortOrder: "desc",
        hideSearch: true
    };

    $("[id$='txHistoryGrid']").CSBasicDatatable(dtOptions);
}
function initPdcHistoryGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        rowInfoModalTitle: "Cheque Details",
        pageLength: 5,
        sortColumn: 2,
        sortOrder: "desc",
        hideSearch: true
    };

    $("[id$='pdcGrid']").CSBasicDatatable(dtOptions);
}