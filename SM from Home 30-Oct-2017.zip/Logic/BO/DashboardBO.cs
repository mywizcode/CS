﻿using System;
using NHibernate;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using ConstroSoft;
using System.Collections.Generic;
using NHibernate.Criterion;
using NHibernate.Transform;
using System.Net.Mail;
using System.Net.Mime;
using System.Linq;

/// <summary>
/// Summary description for SupplierBO
/// </summary>
namespace ConstroSoft
{
    public class DashboardBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public DashboardBO() { }

        public object[] fetchLeadStatsForDashboard(long PropertyId, int lastNoOfMonths)
        {
            ISession session = null;
            object[] result = new Object[3];
            LeadsOpenedGadgetDTO leadsOpenedGadgetDTO = new LeadsOpenedGadgetDTO();
            leadsOpenedGadgetDTO.LeadsOpenedList = new List<LeadsOpenedCountDTO>();
            List<LeadsNewOpenWeekDTO> leadsOpenedWeekList = createLeadsOpenedStats(lastNoOfMonths);
            List<EnquiryLeadSourceWiseCountDTO> LeadSrcDistList = new List<EnquiryLeadSourceWiseCountDTO>();
            LeadsProcessedCountDTO leadsProcessedDto = new LeadsProcessedCountDTO();
            IList<LeadDetailDTO> tmpResultList = new List<LeadDetailDTO>();
            
            result[0] = leadsOpenedGadgetDTO;
            result[1] = LeadSrcDistList;
            result[2] = leadsProcessedDto;
            
            int noOfWeeks = lastNoOfMonths * 5;
            DateTime EndDate = DateTime.Today;
        	DateTime StartDate = EndDate.AddDays((lastNoOfMonths * 5 * -7) + 1);
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        LeadDetail ld = null;
                        MasterControlData es = null;
                        Property p = null;

                        LeadDetailDTO ldDTO = null;

                        var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => ld.LeadDate).WithAlias(() => ldDTO.LeadDate))
                                .Add(Projections.Property(() => ld.DateClosed).WithAlias(() => ldDTO.DateClosed))
                                .Add(Projections.Property(() => ld.Status).WithAlias(() => ldDTO.Status))
                                .Add(Projections.Property(() => es.Name), "Source.Name");

                        var query = session.QueryOver<LeadDetail>(() => ld)
                                .Left.JoinAlias(() => ld.Property, () => p)
                                .Left.JoinAlias(() => ld.Source, () => es)
                                .Select(proj);
                       tmpResultList = query.Where(() => p.Id == PropertyId 
		                			&& ((ld.LeadDate >= StartDate && ld.LeadDate <= EndDate) 
		                					|| (ld.DateClosed >= StartDate && ld.DateClosed <= EndDate)))
                                .TransformUsing(new DeepTransformer<LeadDetailDTO>())      
		                		.List<LeadDetailDTO>();
		                
		                foreach(LeadDetailDTO tmpDTO in tmpResultList) {
		                	//Create stats for new Leads Opened gadget -> New leads and Source wise distrubtion
		                	if(tmpDTO.LeadDate.CompareTo(StartDate) >= 0 && tmpDTO.LeadDate.CompareTo(EndDate) <= 0) {
		                		leadsOpenedGadgetDTO.TotalCount++;
		                		//Daily new opened leads
		                		string tmpDate = DateUtil.getCSDate(tmpDTO.LeadDate);
		                		LeadsNewOpenWeekDTO weekDTO = leadsOpenedWeekList.Find(x => x.StartDate.CompareTo(tmpDTO.LeadDate) <= 0 
		                					&& x.EndDate.CompareTo(tmpDTO.LeadDate) >= 0);
		                		weekDTO.CountDTO.Count++;
			                	
			                	//Source wise distribution.
			                	EnquiryLeadSourceWiseCountDTO srcCountDTO = LeadSrcDistList.Find(x => x.SourceName == tmpDTO.Source.Name);
			                	if(srcCountDTO == null) {
			                		srcCountDTO = new EnquiryLeadSourceWiseCountDTO();
			                		srcCountDTO.SourceName = tmpDTO.Source.Name;
			                		LeadSrcDistList.Add(srcCountDTO);
			                	}
			                	srcCountDTO.Count++;
		                	}
                            if (tmpDTO.Status != LeadStatus.Open && tmpDTO.DateClosed.Value.CompareTo(StartDate) >= 0 && tmpDTO.DateClosed.Value.CompareTo(EndDate) <= 0)
                            {
		                		leadsProcessedDto.TotalProcessed++;
		                		if(tmpDTO.Status == LeadStatus.Converted) leadsProcessedDto.TotalConverted++;
		                		else leadsProcessedDto.TotalLost++;
		                	}
		                }
		                leadsOpenedWeekList.Sort((x, y) => DateTime.Compare(x.StartDate, y.StartDate));
		                leadsOpenedWeekList.ForEach(x => leadsOpenedGadgetDTO.LeadsOpenedList.Add(x.CountDTO));
		                
		                leadsOpenedGadgetDTO.AverageOpened = (leadsOpenedGadgetDTO.TotalCount > 0) ?
                                NumberUtil.Divide(leadsOpenedGadgetDTO.TotalCount, (lastNoOfMonths * Constants.CRM_STATS_NO_OF_WEEKS)) : decimal.Zero;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching Lead Stats:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        private List<LeadsNewOpenWeekDTO> createLeadsOpenedStats(int lastNoOfMonths) {
        	List<LeadsNewOpenWeekDTO> leadOpenedWeekList = new List<LeadsNewOpenWeekDTO>();
            int noOfWeeks = lastNoOfMonths * Constants.CRM_STATS_NO_OF_WEEKS;
        	DateTime date = DateTime.Today;
        	for(int i = 1; i <= noOfWeeks; i++) {
        		LeadsNewOpenWeekDTO weekDTO = new LeadsNewOpenWeekDTO();
        		weekDTO.StartDate = date.AddDays(-6);
        		weekDTO.EndDate = date;
        		weekDTO.CountDTO = new LeadsOpenedCountDTO();
        		weekDTO.CountDTO.FromDate = DateUtil.getCSDate(weekDTO.StartDate);
        		weekDTO.CountDTO.Date = DateUtil.getCSDate(weekDTO.EndDate);
        		leadOpenedWeekList.Add(weekDTO);
        		date = weekDTO.StartDate.AddDays(-1);
        	}
            leadOpenedWeekList.Sort((x, y) => DateTime.Compare(x.StartDate, y.StartDate));
        	return leadOpenedWeekList;
        }
        public object[] fetchEnquiryStatsForDashboard(long PropertyId, int noOfMonths)
        {
            ISession session = null;
            object[] result = new Object[4];
            List<EnquiryLeadSourceWiseCountDTO> enqSrcDistList = new List<EnquiryLeadSourceWiseCountDTO>();
            List<EnquiryNewOpenAndCloseWeekDTO> enqOpenClosedWeekList = createEnquiryOpenClosedStats(noOfMonths);
            List<EnquiryNewOpenAndCloseCountDTO> enqOpenClosedCountList = new List<EnquiryNewOpenAndCloseCountDTO>();
            List<EnquiryCurrentOpenCountDTO> enqCurrentOpenList = new List<EnquiryCurrentOpenCountDTO>();
            EnquiryCountStatsDTO enqCountStatsDTO = new EnquiryCountStatsDTO();
            
            result[0] = enqSrcDistList;
            result[1] = enqOpenClosedCountList;
            result[2] = enqCurrentOpenList;
            result[3] = enqCountStatsDTO;
            
            IList<EnquiryDetailDTO> tmpResultList = new List<EnquiryDetailDTO>();
            Dictionary<DateTime, int> statsForDailyOpen = new Dictionary<DateTime, int>();
            
            DateTime StartDate = enqOpenClosedWeekList[0].StartDate;
            DateTime EndDate = enqOpenClosedWeekList[enqOpenClosedWeekList.Count - 1].EndDate;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	EnquiryDetail ed = null;
                        MasterControlData es = null;
                        Property p = null;

                        EnquiryDetailDTO edDTO = null;
                        
                        var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => ed.EnquiryDate).WithAlias(() => edDTO.EnquiryDate))
                                .Add(Projections.Property(() => ed.DateClosed).WithAlias(() => edDTO.DateClosed))
                                .Add(Projections.Property(() => ed.Status).WithAlias(() => edDTO.Status))
                                .Add(Projections.Property(() => es.Name), "EnquirySource.Name");

                        var query = session.QueryOver<EnquiryDetail>(() => ed)
                                .Left.JoinAlias(() => ed.Property, () => p)
                                .Left.JoinAlias(() => ed.EnquirySource, () => es)
                                .Select(proj);
                       tmpResultList = query.Where(() => p.Id == PropertyId 
		                			&& ((ed.EnquiryDate >= StartDate && ed.EnquiryDate <= EndDate) 
		                					|| (ed.DateClosed >= StartDate && ed.DateClosed <= EndDate)))
		                		.TransformUsing(new DeepTransformer<EnquiryDetailDTO>())      
		                		.List<EnquiryDetailDTO>();
		                
		                foreach(EnquiryDetailDTO tmpDTO in tmpResultList) {
		                	//Create stats for new Enquiry Opened and Closed gadget
		                	if(tmpDTO.EnquiryDate.CompareTo(StartDate) >= 0 && tmpDTO.EnquiryDate.CompareTo(EndDate) <= 0) {
		                		enqCountStatsDTO.TotalLogged++;
		                		
		                		//Enquiry opened in week.
		                		EnquiryNewOpenAndCloseWeekDTO openAndClosedWeekDto = enqOpenClosedWeekList.Find(x => x.StartDate.CompareTo(tmpDTO.EnquiryDate) <= 0 
		                				&& x.EndDate.CompareTo(tmpDTO.EnquiryDate) >= 0);
		                		openAndClosedWeekDto.CountDTO.OpenCount++;
			                	
			                	//Source wise distribution.
			                	EnquiryLeadSourceWiseCountDTO srcCountDTO = enqSrcDistList.Find(x => x.SourceName == tmpDTO.EnquirySource.Name);
			                	if(srcCountDTO == null) {
			                		srcCountDTO = new EnquiryLeadSourceWiseCountDTO();
			                		srcCountDTO.SourceName = tmpDTO.EnquirySource.Name;
			                		enqSrcDistList.Add(srcCountDTO);
			                	}
			                	srcCountDTO.Count++;
			                	
			                	//Stats for Daily Open Enquiry
				                if(statsForDailyOpen.ContainsKey(tmpDTO.EnquiryDate)) {
				                	statsForDailyOpen[tmpDTO.EnquiryDate] += 1;
				                } else {
				                	statsForDailyOpen.Add(tmpDTO.EnquiryDate, 1);
				                }
		                	}
		                	if(tmpDTO.Status != EnquiryStatus.Open && tmpDTO.DateClosed.Value.CompareTo(StartDate) >= 0 && tmpDTO.DateClosed.Value.CompareTo(EndDate) <= 0) {
		                		enqCountStatsDTO.TotalClosed++;
		                		//Enquiry Closed in week.
		                		EnquiryNewOpenAndCloseWeekDTO openAndClosedWeekDto = enqOpenClosedWeekList.Find(x => x.StartDate.CompareTo(tmpDTO.DateClosed) <= 0 
		                				&& x.EndDate.CompareTo(tmpDTO.DateClosed) >= 0);
		                		openAndClosedWeekDto.CountDTO.CloseCount++;
		                		//Stats for Daily Open Enquiry
				                if(statsForDailyOpen.ContainsKey(tmpDTO.DateClosed.Value)) {
				                	statsForDailyOpen[tmpDTO.DateClosed.Value] -= 1;
				                } else {
				                	statsForDailyOpen.Add(tmpDTO.DateClosed.Value, -1);
				                }
		                	}
		                }

                        enqOpenClosedWeekList.Sort((x, y) => DateTime.Compare(x.StartDate, y.StartDate));
		                enqOpenClosedWeekList.ForEach(x => enqOpenClosedCountList.Add(x.CountDTO));
		                
		                //Create Stats for Daily Open Enquiry
		                int OpenEnquiry = session.QueryOver<EnquiryDetail>(() => ed)
                                .Left.JoinAlias(() => ed.Property, () => p)
                                .Left.JoinAlias(() => ed.EnquirySource, () => es)
                                .Where(() => p.Id == PropertyId && ed.EnquiryDate < StartDate && (ed.DateClosed == null || ed.DateClosed > StartDate)).RowCount();
		                DateTime tmpEnqDate = StartDate;
		                int openCount = OpenEnquiry;
		                do {
                            if (statsForDailyOpen.ContainsKey(tmpEnqDate))
                            {
                                openCount = openCount + statsForDailyOpen[tmpEnqDate];
                            }
		                	EnquiryCurrentOpenCountDTO tmpDto = new EnquiryCurrentOpenCountDTO();
                            tmpDto.Date = DateUtil.getCSDate(tmpEnqDate);
		                	tmpDto.OpenCount = openCount;
		                	enqCurrentOpenList.Add(tmpDto);
		                	tmpEnqDate = tmpEnqDate.AddDays(1);
		                }while(tmpEnqDate.CompareTo(EndDate) <= 0);
		                
		                //Total Open on period end date.
		                enqCountStatsDTO.TotalOpen = openCount;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching Enquiry Count Stats:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        
        private List<EnquiryNewOpenAndCloseWeekDTO> createEnquiryOpenClosedStats(int lastNoOfMonths) {
        	List<EnquiryNewOpenAndCloseWeekDTO> enqOpenClosedWeekList = new List<EnquiryNewOpenAndCloseWeekDTO>();
            int noOfWeeks = lastNoOfMonths * Constants.CRM_STATS_NO_OF_WEEKS;
        	DateTime date = DateTime.Today;
        	for(int i = 1; i <= noOfWeeks; i++) {
        		EnquiryNewOpenAndCloseWeekDTO weekDTO = new EnquiryNewOpenAndCloseWeekDTO();
        		weekDTO.StartDate = date.AddDays(-6);
        		weekDTO.EndDate = date;
        		weekDTO.CountDTO = new EnquiryNewOpenAndCloseCountDTO();
        		weekDTO.CountDTO.FromDate = DateUtil.getCSDate(weekDTO.StartDate);
        		weekDTO.CountDTO.Date = DateUtil.getCSDate(weekDTO.EndDate);
        		enqOpenClosedWeekList.Add(weekDTO);
        		date = weekDTO.StartDate.AddDays(-1);
        	}
            enqOpenClosedWeekList.Sort((x, y) => DateTime.Compare(x.StartDate, y.StartDate));
        	return enqOpenClosedWeekList;
        }
    }
}