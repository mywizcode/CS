﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;


/// <summary>
/// Summary description for PropertyAlertBO
/// </summary>
namespace ConstroSoft
{
    public class JobBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public JobBO() { }

        public IList<JobDTO> fetchJobs(string firmNumber)
        {
            ISession session = null;
            IList<JobDTO> result = new List<JobDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                Job job = null;
                JobDTO jobDto = null;
                var proj = Projections.ProjectionList()
                             .Add(Projections.Property(() => job.Id).WithAlias(() => jobDto.Id))
                             .Add(Projections.Property(() => job.JobName).WithAlias(() => jobDto.JobName))
                             .Add(Projections.Property(() => job.Description).WithAlias(() => jobDto.Description))
                             .Add(Projections.Property(() => job.JobIntervalType).WithAlias(() => jobDto.JobIntervalType));
                var query = session.QueryOver<Job>(() => job);
                result = query.Where(() => esc.FirmNumber == firmNumber && job.Status == JobStatus.ACTIVE)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<JobDTO>()).List<JobDTO>();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating Job Details:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }

    }
}