﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NHibernate;

namespace ConstroSoft.Logic.BO
{
    
    public class UserDefinationBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public UserDefinationBO() { }


        public void updateUserProfile(UserDefinitionDTO userdefinationDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        UserDefinition userDefination = session.Get<UserDefinition>(userdefinationDTO.Id);
                        DTOToDomainUtil.populateUserProfileUpdateFields(userDefination, userdefinationDTO);
                        session.Update(userDefination);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating Customer details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
    }
    
}