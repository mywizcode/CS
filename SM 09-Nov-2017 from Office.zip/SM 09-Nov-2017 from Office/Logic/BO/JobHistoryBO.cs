﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;


/// <summary>
/// Summary description for JobHistoryBO
/// </summary>
namespace ConstroSoft
{
    public class JobHistoryBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public JobHistoryBO() { }

        public void saveJobHistory(JobHistoryDTO jobHistoryDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        JobHistory jobHistory = DTOToDomainUtil.populateJobHistoryAddFields(jobHistoryDTO);
                        session.Save(jobHistory);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Job History details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        
        public void updatejobHistoryDetails(JobHistoryDTO jobHistoryDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        JobHistory jobHistory = session.Get<JobHistory>(jobHistoryDTO.Id);
                        DTOToDomainUtil.populateJobHistoryUpdateFields(jobHistory, jobHistoryDTO);
                        session.Update(jobHistory);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating Job History details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
       
    }
}