﻿using System;
using NHibernate;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using ConstroSoft;
using System.Collections.Generic;
using System.Globalization;

/// <summary>
/// Summary description for FBIntegrationBO
/// </summary>
namespace ConstroSoft
{
    public class FBIntegrationBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public FBIntegrationBO()
        {

            // TODO: Add constructor logic here
            //
        }
        public void saveFBuser(PortalUserDTO portalUserDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PortalUser portalUser = DTOToDomainUtil.populatePortalUserAddFields(portalUserDTO);
                        portalUser.Password = Encrypt(portalUser.Password);
                        session.Save(portalUser);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Adding User:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public BusinessOutputTO validateFBUser(PortalUserDTO portalUserDTO)
        {
            BusinessOutputTO businessTO = new BusinessOutputTO();
            ISession session = null;
            log.Debug("Validating user login");
            try
            {
                bool result = false;
                session = NHibertnateSession.OpenSession();
                string username = portalUserDTO.UserName;
                PortalUser portalUser = session.QueryOver<PortalUser>().Where(x => x.UserName == username).SingleOrDefault();
                if (portalUser != null)
                {
                    if (portalUserDTO.Password.Equals(Decrypt(portalUser.Password)))
                    {
                        log.Debug("Login Successful for user:" + portalUserDTO.UserName);
                        businessTO.result = getPortalUserDTO(portalUser);
                        result = true;
                    }
                }
                if (!result)
                {
                    log.Debug("Login Failed for user:" + portalUserDTO.UserName);
                    businessTO.setErrorMessage(Resources.Messages.LOGIN_ERROR_FAILED);
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while login:" + portalUserDTO.UserName);
                log.Error(exp.Message, exp);
                businessTO.setErrorMessage(Resources.Messages.system_error);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return businessTO;
        }
        public string checkUserExists(PortalUserDTO portalUserDTO)
        {
            ISession session = null;
            string result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                PortalUser fbUser = session.QueryOver<PortalUser>().Where(x => x.UserName == portalUserDTO.UserName).SingleOrDefault();
                if (fbUser != null)
                {
                    result = "User with same details already exists.";
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while registering:" + portalUserDTO.UserName);
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }

        public string checkFirmExists(PortalUserDTO portalUserDTO)
        {
            ISession session = null;
            string result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                Firm firm = session.QueryOver<Firm>().Where(x => x.FirmNumber == portalUserDTO.FirmNumber).SingleOrDefault();
                if (firm == null)
                {
                    result = "Firm with " + portalUserDTO.FirmNumber + " does not exist into system.";
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while registering:" + portalUserDTO.UserName);
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        private PortalUserDTO getPortalUserDTO(PortalUser portalUser)
        {
            PortalUserDTO portalUserDTO = new PortalUserDTO();
            portalUserDTO.UserName = portalUser.UserName;
            portalUserDTO.Password = portalUser.Password;
            portalUserDTO.Email = portalUser.Email;
            portalUserDTO.FirmNumber = portalUser.FirmNumber;
            portalUserDTO.Id = portalUser.Id;
            return portalUserDTO;
        }
        private string Encrypt(string clearText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    clearText = Convert.ToBase64String(ms.ToArray());
                }
            }
            return clearText;
        }
        private string Decrypt(string cipherText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }
        public string validateMandatoryFields(PortalUserDTO portalUserDTO)
        {
            string errorMessage = null;
            if (portalUserDTO.UserName == null)
            {
                errorMessage = "Please enter value for User Name. ";
            }
            if (portalUserDTO.Password == null)
            {
                errorMessage += "Please enter value for Password. ";
            }
            if (portalUserDTO.Email == null)
            {
                errorMessage += "Please enter value for Email. ";
            }
            if (portalUserDTO.FirmNumber == null)
            {
                errorMessage += "Please enter value for Firm Number";
            }
            return errorMessage;
        }
        public string validateLoginUser(PortalUserDTO portalUserDTO)
        {
            string errorMessage = null;
            if (portalUserDTO.UserName == null)
            {
                errorMessage = "Please enter value for User Name. ";
            }
            if (portalUserDTO.Password == null)
            {
                errorMessage += "Please enter value for Password. ";
            }
            return errorMessage;
        }

        public string saveFBToken(PortalUserDTO portalUserDTO)
        {
            ISession session = null;
            string token = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        token = GetUniqueKey(100);
                        PortalTokenManager portalTokenManager = populatePortalTokenManager(portalUserDTO, token);
                        session.Save(portalTokenManager);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while generating token:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return token;
        }

        public static string GetUniqueKey(int maxSize = 15)
        {
            char[] chars = new char[62];
            chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890".ToCharArray();
            byte[] data = new byte[1];
            using (RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider())
            {
                crypto.GetNonZeroBytes(data);
                data = new byte[maxSize];
                crypto.GetNonZeroBytes(data);
            }
            StringBuilder result = new StringBuilder(maxSize);
            foreach (byte b in data)
            {
                result.Append(chars[b % (chars.Length)]);
            }
            return result.ToString();
        }

        public static PortalTokenManager populatePortalTokenManager(PortalUserDTO portalUserDTO, string token)
        {
            PortalTokenManager portalTokenManager = new PortalTokenManager();
            portalTokenManager.TokenKey = token;
            portalTokenManager.IssuedOn = DateTime.Now;
            portalTokenManager.ExpiresOn = DateTime.Now.AddMinutes(25);
            portalTokenManager.FirmNumber = portalUserDTO.FirmNumber;
            portalTokenManager.PortalUser = new PortalUser();
            portalTokenManager.PortalUser.Id = portalUserDTO.Id;
            portalTokenManager.InsertDate = DateTime.Now;
            portalTokenManager.InsertUser = portalUserDTO.UserName;
            portalTokenManager.UpdateDate = DateTime.Now;
            portalTokenManager.UpdateUser = portalUserDTO.UserName;
            return portalTokenManager;
        }
        public string validateLeadFields(LeadDetailDTO leadDetailDTO)
        {
            string errorMessage = null;
            errorMessage = validateLeadMandatoryFields(leadDetailDTO);
            if (errorMessage == null)
            {
                errorMessage = validateProperty(leadDetailDTO);
            }
            return errorMessage;
        }
        public string validateProperty(LeadDetailDTO leadDetailDTO)
        {
            ISession session = null;
            string errorMessage = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                Property property = session.QueryOver<Property>().Where(x => x.Name == leadDetailDTO.PropertyName).SingleOrDefault();
                if (property == null)
                {
                    errorMessage = "Property with " + leadDetailDTO.PropertyName + " does not exist into system.";
                }
                else
                {
                    leadDetailDTO.Property = new PropertyDTO();
                    leadDetailDTO.Property.Id = property.Id;

                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while validating property:" + leadDetailDTO.PropertyName);
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return errorMessage;
        }
        public string validateLeadMandatoryFields(LeadDetailDTO leadDetailDTO)
        {
            string errorMessage = null;
            if (leadDetailDTO.FirstName == null)
            {
                errorMessage = "Please enter value for First Name. ";
            }
            if (leadDetailDTO.LastName == null)
            {
                errorMessage += "Please enter value for Last Name. ";
            }
            if (leadDetailDTO.Contact == null)
            {
                errorMessage += "Please enter value for Contact. ";
            }
            if (leadDetailDTO.Email == null)
            {
                errorMessage += "Please enter value for Email. ";
            }
            if (leadDetailDTO.Budget == null)
            {
                errorMessage += "Please enter value for Budget. ";
            }
            if (leadDetailDTO.LeadDate == null)
            {
                errorMessage += "Please enter value for Enquiry Date. ";
            }
            if (leadDetailDTO.PropertyName == null)
            {
                errorMessage += "Please enter value for Property Name. ";
            }
            if (leadDetailDTO.TokenNumber == null)
            {
                errorMessage += "Please enter value for Token Number. ";
            }
            return errorMessage;
        }
        public bool checkTokenValidity(LeadDetailDTO leadDetailDto)
        {
            ISession session = null;
            PortalTokenManager portalTokenManager = null;
            bool valid = false;
            try
            {
                session = NHibertnateSession.OpenSession();
                portalTokenManager = session.QueryOver<PortalTokenManager>().Where(x => x.TokenKey == leadDetailDto.TokenNumber && DateTime.Now < x.ExpiresOn).SingleOrDefault();
                if (portalTokenManager != null)
                {
                    valid = true;
                    leadDetailDto.FirmNumber = portalTokenManager.FirmNumber;
                    leadDetailDto.InsertUser = portalTokenManager.InsertUser;
                    leadDetailDto.UpdateUser = portalTokenManager.UpdateUser;
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while validating token:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return valid;
        }
        public void savePortalLead(LeadDetailDTO leadDetailDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                long Id = -1;
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        LeadDetail leadDetail = populatePortalLead(leadDetailDTO);
                        Random rd = new Random();
                        leadDetail.LeadRefNo = "LEAD" + rd.Next(100, 10000);
                        session.Save(leadDetail);
                        Id = leadDetail.Id;
                        leadDetail.LeadRefNo = "LEAD" + Id;
                        session.Update(leadDetail);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while generating lead:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }

        }
        public static LeadDetail populatePortalLead(LeadDetailDTO leadDetailDTO)
        {
            LeadDetail leadDetail = new LeadDetail();
            leadDetail.FirstName = leadDetailDTO.FirstName;
            leadDetail.LastName = leadDetailDTO.LastName;
            leadDetail.LeadDate = leadDetailDTO.LeadDate;
            leadDetail.Budget = leadDetailDTO.Budget;
            leadDetail.ContactInfo = new ContactInfo();
            leadDetail.ContactInfo.Contact= leadDetailDTO.Contact;
            leadDetail.ContactInfo.Email = leadDetailDTO.Email;
            leadDetail.Property = new Property();
            leadDetail.Property.Id = leadDetailDTO.Property.Id;
            MasterDataBO MasterDataBO = new MasterDataBO();
            leadDetailDTO.Source = MasterDataBO.getMasterDataType(leadDetailDTO.FirmNumber, Constants.MCDType.ENQUIRY_SOURCE, "Social Media Advertise");
            leadDetail.Source = DTOToDomainUtil.copyMasterControlId(leadDetail.Source, leadDetailDTO.Source);
            leadDetail.FirmNumber = leadDetailDTO.FirmNumber;
            leadDetail.InsertDate = DateTime.Now;
            leadDetail.InsertUser = leadDetailDTO.InsertUser;
            leadDetail.UpdateDate = DateTime.Now;
            leadDetail.UpdateUser = leadDetailDTO.UpdateUser;
            leadDetailDTO.Salutation = MasterDataBO.getMasterDataType(leadDetailDTO.FirmNumber, Constants.MCDType.SALUTATION, leadDetailDTO.Salutationstr);
            leadDetail.Salutation = DTOToDomainUtil.copyMasterControlId(leadDetail.Salutation, leadDetailDTO.Salutation);
            return leadDetail;
        }

    }
}