﻿using System;
using System.Web.UI.WebControls;
using ConstroSoft;

public partial class ForgotPassword : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
          log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    private string forgotPasswordErrorGrp = "forgotPasswordErrorGrp";
    private string resetPasswordErrorGrp = "resetPasswordGrp";
    private string passwordRecoveryErrorGrp = "passwordRecoveryGrp";
    private string USERDEFINITION = "USERDEFINITION";
    LoginBO loginBO = new LoginBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Session[Constants.Session.USERNAME] = "";
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        initBootstrapComponantsFromServer();
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
    }
    public void initBootstrapComponantsFromServer()
    {

    }

    protected void validateUserOnForgotPassword(object sender, EventArgs e)
    {
        try
        {
            BusinessOutputTO outputTO = loginBO.getUserDefinition(txtUserName.Text);
            if (outputTO.status == BusinessOutputTO.Status.SUCCESS)
            {
                UserDefinitionDTO userDefDto = (UserDefinitionDTO)outputTO.result;
                ViewState[USERDEFINITION] = userDefDto;
                lbSecurityQuestion.Text = userDefDto.SecurityQuestion.Question;
                pnlForgotPassword.Visible = false;
                pnlPasswordRecovery.Visible = true;
                pnlResetPassword.Visible = false;
            }
            else
            {
                setErrorMessage(outputTO.errorMessage, forgotPasswordErrorGrp);
            }
        }
        catch (Exception ex)
        {
            log.Error("Unexpected error:", ex);
            setErrorMessage(Resources.Messages.system_error, forgotPasswordErrorGrp);
        }
    }
    protected void submitSecurityQuestions(object sender, EventArgs e)
    {
        try
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)ViewState[USERDEFINITION];
            if (validateSecurityQuestion())
            {
                pnlForgotPassword.Visible = false;
                pnlPasswordRecovery.Visible = false;
                pnlResetPassword.Visible = true;
            }
        }
        catch (Exception ex)
        {
            log.Error("Unexpected error:", ex);
            setErrorMessage(Resources.Messages.system_error, passwordRecoveryErrorGrp);
        }
    }
    private bool validateSecurityQuestion()
    {
        Page.Validate(passwordRecoveryErrorGrp);
        bool result = Page.IsValid;
        if (result)
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)ViewState[USERDEFINITION];
            DateTime dob = DateUtil.getCSDateNotNull(txtDOB.Text);
            if (!(txtSecurityAnswer.Text.Equals(userDefDto.SecurityAnswer) && dob.CompareTo(userDefDto.FirmMember.ContactInfo.Dob) == 0))
            {
                result = false;
                setErrorMessage("Incorrect Security Answer or Date of Birth", passwordRecoveryErrorGrp);
            }
        }
        return result;
    }
    protected void resetPassword(object sender, EventArgs e)
    {
        try
        {
            if (validateResetPassword())
            {
                UserDefinitionDTO userDefDto = (UserDefinitionDTO)ViewState[USERDEFINITION];
                loginBO.resetPassword(userDefDto.Username, txtNewPassword.Text);
                Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg("Password is reset successfully."));
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        catch (Exception ex)
        {
            log.Error("Unexpected error:", ex);
            Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotyErrorMsg(CommonUtil.getErrorMessage(ex)));
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private bool validateResetPassword()
    {
        Page.Validate(resetPasswordErrorGrp);
        bool result = Page.IsValid;
        if (result)
        {
            if (!txtNewPassword.Text.Equals(txtConfirmPassword.Text.Trim()))
            {
                result = false;
                setErrorMessage("New Password and Confirm Password does not match", resetPasswordErrorGrp);
            }
        }
        return result;
    }
}