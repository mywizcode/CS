﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;


/// <summary>
/// Summary description for CallHistoryBO
/// </summary>
namespace ConstroSoft
{
    public class CallHistoryBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public CallHistoryBO() { }
        public List<UnresolvedCallGroupInfoDTO> fetchUnresolvedCallsGridData(UserDefinitionDTO userDefDTO, UnresolvedCallsFilterDTO filterDTO)
        {
            ISession session = null;
            List<UnresolvedCallGroupInfoDTO> results = new List<UnresolvedCallGroupInfoDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	CallHistory ch = null;
                        FirmMember fm = null;
                        
                        CallHistoryDTO chDto = null;
                        IList<CallHistoryDTO> tmpResult = null;
                        var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => ch.Id).WithAlias(() => chDto.Id))
                                .Add(Projections.Property(() => ch.CallerNumber).WithAlias(() => chDto.CallerNumber))
                                .Add(Projections.Property(() => ch.CalleeNumber).WithAlias(() => chDto.CalleeNumber))
                                .Add(Projections.Property(() => ch.CallStatus).WithAlias(() => chDto.CallStatus))
                                .Add(Projections.Property(() => ch.CallHistoryStatus).WithAlias(() => chDto.CallHistoryStatus))
                                .Add(Projections.Property(() => ch.StartTime).WithAlias(() => chDto.StartTime))
                                .Add(Projections.Property(() => ch.RecordingUrl).WithAlias(() => chDto.RecordingUrl))
                                .Add(Projections.Property(() => ch.Direction).WithAlias(() => chDto.Direction));
        	            var query = session.QueryOver<CallHistory>(() => ch)
        	                .Inner.JoinAlias(() => ch.FirmMember, () => fm);
                        
        	            ICriteria criteria = query.RootCriteria;
        	            if(filterDTO == null || !filterDTO.IsAllUnresolvedCalls) {
        	            	criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<FirmMember>(() => fm, x => x.Id), userDefDTO.FirmMember.Id));
        	            }
        	            if (filterDTO != null)
                        {
                            if (!string.IsNullOrWhiteSpace(filterDTO.CustomerNumber))
                            {
                                criteria.Add(
                                	Expression.Disjunction()
                                		.Add(Expression.Conjunction()
        	                        			.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.CallerNumber), filterDTO.CustomerNumber))
        	                        			.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.Direction), CallDirection.Incoming)))
        	                        	.Add(Expression.Conjunction()
        	                        			.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.CalleeNumber), filterDTO.CustomerNumber))
        	                        			.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.Direction), CallDirection.Outgoing)))
                                	);
                            }
                        }
        	            
        	            tmpResult = query.Where(() => ch.CallHistoryStatus == CallHistoryStatus.Unresolved)
        	                    .Select(proj)
        	                    .TransformUsing(new DeepTransformer<CallHistoryDTO>()).List<CallHistoryDTO>();
        	            if(tmpResult != null) {
        	            	foreach(CallHistoryDTO tmpDTO in tmpResult){
                                string customerNumber = (tmpDTO.Direction == CallDirection.Incoming) ? tmpDTO.CallerNumber : tmpDTO.CalleeNumber;
        	            		UnresolvedCallGroupInfoDTO tmpGrpDTO = results.Find(x => x.CustomerNumber == customerNumber);
        	            		if(tmpGrpDTO == null) {
        	            			tmpGrpDTO = new UnresolvedCallGroupInfoDTO();
        	            			tmpGrpDTO.CustomerNumber = customerNumber;
                                    tmpGrpDTO.RecordingUrl = tmpDTO.RecordingUrl;
                                    tmpGrpDTO.Id =Convert.ToInt32(tmpDTO.Id);
                                    tmpGrpDTO.LastDiscussionOn = tmpDTO.StartTime;
        	            			results.Add(tmpGrpDTO);
        	            		}
                                if (tmpDTO.Direction == CallDirection.Incoming) tmpGrpDTO.IncomingCallCount++;
        	            		else tmpGrpDTO.OutgoingCallCount++;
                                if (tmpGrpDTO.LastDiscussionOn.CompareTo(tmpDTO.StartTime) < 0) tmpGrpDTO.LastDiscussionOn = tmpDTO.StartTime;
        	            		//If any of the call history for this number is in progress then show status as in progress.
        	            		if(tmpDTO.CallStatus == CallStatus.Inprogress) tmpGrpDTO.CallStatus = CallStatus.Inprogress;
        	            		else if(tmpGrpDTO.CallStatus != CallStatus.Inprogress) tmpGrpDTO.CallStatus = tmpDTO.CallStatus;
        	                }
                            results.Sort((x, y) => x.LastDiscussionOn.CompareTo(y.LastDiscussionOn));
        	            }
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while Loading Unresolved calls grid:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }
        public IList<CallHistoryDTO> fetchUnresolvedCallsForNumber(string customerNumber)
        {
            ISession session = null;
            IList<CallHistoryDTO> results = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        CallHistory ch = null;
                        FirmMember fm = null;
                        MasterControlData salutation = null;

                        CallHistoryDTO chDto = null;
                        var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => ch.Id).WithAlias(() => chDto.Id))
                                .Add(Projections.Property(() => ch.CallerNumber).WithAlias(() => chDto.CallerNumber))
                                .Add(Projections.Property(() => ch.CalleeNumber).WithAlias(() => chDto.CalleeNumber))
                                .Add(Projections.Property(() => ch.CallStatus).WithAlias(() => chDto.CallStatus))
                                .Add(Projections.Property(() => ch.CallHistoryStatus).WithAlias(() => chDto.CallHistoryStatus))
                                .Add(Projections.Property(() => ch.StartTime).WithAlias(() => chDto.StartTime))
                                .Add(Projections.Property(() => ch.Direction).WithAlias(() => chDto.Direction))
                                .Add(Projections.Property(() => salutation.Name), "FirmMember.Salutation.Name")
                                .Add(Projections.Property(() => fm.FirstName), "FirmMember.FirstName")
                                .Add(Projections.Property(() => fm.LastName), "FirmMember.LastName");
                        var query = session.QueryOver<CallHistory>(() => ch)
                            .Inner.JoinAlias(() => ch.FirmMember, () => fm)
                            .Inner.JoinAlias(() => ch.FirmMember.Salutation, () => salutation);

                        ICriteria criteria = query.RootCriteria;
                        criteria.Add(
                                    Expression.Disjunction()
                                        .Add(Expression.Conjunction()
                                                .Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.CallerNumber), customerNumber))
                                                .Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.Direction), CallDirection.Incoming)))
                                        .Add(Expression.Conjunction()
                                                .Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.CalleeNumber), customerNumber))
                                                .Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.Direction), CallDirection.Outgoing)))
                                    );

                        results = query.Where(() => ch.CallHistoryStatus == CallHistoryStatus.Unresolved)
                                .Select(proj)
                                .OrderBy(() => ch.StartTime).Desc()
                                .TransformUsing(new DeepTransformer<CallHistoryDTO>()).List<CallHistoryDTO>();
                        results.ToList<CallHistoryDTO>().ForEach(x => x.FirmMember.FullName = CommonUIConverter.getCustomerFullName(x.FirmMember.Salutation.Name,
                            x.FirmMember.FirstName, x.FirmMember.LastName));
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching unresolved calls for given customer number:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }
		public IList<CallHistoryDTO> fetchCallHistoryGridData(long propertyId, CallHistoryFilterDTO filterDTO)
        {
            ISession session = null;
            IList<CallHistoryDTO> results = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	CallHistory ch = null;
                    	Property p = null;
                        FirmMember fm = null;
                        MasterControlData sal = null;
                        
                        CallHistoryDTO chDto = null;
                        IList<CallHistoryDTO> tmpResult = null;
                        var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => ch.Id).WithAlias(() => chDto.Id))
                                .Add(Projections.Property(() => ch.CallerNumber).WithAlias(() => chDto.CallerNumber))
                                .Add(Projections.Property(() => ch.CalleeNumber).WithAlias(() => chDto.CalleeNumber))
                                .Add(Projections.Property(() => ch.CallStatus).WithAlias(() => chDto.CallStatus))
                                .Add(Projections.Property(() => ch.CallHistoryStatus).WithAlias(() => chDto.CallHistoryStatus))
                                .Add(Projections.Property(() => ch.StartTime).WithAlias(() => chDto.StartTime))
                                .Add(Projections.Property(() => ch.Direction).WithAlias(() => chDto.Direction))
                                .Add(Projections.Property(() => sal.Name), "FirmMember.Salutation.Name")
                                .Add(Projections.Property(() => fm.Id), "FirmMember.Id")
	                            .Add(Projections.Property(() => fm.FirstName), "FirmMember.FirstName")
	                            .Add(Projections.Property(() => fm.LastName), "FirmMember.LastName");
        	            var query = session.QueryOver<CallHistory>(() => ch)
        	            		//.Inner.JoinAlias(() => ch.Property, () => p)
	        	                .Inner.JoinAlias(() => ch.FirmMember, () => fm)
	        	                .Inner.JoinAlias(() => fm.Salutation, () => sal);
                        
        	            if (filterDTO != null)
                        {
        	            	ICriteria criteria = query.RootCriteria;
        	            	if(filterDTO.IsIncoming && !filterDTO.IsOutgoing) {
            	            	criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.Direction), CallDirection.Incoming));
            	            }
        	            	if(!filterDTO.IsIncoming && filterDTO.IsOutgoing) {
            	            	criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.Direction), CallDirection.Outgoing));
            	            }
                            if (!string.IsNullOrWhiteSpace(filterDTO.CustomerNumber))
                            {
                                criteria.Add(
                                	Expression.Disjunction()
                                		.Add(Expression.Conjunction()
        	                        			.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.CallerNumber), filterDTO.CustomerNumber))
        	                        			.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.Direction), CallDirection.Incoming)))
        	                        	.Add(Expression.Conjunction()
        	                        			.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.CalleeNumber), filterDTO.CustomerNumber))
        	                        			.Add(Restrictions.Eq(CommonUtil.BuildProjection<CallHistory>(() => ch, x => x.Direction), CallDirection.Outgoing)))
                                	);
                            }
                        }
        	            
        	            results = query//.Where(() => p.Id == propertyId)
        	                    .Select(proj)
                                .OrderBy(() => ch.StartTime).Desc()
        	                    .TransformUsing(new DeepTransformer<CallHistoryDTO>()).List<CallHistoryDTO>();
                        results.ToList<CallHistoryDTO>().ForEach(x => x.FirmMember.FullName = CommonUIConverter.getCustomerFullName(x.FirmMember.Salutation.Name, 
                            x.FirmMember.FirstName, x.FirmMember.LastName));
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while Loading Call History given Property:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }
        public IList<CallHistoryDTO> fetchCallHistory(string firmNumber)
        {
            ISession session = null;
            IList<CallHistoryDTO> results = new List<CallHistoryDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                CallHistory ch = null;
                var query = session.QueryOver<CallHistory>(() => ch);

                IList<CallHistory> calls = query.Where(() => ch.FirmNumber == firmNumber
                    && ch.Direction == CallDirection.Incoming && ch.RecordingFile == null).List<CallHistory>();
                foreach (CallHistory call in calls)
                {
                    results.Add(DomainToDTOUtil.convertToCallHistoryDTO(call, true));
                }
                results.ToList();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating call details:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }

        public long addCallHistory(CallHistoryDTO callHistoryDTO)
        {
            ISession session = null;
            long Id = 0;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        CallHistory callHistory = DTOToDomainUtil.populateCallHistoryAddFields(callHistoryDTO);
                        session.Save(callHistory);
                        Id = callHistory.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while adding Call History:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        public long updateCallHistory(CallHistoryDTO callHistoryDTO)
        {
            ISession session = null;
            long Id = 0;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        CallHistory callHistory = null;
                        var query = session.QueryOver<CallHistory>(() => callHistory);
                        callHistory = query.Where(x => x.CallSid == callHistoryDTO.CallSid).SingleOrDefault();
                        DTOToDomainUtil.populateCallHistoryUpdateFields(callHistory, callHistoryDTO);
                        session.Update(callHistory);
                        Id = callHistory.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating Call History details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        public CallHistoryDTO fetchCallHistoryforCallSID(string CallSid)
        {
            ISession session = null;
            CallHistoryDTO callHistoryDTO = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                CallHistory ch = null;
                var query = session.QueryOver<CallHistory>(() => ch);
                ch = query.Where(() => ch.CallSid == CallSid).SingleOrDefault<CallHistory>();
                callHistoryDTO = DomainToDTOUtil.convertToCallHistoryDTO(ch, true);
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating call details:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return callHistoryDTO;
        }
        public FirmMemberDTO fetchAgent(string Contact)
        {
            ISession session = null;
            FirmMemberDTO firmMemberDTO = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                FirmMember fm = null;
                ContactInfo ContactInfo = null;
                UserDefinition UserDefinition = null;
                var query = session.QueryOver<FirmMember>(() => fm)
                    .Inner.JoinAlias(() => fm.ContactInfo, () => ContactInfo)
                    .Inner.JoinAlias(() => fm.User, () => UserDefinition);
                fm = query.Where(() => ContactInfo.Contact == Contact).SingleOrDefault<FirmMember>();
                firmMemberDTO = DomainToDTOUtil.convertToFirmMemberDTO(fm, true);
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating firm Member details:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return firmMemberDTO;
        }
        public long updateCallHistoryForIntimation(CallHistoryDTO callHistoryDTO)
        {
            ISession session = null;
            long Id = 0;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        CallHistory callHistory = null;
                        var query = session.QueryOver<CallHistory>(() => callHistory);
                        callHistory = query.Where(x => x.CallSid == callHistoryDTO.CallSid).SingleOrDefault();
                        DTOToDomainUtil.populateCallHistoryUpdateFieldsForInitimation(callHistory, callHistoryDTO);
                        session.Update(callHistory);
                        Id = callHistory.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating Call History details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        public CallHistoryDTO fetchCallDetails(long Id)
        {
            ISession session = null;
            CallHistoryDTO callHistoryDTO = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        CallHistory callHistory = session.Get<CallHistory>(Id);
                        callHistoryDTO = DomainToDTOUtil.convertToCallHistoryDTO(callHistory, true);

                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Call details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return callHistoryDTO;
        }
    }   
}