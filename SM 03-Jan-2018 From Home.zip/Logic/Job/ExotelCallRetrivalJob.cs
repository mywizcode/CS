﻿using ConstroSoft.Logic.CachingProvider;
using ConstroSoft.TelephonyProvider.ExotelProvider;
using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Caching;

namespace ConstroSoft.Logic.Job
{
    public class ExotelCallRetrivalJob : IJob
    {
        private static readonly log4net.ILog log =
                log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        JobHistoryBO jobHistoryBO = new JobHistoryBO();
        CallHistoryBO callHistoryBO = new CallHistoryBO();
        ExotelClient exotelClient = new ExotelClient();
        
        public void Execute(IJobExecutionContext context)
        {
            JobHistoryDTO jobHistoryDTO = new JobHistoryDTO();
            string message = null;
            try{
                var schedulerContext = context.Scheduler.Context;
                JobDTO jobDTO = (JobDTO)schedulerContext.Get(Constants.EXOTEL_CALL_JOB);
                populateJobHistoryAddDto(jobHistoryDTO, jobDTO);
                long Id =jobHistoryBO.saveJobHistory(jobHistoryDTO);
                jobHistoryDTO.Id = Id;
                //Fetch all the incoming calls for which Direction is INBOUND and Call Status is INPROGRESS.
                IList<CallHistoryDTO> calls = callHistoryBO.fetchCallHistory(jobDTO.FirmNumber);
                //Iterate over each call & invoke ExotelClient.getCallDetails
                //If Call Status is COMPLETED, FAILED, BUSY then update call history.
                foreach (CallHistoryDTO call in calls) {
                    InOutBoundCallResDTO outBoundCallResDTO = exotelClient.getCallDetails(call.CallSid);
                    if(outBoundCallResDTO.Call.Status != "inprogress")
                    {
                        bool incoming = false;
                        if (call.Direction == CallDirection.Incoming)
                        { 
                            incoming = true;
                        }
                        DTOToDomainUtil.populateCallHistoryDTOFromExotelCall(outBoundCallResDTO.Call, call, incoming);
                        callHistoryBO.updateCallHistory(call);
                    }
                }
               
            }catch (Exception exp)
            {
                message = exp.Message;
                log.Error(exp.Message, exp);
            }finally{
                populateJobHistoryUpdateDto(jobHistoryDTO, message);
                jobHistoryBO.updatejobHistoryDetails(jobHistoryDTO);
            }
           
        }

        private void populateJobHistoryAddDto(JobHistoryDTO jobHistoryDTO, JobDTO jobDTO)
        {
            jobHistoryDTO.StartTime = DateTime.Now;
            jobHistoryDTO.EndTime = DateTime.Now;
            jobHistoryDTO.JobRunStatus = JobRunStatus.INPROGRESS;
            jobHistoryDTO.Job = jobDTO;
            jobHistoryDTO.FirmNumber = jobDTO.FirmNumber;
            jobHistoryDTO.Message = "Job execution Started.";
            jobHistoryDTO.Version = 0;
            jobHistoryDTO.InsertUser = jobDTO.InsertUser;
            jobHistoryDTO.UpdateUser = jobDTO.UpdateUser;
            jobHistoryDTO.InsertDate = DateTime.Now;
            jobHistoryDTO.UpdateDate = DateTime.Now;
        }

        private void populateJobHistoryUpdateDto(JobHistoryDTO jobHistoryDTO, string message)
        {
            jobHistoryDTO.EndTime = DateTime.Now;
            if (message != null)
            {
                jobHistoryDTO.JobRunStatus = JobRunStatus.FAILURE;
                jobHistoryDTO.Message = message;
            }
            else
            {
                jobHistoryDTO.JobRunStatus = JobRunStatus.SUCCESS;
                jobHistoryDTO.Message = "Job execution completed successfully.";
            }
            jobHistoryDTO.EndTime = DateTime.Now;
            jobHistoryDTO.UpdateDate = DateTime.Now;
        }

    }

}