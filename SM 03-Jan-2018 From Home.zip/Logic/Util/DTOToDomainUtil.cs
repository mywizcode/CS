﻿
/// <summary>
/// Summary description for CommonUtil
/// </summary>
using ConstroSoft;
using System.Collections.Generic;
using System;
using System.Linq;
namespace ConstroSoft
{
    public class DTOToDomainUtil
    {
        public DTOToDomainUtil() { }

        public static void copyToAddress(Address address, AddressDTO addressDto)
        {
            address.AddressLine1 = addressDto.AddressLine1;
            address.AddressLine2 = addressDto.AddressLine2;
            address.Town = addressDto.Town;
            address.City = DTOToDomainUtil.copyCityId(address.City, addressDto.City);
            address.State = DTOToDomainUtil.copyStateId(address.State, addressDto.State);
            address.Country = DTOToDomainUtil.copyCountryId(address.Country, addressDto.Country);
            address.Pin = addressDto.Pin;
            address.AddressType = DTOToDomainUtil.copyMasterControlId(address.AddressType, addressDto.AddressType);
            address.PreferredAddress = addressDto.PreferredAddress;
        }
        public static UserRole copyToUserRole(UserRoleDTO userRoleDTO)
        {
            UserRole userRole = new UserRole();
            userRole.Id = userRoleDTO.Id;
            userRole.Name = userRoleDTO.Name;
            userRole.Description = userRoleDTO.Description;
            return userRole;
        }
        public static void copyToContactInfo(ContactInfo contactInfo, ContactInfoDTO contactInfoDto)
        {
            contactInfo.Contact = contactInfoDto.Contact;
            contactInfo.AltContact = contactInfoDto.AltContact;
            contactInfo.Email = contactInfoDto.Email;
            contactInfo.AltEmail = contactInfoDto.AltEmail;
            contactInfo.Gender = contactInfoDto.Gender;
            contactInfo.MaritalStatus = contactInfoDto.MaritalStatus;
            contactInfo.Dob = contactInfoDto.Dob;
            if (contactInfoDto.Addresses != null)
            {
                ISet<Address> addresses = contactInfo.Addresses;
                ISet<AddressDTO> addressDtos = contactInfoDto.Addresses;
                for (int i = 0; i < addresses.Count; i++)
                {
                    Address address = addresses.ElementAt(i);
                    AddressDTO addressDto = addressDtos.FirstOrDefault(x => x.Id == address.Id);
                    if (addressDto == null)
                    {
                        addresses.Remove(address);
                        i--;
                    }
                    else
                    {
                        DTOToDomainUtil.copyToAddress(address, addressDto);
                    }
                }
                foreach (AddressDTO addressDto in addressDtos)
                {
                    if (addressDto.Id < 1)
                    {
                        Address newAddress = new Address();
                        DTOToDomainUtil.copyToAddress(newAddress, addressDto);
                        newAddress.ContactInfo = contactInfo;
                        contactInfo.Addresses.Add(newAddress);
                    }
                }
            }
            else
            {
                contactInfo.Addresses.Clear();
            }
        }
        public static MasterControlData copyMasterControlId(MasterControlData masterControlData, MasterControlDataDTO masterControlDataDto)
        {
            MasterControlData tmpMasterControlData = masterControlData;
            if (masterControlDataDto == null) tmpMasterControlData = null;
            else if (masterControlData == null || (masterControlData.Id != masterControlDataDto.Id))
            {
                tmpMasterControlData = new MasterControlData();
                tmpMasterControlData.Id = masterControlDataDto.Id;
            }
            return tmpMasterControlData;
        }
        public static Firm copyFirmId(Firm firm, FirmDTO firmDto)
        {
            Firm tmpFirm = firm;
            if (firmDto == null) tmpFirm = null;
            else if (firm == null || (firm.Id != firmDto.Id))
            {
                tmpFirm = new Firm();
                tmpFirm.Id = firmDto.Id;
            }
            return tmpFirm;
        }
        public static Country copyCountryId(Country country, CountryDTO countryDto)
        {
            Country tmpCountry = country;
            if (countryDto == null) tmpCountry = null;
            else if (country == null || (country.Id != countryDto.Id))
            {
                tmpCountry = new Country();
                tmpCountry.Id = countryDto.Id;
            }
            return tmpCountry;
        }
        public static State copyStateId(State state, StateDTO stateDto)
        {
            State tmpState = state;
            if (stateDto == null) tmpState = null;
            else if (state == null || (state.Id != stateDto.Id))
            {
                tmpState = new State();
                tmpState.Id = stateDto.Id;
            }
            return tmpState;
        }
        public static City copyCityId(City city, CityDTO cityDto)
        {
            City tmpCity = city;
            if (cityDto == null) tmpCity = null;
            else if (city == null || (city.Id != cityDto.Id))
            {
                tmpCity = new City();
                tmpCity.Id = cityDto.Id;
            }
            return tmpCity;
        }
        public static Property copyPropertyId(Property property, PropertyDTO propertyDto)
        {
            Property tmpProperty = property;
            if (propertyDto == null) tmpProperty = null;
            else if (property == null || (property.Id != propertyDto.Id))
            {
                tmpProperty = new Property();
                tmpProperty.Id = propertyDto.Id;
            }
            return tmpProperty;
        }
        public static Agency copyAgencyId(Agency agency, AgencyDTO agencyDto)
        {
            Agency tmpAgency = agency;
            if (agencyDto == null) tmpAgency = null;
            else if (agency == null || (agency.Id != agencyDto.Id))
            {
                tmpAgency = new Agency();
                tmpAgency.Id = agencyDto.Id;
            }
            return tmpAgency;
        }
        public static PropertyTower copyPropertyTowerId(PropertyTower propertyTower, PropertyTowerDTO propertyTowerDto)
        {
            PropertyTower tmpPropertyTower = propertyTower;
            if (propertyTowerDto == null) tmpPropertyTower = null;
            else if (propertyTower == null || (propertyTower.Id != propertyTowerDto.Id))
            {
                tmpPropertyTower = new PropertyTower();
                tmpPropertyTower.Id = propertyTowerDto.Id;
            }
            return tmpPropertyTower;
        }
        public static FirmMember copyFirmMemberId(FirmMember firmMember, FirmMemberDTO firmMemberDto)
        {
            FirmMember tmpFirmMember = firmMember;
            if (firmMemberDto == null) tmpFirmMember = null;
            else if (firmMember == null || (firmMember.Id != firmMemberDto.Id))
            {
                tmpFirmMember = new FirmMember();
                tmpFirmMember.Id = firmMemberDto.Id;
            }
            return tmpFirmMember;
        }
        public static EnquiryDetail copyEnquiryDetailId(EnquiryDetail enquiryDetail, EnquiryDetailDTO enquiryDetailDto)
        {
            EnquiryDetail tmpEnquiryDetail = enquiryDetail;
            if (enquiryDetailDto == null) tmpEnquiryDetail = null;
            else if (enquiryDetail == null || (enquiryDetail.Id != enquiryDetailDto.Id))
            {
                tmpEnquiryDetail = new EnquiryDetail();
                tmpEnquiryDetail.Id = enquiryDetailDto.Id;
            }
            return tmpEnquiryDetail;
        }
        public static LeadDetail copyLeadDetailId(LeadDetail leadDetail, LeadDetailDTO leadDetailDto)
        {
            LeadDetail tmpLeadDetail = leadDetail;
            if (leadDetailDto == null) tmpLeadDetail = null;
            else if (leadDetail == null || (leadDetail.Id != leadDetailDto.Id))
            {
                tmpLeadDetail = new LeadDetail();
                tmpLeadDetail.Id = leadDetailDto.Id;
            }
            return tmpLeadDetail;
        }
        public static FirmAccount copyFirmAccountId(FirmAccount firmAccount, FirmAccountDTO firmAccountDto)
        {
            FirmAccount tmpFirmAccount = firmAccount;
            if (firmAccountDto == null) tmpFirmAccount = null;
            else if (firmAccount == null || (firmAccount.Id != firmAccountDto.Id))
            {
                tmpFirmAccount = new FirmAccount();
                tmpFirmAccount.Id = firmAccountDto.Id;
            }
            return tmpFirmAccount;
        }
        public static Customer copyCustomerId(Customer customer, CustomerDTO customerDto)
        {
            Customer tmpCustomer = customer;
            if (customerDto == null) tmpCustomer = null;
            else if (customer == null || (customer.Id != customerDto.Id))
            {
                tmpCustomer = new Customer();
                tmpCustomer.Id = customerDto.Id;
            }
            return tmpCustomer;
        }
        public static PrUnitSaleDetail copyPrUnitSaleDetailId(PrUnitSaleDetail prUnitSaleDetail, PrUnitSaleDetailDTO prUnitSaleDetailDto)
        {
            PrUnitSaleDetail tmpPrUnitSaleDetail = prUnitSaleDetail;
            if (prUnitSaleDetailDto == null) tmpPrUnitSaleDetail = null;
            else if (prUnitSaleDetail == null || (prUnitSaleDetail.Id != prUnitSaleDetailDto.Id))
            {
                tmpPrUnitSaleDetail = new PrUnitSaleDetail();
                tmpPrUnitSaleDetail.Id = prUnitSaleDetailDto.Id;
            }
            return tmpPrUnitSaleDetail;
        }
        public static PropertySchedule copyPropertyScheduleId(PropertySchedule propertySchedule, PropertyScheduleDTO propertyScheduleDto)
        {
        	PropertySchedule tmpPropertySchedule = propertySchedule;
        	if (propertyScheduleDto == null) tmpPropertySchedule = null;
        	else if (propertySchedule == null || (propertySchedule.Id != propertyScheduleDto.Id))
        	{
        		tmpPropertySchedule = new PropertySchedule();
        		tmpPropertySchedule.Id = propertyScheduleDto.Id;
        	}
        	return tmpPropertySchedule;
        }
        public static PropertyUnit copyPropertyUnitId(PropertyUnit propertyUnit, PropertyUnitDTO propertyUnitDto)
        {
            PropertyUnit tmpPropertyUnit = propertyUnit;
            if (propertyUnitDto == null) tmpPropertyUnit = null;
            else if (propertyUnit == null || (propertyUnit.Id != propertyUnitDto.Id))
            {
                tmpPropertyUnit = new PropertyUnit();
                tmpPropertyUnit.Id = propertyUnitDto.Id;
            }
            return tmpPropertyUnit;
        }
        public static MPTBook copyMPTBookId(MPTBookDTO mptBookDto)
        {
            MPTBook mptBook = new MPTBook();
            mptBook.Id = mptBookDto.Id;
            return mptBook;
        }
        //MasterControlData
        public static MasterControlData populateMasterDataAddFields(MasterControlDataDTO masterDataDto)
        {
            MasterControlData masterData = new MasterControlData();
            masterData.Id = masterDataDto.Id;
            masterData.Type = masterDataDto.Type;
            masterData.SystemDefined = masterDataDto.SystemDefined;
            masterData.FirmNumber = masterDataDto.FirmNumber;
            masterData.InsertUser = masterDataDto.InsertUser;
            populateMasterDataUpdateFields(masterData, masterDataDto);
            return masterData;
        }
        public static void populateMasterDataUpdateFields(MasterControlData masterData, MasterControlDataDTO masterDataDto)
        {
            masterData.Name = masterDataDto.Name;
            masterData.Description = masterDataDto.Description;
            masterData.UpdateDate = DateTime.Now;
            masterData.Version = masterDataDto.Version;
            masterData.UpdateUser = masterDataDto.UpdateUser;
        }
        //FirmAccount
        public static FirmAccount populateFirmAccountAddFields(FirmAccountDTO firmAccountDto)
        {
            FirmAccount firmAccount = new FirmAccount();
            firmAccount.Id = firmAccountDto.Id;
            firmAccount.FirmNumber = firmAccountDto.FirmNumber;
            firmAccount.InsertUser = firmAccountDto.InsertUser;
            firmAccount.Firm = DTOToDomainUtil.copyFirmId(firmAccount.Firm, firmAccountDto.Firm);
            populateFirmAccountUpdateFields(firmAccount, firmAccountDto);
            return firmAccount;
        }

        public static void populateFirmAccountUpdateFields(FirmAccount firmAccount, FirmAccountDTO firmAccountDto)
        {
            firmAccount.Name = firmAccountDto.Name;
            firmAccount.AccountNo = firmAccountDto.AccountNo;
            firmAccount.AccountType = DTOToDomainUtil.copyMasterControlId(firmAccount.AccountType, firmAccountDto.AccountType);
            firmAccount.AccountBalance = firmAccountDto.AccountBalance;
            firmAccount.IfscCode = firmAccountDto.IfscCode;
            firmAccount.BankName = firmAccountDto.BankName;
            firmAccount.Branch = firmAccountDto.Branch;
            firmAccount.City = DTOToDomainUtil.copyCityId(firmAccount.City, firmAccountDto.City);
            firmAccount.State = DTOToDomainUtil.copyStateId(firmAccount.State, firmAccountDto.State);
            firmAccount.Country = DTOToDomainUtil.copyCountryId(firmAccount.Country, firmAccountDto.Country);
            firmAccount.UpdateDate = DateTime.Now;
            firmAccount.Version = firmAccountDto.Version;
            firmAccount.UpdateUser = firmAccountDto.UpdateUser;
        }
        //Enquiry
        public static EnquiryDetail populateEnquiryDetailAddFields(EnquiryDetailDTO enquiryDto)
        {
            EnquiryDetail enquiryDetail = new EnquiryDetail();
            enquiryDetail.Salutation = DTOToDomainUtil.copyMasterControlId(enquiryDetail.Salutation, enquiryDto.Salutation);
            enquiryDetail.FirstName = enquiryDto.FirstName;
            enquiryDetail.MiddleName = enquiryDto.MiddleName;
            enquiryDetail.LastName = enquiryDto.LastName;
            enquiryDetail.EnquiryRefNo = CommonUtil.getRandomRefNo();
            enquiryDetail.EnquiryDate = enquiryDto.EnquiryDate;
            enquiryDetail.Property = DTOToDomainUtil.copyPropertyId(enquiryDetail.Property, enquiryDto.Property);
            enquiryDetail.EnquirySource = DTOToDomainUtil.copyMasterControlId(enquiryDetail.EnquirySource, enquiryDto.EnquirySource);
            enquiryDetail.Status = enquiryDto.Status;

            enquiryDetail.FirmNumber = enquiryDto.FirmNumber;
            enquiryDetail.InsertUser = enquiryDto.InsertUser;
            enquiryDetail.ContactInfo = new ContactInfo();
            populateEnquiryDetailUpdateFields(enquiryDetail, enquiryDto);
            return enquiryDetail;
        }
        public static void populateEnquiryDetailUpdateFields(EnquiryDetail enquiryDetail, EnquiryDetailDTO enquiryDto)
        {
            enquiryDetail.AssignedDate = enquiryDto.AssignedDate;
            DTOToDomainUtil.copyToContactInfo(enquiryDetail.ContactInfo, enquiryDto.ContactInfo);
            enquiryDetail.Occupation = DTOToDomainUtil.copyMasterControlId(enquiryDetail.Occupation, enquiryDto.Occupation);
            enquiryDetail.PrUnitType = DTOToDomainUtil.copyMasterControlId(enquiryDetail.PrUnitType, enquiryDto.PrUnitType);
            enquiryDetail.Budget = enquiryDto.Budget;
            enquiryDetail.Assignee = DTOToDomainUtil.copyFirmMemberId(enquiryDetail.Assignee, enquiryDto.Assignee);
            enquiryDetail.Comments = enquiryDto.Comments;
            enquiryDetail.Version = enquiryDto.Version;
            enquiryDetail.UpdateDate = DateTime.Now;
            enquiryDetail.UpdateUser = enquiryDto.UpdateUser;
        }
        //Enquiry Follow up
        public static EnquiryActivity populateEnquiryActivityAddFields(EnquiryActivityDTO enquiryActivityDto)
        {
            EnquiryActivity enquiryActivity = new EnquiryActivity();
            enquiryActivity.Id = enquiryActivityDto.Id;
            enquiryActivity.RecordType = enquiryActivityDto.RecordType;
            enquiryActivity.ReminderMode = enquiryActivityDto.ReminderMode;
            enquiryActivity.ActivityType = enquiryActivityDto.ActivityType;
            enquiryActivity.DateLogged = enquiryActivityDto.DateLogged;
            enquiryActivity.ScheduledDate = enquiryActivityDto.ScheduledDate;
            enquiryActivity.Status = enquiryActivityDto.Status;
            enquiryActivity.EnquiryDetail = DTOToDomainUtil.copyEnquiryDetailId(enquiryActivity.EnquiryDetail, enquiryActivityDto.EnquiryDetail);
            enquiryActivity.LoggedBy = DTOToDomainUtil.copyFirmMemberId(enquiryActivity.LoggedBy, enquiryActivityDto.LoggedBy);
            enquiryActivity.CommunicationMedia = DTOToDomainUtil.copyMasterControlId(enquiryActivity.CommunicationMedia, enquiryActivityDto.CommunicationMedia);
            enquiryActivity.RefNo = CommonUtil.getRandomRefNo();
            enquiryActivity.RevRefNo = enquiryActivityDto.RevRefNo;
            enquiryActivity.FirmNumber = enquiryActivityDto.FirmNumber;
            enquiryActivity.InsertUser = enquiryActivityDto.InsertUser;
            if (enquiryActivityDto.CallHistoryDTO != null)
            {
                enquiryActivity.CallHistory = new CallHistory();
                enquiryActivity.CallHistory.Id = enquiryActivityDto.CallHistoryDTO.Id;
            }
            populateEnquiryActivityUpdateFields(enquiryActivity, enquiryActivityDto);
            return enquiryActivity;
        }
        public static void populateEnquiryActivityUpdateFields(EnquiryActivity enquiryActivity, EnquiryActivityDTO enquiryActivityDto)
        {
            enquiryActivity.Comments = enquiryActivityDto.Comments;
            enquiryActivity.UpdateDate = DateTime.Now;
            enquiryActivity.UpdateUser = enquiryActivityDto.UpdateUser;
            enquiryActivity.Version = enquiryActivityDto.Version;
        }
        //Lead
        public static LeadDetail populateLeadDetailAddFields(LeadDetailDTO leadDto)
        {
            LeadDetail leadDetail = new LeadDetail();
            leadDetail.LeadRefNo = CommonUtil.getRandomRefNo();
            leadDetail.Property = DTOToDomainUtil.copyPropertyId(null, leadDto.Property);
            leadDetail.Assignee = DTOToDomainUtil.copyFirmMemberId(null, leadDto.Assignee);

            leadDetail.FirmNumber = leadDto.FirmNumber;
            leadDetail.InsertUser = leadDto.InsertUser;
            leadDetail.ContactInfo = new ContactInfo();
            populateLeadDetailUpdateFields(leadDetail, leadDto);
            return leadDetail;
        }
        public static void populateLeadDetailUpdateFields(LeadDetail leadDetail, LeadDetailDTO leadDto)
        {
            leadDetail.Salutation = DTOToDomainUtil.copyMasterControlId(leadDetail.Salutation, leadDto.Salutation);
            leadDetail.FirstName = leadDto.FirstName;
            leadDetail.MiddleName = leadDto.MiddleName;
            leadDetail.LastName = leadDto.LastName;
            DTOToDomainUtil.copyToContactInfo(leadDetail.ContactInfo, leadDto.ContactInfo);
            leadDetail.LeadDate = leadDto.LeadDate;
            leadDetail.AssignedDate = leadDto.AssignedDate;
            leadDetail.Source = DTOToDomainUtil.copyMasterControlId(leadDetail.Source, leadDto.Source);
            leadDetail.Budget = leadDto.Budget;
            leadDetail.Assignee = DTOToDomainUtil.copyFirmMemberId(leadDetail.Assignee, leadDto.Assignee);
            leadDetail.Status = leadDto.Status;
            leadDetail.Version = leadDto.Version;
            leadDetail.UpdateDate = DateTime.Now;
            leadDetail.UpdateUser = leadDto.UpdateUser;
        }
        //Lead Follow up
        public static LeadActivity populateLeadActivityAddFields(LeadActivityDTO leadActivityDto)
        {
            LeadActivity leadActivity = new LeadActivity();
            leadActivity.Id = leadActivityDto.Id;
            leadActivity.RecordType = leadActivityDto.RecordType;
            leadActivity.ActivityType = leadActivityDto.ActivityType;
            leadActivity.ReminderMode = leadActivityDto.ReminderMode;
            leadActivity.DateLogged = leadActivityDto.DateLogged;
            leadActivity.ScheduledDate = leadActivityDto.ScheduledDate;
            leadActivity.Status = leadActivityDto.Status;
            leadActivity.RefNo = CommonUtil.getRandomRefNo();
            leadActivity.RevRefNo = leadActivityDto.RevRefNo;
            leadActivity.FirmNumber = leadActivityDto.FirmNumber;
            leadActivity.InsertUser = leadActivityDto.InsertUser;
            leadActivity.LeadDetail = DTOToDomainUtil.copyLeadDetailId(leadActivity.LeadDetail, leadActivityDto.LeadDetail);
            leadActivity.LoggedBy = DTOToDomainUtil.copyFirmMemberId(leadActivity.LoggedBy, leadActivityDto.LoggedBy);
            leadActivity.CommunicationMedia = DTOToDomainUtil.copyMasterControlId(leadActivity.CommunicationMedia, leadActivityDto.CommunicationMedia);
            if (leadActivityDto.CallHistoryDTO != null)
            {
                leadActivity.CallHistory = new CallHistory();
                leadActivity.CallHistory.Id = leadActivityDto.CallHistoryDTO.Id;
            }
            populateLeadActivityUpdateFields(leadActivity, leadActivityDto);
            return leadActivity;
        }
        public static void populateLeadActivityUpdateFields(LeadActivity leadActivity, LeadActivityDTO leadActivityDto)
        {
            leadActivity.Comments = leadActivityDto.Comments;
            leadActivity.UpdateDate = DateTime.Now;
            leadActivity.UpdateUser = leadActivityDto.UpdateUser;
            leadActivity.Version = leadActivityDto.Version;
        }
        public static PropertyUnit populatePropertyUnitAddFields(PropertyUnitDTO propertyUnitDTO)
        {
            PropertyUnit propertyUnit = new PropertyUnit();
            propertyUnit.PropertyTower = DTOToDomainUtil.copyPropertyTowerId(propertyUnit.PropertyTower, propertyUnitDTO.PropertyTower);
            propertyUnit.Wing = propertyUnitDTO.Wing;
            propertyUnit.FloorNo = propertyUnitDTO.FloorNo;
            propertyUnit.UnitNo = propertyUnitDTO.UnitNo;

            populatePropertyUnitDetailUpdateFields(propertyUnit, propertyUnitDTO);
            propertyUnit.FirmNumber = propertyUnitDTO.FirmNumber;
            propertyUnit.InsertUser = propertyUnitDTO.InsertUser;
            return propertyUnit;
        }
        public static void populatePropertyUnitDetailUpdateFields(PropertyUnit propertyUnit, PropertyUnitDTO propertyUnitDTO)
        {

            propertyUnit.UnitType = DTOToDomainUtil.copyMasterControlId(propertyUnit.UnitType, propertyUnitDTO.UnitType);
            propertyUnit.Direction = DTOToDomainUtil.copyMasterControlId(propertyUnit.Direction, propertyUnitDTO.Direction);
            propertyUnit.Facing = DTOToDomainUtil.copyMasterControlId(propertyUnit.Facing, propertyUnitDTO.Facing);
            propertyUnit.BuildupArea = Convert.ToDecimal(propertyUnitDTO.BuildupArea);
            propertyUnit.CarpetArea = Convert.ToDecimal(propertyUnitDTO.CarpetArea);
            propertyUnit.BalconyArea = propertyUnitDTO.BalconyArea;
            propertyUnit.Status = propertyUnitDTO.Status;
            propertyUnit.ReserveComments = propertyUnitDTO.ReserveComments;
            propertyUnit.NoOfBalcony = propertyUnitDTO.NoOfBalcony;
            propertyUnit.Version = propertyUnitDTO.Version;
            propertyUnit.UpdateDate = DateTime.Now;
            propertyUnit.UpdateUser = propertyUnitDTO.UpdateUser;
        }
        //Property Unit Sale
        public static PrUnitSaleDetail populatePrUnitSaleDetailAddFields(PrUnitSaleDetailDTO prUnitSaleDetailDto)
        {
            PrUnitSaleDetail prUnitSaleDetail = new PrUnitSaleDetail();
            prUnitSaleDetail.BookingRefNo = CommonUtil.getRandomRefNo();
            prUnitSaleDetail.Customer = DTOToDomainUtil.copyCustomerId(null, prUnitSaleDetailDto.Customer);
            prUnitSaleDetail.Enquiry = DTOToDomainUtil.copyEnquiryDetailId(null, prUnitSaleDetailDto.Enquiry);
            prUnitSaleDetail.FirmMember = DTOToDomainUtil.copyFirmMemberId(null, prUnitSaleDetailDto.FirmMember);
            prUnitSaleDetail.BookingDate = prUnitSaleDetailDto.BookingDate;
            prUnitSaleDetail.PropertyUnit = DTOToDomainUtil.copyPropertyUnitId(prUnitSaleDetail.PropertyUnit, prUnitSaleDetailDto.PropertyUnit);
            prUnitSaleDetail.MPTUnitBook = new MPTBook();
            prUnitSaleDetail.MPTUnitBook.Description = "Booked Unit Book";

            prUnitSaleDetail.FirmNumber = prUnitSaleDetailDto.FirmNumber;
            prUnitSaleDetail.InsertUser = prUnitSaleDetailDto.InsertUser;

            populatePrUnitSaleDetailUpdateFields(prUnitSaleDetail, prUnitSaleDetailDto);

            return prUnitSaleDetail;
        }
        public static void populatePrUnitSaleDetailUpdateFields(PrUnitSaleDetail prUnitSaleDetail, PrUnitSaleDetailDTO prUnitSaleDetailDto)
        {
            prUnitSaleDetail.SaleRate = prUnitSaleDetailDto.SaleRate;
            prUnitSaleDetail.AgreementAmt = prUnitSaleDetailDto.AgreementAmt;
            prUnitSaleDetail.TotalTaxAmt = prUnitSaleDetailDto.TotalTaxAmt;
            prUnitSaleDetail.TotalPymtAmt = prUnitSaleDetailDto.TotalPymtAmt;
            prUnitSaleDetail.TotalPackageCost = prUnitSaleDetailDto.TotalPackageCost;
            prUnitSaleDetail.Status = prUnitSaleDetailDto.Status;
            prUnitSaleDetail.IsAgreementDone = prUnitSaleDetailDto.IsAgreementDone;
            prUnitSaleDetail.AgreementDate = prUnitSaleDetailDto.AgreementDate;
            prUnitSaleDetail.AgreementNo = prUnitSaleDetailDto.AgreementNo;
            prUnitSaleDetail.IsPossessionDone = prUnitSaleDetailDto.IsPossessionDone;
            prUnitSaleDetail.PossessionDate = prUnitSaleDetailDto.PossessionDate;
            prUnitSaleDetail.LoanBankName = prUnitSaleDetailDto.LoanBankName;
            prUnitSaleDetail.LoanBankBranch = prUnitSaleDetailDto.LoanBankBranch;
            prUnitSaleDetail.LoanAmt = prUnitSaleDetailDto.LoanAmt;
            prUnitSaleDetail.UpdateUser = prUnitSaleDetailDto.UpdateUser;
            prUnitSaleDetail.UpdateDate = DateTime.Now;
            prUnitSaleDetail.Version = prUnitSaleDetailDto.Version;
            populatePrUnitSalePymt(prUnitSaleDetail, prUnitSaleDetailDto.PrUnitSalePymts);
            populatePrUnitSaleTaxDetail(prUnitSaleDetail, prUnitSaleDetailDto.PrUnitSaleTaxDetails);
            populateCoCustomer(prUnitSaleDetail, prUnitSaleDetailDto);
        }
        public static DemandLetterHistory populateDemandLetterHistoryAddFields(DemandLetterHistoryDTO demandLetterHistoryDto)
        {
        	DemandLetterHistory demandLetterHistory = new DemandLetterHistory();
        	demandLetterHistory.UploadDate = demandLetterHistoryDto.UploadDate;
        	demandLetterHistory.DeliveryDate = demandLetterHistoryDto.DeliveryDate;
        	demandLetterHistory.FileName = demandLetterHistoryDto.FileName;
        	demandLetterHistory.DocumentPath = demandLetterHistoryDto.DocumentPath;
        	demandLetterHistory.UploadBy = DTOToDomainUtil.copyFirmMemberId(null, demandLetterHistoryDto.UploadBy);
        	demandLetterHistory.PrUnitSaleDetail = DTOToDomainUtil.copyPrUnitSaleDetailId(null, demandLetterHistoryDto.PrUnitSaleDetail);
        	demandLetterHistory.Stage = DTOToDomainUtil.copyPropertyScheduleId(null, demandLetterHistoryDto.Stage);
        	demandLetterHistory.FirmNumber = demandLetterHistoryDto.FirmNumber;
        	demandLetterHistory.InsertUser = demandLetterHistoryDto.InsertUser;
        	demandLetterHistory.UpdateUser = demandLetterHistoryDto.UpdateUser;
        	return demandLetterHistory;
        }
        private static void populateCoCustomer(PrUnitSaleDetail prUnitSaleDetail, PrUnitSaleDetailDTO prUnitSaleDetailDto)
        {
            if (prUnitSaleDetailDto.CoCustomers != null)
            {
                ISet<CoCustomer> cocustomers = prUnitSaleDetail.CoCustomers;
                ISet<CoCustomerDTO> cocustomerDtos = prUnitSaleDetailDto.CoCustomers;
                for (int i = 0; i < cocustomers.Count; i++)
                {
                    CoCustomer coCustomer = cocustomers.ElementAt(i);
                    CoCustomerDTO cocustomerDto = cocustomerDtos.FirstOrDefault(x => x.Id == coCustomer.Id);
                    if (cocustomerDto == null)
                    {
                        cocustomers.Remove(coCustomer);
                        i--;
                    }
                    else
                    {
                        DTOToDomainUtil.copyTocoCustomer(coCustomer, cocustomerDto);
                    }
                }
                foreach (CoCustomerDTO cocustomerDto in cocustomerDtos)
                {
                    if (cocustomerDto.Id < 1)
                    {
                        CoCustomer newcoCustomer = new CoCustomer();
                        DTOToDomainUtil.copyTocoCustomer(newcoCustomer, cocustomerDto);
                        newcoCustomer.PrUnitSaleDetail = prUnitSaleDetail;
                        cocustomers.Add(newcoCustomer);
                    }
                }
            }
            else
            {
                prUnitSaleDetail.CoCustomers.Clear();
            }
        }
        public static void populatePrUnitSaleCancellationAddFields(PrUnitSaleDetail prUnitSaleDetail, PrUnitSaleDetailDTO prUnitSaleDetailDto)
        {
            prUnitSaleDetail.CanellationDate = prUnitSaleDetailDto.CanellationDate;
            prUnitSaleDetail.CancellationFirmMember = DTOToDomainUtil.copyFirmMemberId(null, prUnitSaleDetailDto.CancellationFirmMember);
            prUnitSaleDetail.Status = PRUnitSaleStatus.Cancelled;
            //Update Customer to builder payments as Suspended.
            foreach (PrUnitSalePymt prUnitPymt in prUnitSaleDetail.PrUnitSalePymts)
            {
            	//At time of Cancellation, suspend all receivable and payable payments.
                if (prUnitPymt.PaymentMaster.Status == PymtMasterStatus.Paid || prUnitPymt.PaymentMaster.Status == PymtMasterStatus.Pending)
                {
                    prUnitPymt.PaymentMaster.Status = PymtMasterStatus.Suspended;
                    prUnitPymt.PaymentMaster.UpdateUser = prUnitSaleDetail.UpdateUser;
                    prUnitPymt.PaymentMaster.UpdateDate = DateTime.Today;
                }
            }
            populatePrUnitSaleCancellationUpdateFields(prUnitSaleDetail, prUnitSaleDetailDto);
        }
        public static void populatePrUnitSaleCancellationUpdateFields(PrUnitSaleDetail prUnitSaleDetail, PrUnitSaleDetailDTO prUnitSaleDetailDto)
        {
            prUnitSaleDetail.CancellationFee = prUnitSaleDetailDto.CancellationFee;
            prUnitSaleDetail.CancellationReason = prUnitSaleDetailDto.CancellationReason;
            prUnitSaleDetail.UpdateUser = prUnitSaleDetailDto.UpdateUser;
            prUnitSaleDetail.UpdateDate = DateTime.Now;

            if (prUnitSaleDetailDto.PrUnitSalePymts != null)
            {
                foreach (PrUnitSalePymtDTO prUnitPymtDto in prUnitSaleDetailDto.PrUnitSalePymts)
                {
                    if (prUnitPymtDto.PymtMode == PaymentMode.Payable)
                    {
                        if (prUnitPymtDto.Id > 0)
                        {
                            PrUnitSalePymt prUnitPymt = prUnitSaleDetail.PrUnitSalePymts.FirstOrDefault<PrUnitSalePymt>(x => x.Id == prUnitPymtDto.Id);
                            populatePrUnitSalePymtUpdateFields(prUnitPymt, prUnitPymtDto);
                        }
                        else
                        {
                            PrUnitSalePymt prUnitPymt = populatePrUnitSalePymtAddFields(prUnitPymtDto);
                            prUnitPymt.PrUnitSaleDetail = prUnitSaleDetail;
                            prUnitSaleDetail.PrUnitSalePymts.Add(prUnitPymt);
                        }
                    }
                }
            }
        }
        public static PrUnitSalePymt populatePrUnitSalePymtAddFields(PrUnitSalePymtDTO prUnitSalePymtDto)
        {
            PrUnitSalePymt prUnitSalePymt = new PrUnitSalePymt();
            prUnitSalePymt.PrUnitSaleDetail = DTOToDomainUtil.copyPrUnitSaleDetailId(null, prUnitSalePymtDto.PrUnitSaleDetail);
            prUnitSalePymt.PymtDate = prUnitSalePymtDto.PymtDate;
            prUnitSalePymt.PymtType = DTOToDomainUtil.copyMasterControlId(prUnitSalePymt.PymtType, prUnitSalePymtDto.PymtType);
            prUnitSalePymt.PymtMode = prUnitSalePymtDto.PymtMode;
            populatePrUnitSalePymtUpdateFields(prUnitSalePymt, prUnitSalePymtDto);

            prUnitSalePymt.FirmNumber = prUnitSalePymtDto.FirmNumber;
            prUnitSalePymt.InsertUser = prUnitSalePymtDto.InsertUser;
            return prUnitSalePymt;
        }
        public static void populatePrUnitSalePymtUpdateFields(PrUnitSalePymt prUnitSalePymt, PrUnitSalePymtDTO prUnitSalePymtDto)
        {
            prUnitSalePymt.PymtAmt = prUnitSalePymtDto.PymtAmt;
            prUnitSalePymt.Description = prUnitSalePymtDto.Description;

            populatePaymentMaster(prUnitSalePymt, prUnitSalePymtDto);
            prUnitSalePymt.Version = prUnitSalePymtDto.Version;
            prUnitSalePymt.UpdateUser = prUnitSalePymtDto.UpdateUser;
            prUnitSalePymt.UpdateDate = DateTime.Now;
        }
        public static void populatePaymentMaster(PrUnitSalePymt prUnitSalePymt, PrUnitSalePymtDTO prUnitSalePymtDto)
        {
            if (prUnitSalePymtDto.PaymentMaster.Id == 0)
            {
                prUnitSalePymt.PaymentMaster = populatePaymentMasterAddFields(prUnitSalePymtDto.PaymentMaster);
            }
            else
            {
                populatePaymentMasterUpdateFields(prUnitSalePymt.PaymentMaster, prUnitSalePymtDto.PaymentMaster);
            }
        }
        public static void populatePrUnitSalePymt(PrUnitSaleDetail prUnitSaleDetail, ISet<PrUnitSalePymtDTO> prUnitSalePymtDtos)
        {
            ISet<PrUnitSalePymt> prUnitSalePymts = prUnitSaleDetail.PrUnitSalePymts;
            if (prUnitSalePymtDtos != null && prUnitSalePymtDtos.Count > 0)
            {
                if (prUnitSalePymts != null && prUnitSalePymts.Count > 0)
                {
                    for (int i = 0; i < prUnitSalePymts.Count; i++)
                    {
                        PrUnitSalePymt tmpPrUnitSalePymt = prUnitSalePymts.ElementAt(i);
                        PrUnitSalePymtDTO tmpPrUnitSalePymtDto = prUnitSalePymtDtos.FirstOrDefault(x => x.Id == tmpPrUnitSalePymt.Id);
                        populatePrUnitSalePymtUpdateFields(tmpPrUnitSalePymt, tmpPrUnitSalePymtDto);
                    }
                }
                foreach (PrUnitSalePymtDTO prUnitSalePymtDto in prUnitSalePymtDtos)
                {
                    if (prUnitSalePymtDto.Id < 1)
                    {
                        PrUnitSalePymt prUnitSalePymt = populatePrUnitSalePymtAddFields(prUnitSalePymtDto);
                        prUnitSalePymt.PrUnitSaleDetail = prUnitSaleDetail;
                        prUnitSalePymts.Add(prUnitSalePymt);
                    }
                }
            }
        }
        public static void populatePrUnitSaleTaxDetail(PrUnitSaleDetail prUnitSaleDetail, ISet<PrUnitSaleTaxDetailDTO> prUnitSaleTaxDetailDtos)
        {
            ISet<PrUnitSaleTaxDetail> prUnitSaleTaxDetails = prUnitSaleDetail.PrUnitSaleTaxDetails;
            if (prUnitSaleTaxDetailDtos != null && prUnitSaleTaxDetailDtos.Count > 0)
            {
                if (prUnitSaleTaxDetails != null && prUnitSaleTaxDetails.Count > 0)
                {
                    for (int i = 0; i < prUnitSaleTaxDetails.Count; i++)
                    {
                        PrUnitSaleTaxDetail tmpTaxDetail = prUnitSaleTaxDetails.ElementAt(i);
                        PrUnitSaleTaxDetailDTO tmpTaxDetailDto = prUnitSaleTaxDetailDtos.FirstOrDefault(x => x.Id == tmpTaxDetail.Id);
                        if (tmpTaxDetailDto == null)
                        {
                            prUnitSaleTaxDetails.Remove(tmpTaxDetail);
                            i--;
                        }
                        else
                        {
                            tmpTaxDetail.TaxAmt = tmpTaxDetailDto.TaxAmt;
                            tmpTaxDetail.UpdateDate = DateTime.Now;
                            tmpTaxDetail.UpdateUser = tmpTaxDetailDto.UpdateUser;
                        }
                    }
                }
                foreach (PrUnitSaleTaxDetailDTO prUnitSalePymtDto in prUnitSaleTaxDetailDtos)
                {
                    if (prUnitSalePymtDto.Id < 1)
                    {
                        PrUnitSaleTaxDetail prUnitSaleTaxPymt = new PrUnitSaleTaxDetail();
                        prUnitSaleTaxPymt.TaxType = DTOToDomainUtil.copyMasterControlId(prUnitSaleTaxPymt.TaxType, prUnitSalePymtDto.TaxType);
                        prUnitSaleTaxPymt.TaxPercentage = prUnitSalePymtDto.TaxPercentage;
                        prUnitSaleTaxPymt.TaxAmtLimit = prUnitSalePymtDto.TaxAmtLimit;
                        prUnitSaleTaxPymt.TaxAmt = prUnitSalePymtDto.TaxAmt;
                        prUnitSaleTaxPymt.IncludeInTotalPymt = prUnitSalePymtDto.IncludeInTotalPymt;
                        prUnitSaleTaxPymt.FirmNumber = prUnitSalePymtDto.FirmNumber;
                        prUnitSaleTaxPymt.InsertUser = prUnitSalePymtDto.InsertUser;
                        prUnitSaleTaxPymt.UpdateUser = prUnitSalePymtDto.UpdateUser;
                        prUnitSaleTaxPymt.Version = prUnitSalePymtDto.Version;
                        prUnitSaleTaxPymt.PrUnitSaleDetail = prUnitSaleDetail;
                        prUnitSaleTaxDetails.Add(prUnitSaleTaxPymt);
                    }
                }
            }
            else
            {
                prUnitSaleDetail.PrUnitSaleTaxDetails.Clear();
            }
        }
        public static PaymentMaster populatePaymentMasterAddFields(PaymentMasterDTO paymentMasterDto)
        {
            PaymentMaster paymentMaster = new PaymentMaster();
            populatePaymentMasterUpdateFields(paymentMaster, paymentMasterDto);

            paymentMaster.FirmNumber = paymentMasterDto.FirmNumber;
            paymentMaster.InsertUser = paymentMasterDto.InsertUser;
            return paymentMaster;
        }
        public static void populatePaymentMasterUpdateFields(PaymentMaster paymentMaster, PaymentMasterDTO paymentMasterDto)
        {
            paymentMaster.TotalAmt = paymentMasterDto.TotalAmt;
            paymentMaster.TotalPaid = paymentMasterDto.TotalPaid;
            paymentMaster.TotalPending = paymentMasterDto.TotalPending;
            paymentMaster.TotalPdcAmt = paymentMasterDto.TotalPdcAmt;
            paymentMaster.Status = paymentMasterDto.Status;

            paymentMaster.Version = paymentMasterDto.Version;
            paymentMaster.UpdateUser = paymentMasterDto.UpdateUser;
            paymentMaster.UpdateDate = DateTime.Now;
        }
        public static MasterPymtTransaction populateMasterPymtTransactionAddFields(MasterPymtTransactionDTO masterPymtTransactionDto)
        {
            MasterPymtTransaction masterPymtTransaction = new MasterPymtTransaction();
            populateMasterPymtTransactionUpdateFields(masterPymtTransaction, masterPymtTransactionDto);

            masterPymtTransaction.MPTBook = DTOToDomainUtil.copyMPTBookId(masterPymtTransactionDto.MPTBook);
            masterPymtTransaction.PymtMode = masterPymtTransactionDto.PymtMode;
            masterPymtTransaction.TxRefNo = CommonUtil.getRandomRefNo();
            masterPymtTransaction.PymtMethod = masterPymtTransactionDto.PymtMethod;
            masterPymtTransaction.Property = DTOToDomainUtil.copyPropertyId(masterPymtTransaction.Property, masterPymtTransactionDto.Property);
            masterPymtTransaction.FirmNumber = masterPymtTransactionDto.FirmNumber;
            masterPymtTransaction.InsertUser = masterPymtTransactionDto.InsertUser;
            return masterPymtTransaction;
        }
        public static void populateMasterPymtTransactionUpdateFields(MasterPymtTransaction masterPymtTransaction, MasterPymtTransactionDTO masterPymtTransactionDto)
        {
            if(masterPymtTransactionDto.PymtStatus != MPTPymtStatus.Deleted) {
                masterPymtTransaction.TxDate = masterPymtTransactionDto.TxDate;
                masterPymtTransaction.CollectionDate = masterPymtTransactionDto.CollectionDate;
                masterPymtTransaction.ChequeDate = masterPymtTransactionDto.ChequeDate;
                masterPymtTransaction.ClearanceDate = masterPymtTransactionDto.ClearanceDate;
                masterPymtTransaction.PymtAmt = masterPymtTransactionDto.PymtAmt;
                masterPymtTransaction.BankName = masterPymtTransactionDto.BankName;
                masterPymtTransaction.Branch = masterPymtTransactionDto.Branch;
                masterPymtTransaction.MediaNo = masterPymtTransactionDto.MediaNo;
                masterPymtTransaction.PayName = masterPymtTransactionDto.PayName;
                masterPymtTransaction.ChequeStatus = masterPymtTransactionDto.ChequeStatus;
                masterPymtTransaction.RcptDelivered = masterPymtTransactionDto.RcptDelivered;
                masterPymtTransaction.RcptDeliveryDate = masterPymtTransactionDto.RcptDeliveryDate;
                masterPymtTransaction.RcptDocPath = masterPymtTransactionDto.RcptDocPath;
            }            
            masterPymtTransaction.PymtStatus = masterPymtTransactionDto.PymtStatus;
            masterPymtTransaction.Comments = masterPymtTransactionDto.Comments;

            masterPymtTransaction.Version = masterPymtTransactionDto.Version;
            masterPymtTransaction.UpdateUser = masterPymtTransactionDto.UpdateUser;
            masterPymtTransaction.UpdateDate = DateTime.Now;

            populateMPTChildUpdateFields(masterPymtTransaction, masterPymtTransactionDto);
        }
        public static void populateMPTChildUpdateFields(MasterPymtTransaction masterPymtTransaction, MasterPymtTransactionDTO masterPymtTransactionDto)
        {
            ISet<PaymentTransaction> pymtTransactions = masterPymtTransaction.PaymentTransactions;
            ISet<PaymentTransactionDTO> pymtTransactionDtos = masterPymtTransactionDto.PaymentTransactions;
            if (pymtTransactions != null && pymtTransactions.Count > 0)
            {
                for (int i = 0; i < pymtTransactions.Count; i++)
                {
                    PaymentTransaction pymtTransaction = pymtTransactions.ElementAt(i);
                    PaymentTransactionDTO pymtTransactionDto = pymtTransactionDtos.FirstOrDefault(x => x.Id == pymtTransaction.Id);
                    if (pymtTransactionDto == null)
                    {
                        pymtTransactions.Remove(pymtTransaction);
                        i--;
                    }
                    else
                    {
                        DTOToDomainUtil.populatePaymentTransactionUpdateFields(pymtTransaction, pymtTransactionDto);
                    }
                }
            }
            foreach (PaymentTransactionDTO pymtTransactionDto in pymtTransactionDtos)
            {
                if (pymtTransactionDto.Id < 1)
                {
                    PaymentTransaction pymtTransaction = DTOToDomainUtil.populatePaymentTransactionAddFields(pymtTransactionDto);
                    pymtTransaction.PaymentMaster = new PaymentMaster();
                    pymtTransaction.PaymentMaster.Id = pymtTransactionDto.PaymentMaster.Id;
                    pymtTransaction.MasterPymtTransaction = masterPymtTransaction;
                    masterPymtTransaction.PaymentTransactions.Add(pymtTransaction);
                }
            }
        }

        public static PaymentTransaction populatePaymentTransactionAddFields(PaymentTransactionDTO paymentTransactionDto)
        {
            PaymentTransaction paymentTransaction = new PaymentTransaction();
            paymentTransaction.TxDate = paymentTransactionDto.TxDate;
            populatePaymentTransactionUpdateFields(paymentTransaction, paymentTransactionDto);

            paymentTransaction.FirmNumber = paymentTransactionDto.FirmNumber;
            paymentTransaction.InsertUser = paymentTransactionDto.InsertUser;
            return paymentTransaction;
        }
        public static void populatePaymentTransactionUpdateFields(PaymentTransaction paymentTransaction, PaymentTransactionDTO paymentTransactionDto)
        {
            paymentTransaction.FirmAccount = DTOToDomainUtil.copyFirmAccountId(paymentTransaction.FirmAccount, paymentTransactionDto.FirmAccount);
            paymentTransaction.Amount = paymentTransactionDto.Amount;
            paymentTransaction.Status = paymentTransactionDto.Status;
            paymentTransaction.InvoiceNumber = paymentTransactionDto.InvoiceNumber;
            paymentTransaction.Comments = paymentTransactionDto.Comments;
            if (paymentTransaction.Status != PymtTransStatus.Pending)
            {
                if (paymentTransaction.AccountTransaction == null)
                {
                    paymentTransaction.AccountTransaction = DTOToDomainUtil.populateAccountTransactionAddFields(paymentTransactionDto.AccountTransaction);
                }
                else
                {
                    DTOToDomainUtil.populateAccountTransactionUpdateFields(paymentTransaction.AccountTransaction, paymentTransactionDto.AccountTransaction);
                }
            }
            if (paymentTransaction.PaymentVoucher == null)
            {
                if (paymentTransactionDto.PaymentVoucherDTO != null)
                {
                    paymentTransaction.PaymentVoucher = new PaymentVoucher();
                    DTOToDomainUtil.populatePaymentVoucherAddFields(paymentTransaction.PaymentVoucher, paymentTransactionDto.PaymentVoucherDTO);
                    paymentTransaction.PaymentVoucher.PaymentTransaction = paymentTransaction;
                }
            }
            else
            {
                DTOToDomainUtil.populatePaymentVoucherUpdateFields(paymentTransaction.PaymentVoucher, paymentTransactionDto.PaymentVoucherDTO);
            }
            paymentTransaction.Version = paymentTransactionDto.Version;
            paymentTransaction.UpdateUser = paymentTransactionDto.UpdateUser;
            paymentTransaction.UpdateDate = DateTime.Now;
        }
        public static AccountTransaction populateAccountTransactionAddFields(AccountTransactionDTO accountTransactionDto)
        {
            AccountTransaction accountTransaction = new AccountTransaction();
            accountTransaction.FirmAccount = DTOToDomainUtil.copyFirmAccountId(null, accountTransactionDto.FirmAccount);
            accountTransaction.TxDate = accountTransactionDto.TxDate;
            accountTransaction.Amount = accountTransactionDto.Amount;
            accountTransaction.TxType = accountTransactionDto.TxType;
            accountTransaction.Comments = accountTransactionDto.Comments;
            populateAccountTransactionUpdateFields(accountTransaction, accountTransactionDto);
            accountTransaction.InsertDate = DateTime.Now;
            accountTransaction.FirmNumber = accountTransactionDto.FirmNumber;
            accountTransaction.InsertUser = accountTransactionDto.InsertUser;
            return accountTransaction;
        }
        public static void populateAccountTransactionUpdateFields(AccountTransaction accountTransaction, AccountTransactionDTO accountTransactionDto)
        {
            accountTransaction.Version = accountTransactionDto.Version;
            accountTransaction.UpdateUser = accountTransactionDto.UpdateUser;
            accountTransaction.UpdateDate = DateTime.Now;
        }
        public static Agency populateAgencyAddFields(AgencyDTO agencyDto)
        {
            Agency agency = new Agency();          
			agency.ContactInfo=new ContactInfo();       
			agency.MPTAgencyBook = new MPTBook();
            agency.MPTAgencyBook.Description = "Agency In Book";
            populateAgencyUpdateFields(agency, agencyDto);
            agency.InsertDate = DateTime.Now;
            agency.FirmNumber = agencyDto.FirmNumber;
            agency.InsertUser = agencyDto.InsertUser;
            return agency;
        }
        public static void populateAgencyUpdateFields(Agency agency, AgencyDTO agencyDto)
        {
            agency.AgencyName = agencyDto.AgencyName;            
            agency.OwnerName = agencyDto.OwnerName;
            agency.Description = agencyDto.Description;
            agency.AgencyType = DTOToDomainUtil.copyMasterControlId(agency.AgencyType, agencyDto.AgencyType);
            agency.RegistrationNo = agencyDto.RegistrationNo;
            agency.AgencyType = DTOToDomainUtil.copyMasterControlId(agency.AgencyType, agencyDto.AgencyType);
            agency.Pan = agencyDto.Pan;
            agency.Salestaxnumber = agencyDto.Salestaxnumber;
            agency.Centralsalestaxnumber = agencyDto.Centralsalestaxnumber;
            agency.Groupname = agencyDto.Groupname;
            agency.Taxclassification = agencyDto.Taxclassification;
            agency.Taxtype = agencyDto.Taxtype;
            agency.Billwise = agencyDto.Billwise;
            agency.Currency = agencyDto.Currency;
            agency.Tallystatus = agencyDto.Tallystatus;
            DTOToDomainUtil.copyToContactInfo(agency.ContactInfo, agencyDto.ContactInfo);                      
            agency.Version = agencyDto.Version;
            agency.UpdateUser = agencyDto.UpdateUser;
            agency.UpdateDate = DateTime.Now;
        }
        public static Firm populateFirmFields(Firm firmDto)
        {
            Firm firm = new Firm();
            firm.Id = firmDto.Id;
            firm.Name = firmDto.FirmNumber;
            firm.WebSite = firmDto.WebSite;
            firm.FirmNumber = firmDto.FirmNumber;
            firm.Description = firmDto.Description;
            firm.GSTin = firmDto.GSTin;
            firm.RegistrationNo = firmDto.RegistrationNo;
            firm.InsertUser = firmDto.InsertUser;
            firm.ContactInfo = new ContactInfo();
            //populateFirmUpdateFields(firm, firmDto);
            return firm;
        }
        public static void populateFirmUpdateFields(Firm firm, FirmDTO firmDto)
        {
           
            firm.UpdateDate = DateTime.Now;
            firm.Version = firmDto.Version;
            firm.UpdateUser = firmDto.UpdateUser;
        }
        //Firm Member
        public static FirmMember populateFirmMemberAddFields(FirmMemberDTO firmMemberDto)
        {
            FirmMember firmMember = new FirmMember();
            firmMember.Id = firmMemberDto.Id;
            firmMember.FirmNumber = firmMemberDto.FirmNumber;
            firmMember.InsertUser = firmMemberDto.InsertUser;
            firmMember.ContactInfo = new ContactInfo();
            populateFirmMemberUpdateFields(firmMember, firmMemberDto);
            return firmMember;
        }
        public static void populateFirmMemberUpdateFields(FirmMember firmMember, FirmMemberDTO firmMemberDto)
        {
            firmMember.FirstName = firmMemberDto.FirstName;
            firmMember.MiddleName = firmMemberDto.MiddleName;
            firmMember.LastName = firmMemberDto.LastName;
            firmMember.JoiningDate = firmMemberDto.JoiningDate;
            firmMember.Qualification = firmMemberDto.Qualification;
            firmMember.Description = firmMemberDto.Description;
            DTOToDomainUtil.copyToContactInfo(firmMember.ContactInfo, firmMemberDto.ContactInfo);
            firmMember.Salutation = DTOToDomainUtil.copyMasterControlId(firmMember.Salutation, firmMemberDto.Salutation);
            firmMember.UpdateDate = DateTime.Now;
            firmMember.Version = firmMemberDto.Version;
            firmMember.UpdateUser = firmMemberDto.UpdateUser;
        }
        //Firm Account Deposites
        public static PropertyFunds populatePropertyFundsAddFields(PropertyFundsDTO propertyFundsDTO)
        {
            PropertyFunds propertyFunds = new PropertyFunds();
            propertyFunds.Id = propertyFundsDTO.Id;
            propertyFunds.TxDate = propertyFundsDTO.TxDate;
            propertyFunds.Amount = propertyFundsDTO.Amount;
            propertyFunds.PymtMethod = propertyFundsDTO.PymtMethod;
            propertyFunds.BankName = propertyFundsDTO.BankName;
            propertyFunds.Branch = propertyFundsDTO.Branch;
            propertyFunds.MediaNo = propertyFundsDTO.MediaNo;
            propertyFunds.ChequeDate = propertyFundsDTO.ChequeDate;
            propertyFunds.PymtStatus = propertyFundsDTO.Status;
            propertyFunds.PayName = propertyFundsDTO.PayName;
            propertyFunds.FirmNumber = propertyFundsDTO.FirmNumber;
            propertyFunds.InsertDate = DateTime.Now;
            propertyFunds.InsertUser = propertyFundsDTO.InsertUser;
            propertyFunds.FirmAccount = DTOToDomainUtil.copyFirmAccountId(propertyFunds.FirmAccount, propertyFundsDTO.FirmAccount);
            propertyFunds.Property =  DTOToDomainUtil.copyPropertyId(propertyFunds.Property, propertyFundsDTO.Property);
            populateFirmAcntDepositeUpdateFields(propertyFunds, propertyFundsDTO);
            return propertyFunds;
        }
        public static void populateFirmAcntDepositeUpdateFields(PropertyFunds propertyFunds, PropertyFundsDTO propertyFundsDTO)
        {
            propertyFunds.Comments = propertyFundsDTO.Comments;
            propertyFunds.UpdateDate = DateTime.Now;
            propertyFunds.UpdateUser = propertyFundsDTO.UpdateUser;
            propertyFunds.Version = propertyFundsDTO.Version;
        }
        //Property
        public static Property populatePropertyAddFields(PropertyDTO propertyDto)
        {
            Property property = new Property();
            property.ContactInfo = new ContactInfo();
            property.PropertyFMAccess = new HashSet<PropertyFMAccess>();
            property.Id = propertyDto.Id;
            property.Name = propertyDto.Name;
            property.FirmNumber = propertyDto.FirmNumber;
            property.InsertUser = propertyDto.InsertUser;
            populatePropertyUpdateFields(property, propertyDto);
            return property;
        }
        public static void populatePropertyUpdateFields(Property property, PropertyDTO propertyDto)
        {
            DTOToDomainUtil.copyToContactInfo(property.ContactInfo, propertyDto.ContactInfo);
            property.PropertyType = DTOToDomainUtil.copyMasterControlId(property.PropertyType, propertyDto.PropertyType);
            property.PropertyLocation = DTOToDomainUtil.copyMasterControlId(property.PropertyLocation, propertyDto.PropertyLocation);
            property.PropertyArea = propertyDto.PropertyArea;
            property.ReraRegNo = propertyDto.ReraRegNo;
            property.Description = propertyDto.Description;
            property.EstimatedAmt = propertyDto.EstimatedAmt;
            property.FirmAccount = DTOToDomainUtil.copyFirmAccountId(property.FirmAccount, propertyDto.FirmAccount);
            property.UpdateDate = DateTime.Now;
            property.UpdateUser = propertyDto.UpdateUser;
            property.Version = propertyDto.Version;
            populatePropertyChildEntity(property, propertyDto);
        }
        private static void populatePropertyChildEntity(Property property, PropertyDTO propertyDto)
        {
            if (propertyDto.PropertyTowers != null)
            {
                ISet<PropertyTower> propertyTowers = property.PropertyTowers;
                ISet<PropertyTowerDTO> propertyTowerDtos = propertyDto.PropertyTowers;
                if (propertyTowers != null && propertyTowers.Count > 0)
                {
                    for (int i = 0; i < propertyTowers.Count; i++)
                    {
                        PropertyTower propertyTower = propertyTowers.ElementAt(i);
                        PropertyTowerDTO propertyTowerDto = propertyTowerDtos.FirstOrDefault(x => x.Id == propertyTower.Id);
                        if (propertyTowerDto == null)
                        {
                            propertyTowers.Remove(propertyTower);
                            i--;
                        }
                        else
                        {
                            DTOToDomainUtil.populatePropertyTowerUpdateFields(propertyTower, propertyTowerDto);
                        }
                    }
                }
                foreach (PropertyTowerDTO propertyTowerDto in propertyTowerDtos)
                {
                    if (propertyTowerDto.Id < 1)
                    {
                        PropertyTower propertyTower = DTOToDomainUtil.populatePropertyTowerAddFields(propertyTowerDto);
                        propertyTower.Property = property;
                        property.PropertyTowers.Add(propertyTower);
                    }
                }
            }
            else
            {
                property.PropertyTowers.Clear();
            }
            if (propertyDto.PropertyTaxDetails != null)
            {
                ISet<PropertyTaxDetail> propertyTaxDetails = property.PropertyTaxDetails;
                ISet<PropertyTaxDetailDTO> propertyTaxDetailDtos = propertyDto.PropertyTaxDetails;
                if (propertyTaxDetails != null && propertyTaxDetails.Count > 0)
                {
                    for (int i = 0; i < propertyTaxDetails.Count; i++)
                    {
                        PropertyTaxDetail propertyTaxDetail = propertyTaxDetails.ElementAt(i);
                        PropertyTaxDetailDTO propertyTaxDetailDto = propertyTaxDetailDtos.FirstOrDefault(x => x.Id == propertyTaxDetail.Id);
                        if (propertyTaxDetailDto == null)
                        {
                            propertyTaxDetails.Remove(propertyTaxDetail);
                            i--;
                        }
                        else
                        {
                            DTOToDomainUtil.populatePropertyTaxDetailUpdateFields(propertyTaxDetail, propertyTaxDetailDto);
                        }
                    }
                }
                foreach (PropertyTaxDetailDTO propertyTaxDetailDto in propertyTaxDetailDtos)
                {
                    if (propertyTaxDetailDto.Id < 1)
                    {
                        PropertyTaxDetail propertyTaxDetail = DTOToDomainUtil.populatePropertyTaxDetailAddFields(propertyTaxDetailDto);
                        propertyTaxDetail.Property = property;
                        property.PropertyTaxDetails.Add(propertyTaxDetail);
                    }
                }
            }
            else
            {
                property.PropertyTaxDetails.Clear();
            }
            if (propertyDto.PropertyCharges != null)
            {
                ISet<PropertyCharge> propertyChargeDetails = property.PropertyCharges;
                ISet<PropertyChargeDTO> propertyChargeDetailDtos = propertyDto.PropertyCharges;
                if (propertyChargeDetails != null && propertyChargeDetails.Count > 0)
                {
                    for (int i = 0; i < propertyChargeDetails.Count; i++)
                    {
                        PropertyCharge propertyChargeDetail = propertyChargeDetails.ElementAt(i);
                        PropertyChargeDTO propertyChargeDetailDto = propertyChargeDetailDtos.FirstOrDefault(x => x.Id == propertyChargeDetail.Id);
                        if (propertyChargeDetailDto == null)
                        {
                            propertyChargeDetails.Remove(propertyChargeDetail);
                            i--;
                        }
                        else
                        {
                            DTOToDomainUtil.populatePropertyChargeDetailUpdateFields(propertyChargeDetail, propertyChargeDetailDto);
                        }
                    }
                }
                foreach (PropertyChargeDTO propertyChargeDetailDto in propertyChargeDetailDtos)
                {
                    if (propertyChargeDetailDto.Id < 1)
                    {
                        PropertyCharge propertyChargeDetail = DTOToDomainUtil.populatePropertyChargeDetailAddFields(propertyChargeDetailDto);
                        propertyChargeDetail.Property = property;
                        property.PropertyCharges.Add(propertyChargeDetail);
                    }
                }
            }
            else
            {
                property.PropertyCharges.Clear();
            }
        }
        //Property Tower
        public static PropertyTower populatePropertyTowerAddFields(PropertyTowerDTO propertyTowerDto)
        {
            PropertyTower propertyTower = new PropertyTower();
            propertyTower.Id = propertyTowerDto.Id;
            propertyTower.Name = propertyTowerDto.Name;
            propertyTower.Property = DTOToDomainUtil.copyPropertyId(propertyTower.Property, propertyTowerDto.Property);
            propertyTower.FirmNumber = propertyTowerDto.FirmNumber;
            propertyTower.InsertUser = propertyTowerDto.InsertUser;
            populatePropertyTowerUpdateFields(propertyTower, propertyTowerDto);
            return propertyTower;
        }
        public static void populatePropertyTowerUpdateFields(PropertyTower propertyTower, PropertyTowerDTO propertyTowerDto)
        {
            propertyTower.Rate = propertyTowerDto.Rate;
            propertyTower.LaunchDate = propertyTowerDto.LaunchDate;
            propertyTower.Possession = propertyTowerDto.Possession;
            propertyTower.Description = propertyTowerDto.Description;
            propertyTower.UpdateDate = DateTime.Now;
            propertyTower.UpdateUser = propertyTowerDto.UpdateUser;
            propertyTower.Version = propertyTowerDto.Version;
        }
        //Property Parking
        public static PropertyParking populatePropertyParkingAddFields(PropertyParkingDTO propertyParkingDto)
        {
            PropertyParking propertyParking = new PropertyParking();
            propertyParking.Id = propertyParkingDto.Id;
            propertyParking.ParkingNo = propertyParkingDto.ParkingNo;
            propertyParking.PropertyTower = DTOToDomainUtil.copyPropertyTowerId(propertyParking.PropertyTower, propertyParkingDto.PropertyTower);
            propertyParking.FirmNumber = propertyParkingDto.FirmNumber;
            propertyParking.InsertUser = propertyParkingDto.InsertUser;
            populatePropertyParkingUpdateFields(propertyParking, propertyParkingDto);
            return propertyParking;
        }
        public static void populatePropertyParkingUpdateFields(PropertyParking propertyParking, PropertyParkingDTO propertyParkingDto)
        {
            propertyParking.ParkingType = DTOToDomainUtil.copyMasterControlId(propertyParking.ParkingType, propertyParkingDto.ParkingType);
            propertyParking.Area = propertyParkingDto.Area;
            propertyParking.CommonParking = propertyParkingDto.CommonParking;
            propertyParking.Status = propertyParkingDto.Status;
            propertyParking.UpdateDate = DateTime.Now;
            propertyParking.UpdateUser = propertyParkingDto.UpdateUser;
            propertyParking.Version = propertyParkingDto.Version;
        }
        //PropertySchedule
        public static PropertySchedule populatePropertyScheduleAddFields(PropertyScheduleDTO propertyScheduleDto)
        {
            PropertySchedule propertySchedule = new PropertySchedule();
            propertySchedule.Id = propertyScheduleDto.Id;
            propertySchedule.StageNumber = propertyScheduleDto.StageNumber;
            propertySchedule.PropertyTower = DTOToDomainUtil.copyPropertyTowerId(propertySchedule.PropertyTower, propertyScheduleDto.PropertyTower);
            propertySchedule.FirmNumber = propertyScheduleDto.FirmNumber;
            propertySchedule.InsertUser = propertyScheduleDto.InsertUser;
            populatePropertyScheduleUpdateFields(propertySchedule, propertyScheduleDto);
            return propertySchedule;
        }
        public static void populatePropertyScheduleUpdateFields(PropertySchedule propertySchedule, PropertyScheduleDTO propertyScheduleDto)
        {
            propertySchedule.StageAbbr = propertyScheduleDto.StageAbbr;
            propertySchedule.Stage = propertyScheduleDto.Stage;
            propertySchedule.Percentage = propertyScheduleDto.Percentage;
            propertySchedule.Status = propertyScheduleDto.Status;
            propertySchedule.UpdateDate = DateTime.Now;
            propertySchedule.UpdateUser = propertyScheduleDto.UpdateUser;
        }
        //PropertyTaxDetail
        public static PropertyTaxDetail populatePropertyTaxDetailAddFields(PropertyTaxDetailDTO propertyTaxDetailDto)
        {
            PropertyTaxDetail propertyTaxDetail = new PropertyTaxDetail();
            propertyTaxDetail.Id = propertyTaxDetailDto.Id;
            propertyTaxDetail.Property = DTOToDomainUtil.copyPropertyId(propertyTaxDetail.Property, propertyTaxDetailDto.Property);
            propertyTaxDetail.FirmNumber = propertyTaxDetailDto.FirmNumber;
            propertyTaxDetail.InsertUser = propertyTaxDetailDto.InsertUser;
            populatePropertyTaxDetailUpdateFields(propertyTaxDetail, propertyTaxDetailDto);
            return propertyTaxDetail;
        }
        public static void populatePropertyTaxDetailUpdateFields(PropertyTaxDetail propertyTaxDetail, PropertyTaxDetailDTO propertyTaxDetailDto)
        {
            propertyTaxDetail.TaxType = DTOToDomainUtil.copyMasterControlId(propertyTaxDetail.TaxType, propertyTaxDetailDto.TaxType);
            propertyTaxDetail.TaxPercentage = propertyTaxDetailDto.TaxPercentage;
            propertyTaxDetail.IncludeInTotalPymt = propertyTaxDetailDto.IncludeInTotalPymt;
            propertyTaxDetail.TaxAmtLimit = propertyTaxDetailDto.TaxAmtLimit;
            propertyTaxDetail.UpdateDate = DateTime.Now;
            propertyTaxDetail.UpdateUser = propertyTaxDetailDto.UpdateUser;
            propertyTaxDetail.Version = propertyTaxDetailDto.Version;
        }
        //PropertyChargeDetail
        public static PropertyCharge populatePropertyChargeDetailAddFields(PropertyChargeDTO propertyChargeDetailDto)
        {
            PropertyCharge propertyChargeDetail = new PropertyCharge();
            propertyChargeDetail.Id = propertyChargeDetailDto.Id;
            propertyChargeDetail.Property = DTOToDomainUtil.copyPropertyId(propertyChargeDetail.Property, propertyChargeDetailDto.Property);
            propertyChargeDetail.FirmNumber = propertyChargeDetailDto.FirmNumber;
            propertyChargeDetail.InsertUser = propertyChargeDetailDto.InsertUser;
            populatePropertyChargeDetailUpdateFields(propertyChargeDetail, propertyChargeDetailDto);
            return propertyChargeDetail;
        }
        public static void populatePropertyChargeDetailUpdateFields(PropertyCharge propertyChargeDetail, PropertyChargeDTO propertyChargeDetailDto)
        {
            propertyChargeDetail.ChargeType = DTOToDomainUtil.copyMasterControlId(propertyChargeDetail.ChargeType, propertyChargeDetailDto.ChargeType);
            propertyChargeDetail.ChargeValue = propertyChargeDetailDto.ChargeValue;
            propertyChargeDetail.UpdateDate = DateTime.Now;
            propertyChargeDetail.UpdateUser = propertyChargeDetailDto.UpdateUser;
            propertyChargeDetail.Version = propertyChargeDetailDto.Version;
        }
        //Customer
        public static Customer populateCustomerAddFields(CustomerDTO customerDto)
        {
            Customer customer = new Customer();
            customer.Id = customerDto.Id;
            customer.Salutation = DTOToDomainUtil.copyMasterControlId(customer.Salutation, customerDto.Salutation);
            customer.CustRefNo = customerDto.CustRefNo;
            customer.FirstName = customerDto.FirstName;
            customer.MiddleName = customerDto.MiddleName;
            customer.LastName = customerDto.LastName;

            customer.FirmNumber = customerDto.FirmNumber;
            customer.InsertUser = customerDto.InsertUser;
            customer.InsertDate = DateTime.Now;
            customer.ContactInfo = new ContactInfo();
            populateCustomerUpdateFields(customer, customerDto);
            return customer;
        }
        public static void populateCustomerUpdateFields(Customer customer, CustomerDTO customerDto)
        {
        	customer.FamilyRelationship = customerDto.FamilyRelationship;
        	customer.FamilyRelName = customerDto.FamilyRelName;
            customer.Pan = customerDto.Pan;
            customer.PassportNo = customerDto.PassportNo;
            customer.AadharNo = customerDto.AadharNo;
            customer.Fax = customerDto.Fax;
            customer.Groupname = customerDto.Groupname;
            customer.Taxclassification = customerDto.Taxclassification;
            customer.Taxtype = customerDto.Taxtype;
            customer.Billwise = customerDto.Billwise;
            customer.Currency = customerDto.Currency;
            customer.Tallystatus = customerDto.Tallystatus;
            customer.Occupation = DTOToDomainUtil.copyMasterControlId(customer.Occupation, customerDto.Occupation);
            customer.Nationality = DTOToDomainUtil.copyCountryId(customer.Nationality, customerDto.Nationality);
            customer.ResidentialStatus = DTOToDomainUtil.copyMasterControlId(customer.ResidentialStatus, customerDto.ResidentialStatus);
            DTOToDomainUtil.copyToContactInfo(customer.ContactInfo, customerDto.ContactInfo);
            customer.UpdateDate = DateTime.Now;
            customer.Version = customerDto.Version;
            customer.InsertUser = customerDto.InsertUser;
            customer.UpdateUser = customerDto.UpdateUser;
        }

        public static void copyTocoCustomer(CoCustomer cocustomer, CoCustomerDTO cocustomerDto)
        {
            if (cocustomerDto != null)
            {
                cocustomer.Id = cocustomerDto.Id;
                cocustomer.SalutationId = DTOToDomainUtil.copyMasterControlId(cocustomer.SalutationId, cocustomerDto.SalutationId);
                cocustomer.FirstName = cocustomerDto.FirstName;
                cocustomer.MiddleName = cocustomerDto.MiddleName;
                cocustomer.LastName = cocustomerDto.LastName;
                cocustomer.RelationWhPrimCust = DTOToDomainUtil.copyMasterControlId(cocustomer.RelationWhPrimCust, cocustomerDto.RelationWhPrimCust);
                cocustomer.Occupation = DTOToDomainUtil.copyMasterControlId(cocustomer.Occupation, cocustomerDto.Occupation);
                cocustomer.Pan = cocustomerDto.Pan;
                cocustomer.IsPoa = cocustomerDto.IsPoa;
                cocustomer.FirmNumber = cocustomerDto.FirmNumber;
                cocustomer.ContactInfo = new ContactInfo();
                DTOToDomainUtil.copyToContactInfo(cocustomer.ContactInfo, cocustomerDto.ContactInfo);
            }
        }
        //Property Unit

        public static void populatePropertyUnitUpdateFields(PropertyUnit propertyUnit, PropertyUnitDTO propertyUnitDTO)
        {
            propertyUnit.PropertyTower = DTOToDomainUtil.copyPropertyTowerId(propertyUnit.PropertyTower, propertyUnitDTO.PropertyTower);
            propertyUnit.UnitType = DTOToDomainUtil.copyMasterControlId(propertyUnit.UnitType, propertyUnitDTO.UnitType);
            propertyUnit.Wing = propertyUnit.Wing;
            propertyUnit.FloorNo = propertyUnit.FloorNo;
            propertyUnit.UnitNo = propertyUnit.UnitNo;
            propertyUnit.BuildupArea = propertyUnit.BuildupArea;
            propertyUnit.CarpetArea = propertyUnit.CarpetArea;
            propertyUnit.BalconyArea = propertyUnit.BalconyArea;
            propertyUnit.NoOfBalcony = propertyUnit.NoOfBalcony;
            propertyUnit.Facing = DTOToDomainUtil.copyMasterControlId(propertyUnit.Facing, propertyUnitDTO.Facing);
            propertyUnit.Status = propertyUnit.Status;
            propertyUnit.Direction = DTOToDomainUtil.copyMasterControlId(propertyUnit.Direction, propertyUnitDTO.Direction);
            propertyUnit.Version = propertyUnitDTO.Version;
            propertyUnit.UpdateDate = DateTime.Now;
            propertyUnit.UpdateUser = propertyUnitDTO.UpdateUser;
        }

        public static PropertyExpense populateExpensesDetailAddFields(PropertyExpenseDTO propertyExpenseDTO)
        {
            PropertyExpense propertyExpense = new PropertyExpense();
            propertyExpense.FirmNumber = propertyExpenseDTO.FirmNumber;
            propertyExpense.InsertUser = propertyExpenseDTO.InsertUser;
            populateExpensesDetailUpdateFields(propertyExpense, propertyExpenseDTO);
            return propertyExpense;
        }
        public static void populateExpensesDetailUpdateFields(PropertyExpense propertyExpense, PropertyExpenseDTO propertyExpenseDTO)
        {
            propertyExpense.Property = DTOToDomainUtil.copyPropertyId(propertyExpense.Property, propertyExpenseDTO.Property);
            propertyExpense.Agency = DTOToDomainUtil.copyAgencyId(propertyExpense.Agency, propertyExpenseDTO.Agency);
            propertyExpense.ExpenseDate = propertyExpenseDTO.ExpenseDate;
            propertyExpense.ExpenseType = DTOToDomainUtil.copyMasterControlId(propertyExpense.ExpenseType, propertyExpenseDTO.ExpenseType);
            propertyExpense.FirmMember = DTOToDomainUtil.copyFirmMemberId(propertyExpense.FirmMember, propertyExpenseDTO.FirmMember);
            propertyExpense.Amount = propertyExpenseDTO.Amount;
            propertyExpense.Comments = propertyExpenseDTO.Comments;
            propertyExpense.UpdateDate = DateTime.Now;
            propertyExpense.UpdateUser = propertyExpenseDTO.UpdateUser;
            propertyExpense.Version = propertyExpenseDTO.Version;
        }
        public static void copyToEmailSMSAlert(EmailSmsAlertConfig emailSmsAlertConfig, EmailSmsAlertConfigDTO emailSmsAlertConfigDTO)
        {
            emailSmsAlertConfig.Id = emailSmsAlertConfigDTO.Id;
        }
        public static void populatePropertyAlertUpdateFields(PropertyAlertConfig propertyAlertConfig,
            PropertyAlertConfigDTO propertyAlertConfigDTO)
        {
            propertyAlertConfig.Sms = propertyAlertConfigDTO.Sms;
            propertyAlertConfig.Email = propertyAlertConfigDTO.Email;
            propertyAlertConfig.EmailConfig = new EmailConfig();
            propertyAlertConfig.EmailConfig.Id = propertyAlertConfigDTO.EmailConfigDTO.Id;
            propertyAlertConfig.UpdateUser = propertyAlertConfigDTO.UpdateUser;
            propertyAlertConfig.UpdateDate = propertyAlertConfigDTO.UpdateDate;
        }
        public static void populateUserProfileUpdateFields(UserDefinition userdefination, UserDefinitionDTO userdefinationDto)
        {
            userdefination.FirmMember.ContactInfo.Dob = userdefinationDto.FirmMember.ContactInfo.Dob;
            userdefination.FirmMember.ContactInfo.Contact = userdefinationDto.FirmMember.ContactInfo.Contact;
            userdefination.FirmMember.ContactInfo.AltContact = userdefinationDto.FirmMember.ContactInfo.AltContact;
            userdefination.ProfileImg = userdefinationDto.ProfileImg;
            userdefination.FirmMember.UpdateDate = DateTime.Now;
        }
        public static void populatePaymentVoucherAddFields(PaymentVoucher paymentVoucher, PaymentVoucherDTO paymentVoucherDto)
        {
           	paymentVoucher.Action = paymentVoucherDto.Action;
        	paymentVoucher.VoucherType = paymentVoucherDto.VoucherType;
        	paymentVoucher.VoucherDate = paymentVoucherDto.VoucherDate;
        	paymentVoucher.VoucherNaration = paymentVoucherDto.VoucherNaration;
        	paymentVoucher.VoucherNumber = paymentVoucherDto.VoucherNumber;
        	paymentVoucher.PartyLedgerName = paymentVoucherDto.PartyLedgerName;
        	paymentVoucher.VoucherEffectiveDate = paymentVoucherDto.VoucherEffectiveDate;
        	paymentVoucher.CstFromIssueType = paymentVoucherDto.CstFromIssueType;
        	paymentVoucher.CstFromRecvType = paymentVoucherDto.CstFromRecvType;
        	paymentVoucher.FbtPaymentType = paymentVoucherDto.FbtPaymentType;
        	paymentVoucher.PersistedView = paymentVoucherDto.PersistedView;
        	paymentVoucher.VchgstClass = paymentVoucherDto.VchgstClass;
        	paymentVoucher.HasCashFlow = paymentVoucherDto.HasCashFlow;
        	paymentVoucher.TallyPostingStatus = paymentVoucherDto.PostingStatus;
        	if (paymentVoucherDto.PaymentLedgers != null && paymentVoucherDto.PaymentLedgers.Count > 0)
            {
                paymentVoucher.PaymentLedgers = new HashSet<PaymentLedger>();
                foreach (PaymentLedgerDTO paymentLedgerDto in paymentVoucherDto.PaymentLedgers)
                {
                	PaymentLedger paymentLedger = new PaymentLedger();
                    DTOToDomainUtil.populatePaymentLedgerAddFields(paymentLedger, paymentLedgerDto);
                    paymentLedger.PaymentVoucher = paymentVoucher;
                    paymentVoucher.PaymentLedgers.Add(paymentLedger);
                }
            }
            populatePaymentVoucherUpdateFields(paymentVoucher, paymentVoucherDto);
       
            paymentVoucher.FirmNumber = paymentVoucherDto.FirmNumber;
            paymentVoucher.InsertUser = paymentVoucherDto.InsertUser;
            paymentVoucher.InsertDate = DateTime.Now;
        }
        public static void populatePaymentLedgerAddFields(PaymentLedger paymentLedger, PaymentLedgerDTO paymentLedgerDto)
        {
        	paymentLedger.LedgerName = paymentLedgerDto.LedgerName;
        	paymentLedger.LedgerType = paymentLedgerDto.LedgerType;
        	paymentLedger.IsDeemedPositive = paymentLedgerDto.IsDeemedPositive;
        	paymentLedger.LedgerFromItem = paymentLedgerDto.LedgerFromItem;
        	paymentLedger.RemoveZeroEntries = paymentLedgerDto.RemoveZeroEntries;
        	paymentLedger.IsPartyLedger = paymentLedgerDto.IsPartyLedger;
        	paymentLedger.IsLastDeemedPositive = paymentLedgerDto.IsLastDeemedPositive;
        	paymentLedger.Amount = paymentLedgerDto.Amount;
        	paymentLedger.VatexpAmount = paymentLedgerDto.VatexpAmount;
        	if (paymentLedgerDto.BillAllocations != null && paymentLedgerDto.BillAllocations.Count > 0)
            {
                paymentLedger.BillAllocations = new HashSet<BillAllocation>();
                foreach (BillAllocationDTO billAllocationDto in paymentLedgerDto.BillAllocations)
                {
                	BillAllocation billAllocation = new BillAllocation();
                    populateBillAllocationAddFields(billAllocation, billAllocationDto);
                    billAllocation.PaymentLedger = paymentLedger;
                    paymentLedger.BillAllocations.Add(billAllocation);
                }
            }
        	if (paymentLedgerDto.BankAllocations != null && paymentLedgerDto.BankAllocations.Count > 0)
            {
                paymentLedger.BankAllocations = new HashSet<BankAllocation>();
                foreach (BankAllocationDTO bankAllocationDto in paymentLedgerDto.BankAllocations)
                {
                	BankAllocation bankAllocation = new BankAllocation();
                    populateBankAllocationAddFields(bankAllocation, bankAllocationDto);
                    bankAllocation.PaymentLedger = paymentLedger;
                	paymentLedger.BankAllocations.Add(bankAllocation);
                }
            }
        	paymentLedger.FirmNumber = paymentLedgerDto.FirmNumber;
            paymentLedger.InsertDate = DateTime.Now; ;
        	paymentLedger.InsertUser = paymentLedgerDto.InsertUser;
        	paymentLedger.UpdateUser = paymentLedgerDto.UpdateUser;
            paymentLedger.UpdateDate = DateTime.Now; ;
        	paymentLedger.Version = paymentLedgerDto.Version;
        }
        public static void populateBillAllocationAddFields(BillAllocation billAllocation, BillAllocationDTO billAllocationDto)
        {
        	billAllocation.Name = billAllocationDto.Name;
        	billAllocation.BillType = billAllocationDto.BillType;
        	billAllocation.TdsDeductSpecialRate = billAllocationDto.TdsDeductSpecialRate;
        	billAllocation.Amount = billAllocationDto.Amount;
        	billAllocation.FirmNumber = billAllocationDto.FirmNumber;
            billAllocation.InsertDate = DateTime.Now; ;
        	billAllocation.InsertUser = billAllocationDto.InsertUser;
        	billAllocation.UpdateUser = billAllocationDto.UpdateUser;
            billAllocation.UpdateDate = DateTime.Now; ;
        	billAllocation.Version = billAllocationDto.Version;
        }
        public static void populateBankAllocationAddFields(BankAllocation bankAllocation, BankAllocationDTO bankAllocationDto)
        {
        	bankAllocation.BDate = bankAllocationDto.BDate;
        	bankAllocation.InstrumentDate = bankAllocationDto.InstrumentDate;
        	bankAllocation.Name = bankAllocationDto.Name;
        	bankAllocation.TransactionType = bankAllocationDto.TransactionType;
        	bankAllocation.BankName = bankAllocationDto.BankName;
        	bankAllocation.BankBranchName = bankAllocationDto.BankBranchName;
        	bankAllocation.PaymentFavouring = bankAllocationDto.PaymentFavouring;
        	bankAllocation.ChequeCrossComment = bankAllocationDto.ChequeCrossComment;
        	bankAllocation.InstrumentNumber = bankAllocationDto.InstrumentNumber;
        	bankAllocation.UniqueReferenceNumber = bankAllocationDto.UniqueReferenceNumber;
        	bankAllocation.Status = bankAllocationDto.Status;
        	bankAllocation.PaymentMode = bankAllocationDto.PaymentMode;
        	bankAllocation.BankPartyName = bankAllocationDto.BankPartyName;
        	bankAllocation.IsConnectedPayment = bankAllocationDto.IsConnectedPayment;
        	bankAllocation.IsSplit = bankAllocationDto.IsSplit;
        	bankAllocation.ChequePrinted = bankAllocationDto.ChequePrinted;
        	bankAllocation.IsContractUsed = bankAllocationDto.IsContractUsed;
        	bankAllocation.Amount = bankAllocationDto.Amount;
        	bankAllocation.FirmNumber = bankAllocationDto.FirmNumber;
            bankAllocation.InsertDate = DateTime.Now; ;
        	bankAllocation.InsertUser = bankAllocationDto.InsertUser;
        	bankAllocation.UpdateUser = bankAllocationDto.UpdateUser;
            bankAllocation.UpdateDate = DateTime.Now; 
        	bankAllocation.Version = bankAllocationDto.Version;
        }
        public static void populatePaymentVoucherUpdateFields(PaymentVoucher paymentVoucher, PaymentVoucherDTO paymentVoucherDTO)
        {
            paymentVoucher.Version = paymentVoucherDTO.Version;
            paymentVoucher.UpdateUser = paymentVoucherDTO.UpdateUser;
            paymentVoucher.UpdateDate = DateTime.Now;
        }
        //PortalUser
        public static PortalUser populatePortalUserAddFields(PortalUserDTO PortalUserDTO)
        {
            PortalUser PortalUser = new PortalUser();
            PortalUser.Id = PortalUserDTO.Id;
            PortalUser.FirmNumber = PortalUserDTO.FirmNumber;
            PortalUser.InsertUser = PortalUserDTO.UserName;
            PortalUser.InsertDate = DateTime.Now;
            populatePortalUserUpdateFields(PortalUser, PortalUserDTO);
            return PortalUser;
        }
        public static void populatePortalUserUpdateFields(PortalUser PortalUser, PortalUserDTO PortalUserDTO)
        {
            PortalUser.UserName = PortalUserDTO.UserName;
            PortalUser.Password = PortalUserDTO.Password;
            PortalUser.Email = PortalUserDTO.Email;
            PortalUser.UpdateDate = DateTime.Now;
            PortalUser.Version = PortalUserDTO.Version;
            PortalUser.UpdateUser = PortalUserDTO.UserName;
        }
        //Job History
        public static JobHistory populateJobHistoryAddFields(JobHistoryDTO jobHistoryDTO)
        {
            JobHistory jobHistory = new JobHistory();
            Job job = new Job();
            job.Id = jobHistoryDTO.Job.Id;
            jobHistory.Job = job;
            jobHistory.StartTime = jobHistoryDTO.StartTime;
            jobHistory.FirmNumber = jobHistoryDTO.FirmNumber;
            jobHistory.InsertUser = jobHistoryDTO.InsertUser;
            populateJobHistoryUpdateFields(jobHistory, jobHistoryDTO);
            return jobHistory;
        }
        public static void populateJobHistoryUpdateFields(JobHistory jobHistory, JobHistoryDTO jobHistoryDTO)
        {
            jobHistory.EndTime = jobHistoryDTO.EndTime;
            jobHistory.Message = jobHistoryDTO.Message;
            jobHistory.Status = jobHistoryDTO.JobRunStatus;
            jobHistory.Version = jobHistoryDTO.Version;
            jobHistory.UpdateDate = DateTime.Now;
            jobHistory.UpdateUser = jobHistoryDTO.UpdateUser;
        }
        //Notification
        public static Notification populateNotificationAddFields(NotificationDTO notificationDTO)
        {
            Notification notification = new Notification();
            notification.Type = notificationDTO.Type;
            notification.SubType = notificationDTO.SubType;
            notification.Message = notificationDTO.Message;
            notification.ScheduledDate = notificationDTO.ScheduledDate;
            notification.PropertyId = notificationDTO.PropertyId;
            notification.UserName = notificationDTO.UserName;
            notification.FirmNumber = notificationDTO.FirmNumber;
            notification.InsertUser = notificationDTO.InsertUser;
            populateNotificationUpdateFields(notification, notificationDTO);
            return notification;
        }
        public static void populateNotificationUpdateFields(Notification notification , NotificationDTO notificationDTO)
        {
            notification.Status = notificationDTO.Status;
            notification.Version = notificationDTO.Version;
            notification.UpdateDate = DateTime.Now;
            notification.UpdateUser = notificationDTO.UpdateUser;
        }
        //Call History
        public static CallHistory populateCallHistoryAddFields(CallHistoryDTO callHistoryDTO)
        {
            CallHistory callHistory = new CallHistory();
            callHistory.CallSid = callHistoryDTO.CallSid;
            callHistory.Direction = callHistoryDTO.Direction;
            callHistory.CallerNumber = callHistoryDTO.CallerNumber;
            callHistory.CalleeNumber = callHistoryDTO.CalleeNumber;
            callHistory.ParentCallSid = callHistoryDTO.ParentCallSid;
            callHistory.AccountSid = callHistoryDTO.AccountSid;
            callHistory.PhoneNumberSid = callHistoryDTO.PhoneNumberSid;
            callHistory.StartTime = callHistoryDTO.StartTime;
            callHistory.Uri= callHistoryDTO.Uri;
            callHistory.DateCreated = callHistoryDTO.DateCreated;
            callHistory.AnsweredBy = callHistoryDTO.AnsweredBy;
            callHistory.ForwardedFrom = callHistoryDTO.ForwardedFrom;
            callHistory.FirmMember = DTOToDomainUtil.copyFirmMemberId(callHistory.FirmMember, callHistoryDTO.FirmMember);
            callHistory.FirmNumber = callHistoryDTO.FirmNumber;
            callHistory.InsertUser = callHistoryDTO.InsertUser;
            populateCallHistoryUpdateFields(callHistory, callHistoryDTO);
            return callHistory;
        }
        public static void populateCallHistoryUpdateFields(CallHistory callHistory , CallHistoryDTO callHistoryDTO)
        {
            if(callHistoryDTO.PrUnitSaleDetail != null){
                callHistory.PrUnitSaleDetail = DTOToDomainUtil.copyPrUnitSaleDetailId(null, callHistoryDTO.PrUnitSaleDetail);
            }
            callHistory.CallStatus = callHistoryDTO.CallStatus;
            callHistory.CallHistoryStatus = callHistoryDTO.CallHistoryStatus;
            callHistory.EndTime = callHistoryDTO.EndTime;
            callHistory.Duration = callHistoryDTO.Duration;
            callHistory.Price = callHistoryDTO.Price;
            callHistory.CallerName = callHistoryDTO.CallerName;
            callHistory.RecordingUrl = callHistoryDTO.RecordingUrl;
            callHistory.RecordingFile = CommonUtil.downloadRecordingFile(callHistoryDTO.RecordingUrl);
            callHistory.DateUpdated = callHistoryDTO.DateUpdated;
            callHistory.Version = callHistoryDTO.Version;
            callHistory.UpdateDate = DateTime.Now;
            callHistory.UpdateUser = callHistoryDTO.UpdateUser;
        }

        public static void populateCallHistoryUpdateFieldsForInitimation(CallHistory callHistory, CallHistoryDTO callHistoryDTO)
        {
            callHistory.PhoneNumberSid = callHistoryDTO.PhoneNumberSid;
            callHistory.Direction = callHistoryDTO.Direction;
            callHistory.DateCreated = callHistoryDTO.DateCreated;
            callHistory.FirmMember = DTOToDomainUtil.copyFirmMemberId(callHistory.FirmMember, callHistoryDTO.FirmMember);
            callHistory.CalleeNumber = callHistoryDTO.CalleeNumber;
            callHistory.CallHistoryStatus = callHistoryDTO.CallHistoryStatus;
            callHistory.Version = callHistoryDTO.Version;
            callHistory.UpdateDate = DateTime.Now;
            callHistory.UpdateUser = callHistoryDTO.UpdateUser;
        }
        public static CallHistoryDTO populateCallHistoryDTOFromExotelCall(Call call, CallHistoryDTO callHistoryDTO, bool isIncoming)
        {
            callHistoryDTO.CallSid = call.Sid;
            callHistoryDTO.ParentCallSid = call.ParentCallSid;
            callHistoryDTO.DateCreated = call.DateCreated;
            callHistoryDTO.AccountSid = call.AccountSid;
            callHistoryDTO.CalleeNumber = call.To;
            callHistoryDTO.CallerNumber = call.From;
            callHistoryDTO.PhoneNumberSid = call.PhoneNumberSid;
            callHistoryDTO.StartTime = (call.StartTime != null) ? call.StartTime.Value : DateTime.Now;
            if (isIncoming) callHistoryDTO.Direction = CallDirection.Incoming;
            else callHistoryDTO.Direction = CallDirection.Outgoing;
            callHistoryDTO.Uri= call.Uri;
            callHistoryDTO.CallStatus = CommonUtil.getCallStatus(call.Status.ToString());
            callHistoryDTO.DateUpdated = call.DateUpdated;
            callHistoryDTO.EndTime = call.EndTime;
            callHistoryDTO.Duration = call.Duration;
            callHistoryDTO.Price = call.Price;
            callHistoryDTO.AnsweredBy = call.AnsweredBy;
            callHistoryDTO.ForwardedFrom = call.ForwardedFrom;
            callHistoryDTO.CallerName = call.CallerName;
            callHistoryDTO.RecordingUrl = call.RecordingUrl;
            return callHistoryDTO;
        }
    }
}