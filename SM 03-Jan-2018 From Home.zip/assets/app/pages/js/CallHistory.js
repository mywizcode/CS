﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initCallHistorySearchGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}
function initCallHistorySearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        sorting: false,
        pageLength: 10
    };

    $("[id$='callHistorySearchGrid']").CSBasicDatatable(dtOptions);
}






