﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initAvailableUnitSearchGrid();
    formatFields();
    showModal();
}

function initAvailableUnitSearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        rowInfoModalTitle: "Unit Details",
        pageLength: 10
    };

    $("[id$='availableUnitSearchGrid']").CSBasicDatatable(dtOptions);
}




