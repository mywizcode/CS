﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initVoucherSearchGrid();
    formatFields();
    showModal();
}

function initVoucherSearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#voucherSearchBtnDiv",
        pageLength: 10
    };

    $("[id$='voucherSearchGrid']").CSBasicDatatable(dtOptions);
}



