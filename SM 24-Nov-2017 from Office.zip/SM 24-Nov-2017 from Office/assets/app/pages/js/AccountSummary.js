﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initAccountSummarySearchGrid();
    formatFields();
    showModal();
}

function initAccountSummarySearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        customBtnGrpId: "#accountSearchBtnDiv",
        rowInfoModalTitle: "Account Details",
        pageLength: 10
    };

    $("[id$='AccountSummarySearchGrid']").CSBasicDatatable(dtOptions);
}





