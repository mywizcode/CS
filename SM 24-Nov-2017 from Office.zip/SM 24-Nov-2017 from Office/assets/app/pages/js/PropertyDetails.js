﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initPrTowerGrid();
    initPrTaxGrid();
    initPrChargesGrid();
    formatFields();
    showModal();
}
function initPrTowerGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: isViewOnly,
        customBtnGrpId: "#prTowerSearchBtnDiv",
        rowInfoModalTitle: "Tower Details",
        pageLength: 5,
        hideSearch: true
    };

    $("[id$='propertyTowerGrid']").CSBasicDatatable(dtOptions);
}
function initPrTaxGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: isViewOnly,
        customBtnGrpId: "#taxDetailGridBtnGrp",
        rowInfoModalTitle: "Tax Details",
        pageLength: 5,
        hideSearch: true
    };

    $("[id$='taxDetailGrid']").CSBasicDatatable(dtOptions);
}
function initPrChargesGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: isViewOnly,
        customBtnGrpId: "#chargesDetailGridBtnGrp",
        rowInfoModalTitle: "Property Charge Details",
        pageLength: 5,
        hideSearch: true
    };

    $("[id$='propertyChargesGrid']").CSBasicDatatable(dtOptions);
}




