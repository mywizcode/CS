﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using ConstroSoft;
using ConstroSoft.Logic.BO;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Drawing;
using System.Web.UI.HtmlControls;

public partial class PropertyParkingSearch : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string SearchFilterModal = "SearchFilterModal";
    DropdownBO drpBO = new DropdownBO();
    PropertyBO propertyBO = new PropertyBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Form.Attributes.Add("enctype", "multipart/form-data");
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                PropertyParkingSearchNavDTO navDto = CommonUtil.getPageNavDTO<PropertyParkingSearchNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_PROPERTY_PARKING)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpTowerFilter, DrpDataType.PROPERTY_TOWER, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(), null, userDefDto.FirmNumber);
        drpTowerFilter.Text = CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Id.ToString();
        drpBO.drpDataBase(drpParkingTypeFilter, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_PARKING_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<CommonParking>(drpCommonParkingFilter, Constants.SELECT_ITEM);
        drpBO.drpEnum<ParkingStatus>(drpParkingStatusFilter, Constants.SELECT_ITEM);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(PropertyParkingSearchNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new PropertyParkingSearchPageDTO();
        initDropdowns();
        setSearchFilter(null);
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(PropertyParkingSearchNavDTO navDto)
    {
        try
        {
            if (navDto != null)
            {
                setSearchFilter(navDto.filterDTO);
            }
            loadPropertyParkingSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageFieldsWithEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        lnkAddPropertyParkingBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_PARKING_ADD);
        ulUploadParkingsAction.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_PARKING_ADD);
        if (propertyParkingSearchGrid.Rows.Count > 0)
        {
            for (var i = 0; i < propertyParkingSearchGrid.Rows.Count; i++)
            {
                HtmlGenericControl tmpBtn = (HtmlGenericControl)propertyParkingSearchGrid.Rows[i].FindControl("liModifyPropertyParkingBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_PARKING_MODIFY);
                tmpBtn = (HtmlGenericControl)propertyParkingSearchGrid.Rows[i].FindControl("liDeletePropertyParkingBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_PARKING_DELETE);
            }
        }
    }
    private void setSearchGrid(IList<PropertyParkingDTO> tmpList)
    {
        getSessionPageData().SearchResult = (tmpList != null) ? tmpList.ToList<PropertyParkingDTO>() : new List<PropertyParkingDTO>();
        assignUiIndexToParking(getSearchPropertyParkingList());
        propertyParkingSearchGrid.DataSource = getSearchPropertyParkingList();
        propertyParkingSearchGrid.DataBind();
    }
    private void assignUiIndexToParking(List<PropertyParkingDTO> unitDtos)
    {
        if (unitDtos != null && unitDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (PropertyParkingDTO parkingDTO in unitDtos)
            {
                parkingDTO.UiIndex = uiIndex++;
                parkingDTO.RowInfo = CommonUIConverter.getGridViewRowInfo(parkingDTO);
            }
        }
    }
    private PropertyParkingSearchPageDTO getSessionPageData()
    {
        return (PropertyParkingSearchPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<PropertyParkingDTO> getSearchPropertyParkingList()
    {
        return getSessionPageData().SearchResult;
    }
    private PropertyParkingDTO getSearchPropertyParkingDTO(long Id)
    {
        List<PropertyParkingDTO> searchList = getSearchPropertyParkingList();
        PropertyParkingDTO selectedPropertyParkingDTO = null;
        if (Id > 0 && searchList != null && searchList.Count > 0)
        {
            selectedPropertyParkingDTO = searchList.Find(c => c.Id == Id);
        }
        return selectedPropertyParkingDTO;
    }
    private void loadPropertyParkingSearchGrid()
    {
        IList<PropertyParkingDTO> results = propertyBO.fetchPropertyParkingGridData(getUserDefinitionDTO().FirmNumber, getSearchFilter(), long.Parse(drpTowerFilter.Text));
        setSearchGrid(results);
    }
    private PropertyParkingSearchNavDTO getCurrentPageNavigation()
    {
        PropertyParkingSearchPageDTO PageDTO = getSessionPageData();
        PropertyParkingSearchNavDTO navDTO = new PropertyParkingSearchNavDTO();
        navDTO.filterDTO = getSearchFilter();
        return navDTO;
    }
    private void navigateToPropertyParkingDetails(long selectedId, PageMode mode)
    {
        PropertyParkingDTO parkingDTO = getSearchPropertyParkingDTO(selectedId);
        PropertyParkingDetailNavDTO navDTO = new PropertyParkingDetailNavDTO();
        navDTO.Mode = mode;
        if (parkingDTO != null) navDTO.ParkingId = parkingDTO.Id;
        navDTO.PrevNavDto = getCurrentPageNavigation();
        Session[Constants.Session.NAV_DTO] = navDTO;
        Response.Redirect(Constants.URL.PROPERTY_PARKING_DETAILS, true);
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    protected void onClickAddPropertyParkingBtn(object sender, EventArgs e)
    {
        try
        {
            navigateToPropertyParkingDetails(0, PageMode.ADD);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickViewPropertyParkingBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            navigateToPropertyParkingDetails(selectedId, PageMode.VIEW);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyPropertyParkingBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            PageMode mode = (isValidForModify(selectedId)) ? PageMode.MODIFY : PageMode.VIEW;
            navigateToPropertyParkingDetails(selectedId, PageMode.MODIFY);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void deletePropertyParking(object sender, EventArgs e)
    {
        try
        {
            long selectedId = getDeleteRecordHdnId();
            if (validatePrParkingDelete(selectedId))
            {
                BusinessOutputTO outputTO = propertyBO.deletePropertyParkingDetails(selectedId);
                string msg = "";
                if (outputTO.status == BusinessOutputTO.Status.SUCCESS)
                {
                    msg = CommonUtil.getRecordDeleteSuccessMsg("Property Parking");
                }
                else
                {
                    propertyBO.updateParkingAsDeleted(selectedId);
                    msg = CommonUtil.getRecordSoftDeleteSuccessMsg("Property Parking");
                }
                setNotyMsg(CommonUtil.getNotySuccessMsg(msg));
                loadPropertyParkingSearchGrid();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool isValidForModify(long Id)
    {
        bool isValid = true;
        PropertyParkingDTO propertyParkingDto = getSearchPropertyParkingDTO(Id);
        if (propertyParkingDto.Status == ParkingStatus.Deleted)
        {
            isValid = false;
            Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotyInfoMsg("Selected Property Parking is deleted, cannot be modified."));
        }
        else if (propertyParkingDto.Status == ParkingStatus.Allotted)
        {
            isValid = false;
            Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotyInfoMsg("Selected Property Parking is Allotted, cannot be modified."));
        }
        return isValid;
    }
    private bool validatePrParkingDelete(long selectedId)
    {
        bool isValid = true;
        PropertyParkingDTO propertyParkingDTO = getSearchPropertyParkingDTO(selectedId);
        if (propertyParkingDTO.Status != ParkingStatus.Available)
        {
            isValid = false;
            setErrorMessage("Only Available property parkings can be deleted.", commonError);
        }
        return isValid;
    }
    protected void onClickUploadParkings(object sender, EventArgs e)
    {
        try
        {
            PropertyParkingUploadNavDTO navDTO = new PropertyParkingUploadNavDTO();
            navDTO.PrevNavDto = getCurrentPageNavigation();
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.PROPERTY_PARKING_UPLOAD, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Filter Criteria - Property Search - Start
    private PropertyParkingFilterDTO getSearchFilter()
    {
        return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            PropertyParkingFilterDTO filterDTO = getSearchFilter();
            drpBO.drpDataBase(drpParkingNoFilter, DrpDataType.PR_PARKING_SEARCH_BY_PARKINGNO, drpTowerFilter.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            if (filterDTO.ParkingId > 0) drpParkingNoFilter.Text = filterDTO.ParkingId.ToString(); else drpParkingNoFilter.ClearSelection();
            if (filterDTO.ParkingType != null) drpParkingTypeFilter.Text = filterDTO.ParkingType.Id.ToString(); else drpParkingTypeFilter.ClearSelection();
            if (filterDTO.Status != null) drpParkingStatusFilter.Text = filterDTO.Status.ToString(); else drpParkingStatusFilter.ClearSelection();
            if (filterDTO.CommonParking != null) drpCommonParkingFilter.Text = filterDTO.CommonParking.ToString(); else drpCommonParkingFilter.ClearSelection();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onSelectFilterTower(object sender, EventArgs e)
    {
        try
        {
            drpBO.drpDataBase(drpParkingNoFilter, DrpDataType.PR_PARKING_SEARCH_BY_PARKINGNO, drpTowerFilter.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            activeModalHdn.Value = SearchFilterModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            CommonUtil.setStickyPrTowerDTO(getUserDefinitionDTO(), long.Parse(drpTowerFilter.Text), drpTowerFilter.SelectedItem.Text);
            PropertyParkingFilterDTO filterDTO = new PropertyParkingFilterDTO();
            if (!string.IsNullOrWhiteSpace(drpParkingNoFilter.Text))
            {
                filterDTO.ParkingId = long.Parse(drpParkingNoFilter.Text);
                filterDTO.ParkingNo = drpParkingNoFilter.SelectedItem.Text;
            }
            if (!string.IsNullOrWhiteSpace(drpParkingTypeFilter.Text))
            {
                filterDTO.ParkingType = CommonUIConverter.getMasterControlDTO(drpParkingTypeFilter.Text, drpParkingTypeFilter.SelectedItem.Text);
            }
            if (!string.IsNullOrWhiteSpace(drpParkingStatusFilter.Text))
            {
                filterDTO.Status = EnumHelper.ToEnum<ParkingStatus>(drpParkingStatusFilter.Text);
            }
            if (!string.IsNullOrWhiteSpace(drpCommonParkingFilter.Text))
            {
                filterDTO.CommonParking = EnumHelper.ToEnum<CommonParking>(drpCommonParkingFilter.Text);
            }
            setSearchFilter(filterDTO);
            loadPropertyParkingSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            loadPropertyParkingSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(PropertyParkingFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new PropertyParkingFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {
            drpTowerFilter.Text = CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Id.ToString();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            PropertyParkingFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.PARKING_NO))
            {
                filterDTO.ParkingId = 0;
                filterDTO.ParkingNo = "";
            }
            else if (token.StartsWith(Constants.FILTER.PARKING_TYPE)) filterDTO.ParkingType = null;
            else if (token.StartsWith(Constants.FILTER.STATUS)) filterDTO.Status = null;
            else if (token.StartsWith(Constants.FILTER.COMMON_PARKING)) filterDTO.CommonParking = null;
            else if (token.StartsWith(Constants.FILTER.TOWER_NAME)) setNotyMsg(CommonUtil.getNotyInfoMsg(Resources.Messages.TOWER_FILTER_DEFAULT));
            setSearchFilterTokens();
            loadPropertyParkingSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        PropertyParkingFilterDTO filterDTO = getSearchFilter();
        string filter = CommonUtil.addFilterToken("", Constants.FILTER.TOWER_NAME + CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Name);
        if (filterDTO != null)
        {
            if (filterDTO.ParkingId > 0) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.PARKING_NO + filterDTO.ParkingNo);
            if (filterDTO.ParkingType != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.PARKING_TYPE + filterDTO.ParkingType.Name);
            if (filterDTO.Status != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.STATUS + filterDTO.Status.ToString());
            if (filterDTO.CommonParking != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.COMMON_PARKING + filterDTO.CommonParking.ToString());
        }
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - PropertyParking Search - End
    //Bulk Upload - Start
    protected void onClickDownloadTemplate(object sender, EventArgs e)
    {
        try
        {
            List<MasterControlDataDTO> resultsParkingType;
            fetchMaster(out resultsParkingType);
            if (resultsParkingType == null || resultsParkingType.Count <= 0)
            {
                setErrorMessage("Please add property parking types before downloading unit template.", commonError);
            }
            else
            {
                setResponse();
                using (ExcelPackage package = new ExcelPackage())
                {
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.Add(CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()).Name);

                    using (var range = worksheet.Cells["A1: k1048576"])
                    {
                        range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Top.Color.SetColor(Color.Black);
                        range.Style.Border.Bottom.Color.SetColor(Color.Green);
                        range.Style.Border.Left.Color.SetColor(Color.Blue);
                        range.Style.Border.Right.Color.SetColor(Color.Yellow);
                    }
                    prepareHeader(worksheet);
                    addValidationLists(resultsParkingType, worksheet);
                    package.Save();
                    using (MemoryStream MyMemoryStream = new MemoryStream())
                    {
                        package.SaveAs(MyMemoryStream);
                        MyMemoryStream.WriteTo(Response.OutputStream);
                        Response.Flush();
                        Response.End();
                    }
                }
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void addValidationLists(List<MasterControlDataDTO> resultsParkingType, ExcelWorksheet worksheet)
    {
        List<string> propertyList = new List<String>();
        propertyList.Add(CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()).Name);
        CommonUtil.addListValidation(worksheet, "A2:A1048576", propertyList);//Property
        CommonUtil.addListValidation(worksheet, "B2:B1048576", CommonUtil.getDropdownItemNames(drpTowerFilter));//Property Tower
        CommonUtil.addListValidation(worksheet, "D2:D1048576", CommonUtil.getMasterDataNames(resultsParkingType));//Parking Type
        CommonUtil.addListValidation(worksheet, "F2:F1048576", CommonUtil.getEnumValues(typeof(CommonParking)));//Common Parking
        CommonUtil.addListValidation(worksheet, "G2:G1048576", CommonUtil.getEnumValues(typeof(ParkingStatus)));//Parking Status
    }

    private void setResponse()
    {
        Response.Clear();
        Response.Buffer = true;
        Response.Charset = "";
        Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        Response.AddHeader("content-disposition", "attachment;filename=" + CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()).Name + ".xlsx");
    }

    private void fetchMaster(out List<MasterControlDataDTO> resultsParkingType)
    {
        resultsParkingType = masterDataBO.fetchMasterData(getUserDefinitionDTO().FirmNumber, Constants.MCDType.PR_PARKING_TYPE.ToString());
    }

    private void prepareHeader(ExcelWorksheet worksheet)
    {
        worksheet.Cells[1, 1].Value = "Property Name";
        worksheet.Cells[1, 2].Value = "Tower Name";
        worksheet.Cells[1, 3].Value = "Parking Number";
        worksheet.Cells[1, 4].Value = "Parking Type";
        worksheet.Cells[1, 5].Value = "Parking Area";
        worksheet.Cells[1, 6].Value = "Common Parking";
        worksheet.Cells[1, 7].Value = "Status";
        using (var range = worksheet.Cells[1, 1, 1, 7])
        {
            range.Style.Font.Bold = true;
            range.Style.Fill.PatternType = ExcelFillStyle.Solid;
            range.Style.Fill.BackgroundColor.SetColor(Color.Blue);
            range.Style.Font.Color.SetColor(Color.White);
        }
        worksheet.Cells["A1:G1048576"].AutoFilter = true;
        worksheet.Cells.AutoFitColumns(0);
    }
    private bool validateFileType(string extension)
    {
        bool isValid = true;
        if (extension != ".xlsx" && extension != ".xls")
        {
            isValid = false;
            setErrorMessage("Please Select Property Parking Excel with extension xlsx or xls.", commonError);
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    //Bulk Upload - End
}