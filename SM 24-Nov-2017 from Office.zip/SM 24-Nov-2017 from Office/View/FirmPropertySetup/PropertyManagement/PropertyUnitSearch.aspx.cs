﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using ConstroSoft;
using ConstroSoft.Logic.BO;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Drawing;
using System.Web.UI.HtmlControls;

public partial class PropertyUnitSearch : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string SearchFilterModal = "SearchFilterModal";
    DropdownBO drpBO = new DropdownBO();
    PropertyBO propertyBO = new PropertyBO();
    PropertyUnitManagementBO prUnitBO = new PropertyUnitManagementBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Form.Attributes.Add("enctype", "multipart/form-data");
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                PropertyUnitSearchNavDTO navDto = CommonUtil.getPageNavDTO<PropertyUnitSearchNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_PROPERTY_UNIT)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpTowerFilter, DrpDataType.PROPERTY_TOWER, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(), null, userDefDto.FirmNumber);
        drpTowerFilter.Text = CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Id.ToString();
        drpBO.drpDataBase(drpUnitTypeFilter, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<PRUnitStatus>(drpUnitStatusFilter, Constants.SELECT_ITEM);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(PropertyUnitSearchNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new PropertyUnitSearchPageDTO();
        initDropdowns();
        setSearchFilter(null);
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(PropertyUnitSearchNavDTO navDto)
    {
        try
        {
            if (navDto != null)
            {
                setSearchFilter(navDto.filterDTO);
            }
            loadPropertyUnitSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageFieldsWithEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        lnkAddPropertyUnitBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_UNIT_ADD);
        ulUploadUnitsAction.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_UNIT_ADD);
        if (propertyUnitSearchGrid.Rows.Count > 0)
        {
            for (var i = 0; i < propertyUnitSearchGrid.Rows.Count; i++)
            {
                HtmlGenericControl tmpBtn = (HtmlGenericControl)propertyUnitSearchGrid.Rows[i].FindControl("liModifyPropertyUnitBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_UNIT_MODIFY);
                tmpBtn = (HtmlGenericControl)propertyUnitSearchGrid.Rows[i].FindControl("liDeletePropertyUnitBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_UNIT_DELETE);
            }
        }
    }
    private void setSearchGrid(IList<PropertyUnitDTO> tmpList)
    {
        getSessionPageData().SearchResult = (tmpList != null) ? tmpList.ToList<PropertyUnitDTO>() : new List<PropertyUnitDTO>();
        assignUiIndexToUnit(getSearchPropertyUnitList());
        propertyUnitSearchGrid.DataSource = getSearchPropertyUnitList();
        propertyUnitSearchGrid.DataBind();
    }
    private void assignUiIndexToUnit(List<PropertyUnitDTO> unitDtos)
    {
        if (unitDtos != null && unitDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (PropertyUnitDTO unitDTO in unitDtos)
            {
                unitDTO.UiIndex = uiIndex++;
                unitDTO.RowInfo = CommonUIConverter.getGridViewRowInfo(unitDTO);
            }
        }
    }
    private PropertyUnitSearchPageDTO getSessionPageData()
    {
        return (PropertyUnitSearchPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<PropertyUnitDTO> getSearchPropertyUnitList()
    {
        return getSessionPageData().SearchResult;
    }
    private PropertyUnitDTO getSearchPropertyUnitDTO(long Id)
    {
        List<PropertyUnitDTO> searchList = getSearchPropertyUnitList();
        PropertyUnitDTO selectedPropertyUnitDTO = null;
        if (Id > 0 && searchList != null && searchList.Count > 0)
        {
            selectedPropertyUnitDTO = searchList.Find(c => c.Id == Id);
        }
        return selectedPropertyUnitDTO;
    }
    private void loadPropertyUnitSearchGrid()
    {
        IList<PropertyUnitDTO> results = prUnitBO.fetchPropertyUnitGridData(getUserDefinitionDTO().FirmNumber, getSearchFilter(), long.Parse(drpTowerFilter.Text));
        setSearchGrid(results);
    }
    private PropertyUnitSearchNavDTO getCurrentPageNavigation()
    {
        PropertyUnitSearchPageDTO PageDTO = getSessionPageData();
        PropertyUnitSearchNavDTO navDTO = new PropertyUnitSearchNavDTO();
        navDTO.filterDTO = getSearchFilter();
        return navDTO;
    }
    private void navigateToPropertyUnitDetails(long selectedId, PageMode mode)
    {
        PropertyUnitDTO unitDTO = getSearchPropertyUnitDTO(selectedId);
        PropertyUnitDetailNavDTO navDTO = new PropertyUnitDetailNavDTO();
        navDTO.Mode = mode;
        if (unitDTO != null) navDTO.PrUnitId = unitDTO.Id;
        navDTO.PrevNavDto = getCurrentPageNavigation();
        Session[Constants.Session.NAV_DTO] = navDTO;
        Response.Redirect(Constants.URL.PROPERTY_UNIT_DETAILS, true);
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    protected void onClickAddPropertyUnitBtn(object sender, EventArgs e)
    {
        try
        {
            navigateToPropertyUnitDetails(0, PageMode.ADD);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickViewPropertyUnitBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            navigateToPropertyUnitDetails(selectedId, PageMode.VIEW);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyPropertyUnitBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            PropertyUnitDTO unitDTO = getSearchPropertyUnitDTO(selectedId);
            PageMode mode = (unitDTO.Status == PRUnitStatus.Available) ? PageMode.MODIFY : PageMode.VIEW;
            Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotyInfoMsg(string.Format("Selected Unit is {0}, cannot be modified.", unitDTO.Status.GetDescription())));
            navigateToPropertyUnitDetails(selectedId, mode);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void deletePropertyUnit(object sender, EventArgs e)
    {
        try
        {
            long selectedId = getDeleteRecordHdnId();
            if (validatePrUnitDelete(selectedId))
            {
                BusinessOutputTO outputTO = prUnitBO.deletePropertyUnitDetails(selectedId);
                string msg = "";
                if (outputTO.status == BusinessOutputTO.Status.SUCCESS)
                {
                	msg = CommonUtil.getRecordDeleteSuccessMsg("Property Unit");
                }
                else
                {
                    prUnitBO.updateUnitAsDeleted(selectedId);
                    msg = CommonUtil.getRecordSoftDeleteSuccessMsg("Property Unit");
                }
                setNotyMsg(CommonUtil.getNotySuccessMsg(msg));
                loadPropertyUnitSearchGrid();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validatePrUnitDelete(long selectedId)
    {
        bool isValid = true;
        PropertyUnitDTO propertyUnitDTO = getSearchPropertyUnitDTO(selectedId);
        if (propertyUnitDTO.Status != PRUnitStatus.Available)
        {
            isValid = false;
            setErrorMessage("Only Available property units can be deleted.", commonError);
        }
        return isValid;
    }
    protected void onClickUploadUnits(object sender, EventArgs e)
    {
        try
        {
        	PropertyUnitUploadNavDTO navDTO = new PropertyUnitUploadNavDTO();
            navDTO.PrevNavDto = getCurrentPageNavigation();
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.PROPERTY_UNIT_UPLOAD, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Filter Criteria - Property Search - Start
    private PropertyUnitFilterDTO getSearchFilter()
    {
        return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            PropertyUnitFilterDTO filterDTO = getSearchFilter();
            drpBO.drpDataBase(drpUnitNoFilter, DrpDataType.PR_TOWER_UNITS, drpTowerFilter.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            if (filterDTO.UnitId > 0) drpUnitNoFilter.Text = filterDTO.UnitId.ToString(); else drpUnitNoFilter.ClearSelection();
            if (filterDTO.UnitType != null) drpUnitTypeFilter.Text = filterDTO.UnitType.Id.ToString(); else drpUnitTypeFilter.ClearSelection();
            if (filterDTO.Wing != null) txtWingFilter.Text = filterDTO.Wing; else txtWingFilter.Text = null;
            if (filterDTO.FloorNo != null) txtFloorNoFilter.Text = filterDTO.FloorNo; else txtFloorNoFilter.Text = null;
            if (filterDTO.Status != null) drpUnitStatusFilter.Text = filterDTO.Status.ToString(); else drpUnitStatusFilter.ClearSelection();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onSelectFilterTower(object sender, EventArgs e)
    {
        try
        {
            drpBO.drpDataBase(drpUnitNoFilter, DrpDataType.PR_TOWER_UNITS, drpTowerFilter.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            activeModalHdn.Value = SearchFilterModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            CommonUtil.setStickyPrTowerDTO(getUserDefinitionDTO(), long.Parse(drpTowerFilter.Text), drpTowerFilter.SelectedItem.Text);
            PropertyUnitFilterDTO filterDTO = new PropertyUnitFilterDTO();
            if (!string.IsNullOrWhiteSpace(drpUnitNoFilter.Text))
            {
                filterDTO.UnitId = long.Parse(drpUnitNoFilter.Text);
                filterDTO.UnitNo = drpUnitNoFilter.SelectedItem.Text;
            }
            if (!string.IsNullOrWhiteSpace(drpUnitTypeFilter.Text))
            {
                filterDTO.UnitType = CommonUIConverter.getMasterControlDTO(drpUnitTypeFilter.Text, drpUnitTypeFilter.SelectedItem.Text);
            }
            if (!string.IsNullOrWhiteSpace(txtWingFilter.Text))
            {
                filterDTO.Wing = txtWingFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(txtFloorNoFilter.Text))
            {
                filterDTO.FloorNo = txtFloorNoFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(drpUnitStatusFilter.Text))
            {
                filterDTO.Status = EnumHelper.ToEnum<PRUnitStatus>(drpUnitStatusFilter.Text);
            }
            setSearchFilter(filterDTO);
            loadPropertyUnitSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            loadPropertyUnitSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(PropertyUnitFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new PropertyUnitFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {
            drpTowerFilter.Text = CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Id.ToString();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            PropertyUnitFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.UNIT_NO))
            {
                filterDTO.UnitId = 0;
                filterDTO.UnitNo = "";
            }
            else if (token.StartsWith(Constants.FILTER.UNIT_TYPE)) filterDTO.UnitType = null;
            else if (token.StartsWith(Constants.FILTER.WING)) filterDTO.Wing = null;
            else if (token.StartsWith(Constants.FILTER.FLOOR_NO)) filterDTO.FloorNo = null;
            else if (token.StartsWith(Constants.FILTER.STATUS)) filterDTO.Status = null;
            else if (token.StartsWith(Constants.FILTER.TOWER_NAME)) setNotyMsg(CommonUtil.getNotyInfoMsg(Resources.Messages.TOWER_FILTER_DEFAULT));
            setSearchFilterTokens();
            loadPropertyUnitSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        PropertyUnitFilterDTO filterDTO = getSearchFilter();
        string filter = CommonUtil.addFilterToken("", Constants.FILTER.TOWER_NAME + CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Name);
        if (filterDTO != null)
        {
            if (filterDTO.UnitId > 0) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.UNIT_NO + filterDTO.UnitNo);
            if (filterDTO.UnitType != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.UNIT_TYPE + filterDTO.UnitType.Name);
            if (filterDTO.Wing != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.WING + filterDTO.Wing);
            if (filterDTO.FloorNo != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.FLOOR_NO + filterDTO.FloorNo);
            if (filterDTO.Status != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.STATUS + filterDTO.Status.ToString());
        }
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - PropertyUnit Search - End
    //Bulk Upload - Start
    protected void onClickDownloadTemplate(object sender, EventArgs e)
    {
        try
        {
            List<MasterControlDataDTO> resultsUnitType;
            List<MasterControlDataDTO> resultsFacing;
            List<MasterControlDataDTO> resultsDirection;
            fetchMaster(out resultsUnitType, out resultsFacing, out resultsDirection);
            if (resultsUnitType == null || resultsUnitType.Count <= 0)
            {
                setErrorMessage("Please add property unit types before downloading unit template.", commonError);
            }
            else if (resultsFacing == null || resultsFacing.Count <= 0)
            {
                setErrorMessage("Please add property unit facing before downloading unit template.", commonError); ;
            }
            else if (resultsDirection == null && resultsDirection.Count <= 0)
            {
                setErrorMessage("Please add property unit direction before downloading unit template.", commonError);
            }
            else
            {
                setResponse();
                using (ExcelPackage package = new ExcelPackage())
                {
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.Add(CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()).Name);

                    using (var range = worksheet.Cells["A1: k1048576"])
                    {
                        range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Top.Color.SetColor(Color.Black);
                        range.Style.Border.Bottom.Color.SetColor(Color.Green);
                        range.Style.Border.Left.Color.SetColor(Color.Blue);
                        range.Style.Border.Right.Color.SetColor(Color.Yellow);
                    }
                    prepareHeader(worksheet);
                    addValidationLists(resultsUnitType, resultsFacing, resultsDirection, worksheet);
                    package.Save();
                    using (MemoryStream MyMemoryStream = new MemoryStream())
                    {
                        package.SaveAs(MyMemoryStream);
                        MyMemoryStream.WriteTo(Response.OutputStream);
                        Response.Flush();
                        Response.End();
                    }
                }
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void addValidationLists(List<MasterControlDataDTO> resultsUnitType, List<MasterControlDataDTO> resultsFacing,
            List<MasterControlDataDTO> resultsDirection, ExcelWorksheet worksheet)
    {
        List<string> propertyList = new List<String>();
        propertyList.Add(CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()).Name);
        CommonUtil.addListValidation(worksheet, "A2:A1048576", propertyList);//Property
        CommonUtil.addListValidation(worksheet, "B2:B1048576", CommonUtil.getDropdownItemNames(drpTowerFilter));//Property Tower
        CommonUtil.addListValidation(worksheet, "F2:F1048576", CommonUtil.getMasterDataNames(resultsUnitType));//Unit Type
        CommonUtil.addListValidation(worksheet, "L2:L1048576", CommonUtil.getMasterDataNames(resultsDirection));//Unit Direction
        CommonUtil.addListValidation(worksheet, "K2:K1048576", CommonUtil.getMasterDataNames(resultsFacing));//Unit Facing
        CommonUtil.addListValidation(worksheet, "M2:M1048576", CommonUtil.getEnumValues(typeof(PRUnitStatus)));//Unit Status
    }

    private void setResponse()
    {
        Response.Clear();
        Response.Buffer = true;
        Response.Charset = "";
        Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        Response.AddHeader("content-disposition", "attachment;filename=" + CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()).Name + ".xlsx");
    }

    private void fetchMaster(out List<MasterControlDataDTO> resultsUnitType, out List<MasterControlDataDTO> resultsFacing, out List<MasterControlDataDTO> resultsDirection)
    {
        resultsUnitType = masterDataBO.fetchMasterData(getUserDefinitionDTO().FirmNumber, MasterDataType.PR_UNIT_TYPE.ToString());
        resultsFacing = masterDataBO.fetchMasterData(getUserDefinitionDTO().FirmNumber, MasterDataType.PR_UNIT_FACING.ToString());
        resultsDirection = masterDataBO.fetchMasterData(getUserDefinitionDTO().FirmNumber, MasterDataType.PR_UNIT_DIRECTION.ToString());
    }

    private void prepareHeader(ExcelWorksheet worksheet)
    {
        worksheet.Cells[1, 1].Value = "Property Name";
        worksheet.Cells[1, 2].Value = "Tower Name";
        worksheet.Cells[1, 3].Value = "Wing";
        worksheet.Cells[1, 4].Value = "Floor Number";
        worksheet.Cells[1, 5].Value = "Unit Number";
        worksheet.Cells[1, 6].Value = "Unit Type";
        worksheet.Cells[1, 7].Value = "Builtup Area";
        worksheet.Cells[1, 8].Value = "Carpet Area";
        worksheet.Cells[1, 9].Value = "Balcony Area";
        worksheet.Cells[1, 10].Value = "No Of Balcony";
        worksheet.Cells[1, 11].Value = "Facing";
        worksheet.Cells[1, 12].Value = "Direction";
        worksheet.Cells[1, 13].Value = "Status";
        using (var range = worksheet.Cells[1, 1, 1, 13])
        {
            range.Style.Font.Bold = true;
            range.Style.Fill.PatternType = ExcelFillStyle.Solid;
            range.Style.Fill.BackgroundColor.SetColor(Color.Blue);
            range.Style.Font.Color.SetColor(Color.White);
        }
        worksheet.Cells["A1:L1048576"].AutoFilter = true;
        worksheet.Cells.AutoFitColumns(0);
    }
    private bool validateFileType(string extension)
    {
        bool isValid = true;
        if (extension != ".xlsx" && extension != ".xls")
        {
            isValid = false;
            setErrorMessage("Please Select Property Unit Excel with extension xlsx or xls.", commonError);
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;

    }
    //Bulk Upload - End
}