﻿using System;
using NHibernate;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using ConstroSoft;
using System.Collections.Generic;
using System.Globalization;

/// <summary>
/// Summary description for FBIntegrationBO
/// </summary>
namespace ConstroSoft
{
    public class ExotelClient
    {

        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public ExotelClient()
        {

        }
        
        /**
         * This API will connect two numbers, Outgoing call to connect two numbers.
         * It connects From Number first. Once the person at the From end picks up the phone, it will connect to the number provided as To.
         * You can choose which number should be connected first by adding that number in the From field. An HTTP POST request is made to
         * https://<your_sid>:<your_token>@api.exotel.com/v1/Accounts/<your_sid>/Calls/connect
         * agentPhoneNumber - User/Sales Agent Phone number configured in Exotel
         * customerNumber - Enquiry/Lead/Customer phone number. If landline number, prefix it with STD code; 
         * callerId- This is your ExoPhone/Exotel Virtual Number
         * StatusCallback - When the call completes, an HTTP POST will be made to the provided URL with the following four parameters:
         * CallSid - an alpha-numeric unique identifier
         * Status - one of: completed, failed, busy, no-answer
         * RecordingUrl - link to the call recording (if it exists)
         * DateUpdated - time when the call state was updated last
         */
        public InOutBoundCallResDTO placeOutBoundCall(string callUrl, string agentPhoneNumber, string customerNumber,string callerId, string StatusCallback){
            
            InOutBoundCallResDTO outBoundCallResDTO = null;
            try
            {
                var client = new RestClient(callUrl);
                var request = new RestRequest();
                request.Method = Method.POST;
                request.AddHeader("Accept", "application/json");
                request.RequestFormat = DataFormat.Json;
                request.AddBody(new {From = agentPhoneNumber, To = customerNumber, CallerId=callerId,  StatusCallback=StatusCallback});
                var response = client.Execute(request);
                outBoundCallResDTO = (InOutBoundCallResDTO)Newtonsoft.Json.JsonConvert.DeserializeObject(response.Content, typeof(InOutBoundCallResDTO));
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while placing outbound call");
                log.Error(exp.Message, exp);
            }
            finally
            {
            }
            return outBoundCallResDTO;
        }
        /**
         * To get details of a call (including Status, Price, etc.), you will need to make a HTTP GET request to
         * https://<your_sid>:<your_token>@api.exotel.com/v1/Accounts/<your_sid>/Calls/<CallSid>
         * 
         */
        public InOutBoundCallResDTO getCallDetails(string callDetailsUrl, string callSid ){
            
            InOutBoundCallResDTO outBoundCallResDTO = null;
            try
            {
                var client = new RestClient(callUrl);
                var request = new RestRequest();
                request.Method = Method.GET;
                request.AddHeader("Accept", "application/json");
                request.RequestFormat = DataFormat.Json;
                request.AddBody(new {CallSid = callSid});
                var response = client.Execute(request);
                outBoundCallResDTO = (InOutBoundCallResDTO)Newtonsoft.Json.JsonConvert.DeserializeObject(response.Content, typeof(InOutBoundCallResDTO));
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while retreiving call details for :"+callSid);
                log.Error(exp.Message, exp);
            }
            finally
            {
            }
            return outBoundCallResDTO;
        }
    }
}