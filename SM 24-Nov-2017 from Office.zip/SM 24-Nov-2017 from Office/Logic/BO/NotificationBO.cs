﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;


/// <summary>
/// Summary description for PropertyAlertBO
/// </summary>
namespace ConstroSoft
{
    public class NotificationBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public NotificationBO() { }

        public IList<NotificationDTO> fetchNotifications(string firmNumber)
        {
            ISession session = null;
            IList<NotificationDTO> result = new List<NotificationDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                Notification notification = null;
                NotificationDTO notificationDTO = null;
                var query = session.QueryOver<Notification>(() => notification);
                result = query.Where(() => notification.FirmNumber == firmNumber && notification.Status == NotificationStatus.OPEN)
                                       .TransformUsing(new DeepTransformer<NotificationDTO>()).List<NotificationDTO>();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating Notification Details:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public void addNotification(NotificationDTO notificationDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Notification notification = DTOToDomainUtil.populateNotificationAddFields(notificationDTO);
                        session.Save(notification);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while adding Notification:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }

    }
}