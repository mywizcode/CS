﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.BO;
using ConstroSoft.Logic.Util;
using OfficeOpenXml;

public partial class PropertyUnitUpload : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifyStep1Error = "addModifyStep1Error";
    string addMasterDataError = "addMasterDataError";
    string addMasterDataModal = "addMasterDataModal";
    DropdownBO drpBO = new DropdownBO();
    PropertyUnitManagementBO prUnitBO = new PropertyUnitManagementBO();
    PropertyBO propertyBO = new PropertyBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                PropertyUnitUploadNavDTO navDto = ApplicationUtil.getPageNavDTO<PropertyUnitUploadNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.PROPERTY_UNIT_ADD)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
    	ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
    }
    public void setErrorMessage(string message, string group)
    {
    	string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        } else CommonUtil.getCustomValidator(Page, message, group);
    }
    private void renderPageFieldsWithEntitlement()
    {

    }
    private void doInit(PropertyUnitUploadNavDTO navDto)
    {
        initDropdowns();
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(PropertyUnitUploadNavDTO navDto)
    {
        if (navDto != null)
        {
            PropertyUnitUploadPageDTO PageDTO = new PropertyUnitUploadPageDTO();
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            //Reset page details
            txtUploadUnitProperty.Text = CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()).Name;
            pnlUploadUnitDetail.Visible = false;
            PageDTO.UploadFailedResult = new List<PropertyUnitMapperDTO>();
            PageDTO.UploadSuccessResult = new List<PropertyUnitMapperDTO>();
            DropDownList drpUnitType = new DropDownList();
            DropDownList drpDirection = new DropDownList();
            DropDownList drpFacing = new DropDownList();
            DropDownList drpTower = new DropDownList();
            drpBO.drpDataBase(drpUnitType, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.PR_UNIT_TYPE.ToString(), null, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpDirection, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.PR_UNIT_DIRECTION.ToString(), null, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpFacing, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.PR_UNIT_FACING.ToString(), null, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpTower, DrpDataType.PROPERTY_TOWER, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(), null, userDefDto.FirmNumber);
            PageDTO.drpUnitType = drpUnitType;
            PageDTO.drpDirection = drpDirection;
            PageDTO.drpFacing = drpFacing;
            PageDTO.drpTower = drpTower;
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void navigateToPreviousPage()
    {
        PropertyUnitUploadPageDTO PageDTO = getSessionPageData();
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is PropertyUnitSearchNavDTO)
            {
                PropertyUnitSearchNavDTO navDTO = (PropertyUnitSearchNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.PROPERTY_UNIT_SEARCH, true);
            }
        }
        Response.Redirect(Constants.URL.PROPERTY_UNIT_SEARCH, true);
    }
    private PropertyUnitUploadPageDTO getSessionPageData()
    {
        return (PropertyUnitUploadPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<PropertyUnitMapperDTO> getUploadFailedList()
    {
        return getSessionPageData().UploadFailedResult;
    }
    private List<PropertyUnitMapperDTO> getUploadSuccessList()
    {
        return getSessionPageData().UploadSuccessResult;
    }
    private bool isUploadSubmitToEnabled()
    {
        return getUploadSuccessList().Count > 0 && Constants.UPLOAD_VALIDATED.Equals(lbSuccessUploadUnitsText.Text);
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelPropertyUnit(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    public void validatePropertyUnits(object sender, EventArgs e)
    {
        try
        {
            pnlUploadUnitDetail.Visible = false;
            HttpFileCollection uploadedFiles = Request.Files;
            List<PropertyUnitMapperDTO> validationFailedList = new List<PropertyUnitMapperDTO>();
            List<PropertyUnitMapperDTO> validationSuccessList = new List<PropertyUnitMapperDTO>();
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            
            for (int i = 0; i < uploadedFiles.Count; i++)
            {
                HttpPostedFile userPostedFile = uploadedFiles[i];
                if (userPostedFile.ContentLength > 0)
                {
                    string filename = Path.GetFileName(userPostedFile.FileName);
                    string extension = Path.GetExtension(filename);
                    HttpPostedFile file = fileUploadUnits.PostedFile;
                    if (validateFileType(extension))
                    {
                        using (file.InputStream)
                        {
                            ExcelPackage excel = new ExcelPackage(file.InputStream);
                            var workSheet = excel.Workbook.Worksheets[1];
                            IEnumerable<PropertyUnitMapperDTO> newcollection = workSheet.ConvertSheetToObjects<PropertyUnitMapperDTO>();
                            int RowNumber = 2;
                            foreach (PropertyUnitMapperDTO propertyUnitMapperDTO in newcollection)
                            {
                            	propertyUnitMapperDTO.RowNumber = RowNumber++;
                            	validateInputDTO(propertyUnitMapperDTO, validationSuccessList);
                            	if (propertyUnitMapperDTO.IsError) validationFailedList.Add(propertyUnitMapperDTO);
                                else validationSuccessList.Add(propertyUnitMapperDTO);
                            }
                        }
                        pnlUploadUnitDetail.Visible = true;
                        getSessionPageData().UploadFailedResult = validationFailedList;
                        getSessionPageData().UploadSuccessResult = validationSuccessList;

                        lbTotalUploadUnitsCount.Text = (validationFailedList.Count + validationSuccessList.Count) + "";
                        lbSuccessUploadUnitsCount.Text = validationSuccessList.Count + "";
                        lbSuccessUploadUnitsText.Text = Constants.UPLOAD_VALIDATED;
                        lbFailedUploadUnitsCount.Text = validationFailedList.Count + "";
                        btnUploadUnitSubmit.Visible = isUploadSubmitToEnabled();
                        populateUnitUploadGrid(validationSuccessList, "SUCCESS");
                    }
                }
                else
                {
                    setErrorMessage("Please Select valid file to upload.", commonError);
                }
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    public void showUploadUnits(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            string mode = rd.Attributes["data-show"];
            btnUploadUnitSubmit.Visible = false;
            if ("ALL".Equals(mode))
            {
                List<PropertyUnitMapperDTO> allUnits = new List<PropertyUnitMapperDTO>();
                allUnits.AddRange(getUploadFailedList());
                allUnits.AddRange(getUploadSuccessList());
                btnUploadUnitSubmit.Visible = isUploadSubmitToEnabled();
                populateUnitUploadGrid(allUnits, mode);
            }
            else if ("SUCCESS".Equals(mode))
            {
                btnUploadUnitSubmit.Visible = isUploadSubmitToEnabled();
                populateUnitUploadGrid(getUploadSuccessList(), mode);
            }
            else if ("ERROR".Equals(mode))
            {
                populateUnitUploadGrid(getUploadFailedList(), mode);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    public void addPropertyUnits(object sender, EventArgs e)
    {
        try
        {
            List<PropertyUnitMapperDTO> uploadList = getUploadSuccessList();
            if (uploadList != null && uploadList.Count > 0)
            {
                List<PropertyUnitMapperDTO> successList = new List<PropertyUnitMapperDTO>();
                List<PropertyUnitMapperDTO> failureList = new List<PropertyUnitMapperDTO>();
                foreach (PropertyUnitMapperDTO inputDTO in uploadList)
                {
                    if (!inputDTO.IsError)
                    {
                        try
                        {
                            prUnitBO.savePropertyUnitDetails(populateUnitDTO(inputDTO));
                            successList.Add(inputDTO);
                        }
                        catch (Exception exp)
                        {
                        	inputDTO.IsError = true;
                        	inputDTO.AllErrorMessage.Add("Failed to upload, Unexpected error has occurred.");
                            failureList.Add(inputDTO);
                        }
                    }
                }
                btnUploadUnitSubmit.Visible = false;
                string msg = (uploadList.Count == successList.Count) ? "Upload process is completed. All Property Units are uploaded successfully." :
                    "Upload process is completed. Some of the Property Units are not uploaded, Please check Failure records.";
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(msg));

                failureList.AddRange(getUploadFailedList());
                getSessionPageData().UploadFailedResult = failureList;
                getSessionPageData().UploadSuccessResult = successList;
                populateUnitUploadGrid(successList, "SUCCESS");

                lbSuccessUploadUnitsCount.Text = successList.Count + "";
                lbSuccessUploadUnitsText.Text = Constants.UPLOAD_SUCCESS;
                lbFailedUploadUnitsCount.Text = failureList.Count + "";
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    private void populateUnitUploadGrid(IList<PropertyUnitMapperDTO> results, string mode)
    {
        unitUploadGrid.Columns[7].Visible = "ALL".Equals(mode) && Constants.UPLOAD_SUCCESS.Equals(lbSuccessUploadUnitsText.Text);
        unitUploadGrid.Columns[8].Visible = !"SUCCESS".Equals(mode);
        assignUiIndexToTaxDetail(results);
        unitUploadGrid.DataSource = results;
        unitUploadGrid.DataBind();
    }

    private void assignUiIndexToTaxDetail(IList<PropertyUnitMapperDTO> results)
    {
        if (results != null && results.Count > 0)
        {
            foreach (PropertyUnitMapperDTO unitDto in results)
            {
                unitDto.RowInfo = CommonUIConverter.getGridViewRowInfo(unitDto);
                if(unitDto.IsError) {
                    unitDto.ErrorMessage = (unitDto.AllErrorMessage.Count > 1) ? "Multiple errors occurred." : unitDto.AllErrorMessage[0];
                }
            }
        }
    }
    private PropertyUnitDTO populateUnitDTO(PropertyUnitMapperDTO propertyUnitMapperDTO)
    {
    	PropertyUnitDTO propertyUnitDTO = new PropertyUnitDTO();
        try
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            propertyUnitDTO.PropertyTower = CommonUIConverter.getPropertyTowerDTO(drpBO.getListItem(getSessionPageData().drpTower, propertyUnitMapperDTO.TowerName).Value, "");
            propertyUnitDTO.Wing = (string.IsNullOrWhiteSpace(propertyUnitMapperDTO.Wing)) ? "" : propertyUnitMapperDTO.Wing.Trim();
            propertyUnitDTO.FloorNo = propertyUnitMapperDTO.FloorNo.TrimNullable();
            propertyUnitDTO.UnitNo = propertyUnitMapperDTO.UnitNo.TrimNullable();
            propertyUnitDTO.UnitType = CommonUIConverter.getMasterControlDTO(drpBO.getListItem(getSessionPageData().drpUnitType, propertyUnitMapperDTO.UnitType).Value, "");
            propertyUnitDTO.BuildupArea = CommonUtil.getDecimalWithoutExt(propertyUnitMapperDTO.BuildupArea);
            propertyUnitDTO.CarpetArea = CommonUtil.getDecimalWithoutExt(propertyUnitMapperDTO.CarpetArea);
            propertyUnitDTO.BalconyArea = CommonUtil.getDecimalWithoutExt(propertyUnitMapperDTO.BalconyArea);
            if(!string.IsNullOrWhiteSpace(propertyUnitMapperDTO.Facing))
                propertyUnitDTO.Facing = CommonUIConverter.getMasterControlDTO(drpBO.getListItem(getSessionPageData().drpFacing, propertyUnitMapperDTO.Facing).Value, "");
            if(!string.IsNullOrWhiteSpace(propertyUnitMapperDTO.Direction))
                propertyUnitDTO.Direction = CommonUIConverter.getMasterControlDTO(drpBO.getListItem(getSessionPageData().drpDirection, propertyUnitMapperDTO.Direction).Value, "");
            propertyUnitDTO.NoOfBalcony = StringUtil.getIntValue(propertyUnitMapperDTO.NoOfBalcony);
            propertyUnitDTO.Status = EnumHelper.ToEnum<PRUnitStatus>(propertyUnitMapperDTO.Status);
            propertyUnitDTO.FirmNumber = userDefDto.FirmNumber;
            propertyUnitDTO.InsertUser = userDefDto.Username;
            propertyUnitDTO.UpdateUser = userDefDto.Username;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw new CustomException("Unexpected error while parsing record. Row:"+propertyUnitMapperDTO.RowNumber);
        }
        return propertyUnitDTO;
    }
    private void validateInputDTO(PropertyUnitMapperDTO inputDTO, List<PropertyUnitMapperDTO> inputList)
    {
        List<string> errorList = new List<string>();
        try
        {
        	//1. Mandatory Validations
        	//2. Format validations (Date/Amount)
        	//3. Valid values
        	//4. Length validations
        	UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        	 //Property
        	if(string.IsNullOrWhiteSpace(inputDTO.PropertyName)) errorList.Add("Property Name is required.");
        	else if(!inputDTO.PropertyName.Equals(txtUploadUnitProperty.Text))  errorList.Add("Property name does not match with selected Property.");
        	//Tower
        	if(string.IsNullOrWhiteSpace(inputDTO.TowerName)) errorList.Add("Tower Name is required.");
            else if (!drpBO.containsItem(getSessionPageData().drpTower, inputDTO.TowerName)) errorList.Add("Tower Name is invalid.");
        	//Wing
            if(!StringUtil.isValidLength(inputDTO.Wing, 50)) errorList.Add("Length of Wing must be less than 50 characters.");
        	//Floor
            if(!StringUtil.isValidLength(inputDTO.FloorNo, 2)) errorList.Add("Length of Floor No must be less than 2 characters.");
            //Floor
            if(string.IsNullOrWhiteSpace(inputDTO.UnitNo)) errorList.Add("Unit No is required.");
            else if(!StringUtil.isValidLength(inputDTO.UnitNo, 25)) errorList.Add("Length of Unit No must be less than 25 characters.");
            //Unit Type
            if(string.IsNullOrWhiteSpace(inputDTO.UnitType)) errorList.Add("Unit Type is required.");
            else if (!drpBO.containsItem(getSessionPageData().drpUnitType, inputDTO.UnitType)) errorList.Add("Unit Type is invalid.");
            //Buildup Area
            if(!StringUtil.isValidDecimalNullable(inputDTO.BuildupArea)) errorList.Add("Buildup Area is not valid.");
            //Carpet Area
            if(!StringUtil.isValidDecimalNullable(inputDTO.CarpetArea)) errorList.Add("Carpet Area is not valid.");
            //Balcony Area
            if(!StringUtil.isValidDecimalNullable(inputDTO.BalconyArea)) errorList.Add("Balcony Area is not valid.");
            //No Of Balcony
            if(!StringUtil.isValidIntNullable(inputDTO.NoOfBalcony)) errorList.Add("No Of Balcony is not valid.");
            //Facing
            if (!string.IsNullOrWhiteSpace(inputDTO.Facing) && !drpBO.containsItem(getSessionPageData().drpFacing, inputDTO.Facing)) errorList.Add("Facing is invalid.");
            //Direction
            if (!string.IsNullOrWhiteSpace(inputDTO.Direction) && !drpBO.containsItem(getSessionPageData().drpDirection, inputDTO.Direction)) errorList.Add("Direction is invalid.");
            //Status
            if(string.IsNullOrWhiteSpace(inputDTO.Status)) errorList.Add("Status is required.");
        	else if(!EnumHelper.isValidEnum<PRUnitStatus>(inputDTO.Status)) errorList.Add("Status is invalid.");
            
            if(errorList.Count == 0) {
                if (prUnitBO.isAlreadyExist(userDefDto.FirmNumber, long.Parse(drpBO.getListItem(getSessionPageData().drpTower, inputDTO.TowerName).Value), 
            			inputDTO.Wing.TrimNullable(), inputDTO.UnitNo.TrimNullable())) {
            		 errorList.Add(string.Format("Unit already exist with wing {0} and Unit No {1}.", inputDTO.Wing, inputDTO.UnitNo));
            	} else {
            		foreach (PropertyUnitMapperDTO tmpDTO in inputList)
                    {
                        if (tmpDTO.TowerName.Equals(inputDTO.TowerName) &&
                        		((string.IsNullOrWhiteSpace(tmpDTO.Wing) && string.IsNullOrWhiteSpace(inputDTO.Wing)) 
                            || (!string.IsNullOrWhiteSpace(tmpDTO.Wing) && !string.IsNullOrWhiteSpace(inputDTO.Wing) 
                            		&& tmpDTO.Wing.TrimNullable().Equals(inputDTO.Wing.TrimNullable()))) 
                            && tmpDTO.UnitNo.TrimNullable().Equals(inputDTO.UnitNo.TrimNullable()))
                        {
                        	errorList.Add("Duplicate Unit with same Unit No and Wing.");
                        }
                    }
            	}
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            errorList.Add("Unexpected error while parsing record.");
        }
        inputDTO.IsError = (errorList.Count > 0);
    	inputDTO.AllErrorMessage = errorList;
    }
    private bool validateFileType(string extension)
    {
        bool isValid = true;
        if (extension != ".xlsx" && extension != ".xls")
        {
            isValid = false;
            setErrorMessage("Please use valid Property Unit upload template.", commonError);
        }
        return isValid;
    }
}