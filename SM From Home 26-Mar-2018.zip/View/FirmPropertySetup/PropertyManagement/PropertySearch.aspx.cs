﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using ConstroSoft;
using ConstroSoft.Logic.BO;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Drawing;
using System.Web.UI.HtmlControls;

public partial class PropertySearch : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string SearchFilterModal = "SearchFilterModal";
    DropdownBO drpBO = new DropdownBO();
    PropertyBO propertyBO = new PropertyBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Form.Attributes.Add("enctype", "multipart/form-data");
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                PropertySearchNavDTO navDto = ApplicationUtil.getPageNavDTO<PropertySearchNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_PROPERTY)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
    	ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpPropertyNameFilter, DrpDataType.PROPERTY_NAME, userDefDto.Id.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpPropertytypeFilter, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.PROPERTY_TYPE.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpPropertyLocationFilter, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.PROPERTY_LOCATION.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
    }
    public void setErrorMessage(string message, string group)
    {
    	string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        } else CommonUtil.getCustomValidator(Page, message, group);
    }
    private void doInit(PropertySearchNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new PropertySearchPageDTO();
        initDropdowns();
        setSearchFilter(null);
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(PropertySearchNavDTO navDto)
    {
        try
        {
            if (navDto != null)
            {
                setSearchFilter(navDto.filterDTO);
            }
            loadPropertySearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageFieldsWithEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        lnkAddPropertyBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_ADD);
        if (propertySearchGrid.Rows.Count > 0)
        {
            for (var i = 0; i < propertySearchGrid.Rows.Count; i++)
            {
                HtmlGenericControl tmpBtn = (HtmlGenericControl)propertySearchGrid.Rows[i].FindControl("liModifyPropertyBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_MODIFY);
                tmpBtn = (HtmlGenericControl)propertySearchGrid.Rows[i].FindControl("liDeletePropertyBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_DELETE);
                tmpBtn = (HtmlGenericControl)propertySearchGrid.Rows[i].FindControl("liManageDocumentsBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MANAGE_PROPERTY_DOCUMENTS);
                tmpBtn = (HtmlGenericControl)propertySearchGrid.Rows[i].FindControl("liPropertyUserAccessBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_USER_ACCESS);
                tmpBtn = (HtmlGenericControl)propertySearchGrid.Rows[i].FindControl("liPropertyVirtualPhoneBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.VIRTUAL_PHONE_USER_ACCESS);
            }
        }
    }
    private void setSearchGrid(IList<PropertyDTO> tmpList)
    {
        getSessionPageData().SearchResult = (tmpList != null) ? tmpList.ToList<PropertyDTO>() : new List<PropertyDTO>();
        propertySearchGrid.DataSource = getSearchPropertyList();
        propertySearchGrid.DataBind();
    }
    private PropertySearchPageDTO getSessionPageData()
    {
        return (PropertySearchPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<PropertyDTO> getSearchPropertyList()
    {
        return getSessionPageData().SearchResult;
    }
    private PropertyDTO getSearchPropertyDTO(long Id)
    {
        List<PropertyDTO> searchList = getSearchPropertyList();
        PropertyDTO selectedPropertyDTO = null;
        if (Id > 0 && searchList != null && searchList.Count > 0)
        {
            selectedPropertyDTO = searchList.Find(c => c.Id == Id);
        }
        return selectedPropertyDTO;
    }
    private void loadPropertySearchGrid()
    {
        IList<PropertyDTO> results = propertyBO.fetchPropertyGridData(getUserDefinitionDTO().FirmNumber, getSearchFilter(), getUserDefinitionDTO().FirmMember.Id);
        setSearchGrid(results);
    }
    private PropertySearchNavDTO getCurrentPageNavigation()
    {
        PropertySearchPageDTO PageDTO = getSessionPageData();
        PropertySearchNavDTO navDTO = new PropertySearchNavDTO();
        navDTO.filterDTO = getSearchFilter();
        return navDTO;
    }
    private void navigateToPropertyDetails(long selectedId, PageMode mode)
    {
        PropertyDTO propertyDTO = getSearchPropertyDTO(selectedId);
        PropertyDetailNavDTO navDTO = new PropertyDetailNavDTO();
        navDTO.Mode = mode;
        if (propertyDTO != null) navDTO.PropertyId = propertyDTO.Id;
        navDTO.PrevNavDto = getCurrentPageNavigation();
        Session[Constants.Session.NAV_DTO] = navDTO;
        Response.Redirect(Constants.URL.PROPERTY_DETAILS, true);
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    protected void onClickAddPropertyBtn(object sender, EventArgs e)
    {
        try
        {
            navigateToPropertyDetails(0, PageMode.ADD);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickViewPropertyBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            navigateToPropertyDetails(selectedId, PageMode.VIEW);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyPropertyBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            navigateToPropertyDetails(selectedId, PageMode.MODIFY);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickPropertyCongirationsBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            PropertyConfigurationNavDTO navDTO = new PropertyConfigurationNavDTO();
            navDTO.PropertyId = selectedId;
            navDTO.PrevNavDto = getCurrentPageNavigation();
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.PROPERTY_CONFIGURATIONS, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickManageDocumentsBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            ManagePropertyDocsNavDTO navDTO = new ManagePropertyDocsNavDTO();
            navDTO.PropertyId = selectedId;
            navDTO.PrevNavDto = getCurrentPageNavigation();
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.PROPERTY_MANAGE_DOCUMENTS, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void deleteProperty(object sender, EventArgs e)
    {
        try
        {
            long selectedId = getDeleteRecordHdnId();
            propertyBO.deleteProperty(selectedId);
            Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg(CommonUtil.getRecordDeleteSuccessMsg("Property")));
            PropertySearchPageDTO PageDTO = getSessionPageData();
            PropertySearchNavDTO navDTO = new PropertySearchNavDTO();
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.PROPERTY_SEARCH, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Filter Criteria - Property Search - Start
    private PropertyFilterDTO getSearchFilter()
    {
        return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            PropertyFilterDTO filterDTO = getSearchFilter();
            if (filterDTO.PropertyId > 0) drpPropertyNameFilter.Text = filterDTO.PropertyId.ToString(); else drpPropertyNameFilter.ClearSelection();
            if (filterDTO.Type != null) drpPropertytypeFilter.Text = filterDTO.Type.Id.ToString(); else drpPropertytypeFilter.ClearSelection();
            if (filterDTO.Location != null) drpPropertyLocationFilter.Text = filterDTO.Location.Id.ToString(); else drpPropertyLocationFilter.ClearSelection();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            PropertyFilterDTO filterDTO = new PropertyFilterDTO();
            if (!string.IsNullOrWhiteSpace(drpPropertyNameFilter.Text))
            {
                filterDTO.PropertyId = long.Parse(drpPropertyNameFilter.Text);
                filterDTO.PropertyName = drpPropertyNameFilter.SelectedItem.Text;
            }
            if (!string.IsNullOrWhiteSpace(drpPropertytypeFilter.Text))
            {
                filterDTO.Type = CommonUIConverter.getMasterControlDTO(drpPropertytypeFilter.Text, drpPropertytypeFilter.SelectedItem.Text);
            }
            if (!string.IsNullOrWhiteSpace(drpPropertyLocationFilter.Text))
            {
                filterDTO.Location = CommonUIConverter.getMasterControlDTO(drpPropertyLocationFilter.Text, drpPropertyLocationFilter.SelectedItem.Text);
            }
            getSessionPageData().FilterDTO = filterDTO;
            loadPropertySearchGrid();
            setSearchFilterTokens();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            loadPropertySearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(PropertyFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new PropertyFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            PropertyFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.PROPERTY_NAME))
            {
                filterDTO.PropertyId = 0;
                filterDTO.PropertyName = "";
            }
            else if (token.StartsWith(Constants.FILTER.PROPERTY_TYPE)) filterDTO.Type = null;
            else if (token.StartsWith(Constants.FILTER.PROPERTY_LOCATION)) filterDTO.Location = null;
            setSearchFilterTokens();
            loadPropertySearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        PropertyFilterDTO filterDTO = getSearchFilter();
        string filter = "";
        if (filterDTO.PropertyId > 0) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.PROPERTY_NAME + filterDTO.PropertyName);
        if (filterDTO.Type != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.PROPERTY_TYPE + filterDTO.Type.Name);
        if (filterDTO.Location != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.PROPERTY_LOCATION + filterDTO.Location.Name);
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - Property Search - End
}