﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;

public partial class EmailSMSProvider : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifyEmailProviderError = "addModifyEmailProviderError";
    string addModifyEmailProviderModal = "addModifyEmailProviderModal";
    string addModifySMSProviderError = "addModifySMSProviderError";
    string addModifySMSProviderModal = "addModifySMSProviderModal";
    DropdownBO drpBO = new DropdownBO();
    EmailAndSMSProviderBO emailAndSMSBO = new EmailAndSMSProviderBO();
    public enum EmailProviderModalAction { ADD, MODIFY }
    public enum SMSProviderModalAction { ADD, MODIFY }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                EmailSMSProviderNavDTO navDto = ApplicationUtil.getPageNavDTO<EmailSMSProviderNavDTO>(Session);
                //if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_MANAGE_MASTER)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
        addCheckBoxAttributes();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private void addCheckBoxAttributes()
    {
        cbEmailProviderEnableSSL.InputAttributes.Add("class", "styled");
        cbEmailProviderDefault.InputAttributes.Add("class", "styled");
        cbSMSProviderDefault.InputAttributes.Add("class", "styled");
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];

    }
    public void setErrorMessage(string message, string group)
    {
        string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }
    }
    private void doInit(EmailSMSProviderNavDTO navDTO)
    {
        Session[Constants.Session.PAGE_DATA] = new EmailSMSProviderPageDTO();
        initDropdowns();
        loadEmailAndSMSProviderGrid(true);
    }
    private void renderPageFieldsWithEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();

    }
    private EmailSMSProviderPageDTO getSessionPageData()
    {
        return (EmailSMSProviderPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private void loadEmailAndSMSProviderGrid(bool isEmailTab)
    {
        EmailSMSProviderPageDTO PageDTO = getSessionPageData();
        IList<EmailConfigDTO> emailList = emailAndSMSBO.fetchEmailProviders(getUserDefinitionDTO().FirmNumber);
        PageDTO.EmailConfigList = (emailList != null) ? emailList.ToList<EmailConfigDTO>() : new List<EmailConfigDTO>();
        IList<SmsConfigDTO> smsList = emailAndSMSBO.fetchSMSProviders(getUserDefinitionDTO().FirmNumber);
        PageDTO.SMSConfigList = (smsList != null) ? smsList.ToList<SmsConfigDTO>() : new List<SmsConfigDTO>();

        EnableTab(isEmailTab);
    }
    private void EnableTab(bool isEmailTab)
    {
        EmailSMSProviderPageDTO PageDTO = getSessionPageData();
        liEmailProvider.Attributes["class"] = (isEmailTab) ? "active" : "";
        liSMSProvider.Attributes["class"] = (isEmailTab) ? "" : "active";
        pnlEmailProvider.Visible = isEmailTab;
        pnlSMSProvider.Visible = !isEmailTab;
        if (isEmailTab) populateEmailProviderGrid(PageDTO.EmailConfigList);
        else populateSMSProviderGrid(PageDTO.SMSConfigList);
    }
    private void populateEmailProviderGrid(List<EmailConfigDTO> tmpList)
    {
        EmailProviderGrid.DataSource = new List<EmailConfigDTO>();
        if (tmpList != null)
        {
            assignUiIndexToEmailProvider(tmpList);
            EmailProviderGrid.DataSource = tmpList;
        }
        EmailProviderGrid.DataBind();
    }
    private void assignUiIndexToEmailProvider(List<EmailConfigDTO> tmpList)
    {
        if (tmpList != null && tmpList.Count > 0)
        {
            foreach (EmailConfigDTO tmpDTO in tmpList)
            {
                
            }
        }
    }
    private void populateSMSProviderGrid(List<SmsConfigDTO> tmpList)
    {
        SMSProviderGrid.DataSource = new List<SmsConfigDTO>();
        if (tmpList != null)
        {
            assignUiIndexToSMSProvider(tmpList);
            SMSProviderGrid.DataSource = tmpList;
        }
        SMSProviderGrid.DataBind();
    }
    private void assignUiIndexToSMSProvider(List<SmsConfigDTO> tmpList)
    {
        if (tmpList != null && tmpList.Count > 0)
        {
            foreach (SmsConfigDTO tmpDTO in tmpList)
            {
            
            }
        }
    }
    protected void onClickEmailProvider(object sender, EventArgs e)
    {
        try
        {
            EnableTab(true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickSMSProvider(object sender, EventArgs e)
    {
        try
        {
            EnableTab(false);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickDeleteEmailProviderBtn(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            EmailConfigDTO selectedDTO = getSelectedEmailProvider(selectedIndex);
            emailAndSMSBO.deleteEmailProvider(selectedDTO.Id);
            //TODO- If Email Provider already used then proper message should be displayed to user
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(CommonUtil.getRecordDeleteSuccessMsg("Email Provider")));
            loadEmailAndSMSProviderGrid(true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickDeleteSMSProviderBtn(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            SmsConfigDTO selectedDTO = getSelectedSMSProvider(selectedIndex);
            emailAndSMSBO.deleteSMSProvider(selectedDTO.Id);
            //TODO- If SMS Provider already used then proper message should be displayed to user
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(CommonUtil.getRecordDeleteSuccessMsg("SMS Provider")));
            loadEmailAndSMSProviderGrid(false);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Email Provider Modal - Start
    private void initEmailProviderModalFields()
    {
        lbEmailProviderModalTitle.Text = (EmailProviderModalAction.ADD.ToString().Equals(EmailProviderModalActionHdnBtn.Value))
            ? Constants.ICON.ADD + Resources.Labels.ADD_EMAIL_PROVIDER : Constants.ICON.MODIFY + Resources.Labels.MODIFY_EMAIL_PROVIDER;
    }
    private void initEmailProviderSectionFields(EmailConfigDTO tmpDTO)
    {
        if (tmpDTO != null) txtEmailProviderName.Text = tmpDTO.Name; else txtEmailProviderName.Text = null;
        if (tmpDTO != null) txtEmailProviderHost.Text = tmpDTO.SmtpHost; else txtEmailProviderHost.Text = null;
        if (tmpDTO != null) txtEmailProviderPort.Text = tmpDTO.SmtpPort; else txtEmailProviderPort.Text = null;
        if (tmpDTO != null) txtEmailProviderEmail.Text = tmpDTO.Email; else txtEmailProviderEmail.Text = null;
        if (tmpDTO != null) txtEmailProviderPassword.Text = tmpDTO.Password; else txtEmailProviderPassword.Text = null;
        if (tmpDTO != null) cbEmailProviderEnableSSL.Checked = tmpDTO.EnableSsl == EmailEnableSSL.Yes; else cbEmailProviderEnableSSL.Checked = false;
        if (tmpDTO != null) cbEmailProviderDefault.Checked = tmpDTO.IsDefault == IsDefault.Yes; else cbEmailProviderDefault.Checked = false;

        cbEmailProviderDefault.Enabled = !cbEmailProviderDefault.Checked;
    }
    private void populateEmailProviderFromUI(EmailConfigDTO tmpDTO)
    {
        tmpDTO.Name = txtEmailProviderName.Text.TrimNullable();
        tmpDTO.SmtpHost = txtEmailProviderHost.Text.TrimNullable();
        tmpDTO.SmtpPort = txtEmailProviderPort.Text.TrimNullable();
        tmpDTO.Email = txtEmailProviderEmail.Text.TrimNullable();
        tmpDTO.Password = txtEmailProviderPassword.Text.TrimNullable();
        tmpDTO.EnableSsl = cbEmailProviderEnableSSL.Checked ? EmailEnableSSL.Yes : EmailEnableSSL.No;
        tmpDTO.IsDefault = cbEmailProviderDefault.Checked ? IsDefault.Yes : IsDefault.No;
        tmpDTO.UpdateUser = getUserDefinitionDTO().Username;
    }
    private EmailConfigDTO populateEmailProviderAdd()
    {
        EmailConfigDTO tmpDTO = new EmailConfigDTO();
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        tmpDTO.FirmNumber = userDef.FirmNumber;
        tmpDTO.InsertUser = userDef.Username;
        return tmpDTO;
    }
    private void setSelectedEmailProvider(long Id)
    {
        List<EmailConfigDTO> tmpList = getSessionPageData().EmailConfigList;
        tmpList.ForEach(c => c.isUISelected = false);
        if (Id > 0) tmpList.Find(c => c.Id == Id).isUISelected = true;
    }
    private EmailConfigDTO getSelectedEmailProvider(long Id)
    {
        List<EmailConfigDTO> tmpList = getSessionPageData().EmailConfigList;
        return (Id > 0) ? tmpList.Find(c => c.Id == Id) : tmpList.Find(c => c.isUISelected);
    }
    protected void onClickAddEmailProviderBtn(object sender, EventArgs e)
    {
        try
        {
            EmailProviderModalActionHdnBtn.Value = EmailProviderModalAction.ADD.ToString();
            initEmailProviderModalFields();
            setSelectedEmailProvider(-1);
            initEmailProviderSectionFields(null);
            activeModalHdn.Value = addModifyEmailProviderModal;
            SetFocus(txtEmailProviderName);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyEmailProviderBtn(object sender, EventArgs e)
    {
        try
        {
            EmailProviderModalActionHdnBtn.Value = EmailProviderModalAction.MODIFY.ToString();
            initEmailProviderModalFields();
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedEmailProvider(selectedIndex);
            initEmailProviderSectionFields(getSelectedEmailProvider(0));
            activeModalHdn.Value = addModifyEmailProviderModal;
            SetFocus(txtEmailProviderName);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void saveEmailProvider(object sender, EventArgs e)
    {
        try
        {
            if (validateEmailProviderAddModify())
            {
                EmailConfigDTO tmpDTO = null;
                string msg = CommonUtil.getNotySuccessMsg(CommonUtil.getRecordAddSuccessMsg("Email Provider"));
                if (EmailProviderModalAction.ADD.ToString().Equals(EmailProviderModalActionHdnBtn.Value))
                {
                    tmpDTO = populateEmailProviderAdd();
                }
                else
                {
                    tmpDTO = getSelectedEmailProvider(0);
                    msg = CommonUtil.getNotySuccessMsg(CommonUtil.getRecordModifySuccessMsg("Email Provider"));
                }
                populateEmailProviderFromUI(tmpDTO);
                emailAndSMSBO.saveOrUpdateEmailConfig(tmpDTO);
                (this.Master as CSMaster).setNotyMsg(msg);
                loadEmailAndSMSProviderGrid(true);
                /*
				 * TODO - In Add mode If this is first entry then assign Email provider to all PROPERTY_ALERT_CONFIG
				 */
            }
            else
            {
                activeModalHdn.Value = addModifyEmailProviderModal;
                SetFocus(txtEmailProviderName);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelEmailProviderModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateEmailProviderAddModify()
    {
        Page.Validate(addModifyEmailProviderError);
        bool IsValid = Page.IsValid;
        if (IsValid)
        {
        	if (EmailProviderModalAction.ADD.ToString().Equals(EmailProviderModalActionHdnBtn.Value))
        	{
        		if (getSessionPageData().EmailConfigList.Any(x => x.Name.Equals(txtEmailProviderName.Text.TrimNullable()))) {
        			setErrorMessage("Provider with same name already exist.", addModifyEmailProviderError);
        			IsValid = false;
        		}
        	}
        }
        return IsValid;
    }
    //Email Provider Modal - End
    //SMS Provider Modal - Start
    private void initSMSProviderModalFields()
    {
        lbSMSProviderModalTitle.Text = (SMSProviderModalAction.ADD.ToString().Equals(SMSProviderModalActionHdnBtn.Value))
            ? Constants.ICON.ADD + Resources.Labels.ADD_SMS_PROVIDER : Constants.ICON.MODIFY + Resources.Labels.MODIFY_SMS_PROVIDER;
    }
    private void initSMSProviderSectionFields(SmsConfigDTO tmpDTO)
    {
        if (tmpDTO != null) txtSMSProviderName.Text = tmpDTO.Name; else txtSMSProviderName.Text = null;
        if (tmpDTO != null) txtSMSProviderURL.Text = tmpDTO.Url; else txtSMSProviderURL.Text = null;
        if (tmpDTO != null) txtSMSProviderUserId.Text = tmpDTO.UserId; else txtSMSProviderUserId.Text = null;
        if (tmpDTO != null) txtSMSProviderPassword.Text = tmpDTO.Password; else txtSMSProviderPassword.Text = null;
        if (tmpDTO != null) txtSMSProviderSenderId.Text = tmpDTO.SenderId; else txtSMSProviderSenderId.Text = null;
        if (tmpDTO != null) cbSMSProviderDefault.Checked = tmpDTO.IsDefault == IsDefault.Yes; else cbSMSProviderDefault.Checked = false;

        cbSMSProviderDefault.Enabled = !cbSMSProviderDefault.Checked;
    }
    private void populateSMSProviderFromUI(SmsConfigDTO tmpDTO)
    {
        tmpDTO.Name = txtSMSProviderName.Text.TrimNullable();
        tmpDTO.Url = txtSMSProviderURL.Text.TrimNullable();
        tmpDTO.UserId = txtSMSProviderUserId.Text.TrimNullable();
        tmpDTO.Password = txtSMSProviderPassword.Text.TrimNullable();
        tmpDTO.SenderId = txtSMSProviderSenderId.Text.TrimNullable();
        tmpDTO.IsDefault = cbSMSProviderDefault.Checked ? IsDefault.Yes : IsDefault.No;
        tmpDTO.UpdateUser = getUserDefinitionDTO().Username;
    }
    private SmsConfigDTO populateSMSProviderAdd()
    {
        SmsConfigDTO tmpDTO = new SmsConfigDTO();
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        tmpDTO.FirmNumber = userDef.FirmNumber;
        tmpDTO.InsertUser = userDef.Username;
        return tmpDTO;
    }
    private void setSelectedSMSProvider(long Id)
    {
        List<SmsConfigDTO> tmpList = getSessionPageData().SMSConfigList;
        tmpList.ForEach(c => c.isUISelected = false);
        if (Id > 0) tmpList.Find(c => c.Id == Id).isUISelected = true;
    }
    private SmsConfigDTO getSelectedSMSProvider(long Id)
    {
        List<SmsConfigDTO> tmpList = getSessionPageData().SMSConfigList;
        return (Id > 0) ? tmpList.Find(c => c.Id == Id) : tmpList.Find(c => c.isUISelected);
    }
    protected void onClickAddSMSProviderBtn(object sender, EventArgs e)
    {
        try
        {
            SMSProviderModalActionHdnBtn.Value = SMSProviderModalAction.ADD.ToString();
            initSMSProviderModalFields();
            setSelectedSMSProvider(-1);
            initSMSProviderSectionFields(null);
            activeModalHdn.Value = addModifySMSProviderModal;
            SetFocus(txtSMSProviderName);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifySMSProviderBtn(object sender, EventArgs e)
    {
        try
        {
            SMSProviderModalActionHdnBtn.Value = SMSProviderModalAction.MODIFY.ToString();
            initSMSProviderModalFields();
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedSMSProvider(selectedIndex);
            initSMSProviderSectionFields(getSelectedSMSProvider(0));
            activeModalHdn.Value = addModifySMSProviderModal;
            SetFocus(txtSMSProviderName);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void saveSMSProvider(object sender, EventArgs e)
    {
    	try
    	{
    		if (validateSMSProviderAddModify())
    		{
    			SmsConfigDTO tmpDTO = null;
    			string msg = CommonUtil.getNotySuccessMsg(CommonUtil.getRecordAddSuccessMsg("SMS Provider"));
    			if (SMSProviderModalAction.ADD.ToString().Equals(SMSProviderModalActionHdnBtn.Value))
    			{
    				tmpDTO = populateSMSProviderAdd();
    			}
    			else
    			{
    				tmpDTO = getSelectedSMSProvider(0);
    				msg = CommonUtil.getNotySuccessMsg(CommonUtil.getRecordModifySuccessMsg("SMS Provider"));
    			}
    			populateSMSProviderFromUI(tmpDTO);
    			emailAndSMSBO.saveOrUpdateSmsConfig(tmpDTO);
    			(this.Master as CSMaster).setNotyMsg(msg);
    			loadEmailAndSMSProviderGrid(true);
                /*
				 * TODO - In Add mode If this is first entry then assign SMS provider to all PROPERTY_ALERT_CONFIG
				 */
    		}
    		else
    		{
    			activeModalHdn.Value = addModifySMSProviderModal;
    			SetFocus(txtSMSProviderName);
    		}
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    protected void cancelSMSProviderModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateSMSProviderAddModify()
    {
        Page.Validate(addModifySMSProviderError);
        bool IsValid = Page.IsValid;
        if (IsValid)
        {
        	if (SMSProviderModalAction.ADD.ToString().Equals(SMSProviderModalActionHdnBtn.Value))
        	{
        		if (getSessionPageData().SMSConfigList.Any(x => x.Name.Equals(txtSMSProviderName.Text.TrimNullable()))) {
        			setErrorMessage("Provider with same name already exist.", addModifySMSProviderError);
        			IsValid = false;
        		}
        	}
        }
        return IsValid;
    }
    //SMS Provider Modal - End
}