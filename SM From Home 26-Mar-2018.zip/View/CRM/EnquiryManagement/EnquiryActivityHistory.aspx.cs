﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.TelephonyProvider;
using System.Web;

public partial class EnquiryActivityHistory : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addMasterDataError = "addMasterDataError";
    string addActivityModalError = "addActivityModalError";
    string addReminderModalError = "addReminderModalError";
    string addReminderModalError1 = "addReminderModalError1";
    string addCommentModalError = "addCommentModalError";
    string selectUserAssigneeModalError = "selectUserAssigneeModalError";
    string selectBookingUnitModalError = "selectBookingUnitModalError";

    string addMasterDataModal = "addMasterDataModal";
    string addActivityModal = "addActivityModal";
    string addReminderModal = "addReminderModal";
    string addCommentModal = "addCommentModal";
    string editActivityCommentModal = "editActivityCommentModal";
    string editActivityCommentModalError = "editActivityCommentModalError";
    string selectUserAssigneeModal = "selectUserAssigneeModal";
    string selectBookingUnitModal = "selectBookingUnitModal";
    string ClickToCallModal = "ClickToCallModal";
    string clickToCallModalError = "clickToCallModalError";
    string closeEnquiryModal = "closeEnquiryModal";
    string closeEnquiryModalError = "closeEnquiryModalError";
    string ShowActivityLogModal = "ShowActivityLogModal";
    string SearchFilterModal = "SearchFilterModal";
    string ShowAttachmentModal = "ShowAttachmentModal";
    DropdownBO drpBO = new DropdownBO();
    EnquiryBO enquiryBO = new EnquiryBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    PropertyUserBO propertyUserBO = new PropertyUserBO();
    DocumentBO documentBO = new DocumentBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                EnquiryActivityHistoryNavDTO navDto = ApplicationUtil.getPageNavDTO<EnquiryActivityHistoryNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_MY_ENQUIRIES)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
        RegisterPostBackControl();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        drpBO.drpDataBase(drpActivityCommunicationMedia, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.COMMUNICATION_MEDIA.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.populateDrpEnqActivity(drpActivityType);
        drpBO.drpEnum<ActivityTypeFilter>(drpRecordTypeFilter, Constants.SELECT_ITEM);
    }
    public void setErrorMessage(string message, string group)
    {
    	string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
	        CustomValidator val = new CustomValidator();
	        val.IsValid = false;
	        val.ErrorMessage = message;
	        val.ValidationGroup = group;
	        this.Page.Validators.Add(val);
        }
    }
    private void RegisterPostBackControl()
    {
        if (AttachmentGrid.Rows.Count > 0)
        {
            for (var i = 0; i < AttachmentGrid.Rows.Count; i++)
            {
                LinkButton tmpBtn = (LinkButton)AttachmentGrid.Rows[i].FindControl("lnkDownloadBtn");
                if (tmpBtn != null)
                {
                    ScriptManager mgr = ScriptManager.GetCurrent(this.Page);
                    mgr.RegisterPostBackControl(tmpBtn);
                }
            }
        }
    }
    private void doInit(EnquiryActivityHistoryNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(EnquiryActivityHistoryNavDTO navDto)
    {
        try
        {
            EnquiryActivityHistoryPageDTO PageDTO = new EnquiryActivityHistoryPageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            setSearchFilter(null);
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            fetchEnquiryAndInitHistory(navDto.EnquiryId);            
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void initContactDrp(EnquiryDetailDTO enquiryDTO)
    {
        drpCustomerContact.Items.Clear();
        if (!String.IsNullOrEmpty(enquiryDTO.ContactInfo.Contact))
        {
            drpCustomerContact.Items.Add(new ListItem("Primary Contact: " + enquiryDTO.ContactInfo.Contact, 
            		enquiryDTO.ContactInfo.Contact));
        }
        if (!String.IsNullOrEmpty(enquiryDTO.ContactInfo.AltContact))
        {
            drpCustomerContact.Items.Add(new ListItem("Alternate Contact: " + enquiryDTO.ContactInfo.AltContact, 
            		enquiryDTO.ContactInfo.AltContact));
        }
    }
    private void initVirtualPhoneDrp(IList<VirtualPhoneDTO> phoneDTOList) {
    	drpVirtualPhone.Items.Clear();
    	foreach(VirtualPhoneDTO tmpDTO in phoneDTOList) {
    		drpVirtualPhone.Items.Add(new ListItem(tmpDTO.PhoneNumber, tmpDTO.PhoneNumber));
    	}
    }
    private void renderPageFieldsWithEntitlement()
    {
        addCheckBoxAttributes();
        EnquiryDetailDTO enquiryDTO = getEnquiryDetailDTO();
        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        liReassignEnquiryBtn.Visible = (enquiryDTO.Status == EnquiryStatus.Open);
        liReopenEnquiry.Visible = (enquiryDTO.Status == EnquiryStatus.Lost);
        liCloseEnquiry.Visible = (enquiryDTO.Status == EnquiryStatus.Open);
        liBookPropertyUnit.Visible = (enquiryDTO.Status == EnquiryStatus.Open && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.BOOK_PR_UNIT));
        liCicktoCall.Visible = (enquiryDTO.Status == EnquiryStatus.Open && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.ENQUIRY_CLICK_TO_CALL));
        ulEnquiryDetailOptions.Visible = lnkReassignEnquiryBtn.Visible || lnkReopenEnquiry.Visible || lnkCloseEnquiry.Visible || liBookPropertyUnit.Visible;
    }
    private void addCheckBoxAttributes()
    {
        cbCopyEnquiryDetails.InputAttributes.Add("class", "styled");
    }
    private EnquiryActivityHistoryPageDTO getSessionPageData()
    {
        return (EnquiryActivityHistoryPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private EnquiryDetailDTO getEnquiryDetailDTO()
    {
        return getSessionPageData().EnquiryDTO;
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private void navigateToPreviousPage()
    {
        EnquiryActivityHistoryPageDTO pageDTO = getSessionPageData();
        if (pageDTO != null && pageDTO.PrevNavDTO != null)
        {
            object obj = pageDTO.PrevNavDTO;
            if (obj is EnquirySearchNavDTO)
            {
                EnquirySearchNavDTO navDTO = (EnquirySearchNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.ENQUIRY_SEARCH, true);
            }
            else if (obj is UserEnquiryHistoryNavDTO)
            {
                UserEnquiryHistoryNavDTO navDTO = (UserEnquiryHistoryNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.USER_ENQUIRY_HISTORY, true);
            }
            else if (obj is EnquiryDetailNavDTO)
            {
                EnquiryDetailNavDTO navDTO = (EnquiryDetailNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.ENQUIRY_DETAILS, true);
            }
        }
        Response.Redirect(Constants.URL.ENQUIRY_SEARCH, true);
    }
    private void fetchEnquiryAndInitHistory(long EnquiryId)
    {
        EnquiryDetailDTO enquiryDTO = enquiryBO.fetchEnquiryDetails(EnquiryId, true);
        EnquiryActivityHistoryPageDTO pageDTO = getSessionPageData();
        pageDTO.EnquiryDTO = enquiryDTO;
        initPageInfo(enquiryDTO);
        initContactDrp(enquiryDTO);
    }
    private void initPageInfo(EnquiryDetailDTO enquiryDTO)
    {
        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        enquiryDTO.Assignee.FullName = CommonUIConverter.getCustomerFullName(enquiryDTO.Assignee.FirstName, enquiryDTO.Assignee.LastName);
        if (enquiryDTO.EnquiryActivities.Count > 0)
        {
            List<EnquiryActivityDTO> list = new List<EnquiryActivityDTO>(enquiryDTO.EnquiryActivities);
            enquiryDTO.EnquiryActivities.Clear();
            enquiryDTO.EnquiryActivities = new HashSet<EnquiryActivityDTO>(list.OrderByDescending(x => x.DateLogged).ThenByDescending(x => x.InsertDate));
        }
        lbCustomerName.Text = CommonUIConverter.getCustomerFullName(enquiryDTO.Salutation.Name, enquiryDTO.FirstName, "", enquiryDTO.LastName);
        lbCustomerContact.Text = enquiryDTO.ContactInfo.Contact;
        btnEnquiryInfoHdn.Attributes["row-info"] = CommonUIConverter.getGridViewRowInfo(enquiryDTO);
        lbEnqAssignee.Text = enquiryDTO.Assignee.FullName;
        lbEnquiryRefNo.Text = enquiryDTO.EnquiryRefNo;
        lbLeadRefNo.Text = (enquiryDTO.Lead != null) ? enquiryDTO.Lead.LeadRefNo : null;
        pnlLeadRefNo.Visible = enquiryDTO.Lead != null;
        lbEnqUnitType.Text = (enquiryDTO.PrUnitType != null) ? enquiryDTO.PrUnitType.Name : null;
        lbEnqSource.Text = (enquiryDTO.EnquirySource != null) ? enquiryDTO.EnquirySource.Name : null;
        lbEnqBudget.Text = (enquiryDTO.Budget != null) ? enquiryDTO.Budget.ToString() : null;
        lbEnqStatus.Text = enquiryDTO.Status.ToString();
        //Populate Activity History
        assignUiIndexToActivity(enquiryDTO);
        populateActivityGrid(enquiryDTO);
        //Upcoming Event Panel
        populateUpcomingReminders(enquiryDTO);
    }
    private void populateUpcomingReminders(EnquiryDetailDTO enquiryDTO)
    {
        enquiryDTO.UpcomingEvents = new List<EnquiryActivityDTO>();
        ISet<EnquiryActivityDTO> activities = enquiryDTO.EnquiryActivities;
        if (activities != null && activities.Count > 0)
        {
            foreach (EnquiryActivityDTO activityDTO in activities)
            {
                if (activityDTO.RecordType == EnqActivityRecordType.Task && activityDTO.Status == EnqLeadActivityStatus.Open)
                {
                    enquiryDTO.UpcomingEvents.Add(activityDTO);
                }
            }
        }
        ulUpcomingReminderOptions.Visible = (enquiryDTO.Status == EnquiryStatus.Open);
        pnlUpcomingReminderEmpty.Visible = enquiryDTO.UpcomingEvents.Count == 0;
        upcomingReminderGrid.Visible = enquiryDTO.UpcomingEvents.Count > 0;
        upcomingReminderGrid.DataSource = enquiryDTO.UpcomingEvents;
        upcomingReminderGrid.DataBind();
    }
    private void populateActivityGrid(EnquiryDetailDTO enquiryDTO)
    {
        activityHistoryGrid.DataSource = new List<EnquiryActivityDTO>();
        if (enquiryDTO != null && enquiryDTO.EnquiryActivities.Count > 0)
        {
            
            activityHistoryGrid.DataSource = enquiryDTO.EnquiryActivities;
            ActivityFilterDTO FilterDTO = getSearchFilter();
            List<EnquiryActivityDTO> tmpList = enquiryDTO.EnquiryActivities.ToList();
            if (FilterDTO.ActivityTypeList != null && FilterDTO.ActivityTypeList.Count > 0)
            {
                tmpList = new List<EnquiryActivityDTO>();
                foreach (EnquiryActivityDTO tmpDTO in enquiryDTO.EnquiryActivities)
                {
                    if (FilterDTO.ActivityTypeList.Contains(tmpDTO.RecordType.GetDescription())
                        || (FilterDTO.ActivityTypeList.Contains(Constants.FILTER.ATTACHMENT) && tmpDTO.NoOfAttachments > 0))
                    {
                        tmpList.Add(tmpDTO);
                    }
                }
            }
            activityHistoryGrid.DataSource = tmpList;
        }
        activityHistoryGrid.DataBind();
    }
    private void assignUiIndexToActivity(EnquiryDetailDTO enquiryDTO)
    {
        ISet<EnquiryActivityDTO> activities = enquiryDTO.EnquiryActivities;
        if (activities != null && activities.Count > 0)
        {
            long uiIndex = 1;
            foreach (EnquiryActivityDTO activityDTO in activities)
            {
                activityDTO.UiIndex = uiIndex++;
                activityDTO.RowInfo = CommonUIConverter.getGridViewRowInfo(activityDTO);
                activityDTO.LoggedBy.FullName = CommonUIConverter.getCustomerFullName(activityDTO.LoggedBy.FirstName, activityDTO.LoggedBy.LastName);
                activityDTO.EnquiryDetail = enquiryDTO;                
                if (activityDTO.RecordType == EnqActivityRecordType.Task && !string.IsNullOrWhiteSpace(activityDTO.RevRefNo))
                {
                    EnquiryActivityDTO eventDTO = activities.ToList<EnquiryActivityDTO>().Find(x => !string.IsNullOrWhiteSpace(x.RefNo) && x.RefNo == activityDTO.RevRefNo);
                    activityDTO.PrevScheduledDate = eventDTO.ScheduledDate;
                    if (eventDTO.CallHistoryDTO != null)
                    {
                        activityDTO.CallHistoryDTO.RecordingUrl = eventDTO.CallHistoryDTO.RecordingUrl;
                    }
                }
            }
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickReassignEnquiryBtn(object sender, EventArgs e)
    {
        try
        {
            EnquiryDetailDTO enquiryDTO = getEnquiryDetailDTO();
            if (enquiryDTO.Status == EnquiryStatus.Open)
            {
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                drpBO.drpDataBase(drpUserAssignee, DrpDataType.ACTIVE_USERS_WITH_PR_ACCESS, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(),
                    Constants.SELECT_ITEM, userDefDto.FirmNumber);
                drpBO.removeSelectedItem(drpUserAssignee, enquiryDTO.Assignee.Id.ToString());
                activeModalHdn.Value = selectUserAssigneeModal;
            }
            else
            {
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(Resources.Messages.ERROR_ENQUIRY_REASSIGN_NOT_OPEN));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickBookPropertyUnitBtn(object sender, EventArgs e)
    {
        try
        {
            EnquiryDetailDTO enquiryDTO = getEnquiryDetailDTO();
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (enquiryDTO.Status == EnquiryStatus.Open)
            {
                drpBO.drpDataBase(drpTower, DrpDataType.PROPERTY_TOWER, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(), null, userDefDto.FirmNumber);
                drpTower.Text = CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Id.ToString();
                drpBO.drpDataBase(drpUnitNo, DrpDataType.PR_AVAILABLE_UNIT, drpTower.Text, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                cbCopyEnquiryDetails.Checked = true;
                activeModalHdn.Value = selectBookingUnitModal;
            }
            else
            {
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Enquiry status is not Open. Cannot place booking against this enquiry."));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickReopenEnquiryBtn(object sender, EventArgs e)
    {
        try
        {
            EnquiryDetailDTO enquiryDTO = getEnquiryDetailDTO();
            if (validateReopenEnquiry(enquiryDTO))
            {
                enquiryBO.reOpenEnquiry(enquiryDTO.Id, getUserDefinitionDTO());
                fetchEnquiryAndInitHistory(enquiryDTO.Id);
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format("Enquiry# {0} is reopened successfully.", enquiryDTO.EnquiryRefNo)));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void selectUpcomingEvent(long EventId)
    {
        EnquiryDetailDTO enquiryDetailDTO = getEnquiryDetailDTO();
        enquiryDetailDTO.UpcomingEvents.ForEach(x => x.isUISelected = false);
        if (EventId > 0)
        {
            enquiryDetailDTO.UpcomingEvents.Find(x => x.Id == EventId).isUISelected = true;
        }
    }
    private bool validateReopenEnquiry(EnquiryDetailDTO enquiryDTO)
    {
        string msg = "";
        if (enquiryDTO.Status != EnquiryStatus.Lost) msg = Resources.Messages.ERROR_ENQUIRY_REOPEN_NOT_CLOSED;
        else if (enquiryDTO.PrUnitSaleDetail != null && enquiryDTO.PrUnitSaleDetail.Id > 0) msg = Resources.Messages.ERROR_ENQUIRY_REOPEN_UNIT_BOOKED;
        else msg = CommonUIConverter.getDuplicateLeadEnquiryMsg(
            enquiryBO.fetchDuplicateEnquiryOrLead(
            enquiryDTO.Property.Id, enquiryDTO.ContactInfo.Contact, enquiryDTO.ContactInfo.AltContact), 
            enquiryDTO.ContactInfo.Contact, enquiryDTO.ContactInfo.AltContact, enquiryDTO.EnquiryRefNo);
        if (!string.IsNullOrWhiteSpace(msg))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(msg));
            return false;
        }
        return true;
    }
    private void selectUpcomingReminder(long Id)
    {
        EnquiryDetailDTO enquiryDTO = getEnquiryDetailDTO();
        enquiryDTO.UpcomingEvents.ForEach(x => x.isUISelected = false);
        if (Id > 0)
        {
            enquiryDTO.UpcomingEvents.Find(x => x.Id == Id).isUISelected = true;
        }
    }
    private EnqActivityMode getEnqActivityMode()
    {
        return EnumHelper.ToEnum<EnqActivityMode>(enqActivityModeHdn.Value);
    }
    private void setEnqActivityMode(EnqActivityMode action)
    {
        enqActivityModeHdn.Value = action.ToString();
    }
    protected string getActivityDesc(string activityType)
    {
        return EnumHelper.ToEnum<EnqActivityType>(activityType).GetDescription();
    }
    //Edit Activity Comments Modal - start
    private EnquiryActivityDTO getSelectedActivity()
    {
        List<EnquiryActivityDTO> tmpList = getEnquiryDetailDTO().EnquiryActivities.ToList<EnquiryActivityDTO>();
        return tmpList.Find(c => c.isUISelected);
    }
    private void setSelectedActivity(long Id)
    {
        EnquiryDetailDTO enquiryDetailDTO = getEnquiryDetailDTO();
        enquiryDetailDTO.EnquiryActivities.ToList<EnquiryActivityDTO>().ForEach(x => x.isUISelected = false);
        if (Id > 0)
        {
            enquiryDetailDTO.EnquiryActivities.ToList<EnquiryActivityDTO>().Find(x => x.Id == Id).isUISelected = true;
        }
    }
    protected void onClickModifyActivityComments(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedActivity(selectedIndex);
            EnquiryActivityDTO selectedActivityDTO = getSelectedActivity();
            activeModalHdn.Value = editActivityCommentModal;
            txtActivityEditComments.Text = getSelectedActivity().Comments;
            divAttchmentEditActModalRow.Visible = (selectedActivityDTO.ActivityType != EnqActivityType.TASK);
            clearTempUploadFields();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void modifyActivityComments(object sender, EventArgs e)
    {
        try
        {
            string comments = txtActivityEditComments.Text.TrimNullable();
            if (!string.IsNullOrWhiteSpace(comments))
            {
                EnquiryActivityDTO tmpDTO = getSelectedActivity();
                List<EnqActAttachmentDTO> tmpAttachments = getAttachmentFromTempFolder();
                if (!tmpDTO.Comments.Equals(comments) || tmpAttachments.Count > 0)
                {
                    tmpDTO.Comments = comments;
                    tmpDTO.Attachments = tmpAttachments;
                    enquiryBO.editEnquiryActivity(tmpDTO, getUserDefinitionDTO());
                    clearTempUploadFields();
                    (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("Activity is updated successfully."));
                    fetchEnquiryAndInitHistory(getEnquiryDetailDTO().Id);
                }
            }
            else
            {
                setErrorMessage("Please enter Comment.", editActivityCommentModalError);
                activeModalHdn.Value = editActivityCommentModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickActivityCommentLogs(object sender, EventArgs e)
    {
        try
        {
        	LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            IList<EnqActCommentLogDTO> result = enquiryBO.fetchEnqActCommentLog(selectedIndex);
            ActivityLogGrid.DataSource = (result != null) ? result : new List<EnqActCommentLogDTO>();
            ActivityLogGrid.DataBind();
            activeModalHdn.Value = ShowActivityLogModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelActivityLogModal(object sender, EventArgs e)
    {
        try
        {
            setSelectedActivity(0);
            clearTempUploadFields();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Edit Activity Comments Modal - end
    //Attachment Logs - Start
    private void bindAttachments(List<EnqActAttachmentDTO> result)
    {
        AttachmentGrid.DataSource = (result != null) ? result : new List<EnqActAttachmentDTO>();
        AttachmentGrid.DataBind();
    }
    protected void onClickActivityAttachments(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedActivity(selectedIndex);
            bindAttachments(enquiryBO.fetchEnqActAttachments(selectedIndex));
            activeModalHdn.Value = ShowAttachmentModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickDownloadAttachmentBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            EnqActAttachmentDTO attachmentDTO = enquiryBO.fetchEnqActAttachment(selectedIndex);
            Response.Buffer = true;
            Response.Charset = "";
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + attachmentDTO.FileName);
            Response.BinaryWrite(attachmentDTO.Content);
            Response.Flush();
            UpdatePanel1.Update();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickDeleteAttachmentBtn(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            enquiryBO.deleteEnqActAttachment(selectedIndex);
            long selectedActivity = getSelectedActivity().Id;
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("Attachment is deleted successfully."));
            fetchEnquiryAndInitHistory(getEnquiryDetailDTO().Id);
            setSelectedActivity(selectedActivity);
            bindAttachments(enquiryBO.fetchEnqActAttachments(selectedActivity));
            if (getSelectedActivity().NoOfAttachments > 0)
            {
                activeModalHdn.Value = ShowAttachmentModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelAttachmentModal(object sender, EventArgs e)
    {
        try
        {
            setSelectedActivity(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Attachments logs - End
    //Close Enquiry Modal - start
    protected void onClickCloseEnquiryBtn(object sender, EventArgs e)
    {
        try
        {
        	activeModalHdn.Value = closeEnquiryModal;
        	txtEnqCloseReason.Text = null;
            clearTempUploadFields();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void closeEnquiry(object sender, EventArgs e)
    {
        try
        {
        	if(validateCloseEnquiry()) {
        		EnquiryDetailDTO enquiryDTO = getEnquiryDetailDTO();
                if (enquiryDTO.Status == EnquiryStatus.Open)
                {
                    List<EnqActAttachmentDTO> attachments = getAttachmentFromTempFolder();
                    enquiryBO.closeEnquiry(enquiryDTO.Id, txtEnqCloseReason.Text.TrimNullable(), attachments, getUserDefinitionDTO());
                    clearTempUploadFields();
                    fetchEnquiryAndInitHistory(enquiryDTO.Id);
                    (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format("Enquiry# {0} is closed successfully.", enquiryDTO.EnquiryRefNo)));
                }
                else
                {
                    (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(Resources.Messages.ERROR_ENQUIRY_CLOSE_NOT_OPEN));
                }
        	} else {
        		activeModalHdn.Value = closeEnquiryModal;
        	}
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelEnqLostReasonModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateCloseEnquiry() {
    	Page.Validate(closeEnquiryModalError);
        return Page.IsValid;
    }
    //Close Enquiry Modal - end
    //Booking Unit Selection logic - start
    protected void onSelectBookingTower(object sender, EventArgs e)
    {
        try
        {
            drpBO.drpDataBase(drpUnitNo, DrpDataType.PR_AVAILABLE_UNIT, drpTower.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            activeModalHdn.Value = selectBookingUnitModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void BookPropertyUnit(object sender, EventArgs e)
    {
        try
        {
            Page.Validate(selectBookingUnitModalError);
            bool isValid = Page.IsValid;
            if (isValid)
            {
                long UnitId = long.Parse(drpUnitNo.Text);
                EnquiryDetailDTO enquiryDTO = getEnquiryDetailDTO();
                BookingFormNavDTO navDTO = new BookingFormNavDTO();
                navDTO.PrUnitId = UnitId;
                navDTO.EnquiryId = enquiryDTO.Id;
                navDTO.copyCustomerDtls = cbCopyEnquiryDetails.Checked;
                //Create Current paga navigation
                EnquiryActivityHistoryNavDTO currPageNavDTO = new EnquiryActivityHistoryNavDTO();
                currPageNavDTO.EnquiryId = enquiryDTO.Id;
                currPageNavDTO.PrevNavDto = getSessionPageData().PrevNavDTO;
                navDTO.PrevNavDto = currPageNavDTO;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotyInfoMsg(string.Format("Booking will be placed against enquiry #{0}.", enquiryDTO.EnquiryRefNo)));
                Response.Redirect(Constants.URL.BOOKING_FORM, true);
            }
            else
            {
                activeModalHdn.Value = selectBookingUnitModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelBookingUnitModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Booking Unit Selection logic - end
    //User Assignee Selection logic - start
    protected void ReassignEnquiry(object sender, EventArgs e)
    {
        try
        {
            Page.Validate(selectUserAssigneeModalError);
            bool isValid = Page.IsValid;
            if (isValid)
            {
                long AssigneeId = long.Parse(drpUserAssignee.Text);
                EnquiryDetailDTO EnquiryDTO = getEnquiryDetailDTO();
                enquiryBO.ReAssignEnquiry(EnquiryDTO.Id, AssigneeId, DateUtil.getUserLocalDateTime(), getUserDefinitionDTO());
                fetchEnquiryAndInitHistory(EnquiryDTO.Id);
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format("Enquiry# {0} is reassigneed successfully.", EnquiryDTO.EnquiryRefNo)));
            }
            else
            {
                activeModalHdn.Value = selectUserAssigneeModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelUserAssigneeModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //User Assignee Selection logic - end
    //Add Activity Modal - Start
    private EnquiryActivityDTO getSelectedUpcomingEvent()
    {
        List<EnquiryActivityDTO> upcomingEventList = getEnquiryDetailDTO().UpcomingEvents.ToList<EnquiryActivityDTO>();
        return upcomingEventList.Find(c => c.isUISelected);
    }
    private void resetActivityModalFields()
    {
        txtActivityDate.Text = DateUtil.getTodayDate();
        drpActivityCommunicationMedia.Text = null;
        txtActivityComments.Text = null;
        drpActivityType.Text = null;
        drpActivityType.Enabled = true;
        lbAddActivityModalHeader.Text = Constants.ICON.ENQUIRY_ADD_ACTIVITY + Resources.Labels.ADD_ACTIVITY;
    }
    private void initActivityModalAction(EnqActivityMode mode, long selectedIndex)
    {
        setEnqActivityMode(mode);
        selectUpcomingEvent(selectedIndex);
        resetActivityModalFields();
        activeModalHdn.Value = addActivityModal;
    }
    protected void onClickAddActivityBtn(object sender, EventArgs e)
    {
        try
        {
            initActivityModalAction(EnqActivityMode.ADD_ACTIVITY, 0);
            clearTempUploadFields();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void addActivity(object sender, EventArgs e)
    {
        try
        {
            if (validateAddActivity())
            {
                UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
                EnquiryDetailDTO enquiryDTO = getEnquiryDetailDTO();
                EnquiryActivityDTO activityDTO = CommonUtil.createNewEnquiryActivityDTO(enquiryDTO.Id, EnqActivityRecordType.Activity, userDefDTO);
                activityDTO.ReminderMode = ReminderMode.None;
                activityDTO.DateLogged = DateUtil.getCSDateTime(txtActivityDate.Text).Value;
                activityDTO.LoggedBy = userDefDTO.FirmMember;
                activityDTO.ActivityType = EnumHelper.ToEnum<EnqActivityType>(drpActivityType.Text);
                activityDTO.CommunicationMedia = CommonUIConverter.getMasterControlDTO(drpActivityCommunicationMedia.Text, null);
                activityDTO.Comments = txtActivityComments.Text.TrimNullable();
                activityDTO.Status = EnqLeadActivityStatus.Completed;
                activityDTO.Attachments = getAttachmentFromTempFolder();

                enquiryBO.addEnquiryActivity(activityDTO, getEnqActivityMode(), 0, userDefDTO);
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("New activity is added successfully."));
                clearTempUploadFields();
                setEnqActivityMode(EnqActivityMode.NONE);
                fetchEnquiryAndInitHistory(enquiryDTO.Id);
            }
            else
            {
                activeModalHdn.Value = addActivityModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelAddActivityModal(object sender, EventArgs e)
    {
        try
        {
            setEnqActivityMode(EnqActivityMode.NONE);
            selectUpcomingEvent(0);
            clearTempUploadFields();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateAddActivity()
    {
        Page.Validate(addActivityModalError);
        return Page.IsValid;
    }
    //Add Activity Modal - End
    //Add Reminder Modal - Start
    private EnquiryActivityDTO getSelectedUpcomingReminder()
    {
        List<EnquiryActivityDTO> upcomingEventList = getEnquiryDetailDTO().UpcomingEvents.ToList<EnquiryActivityDTO>();
        return upcomingEventList.Find(c => c.isUISelected);
    }
    private void resetReminderModalFields()
    {
        txtReminderScheduledDate.Text = null;
        txtReminderComments.Text = null;
        pnlReminderInfo.Visible = false;
        divScheduledDate.Visible = true;
        EnqActivityMode mode = getEnqActivityMode();
        if (mode == EnqActivityMode.ADD_TASK)
        {
            lbReminderModalHeader.Text = Constants.ICON.ADD_REMINDER + Resources.Labels.ADD_TASK;
        }
        else if (mode == EnqActivityMode.RESCHEDULE_TASK)
        {
            EnquiryActivityDTO eventDTO = getSelectedUpcomingReminder();
            lbReminderModalHeader.Text = Constants.ICON.RESCHEDULE_REMINDER + Resources.Labels.RESCHEDULE_TASK;
            pnlReminderInfo.Visible = true;
            lbReminderInfoLabel.Text = "Current Scheduled Date: ";
            lbReminderInfoValue.Text = DateUtil.getCSDateTime(eventDTO.ScheduledDate);
        }
    }
    private void initReminderModalAction(EnqActivityMode mode, long selectedIndex)
    {
        setEnqActivityMode(mode);
        selectUpcomingReminder(selectedIndex);
        resetReminderModalFields();
        activeModalHdn.Value = addReminderModal;
    }
    protected void onClickAddReminderBtn(object sender, EventArgs e)
    {
        try
        {
            initReminderModalAction(EnqActivityMode.ADD_TASK, 0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickRescheduleReminderBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            initReminderModalAction(EnqActivityMode.RESCHEDULE_TASK, selectedIndex);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void addReminder(object sender, EventArgs e)
    {
        try
        {
            if (validateAddReminder())
            {
                EnquiryDetailDTO enquiryDTO = getEnquiryDetailDTO();
                EnqActivityRecordType recordType = EnqActivityRecordType.Task;
                EnquiryActivityDTO reminderDTO = CommonUtil.createNewEnquiryActivityDTO(enquiryDTO.Id, recordType, getUserDefinitionDTO());
                reminderDTO.ReminderMode = getReminderMode();
                reminderDTO.DateLogged = DateUtil.getUserLocalDateTime();
                reminderDTO.LoggedBy = getUserDefinitionDTO().FirmMember;
                reminderDTO.ActivityType = EnqActivityType.TASK;
                reminderDTO.ScheduledDate = DateUtil.getCSDateTime(txtReminderScheduledDate.Text);
                reminderDTO.Comments = txtReminderComments.Text.TrimNullable();
                reminderDTO.Status = EnqLeadActivityStatus.Open; ;

                long parentId = 0;
                EnquiryActivityDTO parentEventDTO = getSelectedUpcomingEvent();
                if (parentEventDTO != null)
                {
                    parentId = parentEventDTO.Id;
                    reminderDTO.RevRefNo = parentEventDTO.RefNo;
                }

                reminderDTO.RefNo = enquiryBO.addEnquiryActivity(reminderDTO, getEnqActivityMode(), parentId, getUserDefinitionDTO());
                setReminderModalSuccessMsg(reminderDTO);
                setEnqActivityMode(EnqActivityMode.NONE);
                fetchEnquiryAndInitHistory(enquiryDTO.Id);
            }
            else
            {
                activeModalHdn.Value = addReminderModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setReminderModalSuccessMsg(EnquiryActivityDTO reminderDTO)
    {
        string msg = "";
        EnqActivityMode mode = getEnqActivityMode();
        if (mode == EnqActivityMode.ADD_TASK) msg = string.Format("Task# {0} is added successfully.", reminderDTO.RefNo);
        else if (mode == EnqActivityMode.RESCHEDULE_TASK) msg = string.Format("Task# {0} is rescheduled successfully.", reminderDTO.RevRefNo);
        else if (mode == EnqActivityMode.COMPLETE_TASK) msg = string.Format("Task# {0} is marked completed successfully.", reminderDTO.RevRefNo);
        else if (mode == EnqActivityMode.CANCEL_TASK) msg = string.Format("Task# {0} is cancelled successfully.", reminderDTO.RevRefNo);

        (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(msg));
    }
    private ReminderMode getReminderMode()
    {
        ReminderMode reminderMode = ReminderMode.None;
        EnqActivityMode mode = getEnqActivityMode();
        if (mode == EnqActivityMode.ADD_TASK) reminderMode = ReminderMode.Scheduled;
        else if (mode == EnqActivityMode.RESCHEDULE_TASK) reminderMode = ReminderMode.Rescheduled;
        else if (mode == EnqActivityMode.COMPLETE_TASK) reminderMode = ReminderMode.None;
        else if (mode == EnqActivityMode.CANCEL_TASK) reminderMode = ReminderMode.Cancelled;

        return reminderMode;
    }
    protected void cancelAddReminderModal(object sender, EventArgs e)
    {
        try
        {
            setEnqActivityMode(EnqActivityMode.NONE);
            selectUpcomingReminder(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateAddReminder()
    {
        string valGrp = addReminderModalError;
        EnqActivityMode activityMode = getEnqActivityMode();
        if (activityMode == EnqActivityMode.CANCEL_TASK || activityMode == EnqActivityMode.COMPLETE_TASK) valGrp = addReminderModalError1;
        Page.Validate(valGrp);
        return Page.IsValid;
    }
    //Add Reminder Modal - End
    //Close Reminder Modal - Start
    private void resetAddCommentModalFields()
    {
        txtAddComments.Text = null;
        EnqActivityMode mode = getEnqActivityMode();
        divCommentInfoModalRow.Visible = true;
        divAttachmentCommentModalRow.Visible = false;
        if (mode == EnqActivityMode.ADD_NOTE)
        {
            EnquiryActivityDTO eventDTO = getSelectedUpcomingReminder();
            lbAddCommentModalHeader.Text = Constants.ICON.ADD_NOTE + Resources.Labels.ADD_NOTE;
            divCommentInfoModalRow.Visible = false;
            divAttachmentCommentModalRow.Visible = true;
        }
        else if (mode == EnqActivityMode.COMPLETE_TASK)
        {
            EnquiryActivityDTO eventDTO = getSelectedUpcomingReminder();
            lbAddCommentModalHeader.Text = Constants.ICON.COMPLETE_REMINDER + Resources.Labels.MARK_AS_COMPLETED;
            lbAddCommentInfoLabel.Text = EnqActivityType.TASK.GetDescription();
            lbAddCommentInfoValue.Text = eventDTO.Comments;
        }
        else if (mode == EnqActivityMode.CANCEL_TASK)
        {
            EnquiryActivityDTO eventDTO = getSelectedUpcomingReminder();
            lbAddCommentModalHeader.Text = Constants.ICON.CANCEL_REMINDER + Resources.Labels.CANCEL_TASK;
            lbAddCommentInfoLabel.Text = EnqActivityType.TASK.GetDescription();
            lbAddCommentInfoValue.Text = eventDTO.Comments;
        }
    }
    private void initAddCommentModalAction(EnqActivityMode mode, long selectedIndex)
    {
        setEnqActivityMode(mode);
        selectUpcomingReminder(selectedIndex);
        resetAddCommentModalFields();
        activeModalHdn.Value = addCommentModal;
    }
    protected void onClickAddNoteBtn(object sender, EventArgs e)
    {
        try
        {
            initAddCommentModalAction(EnqActivityMode.ADD_NOTE, 0);
            clearTempUploadFields();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickCompleteReminderBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            initAddCommentModalAction(EnqActivityMode.COMPLETE_TASK, selectedIndex);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickCancelReminderBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            initAddCommentModalAction(EnqActivityMode.CANCEL_TASK, selectedIndex);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void addComment(object sender, EventArgs e)
    {
        try
        {
            if (validateAddComment())
            {

                EnquiryDetailDTO enquiryDTO = getEnquiryDetailDTO();
                EnqActivityMode enqActivityMode = getEnqActivityMode();
                EnqActivityRecordType recordType = (enqActivityMode == EnqActivityMode.ADD_NOTE) ? EnqActivityRecordType.Note : EnqActivityRecordType.Task;
                EnquiryActivityDTO reminderDTO = CommonUtil.createNewEnquiryActivityDTO(enquiryDTO.Id, recordType, getUserDefinitionDTO());
                reminderDTO.ReminderMode = getReminderMode();
                reminderDTO.DateLogged = DateUtil.getUserLocalDateTime();
                reminderDTO.LoggedBy = getUserDefinitionDTO().FirmMember;
                reminderDTO.ActivityType = (enqActivityMode == EnqActivityMode.ADD_NOTE) ? EnqActivityType.NOTE : EnqActivityType.TASK;
                reminderDTO.Comments = txtAddComments.Text.TrimNullable();
                reminderDTO.Status = EnqLeadActivityStatus.Completed;
                reminderDTO.Attachments = getAttachmentFromTempFolder();

                long parentId = 0;
                EnquiryActivityDTO parentReminderDTO = getSelectedUpcomingEvent();
                if (parentReminderDTO != null)
                {
                    parentId = parentReminderDTO.Id;
                    reminderDTO.RevRefNo = parentReminderDTO.RefNo;
                }

                reminderDTO.RefNo = enquiryBO.addEnquiryActivity(reminderDTO, enqActivityMode, parentId, getUserDefinitionDTO());
                clearTempUploadFields();
                setReminderModalSuccessMsg(reminderDTO);
                setEnqActivityMode(EnqActivityMode.NONE);
                fetchEnquiryAndInitHistory(enquiryDTO.Id);
            }
            else
            {
                activeModalHdn.Value = addCommentModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelAddCommentModal(object sender, EventArgs e)
    {
        try
        {
            setEnqActivityMode(EnqActivityMode.NONE);
            selectUpcomingReminder(0);
            clearTempUploadFields();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateAddComment()
    {
        Page.Validate(addCommentModalError);
        return Page.IsValid;
    }
    private void clearTempUploadFields()
    {
        hasFilesUploaded.Value = "";
        TmpUploadfileCntrlTarget.Value = "";
        documentBO.clearTempFileUploadDirectory(getUserDefinitionDTO().Username);
    }
    private List<EnqActAttachmentDTO> getAttachmentFromTempFolder()
    {
        List<EnqActAttachmentDTO> uploadList = new List<EnqActAttachmentDTO>();
        if (hasFilesUploaded.Value.Equals("Y"))
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            List<FileUIDTO> tmpList = documentBO.downloadTempUploadedFiles(
                string.Format(Constants.DOCUMENT_MANAGEMENT.TMP_FILE_UPLOAD_PATH, userDefDto.Username));
            if (tmpList != null && tmpList.Count > 0)
            {
                foreach (FileUIDTO tmpFile in tmpList)
                {
                    EnqActAttachmentDTO tmpDTO = new EnqActAttachmentDTO();
                    tmpDTO.FileName = tmpFile.Name;
                    tmpDTO.Content = tmpFile.Content;
                    tmpDTO.UploadDate = DateUtil.getUserLocalDateTime();
                    tmpDTO.UploadedBy = CommonUIConverter.getFirmMemberDTO(userDefDto.FirmMember.Id.ToString(), null);
                    tmpDTO.FirmNumber = userDefDto.FirmNumber;
                    tmpDTO.InsertUser = userDefDto.Username;
                    tmpDTO.UpdateUser = userDefDto.Username;
                    uploadList.Add(tmpDTO);
                }
            }
        }
        return uploadList;
    }
    //Close Reminder Modal - End
    //Master Data Modal save logic - Start
    protected void saveMasterData(object sender, EventArgs e)
    {
        try
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (MasterDataType.COMMUNICATION_MEDIA.ToString().Equals(masterDataModalTypeHdn.Value))
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(MasterDataType.COMMUNICATION_MEDIA.ToString(), txtMasterDataInput1.Text.TrimNullable(),
                       txtMasterDataInput2.Text.TrimNullable(), userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Communication Media");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpActivityCommunicationMedia, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.COMMUNICATION_MEDIA.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
            }
            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                activeModalHdn.Value = addMasterDataModal;
                setErrorMessage(errorMsg, addMasterDataError);
            }
            else
            {
                resetMasterDataModalFields();
                setParentModalFlag();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            activeModalHdn.Value = "";
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    protected void cancelMasterDataModal(object sender, EventArgs e)
    {
        try
        {
            resetMasterDataModalFields();
            setParentModalFlag();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    private void resetMasterDataModalFields()
    {
        txtMasterDataInput1.Text = "";
        txtMasterDataInput2.Text = "";
        masterDataModalTypeHdn.Value = "";
    }
    private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
    {
        string errorMsg = "";
        if (string.IsNullOrWhiteSpace(masterDataDto.Name))
        {
            errorMsg = string.Format(Resources.Messages.TEXTFIELD_REQUIRED, type);
        }
        else if (masterDataBO.isAlreadyExist(masterDataDto))
        {
            errorMsg = string.Format(Resources.Messages.ALREADY_EXIST_DB_ERROR, type);
        }
        return errorMsg;
    }
    private void setParentModalFlag()
    {
        activeModalHdn.Value = masterDataParentModalHdn.Value;
        masterDataParentModalHdn.Value = "";
    }
    //Master Data Modal save logic - End
    //Click to Call modal - start
    protected void onClickConnectCall(object sender, EventArgs e)
    {
        try
        {
    		UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
    		IList<VirtualPhoneDTO> vPhoneList = propertyUserBO.fetchOutgoingVitualPhonesAllocattedToUser(userDefDTO.FirmMember.Id, CommonUtil.getCurrentPropertyDTO(userDefDTO).Id);
    		if(vPhoneList != null && vPhoneList.Count > 0) {
    			if (drpCustomerContact.Items.Count == 1 && vPhoneList.Count == 1) {
    				makeCallToCustomer(userDefDTO.FirmMember.ContactInfo.Contact, drpCustomerContact.Text, vPhoneList[0].PhoneNumber);
    			} else {
    				drpCustomerContact.ClearSelection();
    				initVirtualPhoneDrp(vPhoneList);
    				
    				divCustomerNumber.Visible = (drpCustomerContact.Items.Count > 1);
    				lbCustomerNumberField.Visible = !divCustomerNumber.Visible;
    				lbCustomerNumber.Text = drpCustomerContact.Text;
    				
    				divVirtualPhone.Visible = (vPhoneList.Count > 1);
    				lbVirtualPhoneField.Visible = !divVirtualPhone.Visible;
    				lbVirtualPhone.Text = vPhoneList[0].PhoneNumber;
    				
    				activeModalHdn.Value = ClickToCallModal;
    			}    			
    		} else {
    			(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Virtual Phone is not assigned to you. Please contact your supervisor."));
    		}
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void makeCallToCustomer(string agentNumber, string customerNumber, string virtualPhone) {
    	UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        OutboundCallDialDTO callDialDTO = new OutboundCallDialDTO();
        callDialDTO.AgentNumber = agentNumber;
        callDialDTO.CustomerNumber = customerNumber;
        callDialDTO.VirtualPhone = virtualPhone;
        callDialDTO.PropertyId = CommonUtil.getCurrentPropertyDTO(userDefDTO).Id;

        CallClient callClient = new CallClient();
        CallHistoryDTO callHistoryDTO = callClient.placeOutBoundCall(callDialDTO, userDefDTO);
        //Add Call Activity
        EnquiryDetailDTO enquiryDTO = getEnquiryDetailDTO();
        EnquiryActivityDTO activityDTO = CommonUtil.createNewCallEnquiryActivityDTO(enquiryDTO.Id, EnqActivityRecordType.Call, userDefDTO, callHistoryDTO);
        enquiryBO.addEnquiryActivity(activityDTO, EnqActivityMode.MAKE_CALL, 0, userDefDTO);
        (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("Call is placed and new activity is added successfully."));
        setEnqActivityMode(EnqActivityMode.NONE);
        fetchEnquiryAndInitHistory(enquiryDTO.Id);
    }
    protected void connectToCall(object sender, EventArgs e)
    {
        try
        {
            Page.Validate(clickToCallModalError);
            bool isValid = Page.IsValid;
            if (isValid)
            {
            	UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
            	makeCallToCustomer(userDefDTO.FirmMember.ContactInfo.Contact, drpCustomerContact.Text, drpVirtualPhone.Text);
            }
            else
            {
                activeModalHdn.Value = ClickToCallModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelCall(object sender, EventArgs e)
    {
    }
    //Click to Call modal - end
    //Filter Criteria - Enquiry Search - Start
    private ActivityFilterDTO getSearchFilter()
    {
        return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            drpRecordTypeFilter.ClearSelection();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            ActivityFilterDTO filterDTO = getSearchFilter();
            if (!string.IsNullOrWhiteSpace(drpRecordTypeFilter.Text))
            {
                if (!filterDTO.ActivityTypeList.Contains(drpRecordTypeFilter.Text)) filterDTO.ActivityTypeList.Add(drpRecordTypeFilter.Text);
            }
            setSearchFilterTokens();
            populateActivityGrid(getSessionPageData().EnquiryDTO);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }

    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            populateActivityGrid(getSessionPageData().EnquiryDTO);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(ActivityFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new ActivityFilterDTO();
        if (getSessionPageData().FilterDTO.ActivityTypeList == null) getSessionPageData().FilterDTO.ActivityTypeList = new List<string>();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            getSearchFilter().ActivityTypeList.Remove(token);
            setSearchFilterTokens();
            populateActivityGrid(getSessionPageData().EnquiryDTO);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        ActivityFilterDTO filterDTO = getSearchFilter();
        string filter = null;
        if (filterDTO != null)
        {
            foreach (string type in filterDTO.ActivityTypeList)
            {
                filter = CommonUtil.addFilterToken(filter, type);
            }
        }
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - Enquiry Search - End
}
