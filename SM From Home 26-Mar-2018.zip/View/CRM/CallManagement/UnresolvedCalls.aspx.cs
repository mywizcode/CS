﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using ConstroSoft.Logic.BO;
using System.Web.UI.HtmlControls;

public partial class UnresolvedCalls : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string SearchFilterModal = "SearchFilterModal";
    DropdownBO drpBO = new DropdownBO();
    CallHistoryBO callHistoryBO = new CallHistoryBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                UnresolvedCallsNavDTO navDto = ApplicationUtil.getPageNavDTO<UnresolvedCallsNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_UNRESOLVED_CALLS)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);                
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }    
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();          
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    private void renderPageFieldsWithEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        if (unresolvedCallsGrid.Items.Count > 0)
        {
            bool isActionEnabled = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.RESOLVE_CALL);
            foreach (System.Web.UI.WebControls.ListViewItem itemRow in unresolvedCallsGrid.Items)
            {
                HtmlGenericControl tmpBtn = (HtmlGenericControl)itemRow.FindControl("liResolveCallBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.RESOLVE_CALL);
                tmpBtn = (HtmlGenericControl)itemRow.FindControl("ulUnresolveCallOptionsBtn");
                if (tmpBtn != null) tmpBtn.Visible = isActionEnabled;
            }
        }
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {

    }
    public void setErrorMessage(string message, string group)
    {
    	string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
	        CustomValidator val = new CustomValidator();
	        val.IsValid = false;
	        val.ErrorMessage = message;
	        val.ValidationGroup = group;
	        this.Page.Validators.Add(val);
        }
    }
    private void doInit(UnresolvedCallsNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new UnresolvedCallsPageDTO();
        initDropdowns();
        UnresolvedCallsFilterDTO FilterDTO = new UnresolvedCallsFilterDTO();
        setSearchFilter(FilterDTO);
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(UnresolvedCallsNavDTO navDto)
    {
        try
        {
            if (navDto != null)
            {
                setSearchFilter(navDto.filterDTO);
            }
            loadUnresolvedCallsSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private UnresolvedCallsPageDTO getSessionPageData()
    {
        return (UnresolvedCallsPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<UnresolvedCallGroupInfoDTO> getSearchList()
    {
        return getSessionPageData().SearchResult;
    }
    private UnresolvedCallGroupInfoDTO getSearchDTO(long UiIndex)
    {
        List<UnresolvedCallGroupInfoDTO> searchList = getSearchList();
        UnresolvedCallGroupInfoDTO selectedCallsDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            selectedCallsDTO = searchList.Find(c => c.UiIndex == UiIndex);
        }
        return selectedCallsDTO;
    }
    private void populateUnresolvedCallSearchGrid(List<UnresolvedCallGroupInfoDTO> tmpList)
    {
        unresolvedCallsGrid.DataSource = new List<UnresolvedCallGroupInfoDTO>();
        if (tmpList != null)
        {
            assignUiIndexToLeads(tmpList);
            unresolvedCallsGrid.DataSource = tmpList;
        }
        unresolvedCallsGrid.DataBind();        
    }
    private void assignUiIndexToLeads(List<UnresolvedCallGroupInfoDTO> tmpList)
    {
        if (tmpList != null && tmpList.Count > 0)
        {
            long uiIndex = 1;
            foreach (UnresolvedCallGroupInfoDTO tmpDTO in tmpList)
            {
                tmpDTO.UiIndex = uiIndex++;
            }
        }
    }
    private void loadUnresolvedCallsSearchGrid()
    {
        UnresolvedCallsPageDTO PageDTO = getSessionPageData();
        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        List<UnresolvedCallGroupInfoDTO> results = callHistoryBO.fetchUnresolvedCallsGridData(userDefDTO, getSearchFilter());
        PageDTO.SearchResult = (results != null) ? results : new List<UnresolvedCallGroupInfoDTO>();
        populateUnresolvedCallSearchGrid(PageDTO.SearchResult);

        unresolvedCallPanel.Visible = PageDTO.SearchResult.Count > 0;
        NoRecordMsg.Visible = !unresolvedCallPanel.Visible;
        
    }
    private UnresolvedCallsNavDTO getCurrentPageNavigation()
    {
        UnresolvedCallsPageDTO PageDTO = getSessionPageData();
        UnresolvedCallsNavDTO navDTO = new UnresolvedCallsNavDTO();
        navDTO.filterDTO = getSearchFilter();
        navDTO.PrevNavDto = PageDTO.PrevNavDTO;
        return navDTO;
    }
    protected void onClickResolveCallBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            UnresolvedCallGroupInfoDTO selectedCallDTO = getSearchDTO(selectedId);
            ResolveCallNavDTO navDTO = new ResolveCallNavDTO();
            navDTO.CustomerNumber = selectedCallDTO.CustomerNumber;
            navDTO.PrevNavDto = getCurrentPageNavigation();
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.RESOLVE_CALL, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Filter Criteria - Enquiry Search - Start
    private UnresolvedCallsFilterDTO getSearchFilter()
    {
        return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            UnresolvedCallsFilterDTO filterDTO = getSearchFilter();
            if (filterDTO.CustomerNumber != null) txtCustomerNumber.Text = filterDTO.CustomerNumber; else txtCustomerNumber.Text = null;
            if (filterDTO.IsAllUnresolvedCalls) cbAllUnresolvedCalls.Checked = true; else cbAllUnresolvedCalls.Checked = false;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            UnresolvedCallsFilterDTO filterDTO = new UnresolvedCallsFilterDTO();
            if (!string.IsNullOrWhiteSpace(txtCustomerNumber.Text))
            {
                filterDTO.CustomerNumber = txtCustomerNumber.Text.TrimNullable();
            }
            filterDTO.IsAllUnresolvedCalls = cbAllUnresolvedCalls.Checked;

            setSearchFilter(filterDTO);
            loadUnresolvedCallsSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }

    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            loadUnresolvedCallsSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(UnresolvedCallsFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new UnresolvedCallsFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            UnresolvedCallsFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.CUSTOMER_NUMBER))
            {
                filterDTO.CustomerNumber = null;
            }
            else if (token.StartsWith(Constants.FILTER.ALL_CALLS))
            {
                filterDTO.IsAllUnresolvedCalls = false;
            }

            setSearchFilterTokens();
            loadUnresolvedCallsSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        UnresolvedCallsFilterDTO filterDTO = getSearchFilter();
        string filter = null;
        if (filterDTO != null)
        {
            if (filterDTO.CustomerNumber != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.CUSTOMER_NUMBER + filterDTO.CustomerNumber);
            if (filterDTO.IsAllUnresolvedCalls) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.ALL_CALLS);
        }
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - Enquiry Search - End    
}