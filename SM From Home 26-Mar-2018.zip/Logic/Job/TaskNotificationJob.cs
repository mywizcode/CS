﻿using ConstroSoft.Logic.CachingProvider;
using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Caching;

namespace ConstroSoft.Logic.Job
{
    public class TaskNotificationJob : IJob
    {
        private static readonly log4net.ILog log =
                log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public void Execute(IJobExecutionContext context)
        {
            NotificationBO notificationBO = new NotificationBO();
            JobBO jobBO = new JobBO();
        	string message = "Execution Completed:";
            var schedulerContext = context.Scheduler.Context;
            JobDTO tmpJobDTO = (JobDTO)schedulerContext.Get(Constants.JOBS.TASK_NOTIFICATION_JOB);
            DateTime StartTime = DateUtil.getUserLocalDateTime();
            bool isError = false;
            bool isJobStarted = false;
            try{
            	JobDTO jobDTO = jobBO.fetchJobDetails(tmpJobDTO.Id);
                if (jobDTO.JobExecutionStatus != JobExecutionStatus.Inprogress && jobDTO.JobStatus == JobStatus.Active)
                {
                    jobBO.updateJobExecutionStatus(jobDTO.Id, StartTime, "", JobExecutionStatus.Inprogress);
                    isJobStarted = false;
                    if (NotificationCacheProvider.Instance.isNewLeadFlagRaised())
                    {
                    	message = message + " Unassigned Lead count calculated.";
                		notificationBO.fetchAndCacheUnAssignedLeadCount();
                    }
                	if (NotificationCacheProvider.Instance.isUnResolvedFlagRaised())
                    {
                		message = message + " Unresolved call count calculated.";
                		notificationBO.fetchAndCacheUnResolvedCallCount();
                    }
                }
            }catch (Exception exp)
            {
            	isError = true;
                message = exp.Message;
                log.Error(exp.Message, exp);
                //TODO - send email to administrator about job is failed.
            } finally {
	            try{
	            	JobExecutionStatus status = (isError) ? JobExecutionStatus.Failed : JobExecutionStatus.Completed;
	            	if(isError) {
	            		JobHistoryDTO jobHistoryDTO = CommonUtil.populateJobHistoryAddDTO(tmpJobDTO, message);
	            		jobBO.saveJobHistory(jobHistoryDTO);
	            	}
	            	//If Job is in Inprogress status then only update status
	            	if(isJobStarted) {
	            		jobBO.updateJobExecutionStatus(tmpJobDTO.Id, StartTime, message, status);
	            	}
	            } catch (Exception exp)
	            {
	            	log.Error("Task Notification Job - Exception while updating job execution status:", exp);
	            }
            }
        }
    }
}