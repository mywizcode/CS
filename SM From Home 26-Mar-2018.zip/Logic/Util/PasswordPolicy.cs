﻿using System;
using System.Text.RegularExpressions;
/// Summary description for EmailUtil
/// </summary>
using ConstroSoft;
using NHibernate;

namespace ConstroSoft
{
    public static class PasswordPolicy
    {
        //Logger Instance
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private static int Minimum_Length = 8;
        private static int Maximum_Length = 15;
        private static int Upper_Case_length = 1;
        private static int Lower_Case_length = 1;
        private static int NonAlpha_length = 1;
        private static int Numeric_length = 1;
        

        public static string IsValid(string UserName, string TmpPassword)
        {
        	if (string.IsNullOrWhiteSpace(TmpPassword))
        		return "Password should not be empty.";
        	string Password = TmpPassword.Trim();
        	if (UserName.Equals(Password))
                return "Password should not be same as Username.";
            if (Password.Length < Minimum_Length || Password.Length > Maximum_Length)
                return string.Format("Password must be between {0} and {1} characters.", Minimum_Length, Maximum_Length);
            if (UpperCaseCount(Password) < Upper_Case_length)
                return "Password should contain At least one upper case letter.";
            if (LowerCaseCount(Password) < Lower_Case_length)
                return "Password should contain At least one lower case letter.";
            if (NumericCount(Password) < Numeric_length)
                return "Password should contain At least one numeric value.";
            if (NonAlphaCount(Password) < NonAlpha_length)
                return "Password should contain At least one special case characters.";
            return "";
         }

        private static int UpperCaseCount(string Password)
        {
            return Regex.Matches(Password, "[A-Z]").Count;
        }

        private static int LowerCaseCount(string Password)
        {
            return Regex.Matches(Password, "[a-z]").Count;
        }
        private static int NumericCount(string Password)
        {
            return Regex.Matches(Password, "[0-9]").Count;
        }
        private static int NonAlphaCount(string Password)
        {
            return Regex.Matches(Password, @"[^0-9a-zA-Z\._]").Count;
        }
    }
}