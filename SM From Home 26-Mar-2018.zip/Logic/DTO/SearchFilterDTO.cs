﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ConstroSoft;

/// <summary>
/// Summary description for UserDefinitionDTO
/// </summary>
namespace ConstroSoft
{
    [Serializable]
    public class PropertyFilterDTO
    {
        public PropertyFilterDTO() { }
        public long PropertyId { get; set; }
        public string PropertyName { get; set; }
        public MasterControlDataDTO Type { get; set; }
        public MasterControlDataDTO Location { get; set; }
    }
    [Serializable]
    public class PropertyUnitFilterDTO
    {
        public PropertyUnitFilterDTO() { }
        public long UnitId { get; set; }
        public string UnitNo { get; set; }
        public string Wing { get; set; }
        public string FloorNo { get; set; }
        public MasterControlDataDTO UnitType { get; set; }
        public PRUnitStatus? Status { get; set; }
    }
    [Serializable]
    public class PropertyParkingFilterDTO
    {
        public PropertyParkingFilterDTO() { }
        public long ParkingId { get; set; }
        public string ParkingNo { get; set; }
        public MasterControlDataDTO ParkingType { get; set; }
        public CommonParking? CommonParking { get; set; }
        public ParkingStatus? Status { get; set; }
    }
    [Serializable]
    public class SoldUnitFilterDTO
    {
        public SoldUnitFilterDTO() { }
        public long UnitId { get; set; }
        public string UnitNo { get; set; }
        public long CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string CustRefNo { get; set; }
        public long SalesExecutiveId { get; set; }
        public string SalesExecutiveName { get; set; }
    }
    [Serializable]
    public class LeadFilterDTO
    {
        public LeadFilterDTO() { }
        public string LeadRefNo { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Contact { get; set; }
        public long SourceId { get; set; }
        public string Source { get; set; }
        public LeadStatus? Status { get; set; }
    }
    [Serializable]
    public class CallHistoryFilterDTO
    {
        public CallHistoryFilterDTO() { }
        public long AgentId { get; set; }
        public string AgentName { get; set; }
        public string CustomerNumber { get; set; }
        public bool IsIncoming { get; set; }
        public bool IsOutgoing { get; set; }
    }
    [Serializable]
    public class UnresolvedCallsFilterDTO
    {
        public UnresolvedCallsFilterDTO() { }
        public string CustomerNumber { get; set; }
        public bool IsAllUnresolvedCalls { get; set; }
    }
    [Serializable]
    public class EnquiryFilterDTO
    {
        public EnquiryFilterDTO() { }
        public string EnquiryRefNo { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Contact { get; set; }
        public long SourceId { get; set; }
        public string Source { get; set; }
        public EnquiryStatus? Status { get; set; }
        public string LeadRefNo { get; set; }       
    }
    [Serializable]
    public class ActivityFilterDTO
    {
        public ActivityFilterDTO() { }
        public List<string> ActivityTypeList { get; set; }
    }
    [Serializable]
    public class EmailTemplateFilterDTO
    {
        public EmailTemplateFilterDTO() { }
        public string RefNo { get; set; }
        public string Name { get; set; }
        public string Status { get; set; }
    }
    [Serializable]
    public class EmailCampaignFilterDTO
    {
        public EmailCampaignFilterDTO() { }
        public string RefNo { get; set; }
        public string Name { get; set; }
        public string Status { get; set; }
    }
    [Serializable]
    public class CustomerFilterDTO
    {
        public CustomerFilterDTO() { }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime? Dob { get; set; }
        public string Contact { get; set; }
        public string CustRefNo { get; set; }
    }
    [Serializable]
    public class CustomerPymtSearchFilterDTO
    {
        public CustomerPymtSearchFilterDTO() { }
        public long UnitId { get; set; }
        public string UnitNo { get; set; }
        public long CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string CustRefNo { get; set; }
        public string BookingRefNo {get; set;}
        public PRUnitSaleStatus? UnitSaleStatus { get; set; }
    }
    [Serializable]
    public class CustomerPymtTxHistoryFilterDTO
    {
        public CustomerPymtTxHistoryFilterDTO() { }
        public long PymtTypeId { get; set; }
        public string PymtType { get; set; }
        public PaymentMethod? PymtMethod { get; set; }
        public string TxRefNo { get; set; }
        public string MediaNo {get; set;}
    }    
    [Serializable]
    public class PropertyFundFilterDTO
    {
        public PropertyFundFilterDTO() { }
        public long FundId { get; set; }
        public string AccountName { get; set; }
        public PaymentMethod? PymtMethod { get; set; }
        public string MediaNo { get; set; }
    }
    [Serializable]
    public class VoucherFilterDTO
    {
        public VoucherFilterDTO() { }
        public VoucherType? VoucherType { get; set; }
        public TallyPostingStatus? TallyPostingStatus { get; set; }
        public Action? Action { get; set; }
    }
}