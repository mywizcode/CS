﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;


/// <summary>
/// Summary description for PropertyAlertBO
/// </summary>
namespace ConstroSoft
{
    public class EmailAndSMSProviderBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public EmailAndSMSProviderBO() { }

        public IList<EmailConfigDTO> fetchEmailProviders(string firmNumber)
        {
            ISession session = null;
            IList<EmailConfigDTO> result = new List<EmailConfigDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	EmailConfig ec = null;
                    	
                    	IList<EmailConfig> tmpResult = session.QueryOver<EmailConfig>(() => ec)
                                .Where(() => ec.FirmNumber == firmNumber).List<EmailConfig>();
                    	if(tmpResult != null) {
                    		foreach(EmailConfig tmpObj in tmpResult) {
                    			result.Add(DomainToDTOUtil.convertToEmailConfigDTO(tmpObj, true));
                    		}
                    	}
                    } catch (Exception e)
                    {
                        log.Error("Exception while fetching Email Providers for Firm:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        
        public IList<SmsConfigDTO> fetchSMSProviders(string firmNumber)
        {
        	ISession session = null;
        	IList<SmsConfigDTO> result = new List<SmsConfigDTO>();
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				SmsConfig ec = null;
        				
        				IList<SmsConfig> tmpResult = session.QueryOver<SmsConfig>(() => ec)
        						.Where(() => ec.FirmNumber == firmNumber).List<SmsConfig>();
        				if(tmpResult != null) {
        					foreach(SmsConfig tmpObj in tmpResult) {
        						result.Add(DomainToDTOUtil.convertToSmsConfigDTO(tmpObj, true));
        					}
        				}
        			} catch (Exception e)
        			{
        				log.Error("Exception while fetching SMS Providers for Firm:", e);
        				throw new Exception(Resources.Messages.system_error);
        			}

        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        	return result;
        }
        public long saveOrUpdateEmailConfig(EmailConfigDTO tmpDTO)
        {
        	ISession session = null;
        	long Id = -1;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				//If Current Provider is Default then reset flag for all providers first then add/update current provider.
        				if(tmpDTO.IsDefault == IsDefault.Yes) {
	        				string hqlUpdate = "update EmailConfig ec set ec.IsDefault = :default";
	                        session.CreateQuery(hqlUpdate)
	                                .SetEnum("default", IsDefault.No)
	                                .ExecuteUpdate();
        				}
                        
        				EmailConfig tmpObj = null;
        				if(tmpDTO.Id > 0) {
        					tmpObj = session.Get<EmailConfig>(tmpDTO.Id);
                            DTOToDomainUtil.populateEmailConfigUpdateFields(tmpObj, tmpDTO);
        					session.Update(tmpObj);
        				} else {
        					tmpObj = DTOToDomainUtil.populateEmailConfigAddFields(tmpDTO);
        					session.Save(tmpObj);
        				}
                        Id = tmpObj.Id;
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while saving EmailConfig details:", e);
        				throw new Exception(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        	return Id;
        }
        public long saveOrUpdateSmsConfig(SmsConfigDTO tmpDTO)
        {
        	ISession session = null;
        	long Id = -1;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				//If Current Provider is Default then reset flag for all providers first then add/update current provider.
        				if(tmpDTO.IsDefault == IsDefault.Yes) {
        					string hqlUpdate = "update SmsConfig ec set ec.IsDefault = :default";
        					session.CreateQuery(hqlUpdate)
        							.SetEnum("default", IsDefault.No)
        							.ExecuteUpdate();
        				}
        				
        				SmsConfig tmpObj = null;
        				if(tmpDTO.Id > 0) {
        					tmpObj = session.Get<SmsConfig>(tmpDTO.Id);
                            DTOToDomainUtil.populateSmsConfigUpdateFields(tmpObj, tmpDTO);
        					session.Update(tmpObj);
        				} else {
        					tmpObj = DTOToDomainUtil.populateSmsConfigAddFields(tmpDTO);
        					session.Save(tmpObj);
        				}
                        Id = tmpObj.Id;
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while saving SmsConfig details:", e);
        				throw new Exception(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        	return Id;
        }
        public void deleteEmailProvider(long Id)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	EmailConfig config = session.Get<EmailConfig>(Id);
                        session.Delete(config);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while deleting Email Provider details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void deleteSMSProvider(long Id)
        {
        	ISession session = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				SmsConfig config = session.Get<SmsConfig>(Id);
        				session.Delete(config);
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while deleting SMS Provider details:", e);
        				throw new Exception(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        }
    }
}