﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using NHibernate;

namespace ConstroSoft.Logic.BO
{
    public class LeadEnquiryReportBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public LeadEnquiryReportBO() { }
        DashboardBO dashboardBO = new DashboardBO();
        public BusinessOutputTO processLeadEnquiryLetter(string firmNumber, IList<AllEnquiryLeadUIDTO> listPrUnitSaleDetailDto, long propertyId,string period,string fromDate,string toDate)
        {
            BusinessOutputTO businessOutputTO = new BusinessOutputTO();
            businessOutputTO.resultList = new List<object>();
            try
            {
                DataTable EnquiryReport = PopulateLeadEnquiryReportColumns();
                DataTable EnquirySourceReport = populateEnquirySourceReportColumns();
                PropertyBO propertyBO = new PropertyBO();
                FirmBO firmBO = new FirmBO();
                EnquiryBO enquiryBO = new EnquiryBO();
                FirmDTO firmDto = firmBO.fetchFirmDetails(firmNumber);
                PropertyDTO propertyDTO = propertyBO.fetchProperty(propertyId);
                List<AllEnquiryLeadUIDTO> propertyScheduleList = enquiryBO.fetchAllEnquiryLeadData(propertyId);
                DataRow EnquiryReportRow = populateLeadEnquiryReportRows(EnquiryReport, propertyScheduleList, propertyDTO.Name,period, fromDate,toDate);
                EnquiryReport.Rows.Add(EnquiryReportRow);
                businessOutputTO.resultList.Add(EnquiryReport);
                businessOutputTO.resultList.Add(EnquirySourceReport);
            }
            catch (Exception e)
            {
                log.Error("Exception while generating Payment Due Report", e);
                throw new Exception(Resources.Messages.system_error);
            }
            return businessOutputTO;
        }
        public static string validateStageSetup(List<PropertyScheduleDTO> tmpStageList)
        {
            string errorMessage = "";
            if (tmpStageList == null && tmpStageList.Count == 0)
            {
                errorMessage = "Property Schedule is not set. Please set Property Schedule";
            }
            return errorMessage;
        }
        private static DataTable PopulateLeadEnquiryReportColumns()
        {
            DataTable EnquiryReport = new DataTable();
            EnquiryReport.Columns.Add("TotalLoggedEnquiry", typeof(Int64));
            EnquiryReport.Columns.Add("TotalOpenEnquiry", typeof(Int64));
            EnquiryReport.Columns.Add("TotalLostEnquiry", typeof(Int64));
            EnquiryReport.Columns.Add("TotalOwnedEnquiry", typeof(Int64));
            EnquiryReport.Columns.Add("PropertyName", typeof(string));
            EnquiryReport.Columns.Add("Period", typeof(string));
            EnquiryReport.Columns.Add("FromDate", typeof(DateTime));
            EnquiryReport.Columns.Add("ToDate", typeof(DateTime));
            return EnquiryReport;
        }
        private static DataTable populateEnquirySourceReportColumns()
        {

            DataTable EnquirySource = new DataTable();
            EnquirySource.Columns.Add("EnquirySourceName", typeof(string));
            EnquirySource.Columns.Add("Totalnumberofenquiries", typeof(string));
            EnquirySource.Columns.Add("PercentageOfTotalEnquires", typeof(string));            
            return EnquirySource;
        }
        private DataRow populateLeadEnquiryReportRows(DataTable EnquiryReport, List<AllEnquiryLeadUIDTO> allEnquiryLeadUIDTO, string propertyName, string period, string fromDate, string toDate)
        {
            DataRow EnquiryReportReportRow = EnquiryReport.NewRow();
            string BLANK_STRING = "";
            //object[] leadStats = dashboardBO.fetchLeadStatsForDashboard(propertyDTO.Id, noOfMonths);
            int totalOpenEnquiry = (from openEnquiry in allEnquiryLeadUIDTO select openEnquiry.EnquiriesOpen).Count();
            int totalLostEnquiry = (from lostEnquiry in allEnquiryLeadUIDTO select lostEnquiry.EnquiriesLost).Count();
            int totalOwnedEnquiry = (from ownedEnquiry in allEnquiryLeadUIDTO select ownedEnquiry.EnquiriesWon).Count();
            int totalloggedEnquiry = totalOpenEnquiry + totalLostEnquiry + totalOwnedEnquiry;
            int totalOpenLead = (from openLead in allEnquiryLeadUIDTO select openLead.EnquiriesOpen).Count();
            int totalLostLead = (from lostLead in allEnquiryLeadUIDTO select lostLead.EnquiriesLost).Count();
            int totalOwnedLead = (from ownedLead in allEnquiryLeadUIDTO select ownedLead.EnquiriesWon).Count();
            int totalloggedLead = totalOpenLead + totalLostLead + totalOwnedLead;
            EnquiryReportReportRow["TotalOpenEnquiry"] = totalOpenEnquiry + totalOpenLead;
            EnquiryReportReportRow["TotalLostEnquiry"] = totalLostEnquiry + totalLostEnquiry;
            EnquiryReportReportRow["TotalOwnedEnquiry"] = totalOwnedEnquiry + totalOwnedLead;
            EnquiryReportReportRow["TotalLoggedEnquiry"] = totalloggedEnquiry + totalloggedLead;
            EnquiryReportReportRow["PropertyName"] = propertyName;
            EnquiryReportReportRow["Period"] = period;
            EnquiryReportReportRow["FromDate"] = fromDate;
            EnquiryReportReportRow["ToDate"] = toDate;
            return EnquiryReportReportRow;
        }

        private DataRow populateEnquirySourceReportRows(DataTable EnquirySourceReport, List<EnquirySourceDTO> enquirySourceDTO, string firmNumber)
        {
            string BLANK_STRING = "";
            DataRow EnquirySourceNameReportRow = EnquirySourceReport.NewRow();
            EnquirySourceNameReportRow["EnquirySourceName"] = (from enquirySourceName in enquirySourceDTO select enquirySourceName.EnquirySourceName);
            EnquirySourceNameReportRow["Totalnumberofenquiries"] = (from totalnumberofenquiries in enquirySourceDTO select totalnumberofenquiries.Totalnumberofenquiries);
            EnquirySourceNameReportRow["PercentageOfTotalEnquires"] = (from percentageOfTotalEnquires in enquirySourceDTO select percentageOfTotalEnquires.PercentageOfTotalEnquires);
            return EnquirySourceNameReportRow;
        }
        
    }
}