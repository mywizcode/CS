﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;


/// <summary>
/// Summary description for PropertyAlertBO
/// </summary>
namespace ConstroSoft
{
    public class PropertyAlertBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public PropertyAlertBO() { }

        public IList<PropertyAlertConfigDTO> fetchPropertyAlerts(long PropertyId)
        {
            ISession session = null;
            IList<PropertyAlertConfigDTO> result = new List<PropertyAlertConfigDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	PropertyAlertConfig pac = null;
                    	EmailConfig ec = null;
                    	SmsConfig sc = null;
                    	Property p = null;
                    	
                    	PropertyAlertConfigDTO pacDTO = null;
                    	var proj = Projections.ProjectionList()
                                .Add(Projections.Property(() => pac.Id).WithAlias(() => pacDTO.Id))
                                .Add(Projections.Property(() => pac.FunctionName).WithAlias(() => pacDTO.FunctionName))
                                .Add(Projections.Property(() => pac.EmailEnabled).WithAlias(() => pacDTO.EmailEnabled))
                                .Add(Projections.Property(() => pac.SmsEnabled).WithAlias(() => pacDTO.SmsEnabled))
                                .Add(Projections.Property(() => ec.Name), "EmailConfig.Name")
                                .Add(Projections.Property(() => sc.Name), "SmsConfig.Name");
	                    var query = session.QueryOver<PropertyAlertConfig>(() => pac)
                            .Inner.JoinAlias(() => pac.Property, () => p)
	                        .Left.JoinAlias(() => pac.EmailConfig, () => ec)
	                        .Left.JoinAlias(() => pac.SmsConfig, () => sc);
	                    
	                    result = query.Where(() => p.Id == PropertyId)
	                        .Select(proj)
	                        .TransformUsing(new DeepTransformer<PropertyAlertConfigDTO>()).List<PropertyAlertConfigDTO>();
                    } catch (Exception e)
                    {
                        log.Error("Exception while fetching Property Alert Configs:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public PropertyAlertConfigDTO fetchPropertyAlertDetails(long AlertId)
        {
            ISession session = null;
            PropertyAlertConfigDTO result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	PropertyAlertConfig config = session.Get<PropertyAlertConfig>(AlertId);
                    	result = DomainToDTOUtil.convertToPropertyAlertConfigDTO(config, true, true);
                    } catch (Exception e)
                    {
                        log.Error("Exception while fetching Property Alert Details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public byte[] fetchAttachmentContent(long Id)
        {
            ISession session = null;
            byte[] result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	PropertyAlertConfigAttachment attachment = session.Get<PropertyAlertConfigAttachment>(Id);
                    	result = attachment.Content;
                    } catch (Exception e)
                    {
                        log.Error("Exception while fetching Property Alert Config Attachment Content:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public PropertyAlertConfigDTO savePropertyAlertDetails(PropertyAlertConfigDTO configDTO)
        {
            ISession session = null;
            PropertyAlertConfigDTO result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	PropertyAlertConfig config = session.Get<PropertyAlertConfig>(configDTO.Id);
                    	DTOToDomainUtil.populatePropertyAlertUpdateFields(config, configDTO);
                    	
                        session.Update(config);
                        tx.Commit();
                    } catch (Exception e)
                    {
                    	tx.Rollback();
                        log.Error("Exception while fetching Property Alert Details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
    }
}