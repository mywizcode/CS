﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;


/// <summary>
/// Summary description for PropertyAlertBO
/// </summary>
namespace ConstroSoft
{
    public class MarketingCampaignBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public MarketingCampaignBO() { }

        public EmailSmsStoreDTO fetchEmailSmsTemplate(long Id)
        {
            ISession session = null;
            EmailSmsStoreDTO result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	EmailSmsStore tmpObj = session.Get<EmailSmsStore>(Id);
                    	result = DomainToDTOUtil.convertToEmailSmsStoreDTO(tmpObj, true, true);
                    	
                    } catch (Exception e)
                    {
                        log.Error("Exception while fetching Email SMS Template for given Id:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
    }
}