$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    Ladda.bind('.btn-ladda-spinner');
    bindBlockUI(controlToFormat);
    initDropdown(controlToFormat);
    initDate(controlToFormat);
    $('input.submitForm').on('keypress', function (e) {
        if (e.which == 10 || e.which == 13) {
            if (document.getElementById("ContentPlaceHolder1_btnLogin") != null) {
                document.getElementById("ContentPlaceHolder1_btnLogin").click();
            } else if (document.getElementById("ContentPlaceHolder1_btnLoginSetupNext") != null) {
                document.getElementById("ContentPlaceHolder1_btnLoginSetupNext").click();
            }  else if (document.getElementById("ContentPlaceHolder1_btnLoginSetupSubmit") != null) {
                document.getElementById("ContentPlaceHolder1_btnLoginSetupSubmit").click();
            } else if (document.getElementById("ContentPlaceHolder1_btnFPSecQuesitonSubmit") != null) {
                document.getElementById("ContentPlaceHolder1_btnFPSecQuesitonSubmit").click();
            } else if (document.getElementById("ContentPlaceHolder1_btnResetPwdSubmit") != null) {
                document.getElementById("ContentPlaceHolder1_btnResetPwdSubmit").click();
            }
        }
    });
    initNotyMsg();
}
