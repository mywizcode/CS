﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initShowActivityLogGrid();
    initAttachmentGrid();
    formatActivityActionMsg(controlToFormat);
    formatFields(controlToFormat);
    showModal(controlToFormat);
}
function initShowActivityLogGrid() {
    var dtOptions = {
        hasActionColumn: false,
        hideSearch: true,
        pagination: false,
        sorting: false
    };

    $("[id$='ActivityLogGrid']").CSBasicDatatable(dtOptions);
}
function initAttachmentGrid() {
    var dtOptions = {
        hasActionColumn: false,
        hideSearch: true,
        pagination: false,
        sorting: false
    };
    $("[id$='AttachmentGrid']").CSBasicDatatable(dtOptions);
}