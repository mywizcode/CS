﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
	initEmailProviderGrid();
	initSMSProviderGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}
function initEmailProviderGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        rowInfoModalTitle: "Email Provider",
        pageLength: 5,
        hideSearch: true
    };

    $("[id$='EmailProviderGrid']").CSBasicDatatable(dtOptions);
}
function initSMSProviderGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        rowInfoModalTitle: "SMS Provider",
        pageLength: 5,
        hideSearch: true
    };

    $("[id$='SMSProviderGrid']").CSBasicDatatable(dtOptions);
}