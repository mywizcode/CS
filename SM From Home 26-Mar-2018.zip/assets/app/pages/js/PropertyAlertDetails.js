﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
	formatFields(controlToFormat);
	showModal(controlToFormat);
	var isPageRendered = (controlToFormat == "div.content-wrapper" || controlToFormat == "body");
	if (isPageRendered) initSummernote();
}

function initSummernote() {
    $('.summernote').on("summernote.blur", function () {
        $("[id$='txtEmailBody']").html(escape($('.summernote').summernote('code'))); 
    }).summernote({
        height: 500        
    });
    $('.summernote').summernote("code", unescape($("[id$='txtEmailBody']").text()));
    $(".link-dialog input[type=checkbox], .note-modal-form input[type=radio]").uniform({
        radioClass: 'choice'
    });

    // Styled file input
    $(".note-image-input").uniform({
        fileButtonClass: 'action btn bg-warning-400'
    });
}