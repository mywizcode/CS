﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initParkingSearchGrid();
    initPropertyParkingUploadGrid();
    formatFields();
    showModal();
}

function initParkingSearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#propertyParkingSearchBtnDiv",
        pageLength: 10
    };

    $("[id$='propertyParkingSearchGrid']").CSBasicDatatable(dtOptions);
}
function initPropertyParkingUploadGrid() {
    var dtOptions = {
        hasActionColumn: false,
        rowInfoModalTitle: "Parking Details",
        pageLength: 10
    };

    $("[id$='parkingUploadGrid']").CSBasicDatatable(dtOptions);
}


