﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using ConstroSoft;

public partial class CSMaster : System.Web.UI.MasterPage
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            try
            {
                if (CommonUtil.isSessionActive(Session))
                {
                    UserDefinitionDTO userDef = getUserDefinitionDTO();
                    lbUserName.Text = userDef.Username;
                    setFunctionName();
                    initSidebar();
                    applyEntitlement();
                    initPropertyGrid();
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
            catch (Exception ex)
            {
            }
        }
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void setFunctionName()
    {
        string[] fnAndPageName = getFunctionAndPageName();
        functionName.Value = fnAndPageName[0].ToUpper();
        pageName.Value = fnAndPageName[1].ToUpper();
    }
    private string[] getFunctionAndPageName()
    {
        string[] fnAndPageName = new string[2];
        string absPath = HttpContext.Current.Request.Url.AbsolutePath;
        string appPath = HttpContext.Current.Request.ApplicationPath;
        int index = absPath.IndexOf(appPath);
        string expPath = (index < 0) ? absPath : absPath.Remove(index, appPath.Length);
        string[] arrUrl = expPath.TrimStart('/').Split('/');
        fnAndPageName[0] = (arrUrl.Length > 0) ? arrUrl[0] : "";
        fnAndPageName[1] = (arrUrl.Length > 1) ? arrUrl[1] : "";
        return fnAndPageName;
    }
    private bool isCRM()
    {
        return (Constants.Function.CRM.ToUpper().Equals(functionName.Value));
    }
    private bool isERP()
    {
        return (Constants.Function.ERP.ToUpper().Equals(functionName.Value));
    }
    private bool isAcntFianance()
    {
        return (Constants.Function.ACNT_FINANCE.ToUpper().Equals(functionName.Value));
    }
    private bool isFirmPropertySetup()
    {
        return (Constants.Function.FIRM_PROPERTY_SETUP.ToUpper().Equals(functionName.Value));
    }
    private bool isAdministration()
    {
        return (Constants.Function.ADMINISTRATION.ToUpper().Equals(functionName.Value));
    }
    private void initSidebar()
    {
        CRMDashboard.Visible = isCRM();
        PreSaleMenuHeader.Visible = isCRM();
        PostSaleMenuHeader.Visible = isCRM();
        EnquiryManagementMenu.Visible = isCRM();
        SaleManagementMenu.Visible = isCRM();
        PromoManagementMenu.Visible = isCRM();
        ERPDashboard.Visible = isERP();
        AcntFinanceDashboard.Visible = isAcntFianance();
        AcntFinanceMenuHeader.Visible = isAcntFianance();
        AccountManagementMenu.Visible = isAcntFianance();
        PaymentManagementMenu.Visible = isAcntFianance();
        PropertyFund.Visible = isAcntFianance();
        ExpensesMenuHeader.Visible = isAcntFianance();
        ExpenseManagementMenu.Visible = isAcntFianance();
        AcntFinanceReportMenuHeader.Visible = isAcntFianance();
        AcntFinanceReportMenu.Visible = isAcntFianance();
        FirmMenuHeader.Visible = isFirmPropertySetup();
        FirmSetup.Visible = isFirmPropertySetup();
        PropertySetupMenuHeader.Visible = isFirmPropertySetup();
        Property.Visible = isFirmPropertySetup();
        PropertyUnit.Visible = isFirmPropertySetup();
        PymtSchedule.Visible = isFirmPropertySetup();
        PropertyParking.Visible = isFirmPropertySetup();
        AdministrationDashboard.Visible = isAdministration(); ;
        MasterData.Visible = isAdministration();

        //Set sidebar menu header
        setSidebarMenuText();
    }
    private void setSidebarMenuText()
    {
        divSidebarHeader.Visible = false;
        if (isCRM())
        {
            divSidebarHeader.Visible = true;
            lbSidebarMenuIcon.Text = Constants.ICON.CRM_FN_MENU;
            lbSidebarMenuText.Text = Resources.Labels.CRM_MENU;
            lbSidebarMenuDesc.Text = "Pre and Post Sale";
        }
        else if (isERP())
        {
            divSidebarHeader.Visible = true;
            lbSidebarMenuIcon.Text = Constants.ICON.ERP_FN_MENU;
            lbSidebarMenuText.Text = Resources.Labels.ERP_MENU;
            lbSidebarMenuDesc.Text = "Enterprise Resource Planning";
        }
        else if (isAcntFianance())
        {
            divSidebarHeader.Visible = true;
            lbSidebarMenuIcon.Text = Constants.ICON.ACNTFINANCE_FN_MENU;
            lbSidebarMenuText.Text = Resources.Labels.ACCNT_FINANCE_MENU;
            lbSidebarMenuDesc.Text = "Account and Payments";
        }
        else if (isFirmPropertySetup())
        {
            divSidebarHeader.Visible = true;
            lbSidebarMenuIcon.Text = Constants.ICON.PR_SETUP_FN_MENU;
            lbSidebarMenuText.Text = Resources.Labels.FIRM_PROPERTY_SETUP_MENU;
            lbSidebarMenuDesc.Text = "Firm and Property settings";
        }
        else if (isAdministration())
        {
            divSidebarHeader.Visible = true;
            lbSidebarMenuIcon.Text = Constants.ICON.ADMIN_FN_MENU;
            lbSidebarMenuText.Text = Resources.Labels.ADMINISTRATION_MENU;
            lbSidebarMenuDesc.Text = "Application settings";
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        //Dashboard
        
    }
    public void logoutUser(object sender, EventArgs e)
    {
        CommonUtil.clearSession(Session, Application);
        Response.Redirect(Constants.URL.LOGIN, true);
    }
    public void initPropertyGrid()
    {
        UserDefinitionDTO userDTO = getUserDefinitionDTO();
        propertySelectionGrid.DataSource = userDTO.AssignedProperties;
        propertySelectionGrid.DataBind();
        long defaultPropertyId = 0;
        if (userDTO.AssignedProperties.Count > 0)
        {
            PropertyDTO selectedProperty = userDTO.AssignedProperties.Find(c => c.isUISelected);
            defaultPropertyId = (selectedProperty != null) ? selectedProperty.Id : userDTO.AssignedProperties[0].Id;
        }
         
        selectHeaderProperty(defaultPropertyId);
    }
    protected void onClickSelectNavbarProperty(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            selectHeaderProperty(selectedIndex);
            Response.Redirect(Constants.URL.CRM_DASHBOARD, true);
            /*
             * TODO - We need to define function which will redirect to default page of the User.
             * OR create common landing page of the application where all users will land after login and thereafter they can select function(Horizontal menu) for further navigation.
             * So when user changes Property he will navigate to this common landing page.
             * */
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
        }
    }
    private void selectHeaderProperty(long selectedIndex)
    {
        UserDefinitionDTO userDTO = getUserDefinitionDTO();
        userDTO.AssignedProperties.ForEach(x => x.isUISelected = false);
        foreach (PropertyDTO propertyDTO in userDTO.AssignedProperties)
        {
            if (propertyDTO.Id == selectedIndex)
            {
                propertyDTO.isUISelected = true;
                lbHeaderPropertyName.Text = propertyDTO.Name;
                lbHeaderMobilePropertyName.Text = propertyDTO.Name;
                break;
            }
        }
    }
}
