﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using System.Data;
using CrystalDecisions.CrystalReports.Engine;
using System.Web.UI.HtmlControls;

public partial class AvailableUnitSearch : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string SearchFilterModal = "SearchFilterModal";
    DropdownBO drpBO = new DropdownBO();
    AvailablePropertyUnitBO availableUnitBO = new AvailablePropertyUnitBO();
    protected void Page_Load(object sender, EventArgs e)
    {
    	if (ApplicationUtil.isSubPageRendered(Page)) clearMessages();
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                AvailableUnitPageDTO navDto = CommonUtil.getPageNavDTO<AvailableUnitPageDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_AVAILABLE_PR_UNIT)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
    	renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
    	ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpTowerFilter, DrpDataType.PROPERTY_TOWER, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(), null, userDefDto.FirmNumber);
        drpTowerFilter.Text = CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Id.ToString();
        drpBO.drpDataBase(drpUnitTypeFilter, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpUnitNoFilter, DrpDataType.PR_TOWER_UNITS, drpTowerFilter.Text, Constants.SELECT_ITEM, userDefDto.FirmNumber);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(AvailableUnitPageDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new AvailableUnitSearchPageDTO();
        initDropdowns();
        setSearchFilter(null);
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(AvailableUnitPageDTO navDto)
    {
        try
        {
            if (navDto != null)
            {
                setSearchFilter(navDto.FilterDTO);
            }
            loadAvailableUnitSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageFieldsWithEntitlement()
    {
    	UserDefinitionDTO userDefDto = getUserDefinitionDTO();
    	if (availableUnitSearchGrid.Rows.Count > 0)
        {
            bool isActionEnabled = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.BOOK_PR_UNIT, Constants.Entitlement.GET_QUOTATION);
            for (var i = 0; i < availableUnitSearchGrid.Rows.Count; i++)
            {
                HtmlGenericControl tmpBtn = (HtmlGenericControl)availableUnitSearchGrid.Rows[i].FindControl("liBookAvailableUnitBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.BOOK_PR_UNIT);
                tmpBtn = (HtmlGenericControl)availableUnitSearchGrid.Rows[i].FindControl("liGetUnitQuoteBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.GET_QUOTATION);
                tmpBtn = (HtmlGenericControl)availableUnitSearchGrid.Rows[i].FindControl("ulAction");
                if (tmpBtn != null) tmpBtn.Visible = isActionEnabled;
            }
            availableUnitSearchGrid.Columns[0].Visible = isActionEnabled;
        }
    }
    private void setSearchGrid(IList<PropertyUnitDTO> tmpList)
    {
        getSessionPageData().SearchResult = (tmpList != null) ? tmpList.ToList<PropertyUnitDTO>() : new List<PropertyUnitDTO>();
        assignUiIndexToUnit(getSearchPrUnitList());
        availableUnitSearchGrid.DataSource = getSearchPrUnitList();
        availableUnitSearchGrid.DataBind();
    }
    private void assignUiIndexToUnit(List<PropertyUnitDTO> unitDtos)
    {
        if (unitDtos != null && unitDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (PropertyUnitDTO unitDTO in unitDtos)
            {
                unitDTO.UiIndex = uiIndex++;
                unitDTO.RowInfo = CommonUIConverter.getGridViewRowInfo(unitDTO);
            }
        }
    }
    private AvailableUnitSearchPageDTO getSessionPageData()
    {
        return (AvailableUnitSearchPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<PropertyUnitDTO> getSearchPrUnitList()
    {
        return getSessionPageData().SearchResult;
    }
    private PropertyUnitDTO getSearchPropertyUnitDTO(long Id)
    {
        List<PropertyUnitDTO> searchList = getSearchPrUnitList();
        PropertyUnitDTO selectedUnitDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            selectedUnitDTO = searchList.Find(c => c.Id == Id);
        }
        return selectedUnitDTO;
    }
    private void loadAvailableUnitSearchGrid()
    {
        IList<PropertyUnitDTO> results = availableUnitBO.fetchAvailablePropertyUnits(getUserDefinitionDTO().FirmNumber, long.Parse(drpTowerFilter.Text), getSearchFilter());
        setSearchGrid(results);
    }
    protected void onClickBookAvailableUnitBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            BookingFormNavDTO navDTO = new BookingFormNavDTO();
            navDTO.PrUnitId = selectedId;
            AvailableUnitNavDTO unitNavDto = new AvailableUnitNavDTO();
            unitNavDto.filterDTO = getSearchFilter();
            navDTO.PrevNavDto = unitNavDto;
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.BOOKING_FORM, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickGetUnitQuoteBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);

            PropertyBO propertyBO = new PropertyBO();
            FirmBO firmBO = new FirmBO();

            PropertyUnitDTO propertyUnitDto = propertyBO.fetchPropertyUnitWithParent(selectedId, true);
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            FirmDTO firmDto = firmBO.fetchFirmDetails(userDefDto.FirmNumber);
            PropertyDTO propertyDTO = propertyBO.fetchProperty(propertyUnitDto.PropertyTower.Property.Id);
            List<PropertyScheduleDTO> propertyScheduleList = propertyBO.fetchPropertySchedule(propertyUnitDto.PropertyTower.Id);

            DataTable PropertyUnit = new DataTable();
            DataRow prUnitRow = PropertyUnit.NewRow();
            populatePropertyUnit(propertyUnitDto, firmDto, propertyDTO, PropertyUnit, prUnitRow);

            DataTable PropertyTax = new DataTable();
            PropertyDTO propertyDto = populatePropertyTax(propertyUnitDto, PropertyTax);

            DataTable PropertyPymtSchd = new DataTable();
            populatePropertySchd(propertyScheduleList, PropertyPymtSchd);

            DataTable PropertyCharge = new DataTable();
            populatePropertyCharges(propertyDTO, PropertyCharge);

            ReportDocument quotationReportDocument = new ReportDocument();
            string reportPath = Server.MapPath("~//REPORTS//Quotation//UnitQuotation.rpt");
            quotationReportDocument.Load(reportPath);
            quotationReportDocument.Database.Tables["PropertyUnit"].SetDataSource(PropertyUnit);
            quotationReportDocument.Subreports["PropertyCharges"].SetDataSource(PropertyCharge);
            quotationReportDocument.Subreports["PropertyTaxes"].SetDataSource(PropertyTax);
            quotationReportDocument.Subreports["PROPERTYPAYSCHD"].SetDataSource(PropertyPymtSchd);
            try
            {
                quotationReportDocument.ExportToHttpResponse
                (CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, true,
                "Quote for "+propertyUnitDto.PropertyTower.Property.Name + "-" + propertyUnitDto.PropertyTower.Name + "-" + propertyUnitDto.Wing + "-" + propertyUnitDto.UnitNo);
            }
            catch (Exception exp)
            {

            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private static void populatePropertyUnit(PropertyUnitDTO propertyUnitDto, FirmDTO firmDto, PropertyDTO propertyDTO, DataTable PropertyUnit, DataRow prUnitRow)
    {
        PropertyUnit.Columns.Add("PropertyName", typeof(string));
        PropertyUnit.Columns.Add("PropertyAddress", typeof(string));
        PropertyUnit.Columns.Add("PrTowerName", typeof(string));
        PropertyUnit.Columns.Add("PrWing", typeof(string));
        PropertyUnit.Columns.Add("PrFloorNo", typeof(string));
        PropertyUnit.Columns.Add("PrFlatNo", typeof(string));
        PropertyUnit.Columns.Add("BuiltupArea", typeof(decimal));
        PropertyUnit.Columns.Add("CarpetArea", typeof(decimal));
        PropertyUnit.Columns.Add("BookingRate", typeof(decimal));
        PropertyUnit.Columns.Add("FirmName", typeof(string));

        prUnitRow["PropertyName"] = propertyUnitDto.PropertyTower.Property.Name;
        prUnitRow["PrTowerName"] = propertyUnitDto.PropertyTower.Name;
        string address = null;
        if (propertyDTO.ContactInfo.Addresses != null)
        {
            List<AddressDTO> addressList = propertyDTO.ContactInfo.Addresses.ToList();
            AddressDTO addressDTO = addressList[0];
            address = addressDTO.AddressLine1 + " " + addressDTO.AddressLine2 + " " + addressDTO.Town + " "
                + addressDTO.City.Name + " " + addressDTO.State.Name + " " + addressDTO.Country.Name;
        }
        prUnitRow["PropertyAddress"] = address;
        prUnitRow["PrWing"] = propertyUnitDto.Wing;
        prUnitRow["PrFloorNo"] = propertyUnitDto.FloorNo;
        prUnitRow["PrFlatNo"] = propertyUnitDto.UnitNo;
        prUnitRow["BuiltupArea"] = propertyUnitDto.BuildupArea;
        prUnitRow["CarpetArea"] = propertyUnitDto.CarpetArea;
        prUnitRow["BookingRate"] = propertyUnitDto.PropertyTower.Rate;
        prUnitRow["FirmName"] = firmDto.Name;

        PropertyUnit.Rows.Add(prUnitRow);
    }
    private static void populatePropertyCharges(PropertyDTO propertyDto, DataTable PropertyCharge)
    {
        PropertyCharge.Columns.Add("ChargeType", typeof(string));
        PropertyCharge.Columns.Add("ChargeValue", typeof(string));

        if (propertyDto.PropertyCharges != null && propertyDto.PropertyCharges.Count > 0)
        {
            foreach (PropertyChargeDTO propertyChargeDTO in propertyDto.PropertyCharges)
            {
                DataRow chargeRow = PropertyCharge.NewRow();
                chargeRow["ChargeType"] = propertyChargeDTO.ChargeType.Name;
                chargeRow["ChargeValue"] = Convert.ToDecimal(propertyChargeDTO.ChargeValue);
                PropertyCharge.Rows.Add(chargeRow);
            }
        }
        else
        {
            DataRow chargeRow = PropertyCharge.NewRow();
            PropertyCharge.Rows.Add(chargeRow);
        }
    }

    private static void populatePropertySchd(List<PropertyScheduleDTO> propertyScheduleList, DataTable PropertyPymtSchd)
    {
        PropertyPymtSchd.Columns.Add("STAGE", typeof(string));
        PropertyPymtSchd.Columns.Add("PERCENTAGE", typeof(decimal));
        PropertyPymtSchd.Columns.Add("STATUS", typeof(string));
        PropertyPymtSchd.Columns.Add("STAGE_NUMBER", typeof(Int32));
        if (propertyScheduleList != null && propertyScheduleList.Count() > 0)
        {
            foreach (PropertyScheduleDTO propertySchdDto in propertyScheduleList)
            {
                DataRow stageRow = PropertyPymtSchd.NewRow();
                stageRow["STAGE"] = propertySchdDto.Stage.ToString();
                stageRow["PERCENTAGE"] = propertySchdDto.Percentage;
                stageRow["STATUS"] = propertySchdDto.Status.ToString();
                stageRow["STAGE_NUMBER"] = propertySchdDto.StageNumber;
                PropertyPymtSchd.Rows.Add(stageRow);
            }

        }
        else
        {
            DataRow stageRow = PropertyPymtSchd.NewRow();
            PropertyPymtSchd.Rows.Add(stageRow);
        }
    }

    private static PropertyDTO populatePropertyTax(PropertyUnitDTO propertyUnitDto, DataTable PropertyTax)
    {
        PropertyTax.Columns.Add("TaxType", typeof(string));
        PropertyTax.Columns.Add("TaxPercentage", typeof(string));
        PropertyDTO propertyDto = propertyUnitDto.PropertyTower.Property;
        if (propertyDto.PropertyTaxDetails != null && propertyDto.PropertyTaxDetails.Count > 0)
        {
            foreach (PropertyTaxDetailDTO propertyTaxDetailDto in propertyDto.PropertyTaxDetails)
            {
                if (IncludeInPymtTotal.Yes == propertyTaxDetailDto.IncludeInTotalPymt)
                {
                    DataRow taxRow = PropertyTax.NewRow();

                    taxRow["TaxType"] = propertyTaxDetailDto.TaxType.Name;
                    taxRow["TaxPercentage"] = propertyTaxDetailDto.TaxPercentage.ToString();
                    PropertyTax.Rows.Add(taxRow);
                }
            }
        }
        return propertyDto;
    }
    protected void availableUnitRowCreated(Object sender, GridViewRowEventArgs e)
    {
        LinkButton lnkGetUnitQuoteBtn = (LinkButton)e.Row.FindControl("lnkGetUnitQuoteBtn");
        if (lnkGetUnitQuoteBtn != null)
        {
            ScriptManager mgr = ScriptManager.GetCurrent(this.Page);
            mgr.RegisterPostBackControl(lnkGetUnitQuoteBtn);
        }
    }
    //Filter Criteria - Property Search - Start
    private PropertyUnitFilterDTO getSearchFilter()
    {
        return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            PropertyUnitFilterDTO filterDTO = getSearchFilter();
            drpBO.drpDataBase(drpUnitNoFilter, DrpDataType.PR_TOWER_UNITS, drpTowerFilter.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            if (filterDTO.UnitId > 0) drpUnitNoFilter.Text = filterDTO.UnitId.ToString(); else drpUnitNoFilter.ClearSelection();
            if (filterDTO.UnitType != null) drpUnitTypeFilter.Text = filterDTO.UnitType.Id.ToString(); else drpUnitTypeFilter.ClearSelection();
            if (filterDTO.Wing != null) txtWingFilter.Text = filterDTO.Wing; else txtWingFilter.Text = null;
            if (filterDTO.FloorNo != null) txtFloorNoFilter.Text = filterDTO.FloorNo; else txtFloorNoFilter.Text = null;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onSelectFilterTower(object sender, EventArgs e)
    {
        try
        {
            drpBO.drpDataBase(drpUnitNoFilter, DrpDataType.PR_TOWER_UNITS, drpTowerFilter.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            activeModalHdn.Value = SearchFilterModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            CommonUtil.setStickyPrTowerDTO(getUserDefinitionDTO(), long.Parse(drpTowerFilter.Text), drpTowerFilter.SelectedItem.Text);
            PropertyUnitFilterDTO filterDTO = new PropertyUnitFilterDTO();
            if (!string.IsNullOrWhiteSpace(drpUnitNoFilter.Text))
            {
                filterDTO.UnitId = long.Parse(drpUnitNoFilter.Text);
                filterDTO.UnitNo = drpUnitNoFilter.SelectedItem.Text;
            }
            if (!string.IsNullOrWhiteSpace(drpUnitTypeFilter.Text))
            {
                filterDTO.UnitType = CommonUIConverter.getMasterControlDTO(drpUnitTypeFilter.Text, drpUnitTypeFilter.SelectedItem.Text);
            }
            if (!string.IsNullOrWhiteSpace(txtWingFilter.Text))
            {
                filterDTO.Wing = txtWingFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(txtFloorNoFilter.Text))
            {
                filterDTO.FloorNo = txtFloorNoFilter.Text;
            }
            setSearchFilter(filterDTO);
            loadAvailableUnitSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            loadAvailableUnitSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(PropertyUnitFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new PropertyUnitFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {
            drpTowerFilter.Text = CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Id.ToString();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            PropertyUnitFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.UNIT_NO))
            {
                filterDTO.UnitId = 0;
                filterDTO.UnitNo = "";
            }
            else if (token.StartsWith(Constants.FILTER.UNIT_TYPE)) filterDTO.UnitType = null;
            else if (token.StartsWith(Constants.FILTER.WING)) filterDTO.Wing = null;
            else if (token.StartsWith(Constants.FILTER.FLOOR_NO)) filterDTO.FloorNo = null;
            else if (token.StartsWith(Constants.FILTER.TOWER_NAME)) (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyInfoMsg(Resources.Messages.TOWER_FILTER_DEFAULT));

            setSearchFilterTokens();
            loadAvailableUnitSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        PropertyUnitFilterDTO filterDTO = getSearchFilter();
        string filter = CommonUtil.addFilterToken("", Constants.FILTER.TOWER_NAME + CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Name);
        if (filterDTO != null)
        {
            if (filterDTO.UnitId > 0) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.UNIT_NO + filterDTO.UnitNo);
            if (filterDTO.UnitType != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.UNIT_TYPE + filterDTO.UnitType.Name);
            if (filterDTO.Wing != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.WING + filterDTO.Wing);
            if (filterDTO.FloorNo != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.FLOOR_NO + filterDTO.FloorNo);
        }
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - PropertyUnit Search - End
}
