﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initAccountSummarySearchGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initAccountSummarySearchGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "acntSummaryGrid",
        pageLength: 10,        
        isViewOnly: false,
        hideSearch: false
    };
    $("[id$='acntSummaryGrid']").CSBasicDatatable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitHdnId");
}





