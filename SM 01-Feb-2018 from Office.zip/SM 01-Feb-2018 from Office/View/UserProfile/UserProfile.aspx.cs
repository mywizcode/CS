﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using ConstroSoft.Logic.BO;
using System.Web.UI.HtmlControls;
using System.Web;
using System.IO;
using System.Drawing;
using System.Web.Hosting;

public partial class UserProfile : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string editProfileModalError = "editProfileModalError";
    string uploadDocumentModalError = "uploadDocumentModalError";
    string editProfileModal = "editProfileModal";
    string uploadDocumentModal = "uploadDocumentModal";
    string uploadCroppedImageModal = "uploadCroppedImageModal";
    DropdownBO drpBO = new DropdownBO();
    LoginBO loginBO = new LoginBO();
    DocumentBO documentBO = new DocumentBO();
    protected void Page_Load(object sender, EventArgs e)
    {
    	if (ApplicationUtil.isSubPageRendered(Page)) clearMessages();
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                doInit();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    private void renderPageFieldsWithEntitlement()
    {

    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {

    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit()
    {
    	UserProfilePageDTO PageDTO = new UserProfilePageDTO();
    	Session[Constants.Session.PAGE_DATA] = PageDTO;
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        initDropdowns();
        populateProfileInfo(userDefDto);
    }
    private UserProfilePageDTO getSessionPageData()
    {
        return (UserProfilePageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private void populateProfileInfo(UserDefinitionDTO userDefDto)
    {
    	UserProfilePageDTO PageDTO = getSessionPageData();
    	PageDTO.FirmMember = loginBO.fetchFirmMemberDetails(userDefDto.FirmMember.Id);
        FirmMemberDTO firmMemberDTO = PageDTO.FirmMember;
        lbFullName.Text = CommonUIConverter.getCustomerFullName(firmMemberDTO.Salutation.Name, firmMemberDTO.FirstName, firmMemberDTO.MiddleName, firmMemberDTO.LastName);
        lbUsername.Text = firmMemberDTO.UserDefinition.Username;
        lbPrimaryContact.Text = firmMemberDTO.ContactInfo.Contact;
        lbSecondaryContact.Text = firmMemberDTO.ContactInfo.AltContact;
        lbDob.Text = DateUtil.getCSDate(firmMemberDTO.ContactInfo.Dob);
        lbEmail.Text = firmMemberDTO.ContactInfo.Email;

        imgUserProfile.ImageUrl = userDefDto.ProfileImagePath;
    }
    //Profile Modal - Start
    private void initProfileModalFields()
    {
    }
    private void initProfileSectionFields(FirmMemberDTO firmMemberDTO)
    {
        if (firmMemberDTO != null && firmMemberDTO.ContactInfo != null) txtUserDOB.Text = DateUtil.getCSDate(firmMemberDTO.ContactInfo.Dob); else txtUserDOB.Text = null;
        if (firmMemberDTO != null && firmMemberDTO.ContactInfo != null) txtUserContact.Text = firmMemberDTO.ContactInfo.Contact; else txtUserContact.Text = null;
        if (firmMemberDTO != null && firmMemberDTO.ContactInfo != null) txtUserAltContact.Text = firmMemberDTO.ContactInfo.AltContact; else txtUserAltContact.Text = null;
        if (firmMemberDTO != null && firmMemberDTO.ContactInfo != null) txtUserEmail.Text = firmMemberDTO.ContactInfo.Email; else txtUserEmail.Text = null;
    }
    private void populateProfileFromUI(FirmMemberDTO firmMemberDTO)
    {
        firmMemberDTO.ContactInfo.Dob = DateUtil.getCSDateNotNull(txtUserDOB.Text);
        firmMemberDTO.ContactInfo.Contact = txtUserContact.Text;
        firmMemberDTO.ContactInfo.AltContact = txtUserAltContact.Text;
        firmMemberDTO.ContactInfo.Email = txtUserEmail.Text;
        
        firmMemberDTO.UpdateUser = getUserDefinitionDTO().Username;
    }
    protected void onClickEditProfileBtn(object sender, EventArgs e)
    {
        try
        {
        	initProfileModalFields();
        	initProfileSectionFields(getSessionPageData().FirmMember);
            activeModalHdn.Value = editProfileModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void saveProfile(object sender, EventArgs e)
    {
        try
        {
            if (validateProfileUpdate() && validateDuplicateAgentContact())
            {
                FirmMemberDTO firmMemberDTO = getSessionPageData().FirmMember;
                populateProfileFromUI(firmMemberDTO);
                loginBO.updateUserProfile(firmMemberDTO);
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("Profile details are updated successfully."));
                populateProfileInfo(getUserDefinitionDTO());
                getUserDefinitionDTO().FirmMember = getSessionPageData().FirmMember;
            }
            else
            {
                activeModalHdn.Value = editProfileModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelProfileModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateProfileUpdate()
    {
        bool isValid = true;
        Page.Validate(editProfileModalError);
        isValid = Page.IsValid;
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        string msg = CommonUtil.validateContact(txtUserContact.Text);
        string msg1 = CommonUtil.validateContact(txtUserAltContact.Text);
        if(!string.IsNullOrWhiteSpace(msg)) {
        	setErrorMessage(msg, editProfileModal);
        	isValid = false;
        } else if(!string.IsNullOrWhiteSpace(msg1)) {
        	setErrorMessage(msg1, editProfileModal);
        	isValid = false;
        }
        return isValid;
    }
    private bool validateDuplicateAgentContact() {
    	bool isValid = true;
    	UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
    	string contact = txtUserContact.Text.Trim();
    	FirmMemberDTO fmDTO = loginBO.fetchAgentWithDuplicateContact(userDefDTO.Id, contact);
    	if(fmDTO != null) {
    		string agentName = CommonUIConverter.getCustomerFullName(fmDTO.FirstName, fmDTO.LastName);
    		setErrorMessage(string.Format("Contact number {0} is already used by agent {1}.", contact, agentName), editProfileModal);
    		isValid = false;
    	} else if(!string.IsNullOrWhiteSpace(txtUserAltContact.Text)) {
    		contact = txtUserAltContact.Text.Trim();
    		fmDTO = loginBO.fetchAgentWithDuplicateContact(userDefDTO.Id, contact);
    		if(fmDTO != null) {
    			string agentName = CommonUIConverter.getCustomerFullName(fmDTO.FirstName, fmDTO.LastName);
        		setErrorMessage(string.Format("Contact number {0} is already used by agent {1}.", contact, agentName), editProfileModal);
        		isValid = false;
    		}
    	}
    	return isValid;
    }
    //Lead Modal - End 
    //Upload Document Modal- start
    protected void onClickUploadProfilePic(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = uploadDocumentModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void UploadDocument(object sender, EventArgs e)
    {
        try
        {
            HttpFileCollection uploadedFiles = Request.Files;
            if (uploadedFiles != null && uploadedFiles.Count > 0)
            {
                for (int i = 0; i < uploadedFiles.Count; i++)
                {
                    HttpPostedFile userPostedFile = uploadedFiles[i];
                    if (userPostedFile.ContentLength > 0)
                    {
                        string filename = Path.GetFileName(userPostedFile.FileName);
                        string extension = Path.GetExtension(filename);
                        HttpPostedFile file = fileUpload.PostedFile;
                        if (validateUploadDocument(userPostedFile))
                        {
                            UserDefinitionDTO userDefDTO = getUserDefinitionDTO();   
                            documentBO.createFolderIfNotExist(Constants.DOCUMENT_MANAGEMENT.TMP_PATH);

                            string tmpProfileImg = CommonUtil.getUserTempProfileImagePathRelative(userDefDTO.Username);
                            System.Drawing.Image img = System.Drawing.Image.FromStream(userPostedFile.InputStream);
                            Bitmap bmpCropped = new Bitmap(img);
                            ImageHandler.SaveAsJpeg(bmpCropped, img.Width, img.Height, 100L, HostingEnvironment.MapPath(tmpProfileImg));
                            ImgImageCropper.ImageUrl = Page.ResolveUrl(tmpProfileImg);
                            activeModalHdn.Value = uploadCroppedImageModal;
                        }
                    }
                    else
                    {
                        setErrorMessage("Please Select file to upload.", uploadDocumentModalError);
                        activeModalHdn.Value = uploadDocumentModal;
                    }
                }
            }
            else
            {
                setErrorMessage("Please Select file to upload.", uploadDocumentModalError);
                activeModalHdn.Value = uploadDocumentModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    protected void cancelUploadDocumentModal(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateUploadDocument(HttpPostedFile userPostedFile)
    {
        bool isValid = true;
        string[] fileExtensions = { "image/png", "image/jpeg", "image/bmp" };
        if (!fileExtensions.Contains(userPostedFile.ContentType))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please select valid profile picture."));
        }
        //TODO - Do we need file size limit
        return isValid;
    }
    //Upload Document Modal - end
    //Crop Image Modal- start
    protected void SaveCroppedImage(object sender, EventArgs e)
    {
        try
        {
            int x, y, w, h;
            if (!int.TryParse(cropXHdn.Value, out x)) x = 0;
            if (!int.TryParse(cropYHdn.Value, out y)) y = 0;
            if (!int.TryParse(cropHeightHdn.Value, out h)) h = 0;
            if (!int.TryParse(cropWidthHdn.Value, out w)) w = 0;

            UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
            string tmpProfileImg = CommonUtil.getUserTempProfileImagePath(userDefDTO.Username);
            documentBO.createFolderIfNotExist(CommonUtil.getUserProfilePathRelative(userDefDTO.Username));
            string UserProfileImg = CommonUtil.getUserProfileImagePath(userDefDTO.Username);
            
            using (System.Drawing.Image img = System.Drawing.Image.FromFile(tmpProfileImg))
            {
                using (Bitmap bmpCropped = new Bitmap(w, h))
                {
                    using (Graphics g = Graphics.FromImage(bmpCropped))
                    {
                        Rectangle rectDestination = new Rectangle(0, 0, bmpCropped.Width, bmpCropped.Height);
                        Rectangle rectCropArea = new Rectangle(x, y, w, h);
                        g.DrawImage(img, rectDestination, rectCropArea, GraphicsUnit.Pixel);
                        ImageHandler.SaveAsJpeg(bmpCropped, bmpCropped.Width, bmpCropped.Height, 50L, UserProfileImg);
                    }
                }
            }
            //Delete temporary profile image
            deleteTemporaryProfileImg();
            Response.Redirect(Constants.URL.USER_PROFILE, false);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    protected void cancelCropImageModal(object sender, EventArgs e)
    {
        try
        {
            //Delete temporary profile image
            deleteTemporaryProfileImg();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void deleteTemporaryProfileImg()
    {
        FileUIDTO fileDTO = new FileUIDTO();
        fileDTO.FileType = FileType.File;
        fileDTO.FullPath = CommonUtil.getUserTempProfileImagePathRelative(getUserDefinitionDTO().Username);
        documentBO.deleteFile(fileDTO);
    }
    //Crop Image Modal - end
    protected void changePassword(object sender, EventArgs e)
    {
        try
        {
            if (validateChangePassword())
            {
                loginBO.resetPassword(getUserDefinitionDTO().Username, txtNewPassword.Text);
                Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg("Password is changed successfully. Please login with your new password."));
                CommonUtil.clearSession(Session, Application);
                Response.Redirect(Constants.URL.CHANGE_PASSWORD_SUCCESS, true);
            }
            else
            {
                activeTab.Value = "ChangePassword";
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateChangePassword()
    {
        bool result = true;
        if (string.IsNullOrWhiteSpace(txtCurrentPassword.Text))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please enter Current Password."));
            result = false;
        }
        else if (string.IsNullOrWhiteSpace(txtNewPassword.Text))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please enter New Password."));
            result = false;
        }
        else if (string.IsNullOrWhiteSpace(txtConfirmNewPassword.Text))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please enter Confirm New Password."));
            result = false;
        }
        else if (!txtNewPassword.Text.Equals(txtConfirmNewPassword.Text))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("New Password and Confirm New Password does not match."));
            result = false;
        } else if(!loginBO.validatePassword(getUserDefinitionDTO().Username, txtCurrentPassword.Text)) {
        	(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Current password is not valid."));
            result = false;
        }
        return result;
    }
}