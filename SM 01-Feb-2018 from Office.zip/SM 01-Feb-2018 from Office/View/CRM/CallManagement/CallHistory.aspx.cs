﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using ConstroSoft.Logic.BO;
using System.Web.UI.HtmlControls;

public partial class CallHistory : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string SearchFilterModal = "SearchFilterModal";
    DropdownBO drpBO = new DropdownBO();
    CallHistoryBO callHistoryBO = new CallHistoryBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSubPageRendered(Page)) clearMessages();
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                CallHistoryNavDTO navDto = CommonUtil.getPageNavDTO<CallHistoryNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_CALL_HISTORY)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    private void renderPageFieldsWithEntitlement()
    {
        
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
    	UserDefinitionDTO userDefDto = getUserDefinitionDTO();
    	drpBO.drpDataBase(drpAgentFilter, DrpDataType.ACTIVE_USERS_WITH_PR_ACCESS, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(CallHistoryNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new CallHistoryPageDTO();
        initDropdowns();
        CallHistoryFilterDTO FilterDTO = new CallHistoryFilterDTO();
        setSearchFilter(FilterDTO);
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(CallHistoryNavDTO navDto)
    {
        try
        {
            if (navDto != null)
            {
                setSearchFilter(navDto.filterDTO);
                //Set default filter agent as logged in user.
                CallHistoryFilterDTO filterDTO = getSearchFilter();
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                filterDTO.AgentId = userDefDto.FirmMember.Id;
                filterDTO.AgentName = CommonUIConverter.getCustomerFullName(userDefDto.FirmMember.FirstName, userDefDto.FirmMember.LastName);
            }
            loadCallHistorySearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private CallHistoryPageDTO getSessionPageData()
    {
        return (CallHistoryPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<CallHistoryDTO> getSearchList()
    {
        return getSessionPageData().SearchResult;
    }
    private CallHistoryDTO getSearchDTO(long Id)
    {
        List<CallHistoryDTO> searchList = getSearchList();
        CallHistoryDTO selectedCallsDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            selectedCallsDTO = searchList.Find(c => c.Id == Id);
        }
        return selectedCallsDTO;
    }
    private void populateCallHistorySearchGrid(List<CallHistoryDTO> tmpList)
    {
        callHistorySearchGrid.DataSource = new List<CallHistoryDTO>();
        if (tmpList != null)
        {
            assignUiIndexToLeads(tmpList);
            callHistorySearchGrid.DataSource = tmpList;
        }
        callHistorySearchGrid.DataBind();
    }
    private void assignUiIndexToLeads(List<CallHistoryDTO> tmpList)
    {
        if (tmpList != null && tmpList.Count > 0)
        {
            long uiIndex = 1;
            foreach (CallHistoryDTO tmpDTO in tmpList)
            {
                //tmpDTO.UiIndex = uiIndex++;
            }
        }
    }
    private void loadCallHistorySearchGrid()
    {
        CallHistoryPageDTO PageDTO = getSessionPageData();
        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        PropertyDTO propertyDTO = CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO());
        IList<CallHistoryDTO> results = callHistoryBO.fetchCallHistoryGridData(propertyDTO.Id, getSearchFilter());
        PageDTO.SearchResult = (results != null) ? results.ToList<CallHistoryDTO>() : new List<CallHistoryDTO>();
        populateCallHistorySearchGrid(PageDTO.SearchResult);
    }

    //Filter Criteria - Call Search - Start
    private CallHistoryFilterDTO getSearchFilter()
    {
        return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            CallHistoryFilterDTO filterDTO = getSearchFilter();
            if (filterDTO.AgentId > 0) drpAgentFilter.Text = filterDTO.AgentId.ToString(); else drpAgentFilter.ClearSelection();
            if (filterDTO.CustomerNumber != null) txtCustomerNumber.Text = filterDTO.CustomerNumber; else txtCustomerNumber.Text = null;
            cbCallDirectionIncoming.Checked = filterDTO.IsIncoming;
            cbCallDirectionOutgoing.Checked = filterDTO.IsOutgoing;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            CallHistoryFilterDTO filterDTO = new CallHistoryFilterDTO();
            if (!string.IsNullOrWhiteSpace(drpAgentFilter.Text))
            {
                filterDTO.AgentId = long.Parse(drpAgentFilter.Text);
                filterDTO.AgentName = drpAgentFilter.SelectedItem.Text;
            }
            if (!string.IsNullOrWhiteSpace(txtCustomerNumber.Text))
            {
                filterDTO.CustomerNumber = txtCustomerNumber.Text;
            }
            filterDTO.IsIncoming = cbCallDirectionIncoming.Checked;
            filterDTO.IsOutgoing = cbCallDirectionOutgoing.Checked;

            setSearchFilter(filterDTO);
            loadCallHistorySearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }

    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            loadCallHistorySearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(CallHistoryFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new CallHistoryFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            CallHistoryFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.AGENT))
            {
                filterDTO.AgentId = 0;
                filterDTO.AgentName = "";
            }
            if (token.StartsWith(Constants.FILTER.CUSTOMER_NUMBER)) filterDTO.CustomerNumber = null;
            else if (token.StartsWith(Constants.FILTER.INCOMING)) filterDTO.IsIncoming = false;
            else if (token.StartsWith(Constants.FILTER.OUTGOING)) filterDTO.IsOutgoing = false;

            setSearchFilterTokens();
            loadCallHistorySearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        CallHistoryFilterDTO filterDTO = getSearchFilter();
        string filter = null;
        if (filterDTO != null)
        {
            if (filterDTO.AgentId > 0) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.AGENT + filterDTO.AgentName);
            if (filterDTO.CustomerNumber != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.CUSTOMER_NUMBER + filterDTO.CustomerNumber);
            if (filterDTO.IsIncoming) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.INCOMING);
            if (filterDTO.IsOutgoing) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.OUTGOING);
        }
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - Call Search - End
}