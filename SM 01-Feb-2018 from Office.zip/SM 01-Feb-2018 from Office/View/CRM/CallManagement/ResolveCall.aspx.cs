﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using ConstroSoft.Logic.BO;
using System.Web.UI.HtmlControls;
using ConstroSoft.TelephonyProvider;

public partial class ResolveCall : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addLeadModalError = "addLeadModalError";
    string addMasterDataError = "addMasterDataError";
    string addLeadModal = "addLeadModal";
    string addMasterDataModal = "addMasterDataModal";
    string ClickToCallModal = "ClickToCallModal";
    string clickToCallModalError = "clickToCallModalError";
    DropdownBO drpBO = new DropdownBO();
    CallHistoryBO callHistoryBO = new CallHistoryBO();
    CustomerBO customerBO = new CustomerBO();
    EnquiryBO enquiryBO = new EnquiryBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    PropertyUserBO propertyUserBO = new PropertyUserBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSubPageRendered(Page)) clearMessages();
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                ResolveCallNavDTO navDto = CommonUtil.getPageNavDTO<ResolveCallNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.RESOLVE_CALL)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);                
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }    
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();          
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
        addCheckBoxAttributes();
    }
    private void renderPageFieldsWithEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        btnAddNewLead.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.LEAD_ADD);
        lnkClickToCallBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.RESOLVE_CALL_CLICK_TO_CALL);
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        drpBO.drpDataBase(drpLeadProperty, DrpDataType.PROPERTY_NAME, userDefDto.FirmMember.Id.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpLeadSource, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.ENQUIRY_SOURCE.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpLeadSalutation, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.SALUTATION.ToString(), null, userDefDto.FirmNumber);
    }
    private void addCheckBoxAttributes()
    {
    	foreach (ListViewItem item in unresolvedCallsGrid.Items)
        {
            CheckBox chBox = (CheckBox)item.FindControl("cbUnresolvedCall");
            if (chBox != null)
            {
                chBox.InputAttributes.Add("class", "styled block-ui-change");
                chBox.InputAttributes.Add("data-panel", "blockui-panel-1");
            }
        }
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(ResolveCallNavDTO navDto)
    {
        if (navDto != null)
        {
            Session[Constants.Session.PAGE_DATA] = new ResolveCallPageDTO();
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(ResolveCallNavDTO navDto)
    {
        try
        {
            ResolveCallPageDTO PageDTO = getSessionPageData();
            PageDTO.CustomerNumber = navDto.CustomerNumber;
            lbCustomerNumber.Text = PageDTO.CustomerNumber;
            loadCallAndMatchingRecords();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void navigateToPreviousPage()
    {
        ResolveCallPageDTO pageDTO = getSessionPageData();
        if (pageDTO != null && pageDTO.PrevNavDTO != null)
        {
            object obj = pageDTO.PrevNavDTO;
            if (obj is UnresolvedCallsNavDTO)
            {
                UnresolvedCallsNavDTO navDTO = (UnresolvedCallsNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.UNRESOLVED_CALLS, true);
            }
        }
        Response.Redirect(Constants.URL.UNRESOLVED_CALLS, true);
    }
    private ResolveCallPageDTO getSessionPageData()
    {
        return (ResolveCallPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<CallHistoryDTO> getSearchList()
    {
        return getSessionPageData().SearchResult;
    }
    private List<VwCustomer> getMatchingEntityList()
    {
    	return getSessionPageData().MatchingEntityList;
    }
    private List<CallHistoryDTO> getSelectedCallRecords(){
    	ResolveCallPageDTO PageDTO = getSessionPageData();
    	List<CallHistoryDTO> callList = PageDTO.SearchResult.FindAll(x => x.isUISelected);
    	return callList;
    }
    private VwCustomer getSelectedMatchingRecord(){
    	ResolveCallPageDTO PageDTO = getSessionPageData();
    	return PageDTO.MatchingEntityList.Find(x => x.isUISelected);
    }
    private void setMatchingEntitySelected(string EntityType, long EntityId)
    {
        List<VwCustomer> matchingEntityList = getMatchingEntityList();
        matchingEntityList.ForEach(x => x.isUISelected = false);
        if (EntityId > 0)
        {
        	VwCustomer selectedEntity = matchingEntityList.Find(x => (x.EntityType.Equals(EntityType) && x.EntityId == EntityId));
        	selectedEntity.isUISelected = true;
        }
    }
    private void populateUnresolvedCallSearchGrid(List<CallHistoryDTO> tmpList)
    {
        unresolvedCallsGrid.DataSource = new List<CallHistoryDTO>();
        if (tmpList != null)
        {
            unresolvedCallsGrid.DataSource = tmpList;
        }
        unresolvedCallsGrid.DataBind();        
    }
    private void populateMatchingEntityGrid(List<VwCustomer> tmpList)
    {
    	matchingCustomerGrid.DataSource = new List<VwCustomer>();
        if (tmpList != null)
        {
        	assignUiIndexToMatchingEntity(tmpList);
        	matchingCustomerGrid.DataSource = tmpList;
        }
        matchingCustomerGrid.DataBind();        
    }
    private void assignUiIndexToMatchingEntity(List<VwCustomer> tmpList)
    {
        if (tmpList != null && tmpList.Count > 0)
        {
            long uiIndex = 1;
            foreach (VwCustomer tmpDTO in tmpList)
            {
            	tmpDTO.UiIndex = uiIndex++;
            	tmpDTO.RowInfo = CommonUIConverter.getGridViewRowInfo(tmpDTO);
            }
        }
    }
    private void loadCallAndMatchingRecords() {
    	
    	ResolveCallPageDTO PageDTO = getSessionPageData();
        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        //Load Call history records for current customer number.
        IList<CallHistoryDTO> callHistList = callHistoryBO.fetchUnresolvedCallsForNumber(PageDTO.CustomerNumber);
        if (callHistList != null && callHistList.Count > 0)
        {
            PageDTO.SearchResult = callHistList.ToList<CallHistoryDTO>();
            populateUnresolvedCallSearchGrid(PageDTO.SearchResult);

            IList<VwCustomer> matchingEntityList = customerBO.fetchMatchingCustomersForUnresolvedCall(PageDTO.CustomerNumber);
            PageDTO.MatchingEntityList = (matchingEntityList != null) ? matchingEntityList.ToList<VwCustomer>() : new List<VwCustomer>();
            populateMatchingEntityGrid(PageDTO.MatchingEntityList);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    protected string getRecordType(string EntityType)
    {
        VwCustomerEntityType tmpType = CommonUtil.getVwCustomerType(EntityType);
        return tmpType.GetDescription();
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onChangeUnresolvedCallSelection(object sender, EventArgs e)
    {
        try
        {
            CheckBox cb = (CheckBox)sender;
            long selectedId = long.Parse(cb.Attributes["data-pid"]);
            getSessionPageData().SearchResult.Find(x => x.Id == selectedId).isUISelected = cb.Checked;
            populateUnresolvedCallSearchGrid(getSessionPageData().SearchResult);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onSelectMatchingRecord(object sender, EventArgs e)
    {
        try
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            if (rd.Checked)
            {
                Button tmpBtn = (Button)(((GridViewRow)rd.NamingContainer).FindControl("btnMatchingEntityRowIdentifier"));
                long EntityId = long.Parse(tmpBtn.Attributes["row-identifier"]);
                string EntityType = tmpBtn.Attributes["row-type"];
                setMatchingEntitySelected(EntityType, EntityId);
            }
            VwCustomer tmpCustRecord = getSelectedMatchingRecord();
            if ((tmpCustRecord.EntityType.Equals("EQ") || tmpCustRecord.EntityType.Equals("LD")) && !tmpCustRecord.UIStatus.Equals("Open")) {
            	string entityType = (tmpCustRecord.EntityType.Equals("EQ")) ? "Enquiry" : "Lead";
            	(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyInfoMsg(string.Format("Selected matching {0} customer record is not open.", entityType)));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void resolveCall(object sender, EventArgs e)
    {
        try
        {
            if (validateResolveCall())
            {
                List<CallHistoryDTO> callList = getSelectedCallRecords();
                VwCustomer tmpCustRecord = getSelectedMatchingRecord();
                UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
                foreach (CallHistoryDTO tmpDTO in callList)
                {
                    if (tmpCustRecord.EntityType.Equals("LD"))
                    {
                        LeadActivityDTO activityDTO = CommonUtil.createNewCallLeadActivityDTO(0, EnqActivityRecordType.Call, getUserDefinitionDTO(), tmpDTO);
                        activityDTO.LeadDetail = new LeadDetailDTO();
                        activityDTO.LeadDetail.Id = tmpCustRecord.EntityId;
                        enquiryBO.addLeadActivity(activityDTO, EnqActivityMode.MAKE_CALL, 0, userDefDTO);
                    }
                    else if (tmpCustRecord.EntityType.Equals("EQ"))
                    {
                        EnquiryActivityDTO activityDTO = CommonUtil.createNewCallEnquiryActivityDTO(0, EnqActivityRecordType.Call, getUserDefinitionDTO(), tmpDTO);
                        activityDTO.EnquiryDetail = new EnquiryDetailDTO();
                        activityDTO.EnquiryDetail.Id = tmpCustRecord.EntityId;
                        enquiryBO.addEnquiryActivity(activityDTO, EnqActivityMode.MAKE_CALL, 0, userDefDTO);
                    }
                }
                if (tmpCustRecord.EntityType.Equals("UO") || tmpCustRecord.EntityType.Equals("UC"))
                {
                    callHistoryBO.bindCallDetailsToUnit(callList, tmpCustRecord.EntityId, userDefDTO);
                }
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("Selected call records are resolved successfully."));

                if (getSessionPageData().SearchResult.Count == callList.Count) navigateToPreviousPage();
                else loadCallAndMatchingRecords();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelResolveCall(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateResolveCall()
    {
        bool isValid = true;
        List<CallHistoryDTO> callList = getSelectedCallRecords();
        if (callList == null || callList.Count == 0)
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please select unresolved call."));
            return false;
        }
        VwCustomer tmpCustRecord = getSelectedMatchingRecord();
        if (tmpCustRecord == null)
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please select matching customer record."));
            return false;
        }
        return isValid;
    }
    //Master Data Modal save logic - Start
    protected void saveMasterData(object sender, EventArgs e)
    {
        try
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (MasterDataType.ENQUIRY_SOURCE.ToString().Equals(masterDataModalTypeHdn.Value))
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(MasterDataType.ENQUIRY_SOURCE.ToString(), txtMasterDataInput1.Text,
                        txtMasterDataInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Enquiry/Lead Source");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpLeadSource, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.ENQUIRY_SOURCE.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
            }

            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                activeModalHdn.Value = addMasterDataModal;
                setErrorMessage(errorMsg, addMasterDataError);
            }
            else
            {
                resetMasterDataModalFields();
                setParentModalFlag();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            activeModalHdn.Value = "";
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    protected void cancelMasterDataModal(object sender, EventArgs e)
    {
        try
        {
            resetMasterDataModalFields();
            setParentModalFlag();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    private void resetMasterDataModalFields()
    {
        txtMasterDataInput1.Text = "";
        txtMasterDataInput2.Text = "";
        masterDataModalTypeHdn.Value = "";
    }
    private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
    {
        string errorMsg = "";
        if (string.IsNullOrWhiteSpace(masterDataDto.Name))
        {
            errorMsg = string.Format(Resources.Messages.TEXTFIELD_REQUIRED, type);
        }
        else if (masterDataBO.isAlreadyExist(masterDataDto))
        {
            errorMsg = string.Format(Resources.Messages.ALREADY_EXIST_DB_ERROR, type);
        }
        return errorMsg;
    }
    private void setParentModalFlag()
    {
        activeModalHdn.Value = masterDataParentModalHdn.Value;
        masterDataParentModalHdn.Value = "";
    }
    //Master Data Modal save logic - End
    //Lead Modal - Start
    private void initLeadModalFields()
    {
    }
    private void initLeadSectionFields(LeadDetailDTO leadDetailDTO)
    {
        if (leadDetailDTO != null && leadDetailDTO.Salutation != null) drpLeadSalutation.Text = leadDetailDTO.Salutation.Id.ToString(); else drpLeadSalutation.ClearSelection();
        if (leadDetailDTO != null) txtLeadFirstName.Text = leadDetailDTO.FirstName; else txtLeadFirstName.Text = null;
        if (leadDetailDTO != null) txtLeadMiddleName.Text = leadDetailDTO.MiddleName; else txtLeadMiddleName.Text = null;
        if (leadDetailDTO != null) txtLeadLastName.Text = leadDetailDTO.LastName; else txtLeadLastName.Text = null;
        if (leadDetailDTO != null) txtLeadDate.Text = DateUtil.getCSDateTime(leadDetailDTO.LeadDate); else txtLeadDate.Text = DateUtil.getDateTime(Constants.DATETIME_FORMAT_SHORT);
        if (leadDetailDTO != null && leadDetailDTO.ContactInfo != null) txtLeadContact.Text = leadDetailDTO.ContactInfo.Contact; else txtLeadContact.Text = null;
        if (leadDetailDTO != null && leadDetailDTO.ContactInfo != null) txtLeadAltContact.Text = leadDetailDTO.ContactInfo.AltContact; else txtLeadAltContact.Text = null;
        if (leadDetailDTO != null && leadDetailDTO.ContactInfo != null) txtLeadEmail.Text = leadDetailDTO.ContactInfo.Email; else txtLeadEmail.Text = null;
        if (leadDetailDTO != null && leadDetailDTO.Budget != null) txtLeadBudget.Text = leadDetailDTO.Budget.ToString(); else txtLeadBudget.Text = null;
        if (leadDetailDTO != null && leadDetailDTO.Property != null) drpLeadProperty.Text = leadDetailDTO.Property.Id.ToString(); else drpLeadProperty.ClearSelection();
        if (leadDetailDTO != null && leadDetailDTO.Source != null) drpLeadSource.Text = leadDetailDTO.Source.Id.ToString(); else drpLeadSource.ClearSelection();
    }
    private void populateAddressFromUI(LeadDetailDTO leadDetailDTO)
    {
        leadDetailDTO.Salutation = CommonUIConverter.getMasterControlDTO(drpLeadSalutation.Text, drpLeadSalutation.SelectedItem.Text);
        leadDetailDTO.FirstName = txtLeadFirstName.Text;
        leadDetailDTO.MiddleName = txtLeadMiddleName.Text;
        leadDetailDTO.LastName = txtLeadLastName.Text;
        leadDetailDTO.LeadDate = DateUtil.getCSDateTimeShort(txtLeadDate.Text).Value;
        leadDetailDTO.ContactInfo.Contact = txtLeadContact.Text;
        leadDetailDTO.ContactInfo.AltContact = txtLeadAltContact.Text;
        leadDetailDTO.ContactInfo.Email = txtLeadEmail.Text;
        leadDetailDTO.Budget = CommonUtil.getDecimalWithoutExt(txtLeadBudget.Text);
        leadDetailDTO.Property = CommonUIConverter.getPropertyDTO(drpLeadProperty.Text, drpLeadProperty.SelectedItem.Text);
        leadDetailDTO.Source = CommonUIConverter.getMasterControlDTO(drpLeadSource.Text, drpLeadSource.SelectedItem.Text);
    }
    private LeadDetailDTO populateLeadDetailAdd()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        LeadDetailDTO leadDetailDTO = new LeadDetailDTO();
        leadDetailDTO.ContactInfo = new ContactInfoDTO();
        leadDetailDTO.Status = LeadStatus.Open;
        leadDetailDTO.Assignee = CommonUIConverter.getFirmMemberDTO(userDefDto.FirmMember.Id.ToString(), null);
        leadDetailDTO.AssignedDate = DateTime.Today;

        leadDetailDTO.FirmNumber = userDefDto.FirmNumber;
        leadDetailDTO.InsertUser = userDefDto.Username;
        leadDetailDTO.UpdateUser = userDefDto.Username;
        return leadDetailDTO;
    }
    protected void onClickAddLeadBtn(object sender, EventArgs e)
    {
        try
        {
            List<CallHistoryDTO> callList = getSelectedCallRecords();
            if (callList != null && callList.Count > 0)
            {
                initLeadModalFields();
                initLeadSectionFields(null);
                activeModalHdn.Value = addLeadModal;
            }
            else
            {
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please select unresolved call."));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void saveLead(object sender, EventArgs e)
    {
        try
        {
            if (validateLeadAdd() && validateDuplicateLeadOrEnquiry())
            {
                LeadDetailDTO leadDetailDTO = populateLeadDetailAdd();
                populateAddressFromUI(leadDetailDTO);
                List<CallHistoryDTO> callList = getSelectedCallRecords();
                if (callList != null && callList.Count > 0)
                {
                    leadDetailDTO.LeadActivities = new HashSet<LeadActivityDTO>();
                    foreach (CallHistoryDTO tmpDTO in callList)
                    {
                        LeadActivityDTO activityDTO = CommonUtil.createNewCallLeadActivityDTO(0, EnqActivityRecordType.Call, getUserDefinitionDTO(), tmpDTO);
                        leadDetailDTO.LeadActivities.Add(activityDTO);
                    }
                }
                string leadRefNo = enquiryBO.addLeadDetails(leadDetailDTO, getUserDefinitionDTO());
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format("New Lead #{0} is added successfully.", leadRefNo)));
                loadCallAndMatchingRecords();
            }
            else
            {
                activeModalHdn.Value = addLeadModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelLeadModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateLeadAdd()
    {
        bool isValid = true;
        Page.Validate(addLeadModalError);
        isValid = Page.IsValid;
        return isValid;
    }
    private bool validateDuplicateLeadOrEnquiry() {
    	bool isValid = true;
    	long propertyId = long.Parse(drpLeadProperty.Text);
    	string msg = enquiryBO.checkDuplicateEnquiryOrLead(propertyId, txtLeadContact.Text, txtLeadAltContact.Text);
    	if(!string.IsNullOrWhiteSpace(msg)) {
    		isValid = false;
    		setErrorMessage(msg, addLeadModalError);
    	}
    	return isValid;
    }
    //Lead Modal - End
    //Click to Call modal - start
    private void initVirtualPhoneDrp(IList<VirtualPhoneDTO> phoneDTOList) {
    	drpVirtualPhone.Items.Clear();
    	foreach(VirtualPhoneDTO tmpDTO in phoneDTOList) {
    		drpVirtualPhone.Items.Add(new ListItem(tmpDTO.PhoneNumber, tmpDTO.PhoneNumber));
    	}
    }
    protected void onClickConnectCall(object sender, EventArgs e)
    {
        try
        {
    		UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
    		ResolveCallPageDTO PageDTO = getSessionPageData();
    		IList<VirtualPhoneDTO> vPhoneList = propertyUserBO.fetchOutgoingVitualPhonesAllocattedToUser(userDefDTO.FirmMember.Id, CommonUtil.getCurrentPropertyDTO(userDefDTO).Id);
    		if(vPhoneList != null && vPhoneList.Count > 0) {
    			if (vPhoneList.Count == 1) {
    				makeCallToCustomer(userDefDTO.FirmMember.ContactInfo.Contact, PageDTO.CustomerNumber, vPhoneList[0].PhoneNumber);
    			} else {
    				initVirtualPhoneDrp(vPhoneList);
    				lbCustomerNumber.Text = PageDTO.CustomerNumber;
                    drpVirtualPhone.Text = vPhoneList[0].PhoneNumber;
    				
    				activeModalHdn.Value = ClickToCallModal;
    			}    			
    		} else {
    			(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Virtual Phone is not assigned to you. Please contact your supervisor."));
    		}
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void makeCallToCustomer(string agentNumber, string customerNumber, string virtualPhone) {
    	UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        OutboundCallDialDTO callDialDTO = new OutboundCallDialDTO();
        callDialDTO.AgentNumber = agentNumber;
        callDialDTO.CustomerNumber = customerNumber;
        callDialDTO.VirtualPhone = virtualPhone;
        callDialDTO.PropertyId = CommonUtil.getCurrentPropertyDTO(userDefDTO).Id;

        CallClient callClient = new CallClient();
        CallHistoryDTO callHistoryDTO = callClient.placeOutBoundCall(callDialDTO, userDefDTO);
        
        (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("Call is placed successfully."));
        loadCallAndMatchingRecords();
    }
    protected void connectToCall(object sender, EventArgs e)
    {
        try
        {
            Page.Validate(clickToCallModalError);
            bool isValid = Page.IsValid;
            if (isValid)
            {
            	UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
            	makeCallToCustomer(userDefDTO.FirmMember.ContactInfo.Contact, getSessionPageData().CustomerNumber, drpVirtualPhone.Text);
            }
            else
            {
                activeModalHdn.Value = ClickToCallModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelCall(object sender, EventArgs e)
    {
    }
    //Click to Call modal - end
}