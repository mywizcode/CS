﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Constants.
/// </summary>
namespace ConstroSoft
{
    public static class Constants
    {
        //Page Constants
        public class URL
        {
            public const string LOGIN = "/Login";
            public const string CHANGE_PASSWORD_SUCCESS = "/Login?p1=cpsuccess";
            public const string CHANGE_PASSWORD = "ChangePassword";
            public const string FORGOT_PASSWORD = "ForgotPassword";
            public const string LOGIN_SETUP = "LoginSetup";
            public const string ACCESS_DENIED = "~/Error/AccessDenied";

            public const string DEFAULT_HOME_PAGE = "~/DefaultPage";
            //CRM Menu
            public const string CRM_DASHBOARD = "~/CRM/CRMHome";
            public const string CALL_HISTORY = "~/CRM/CallHistory";
            public const string UNRESOLVED_CALLS = "~/CRM/UnresolvedCalls";
            public const string RESOLVE_CALL = "~/CRM/UnresolvedCalls/Resolve";
            public const string MY_LEADS = "~/CRM/Lead";
            public const string LEAD_ACTIVITY_HISTORY = "~/CRM/Lead/ActivityHistory";
            public const string ENQUIRY_SEARCH = "~/CRM/Enquiry";
            public const string ENQUIRY_DETAILS = "~/CRM/Enquiry/EnquiryDetails";
            public const string ENQUIRY_ACTIVITY_HISTORY = "~/CRM/Enquiry/ActivityHistory";
            public const string ALL_ENQUIRY_LEAD_HISTORY = "~/CRM/AllEnquiryLeadSearch";
            public const string USER_ENQUIRY_HISTORY = "~/CRM/AllEnquiryLeadSearch/UserEnquiryHistory";
            public const string USER_LEAD_HISTORY = "~/CRM/AllEnquiryLeadSearch/UserLeadHistory";
            public const string LEAD_ASSIGNMENT = "~/CRM/LeadAssignment";
            public const string AVAILABLE_UNIT_SEARCH = "~/CRM/AvailableUnit";
            public const string SOLD_UNIT_SEARCH = "~/CRM/SoldUnit";
            public const string SOLD_UNIT_DETAILS = "~/CRM/SoldUnit/UnitDetails";
            public const string SOLD_UNIT_MANAGE_DOCUMENTS = "~/CRM/SoldUnit/ManageDocuments";
            public const string SOLD_UNIT_CALL_HISTORY = "~/CRM/SoldUnit/CallHistory";
            public const string CANCELLED_UNIT_SEARCH = "~/CRM/CancelledUnit";
            public const string CANCELLED_UNIT_DETAILS = "~/CRM/CancelledUnit/UnitDetails";
            public const string CANCELLED_UNIT_MANAGE_DOCUMENTS = "~/CRM/CancelledUnit/ManageDocuments";
            public const string CANCELLED_UNIT_CALL_HISTORY = "~/CRM/CancelledUnit/CallHistory";
            public const string GENERATE_LETTERS = "~/CRM/SoldUnit/LetterGeneration";
            public const string BOOKING_CANCELLATION = "~/CRM/SoldUnit/BookingCancellation";
            public const string BOOKING_CANCEL_SUCCESS = "~/CRM/SoldUnit/BookingCancelSuccess";
            public const string BOOKING_FORM = "~/CRM/AvailableUnit/BookingForm";
            public const string BOOKING_SUCCESS = "~/CRM/AvailableUnit/BookingSuccess";
            public const string ACNTFINANCE_DASHBOARD = "~/AcntFinance/AcntFinanceHome";
            public const string CUSTOMER_PYMT_SEARCH = "~/AcntFinance/CustomerPayment";
            public const string CUSTOMER_PYMT_ADD = "~/AcntFinance/CustomerPayment/Add";
            public const string CUSTOMER_PYMT_ADDPDC = "~/AcntFinance/CustomerPayment/AddPdc";
            public const string CUSTOMER_PYMT_MODIFYPDC = "~/AcntFinance/CustomerPayment/ModifyPdc";
            public const string CUSTOMER_PYMT_HISTORY = "~/AcntFinance/CustomerPayment/PymtHistory";
            public const string FIRM_PROPERTY_SETUP_DASHBOARD = "~/FirmPropertySetup/PropertySetupHome";
			public const string FIRM_SETUP = "~/FirmPropertySetup/FirmSetup";
			public const string PROPERTY_FUND_SEARCH = "~/AcntFinance/PropertyFund";
            public const string PROPERTY_FUND_DETAIL = "~/AcntFinance/PropertyFund/FundDetails";
			public const string FIRM_ACCOUNT = "~/AcntFinance/AccountSummary";
            public const string FIRM_ACCOUNT_STATEMENT = "~/AcntFinance/AccountStatement";
            public const string CUSTOMER_SEARCH = "~/CRM/Customer";
            public const string CUSTOMER_DETAILS = "~/CRM/Customer/CustomerDetails";
            public const string CUSTOMER_MANAGE_DOCUMENTS = "~/CRM/Customer/ManageDocuments";
            public const string PROPERTY_MANAGE_DOCUMENTS = "~/FirmPropertySetup/Property/ManageDocuments";
            public const string PROPERTY_SEARCH = "~/FirmPropertySetup/Property";
            public const string PROPERTY_DETAILS = "~/FirmPropertySetup/Property/PropertyDetails";
            public const string PROPERTY_UNIT_SEARCH = "~/FirmPropertySetup/PropertyUnit";
            public const string PROPERTY_UNIT_DETAILS = "~/FirmPropertySetup/PropertyUnit/UnitDetails";
            public const string PROPERTY_UNIT_UPLOAD = "~/FirmPropertySetup/PropertyUnit/Upload";
            public const string PROPERTY_PARKING_SEARCH = "~/FirmPropertySetup/PropertyParking";
            public const string PROPERTY_PARKING_DETAILS = "~/FirmPropertySetup/PropertyParking/ParkingDetails";
            public const string PROPERTY_PARKING_UPLOAD = "~/FirmPropertySetup/PropertyParking/Upload";
            public const string PROPERTY_USER_ACCESS = "~/FirmPropertySetup/Property/UserAccess";
            public const string PROPERTY_VIRTUAL_PHONE = "~/FirmPropertySetup/Property/VirtualPhone";
            public const string ADMINITRATION_DASHBOARD = "~/Administration/AdministrationHome";
            public const string USER_PROFILE = "~/User/UserProfile";
        }
        public class Function
        {
            public const string CRM = "CRM";
            public const string ERP = "ERP";
            public const string FIRM_PROPERTY_SETUP = "FirmPropertySetup";
            public const string ACNT_FINANCE = "AcntFinance";
            public const string ADMINISTRATION = "Administration";
            public const string PROPERTY_WITH_ACCESS = "PROPERTY_WITH_ACCESS";
        }
        public class Session
        {
            public const string USERDEFINITION = "USERDEFINITION";
            public const string USERNAME = "USERNAME";
            public const string NOTY_MSG = "NOTY_MSG";
            public const string PAGE_DATA = "PAGE_DATA";
            public const string NAV_DTO = "NAV_DTO";
            public const string FUNCTION_NAME = "FUNCTION";
        }
        public class Entitlement
        {
            public const string MENU_FN_CRM = "MENU_FN_CRM";
            public const string MENU_CALL_MANAGEMENT = "MENU_CALL_MANAGEMENT";
            public const string MENU_CALL_HISTORY = "MENU_CALL_HISTORY";
            public const string MENU_UNRESOLVED_CALLS = "MENU_UNRESOLVED_CALLS";
            public const string RESOLVE_CALL = "RESOLVE_CALL";
            public const string RESOLVE_CALL_CLICK_TO_CALL = "RESOLVE_CALL_CLICK_TO_CALL";
            public const string MENU_ENQUIRY_MANAGEMENT = "MENU_ENQUIRY_MANAGEMENT";
            public const string MENU_ALL_ENQ_LEADS = "MENU_ALL_ENQ_LEADS";
            public const string MENU_LEAD_ASSIGNMENT = "MENU_LEAD_ASSIGNMENT";
            public const string MENU_MY_LEADS = "MENU_MY_LEADS";
            public const string LEAD_ADD = "LEAD_ADD";
            public const string LEAD_CLICK_TO_CALL = "LEAD_CLICK_TO_CALL";
            public const string MENU_MY_ENQUIRIES = "MENU_MY_ENQUIRIES";
            public const string ENQUIRY_ADD = "ENQUIRY_ADD";
            public const string ENQUIRY_MODIFY = "ENQUIRY_MODIFY";
            public const string ENQUIRY_CLICK_TO_CALL = "ENQUIRY_CLICK_TO_CALL";
            public const string MENU_PROMOTION_MANAGEMENT = "MENU_PROMOTION_MANAGEMENT";
            public const string MENU_PROMOTIONS = "MENU_PROMOTIONS";
            public const string MENU_SALE_MANAGEMENT = "MENU_SALE_MANAGEMENT";
            public const string MENU_AVAILABLE_PR_UNIT = "MENU_AVAILABLE_PR_UNIT";
            public const string BOOK_PR_UNIT = "BOOK_PR_UNIT";
            public const string GET_QUOTATION = "GET_QUOTATION";
            public const string MENU_SOLD_PR_UNIT = "MENU_SOLD_PR_UNIT";
            public const string SOLD_UNIT_MODIFY = "SOLD_UNIT_MODIFY";
            public const string CANCEL_BOOKING = "CANCEL_BOOKING";
            public const string GENERATE_LETTERS = "GENERATE_LETTERS";
            public const string MANAGE_SOLD_UNIT_DOCUMENTS = "MANAGE_SOLD_UNIT_DOCUMENTS";
            public const string SOLD_UNIT_CLICK_TO_CALL = "SOLD_UNIT_CLICK_TO_CALL";
            public const string SOLD_UNIT_CUSTOMER_CALL_HISTORY = "SOLD_UNIT_CUSTOMER_CALL_HISTORY";
            public const string SOLD_UNIT_DOC_CREATE_FOLDER = "SOLD_UNIT_DOC_CREATE_FOLDER";
            public const string SOLD_UNIT_DOC_UPLOAD_DOCUMENT = "SOLD_UNIT_DOC_UPLOAD_DOCUMENT";
            public const string SOLD_UNIT_DOC_DELETE_DOCUMENT = "SOLD_UNIT_DOC_DELETE_DOCUMENT";
            public const string MENU_CANCELLED_PR_UNIT = "MENU_CANCELLED_PR_UNIT";
            public const string CANCELLED_UNIT_MODIFY = "CANCELLED_UNIT_MODIFY";
            public const string MANAGE_CANCELLED_UNIT_DOCUMENTS = "MANAGE_CANCELLED_UNIT_DOCUMENTS";
            public const string CANCELLED_UNIT_CLICK_TO_CALL = "CANCELLED_UNIT_CLICK_TO_CALL";
            public const string CANCELLED_UNIT_CUSTOMER_CALL_HISTORY = "CANCELLED_UNIT_CUSTOMER_CALL_HISTORY";
            public const string CANCELLED_UNIT_DOC_CREATE_FOLDER = "CANCELLED_UNIT_DOC_CREATE_FOLDER";
            public const string CANCELLED_UNIT_DOC_UPLOAD_DOCUMENT = "CANCELLED_UNIT_DOC_UPLOAD_DOCUMENT";
            public const string CANCELLED_UNIT_DOC_DELETE_DOCUMENT = "CANCELLED_UNIT_DOC_DELETE_DOCUMENT";
            public const string MENU_CUSTOMER = "MENU_CUSTOMER";
            public const string CUSTOMER_ADD = "CUSTOMER_ADD";
            public const string CUSTOMER_MODIFY = "CUSTOMER_MODIFY";
            public const string CUSTOMER_DELETE = "CUSTOMER_DELETE";
            public const string MANAGE_CUSTOMER_DOCUMENTS = "MANAGE_CUSTOMER_DOCUMENTS";
            public const string CUSTOMER_DOC_CREATE_FOLDER = "CUSTOMER_DOC_CREATE_FOLDER";
            public const string CUSTOMER_DOC_UPLOAD_DOCUMENT = "CUSTOMER_DOC_UPLOAD_DOCUMENT";
            public const string CUSTOMER_DOC_DELETE_DOCUMENT = "CUSTOMER_DOC_DELETE_DOCUMENT";
            public const string MENU_FN_ACCOUNT_FINANCE = "MENU_FN_ACCOUNT_FINANCE";
            public const string MENU_ACCOUNT_MANAGEMENT = "MENU_ACCOUNT_MANAGEMENT";
            public const string MENU_ACCOUNTS = "MENU_ACCOUNTS";
            public const string ACCOUNT_ADD = "ACCOUNT_ADD";
            public const string ACCOUNT_MODIFY = "ACCOUNT_MODIFY";
            public const string MENU_TALLY_MANAGEMENT = "MENU_TALLY_MANAGEMENT";
            public const string MENU_PAYMENT_MANAGEMENT = "MENU_PAYMENT_MANAGEMENT";
            public const string MENU_CUSTOMER_PAYMENTS = "MENU_CUSTOMER_PAYMENTS";
            public const string PAYMENT_ADD = "PAYMENT_ADD";
            public const string PDC_ADD = "PDC_ADD";
            public const string GENERATE_PYMT_RECEIPT = "GENERATE_PYMT_RECEIPT";
            public const string MARK_PYMT_RCPT_DELIVERED = "MARK_PYMT_RCPT_DELIVERED";
            public const string DELETE_PAYMENT_TRANSACTION = "DELETE_PAYMENT_TRANSACTION";
            public const string MODIFY_PDC = "MODIFY_PDC";
            public const string DELETE_PDC = "DELETE_PDC";
            public const string MENU_PROPERTY_FUND_MANAGEMENT = "MENU_PROPERTY_FUND_MANAGEMENT";
            public const string ADD_PROPERTY_FUNDS = "ADD_PROPERTY_FUNDS";
            public const string DELETE_PROPERTY_FUNDS = "DELETE_PROPERTY_FUNDS";
            public const string MENU_ACNTFN_REPORT_AND_ANALYTICS = "MENU_ACNTFN_REPORT_AND_ANALYTICS";
            public const string PAYMENT_DUE_REPORT = "PAYMENT_DUE_REPORT";
            public const string PAYMENT_SHEDULE_REPORT = "PAYMENT_SHEDULE_REPORT";
            public const string MENU_FIRM_PROPERTY_SETUP = "MENU_FIRM_PROPERTY_SETUP";
            public const string MENU_FIRM = "MENU_FIRM";
            public const string MODIFY_FIRM_DETAILS = "MODIFY_FIRM_DETAILS";
            public const string MENU_PROPERTY = "MENU_PROPERTY";
            public const string PROPERTY_ADD = "PROPERTY_ADD";
            public const string PROPERTY_MODIFY = "PROPERTY_MODIFY";
            public const string PROPERTY_DELETE = "PROPERTY_DELETE";
            public const string PROPERTY_USER_ACCESS = "PROPERTY_USER_ACCESS";
            public const string VIRTUAL_PHONE_USER_ACCESS = "VIRTUAL_PHONE_USER_ACCESS";
            public const string MANAGE_PROPERTY_DOCUMENTS = "MANAGE_PROPERTY_DOCUMENTS";
            public const string PROPERTY_DOC_CREATE_FOLDER = "PROPERTY_DOC_CREATE_FOLDER";
            public const string PROPERTY_DOC_UPLOAD_DOCUMENT = "PROPERTY_DOC_UPLOAD_DOCUMENT";
            public const string PROPERTY_DOC_DELETE_DOCUMENT = "PROPERTY_DOC_DELETE_DOCUMENT";
            public const string MENU_PROPERTY_UNIT = "MENU_PROPERTY_UNIT";
            public const string PROPERTY_UNIT_ADD = "PROPERTY_UNIT_ADD";
            public const string PROPERTY_UNIT_MODIFY = "PROPERTY_UNIT_MODIFY";
            public const string PROPERTY_UNIT_DELETE = "PROPERTY_UNIT_DELETE";
            public const string MENU_PROPERTY_PARKING = "MENU_PROPERTY_PARKING";
            public const string PROPERTY_PARKING_ADD = "PROPERTY_PARKING_ADD";
            public const string PROPERTY_PARKING_MODIFY = "PROPERTY_PARKING_MODIFY";
            public const string PROPERTY_PARKING_DELETE = "PROPERTY_PARKING_DELETE";
            public const string MENU_PROPERTY_PYMT_SCHEDULE = "MENU_PROPERTY_PYMT_SCHEDULE";
            public const string PYMT_SCHEDULE_ADD = "PYMT_SCHEDULE_ADD";
            public const string PYMT_SCHEDULE_MODIFY = "PYMT_SCHEDULE_MODIFY";
            public const string PYMT_SCHEDULE_DELETE = "PYMT_SCHEDULE_DELETE";
            public const string MENU_ADMINISTRATION = "MENU_ADMINISTRATION";
            public const string MENU_MANAGE_MASTER = "MENU_MANAGE_MASTER";
            public const string MASTER_DATA_ADD = "MASTER_DATA_ADD";
            public const string MASTER_DATA_MODIFY = "MASTER_DATA_MODIFY";
            public const string MASTER_DATA_DELETE = "MASTER_DATA_DELETE";
        }
        public class FUNCTIONNAME
        {
            public const string ENQUIRY = "MANAGE ENQUIRY";
            public const string SALE = "MANAGE SALES";

        }
        public class EMAILSMSTYPE
        {
            public const string ENQUIRYTHANKS = "ENQUIRY THANKS";
            public const string SALESTHANKS = "SALE THANKS";
            public const string SALESCANCEL = "SALE CANCEL";
        }
        public class PYMT_ENTITY
        {
            public const string UNIT_SALE = "FIRM_CUSTOMER";
            public const string CONTRACTOR = "FIRM_CONTRACTOR";
            public const string SUPPLIER = "FIRM_SUPPLIER";
            public const string AGENCY = "FIRM_AGENCY";
        }
        public class FILTER
        {
            public const string TOWER_NAME = "Tower: ";
            public const string PROPERTY_NAME = "Name: ";
            public const string PROPERTY_TYPE = "Type: ";
            public const string PROPERTY_LOCATION = "Location: ";
            public const string UNIT_NO = "Unit No: ";
            public const string UNIT_TYPE = "Unit Type: ";
            public const string WING = "Wing: ";
            public const string FLOOR_NO = "Floor No: ";
            public const string STATUS = "Status: ";
            public const string FIRST_NAME = "First Name: ";
            public const string LAST_NAME = "Last Name: ";
            public const string DOB = "Dob: ";
            public const string CONTACT = "Contact: ";
            public const string CUST_REF_NO = "Customer Ref #: ";
            public const string CUSTOMER = "Customer: ";
            public const string SALES_EXECUTIVE = "Executive: ";
            public const string BOOKING_REF_NO = "Booking Ref #: ";
            public const string PYMT_TYPE = "Pymt Type: ";
            public const string PYMT_METHOD = "Pymt Method: ";
            public const string MEDIA_NO = "Media No: ";
            public const string TX_REF_NO = "Tx Ref No: ";
            public const string PARKING_NO = "Parking No: ";
            public const string PARKING_TYPE = "Parking Type: ";
            public const string COMMON_PARKING = "Common Parking: ";
            public const string ENQUIRY_REF_NO = "Enquiry Ref #: ";            
            public const string LEAD_REF_NO = "Lead Ref #: ";
            public const string ENQUIRY_STATUS = "Status: ";
            public const string ENQUIRY_SOURCE = "Source: ";
            public const string SOURCE = "Source: ";
            public const string ACCOUNT_NAME = "Account Name: ";
            public const string VOUCHER_TYPE = "Voucher Type: ";
            public const string POSTING_STATUS = "Posting Status: ";
            public const string ACTION = "Action: ";
            public const string CUSTOMER_NUMBER = "Customer Number: ";
            public const string ALL_CALLS = "All Calls";
            public const string AGENT = "Agent: ";
            public const string INCOMING = "Incoming";
            public const string OUTGOING = "Outgoing";
        }
        public class ICON
        {
        	public const string ADD = "<i class=\"icon-googleplus5 position-left\"></i>";
            public const string MODIFY = "<i class=\"icon-pencil7 position-left\"></i>";
            public const string SEARCH = "<i class=\"icon-stack2 position-left\"></i>";
            public const string VIEW_DTL = "<i class=\"icon-grid position-left\"></i>";
            public const string UPLOAD = "<i class=\"icon-upload7 position-left\"></i>";
            public const string CRM_FN_MENU = "<i class=\"icon-people\"></i>";
            public const string ERP_FN_MENU = "<i class=\"icon-construction\"></i>";
            public const string ACNTFINANCE_FN_MENU = "<i class=\"icon-calculator\"></i>";
            public const string PR_SETUP_FN_MENU = "<i class=\"icon-sphere\"></i>";
            public const string ADMIN_FN_MENU = "<i class=\"icon-gear\"></i>";
            public const string ENQUIRY_ADD_ACTIVITY = "<i class=\"icon-mention position-left\"></i>";
            public const string ADD_REMINDER = "<i class=\"icon-alarm-add position-left\"></i>";
            public const string RESCHEDULE_REMINDER = "<i class=\"icon-history position-left\"></i>";
            public const string COMPLETE_REMINDER = "<i class=\"icon-alarm-check position-left\"></i>";
            public const string CANCEL_REMINDER = "<i class=\"icon-alarm-cancel position-left\"></i>";
            public const string ADD_NOTE = "<i class=\"icon-bubble7 position-left\"></i>";
        }
        public class NOTY_TYPE
        {
            public const string SUCCESS = "success";
            public const string ERROR = "error";
            public const string WARNING = "warning";
            public const string INFO = "information";
        }

        public class ENQ_ACTIVITY_ACTION_COMMENT
        {
            public const string ASSIGNMENT	= "Enquiry is assigned to {0}.";
            public const string REASSIGNMENT	= "Enquiry is reassigned to {0}.";
            public const string CONVERTED	= "Lead #{0} is converted to Enquiry.";
            public const string CREATE	= "New Enquiry is created.";
            public const string LOST	= "Enquiry Lost - Enquiry is Closed.";
            public const string WON	= "Enquiry Won - Unit booking is placed against this enquiry. Booking Ref# {0}";
            public const string BOOKING_CANCELLED	= "Enquiry Lost - Unit booking done against this enquiry is cancelled.";
            public const string REOPENED	= "Enquiry is reopened.";
        }
        public class LEAD_ACTIVITY_ACTION_COMMENT
        {
            public const string ASSIGNMENT = "Lead is assigned to {0}.";
            public const string REASSIGNMENT = "Lead is reassigned to {0}.";
            public const string CONVERTED = "Lead is converted to Enquiry #{0}.";
            public const string CREATE = "New Lead is created.";
            public const string LOST = "Lead Lost - Lead is Closed.";
        }
        public class DOCUMENT_MANAGEMENT
        {
            public const string DOC_MANAGEMENT_PATH = "~\\Uploads\\";
            public const string BOOKING_UNIT_DOC_PATH = DOC_MANAGEMENT_PATH + "Booked Units\\";
            public const string CUSTOMER_DOC_PATH = DOC_MANAGEMENT_PATH + "Customer\\";
            public const string PROPERTY_DOC_PATH = DOC_MANAGEMENT_PATH + "Property\\";
            public const string PAYMENT_RECEIPT_PATH = "Payment Receipt\\";
            public const string DEMAND_LETTER_FOLDER = "Demand Letters";
            public const string CUSTOMER_TEMP_FOLDER = "Customer Documents";
            public const string TMP_PATH = DOC_MANAGEMENT_PATH + "Temp\\";
            public const string USER_DOCUMENT_PATH = DOC_MANAGEMENT_PATH + "User\\";
            public const string USER_PROFILE_PATH = USER_DOCUMENT_PATH + "{0}\\Profile\\";
            public const string USER_TMP_PROFILE_IMG = "{0}_ProfileImg.jpg";
            public const string USER_PROFILE_IMG = "User_Profile.jpg";
            public const string USER_PROFILE_DEFAULT_IMG = "~/assets/app/images/default_img.jpg";
            public const string HOME = "Home";
        }
        public class NOTIFICATIONS
        {
            public const string MSG_SEPARATOR = "~~";
            public const string PARAM_SEPARATOR = "~";
            public const string KEY_SEPARATOR = "~";
            public const string PARAM_LINK = "LINK:";
            public const string PARAM_BOLD = "BOLD:";
            public const int REMINDER_TO_NOTIFY = 24;
            public const string NEW_LEAD_FLAG = "NEW_LEAD_FLAG";
            public const string UNRESOLVED_FLAG = "UNRESOLVED_FLAG";
        }
        public class JOBS
        {
            public const string TASK_NOTIFICATION_JOB = "TaskNotificationJob";
            public const string EXOTEL_CALL_JOB = "ExotelCallJob";
        }
        //public const string DOC_DEFAULT_PATH = "C:\\MyData\\Sunil\\WizEye\\ConstroSoft";
        public const string DATE_DD_MM_YYYY = "dd-mm-yyyy";
        public const string DATE_FORMAT = "dd-MMM-yyyy";
        public const string DATETIME_FORMAT = "dddd, dd-MMM-yyyy, hh:mm tt";
        public const string DATETIME_FORMAT_SHORT = "dd-MMM-yyyy, hh:mm tt";
        public const string TALLY_DATE_FORMAT = "yyyyMMdd";
        public const string DEFAULT_COUNTRY = "1";
        public const string DEFAULT_STATE = "21";
        public const string SCROLL_TOP = "TOP";
        public const string SYSADMIN_USER = "SYSADMIN";
        public const string MCD_SALE_PAYMENT = "SALE PAYMENT";
        public const string MCD_CANCELLATION_PAYMENT = "CANCELLATION PAYMENT";
        public const string MCD_FACEBOOK = "Facebook";
        public static readonly string[] SELECT_ITEM = { "--Select--", "" };
        public static readonly string[] SEC_QUESTION_SELECT_ITEM = { "--Select Security Question--", "" };
        public static readonly string[] APPENDERS = { "Rs.", "%", "Sq.Ft.", "Sq.Mtr." };
        public const string YES = "Y";
        public const string NO = "N";
        public const string UPLOAD_VALIDATED = "Validated Successfully";
        public const string UPLOAD_SUCCESS = "Uploaded Successfully";
        public const int CRM_STATS_NO_OF_WEEKS = 5;
        //Account Transaction Comments
        public const string PYMT_FROM = "PYMT FROM {0}";
        public const string REV_PYMT_FROM = "REVERSAL-PYMT FROM {0}";
        public const string PYMT_TO = "PYMT TO {0}";
        public const string REV_PYMT_TO = "REVERSAL-PYMT TO {0}";
        public const string CASH_PYMT_MODE = "PYMT METHOD-CASH";
        public const string CHQ_PYMT_MODE = "PYMT METHOD-CHQUE,CHQUE#{0}";
        public const string NEFT_PYMT_MODE = "PYMT METHOD-NEFT";
        public const string DD_PYMT_MODE = "PYMT METHOD-DD";
        public const string RTGS_PYMT_MODE = "PYMT METHOD-RTGS";
        public const string TX_REF = "TX REF#{0}";
        public const string REV_TX_REF = "REV TX REF#{0}";
        public const string UNIT_SALE_TYPE = "UNIT SALE-";
        public const string PROP_EXP_TYPE = "EXPENSE TYPE-";
        public const string TOKEN_FIELD_DELIMITER = "~";
        public const string SEP1 = "~~";
        public const string SEP2 = "~";
        //Tally Constant
        public const string VOUCHER_CREATE_ACTION = "Create";
        public const string VOUCHER_CANCEL_ACTION = "Cancel";
        public const string VOUCHER_TYPE_PAYMENT = "Payment";
        public const string VOUCHER_TYPE_RECEIPT = "Receipt";
        public const string VOUCHER_YES = "Yes";
        public const string VOUCHER_NO = "No";
        public const string VOUCHER_BILL_LEDGERTYPE = "Bill";
        public const string VOUCHER_BANK_LEDGERTYPE = "Bank";
        public const string VOUCHER_LEDGERNAME_CASH = "Cash";
        public const string VOUCHER_CHEQUE_COMMENT = "A/c Payee";
        public const string VOUCHER_PENDING = "Pending";
        public const string VOUCHER_BILLTYPE = "New Ref";

    }
}