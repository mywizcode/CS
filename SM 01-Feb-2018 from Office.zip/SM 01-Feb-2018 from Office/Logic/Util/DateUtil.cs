﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Mail;
/// <summary>
/// Summary description for EmailUtil
/// </summary>
using ConstroSoft;
using NHibernate;

namespace ConstroSoft
{
    public static class DateUtil
    {
        //Logger Instance
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public static string getFormattedDate(DateTime date, string format)
        {
            return date.ToString(format);
        }
        /**
         * Returns date in constrosoft UI (dd-MMM-yyyy) format. Accepts Nullable DateTime.
         */
        public static string getCSDate(DateTime? date)
        {
            return (date != null) ? date.Value.ToString(Constants.DATE_FORMAT) : null;
        }
        /**
         * Returns date in Tally (yyyyMMdd) format. Accepts Nullable DateTime.
         */
        public static string getTallyDate(DateTime? date)
        {
            return (date != null) ? date.Value.ToString(Constants.TALLY_DATE_FORMAT) : null;
        }
        public static DateTime? getCSDate(string strDate)
        {
            DateTime? date = null;
            if (!string.IsNullOrWhiteSpace(strDate)) date = DateTime.ParseExact(strDate, Constants.DATE_FORMAT, CultureInfo.InvariantCulture);
            return date;
        }
        public static string getCSDateTime(DateTime? date)
        {
            return (date != null) ? date.Value.ToString(Constants.DATETIME_FORMAT) : null;
        }
        public static DateTime? getCSDateTime(string strDateTime)
        {
            DateTime? date = null;
            if (!string.IsNullOrWhiteSpace(strDateTime)) date = DateTime.ParseExact(strDateTime, Constants.DATETIME_FORMAT, CultureInfo.InvariantCulture);
            return date;
        }
        public static DateTime? getCSDateTimeShort(string strDateTime)
        {
            DateTime? date = null;
            if (!string.IsNullOrWhiteSpace(strDateTime)) date = DateTime.ParseExact(strDateTime, Constants.DATETIME_FORMAT_SHORT, CultureInfo.InvariantCulture);
            return date;
        }
        public static DateTime getCSDateNotNull(string strDate)
        {
            DateTime date = DateTime.Today;
            if (!string.IsNullOrWhiteSpace(strDate)) date = DateTime.ParseExact(strDate, Constants.DATE_FORMAT, CultureInfo.InvariantCulture);
            return date;
        }
        public static string getTodayDate()
        {
            return DateTime.Today.ToString(Constants.DATE_FORMAT);
        }
        public static string getDateTime(string dateFormat)
        {
            return DateTime.Now.ToString(dateFormat);
        }
        public static int getDateDiffInDays(DateTime startDate, DateTime endDate, int inclusive)
        {
            int days = 0;
            if (startDate.CompareTo(endDate) <= 0)
            {
                if (inclusive == 0)
                {
                    days = ((endDate - startDate).Days) - 1;
                }
                else if (inclusive == 1)
                {
                    days = (endDate - startDate).Days;
                }
                else
                {
                    days = (endDate - startDate).Days + 1;
                }
            }
            return days;
        }
        public static bool isReminderQualifiedForNotification(DateTime? scheduledDate)
        {
        	bool isQualified = (scheduledDate.Value.CompareTo(DateTime.Now) > 0);
        	if(!isQualified) {
        		TimeSpan span = (scheduledDate.Value - DateTime.Now);
                isQualified = span.TotalHours <= Constants.NOTIFICATIONS.REMINDER_TO_NOTIFY;
        	}
        	return isQualified;
        }
        public static DateTime[] getPreviousCalendarMonthRange(int NoOfMonths) {
    		DateTime[] range = new DateTime[2];
    		var startOfMonth = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
    		range[0] = startOfMonth.AddMonths(NoOfMonths);
    		range[1] = (NoOfMonths == 0) ? DateTime.Today : startOfMonth.AddDays(-1);
    		return range;
    	}
        public static DateTime? getUserLocalDateTime()
        {
            TimeZoneInfo usersTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            DateTime? usersLocalDateTime = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, usersTimeZone);
            return usersLocalDateTime;
        }
        public static DateTime? getUserLocalDate()
        {
            TimeZoneInfo usersTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            DateTime? usersLocalDate = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow.Date, usersTimeZone);
            return usersLocalDate;
         }
    }
}