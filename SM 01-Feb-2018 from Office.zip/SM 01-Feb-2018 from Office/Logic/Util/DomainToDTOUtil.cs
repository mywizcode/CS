﻿
/// <summary>
/// Summary description for CommonUtil
/// </summary>
using ConstroSoft;
using System.Collections.Generic;
namespace ConstroSoft
{
    public class DomainToDTOUtil
    {
        public DomainToDTOUtil() { }
        public static AddressDTO convertToAddressDTO(Address address)
        {
            AddressDTO addressDto = null;
            if (address != null)
            {
                addressDto = new AddressDTO();
                addressDto.Id = address.Id;
                addressDto.PreferredAddress = address.PreferredAddress;
                addressDto.AddressLine1 = address.AddressLine1;
                addressDto.AddressLine2 = address.AddressLine2;
                addressDto.Town = address.Town;
                addressDto.Pin = address.Pin;
                addressDto.AddressType = DomainToDTOUtil.convertToMasterControlDTO(address.AddressType, false);
                addressDto.City = DomainToDTOUtil.convertToCityDTO(address.City, false);
                addressDto.State = DomainToDTOUtil.convertToStateDTO(address.State, false);
                addressDto.Country = DomainToDTOUtil.convertToCountryDTO(address.Country, false);
            }
            return addressDto;
        }
        public static ContactInfoDTO convertToContactInfoDTO(ContactInfo contactInfo)
        {
            ContactInfoDTO contactInfoDto = null;
            if (contactInfo != null)
            {
                contactInfoDto = new ContactInfoDTO();
                contactInfoDto.Id = contactInfo.Id;
                contactInfoDto.Contact = contactInfo.Contact;
                contactInfoDto.AltContact = contactInfo.AltContact;
                contactInfoDto.Gender = contactInfo.Gender;
                contactInfoDto.MaritalStatus = contactInfo.MaritalStatus;
                contactInfoDto.Dob = contactInfo.Dob;
                contactInfoDto.Email = contactInfo.Email;
                contactInfoDto.AltEmail = contactInfo.AltEmail;
                contactInfoDto.Addresses = new HashSet<AddressDTO>();
                if (contactInfo.Addresses != null && contactInfo.Addresses.Count > 0)
                {
                    foreach (Address address in contactInfo.Addresses)
                    {
                        contactInfoDto.Addresses.Add(DomainToDTOUtil.convertToAddressDTO(address));
                    }
                }
            }
            return contactInfoDto;
        }
        public static FirmDTO convertToFirmDTO(Firm firm, bool allFields)
        {
            FirmDTO firmDto = null;
            if (firm != null)
            {
                firmDto = new FirmDTO();
                firmDto.Id = firm.Id;
                firmDto.Name = firm.Name;
                firmDto.FirmNumber = firm.FirmNumber;
                if (allFields)
                {
                    firmDto.RegistrationNo = firm.RegistrationNo;
                    firmDto.GSTin = firm.GSTin;
                    firmDto.WebSite = firm.WebSite;
                    firmDto.Description = firm.Description;
                    firmDto.InsertDate = firm.InsertDate;
                    firmDto.UpdateDate = firm.UpdateDate;
                    firmDto.Version = firm.Version;
                    firmDto.InsertUser = firm.InsertUser;
                    firmDto.UpdateUser = firm.UpdateUser;
                    firmDto.ContactInfo = DomainToDTOUtil.convertToContactInfoDTO(firm.ContactInfo);
                }
            }
            return firmDto;
        }

        public static FirmAccountDTO convertToFirmAccountDTO(FirmAccount firmAccount, bool allFields)
        {
            FirmAccountDTO firmAccountDto = null;
            if (firmAccount != null)
            {
                firmAccountDto = new FirmAccountDTO();
                firmAccountDto.Id = firmAccount.Id;
                firmAccountDto.Name = firmAccount.Name;
                firmAccountDto.AccountNo = firmAccount.AccountNo;
                if (allFields)
                {
                    firmAccountDto.AccountType = DomainToDTOUtil.convertToMasterControlDTO(firmAccount.AccountType, false);
                    firmAccountDto.AccountBalance = firmAccount.AccountBalance;
                    firmAccountDto.IfscCode = firmAccount.IfscCode;
                    firmAccountDto.BankName = firmAccount.BankName;
                    firmAccountDto.Branch = firmAccount.Branch;
                    firmAccountDto.City = DomainToDTOUtil.convertToCityDTO(firmAccount.City, false);
                    firmAccountDto.State = DomainToDTOUtil.convertToStateDTO(firmAccount.State, false);
                    firmAccountDto.Country = DomainToDTOUtil.convertToCountryDTO(firmAccount.Country, false);
                    firmAccountDto.FirmNumber = firmAccount.FirmNumber;
                    firmAccountDto.UpdateDate = firmAccount.UpdateDate;
                    firmAccountDto.Version = firmAccount.Version;
                    firmAccountDto.InsertUser = firmAccount.InsertUser;
                    firmAccountDto.UpdateUser = firmAccount.UpdateUser;
                    firmAccountDto.RowInfo = CommonUIConverter.getGridViewRowInfo(firmAccountDto);
                }
            }
            return firmAccountDto;
        }
        public static EnquiryDetailDTO convertToEnquiryDetailDTO(EnquiryDetail enquiryDetail, bool allFields, bool fetchActivities)
        {
            EnquiryDetailDTO enquiryDto = null;
            if (enquiryDetail != null)
            {
                enquiryDto = new EnquiryDetailDTO();
                enquiryDto.Id = enquiryDetail.Id;
                enquiryDto.EnquiryRefNo = enquiryDetail.EnquiryRefNo;
                if (allFields)
                {
                	enquiryDto.Salutation = DomainToDTOUtil.convertToMasterControlDTO(enquiryDetail.Salutation, false);
	                enquiryDto.FirstName = enquiryDetail.FirstName;
	                enquiryDto.MiddleName = enquiryDetail.MiddleName;
	                enquiryDto.LastName = enquiryDetail.LastName;
	                enquiryDto.AssignedDate = enquiryDetail.AssignedDate;
                    enquiryDto.DateClosed = enquiryDetail.DateClosed;
	                enquiryDto.ContactInfo = DomainToDTOUtil.convertToContactInfoDTO(enquiryDetail.ContactInfo);
	                enquiryDto.Occupation = DomainToDTOUtil.convertToMasterControlDTO(enquiryDetail.Occupation, false);
	                enquiryDto.EnquiryDate = enquiryDetail.EnquiryDate;
	                enquiryDto.Property = DomainToDTOUtil.convertToPropertyDTO(enquiryDetail.Property, false);
	                enquiryDto.PrUnitType = DomainToDTOUtil.convertToMasterControlDTO(enquiryDetail.PrUnitType, false);
	                enquiryDto.EnquirySource = DomainToDTOUtil.convertToMasterControlDTO(enquiryDetail.EnquirySource, false);
	                enquiryDto.Budget = enquiryDetail.Budget;
	                enquiryDto.Lead = DomainToDTOUtil.convertToLeadDetailDTO(enquiryDetail.Lead, false, false);
	                enquiryDto.PrUnitSaleDetail = DomainToDTOUtil.convertToPrUnitSaleDetailDTO(enquiryDetail.PrUnitSaleDetail, false);
	                enquiryDto.Assignee = DomainToDTOUtil.convertToFirmMemberDTO(enquiryDetail.Assignee, false);
	                enquiryDto.FirmNumber = enquiryDetail.FirmNumber;
	                enquiryDto.Status = enquiryDetail.Status;
	                enquiryDto.Comments = enquiryDetail.Comments;
	                enquiryDto.EnquiryActivities = new HashSet<EnquiryActivityDTO>();
	                if (fetchActivities)
	                {
	                    if (enquiryDetail.EnquiryActivities != null && enquiryDetail.EnquiryActivities.Count > 0)
	                    {
	                        foreach (EnquiryActivity enquiryActivity in enquiryDetail.EnquiryActivities)
	                        {
	                            enquiryDto.EnquiryActivities.Add(DomainToDTOUtil.convertToEnquiryActivityDTO(enquiryActivity, true));
	                        }
	                    }
	                }
	                enquiryDto.InsertUser = enquiryDetail.InsertUser;
	                enquiryDto.UpdateUser = enquiryDetail.UpdateUser;
	                enquiryDto.InsertDate = enquiryDetail.InsertDate;
	                enquiryDto.UpdateDate = enquiryDetail.UpdateDate;
	                enquiryDto.Version = enquiryDetail.Version;
                }
            }
            return enquiryDto;
        }
        public static EnquiryActivityDTO convertToEnquiryActivityDTO(EnquiryActivity enquiryActivity, bool allFields)
        {
            EnquiryActivityDTO enquiryActivityDto = null;
            if (enquiryActivity != null)
            {
                enquiryActivityDto = new EnquiryActivityDTO();
                enquiryActivityDto.Id = enquiryActivity.Id;
                if (allFields)
                {
                    enquiryActivityDto.RecordType = enquiryActivity.RecordType;
                    enquiryActivityDto.ReminderMode = enquiryActivity.ReminderMode;
                    enquiryActivityDto.ActivityType = enquiryActivity.ActivityType;
                    enquiryActivityDto.DateLogged = enquiryActivity.DateLogged;
                    enquiryActivityDto.ScheduledDate = enquiryActivity.ScheduledDate;
                    enquiryActivityDto.Status = enquiryActivity.Status;
                    enquiryActivityDto.Comments = enquiryActivity.Comments;
                    enquiryActivityDto.RefNo = enquiryActivity.RefNo;
                    enquiryActivityDto.RevRefNo = enquiryActivity.RevRefNo;
                    enquiryActivityDto.FirmNumber = enquiryActivity.FirmNumber;
                    enquiryActivityDto.CommunicationMedia = DomainToDTOUtil.convertToMasterControlDTO(enquiryActivity.CommunicationMedia, false);
                    enquiryActivityDto.LoggedBy = DomainToDTOUtil.convertToFirmMemberDTO(enquiryActivity.LoggedBy, false);
                    enquiryActivityDto.InsertDate = enquiryActivity.InsertDate;
                    enquiryActivityDto.UpdateDate = enquiryActivity.UpdateDate;
                    enquiryActivityDto.Version = enquiryActivity.Version;
                    enquiryActivityDto.InsertUser = enquiryActivity.InsertUser;
                    enquiryActivityDto.UpdateUser = enquiryActivity.UpdateUser;
                    if (enquiryActivity.CallHistory != null)
                    {
                        enquiryActivityDto.CallHistoryDTO = convertToCallHistoryDTO(enquiryActivity.CallHistory, false);
                    }
                }
            }
            return enquiryActivityDto;
        }
        public static LeadDetailDTO convertToLeadDetailDTO(LeadDetail leadDetail, bool allFields, bool fetchActivities)
        {
            LeadDetailDTO leadDto = null;
            if (leadDetail != null)
            {
                leadDto = new LeadDetailDTO();
                leadDto.Id = leadDetail.Id;
                leadDto.LeadRefNo = leadDetail.LeadRefNo;
                if (allFields)
                {
                    leadDto.Salutation = DomainToDTOUtil.convertToMasterControlDTO(leadDetail.Salutation, false);
                    leadDto.FirstName = leadDetail.FirstName;
                    leadDto.MiddleName = leadDetail.MiddleName;
                    leadDto.LastName = leadDetail.LastName;
                    leadDto.ContactInfo = DomainToDTOUtil.convertToContactInfoDTO(leadDetail.ContactInfo);
                    leadDto.LeadDate = leadDetail.LeadDate;
                    leadDto.AssignedDate = leadDetail.AssignedDate;
                    leadDto.DateClosed = leadDetail.DateClosed;
                    leadDto.Property = DomainToDTOUtil.convertToPropertyDTO(leadDetail.Property, false);
                    leadDto.Source = DomainToDTOUtil.convertToMasterControlDTO(leadDetail.Source, false);
                    leadDto.Budget = leadDetail.Budget;
                    leadDto.Assignee = DomainToDTOUtil.convertToFirmMemberDTO(leadDetail.Assignee, false);
                    leadDto.FirmNumber = leadDetail.FirmNumber;
                    leadDto.Status = leadDetail.Status;
                    if (fetchActivities)
                    {
                        if (leadDetail.LeadActivities != null && leadDetail.LeadActivities.Count > 0)
                        {
                            leadDto.LeadActivities = new HashSet<LeadActivityDTO>();
                            foreach (LeadActivity leadActivity in leadDetail.LeadActivities)
                            {
                                leadDto.LeadActivities.Add(DomainToDTOUtil.convertToLeadActivityDTO(leadActivity, true));
                            }
                        }
                    }
                    leadDto.InsertUser = leadDetail.InsertUser;
                    leadDto.UpdateUser = leadDetail.UpdateUser;
                    leadDto.InsertDate = leadDetail.InsertDate;
                    leadDto.UpdateDate = leadDetail.UpdateDate;
                    leadDto.Version = leadDetail.Version;
                }
            }
            return leadDto;
        }
        public static LeadActivityDTO convertToLeadActivityDTO(LeadActivity leadActivity, bool allFields)
        {
            LeadActivityDTO leadActivityDto = null;
            if (leadActivity != null)
            {
                leadActivityDto = new LeadActivityDTO();
                leadActivityDto.Id = leadActivity.Id;
                if (allFields)
                {
                    leadActivityDto.RecordType = leadActivity.RecordType;
                    leadActivityDto.ActivityType = leadActivity.ActivityType;
                    leadActivityDto.ReminderMode = leadActivity.ReminderMode;
                    leadActivityDto.DateLogged = leadActivity.DateLogged;
                    leadActivityDto.ScheduledDate = leadActivity.ScheduledDate;
                    leadActivityDto.Status = leadActivity.Status;
                    leadActivityDto.Comments = leadActivity.Comments;
                    leadActivityDto.RefNo = leadActivity.RefNo;
                    leadActivityDto.RevRefNo = leadActivity.RevRefNo;
                    leadActivityDto.FirmNumber = leadActivity.FirmNumber;
                    leadActivityDto.CommunicationMedia = DomainToDTOUtil.convertToMasterControlDTO(leadActivity.CommunicationMedia, false);
                    leadActivityDto.LoggedBy = DomainToDTOUtil.convertToFirmMemberDTO(leadActivity.LoggedBy, false);
                    leadActivityDto.InsertDate = leadActivity.InsertDate;
                    leadActivityDto.UpdateDate = leadActivity.UpdateDate;
                    leadActivityDto.Version = leadActivity.Version;
                    leadActivityDto.InsertUser = leadActivity.InsertUser;
                    leadActivityDto.UpdateUser = leadActivity.UpdateUser;
                    if(leadActivity.CallHistory != null) {
                        leadActivityDto.CallHistoryDTO = convertToCallHistoryDTO(leadActivity.CallHistory, false);
                    }
                }
            }
            return leadActivityDto;
        }
        public static PropertyDTO convertToPropertyDTO(Property property, bool allFields)
        {
            PropertyDTO propertyDto = null;
            if (property != null)
            {
                propertyDto = new PropertyDTO();
                propertyDto.Id = property.Id;
                propertyDto.Name = property.Name;
                if (allFields)
                {
                    propertyDto.FirmAccount = DomainToDTOUtil.convertToFirmAccountDTO(property.FirmAccount, false);
                    propertyDto.ContactInfo = DomainToDTOUtil.convertToContactInfoDTO(property.ContactInfo);
                    propertyDto.PropertyType = DomainToDTOUtil.convertToMasterControlDTO(property.PropertyType, false);
                    propertyDto.PropertyLocation = DomainToDTOUtil.convertToMasterControlDTO(property.PropertyLocation, false);
                    propertyDto.ReraRegNo = property.ReraRegNo;
                    propertyDto.PropertyArea = property.PropertyArea;
                    propertyDto.Description = property.Description;
                    propertyDto.EstimatedAmt = property.EstimatedAmt;
                    propertyDto.FirmNumber = property.FirmNumber;
                    propertyDto.InsertDate = property.InsertDate;
                    propertyDto.UpdateDate = property.UpdateDate;
                    propertyDto.Version = property.Version;
                    propertyDto.InsertUser = property.InsertUser;
                    propertyDto.UpdateUser = property.UpdateUser;

                    propertyDto.PropertyTowers = new HashSet<PropertyTowerDTO>();
                    if (property.PropertyTowers != null && property.PropertyTowers.Count > 0)
                    {
                        foreach (PropertyTower propertyTower in property.PropertyTowers)
                        {
                            propertyDto.PropertyTowers.Add(DomainToDTOUtil.convertToPropertyTowerDTO(propertyTower, true));
                        }
                    }
                    propertyDto.PropertyTaxDetails = new HashSet<PropertyTaxDetailDTO>();
                    if (property.PropertyTaxDetails != null && property.PropertyTaxDetails.Count > 0)
                    {
                        foreach (PropertyTaxDetail propertyTaxDetail in property.PropertyTaxDetails)
                        {
                            propertyDto.PropertyTaxDetails.Add(DomainToDTOUtil.convertToPropertyTaxDetailDTO(propertyTaxDetail, true));
                        }
                    }
                    propertyDto.PropertyCharges = new HashSet<PropertyChargeDTO>();
                    if (property.PropertyCharges != null && property.PropertyCharges.Count > 0)
                    {
                        foreach (PropertyCharge propertyCharge in property.PropertyCharges)
                        {
                            propertyDto.PropertyCharges.Add(DomainToDTOUtil.convertToPropertyChargeDTO(propertyCharge, true));
                        }
                    }
                }
            }
            return propertyDto;
        }
        public static PropertyTowerDTO convertToPropertyTowerDTO(PropertyTower propertyTower, bool allFields)
        {
            PropertyTowerDTO propertyTowerDto = null;
            if (propertyTower != null)
            {
                propertyTowerDto = new PropertyTowerDTO();
                propertyTowerDto.Id = propertyTower.Id;
                propertyTowerDto.Name = propertyTower.Name;
                if (allFields)
                {
                    propertyTowerDto.Property = DomainToDTOUtil.convertToPropertyDTO(propertyTower.Property, false);
                    propertyTowerDto.Rate = propertyTower.Rate;
                    propertyTowerDto.LaunchDate = propertyTower.LaunchDate;
                    propertyTowerDto.Possession = propertyTower.Possession;
                    propertyTowerDto.Description = propertyTower.Description;
                    propertyTowerDto.FirmNumber = propertyTower.FirmNumber;
                    propertyTowerDto.InsertDate = propertyTower.InsertDate;
                    propertyTowerDto.UpdateDate = propertyTower.UpdateDate;
                    propertyTowerDto.Version = propertyTower.Version;
                    propertyTowerDto.InsertUser = propertyTower.InsertUser;
                    propertyTowerDto.UpdateUser = propertyTower.UpdateUser;
                }
            }
            return propertyTowerDto;
        }
        public static PropertyParkingDTO convertToPropertyParkingDTO(PropertyParking propertyParking, bool allFields)
        {
            PropertyParkingDTO propertyParkingDto = null;
            if (propertyParking != null)
            {
                propertyParkingDto = new PropertyParkingDTO();
                propertyParkingDto.Id = propertyParking.Id;
                propertyParkingDto.ParkingNo = propertyParking.ParkingNo;
                propertyParkingDto.ParkingType = DomainToDTOUtil.convertToMasterControlDTO(propertyParking.ParkingType, false);
                propertyParkingDto.Area = propertyParking.Area;
                if (allFields)
                {
                    propertyParkingDto.PropertyTower = DomainToDTOUtil.convertToPropertyTowerDTO(propertyParking.PropertyTower, false);
                    propertyParkingDto.CommonParking = propertyParking.CommonParking;
                    propertyParkingDto.Status = propertyParking.Status;
                    propertyParkingDto.FirmNumber = propertyParking.FirmNumber;
                    propertyParkingDto.InsertDate = propertyParking.InsertDate;
                    propertyParkingDto.UpdateDate = propertyParking.UpdateDate;
                    propertyParkingDto.Version = propertyParking.Version;
                    propertyParkingDto.InsertUser = propertyParking.InsertUser;
                    propertyParkingDto.UpdateUser = propertyParking.UpdateUser;
                }
            }
            return propertyParkingDto;
        }
        public static PropertyUnitDTO convertToPropertyUnitDTO(PropertyUnit propertyUnit, bool allFields)
        {
            PropertyUnitDTO propertyUnitDTO = null;
            if (propertyUnit != null)
            {
                propertyUnitDTO = new PropertyUnitDTO();
                propertyUnitDTO.Id = propertyUnit.Id;
                if (allFields)
                {
                    propertyUnitDTO.PropertyTower = DomainToDTOUtil.convertToPropertyTowerDTO(propertyUnit.PropertyTower, false);
                    propertyUnitDTO.UnitType = DomainToDTOUtil.convertToMasterControlDTO(propertyUnit.UnitType, false);
                    propertyUnitDTO.Wing = propertyUnit.Wing;
                    propertyUnitDTO.FloorNo = propertyUnit.FloorNo;
                    propertyUnitDTO.UnitNo = propertyUnit.UnitNo;
                    propertyUnitDTO.BuildupArea = propertyUnit.BuildupArea;
                    propertyUnitDTO.CarpetArea = propertyUnit.CarpetArea;
                    propertyUnitDTO.BalconyArea = propertyUnit.BalconyArea;
                    propertyUnitDTO.NoOfBalcony = propertyUnit.NoOfBalcony;
                    propertyUnitDTO.Facing = DomainToDTOUtil.convertToMasterControlDTO(propertyUnit.Facing, false);
                    propertyUnitDTO.Status = propertyUnit.Status;
                    propertyUnitDTO.Direction = DomainToDTOUtil.convertToMasterControlDTO(propertyUnit.Direction, false);
                    propertyUnitDTO.ReserveComments = propertyUnit.ReserveComments;
                    propertyUnitDTO.FirmNumber = propertyUnit.FirmNumber;
                    propertyUnitDTO.InsertDate = propertyUnit.InsertDate;
                    propertyUnitDTO.UpdateDate = propertyUnit.UpdateDate;
                    propertyUnitDTO.Version = propertyUnit.Version;
                    propertyUnitDTO.InsertUser = propertyUnit.InsertUser;
                    propertyUnitDTO.UpdateUser = propertyUnit.UpdateUser;
                }
            }
            return propertyUnitDTO;
        }
        public static PropertyScheduleDTO convertToPropertyScheduleDTO(PropertySchedule propertySchedule, bool allFields)
        {
            PropertyScheduleDTO propertyScheduleDto = null;
            if (propertySchedule != null)
            {
                propertyScheduleDto = new PropertyScheduleDTO();
                propertyScheduleDto.Id = propertySchedule.Id;
                propertyScheduleDto.StageNumber = propertySchedule.StageNumber;
                propertyScheduleDto.StageAbbr = propertySchedule.StageAbbr;
                propertyScheduleDto.Stage = propertySchedule.Stage;
                propertyScheduleDto.Percentage = propertySchedule.Percentage;
                if (allFields)
                {
                    propertyScheduleDto.PropertyTower = DomainToDTOUtil.convertToPropertyTowerDTO(propertySchedule.PropertyTower, false);
                    propertyScheduleDto.Status = propertySchedule.Status;
                    propertyScheduleDto.FirmNumber = propertySchedule.FirmNumber;
                    propertyScheduleDto.InsertDate = propertySchedule.InsertDate;
                    propertyScheduleDto.UpdateDate = propertySchedule.UpdateDate;
                    propertyScheduleDto.Version = propertySchedule.Version;
                    propertyScheduleDto.InsertUser = propertySchedule.InsertUser;
                    propertyScheduleDto.UpdateUser = propertySchedule.UpdateUser;
                }
            }
            return propertyScheduleDto;
        }

        public static PropertyChargeDTO convertToPropertyChargeDTO(PropertyCharge propertyCharge, bool allFields)
        {
            PropertyChargeDTO propertyChargeDTO = null;
            if (propertyCharge != null)
            {
                propertyChargeDTO = new PropertyChargeDTO();
                propertyChargeDTO.Id = propertyCharge.Id;
                if (allFields)
                {
                    propertyChargeDTO.Property = DomainToDTOUtil.convertToPropertyDTO(propertyCharge.Property, false);
                    propertyChargeDTO.ChargeType = DomainToDTOUtil.convertToMasterControlDTO(propertyCharge.ChargeType, false);
                    propertyChargeDTO.ChargeValue = propertyCharge.ChargeValue;
                    propertyChargeDTO.FirmNumber = propertyCharge.FirmNumber;
                    propertyChargeDTO.InsertDate = propertyCharge.InsertDate;
                    propertyChargeDTO.UpdateDate = propertyCharge.UpdateDate;
                    propertyChargeDTO.Version = propertyCharge.Version;
                    propertyChargeDTO.InsertUser = propertyCharge.InsertUser;
                    propertyChargeDTO.UpdateUser = propertyCharge.UpdateUser;
                }
            }
            return propertyChargeDTO;
        }


        public static PropertyTaxDetailDTO convertToPropertyTaxDetailDTO(PropertyTaxDetail propertyTaxDetail, bool allFields)
        {
            PropertyTaxDetailDTO propertyTaxDetailDto = null;
            if (propertyTaxDetail != null)
            {
                propertyTaxDetailDto = new PropertyTaxDetailDTO();
                propertyTaxDetailDto.Id = propertyTaxDetail.Id;
                if (allFields)
                {
                    propertyTaxDetailDto.Property = DomainToDTOUtil.convertToPropertyDTO(propertyTaxDetail.Property, false);
                    propertyTaxDetailDto.TaxType = DomainToDTOUtil.convertToMasterControlDTO(propertyTaxDetail.TaxType, false);
                    propertyTaxDetailDto.TaxPercentage = propertyTaxDetail.TaxPercentage;
                    propertyTaxDetailDto.IncludeInTotalPymt = propertyTaxDetail.IncludeInTotalPymt;
                    propertyTaxDetailDto.TaxAmtLimit = propertyTaxDetail.TaxAmtLimit;
                    propertyTaxDetailDto.FirmNumber = propertyTaxDetail.FirmNumber;
                    propertyTaxDetailDto.InsertDate = propertyTaxDetail.InsertDate;
                    propertyTaxDetailDto.UpdateDate = propertyTaxDetail.UpdateDate;
                    propertyTaxDetailDto.Version = propertyTaxDetail.Version;
                    propertyTaxDetailDto.InsertUser = propertyTaxDetail.InsertUser;
                    propertyTaxDetailDto.UpdateUser = propertyTaxDetail.UpdateUser;
                }
            }
            return propertyTaxDetailDto;
        }
        public static PrUnitSaleDetailDTO convertToPrUnitSaleDetailDTO(PrUnitSaleDetail prUnitSaleDetail, bool allFields)
        {
            PrUnitSaleDetailDTO prUnitSaleDetailDto = null;
            if (prUnitSaleDetail != null)
            {
                prUnitSaleDetailDto = new PrUnitSaleDetailDTO();
                prUnitSaleDetailDto.Id = prUnitSaleDetail.Id;
                prUnitSaleDetailDto.BookingRefNo = prUnitSaleDetail.BookingRefNo;
                prUnitSaleDetailDto.Status = prUnitSaleDetail.Status;
                if (allFields)
                {
                    prUnitSaleDetailDto.BookingDate = prUnitSaleDetail.BookingDate;
                    prUnitSaleDetailDto.SaleRate = prUnitSaleDetail.SaleRate;
                    prUnitSaleDetailDto.IsAgreementDone = prUnitSaleDetail.IsAgreementDone;
                    prUnitSaleDetailDto.AgreementDate = prUnitSaleDetail.AgreementDate;
                    prUnitSaleDetailDto.AgreementNo = prUnitSaleDetail.AgreementNo;
                    prUnitSaleDetailDto.IsPossessionDone = prUnitSaleDetail.IsPossessionDone;
                    prUnitSaleDetailDto.PossessionDate = prUnitSaleDetail.PossessionDate;
                    prUnitSaleDetailDto.LoanBankName = prUnitSaleDetail.LoanBankName;
                    prUnitSaleDetailDto.LoanBankBranch = prUnitSaleDetail.LoanBankBranch;
                    prUnitSaleDetailDto.LoanAmt = prUnitSaleDetail.LoanAmt;
                    prUnitSaleDetailDto.AgreementAmt = prUnitSaleDetail.AgreementAmt;
                    prUnitSaleDetailDto.TotalTaxAmt = prUnitSaleDetail.TotalTaxAmt;
                    prUnitSaleDetailDto.TotalOtherAmt = prUnitSaleDetail.TotalOtherAmt;
                    prUnitSaleDetailDto.TotalPymtAmt = prUnitSaleDetail.TotalPymtAmt;
                    prUnitSaleDetailDto.TotalCashAmt = prUnitSaleDetail.TotalCashAmt;
                    prUnitSaleDetailDto.TotalPackageCost = prUnitSaleDetail.TotalPackageCost;
                    prUnitSaleDetailDto.CanellationDate = prUnitSaleDetail.CanellationDate;
                    prUnitSaleDetailDto.CancellationFee = prUnitSaleDetail.CancellationFee;
                    prUnitSaleDetailDto.CancellationReason = prUnitSaleDetail.CancellationReason;
                    prUnitSaleDetailDto.FirmNumber = prUnitSaleDetail.FirmNumber;
                    prUnitSaleDetailDto.InsertDate = prUnitSaleDetail.InsertDate;
                    prUnitSaleDetailDto.UpdateDate = prUnitSaleDetail.UpdateDate;
                    prUnitSaleDetailDto.Version = prUnitSaleDetail.Version;
                    prUnitSaleDetailDto.InsertUser = prUnitSaleDetail.InsertUser;
                    prUnitSaleDetailDto.UpdateUser = prUnitSaleDetail.UpdateUser;
                    prUnitSaleDetailDto.PropertyUnit = DomainToDTOUtil.convertToPropertyUnitDTO(prUnitSaleDetail.PropertyUnit, false);
                    prUnitSaleDetailDto.Customer = DomainToDTOUtil.convertToCustomerDTO(prUnitSaleDetail.Customer, false);
                    prUnitSaleDetailDto.Enquiry = DomainToDTOUtil.convertToEnquiryDetailDTO(prUnitSaleDetail.Enquiry, false, false);
                    prUnitSaleDetailDto.FirmMember = DomainToDTOUtil.convertToFirmMemberDTO(prUnitSaleDetail.FirmMember, false);
                    prUnitSaleDetailDto.CancellationFirmMember = DomainToDTOUtil.convertToFirmMemberDTO(prUnitSaleDetail.CancellationFirmMember, false);
                    prUnitSaleDetailDto.PrUnitSalePymts = new HashSet<PrUnitSalePymtDTO>();
                    if (prUnitSaleDetail.PrUnitSalePymts != null && prUnitSaleDetail.PrUnitSalePymts.Count > 0)
                    {
                        foreach (PrUnitSalePymt prUnitSalePymt in prUnitSaleDetail.PrUnitSalePymts)
                        {
                            prUnitSaleDetailDto.PrUnitSalePymts.Add(DomainToDTOUtil.convertToPrUnitSalePymtDTO(prUnitSalePymt, true));
                        }
                    }
                    prUnitSaleDetailDto.PrUnitSaleTaxDetails = new HashSet<PrUnitSaleTaxDetailDTO>();
                    if (prUnitSaleDetail.PrUnitSaleTaxDetails != null && prUnitSaleDetail.PrUnitSaleTaxDetails.Count > 0)
                    {
                        foreach (PrUnitSaleTaxDetail prUnitSaleTaxDetail in prUnitSaleDetail.PrUnitSaleTaxDetails)
                        {
                            prUnitSaleDetailDto.PrUnitSaleTaxDetails.Add(DomainToDTOUtil.convertToPrUnitSaleTaxDetailDTO(prUnitSaleTaxDetail, true));
                        }
                    }
                    prUnitSaleDetailDto.PrParkings = new HashSet<PropertyParkingDTO>();
                    if (prUnitSaleDetail.PrUnitParkings != null && prUnitSaleDetail.PrUnitParkings.Count > 0)
                    {
                        foreach (PropertyParking propertyParking in prUnitSaleDetail.PrUnitParkings)
                        {
                            prUnitSaleDetailDto.PrParkings.Add(DomainToDTOUtil.convertToPropertyParkingDTO(propertyParking, false));
                        }
                    }
                    prUnitSaleDetailDto.CoCustomers = new HashSet<CoCustomerDTO>();
                    if (prUnitSaleDetail.CoCustomers != null && prUnitSaleDetail.CoCustomers.Count > 0)
                    {
                        foreach (CoCustomer coCustomer in prUnitSaleDetail.CoCustomers)
                        {
                            prUnitSaleDetailDto.CoCustomers.Add(DomainToDTOUtil.convertToCocustomerDTO(coCustomer, true));
                        }
                    }
                }
            }
            return prUnitSaleDetailDto;
        }
        public static DemandLetterHistoryDTO convertToDemandLetterHistoryDTO(DemandLetterHistory demandLetterHistory, bool allFields)
        {
        	DemandLetterHistoryDTO demandLetterHistoryDto = null;
        	if (demandLetterHistory != null)
        	{
        		demandLetterHistoryDto = new DemandLetterHistoryDTO();
        		demandLetterHistoryDto.Id = demandLetterHistory.Id;
        		if (allFields)
        		{
        			demandLetterHistoryDto.UploadDate = demandLetterHistory.UploadDate;
        			demandLetterHistoryDto.DeliveryDate = demandLetterHistory.DeliveryDate;
        			demandLetterHistoryDto.FileName = demandLetterHistory.FileName;
        			demandLetterHistoryDto.DocumentPath = demandLetterHistory.DocumentPath;       			
        			
        			demandLetterHistoryDto.PrUnitSaleDetail = DomainToDTOUtil.convertToPrUnitSaleDetailDTO(demandLetterHistory.PrUnitSaleDetail, false);
        			demandLetterHistoryDto.UploadBy = DomainToDTOUtil.convertToFirmMemberDTO(demandLetterHistory.UploadBy, false);
                    demandLetterHistoryDto.UploadBy.FullName = CommonUIConverter.getCustomerFullName(demandLetterHistoryDto.UploadBy.FirstName,
                            demandLetterHistoryDto.UploadBy.LastName);
        			demandLetterHistoryDto.Stage = DomainToDTOUtil.convertToPropertyScheduleDTO(demandLetterHistory.Stage, false);
        			demandLetterHistoryDto.FirmNumber = demandLetterHistory.FirmNumber;
        			demandLetterHistoryDto.InsertDate = demandLetterHistory.InsertDate;
        			demandLetterHistoryDto.UpdateDate = demandLetterHistory.UpdateDate;
        			demandLetterHistoryDto.Version = demandLetterHistory.Version;
        			demandLetterHistoryDto.InsertUser = demandLetterHistory.InsertUser;
        			demandLetterHistoryDto.UpdateUser = demandLetterHistory.UpdateUser;
        		}
        	}
        	return demandLetterHistoryDto;
        }
        public static PrUnitSaleTaxDetailDTO convertToPrUnitSaleTaxDetailDTO(PrUnitSaleTaxDetail propertyTaxDetail, bool allFields)
        {
            PrUnitSaleTaxDetailDTO propertyTaxDetailDto = null;
            if (propertyTaxDetail != null)
            {
                propertyTaxDetailDto = new PrUnitSaleTaxDetailDTO();
                propertyTaxDetailDto.Id = propertyTaxDetail.Id;
                if (allFields)
                {
                    propertyTaxDetailDto.PrUnitSaleDetail = DomainToDTOUtil.convertToPrUnitSaleDetailDTO(propertyTaxDetail.PrUnitSaleDetail, false);
                    propertyTaxDetailDto.TaxType = DomainToDTOUtil.convertToMasterControlDTO(propertyTaxDetail.TaxType, false);
                    propertyTaxDetailDto.TaxPercentage = propertyTaxDetail.TaxPercentage;
                    propertyTaxDetailDto.IncludeInTotalPymt = propertyTaxDetail.IncludeInTotalPymt;
                    propertyTaxDetailDto.TaxAmtLimit = propertyTaxDetail.TaxAmtLimit;
                    propertyTaxDetailDto.TaxAmt = propertyTaxDetail.TaxAmt;
                    propertyTaxDetailDto.FirmNumber = propertyTaxDetail.FirmNumber;
                    propertyTaxDetailDto.InsertDate = propertyTaxDetail.InsertDate;
                    propertyTaxDetailDto.UpdateDate = propertyTaxDetail.UpdateDate;
                    propertyTaxDetailDto.Version = propertyTaxDetail.Version;
                    propertyTaxDetailDto.InsertUser = propertyTaxDetail.InsertUser;
                    propertyTaxDetailDto.UpdateUser = propertyTaxDetail.UpdateUser;
                }
            }
            return propertyTaxDetailDto;
        }

        public static PrUnitSalePymtDTO convertToPrUnitSalePymtDTO(PrUnitSalePymt prUnitSalePymt, bool allFields)
        {
            PrUnitSalePymtDTO prUnitSalePymtDto = null;
            if (prUnitSalePymt != null)
            {
                prUnitSalePymtDto = new PrUnitSalePymtDTO();
                prUnitSalePymtDto.Id = prUnitSalePymt.Id;
                if (allFields)
                {
                    prUnitSalePymtDto.PrUnitSaleDetail = DomainToDTOUtil.convertToPrUnitSaleDetailDTO(prUnitSalePymt.PrUnitSaleDetail, false);
                    prUnitSalePymtDto.PaymentMaster = DomainToDTOUtil.convertToPaymentMasterDTO(prUnitSalePymt.PaymentMaster, true, false);
                    prUnitSalePymtDto.PymtType = DomainToDTOUtil.convertToMasterControlDTO(prUnitSalePymt.PymtType, false);
                    prUnitSalePymtDto.PymtDate = prUnitSalePymt.PymtDate;
                    prUnitSalePymtDto.PymtAmt = prUnitSalePymt.PymtAmt;
                    prUnitSalePymtDto.PymtMode = prUnitSalePymt.PymtMode;
                    prUnitSalePymtDto.Description = prUnitSalePymt.Description;
                    prUnitSalePymtDto.FirmNumber = prUnitSalePymt.FirmNumber;
                    prUnitSalePymtDto.InsertDate = prUnitSalePymt.InsertDate;
                    prUnitSalePymtDto.UpdateDate = prUnitSalePymt.UpdateDate;
                    prUnitSalePymtDto.Version = prUnitSalePymt.Version;
                    prUnitSalePymtDto.InsertUser = prUnitSalePymt.InsertUser;
                    prUnitSalePymtDto.UpdateUser = prUnitSalePymt.UpdateUser;
                }
            }
            return prUnitSalePymtDto;
        }
        public static PaymentMasterDTO convertToPaymentMasterDTO(PaymentMaster paymentMaster, bool allFields, bool fetchTransactions)
        {
            PaymentMasterDTO paymentMasterDto = null;
            if (paymentMaster != null)
            {
                paymentMasterDto = new PaymentMasterDTO();
                paymentMasterDto.Id = paymentMaster.Id;
                if (allFields)
                {
                    paymentMasterDto.TotalAmt = paymentMaster.TotalAmt;
                    paymentMasterDto.TotalPaid = paymentMaster.TotalPaid;
                    paymentMasterDto.TotalPending = paymentMaster.TotalPending;
                    paymentMasterDto.TotalPdcAmt = paymentMaster.TotalPdcAmt;
                    paymentMasterDto.Status = paymentMaster.Status;
                    paymentMasterDto.FirmNumber = paymentMaster.FirmNumber;
                    paymentMasterDto.InsertDate = paymentMaster.InsertDate;
                    paymentMasterDto.UpdateDate = paymentMaster.UpdateDate;
                    paymentMasterDto.Version = paymentMaster.Version;
                    paymentMasterDto.InsertUser = paymentMaster.InsertUser;
                    paymentMasterDto.UpdateUser = paymentMaster.UpdateUser;
                    paymentMasterDto.PaymentTransactions = new HashSet<PaymentTransactionDTO>();
                    if (fetchTransactions)
                    {
                        if (paymentMaster.PaymentTransactions != null && paymentMaster.PaymentTransactions.Count > 0)
                        {
                            foreach (PaymentTransaction paymentTransaction in paymentMaster.PaymentTransactions)
                            {
                                paymentMasterDto.PaymentTransactions.Add(DomainToDTOUtil.convertToPaymentTransactionDTO(paymentTransaction, true));
                            }
                        }
                    }
                }
            }
            return paymentMasterDto;
        }
        public static MasterPymtTransactionDTO convertToMPTDTO(MasterPymtTransaction mpt, bool allFields)
        {
            MasterPymtTransactionDTO mptDto = null;
            if (mpt != null)
            {
                mptDto = new MasterPymtTransactionDTO();
                mptDto.Id = mpt.Id;
                if (allFields)
                {
                    mptDto.MPTBook = DomainToDTOUtil.convertToMPTBookDTO(mpt.MPTBook);
                    mptDto.PymtMode = mpt.PymtMode;
                    mptDto.TxRefNo = mpt.TxRefNo;
                    mptDto.PymtMethod = mpt.PymtMethod;
                    mptDto.TxDate = mpt.TxDate;
                    mptDto.PymtAmt = mpt.PymtAmt;
                    mptDto.CollectionDate = mpt.CollectionDate;
                    mptDto.ClearanceDate = mpt.ClearanceDate;
                    mptDto.ChequeDate = mpt.ChequeDate;
                    mptDto.PayName = mpt.PayName;
                    mptDto.BankName = mpt.BankName;
                    mptDto.Branch = mpt.Branch;
                    mptDto.MediaNo = mpt.MediaNo;
                    mptDto.ChequeStatus = mpt.ChequeStatus;
                    mptDto.Comments = mpt.Comments;
                    mptDto.PymtStatus = mpt.PymtStatus;
                    mptDto.RcptDelivered = mpt.RcptDelivered;
                    mptDto.RcptDeliveryDate = mpt.RcptDeliveryDate;
                    mptDto.RcptDocPath = mpt.RcptDocPath;
                    mptDto.Property = DomainToDTOUtil.convertToPropertyDTO(mpt.Property, false);
                    mptDto.FirmNumber = mpt.FirmNumber;
                    mptDto.InsertDate = mpt.InsertDate;
                    mptDto.UpdateDate = mpt.UpdateDate;
                    mptDto.Version = mpt.Version;
                    mptDto.InsertUser = mpt.InsertUser;
                    mptDto.UpdateUser = mpt.UpdateUser;
                    mptDto.PaymentTransactions = new HashSet<PaymentTransactionDTO>();
                    if (mpt.PaymentTransactions != null && mpt.PaymentTransactions.Count > 0)
                    {
                        foreach (PaymentTransaction paymentTransaction in mpt.PaymentTransactions)
                        {
                            mptDto.PaymentTransactions.Add(DomainToDTOUtil.convertToPaymentTransactionDTO(paymentTransaction, true));
                        }
                    }
                }
            }
            return mptDto;
        }
        public static MPTBookDTO convertToMPTBookDTO(MPTBook mptBook)
        {
            MPTBookDTO mptBookDto = null;
            if (mptBook != null)
            {
                mptBookDto = new MPTBookDTO();
                mptBookDto.Id = mptBook.Id;
            }
            return mptBookDto;
        }
        public static PaymentTransactionDTO convertToPaymentTransactionDTO(PaymentTransaction paymentTransaction, bool allFields)
        {
            PaymentTransactionDTO paymentTransactionDto = null;
            if (paymentTransaction != null)
            {
                paymentTransactionDto = new PaymentTransactionDTO();
                paymentTransactionDto.Id = paymentTransaction.Id;
                if (allFields)
                {
                    paymentTransactionDto.TxDate = paymentTransaction.TxDate;
                    paymentTransactionDto.Amount = paymentTransaction.Amount;
                    paymentTransactionDto.Status = paymentTransaction.Status;
                    paymentTransactionDto.InvoiceNumber = paymentTransaction.InvoiceNumber;
                    paymentTransactionDto.Comments = paymentTransaction.Comments;
                    paymentTransactionDto.FirmNumber = paymentTransaction.FirmNumber;
                    paymentTransactionDto.InsertDate = paymentTransaction.InsertDate;
                    paymentTransactionDto.UpdateDate = paymentTransaction.UpdateDate;
                    paymentTransactionDto.Version = paymentTransaction.Version;
                    paymentTransactionDto.InsertUser = paymentTransaction.InsertUser;
                    paymentTransactionDto.UpdateUser = paymentTransaction.UpdateUser;
                    paymentTransactionDto.FirmAccount = DomainToDTOUtil.convertToFirmAccountDTO(paymentTransaction.FirmAccount, false);
                    paymentTransactionDto.PaymentMaster = DomainToDTOUtil.convertToPaymentMasterDTO(paymentTransaction.PaymentMaster, false, false);
                    paymentTransactionDto.AccountTransaction = DomainToDTOUtil.convertToAccountTransactionDTO(paymentTransaction.AccountTransaction, false);
                    paymentTransactionDto.PaymentVoucherDTO = DomainToDTOUtil.convertToPaymentVoucherDTO(paymentTransaction.PaymentVoucher, false);
                    paymentTransactionDto.MasterPymtTransaction = DomainToDTOUtil.convertToMPTDTO(paymentTransaction.MasterPymtTransaction, false);
                }
            }
            return paymentTransactionDto;
        }
        public static AccountTransactionDTO convertToAccountTransactionDTO(AccountTransaction accountTransaction, bool allFields)
        {
            AccountTransactionDTO accountTransactionDto = null;
            if (accountTransaction != null)
            {
                accountTransactionDto = new AccountTransactionDTO();
                accountTransactionDto.Id = accountTransaction.Id;
                accountTransactionDto.FirmAccount = DomainToDTOUtil.convertToFirmAccountDTO(accountTransaction.FirmAccount, false);
                accountTransactionDto.TxType = accountTransaction.TxType;//Required always populated, Ref->Pdc
                accountTransactionDto.Comments = accountTransaction.Comments;//Required always populated, Ref->Pdc account reverse tx comments
                if (allFields)
                {
                    accountTransactionDto.TxDate = accountTransaction.TxDate;
                    accountTransactionDto.Amount = accountTransaction.Amount;
                    accountTransactionDto.FirmNumber = accountTransaction.FirmNumber;
                    accountTransactionDto.InsertDate = accountTransaction.InsertDate;
                    accountTransactionDto.UpdateDate = accountTransaction.UpdateDate;
                    accountTransactionDto.Version = accountTransaction.Version;
                    accountTransactionDto.InsertUser = accountTransaction.InsertUser;
                    accountTransactionDto.UpdateUser = accountTransaction.UpdateUser;
                }
            }
            return accountTransactionDto;
        }
        public static FirmMemberDTO convertToFirmMemberDTO(FirmMember firmMember, bool allFields)
        {
            FirmMemberDTO firmMemberDto = null;
            if (firmMember != null)
            {
                firmMemberDto = new FirmMemberDTO();
                firmMemberDto.Id = firmMember.Id;
                firmMemberDto.Salutation = DomainToDTOUtil.convertToMasterControlDTO(firmMember.Salutation, false);
                firmMemberDto.FirstName = firmMember.FirstName;
                firmMemberDto.MiddleName = firmMember.MiddleName;
                firmMemberDto.LastName = firmMember.LastName;
                if (allFields)
                {
                    firmMemberDto.JoiningDate = firmMember.JoiningDate;
                    firmMemberDto.Qualification = firmMember.Qualification;
                    firmMemberDto.Description = firmMember.Description;
                    firmMemberDto.FirmNumber = firmMember.FirmNumber;
                    firmMemberDto.ContactInfo = DomainToDTOUtil.convertToContactInfoDTO(firmMember.ContactInfo);
                    firmMemberDto.UserDefinition = DomainToDTOUtil.convertToUserDefinitionDTO(firmMember.User);
                    firmMemberDto.InsertDate = firmMember.InsertDate;
                    firmMemberDto.UpdateDate = firmMember.UpdateDate;
                    firmMemberDto.Version = firmMember.Version;
                    firmMemberDto.InsertUser = firmMember.InsertUser;
                    firmMemberDto.UpdateUser = firmMember.UpdateUser;
                }
            }
            return firmMemberDto;
        }
        public static PropertyFundsDTO convertToPropertyFundDTO(PropertyFunds propertyFunds, bool allFields)
        {
            PropertyFundsDTO propertyFundsDTO = null;
            if (propertyFunds != null)
            {
                propertyFundsDTO = new PropertyFundsDTO();
                propertyFundsDTO.Id = propertyFunds.Id;
                if (allFields)
                {
                    propertyFundsDTO.TxDate = propertyFunds.TxDate;
                    propertyFundsDTO.Amount = propertyFunds.Amount;
                    propertyFundsDTO.PymtMethod = propertyFunds.PymtMethod;
                    propertyFundsDTO.BankName = propertyFunds.BankName;
                    propertyFundsDTO.Branch = propertyFunds.Branch;
                    propertyFundsDTO.MediaNo = propertyFunds.MediaNo;
                    propertyFundsDTO.ChequeDate = propertyFunds.ChequeDate;
                    propertyFundsDTO.Comments = propertyFunds.Comments;
                    propertyFundsDTO.PayName = propertyFunds.PayName;
                    propertyFundsDTO.Status = propertyFunds.PymtStatus;
                    propertyFundsDTO.FirmNumber = propertyFunds.FirmNumber;
                    propertyFundsDTO.InsertDate = propertyFunds.InsertDate;
                    propertyFundsDTO.UpdateDate = propertyFunds.UpdateDate;
                    propertyFundsDTO.Version = propertyFunds.Version;
                    propertyFundsDTO.InsertUser = propertyFunds.InsertUser;
                    propertyFundsDTO.UpdateUser = propertyFunds.UpdateUser;
                    propertyFundsDTO.FirmAccount = DomainToDTOUtil.convertToFirmAccountDTO(propertyFunds.FirmAccount, false);
                    propertyFundsDTO.Property = DomainToDTOUtil.convertToPropertyDTO(propertyFunds.Property, false);
                    //TODO - Load Transaction
                }
            }
            return propertyFundsDTO;
        }
        public static MasterControlDataDTO convertToMasterControlDTO(MasterControlData masterControlData, bool allFields)
        {
            //Populate only basic fields, if allFields is true then only copy all fields.
            MasterControlDataDTO masterControlDataDto = null;
            if (masterControlData != null)
            {
                masterControlDataDto = new MasterControlDataDTO();
                masterControlDataDto.Id = masterControlData.Id;
                masterControlDataDto.Name = masterControlData.Name;
                if (allFields)
                {
                    masterControlDataDto.Type = masterControlData.Type;
                    masterControlDataDto.Description = masterControlData.Description;
                    masterControlDataDto.SystemDefined = masterControlData.SystemDefined;
                    masterControlDataDto.UpdateDate = masterControlData.UpdateDate;
                    masterControlDataDto.Version = masterControlData.Version;
                    masterControlDataDto.InsertUser = masterControlData.InsertUser;
                    masterControlDataDto.UpdateUser = masterControlData.UpdateUser;
                }
            }
            return masterControlDataDto;
        }
        public static CountryDTO convertToCountryDTO(Country country, bool allFields)
        {
            //Populate only basic fields, if allFields is true then only copy all fields.
            CountryDTO countryDto = null;
            if (country != null)
            {
                countryDto = new CountryDTO();
                countryDto.Id = country.Id;
                countryDto.Name = country.Name;
                countryDto.Abbreviation = country.Abbreviation;
            }
            return countryDto;
        }
        public static StateDTO convertToStateDTO(State state, bool allFields)
        {
            //Populate only basic fields, if allFields is true then only copy all fields.
            StateDTO stateDto = null;
            if (state != null)
            {
                stateDto = new StateDTO();
                stateDto.Id = state.Id;
                stateDto.Name = state.Name;
                stateDto.Abbreviation = state.Abbreviation;
            }
            return stateDto;
        }
        public static CityDTO convertToCityDTO(City city, bool allFields)
        {
            //Populate only basic fields, if allFields is true then only copy all fields.
            CityDTO cityDto = null;
            if (city != null)
            {
                cityDto = new CityDTO();
                cityDto.Id = city.Id;
                cityDto.Name = city.Name;
                cityDto.Abbreviation = city.Abbreviation;
            }
            return cityDto;
        }
        //Customer
        public static CustomerDTO convertToCustomerDTO(Customer customer, bool allFields)
        {
            CustomerDTO customerDto = null;
            if (customer != null)
            {
                customerDto = new CustomerDTO();
                customerDto.Id = customer.Id;
                customerDto.CustRefNo = customer.CustRefNo;
                customerDto.Salutation = DomainToDTOUtil.convertToMasterControlDTO(customer.Salutation, false);
                customerDto.FirstName = customer.FirstName;
                customerDto.MiddleName = customer.MiddleName;
                customerDto.LastName = customer.LastName;
                if (allFields)
                {
                	customerDto.FamilyRelationship = customer.FamilyRelationship;
                	customerDto.FamilyRelName = customer.FamilyRelName;
                    customerDto.Pan = customer.Pan;
                    customerDto.PassportNo = customer.PassportNo;
                    customerDto.AadharNo = customer.AadharNo;
                    customerDto.Fax = customer.Fax;
                    customerDto.Groupname = customer.Groupname;
                    customerDto.Taxclassification = customer.Taxclassification;
                    customerDto.Taxtype = customer.Taxtype;
                    customerDto.Billwise = customer.Billwise;
                    customerDto.Currency = customer.Currency;
                    customerDto.Tallystatus = customer.Tallystatus;
                    customerDto.Occupation = DomainToDTOUtil.convertToMasterControlDTO(customer.Occupation, false);
                    customerDto.Nationality = DomainToDTOUtil.convertToCountryDTO(customer.Nationality, false);
                    customerDto.ResidentialStatus = DomainToDTOUtil.convertToMasterControlDTO(customer.ResidentialStatus, false);
                    customerDto.ContactInfo = DomainToDTOUtil.convertToContactInfoDTO(customer.ContactInfo);
                    customerDto.FirmNumber = customer.FirmNumber;
                    customerDto.InsertDate = customer.InsertDate;
                    customerDto.UpdateDate = customer.UpdateDate;
                    customerDto.Version = customer.Version;
                    customerDto.InsertUser = customer.InsertUser;
                    customerDto.UpdateUser = customer.UpdateUser;
                }
            }
            return customerDto;
        }

        public static CoCustomerDTO convertToCocustomerDTO(CoCustomer cocustomer, bool allFields)
        {
            CoCustomerDTO coCustomerDto = null;
            if (cocustomer != null)
            {
                coCustomerDto = new CoCustomerDTO();
                coCustomerDto.Id = cocustomer.Id;
                if (allFields)
                {
                    coCustomerDto.SalutationId = DomainToDTOUtil.convertToMasterControlDTO(cocustomer.SalutationId, false);
                    coCustomerDto.FirstName = cocustomer.FirstName;
                    coCustomerDto.MiddleName = cocustomer.MiddleName;
                    coCustomerDto.LastName = cocustomer.LastName;
                    coCustomerDto.RelationWhPrimCust = DomainToDTOUtil.convertToMasterControlDTO(cocustomer.RelationWhPrimCust, false);
                    coCustomerDto.Occupation = DomainToDTOUtil.convertToMasterControlDTO(cocustomer.Occupation, false);
                    coCustomerDto.Pan = cocustomer.Pan;
                    coCustomerDto.IsPoa = cocustomer.IsPoa;
                    coCustomerDto.FirmNumber = cocustomer.FirmNumber;
                    coCustomerDto.ContactInfo = DomainToDTOUtil.convertToContactInfoDTO(cocustomer.ContactInfo);
                }
            }
            return coCustomerDto;
        }
        public static AgencyDTO convertToAgencyDTO(Agency agency, bool allFields)
        {
            AgencyDTO agencyDTO = null;
            if (agency != null)
            {
                agencyDTO = new AgencyDTO();
                agencyDTO.Id = agency.Id;
                agencyDTO.AgencyName = agency.AgencyName;
                if (allFields)
                {
                    agencyDTO.RegistrationNo = agency.RegistrationNo;
                    agencyDTO.Description = agency.Description;
                    agencyDTO.ContactInfo = DomainToDTOUtil.convertToContactInfoDTO(agency.ContactInfo);
                    agencyDTO.OwnerName = agency.OwnerName;
                    agencyDTO.AgencyType = DomainToDTOUtil.convertToMasterControlDTO(agency.AgencyType,false);
                    agencyDTO.AgencyName = agency.AgencyName;
                    agencyDTO.Pan = agency.Pan;
                    agencyDTO.Salestaxnumber = agency.Salestaxnumber;
                    agencyDTO.Centralsalestaxnumber = agency.Centralsalestaxnumber;
                    agencyDTO.Groupname = agency.Groupname;
                    agencyDTO.Taxclassification = agency.Taxclassification;
                    agencyDTO.Taxtype = agency.Taxtype;
                    agencyDTO.Billwise = agency.Billwise;
                    agencyDTO.Currency = agency.Currency;
                    agencyDTO.Tallystatus = agency.Tallystatus;
                    agencyDTO.FirmNumber = agency.FirmNumber;
                    agencyDTO.InsertDate = agency.InsertDate;
                    agencyDTO.UpdateDate = agency.UpdateDate;
                    agencyDTO.Version = agency.Version;
                    agencyDTO.InsertUser = agency.InsertUser;
                    agencyDTO.UpdateUser = agency.UpdateUser;
                }
            }
            return agencyDTO;
        }
        public static PropertyExpenseDTO convertToPropertyExpenseDTO(PropertyExpense propertyExpense, bool allFields)
        {
            PropertyExpenseDTO propertyExpenseDTO = null;
            if (propertyExpense != null)
            {
                propertyExpenseDTO = new PropertyExpenseDTO();
                propertyExpenseDTO.Id = propertyExpense.Id;
                if (allFields)
                {
                    propertyExpenseDTO.Property = DomainToDTOUtil.convertToPropertyDTO(propertyExpense.Property, false);
                    propertyExpenseDTO.Agency = DomainToDTOUtil.convertToAgencyDTO(propertyExpense.Agency, false);
                    propertyExpenseDTO.ExpenseDate = propertyExpense.ExpenseDate;
                    propertyExpenseDTO.ExpenseType = DomainToDTOUtil.convertToMasterControlDTO(propertyExpense.ExpenseType, false);
                    propertyExpenseDTO.FirmMember = DomainToDTOUtil.convertToFirmMemberDTO(propertyExpense.FirmMember, false);
                    propertyExpenseDTO.Amount = propertyExpense.Amount;
                    propertyExpenseDTO.Comments = propertyExpense.Comments;
                    propertyExpenseDTO.PaymentMaster = DomainToDTOUtil.convertToPaymentMasterDTO(propertyExpense.PaymentMaster, true, true);
                    propertyExpenseDTO.FirmNumber = propertyExpense.FirmNumber;
                    propertyExpenseDTO.InsertDate = propertyExpense.InsertDate;
                    propertyExpenseDTO.UpdateDate = propertyExpense.UpdateDate;
                    propertyExpenseDTO.Version = propertyExpense.Version;
                    propertyExpenseDTO.InsertUser = propertyExpense.InsertUser;
                    propertyExpenseDTO.UpdateUser = propertyExpense.UpdateUser;
                }
            }
            return propertyExpenseDTO;
        }
        public static ReportConfigDTO convertToReportConfigDTO(ReportConfig reportConfig)
        {
            ReportConfigDTO reportConfigDTO = null;
            if (reportConfig != null)
            {
                reportConfigDTO = new ReportConfigDTO();
                reportConfigDTO.Id = reportConfig.Id;
                reportConfigDTO.ReportName = reportConfig.ReportName;
                reportConfigDTO.ReportPath = reportConfig.ReportPath;
                reportConfigDTO.ReportDecription = reportConfig.ReportDecription;
                reportConfigDTO.FirmNumber = reportConfig.FirmNumber;
                reportConfigDTO.InsertDate = reportConfig.InsertDate;
                reportConfigDTO.InsertUser = reportConfig.InsertUser;
                reportConfigDTO.UpdateUser = reportConfig.UpdateUser;
                reportConfigDTO.UpdateDate = reportConfig.UpdateDate;
                reportConfigDTO.Version = reportConfig.Version;
            }
            return reportConfigDTO;
        }
        public static UserRoleDTO convertToUserRoleDTO(UserRole userRole)
        {
            UserRoleDTO userRoleDTO = new UserRoleDTO();
            userRoleDTO.Id = userRole.Id;
            userRoleDTO.Name = userRole.Name;
            userRoleDTO.Description = userRole.Description;
            return userRoleDTO;
        }
        public static UserDefinitionDTO convertToUserDefinitionDTO(UserDefinition userDefinition)
        {

            UserDefinitionDTO userDefinitionDTO = null;
            if (userDefinition != null)
            {
                userDefinitionDTO = new UserDefinitionDTO();
                userDefinitionDTO.Id = userDefinition.Id;
                userDefinitionDTO.Username = userDefinition.Username;
                userDefinitionDTO.Password = userDefinition.Password;
                userDefinitionDTO.UserRole = DomainToDTOUtil.convertToUserRoleDTO(userDefinition.UserRole);
                userDefinitionDTO.SecurityQuestion = new SecurityQuestionDTO();
                userDefinitionDTO.SecurityQuestion.Id = userDefinition.SecurityQuestion.Id;
                userDefinitionDTO.SecurityQuestion.Question = userDefinition.SecurityQuestion.Question;
                userDefinitionDTO.SecurityAnswer = userDefinition.SecurityAnswer;
                userDefinitionDTO.ActivationDate = userDefinition.ActivationDate;
                userDefinitionDTO.ExpirationDate = userDefinition.ExpirationDate;
                userDefinitionDTO.Status = userDefinition.Status;
                userDefinitionDTO.ProfileImg = userDefinition.ProfileImg;
                userDefinitionDTO.FirmMember = DomainToDTOUtil.convertToFirmMemberDTO(userDefinition.FirmMember, false);
                userDefinitionDTO.FirmNumber = userDefinition.FirmNumber;
                userDefinitionDTO.InsertDate = userDefinition.InsertDate;
                userDefinitionDTO.UpdateDate = userDefinition.UpdateDate;
                userDefinitionDTO.Version = userDefinition.Version;
                userDefinitionDTO.InsertUser = userDefinition.InsertUser;
                userDefinitionDTO.UpdateUser = userDefinition.UpdateUser;
            }
            return userDefinitionDTO;
        }
        public static NotificationDTO convertToNotificationDTO(Notification notification, bool allFields)
        {
        	//Populate only basic fields, if allFields is true then only copy all fields.
        	NotificationDTO notificationDTO = null;
        	if (notification != null)
        	{
        		notificationDTO = new NotificationDTO();
        		notificationDTO.Id = notification.Id;
        		if (allFields)
        		{
        			notificationDTO.Type = notification.Type;
        			notificationDTO.SubType = notification.SubType;
        			notificationDTO.Message = notification.Message;
                    notificationDTO.RefEntityInfo = notification.RefEntityInfo;
        			notificationDTO.ScheduledDate = notification.ScheduledDate;
        			notificationDTO.PropertyId = notification.PropertyId;
        			notificationDTO.UserName = notification.UserName;
        			notificationDTO.FirmNumber = notification.FirmNumber;
        			notificationDTO.InsertUser = notification.InsertUser;
        			notificationDTO.Status = notification.Status;
        			notificationDTO.Version = notification.Version;
        			notificationDTO.UpdateDate = notification.UpdateDate;
        			notificationDTO.UpdateUser = notification.UpdateUser;
                    NotificationUtil.populateNotificationAlertInfo(notificationDTO);
        		}
        	}
        	return notificationDTO;
        }
        public static EmailSmsAlertConfigDTO convertToEmailSMSAlertConfig(EmailSmsAlertConfig emailSmsAlertConfig)
        {
            EmailSmsAlertConfigDTO emailSmsAlertConfigDTO = null;
            if (emailSmsAlertConfig != null)
            {
                emailSmsAlertConfigDTO = new EmailSmsAlertConfigDTO();
                emailSmsAlertConfigDTO.Id = emailSmsAlertConfig.Id;

            }
            return emailSmsAlertConfigDTO;
        }
        public static EmailConfigDTO convertToEmailConfig(EmailConfig emailConfig)
        {
            EmailConfigDTO emailConfigDTO = null;
            if (emailConfig != null)
            {
                emailConfigDTO = new EmailConfigDTO();
                emailConfigDTO.Id = emailConfig.Id;
                emailConfigDTO.Email = emailConfig.Email;
                emailConfigDTO.Password = emailConfig.Password;
                emailConfigDTO.SmtpHost = emailConfig.SmtpHost;
                emailConfigDTO.SmtpPort = emailConfig.SmtpPort;
                emailConfigDTO.FirmNumber = emailConfig.FirmNumber;
            }
            return emailConfigDTO;
        }
        public static TallyConfigDTO convertToTallyConfigDTO(TallyConfig tallyConfig)
        {
            TallyConfigDTO tallyConfigDTO = null;
            if (tallyConfig != null)
            {
                tallyConfigDTO = new TallyConfigDTO();
                tallyConfigDTO.Id = tallyConfig.Id;
                tallyConfigDTO.Tallyhost = tallyConfig.Tallyhost;
                tallyConfigDTO.Tallyport = tallyConfig.Tallyport;
                tallyConfigDTO.FirmNumber = tallyConfig.FirmNumber;
                tallyConfigDTO.InsertDate = tallyConfig.InsertDate;
                tallyConfigDTO.InsertUser = tallyConfig.InsertUser;
                tallyConfigDTO.UpdateUser = tallyConfig.UpdateUser;
                tallyConfigDTO.UpdateDate = tallyConfig.UpdateDate;
                tallyConfigDTO.Version = tallyConfig.Version;
            }
            return tallyConfigDTO;
        }
        public static PaymentVoucherDTO convertToPaymentVoucherDTO(PaymentVoucher paymentVoucher, bool allFields)
        {
        	PaymentVoucherDTO paymentVoucherDto = null;
            if (paymentVoucher != null)
            {
            	paymentVoucherDto = new PaymentVoucherDTO();
            	paymentVoucherDto.Id = paymentVoucher.Id;
                if (allFields)
                {
                	paymentVoucherDto.Action = paymentVoucher.Action;
                	paymentVoucherDto.VoucherType = paymentVoucher.VoucherType;
                	paymentVoucherDto.VoucherDate = paymentVoucher.VoucherDate;
                	paymentVoucherDto.VoucherNaration = paymentVoucher.VoucherNaration;
                	paymentVoucherDto.VoucherNumber = paymentVoucher.VoucherNumber;
                	paymentVoucherDto.PartyLedgerName = paymentVoucher.PartyLedgerName;
                	paymentVoucherDto.VoucherEffectiveDate = paymentVoucher.VoucherEffectiveDate;
                	paymentVoucherDto.CstFromIssueType = paymentVoucher.CstFromIssueType;
                	paymentVoucherDto.CstFromRecvType = paymentVoucher.CstFromRecvType;
                	paymentVoucherDto.FbtPaymentType = paymentVoucher.FbtPaymentType;
                	paymentVoucherDto.PersistedView = paymentVoucher.PersistedView;
                	paymentVoucherDto.VchgstClass = paymentVoucher.VchgstClass;
                	paymentVoucherDto.HasCashFlow = paymentVoucher.HasCashFlow;
                	paymentVoucherDto.PostingStatus = paymentVoucher.TallyPostingStatus;
                	paymentVoucherDto.PaymentTransactionDTO = DomainToDTOUtil.convertToPaymentTransactionDTO(paymentVoucher.PaymentTransaction, false);
                	if (paymentVoucher.PaymentLedgers != null && paymentVoucher.PaymentLedgers.Count > 0)
                    {
                        paymentVoucherDto.PaymentLedgers = new HashSet<PaymentLedgerDTO>();
                        foreach (PaymentLedger paymentLedger in paymentVoucher.PaymentLedgers)
                        {
                        	paymentVoucherDto.PaymentLedgers.Add(DomainToDTOUtil.convertToPaymentLedgerDTO(paymentLedger, true));
                        }
                    }
                	paymentVoucherDto.FirmNumber = paymentVoucher.FirmNumber;
                	paymentVoucherDto.InsertDate = paymentVoucher.InsertDate;
                	paymentVoucherDto.InsertUser = paymentVoucher.InsertUser;
                    paymentVoucherDto.UpdateUser = paymentVoucher.UpdateUser;
                    paymentVoucherDto.UpdateDate = paymentVoucher.UpdateDate;
                    paymentVoucherDto.Version = paymentVoucher.Version;
                }
            }
            return paymentVoucherDto;
        }
        
        public static PaymentLedgerDTO convertToPaymentLedgerDTO(PaymentLedger paymentLedger, bool allFields)
        {
        	PaymentLedgerDTO paymentLedgerDto = null;
            if (paymentLedger != null)
            {
            	paymentLedgerDto = new PaymentLedgerDTO();
            	paymentLedgerDto.Id = paymentLedger.Id;
                if (allFields)
                {
                	paymentLedgerDto.LedgerName = paymentLedger.LedgerName;
                	paymentLedgerDto.LedgerType = paymentLedger.LedgerType;
                	paymentLedgerDto.IsDeemedPositive = paymentLedger.IsDeemedPositive;
                	paymentLedgerDto.LedgerFromItem = paymentLedger.LedgerFromItem;
                	paymentLedgerDto.RemoveZeroEntries = paymentLedger.RemoveZeroEntries;
                	paymentLedgerDto.IsPartyLedger = paymentLedger.IsPartyLedger;
                	paymentLedgerDto.IsLastDeemedPositive = paymentLedger.IsLastDeemedPositive;
                	paymentLedgerDto.Amount = paymentLedger.Amount;
                	paymentLedgerDto.VatexpAmount = paymentLedger.VatexpAmount;
                	if (paymentLedger.BillAllocations != null && paymentLedger.BillAllocations.Count > 0)
                    {
                        paymentLedgerDto.BillAllocations = new HashSet<BillAllocationDTO>();
                        foreach (BillAllocation billAllocation in paymentLedger.BillAllocations)
                        {
                        	paymentLedgerDto.BillAllocations.Add(DomainToDTOUtil.convertToBillAllocationDTO(billAllocation, true));
                        }
                    }
                	if (paymentLedger.BankAllocations != null && paymentLedger.BankAllocations.Count > 0)
                    {
                        paymentLedgerDto.BankAllocations = new HashSet<BankAllocationDTO>();
                        foreach (BankAllocation bankAllocation in paymentLedger.BankAllocations)
                        {
                        	paymentLedgerDto.BankAllocations.Add(DomainToDTOUtil.convertToBankAllocationDTO(bankAllocation, true));
                        }
                    }
                	paymentLedgerDto.PaymentVoucherDTO = DomainToDTOUtil.convertToPaymentVoucherDTO(paymentLedger.PaymentVoucher, false);
                	paymentLedgerDto.FirmNumber = paymentLedger.FirmNumber;
                	paymentLedgerDto.InsertDate = paymentLedger.InsertDate;
                	paymentLedgerDto.InsertUser = paymentLedger.InsertUser;
                	paymentLedgerDto.UpdateUser = paymentLedger.UpdateUser;
                	paymentLedgerDto.UpdateDate = paymentLedger.UpdateDate;
                	paymentLedgerDto.Version = paymentLedger.Version;
                }
            }
            return paymentLedgerDto;
        }
        public static BillAllocationDTO convertToBillAllocationDTO(BillAllocation billAllocation, bool allFields)
        {
        	BillAllocationDTO billAllocationDTO = null;
            if (billAllocation != null)
            {
            	billAllocationDTO = new BillAllocationDTO();
            	billAllocationDTO.Id = billAllocation.Id;
                if (allFields)
                {
                	billAllocationDTO.Name = billAllocation.Name;
                	billAllocationDTO.BillType = billAllocation.BillType;
                	billAllocationDTO.TdsDeductSpecialRate = billAllocation.TdsDeductSpecialRate;
                	billAllocationDTO.Amount = billAllocation.Amount;
                	billAllocationDTO.PaymentLedgerDTO = DomainToDTOUtil.convertToPaymentLedgerDTO(billAllocation.PaymentLedger, false);
                	billAllocationDTO.FirmNumber = billAllocation.FirmNumber;
                	billAllocationDTO.InsertDate = billAllocation.InsertDate;
                	billAllocationDTO.InsertUser = billAllocation.InsertUser;
                	billAllocationDTO.UpdateUser = billAllocation.UpdateUser;
                	billAllocationDTO.UpdateDate = billAllocation.UpdateDate;
                	billAllocationDTO.Version = billAllocation.Version;
                }
            }
            return billAllocationDTO;
        }
        public static BankAllocationDTO convertToBankAllocationDTO(BankAllocation bankAllocation, bool allFields)
        {
        	BankAllocationDTO bankAllocationDTO = null;
            if (bankAllocation != null)
            {
            	bankAllocationDTO = new BankAllocationDTO();
            	bankAllocationDTO.Id = bankAllocation.Id;
                if (allFields)
                {
                	bankAllocationDTO.BDate = bankAllocation.BDate;
                	bankAllocationDTO.InstrumentDate = bankAllocation.InstrumentDate;
                	bankAllocationDTO.Name = bankAllocation.Name;
                	bankAllocationDTO.TransactionType = bankAllocation.TransactionType;
                	bankAllocationDTO.BankName = bankAllocation.BankName;
                	bankAllocationDTO.BankBranchName = bankAllocation.BankBranchName;
                	bankAllocationDTO.PaymentFavouring = bankAllocation.PaymentFavouring;
                	bankAllocationDTO.ChequeCrossComment = bankAllocation.ChequeCrossComment;
                	bankAllocationDTO.InstrumentNumber = bankAllocation.InstrumentNumber;
                	bankAllocationDTO.UniqueReferenceNumber = bankAllocation.UniqueReferenceNumber;
                	bankAllocationDTO.Status = bankAllocation.Status;
                	bankAllocationDTO.PaymentMode = bankAllocation.PaymentMode;
                	bankAllocationDTO.BankPartyName = bankAllocation.BankPartyName;
                	bankAllocationDTO.IsConnectedPayment = bankAllocation.IsConnectedPayment;
                	bankAllocationDTO.IsSplit = bankAllocation.IsSplit;
                	bankAllocationDTO.ChequePrinted = bankAllocation.ChequePrinted;
                	bankAllocationDTO.IsContractUsed = bankAllocation.IsContractUsed;
                	bankAllocationDTO.Amount = bankAllocation.Amount;
                	bankAllocationDTO.PaymentLedgerDTO = DomainToDTOUtil.convertToPaymentLedgerDTO(bankAllocation.PaymentLedger, false);
                	bankAllocationDTO.FirmNumber = bankAllocation.FirmNumber;
                	bankAllocationDTO.InsertDate = bankAllocation.InsertDate;
                	bankAllocationDTO.InsertUser = bankAllocation.InsertUser;
                	bankAllocationDTO.UpdateUser = bankAllocation.UpdateUser;
                	bankAllocationDTO.UpdateDate = bankAllocation.UpdateDate;
                	bankAllocationDTO.Version = bankAllocation.Version;
                }
            }
            return bankAllocationDTO;
        }
        public static CallHistoryDTO convertToCallHistoryDTO(CallHistory callHistory, bool allFields)
        {
            CallHistoryDTO callHistoryDTO = null;
            if (callHistory != null)
            {
                callHistoryDTO = new CallHistoryDTO();
                callHistoryDTO.Id = callHistory.Id;
                callHistoryDTO.CallSid = callHistory.CallSid;
                callHistoryDTO.Direction = callHistory.Direction;
                callHistoryDTO.CallerNumber = callHistory.CallerNumber;
                callHistoryDTO.CalleeNumber = callHistory.CalleeNumber;
                callHistoryDTO.StartTime = callHistory.StartTime;
                callHistoryDTO.CallStatus = callHistory.CallStatus;
                callHistoryDTO.CallHistoryStatus = callHistory.CallHistoryStatus;
                callHistoryDTO.FirmMember = convertToFirmMemberDTO(callHistory.FirmMember, false);
                if (callHistoryDTO.FirmMember != null) 
                	callHistoryDTO.FirmMember.FullName = CommonUIConverter.getCustomerFullName(callHistoryDTO.FirmMember.FirstName, callHistoryDTO.FirmMember.LastName);
                if (allFields)
                {                 
                    callHistoryDTO.ParentCallSid = callHistory.ParentCallSid;
                    callHistoryDTO.AccountSid = callHistory.AccountSid;
                    callHistoryDTO.PhoneNumberSid = callHistory.PhoneNumberSid;
                    callHistoryDTO.Uri = callHistory.Uri;
                    callHistoryDTO.DateCreated = callHistory.DateCreated;
                    callHistoryDTO.AnsweredBy = callHistory.AnsweredBy;
                    callHistoryDTO.ForwardedFrom = callHistory.ForwardedFrom;
                    callHistoryDTO.FirmNumber = callHistory.FirmNumber;
                    callHistoryDTO.InsertUser = callHistory.InsertUser;
                    callHistoryDTO.EndTime = callHistory.EndTime;
                    callHistoryDTO.Duration = callHistory.Duration;
                    callHistoryDTO.Price = callHistory.Price;
                    callHistoryDTO.CallerName = callHistory.CallerName;
                    callHistoryDTO.RecordingUrl = callHistory.RecordingUrl;
                    callHistoryDTO.RecordingFile = callHistory.RecordingFile;
                    callHistoryDTO.DateUpdated = callHistory.DateUpdated;
                    callHistoryDTO.Version = callHistory.Version;
                    callHistoryDTO.UpdateDate = callHistory.UpdateDate;
                    callHistoryDTO.UpdateUser = callHistory.UpdateUser;
                }
            }
            return callHistoryDTO;
        }      
    }
}