﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ConstroSoft.Controller
{
    public class FBUserRegistrationController : ApiController
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        [HttpPost]
        [ActionName("RegisterUser")]
        public string RegisterUser([FromBody]PortalUserDTO inputDTO)
        {
        	List<string> responseJson = new List<string>();
        	try
            {
        		if(inputDTO == null) throw new CustomException("Input object cannot be NULL.");
                FBIntegrationBO fBIntegrationBO = new FBIntegrationBO();

        		responseJson = validateInputMandatoryFields(inputDTO);
                if(responseJson.Count == 0) {
                	if(fBIntegrationBO.isUserExists(inputDTO.UserName)) throw new CustomException("User Name already exist in system.");
                	if(!fBIntegrationBO.isFirmExists(inputDTO.UserName)) throw new CustomException("Firm number does not exist in system.");
                	
                	fBIntegrationBO.saveFBuser(inputDTO);
                    responseJson.Add(inputDTO.UserName + " created successfully.");
                }                
            }
        	catch (Exception exp)
            {
                log.Error("Unexpected error while registering user for facebook.", exp);
                responseJson.Add(CommonUtil.getErrorMessage(exp));
            }
        	return JsonConvert.SerializeObject(responseJson);
        }
        private List<string> validateInputMandatoryFields(PortalUserDTO inputDTO)
        {
        	List<string> errMsgList = new List<string>();
            if (string.IsNullOrWhiteSpace(inputDTO.UserName)) errMsgList.Add("User Name is mandatory.");
            if (string.IsNullOrWhiteSpace(inputDTO.Password)) errMsgList.Add("Password is mandatory.");
            if (string.IsNullOrWhiteSpace(inputDTO.Email)) errMsgList.Add("Email is mandatory.");
            if (string.IsNullOrWhiteSpace(inputDTO.FirmNumber)) errMsgList.Add("Firm Number is mandatory.");
            return errMsgList;
        }
    }
}