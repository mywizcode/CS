﻿using System;
using System.Collections.Generic;
using System.Runtime.Caching; 
namespace ConstroSoft.Logic.CachingProvider
{
    public sealed class NotificationCacheProvider
    {
    	#region Singleton
        private static readonly log4net.ILog log =
                log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private static volatile NotificationCacheProvider instance;
        private static object syncRoot = new Object();
        private MemoryCache cache = new MemoryCache("NotificationCache");

        private NotificationCacheProvider() {}

        public static NotificationCacheProvider Instance
        {
           get 
           {
              if (instance == null) 
              {
                 lock (syncRoot) 
                 {
                    if (instance == null) 
                       instance = new NotificationCacheProvider();
                 }
              }

              return instance;
           }
        }
        
        #endregion

        public void clearAndAddNotifications(string key, List<NotificationDTO> value)
        {
        	lock (syncRoot)
            {
        		cache.Remove(key);
                cache.Add(key, value, DateTimeOffset.MaxValue);
            }
        }
        public void addNotifications(string key, List<NotificationDTO> value)
        {
        	lock (syncRoot)
            {
        		List<NotificationDTO> tmpValue = (List<NotificationDTO>)cache[key];
        		if(tmpValue != null) {
        			tmpValue.AddRange(value);
        		}
            }
        }
        public void addNotification(string key, NotificationDTO value)
        {
        	lock (syncRoot)
            {
        		List<NotificationDTO> tmpValue = (List<NotificationDTO>)cache[key];
        		if(tmpValue != null) {
        			tmpValue.Add(value);
        		}
            }
        }
        public void addNotifications(Dictionary<string, List<NotificationDTO>> notificationDict)
        {
        	lock (syncRoot)
            {
        		foreach(KeyValuePair<string, List<NotificationDTO>> entry in notificationDict)
                {
        			List<NotificationDTO> tmpValue = (List<NotificationDTO>)cache[entry.Key];
        			if(tmpValue != null) {
                        tmpValue.AddRange(entry.Value);
            		}
                }
            }
        }
        public void removeAllNotifications(string key)
        {
        	lock (syncRoot)
            {
        		cache.Remove(key);
            }
        }
        public void removeNotification(string key, string UIUniqueKey)
        {
        	lock (syncRoot)
            {
        		List<NotificationDTO> value = (List<NotificationDTO>)cache[key];
        		if(value != null) {
        			NotificationDTO tmpDTO = value.Find(x => x.UIUniqueKey == UIUniqueKey);
        			if(tmpDTO != null) {
    					value.Remove(tmpDTO);
    				}
        		}
            }
        }
        public List<NotificationDTO> getAllNotifications(params string[] keys)
        {
        	lock (syncRoot)
            {
        		List<NotificationDTO> tmpList = new List<NotificationDTO>();
        		foreach (string key in keys)
                {
                    string cacheKey = NotificationUtil.getCacheKey(key);
                    List<NotificationDTO> cacheList = (List<NotificationDTO>)cache[cacheKey];
                    if (cacheList != null) tmpList.AddRange(NotificationUtil.getQualifiedNotifications(key, cacheList));
                }
        		return tmpList;
            }
        }
        public void markNewLeadFlag()
        {
            lock (syncRoot)
            {
                cache.Remove(Constants.NOTIFICATIONS.NEW_LEAD_FLAG);
                cache.Add(Constants.NOTIFICATIONS.NEW_LEAD_FLAG, "YES", DateTimeOffset.MaxValue);
            }
        }
        public void unMarkNewLeadFlag()
        {
            lock (syncRoot)
            {
                cache.Remove(Constants.NOTIFICATIONS.NEW_LEAD_FLAG);
                cache.Add(Constants.NOTIFICATIONS.NEW_LEAD_FLAG, "NO", DateTimeOffset.MaxValue);
            }
        }
        public bool isNewLeadFlagRaised()
        {
            lock (syncRoot)
            {
                bool raised = false;
                if (cache.Contains(Constants.NOTIFICATIONS.NEW_LEAD_FLAG))
                {
                    raised = ((string)cache[Constants.NOTIFICATIONS.NEW_LEAD_FLAG]).Equals("YES");
                }
                return raised;
            }
        }
    } 
}