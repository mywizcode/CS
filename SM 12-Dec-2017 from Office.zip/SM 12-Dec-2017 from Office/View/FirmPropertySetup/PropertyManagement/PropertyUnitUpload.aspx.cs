﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.BO;
using ConstroSoft.Logic.Util;
using OfficeOpenXml;

public partial class PropertyUnitUpload : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifyStep1Error = "addModifyStep1Error";
    string addMasterDataError = "addMasterDataError";
    string addMasterDataModal = "addMasterDataModal";
    DropdownBO drpBO = new DropdownBO();
    PropertyUnitManagementBO prUnitBO = new PropertyUnitManagementBO();
    PropertyBO propertyBO = new PropertyBO();
    protected void Page_Load(object sender, EventArgs e)
    {
    	if (ApplicationUtil.isSubPageRendered(Page)) clearMessages();
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                PropertyUnitUploadNavDTO navDto = CommonUtil.getPageNavDTO<PropertyUnitUploadNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.PROPERTY_UNIT_ADD)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
    	ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void renderPageFieldsWithEntitlement()
    {

    }
    private void doInit(PropertyUnitUploadNavDTO navDto)
    {
        initDropdowns();
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(PropertyUnitUploadNavDTO navDto)
    {
        if (navDto != null)
        {
            PropertyUnitUploadPageDTO PageDTO = new PropertyUnitUploadPageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            //Reset page details
            txtUploadUnitProperty.Text = CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()).Name;
            pnlUploadUnitDetail.Visible = false;
            PageDTO.UploadFailedResult = new List<PropertyUnitDTO>();
            PageDTO.UploadSuccessResult = new List<PropertyUnitDTO>();
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void navigateToPreviousPage()
    {
        PropertyUnitUploadPageDTO PageDTO = getSessionPageData();
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is PropertyUnitSearchNavDTO)
            {
                PropertyUnitSearchNavDTO navDTO = (PropertyUnitSearchNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.PROPERTY_UNIT_SEARCH, true);
            }
        }
        Response.Redirect(Constants.URL.PROPERTY_UNIT_SEARCH, true);
    }
    private PropertyUnitUploadPageDTO getSessionPageData()
    {
        return (PropertyUnitUploadPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<PropertyUnitDTO> getUploadFailedList()
    {
        return getSessionPageData().UploadFailedResult;
    }
    private List<PropertyUnitDTO> getUploadSuccessList()
    {
        return getSessionPageData().UploadSuccessResult;
    }
    private bool isUploadSubmitToEnabled()
    {
        return getUploadSuccessList().Count > 0 && Constants.UPLOAD_VALIDATED.Equals(lbSuccessUploadUnitsText.Text);
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelPropertyUnit(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    public void validatePropertyUnits(object sender, EventArgs e)
    {
        try
        {
            pnlUploadUnitDetail.Visible = false;
            HttpFileCollection uploadedFiles = Request.Files;
            List<PropertyUnitDTO> validationFailedList = new List<PropertyUnitDTO>();
            List<PropertyUnitDTO> validationSuccessList = new List<PropertyUnitDTO>();
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            DropDownList drpUnitType = new DropDownList();
            DropDownList drpDirection = new DropDownList();
            DropDownList drpFacing = new DropDownList();
            DropDownList drpTower = new DropDownList();
            drpBO.drpDataBase(drpUnitType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, null, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpDirection, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_DIRECTION, null, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpFacing, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_FACING, null, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpTower, DrpDataType.PROPERTY_TOWER, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(), null, userDefDto.FirmNumber);
            for (int i = 0; i < uploadedFiles.Count; i++)
            {
                HttpPostedFile userPostedFile = uploadedFiles[i];
                if (userPostedFile.ContentLength > 0)
                {
                    string filename = Path.GetFileName(userPostedFile.FileName);
                    string extension = Path.GetExtension(filename);
                    HttpPostedFile file = fileUploadUnits.PostedFile;
                    if (validateFileType(extension))
                    {
                        using (file.InputStream)
                        {
                            ExcelPackage excel = new ExcelPackage(file.InputStream);
                            var workSheet = excel.Workbook.Worksheets[1];
                            IEnumerable<PropertyUnitMapperDTO> newcollection = workSheet.ConvertSheetToObjects<PropertyUnitMapperDTO>();
                            foreach (PropertyUnitMapperDTO propertyUnitMapperDTO in newcollection)
                            {
                                if (!string.IsNullOrWhiteSpace(propertyUnitMapperDTO.PropertyName))
                                {
                                    PropertyUnitDTO propertyUnitDTO = populatePropertyUnitDTO(validationSuccessList, propertyUnitMapperDTO,
                                        drpUnitType, drpDirection, drpFacing, drpTower);
                                    if (propertyUnitDTO.isError)
                                    {
                                        validationFailedList.Add(propertyUnitDTO);
                                    }
                                    else
                                    {
                                        validationSuccessList.Add(propertyUnitDTO);
                                    }
                                }
                            }
                        }
                        pnlUploadUnitDetail.Visible = true;
                        getSessionPageData().UploadFailedResult = validationFailedList;
                        getSessionPageData().UploadSuccessResult = validationSuccessList;

                        lbTotalUploadUnitsCount.Text = (validationFailedList.Count + validationSuccessList.Count) + "";
                        lbSuccessUploadUnitsCount.Text = validationSuccessList.Count + "";
                        lbSuccessUploadUnitsText.Text = Constants.UPLOAD_VALIDATED;
                        lbFailedUploadUnitsCount.Text = validationFailedList.Count + "";
                        btnUploadUnitSubmit.Visible = isUploadSubmitToEnabled();
                        populateUnitUploadGrid(validationSuccessList, "SUCCESS");
                    }
                }
                else
                {
                    setErrorMessage("Please Select valid file to upload.", commonError);
                }
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    public void showUploadUnits(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            string mode = rd.Attributes["data-show"];
            btnUploadUnitSubmit.Visible = false;
            if ("ALL".Equals(mode))
            {
                List<PropertyUnitDTO> allUnits = new List<PropertyUnitDTO>();
                allUnits.AddRange(getUploadFailedList());
                allUnits.AddRange(getUploadSuccessList());
                btnUploadUnitSubmit.Visible = isUploadSubmitToEnabled();
                populateUnitUploadGrid(allUnits, mode);
            }
            else if ("SUCCESS".Equals(mode))
            {
                btnUploadUnitSubmit.Visible = isUploadSubmitToEnabled();
                populateUnitUploadGrid(getUploadSuccessList(), mode);
            }
            else if ("ERROR".Equals(mode))
            {
                populateUnitUploadGrid(getUploadFailedList(), mode);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    public void addPropertyUnits(object sender, EventArgs e)
    {
        try
        {
            List<PropertyUnitDTO> uploadList = getUploadSuccessList();
            if (uploadList != null && uploadList.Count > 0)
            {
                List<PropertyUnitDTO> successList = new List<PropertyUnitDTO>();
                List<PropertyUnitDTO> failureList = new List<PropertyUnitDTO>();
                foreach (PropertyUnitDTO propertyUnitDTO in uploadList)
                {
                    if (!propertyUnitDTO.isError)
                    {
                        try
                        {
                            prUnitBO.savePropertyUnitDetails(propertyUnitDTO);
                            successList.Add(propertyUnitDTO);
                        }
                        catch (Exception exp)
                        {
                            propertyUnitDTO.isError = true;
                            propertyUnitDTO.ErrorMessage = "Failed to upload, Please contact support for more details. ";
                            failureList.Add(propertyUnitDTO);
                        }
                    }
                }
                btnUploadUnitSubmit.Visible = false;
                string msg = (uploadList.Count == successList.Count) ? "Upload process is completed. All Property Units are uploaded successfully." :
                    "Upload process is completed. Some of the Property Units are not uploaded, Please check Failure records.";
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(msg));

                failureList.AddRange(getUploadFailedList());
                getSessionPageData().UploadFailedResult = failureList;
                getSessionPageData().UploadSuccessResult = successList;
                populateUnitUploadGrid(successList, "SUCCESS");

                lbSuccessUploadUnitsCount.Text = successList.Count + "";
                lbSuccessUploadUnitsText.Text = Constants.UPLOAD_SUCCESS;
                lbFailedUploadUnitsCount.Text = failureList.Count + "";
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    private void populateUnitUploadGrid(IList<PropertyUnitDTO> results, string mode)
    {
        unitUploadGrid.Columns[6].Visible = "ALL".Equals(mode) && Constants.UPLOAD_SUCCESS.Equals(lbSuccessUploadUnitsText.Text);
        unitUploadGrid.Columns[7].Visible = !"SUCCESS".Equals(mode);
        assignUiIndexToTaxDetail(results);
        unitUploadGrid.DataSource = results;
        unitUploadGrid.DataBind();
    }

    private void assignUiIndexToTaxDetail(IList<PropertyUnitDTO> results)
    {
        if (results != null && results.Count > 0)
        {
            long uiIndex = 1;
            foreach (PropertyUnitDTO unitDto in results)
            {
                unitDto.UiIndex = uiIndex++;
                unitDto.RowInfo = CommonUIConverter.getGridViewRowInfo(unitDto);
            }
        }
    }
    public PropertyUnitDTO populatePropertyUnitDTO(List<PropertyUnitDTO> unitList, PropertyUnitMapperDTO propertyUnitMapperDTO,
        DropDownList drpUnitType, DropDownList drpDirection, DropDownList drpFacing, DropDownList drpTower)
    {
        PropertyUnitDTO propertyUnitDTO = new PropertyUnitDTO();
        StringBuilder sb = new StringBuilder();
        try
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            if (!propertyUnitMapperDTO.PropertyName.Equals(txtUploadUnitProperty.Text))
            {
                sb.Append("Unit Belongs to different Property.");
            }
            propertyUnitDTO.Wing = propertyUnitMapperDTO.Wing;
            if (propertyUnitMapperDTO.FloorNo == null)
            {
                sb.Append("Floor Number Missing. ");
            }
            else
            {
                propertyUnitDTO.FloorNo = propertyUnitMapperDTO.FloorNo;
            }
            if (propertyUnitMapperDTO.UnitNo == null)
            {
                sb.Append("UnitNo Number Missing. ");
            }
            else
            {
                propertyUnitDTO.UnitNo = propertyUnitMapperDTO.UnitNo;
            }
            if (propertyUnitMapperDTO.UnitType == null)
            {
                sb.Append("Unit Type Missing. ");
            }
            else
            {
                foreach (ListItem li in drpUnitType.Items)
                {
                    if (li.Text.Equals(propertyUnitMapperDTO.UnitType))
                    {
                        propertyUnitDTO.UnitType = CommonUIConverter.getMasterControlDTO(li.Value, propertyUnitMapperDTO.UnitType);
                    }
                }
            }
            if (propertyUnitMapperDTO.BuildupArea == null)
            {
                sb.Append("Builtup Area is Missing. ");
            }
            else
            {
                propertyUnitDTO.BuildupArea = CommonUtil.getDecimalWithoutExt(propertyUnitMapperDTO.BuildupArea);
            }
            if (propertyUnitMapperDTO.CarpetArea == null)
            {
                sb.Append("Carpet Area is Missing. ");
            }
            else
            {
                propertyUnitDTO.CarpetArea = CommonUtil.getDecimalWithoutExt(propertyUnitMapperDTO.CarpetArea);
            }
            if (propertyUnitMapperDTO.BalconyArea == null)
            {
                sb.Append("Balcony Area is Missing. ");
            }
            else
            {
                propertyUnitDTO.BalconyArea = CommonUtil.getDecimalWithoutExt(propertyUnitMapperDTO.BalconyArea);
            }
            if (propertyUnitMapperDTO.Facing != null)
            {
                foreach (ListItem li in drpFacing.Items)
                {
                    if (li.Text.Equals(propertyUnitMapperDTO.Facing))
                    {
                        propertyUnitDTO.Facing = CommonUIConverter.getMasterControlDTO(li.Value, propertyUnitMapperDTO.Facing);
                    }
                }
            }
            if (propertyUnitMapperDTO.Status == null)
            {
                sb.Append("Status is Missing. ");
            }
            else
            {
                propertyUnitDTO.Status = EnumHelper.ToEnum<PRUnitStatus>(propertyUnitMapperDTO.Status);
            }
            if (propertyUnitMapperDTO.Direction != null)
            {
                foreach (ListItem li in drpDirection.Items)
                {
                    if (li.Text.Equals(propertyUnitMapperDTO.Direction))
                    {
                        propertyUnitDTO.Direction = CommonUIConverter.getMasterControlDTO(li.Value, propertyUnitMapperDTO.Direction);
                    }
                }
            }
            if (propertyUnitMapperDTO.NoOfBalcony == null)
            {
                sb.Append("Number Of Balcony is Missing. ");
            }
            else
            {
                propertyUnitDTO.NoOfBalcony = Convert.ToInt32(propertyUnitMapperDTO.NoOfBalcony);
            }
            propertyUnitDTO.FirmNumber = userDefDto.FirmNumber;
            propertyUnitDTO.Version = userDefDto.Version;
            propertyUnitDTO.UpdateUser = userDefDto.Username;
            if (propertyUnitMapperDTO.TowerName == null)
            {
                sb.Append("Tower Name is Missing. ");
            }
            else
            {
                propertyUnitDTO.PropertyTower = new PropertyTowerDTO();
                foreach (ListItem li in drpTower.Items)
                {
                    if (li.Text.Equals(propertyUnitMapperDTO.TowerName))
                        propertyUnitDTO.PropertyTower.Id = long.Parse(li.Value);
                    propertyUnitDTO.TowerName = propertyUnitMapperDTO.TowerName;
                }
            }
            propertyUnitDTO.FirmNumber = userDefDto.FirmNumber;
            propertyUnitDTO.InsertUser = userDefDto.Username;
            if (prUnitBO.isAlreadyExist(propertyUnitDTO))
            {
                sb.Append(string.Format(Resources.Messages.ERROR_SAME_NAME_EXIST, propertyUnitDTO.UnitNo));
            }
            else
            {
                foreach (PropertyUnitDTO unitDTO in unitList)
                {
                    if (unitDTO.Wing.Equals(propertyUnitDTO.Wing) && unitDTO.UnitNo.Equals(propertyUnitDTO.UnitNo))
                    {
                        sb.Append("Duplicate Unit with same UnitNo and Wing.");
                    }
                }
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            sb.Append(exp.Message);
        }
        if (!string.IsNullOrWhiteSpace(sb.ToString()))
        {
            propertyUnitDTO.isError = true;
            propertyUnitDTO.ErrorMessage = sb.ToString();
        }
        return propertyUnitDTO;
    }
    private bool validateFileType(string extension)
    {
        bool isValid = true;
        if (extension != ".xlsx" && extension != ".xls")
        {
            isValid = false;
            setErrorMessage("Please Select Property Unit Excel with extension xlsx or xls.", commonError);
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;

    }
}