﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;
using ConstroSoft.Logic.CachingProvider;


/// <summary>
/// Summary description for PropertyAlertBO
/// </summary>
namespace ConstroSoft
{
    public class NotificationBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public NotificationBO() { }

        public void fetchAndCacheUserNotifications(UserDefinitionDTO userDefDTO, long propertyId)
        {
            ISession session = null;
            List<NotificationDTO> allNotificationList = new List<NotificationDTO>();
            try
            {
            	session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	Notification notification = null;
                        //Fetch all notifications which are open for given user and property
                        var query = session.QueryOver<Notification>(() => notification);
                        IList<Notification> result = query.Where(() => notification.UserName == userDefDTO.Username 
                                && notification.PropertyId == propertyId && notification.Status == NotificationStatus.OPEN).List<Notification>();
                        foreach (Notification tmpObj in result)
                        {
                            allNotificationList.Add(DomainToDTOUtil.convertToNotificationDTO(tmpObj, true));
                        }
                        //Fetch qualifying Reminders scheduled on Lead and convert to task notifications
                        DateTime cutOffDate = DateTime.Now.AddDays((int)(Constants.NOTIFICATIONS.REMINDER_TO_NOTIFY/24));
                        LeadActivity la = null;
                        LeadDetail ld = null;
                        FirmMember assignee = null;
                        Property p = null;
                        IList<LeadActivity> tmpLeadTaskList = session.QueryOver<LeadActivity>(() => la)
                        		.Left.JoinAlias(() => la.LeadDetail, () => ld)
                        		.Left.JoinAlias(() => ld.Assignee, () => assignee)
                                .Left.JoinAlias(() => ld.Property, () => p)
                                .Where(() => assignee.Id == userDefDTO.FirmMember.Id && p.Id == propertyId && la.RecordType == EnqActivityRecordType.Reminder 
                        			&& la.Status == EnqLeadActivityStatus.Open && la.ScheduledDate <= cutOffDate).List<LeadActivity>();
                        foreach(LeadActivity tmpActivity in tmpLeadTaskList)
                        {
                        	allNotificationList.Add(NotificationUtil.createLeadReminderNotification(userDefDTO, tmpActivity, userDefDTO.Username));
                        }
                        //Fetch qualifying Reminders scheduled on Enquiry and convert to task notifications
                        EnquiryActivity ea = null;
                        EnquiryDetail ed = null;
                        IList<EnquiryActivity> tmpEnquiryTaskList = session.QueryOver<EnquiryActivity>(() => ea)
                        		.Left.JoinAlias(() => ea.EnquiryDetail, () => ed)
                        		.Left.JoinAlias(() => ed.Assignee, () => assignee)
                                .Left.JoinAlias(() => ed.Property, () => p)
                        		.Where(() => assignee.Id == userDefDTO.FirmMember.Id && p.Id == propertyId && ea.RecordType == EnqActivityRecordType.Reminder 
                        			&& ea.Status == EnqLeadActivityStatus.Open && ea.ScheduledDate <= cutOffDate).List<EnquiryActivity>();
                        foreach(EnquiryActivity tmpActivity in tmpEnquiryTaskList)
                        {
                        	allNotificationList.Add(NotificationUtil.createEnquiryReminderNotification(userDefDTO, tmpActivity, userDefDTO.Username));
                        }
                        
                        NotificationCacheProvider.Instance.clearAndAddNotifications(
                            NotificationUtil.getNotificationUserKey(userDefDTO.Username, propertyId), allNotificationList);
                    }
                    catch (Exception e)
                    {
                    	log.Error("Unexpected error populating Notification for given user: " + userDefDTO.Username +", and property:" + propertyId, e);
                        log.Error(e.Message, e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void fetchAndCacheUnAssignedLeadCount(string firmNumber)
        {
            ISession session = null;
            IList<Object[]> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        LeadDetail ld = null;
                        Property p = null;
                        result = session.QueryOver<LeadDetail>(() => ld)
                            .JoinAlias(() => ld.Property, () => p)
                            .SelectList(list => list
                                .SelectCount(() => ld.Id)
                                .SelectGroup(() => p.Id)
                            )
                            .Where(() => ld.Status == LeadStatus.Open && ld.FirmNumber == firmNumber && ld.Assignee == null)
                            .List<Object[]>();
                        NotificationCacheProvider.Instance.unMarkNewLeadFlag();
                        List<NotificationDTO> notificationList = new List<NotificationDTO>();
                        if (result != null && result.Count > 0)
                        {
                            foreach (object[] tmpObj in result)
                            {
                                NotificationDTO tmpNotificationDTO = NotificationUtil.createUnAssignedLeadsNotification(long.Parse(tmpObj[1].ToString()), int.Parse(tmpObj[0].ToString()));
                                notificationList.Add(tmpNotificationDTO);
                            }
                        }
                        NotificationCacheProvider.Instance.clearAndAddNotifications(Constants.Entitlement.MENU_LEAD_ASSIGNMENT, notificationList);
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while fetching unassigned lead count:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void markNotificationClosed(long Id)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	Notification dbNotification = session.Get<Notification>(Id);
                        if(dbNotification != null && (dbNotification.Status == NotificationStatus.OPEN)) {
                        	dbNotification.Status = NotificationStatus.CLOSED;
                        	session.Update(dbNotification);
                            tx.Commit();
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while marking notification as closed:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public long addNotification(NotificationDTO notificationDTO)
        {
            ISession session = null;
            long Id = 0;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Notification notification = DTOToDomainUtil.populateNotificationAddFields(notificationDTO);
                        session.Save(notification);
                        Id = notification.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while adding Notification:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }

        public void createUserNotificationsForInCall(UserDefinitionDTO userDefinitionDTO, CallHistoryDTO callHistoryDTO)
        {
            ISession session = null;
            IList<Notification> allNotificationList = new List<Notification>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                       Notification notification = null;
                       //Fetch all notifications which are open for given user and property
                       var query = session.QueryOver<Notification>(() => notification);
                       allNotificationList = query.Where(() => notification.UserName == userDefinitionDTO.Username
                                && notification.PropertyId == 0 && notification.Status == NotificationStatus.OPEN && notification.SubType == NotificationSubType.INCOMING_CALL_INTIMATION).List<Notification>();
                       string key = null;
                       foreach (Notification tmpObj in allNotificationList)
                       {
                           Notification dbNotification = session.Get<Notification>(tmpObj.Id);
                           if (dbNotification != null && (dbNotification.Status == NotificationStatus.OPEN))
                           {
                               dbNotification.Status = NotificationStatus.CLOSED;
                               session.Update(dbNotification);
                           }
                       }
                       //Add new INCOMING_CALL_INTIMATION notification in DB.
                       Notification newNotification = NotificationUtil.getAlertNotification(userDefinitionDTO,
                               "Incoming call from " + callHistoryDTO.CallerNumber, DateTime.Now,
                               NotificationSubType.INCOMING_CALL_INTIMATION, callHistoryDTO.CallerNumber, userDefinitionDTO.Username, callHistoryDTO.Id.ToString());
                       session.Save(notification);
                       NotificationDTO notificationDTO = DomainToDTOUtil.convertToNotificationDTO(notification, true);
                       //Convert new INCOMING_CALL_INTIMATION record to DTO and add to notification cache
                       key = NotificationUtil.getNotificationUserKey(notification.UserName, 0);
                       NotificationCacheProvider.Instance.addCallIntimationForUser(key, notificationDTO);
                    }
                    catch (Exception e)
                    {
                        log.Error("Unexpected error populating Notification for given user: " + userDefinitionDTO.Username);
                        log.Error(e.Message, e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void removeUserNotificationsForInCall(UserDefinitionDTO userDefinitionDTO, CallHistoryDTO callHistoryDTO)
        {
            ISession session = null;
            IList<Notification> allNotificationList = new List<Notification>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Notification notification = null;
                        //Fetch all notifications which are open for given user and property
                        var query = session.QueryOver<Notification>(() => notification);
                        allNotificationList = query.Where(() => notification.UserName == userDefinitionDTO.Username
                                 && notification.PropertyId == 0 && notification.Status == NotificationStatus.OPEN && notification.SubType == NotificationSubType.INCOMING_CALL_INTIMATION).List<Notification>();
                        string key = NotificationUtil.getNotificationUserKey(userDefinitionDTO.Username, 0);
                        //Find Notification where RefEntityInfo = CALL_HISTORY.ID and mark as closed and update to DB
                        //Remove notification from Cache for key NotificationUtil.getNotificationUserKey() and UIUniqueKey = Notification.Id
                        foreach (Notification tmpObj in allNotificationList)
                        {
                            Notification dbNotification = session.Get<Notification>(tmpObj.Id);
                            if (dbNotification != null && (dbNotification.Status == NotificationStatus.OPEN))
                            {
                                dbNotification.Status = NotificationStatus.CLOSED;
                                session.Update(dbNotification);
                                NotificationCacheProvider.Instance.removeNotification(key, tmpObj.Id.ToString());
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        log.Error("Unexpected error populating Notification for given user: " + userDefinitionDTO.Username);
                        log.Error(e.Message, e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
    }
}