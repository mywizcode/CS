﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using NHibernate;
using NHibernate.Criterion;

namespace ConstroSoft.Logic.BO
{

    public class PaymentVoucherBO
    {
        private static readonly log4net.ILog log =
             log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public PaymentVoucherBO() { }


        public IList<PaymentVoucherDTO> fetchPaymentVoucherGridData(string firmNumber, VoucherFilterDTO voucherFilterDTO)
        {
            ISession session = null;
            IList<PaymentVoucherDTO> results = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                PaymentVoucherDTO pvDto = null;
                PaymentVoucher pv = null;
                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => pv.Id).WithAlias(() => pvDto.Id))
                            .Add(Projections.Property(() => pv.VoucherType).WithAlias(() => pvDto.VoucherType))
                            .Add(Projections.Property(() => pv.Action).WithAlias(() => pvDto.Action))
                            .Add(Projections.Property(() => pv.VoucherDate).WithAlias(() => pvDto.VoucherDate))
                            .Add(Projections.Property(() => pv.VoucherNumber).WithAlias(() => pvDto.VoucherNumber))
                            .Add(Projections.Property(() => pv.VoucherNaration).WithAlias(() => pvDto.VoucherNaration))
                            .Add(Projections.Property(() => pv.PartyLedgerName).WithAlias(() => pvDto.PartyLedgerName))
                            .Add(Projections.Property(() => pv.TallyPostingStatus).WithAlias(() => pvDto.PostingStatus));
                var query = session.QueryOver<PaymentVoucher>(() => pv);
                if (voucherFilterDTO != null)
                {
                    ICriteria criteria = query.RootCriteria;
                    if (voucherFilterDTO.Action != null)
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<PaymentVoucher>(() => pv, x => x.Action), voucherFilterDTO.Action.GetDescription()));
                    }
                    if (voucherFilterDTO.TallyPostingStatus != null)
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<PaymentVoucher>(() => pv, x => x.TallyPostingStatus), voucherFilterDTO.TallyPostingStatus.GetDescription()));
                    }
                    if (voucherFilterDTO.VoucherType != null)
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<PaymentVoucher>(() => pv, x => x.VoucherType), voucherFilterDTO.VoucherType.GetDescription()));
                    }

                }
                results = query.Where(() => pv.FirmNumber == firmNumber)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<PaymentVoucherDTO>()).List<PaymentVoucherDTO>();
                results.ToList();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating Voucher grid:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }
        public void updatePaymentVoucher(PaymentVoucherDTO paymentVoucherDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PaymentVoucher paymentVoucher = session.Get<PaymentVoucher>(paymentVoucherDTO.Id);
                        DTOToDomainUtil.populatePaymentVoucherUpdateFields(paymentVoucher, paymentVoucherDTO);
                        session.Update(paymentVoucher);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating Payment Voucher details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public PaymentVoucherDTO fetchPaymentVoucher(long Id)
        {
            ISession session = null;
            PaymentVoucherDTO paymentVoucherDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PaymentVoucher paymentVoucher = session.Get<PaymentVoucher>(Id);
                        paymentVoucherDto = DomainToDTOUtil.convertToPaymentVoucherDTO(paymentVoucher, true);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Payment Voucher details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return paymentVoucherDto;
        }

        public BusinessOutputTO processPaymentReceipt(CustomerPaymentHistoryPageDTO customerPymtHistoryDTO, MPTHistoryUIDTO mptHistUIDTO)
        {
            BusinessOutputTO businessOutputTO = new BusinessOutputTO();
            string BLANK_STRING = "";
            try
            {
                DataTable PaymentReceipt = populatePaymentReceiptColumns();
                DataRow PaymentReceiptRow = populatePaymentReceiptRows(PaymentReceipt, customerPymtHistoryDTO, mptHistUIDTO);
                PaymentReceipt.Rows.Add(PaymentReceiptRow);
                businessOutputTO.result = PaymentReceipt;
                businessOutputTO.status = BusinessOutputTO.Status.SUCCESS;
                businessOutputTO.successMessage = "Payment Receipt for " + CommonUIConverter.getCustomerFullName(customerPymtHistoryDTO.PrUnitSaleDetail.Customer.FirstName,
            customerPymtHistoryDTO.PrUnitSaleDetail.Customer.LastName);
            }
            catch (Exception e)
            {
                log.Error("Exception while generating demand letter", e);
                throw new Exception(Resources.Messages.system_error);
            }
            return businessOutputTO;
        }
       

        private DataRow populatePaymentReceiptRows(DataTable PaymentReceipt, CustomerPaymentHistoryPageDTO customerPymtHistoryDTO, MPTHistoryUIDTO mptHistUIDTO)
        {
            DataRow PaymentReceiptRow = PaymentReceipt.NewRow();            
            string BLANK_STRING = "";            
            PaymentReceiptRow["CustomerName"] = CommonUIConverter.getCustomerFullName(customerPymtHistoryDTO.PrUnitSaleDetail.Customer.FirstName, customerPymtHistoryDTO.PrUnitSaleDetail.Customer.LastName);
            PaymentReceiptRow["Amount"] = mptHistUIDTO.PymtAmt != null ? mptHistUIDTO.PymtAmt : 0;
            PaymentReceiptRow["ReferanceNumber"] = mptHistUIDTO.TxRefNo != null ? mptHistUIDTO.TxRefNo:BLANK_STRING ;
            PaymentReceiptRow["Date"] = mptHistUIDTO.TxDate;
            PaymentReceiptRow["BankName"] = mptHistUIDTO.BankName != null ? mptHistUIDTO.BankName : BLANK_STRING;
            PaymentReceiptRow["Branch"] = mptHistUIDTO.Branch != null ? mptHistUIDTO.Branch : BLANK_STRING;
            PaymentReceiptRow["PropertyName"] = "";
            PaymentReceiptRow["BuildName"] = customerPymtHistoryDTO.PrUnitSaleDetail.PropertyUnit.TowerName != null ? customerPymtHistoryDTO.PrUnitSaleDetail.PropertyUnit.TowerName : BLANK_STRING;
            PaymentReceiptRow["UnitNo"] = customerPymtHistoryDTO.PrUnitSaleDetail.PropertyUnit.UnitNo != null ? customerPymtHistoryDTO.PrUnitSaleDetail.PropertyUnit.UnitNo : BLANK_STRING;
            PaymentReceiptRow["ModeOfPayment"] = mptHistUIDTO.PymtMethod;
            PaymentReceiptRow["Address"] = "";
            return PaymentReceiptRow;
        }
        private static DataTable populatePaymentReceiptColumns()
        {
            DataTable PaymentReceipt = new DataTable();
            PaymentReceipt.Columns.Add("CustomerName", typeof(string));
            PaymentReceipt.Columns.Add("Amount", typeof(string));
            PaymentReceipt.Columns.Add("ReferanceNumber", typeof(string));
            PaymentReceipt.Columns.Add("Date", typeof(string));
            PaymentReceipt.Columns.Add("BankName", typeof(string));
            PaymentReceipt.Columns.Add("Branch", typeof(string));
            PaymentReceipt.Columns.Add("PropertyName", typeof(string));
            PaymentReceipt.Columns.Add("BuildName", typeof(string));
            PaymentReceipt.Columns.Add("UnitNo", typeof(string));
            PaymentReceipt.Columns.Add("Address", typeof(string));
            PaymentReceipt.Columns.Add("ModeOfPayment", typeof(string));          
            return PaymentReceipt;
        }
    }
}
