﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;


/// <summary>
/// Summary description for CallHistoryBO
/// </summary>
namespace ConstroSoft
{
    public class CallHistoryBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public CallHistoryBO() { }

        public IList<CallHistoryDTO> fetchCallHistory(string firmNumber)
        {
            ISession session = null;
            IList<CallHistoryDTO> results = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                CallHistory ch = null;
                var query = session.QueryOver<CallHistory>(() => ch);
                results = query.Where(() => ch.FirmNumber == firmNumber
                    && ch.CallStatus == CallStatus.inprogress).TransformUsing(new DeepTransformer<CallHistoryDTO>()).List<CallHistoryDTO>();
                results.ToList();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating call details:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }

        public long addCallHistory(CallHistoryDTO callHistoryDTO)
        {
            ISession session = null;
            long Id = 0;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        CallHistory callHistory = DTOToDomainUtil.populateCallHistoryAddFields(callHistoryDTO);
                        session.Save(callHistory);
                        Id = callHistory.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while adding Call History:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        public long updateCallHistory(CallHistoryDTO callHistoryDTO)
        {
            ISession session = null;
            long Id = 0;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        CallHistory callHistory = null;
                        var query = session.QueryOver<CallHistory>(() => callHistory);
                        callHistory = query.Where(x => x.CallSid == callHistoryDTO.CallSid).SingleOrDefault();
                        DTOToDomainUtil.populateCallHistoryUpdateFields(callHistory, callHistoryDTO);
                        session.Update(callHistory);
                        Id = callHistory.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating Call History details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        public CallHistoryDTO fetchCallHistoryforCallSID(string CallSid)
        {
            ISession session = null;
            CallHistoryDTO callHistoryDTO = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                CallHistory ch = null;
                var query = session.QueryOver<CallHistory>(() => ch);
                callHistoryDTO = query.Where(() => ch.CallSid == CallSid).TransformUsing(new DeepTransformer<CallHistoryDTO>()).SingleOrDefault<CallHistoryDTO>();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating call details:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return callHistoryDTO;
        }
        public FirmMemberDTO fetchAgent(string Contact)
        {
            ISession session = null;
            FirmMemberDTO firmMemberDTO = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                FirmMember fm = null;
                var query = session.QueryOver<FirmMember>(() => fm);
                firmMemberDTO = query.Where(() => fm.ContactInfo.Contact == Contact).TransformUsing(new DeepTransformer<FirmMemberDTO>()).SingleOrDefault<FirmMemberDTO>();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating firm Member details:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return firmMemberDTO;
        }
    }   
}