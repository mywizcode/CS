﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

