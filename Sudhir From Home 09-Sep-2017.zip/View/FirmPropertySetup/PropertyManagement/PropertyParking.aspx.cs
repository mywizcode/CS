﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Net;
using System.IO;
using System.Windows.Forms;
using System.Net.Mail;
using ConstroSoft;
using ConstroSoft.Logic.BO;
using OfficeOpenXml;
using OfficeOpenXml.DataValidation;
using OfficeOpenXml.Style;
using System.Drawing;
using ConstroSoft.Logic.Util;
using System.Text;

public partial class PropertyParking : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifyStep1Error = "addModifyStep1Error";
    string addMasterDataError = "addMasterDataError";
    string addMasterDataModal = "addMasterDataModal";
    string SearchFilterModal = "SearchFilterModal";
    string step1 = "step1";
    string step2 = "step2";
    string VS_PR_UNIT_LIST = "VS_PR_UNIT_LIST";
    string VS_PR_UNIT_FILTER = "VS_PR_UNIT_FILTER";
    string VS_SELECTED_DB_PR_UNIT = "VS_SELECTED_DB_PR_UNIT";
    string VS_UPLOAD_FAILED = "VS_UPLOAD_FAILED";
    string VS_UPLOAD_SUCCESS = "VS_UPLOAD_SUCCESS";
    DropdownBO drpBO = new DropdownBO();
    PropertyBO propertyBO = new PropertyBO();
    PropertyUnitManagementBO prUnitBO = new PropertyUnitManagementBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    public enum PrUnitPageMode { ADD, MODIFY, VIEW, UPLOAD_UNIT, NONE }
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Form.Attributes.Add("enctype", "multipart/form-data");
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(); else Response.Redirect(Constants.URL.DEFAULT_HOME_PAGE, false);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg) {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        lnkAddPropertyUnitBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_ADD);
        if (propertyUnitSearchGrid.Rows.Count > 0)
        {
            for (var i = 0; i < propertyUnitSearchGrid.Rows.Count; i++)
            {
                LinkButton tmpModifyBtn = (LinkButton)propertyUnitSearchGrid.Rows[i].FindControl("lnkModifyPropertyUnitBtn");
                if (tmpModifyBtn != null)
                {
                    tmpModifyBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_MODIFY);
                }
                LinkButton tmpDeleteBtn = (LinkButton)propertyUnitSearchGrid.Rows[i].FindControl("lnkDeletePropertyUnitBtn");
                if (tmpDeleteBtn != null)
                {
                    tmpDeleteBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_DELETE);
                }
            }
        }
    }
    private PrUnitPageMode getModifyModeIfEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        return CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_UNIT_MODIFY) ? PrUnitPageMode.MODIFY : PrUnitPageMode.VIEW;
    }
    private void preRenderInitFormElements()
    {
        renderPageLayout();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpTowerFilter, DrpDataType.PROPERTY_TOWER, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(), null, userDefDto.FirmNumber);
        drpTowerFilter.Text = CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Id.ToString();
        drpBO.drpDataBase(drpUnitType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        CommonUtil.copyDropDownItems(drpUnitTypeFilter, drpUnitType);
        drpBO.drpDataBase(drpDirection, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_DIRECTION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpFacing, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_FACING, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<PRUnitStatus>(drpStatus, Constants.SELECT_ITEM);
        CommonUtil.copyDropDownItems(drpUnitStatusFilter, drpStatus);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit()
    {
        initPageInfo(PrUnitPageMode.NONE);
        clearSearchGrid();
        initDropdowns();
        setSearchFilter(null);
        loadPropertyUnitSearchGrid();
    }
    private void initPageInfo(PrUnitPageMode pageMode)
    {
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        pageModeHdn.Value = pageMode.ToString();
        activeStepHdn.Value = step1;
        if (PrUnitPageMode.NONE == pageMode)
        {
            ViewState[VS_SELECTED_DB_PR_UNIT] = null;
        }
    }
    private void renderPageLayout()
    {
        PrUnitPageMode pageMode = EnumHelper.ToEnum<PrUnitPageMode>(pageModeHdn.Value);
        liReturnToList.Visible = (PrUnitPageMode.NONE != pageMode);
        pnlPropertyUnitSearch.Visible = (PrUnitPageMode.NONE == pageMode);
        pnlPropertyUnitAddModify.Visible = (PrUnitPageMode.ADD == pageMode || PrUnitPageMode.MODIFY == pageMode || PrUnitPageMode.VIEW == pageMode);
        liUploadUnits.Visible = (PrUnitPageMode.NONE == pageMode);
        pnlUploadUnits.Visible = (PrUnitPageMode.UPLOAD_UNIT == pageMode);
        initFormFields();
        resetPageTitle(pageMode);
    }
    private void resetPageTitle(PrUnitPageMode pageMode)
    {
        if (PrUnitPageMode.NONE == pageMode) lbPageTitle.Text = Constants.ICON.SEARCH + Resources.Labels.SEARCH_PROPERTY_UNIT;
        else if (PrUnitPageMode.ADD == pageMode) lbPageTitle.Text = Constants.ICON.ADD + Resources.Labels.ADD_PROPERTY_UNIT;
        else if (PrUnitPageMode.MODIFY == pageMode) lbPageTitle.Text = Constants.ICON.MODIFY + Resources.Labels.MODIFY_PROPERTY_UNIT;
        else if (PrUnitPageMode.VIEW == pageMode) lbPageTitle.Text = Constants.ICON.VIEW_DTL + Resources.Labels.PROPERTY_UNIT_DETAILS;
        else if (PrUnitPageMode.UPLOAD_UNIT == pageMode) lbPageTitle.Text = Constants.ICON.UPLOAD + Resources.Labels.UPLOAD_UNITS;
    }
    private void initFormFields()
    {
        bool isReadOnly = isViewMode();
        bool visible = !isViewMode();
        bool isEnabled = !isReadOnly;
        if (pnlPropertyUnitAddModify.Visible)
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            //Fields
            txtWing.ReadOnly = isReadOnly || isModifyMode();
            txtFloorNo.ReadOnly = isReadOnly || isModifyMode();
            txtUnitNo.ReadOnly = isReadOnly || isModifyMode();
            drpUnitType.Enabled = isEnabled;
            txtNoOfBalcony.ReadOnly = isReadOnly;
            txtBuiltupArea.ReadOnly = isReadOnly;
            txtCarpetArea.ReadOnly = isReadOnly;
            txtBalconyArea.ReadOnly = isReadOnly;
            drpDirection.Enabled = isEnabled;
            drpFacing.Enabled = isEnabled;
            drpStatus.Enabled = isEnabled;
            txtReserveComments.ReadOnly = isReadOnly;
            //Buttons
            btnAddModifyPrUnitSubmit.Visible = visible;
            addUnitTypeBtn.Visible = visible;
            addDirectionBtn.Visible = visible;
            addFacingBtn.Visible = visible;
        }
    }
    private void clearSearchGrid()
    {
        List<PropertyUnitDTO> tmpList = new List<PropertyUnitDTO>();
        ViewState[VS_PR_UNIT_LIST] = tmpList;
        propertyUnitSearchGrid.DataSource = tmpList;
        propertyUnitSearchGrid.DataBind();
    }
    private bool isAddMode() {
        return PrUnitPageMode.ADD.ToString().Equals(pageModeHdn.Value);
    }
    private bool isModifyMode() {
        return PrUnitPageMode.MODIFY.ToString().Equals(pageModeHdn.Value);
    }
    private bool isViewMode() {
        return PrUnitPageMode.VIEW.ToString().Equals(pageModeHdn.Value);
    }
    private List<PropertyUnitDTO> getSearchPropertyUnitList()
    {
        return (List<PropertyUnitDTO>)ViewState[VS_PR_UNIT_LIST];
    }
    private PropertyUnitDTO getSearchPropertyUnitDTO(long Id)
    {
        List<PropertyUnitDTO> searchList = getSearchPropertyUnitList();
        PropertyUnitDTO selectedPropertyUnitDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            selectedPropertyUnitDTO = searchList.Find(c => c.Id == Id);
        }
        return selectedPropertyUnitDTO;
    }
    private PropertyUnitDTO getDBPropertyUnitDTO()
    {
        return (PropertyUnitDTO)ViewState[VS_SELECTED_DB_PR_UNIT];
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private void loadPropertyUnitSearchGrid()
    {
        IList<PropertyUnitDTO> results = prUnitBO.fetchPropertyUnitGridData(getUserDefinitionDTO().FirmNumber, getSearchFilter(), long.Parse(drpTowerFilter.Text));
        ViewState[VS_PR_UNIT_LIST] = results;
        propertyUnitSearchGrid.DataSource = results;
        propertyUnitSearchGrid.DataBind();
    }
    private void fetchSelectedPropertyUnit(long Id)
    {
        PropertyUnitDTO propertyUnitDTO = null;
        if (isAddMode())
        {
            propertyUnitDTO = populatePropertyUnitDTOAdd();
        }
        else if (isModifyMode() || isViewMode())
        {
            propertyUnitDTO = prUnitBO.fetchPropertyUnitDetails(Id);
        }
        ViewState[VS_SELECTED_DB_PR_UNIT] = propertyUnitDTO;
    }
    private void doViewModifyAction(PrUnitPageMode pageMode, long Id)
    {
        initPageInfo(pageMode);
        fetchSelectedPropertyUnit(Id);
        populateUIFieldsFromDTO(getDBPropertyUnitDTO());
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            initPageInfo(PrUnitPageMode.NONE);
            loadPropertyUnitSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickAddPropertyUnitBtn(object sender, EventArgs e)
    {
        try
        {
            initPageInfo(PrUnitPageMode.ADD);
            fetchSelectedPropertyUnit(0);
            populateUIFieldsFromDTO(null);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickViewPropertyUnitBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            string selectedId = rd.Attributes["data-pid"];
            doViewModifyAction(PrUnitPageMode.VIEW, long.Parse(selectedId));
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyPropertyUnitBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            if(isValidForModify(selectedId)) {
                PropertyUnitDTO propertyUnitDto = getSearchPropertyUnitDTO(selectedId);
                doViewModifyAction(PrUnitPageMode.MODIFY, selectedId);
            }            
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onSelectUnitStatus(object sender, EventArgs e)
    {
        try
        {
            PRUnitStatus status = EnumHelper.ToEnum<PRUnitStatus>(drpStatus.Text);
            divReverseComments.Visible = (PRUnitStatus.Reserved == status);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void addOrModifyPropertyUnit(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyUnitAddOrModify())
            {
                PropertyUnitDTO propertyUnitDTO = getDBPropertyUnitDTO();
                populatePropertyUnitDTOFromUI(propertyUnitDTO);
                long Id = propertyUnitDTO.Id;
                if (isAddMode())
                {
                    Id = prUnitBO.savePropertyUnitDetails(propertyUnitDTO);
                    setSuccessMessage(CommonUtil.getRecordAddSuccessMsg("Property Unit"));
                }
                else if (isModifyMode())
                {
                    prUnitBO.updatePropertyUnitDetails(propertyUnitDTO);
                    setSuccessMessage(CommonUtil.getRecordModifySuccessMsg("Property Unit"));
                }
                loadPropertyUnitSearchGrid();
                doViewModifyAction(getModifyModeIfEntitlement(), Id);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addModifyStep1Error);
        }
    }
    protected void deletePropertyUnit(object sender, EventArgs e)
    {
        try
        {
            long selectedId = getDeleteRecordHdnId();
            if (validatePrUnitDelete(selectedId))
            {
                BusinessOutputTO outputTO = prUnitBO.deletePropertyUnitDetails(selectedId);
                if (outputTO.status == BusinessOutputTO.Status.SUCCESS)
                {
                    setSuccessMessage(CommonUtil.getRecordDeleteSuccessMsg("Property Unit"));
                }
                else
                {
                    prUnitBO.updateUnitAsDeleted(selectedId);
                    setSuccessMessage(CommonUtil.getRecordSoftDeleteSuccessMsg("Property Unit"));
                }
                initPageInfo(PrUnitPageMode.NONE);
                loadPropertyUnitSearchGrid();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelPropertyUnit(object sender, EventArgs e)
    {
        try
        {
            initPageInfo(PrUnitPageMode.NONE);
            loadPropertyUnitSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validatePrUnitDelete(long selectedId)
    {
        bool isValid = true;
        PropertyUnitDTO propertyUnitDTO = getSearchPropertyUnitDTO(selectedId);
        if (propertyUnitDTO.Status != PRUnitStatus.Available)
        {
            isValid = false;
            setErrorMessage("Only Available property units can be deleted.", commonError);
        }
        return isValid;
    }
    /**
     * Define all validation which will be done before add or Modify property.
     * */
    private bool validatePropertyUnitAddOrModify()
    {
        bool isValid = validateStep(step1);
        return isValid;
    }
    /**
     * Validates given step.
     * */
    private bool validateStep(string step)
    {
        bool isValid = true;
        if (!isViewMode())
        {
            if (step.Equals(step1))
            {
                isValid = validateAllStep1Group();
            }
            else if (step.Equals(step2))
            {

            }
        }
        return isValid;
    }
    private bool validateAllStep1Group()
    {
        bool isValid = true;
        Page.Validate(addModifyStep1Error);
        isValid = Page.IsValid;
        if (isValid) isValid = validateUnitAddOrModifyOther();
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    private bool validateUnitAddOrModifyOther()
    {
        bool isValid = true;
        PRUnitStatus status = EnumHelper.ToEnum<PRUnitStatus>(drpStatus.Text);
        if (!(PRUnitStatus.Available == status || PRUnitStatus.Reserved == status))
        {
            isValid = false;
            setErrorMessage("Please select Status as 'Available' or 'Reserved'.", addModifyStep1Error);
        }
        if (PRUnitStatus.Reserved == status && string.IsNullOrWhiteSpace(txtReserveComments.Text))
        {
            isValid = false;
            setErrorMessage("Please enter Reserve Comments.", addModifyStep1Error);
        }
        if (isAddMode())
        {
            if (prUnitBO.validateUnitExist(getUserDefinitionDTO().FirmNumber, long.Parse(drpTowerFilter.Text), txtWing.Text,
                txtFloorNo.Text, txtUnitNo.Text))
            {
                setErrorMessage("Property Unit already exist.", addModifyStep1Error);
                isValid = false;
            }
        }
        return isValid;
    }
    private bool isValidForModify(long Id)
    {
        bool isValid = true;
        PropertyUnitDTO propertyUnitDto = getSearchPropertyUnitDTO(Id);
        if (propertyUnitDto.Status == PRUnitStatus.Deleted)
        {
            isValid = false;
            initPageInfo(PrUnitPageMode.NONE);
            setErrorMessage("Selected Property Unit is deleted, cannot be modified.", commonError);
        }
        else if (propertyUnitDto.Status == PRUnitStatus.Sold)
        {
            isValid = false;
            initPageInfo(PrUnitPageMode.NONE);
            setErrorMessage("Selected Property Unit is Sold, cannot be modified.", commonError);
        }
        return isValid;
    }
    private PropertyUnitDTO populatePropertyUnitDTOAdd()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        PropertyUnitDTO propertyUnitDto = new PropertyUnitDTO();
        propertyUnitDto.PropertyTower = new PropertyTowerDTO();
        propertyUnitDto.PropertyTower.Id = long.Parse(drpTowerFilter.Text);
        propertyUnitDto.FirmNumber = userDefDto.FirmNumber;
        propertyUnitDto.InsertUser = userDefDto.Username;
        return propertyUnitDto;
    }
    private void populatePropertyUnitDTOFromUI(PropertyUnitDTO propertyUnitDTO)
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        if (isAddMode())
        {
            propertyUnitDTO.Wing = txtWing.Text;
            propertyUnitDTO.FloorNo = txtFloorNo.Text;
            propertyUnitDTO.UnitNo = txtUnitNo.Text;
        }
        propertyUnitDTO.UnitType = CommonUIConverter.getMasterControlDTO(drpUnitType.Text, null);
        propertyUnitDTO.BuildupArea = CommonUtil.getDecimalWithoutExt(txtBuiltupArea.Text);
        propertyUnitDTO.CarpetArea = CommonUtil.getDecimalWithoutExt(txtCarpetArea.Text);
        propertyUnitDTO.BalconyArea = CommonUtil.getDecimalWithoutExt(txtBalconyArea.Text);
        propertyUnitDTO.Facing = CommonUIConverter.getMasterControlDTO(drpFacing.Text, null);
        propertyUnitDTO.Status = EnumHelper.ToEnum<PRUnitStatus>(drpStatus.Text);
        propertyUnitDTO.Direction = CommonUIConverter.getMasterControlDTO(drpDirection.Text, null);
        propertyUnitDTO.ReserveComments = (propertyUnitDTO.Status == PRUnitStatus.Reserved) ? txtReserveComments.Text : "";
        propertyUnitDTO.NoOfBalcony = Convert.ToInt32(txtNoOfBalcony.Text);
        propertyUnitDTO.FirmNumber = userDefDto.FirmNumber;
        propertyUnitDTO.Version = userDefDto.Version;
        propertyUnitDTO.UpdateUser = userDefDto.Username;
    }
    private void populateUIFieldsFromDTO(PropertyUnitDTO propertyUnitDto)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        txtProperty.Text = CommonUtil.getCurrentPropertyDTO(userDefDto).Name;
        txtTower.Text = drpTowerFilter.SelectedItem.Text;
        if (propertyUnitDto != null) drpUnitType.Text = propertyUnitDto.UnitType.Id.ToString(); else drpUnitType.Text = null;
        if (propertyUnitDto != null) txtWing.Text = propertyUnitDto.Wing; else txtWing.Text = null;
        if (propertyUnitDto != null) txtReserveComments.Text = propertyUnitDto.ReserveComments; else txtReserveComments.Text = null;
        if (propertyUnitDto != null) txtNoOfBalcony.Text = Convert.ToDecimal(propertyUnitDto.NoOfBalcony).ToString(); else txtNoOfBalcony.Text = null;
        if (propertyUnitDto != null) txtFloorNo.Text = Convert.ToDecimal(propertyUnitDto.FloorNo).ToString(); else txtFloorNo.Text = null;
        if (propertyUnitDto != null && propertyUnitDto.UnitNo != null) txtUnitNo.Text = propertyUnitDto.UnitNo; else txtUnitNo.Text = null;
        if (propertyUnitDto != null && propertyUnitDto.BuildupArea != null) txtBuiltupArea.Text = propertyUnitDto.BuildupArea.ToString(); else txtBuiltupArea.Text = null;
        if (propertyUnitDto != null && propertyUnitDto.CarpetArea != null) txtCarpetArea.Text = propertyUnitDto.CarpetArea.ToString(); else txtCarpetArea.Text = null;
        if (propertyUnitDto != null && propertyUnitDto.BalconyArea != null) txtBalconyArea.Text = propertyUnitDto.BalconyArea.ToString(); else txtBalconyArea.Text = null;
        if (propertyUnitDto != null && propertyUnitDto.Facing != null) drpFacing.Text = propertyUnitDto.Facing.Id.ToString(); else drpFacing.Text = null;
        if (propertyUnitDto != null) drpStatus.Text = propertyUnitDto.Status.ToString(); else drpStatus.Text = PRUnitStatus.Available.ToString();
        if (propertyUnitDto != null && propertyUnitDto.Direction != null) drpDirection.Text = propertyUnitDto.Direction.Id.ToString(); else drpDirection.ClearSelection();
        divReverseComments.Visible = (propertyUnitDto != null && PRUnitStatus.Reserved == propertyUnitDto.Status);
    }
    //Filter Criteria - Property Search - Start
    private PropertyUnitFilterDTO getSearchFilter()
    {
        return (PropertyUnitFilterDTO)ViewState[VS_PR_UNIT_FILTER];
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            PropertyUnitFilterDTO filterDTO = getSearchFilter();
            drpBO.drpDataBase(drpUnitNoFilter, DrpDataType.PR_UNIT_SEARCH_BY_UNITNO, drpTowerFilter.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            if (filterDTO.UnitId > 0) drpUnitNoFilter.Text = filterDTO.UnitId.ToString(); else drpUnitNoFilter.ClearSelection();
            if (filterDTO.UnitType != null) drpUnitTypeFilter.Text = filterDTO.UnitType.Id.ToString(); else drpUnitTypeFilter.ClearSelection();
            if (filterDTO.Wing != null) txtWingFilter.Text = filterDTO.Wing; else txtWingFilter.Text = null;
            if (filterDTO.FloorNo != null) txtFloorNoFilter.Text = filterDTO.FloorNo; else txtFloorNoFilter.Text = null;
            if (filterDTO.Status != null) drpUnitStatusFilter.Text = filterDTO.Status.ToString(); else drpUnitStatusFilter.ClearSelection();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onSelectFilterTower(object sender, EventArgs e)
    {
        try
        {
            drpBO.drpDataBase(drpUnitNoFilter, DrpDataType.PR_UNIT_SEARCH_BY_UNITNO, drpTowerFilter.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            activeModalHdn.Value = SearchFilterModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            CommonUtil.setStickyPrTowerDTO(getUserDefinitionDTO(), long.Parse(drpTowerFilter.Text), drpTowerFilter.SelectedItem.Text);
            PropertyUnitFilterDTO filterDTO = new PropertyUnitFilterDTO();
            if (!string.IsNullOrWhiteSpace(drpUnitNoFilter.Text))
            {
                filterDTO.UnitId = long.Parse(drpUnitNoFilter.Text);
                filterDTO.UnitNo = drpUnitNoFilter.SelectedItem.Text;
            }
            if (!string.IsNullOrWhiteSpace(drpUnitTypeFilter.Text))
            {
                filterDTO.UnitType = CommonUIConverter.getMasterControlDTO(drpUnitTypeFilter.Text, drpUnitTypeFilter.SelectedItem.Text);
            }
            if (!string.IsNullOrWhiteSpace(txtWingFilter.Text))
            {
                filterDTO.Wing = txtWingFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(txtFloorNoFilter.Text))
            {
                filterDTO.FloorNo = txtFloorNoFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(drpUnitStatusFilter.Text))
            {
                filterDTO.Status = EnumHelper.ToEnum<PRUnitStatus>(drpUnitStatusFilter.Text);
            }
            setSearchFilter(filterDTO);
            loadPropertyUnitSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            loadPropertyUnitSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(PropertyUnitFilterDTO searchFilterDTO)
    {
        ViewState[VS_PR_UNIT_FILTER] = (searchFilterDTO != null) ? searchFilterDTO : new PropertyUnitFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {
            drpTowerFilter.Text = CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Id.ToString();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            PropertyUnitFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.UNIT_NO))
            {
                filterDTO.UnitId = 0;
                filterDTO.UnitNo = "";
            }
            else if (token.StartsWith(Constants.FILTER.UNIT_TYPE)) filterDTO.UnitType = null;
            else if (token.StartsWith(Constants.FILTER.WING)) filterDTO.Wing = null;
            else if (token.StartsWith(Constants.FILTER.FLOOR_NO)) filterDTO.FloorNo = null;
            else if (token.StartsWith(Constants.FILTER.STATUS)) filterDTO.Status = null;
            else if (token.StartsWith(Constants.FILTER.TOWER_NAME)) setNotyMsg(CommonUtil.getNotyInfoMsg(Resources.Messages.TOWER_FILTER_DEFAULT));
            setSearchFilterTokens();
            loadPropertyUnitSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        PropertyUnitFilterDTO filterDTO = getSearchFilter();
        string filter = CommonUtil.addFilterToken("", Constants.FILTER.TOWER_NAME + CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Name);
        if (filterDTO != null)
        {
            if (filterDTO.UnitId > 0) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.UNIT_NO + filterDTO.UnitNo);
            if (filterDTO.UnitType != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.UNIT_TYPE + filterDTO.UnitType.Name);
            if (filterDTO.Wing != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.WING + filterDTO.Wing);
            if (filterDTO.FloorNo != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.FLOOR_NO + filterDTO.FloorNo);
            if (filterDTO.Status != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.STATUS + filterDTO.Status.ToString());
        }
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - PropertyUnit Search - End
    //Master Data Modal save logic - Start
    protected void saveMasterData(object sender, EventArgs e)
    {
        try
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (masterDataModalTypeHdn.Value == "UNIT_TYPE")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_UNIT_TYPE, txtMasterDataInput1.Text,
                        txtMasterDataInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Unit Type");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpUnitType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    CommonUtil.copyDropDownItems(drpUnitTypeFilter, drpUnitType);
                }
            }
            else if (masterDataModalTypeHdn.Value == "DIRECTION")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_UNIT_DIRECTION, txtMasterDataInput1.Text,
                        txtMasterDataInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Direction");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpDirection, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_DIRECTION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
            }
            else if (masterDataModalTypeHdn.Value == "FACING")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_UNIT_FACING, txtMasterDataInput1.Text,
                        txtMasterDataInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Facing");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpFacing, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_FACING, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
            }

            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                activeModalHdn.Value = addMasterDataModal;
                setErrorMessage(errorMsg, addMasterDataError);
            }
            else
            {
                resetMasterDataModalFields();
                setParentModalFlag();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            activeModalHdn.Value = "";
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    protected void cancelMasterDataModal(object sender, EventArgs e)
    {
        try
        {
            resetMasterDataModalFields();
            setParentModalFlag();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    private void resetMasterDataModalFields()
    {
        txtMasterDataInput1.Text = "";
        txtMasterDataInput2.Text = "";
        masterDataModalTypeHdn.Value = "";
    }
    private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
    {
        string errorMsg = "";
        if (string.IsNullOrWhiteSpace(masterDataDto.Name))
        {
            errorMsg = string.Format(Resources.Messages.TEXTFIELD_REQUIRED, type);
        }
        else if (masterDataBO.isAlreadyExist(masterDataDto))
        {
            errorMsg = string.Format(Resources.Messages.ALREADY_EXIST_DB_ERROR, type);
        }
        return errorMsg;
    }
    private void setParentModalFlag()
    {
        activeModalHdn.Value = masterDataParentModalHdn.Value;
        masterDataParentModalHdn.Value = "";
    }
    //Master Data Modal save logic - End
    //Bulk Upload - Start
    protected void onClickDownloadTemplate(object sender, EventArgs e)
    {
        try
        {
            List<MasterControlDataDTO> resultsUnitType;
            List<MasterControlDataDTO> resultsFacing;
            List<MasterControlDataDTO> resultsDirection;
            fetchMaster(out resultsUnitType, out resultsFacing, out resultsDirection);
            if (resultsUnitType == null || resultsUnitType.Count <= 0)
            {
                setErrorMessage("Please add property unit types before downloading unit template.", commonError);
            }
            else if (resultsFacing == null || resultsFacing.Count <= 0)
            {
                setErrorMessage("Please add property unit facing before downloading unit template.", commonError); ;
            }
            else if (resultsDirection == null && resultsDirection.Count <= 0)
            {
                setErrorMessage("Please add property unit direction before downloading unit template.", commonError);
            }
            else
            {
                setResponse();
                using (ExcelPackage package = new ExcelPackage())
                {
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.Add(CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()).Name);

                    using (var range = worksheet.Cells["A1: k1048576"])
                    {
                        range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Top.Color.SetColor(Color.Black);
                        range.Style.Border.Bottom.Color.SetColor(Color.Green);
                        range.Style.Border.Left.Color.SetColor(Color.Blue);
                        range.Style.Border.Right.Color.SetColor(Color.Yellow);
                    }
                    prepareHeader(worksheet);
                    addValidationLists(resultsUnitType, resultsFacing, resultsDirection, worksheet);
                    package.Save();
                    using (MemoryStream MyMemoryStream = new MemoryStream())
                    {
                        package.SaveAs(MyMemoryStream);
                        MyMemoryStream.WriteTo(Response.OutputStream);
                        Response.Flush();
                        Response.End();
                    }
                }
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void addValidationLists(List<MasterControlDataDTO> resultsUnitType, List<MasterControlDataDTO> resultsFacing,
            List<MasterControlDataDTO> resultsDirection, ExcelWorksheet worksheet)
    {
        List<string> propertyList = new List<String>();
        propertyList.Add(CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()).Name);
        CommonUtil.addListValidation(worksheet, "A2:A1048576", propertyList);//Property
        CommonUtil.addListValidation(worksheet, "B2:B1048576", CommonUtil.getDropdownItemNames(drpTowerFilter));//Property Tower
        CommonUtil.addListValidation(worksheet, "F2:F1048576", CommonUtil.getMasterDataNames(resultsUnitType));//Unit Type
        CommonUtil.addListValidation(worksheet, "L2:L1048576", CommonUtil.getMasterDataNames(resultsDirection));//Unit Direction
        CommonUtil.addListValidation(worksheet, "K2:K1048576", CommonUtil.getMasterDataNames(resultsFacing));//Unit Facing
        CommonUtil.addListValidation(worksheet, "M2:M1048576", CommonUtil.getEnumValues(typeof(PRUnitStatus)));//Unit Status
    }
    
    private void setResponse()
    {
        Response.Clear();
        Response.Buffer = true;
        Response.Charset = "";
        Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        Response.AddHeader("content-disposition", "attachment;filename=" + CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()).Name + ".xlsx");
    }

    private void fetchMaster(out List<MasterControlDataDTO> resultsUnitType, out List<MasterControlDataDTO> resultsFacing, out List<MasterControlDataDTO> resultsDirection)
    {
        resultsUnitType = masterDataBO.fetchMasterData(getUserDefinitionDTO().FirmNumber, MasterDataType.PR_UNIT_TYPE.ToString());
        resultsFacing = masterDataBO.fetchMasterData(getUserDefinitionDTO().FirmNumber, MasterDataType.PR_UNIT_FACING.ToString());
        resultsDirection = masterDataBO.fetchMasterData(getUserDefinitionDTO().FirmNumber, MasterDataType.PR_UNIT_DIRECTION.ToString());
    }

    private void prepareHeader(ExcelWorksheet worksheet)
    {
        worksheet.Cells[1, 1].Value = "Property Name";
        worksheet.Cells[1, 2].Value = "Tower Name";
        worksheet.Cells[1, 3].Value = "Wing";
        worksheet.Cells[1, 4].Value = "Floor Number";
        worksheet.Cells[1, 5].Value = "Unit Number";
        worksheet.Cells[1, 6].Value = "Unit Type";
        worksheet.Cells[1, 7].Value = "Builtup Area";
        worksheet.Cells[1, 8].Value = "Carpet Area";
        worksheet.Cells[1, 9].Value = "Balcony Area";
        worksheet.Cells[1, 10].Value = "No Of Balcony";
        worksheet.Cells[1, 11].Value = "Facing";
        worksheet.Cells[1, 12].Value = "Direction";
        worksheet.Cells[1, 13].Value = "Status";
        using (var range = worksheet.Cells[1, 1, 1, 13])
        {
            range.Style.Font.Bold = true;
            range.Style.Fill.PatternType = ExcelFillStyle.Solid;
            range.Style.Fill.BackgroundColor.SetColor(Color.Blue);
            range.Style.Font.Color.SetColor(Color.White);
        }
        worksheet.Cells["A1:L1048576"].AutoFilter = true;
        worksheet.Cells.AutoFitColumns(0);
    }
    protected void onClickUploadUnits(object sender, EventArgs e)
    {
        try
        {
            initPageInfo(PrUnitPageMode.UPLOAD_UNIT);
            txtUploadUnitProperty.Text = CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()).Name;
            pnlUploadUnitDetail.Visible = false;
            ViewState[VS_UPLOAD_FAILED] = new List<PropertyUnitDTO>();
            ViewState[VS_UPLOAD_SUCCESS] = new List<PropertyUnitDTO>();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateFileType(string extension)
    {
        bool isValid = true;
        if (extension != ".xlsx" && extension != ".xls")
        {
            isValid = false;
            setErrorMessage("Please Select Property Unit Excel with extension xlsx or xls.", commonError);
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;

    }
    private List<PropertyUnitDTO> getUploadFailedList()
    {
        return (List<PropertyUnitDTO>)ViewState[VS_UPLOAD_FAILED];
    }
    private List<PropertyUnitDTO> getUploadSuccessList()
    {
        return (List<PropertyUnitDTO>)ViewState[VS_UPLOAD_SUCCESS];
    }
    private bool isUploadSubmitToEnabled()
    {
        return getUploadSuccessList().Count > 0 && Constants.UPLOAD_VALIDATED.Equals(lbSuccessUploadUnitsText.Text);
    }
    public void addPropertyUnits(object sender, EventArgs e)
    {
        try
        {
            List<PropertyUnitDTO> uploadList = getUploadSuccessList();
            if(uploadList != null && uploadList.Count > 0) {
                List<PropertyUnitDTO> successList = new List<PropertyUnitDTO>();
                List<PropertyUnitDTO> failureList = new List<PropertyUnitDTO>();
                foreach (PropertyUnitDTO propertyUnitDTO in uploadList)
                {
                    if (!propertyUnitDTO.isError)
                    {
                        try
                        {
                            prUnitBO.savePropertyUnitDetails(propertyUnitDTO);
                            successList.Add(propertyUnitDTO);
                        }
                        catch (Exception exp)
                        {
                            propertyUnitDTO.isError = true;
                            propertyUnitDTO.ErrorMessage = "Failed to upload, Please contact support for more details. ";
                            failureList.Add(propertyUnitDTO);
                        }
                    }
                }
                btnUploadUnitSubmit.Visible = false;
                string msg = (uploadList.Count == successList.Count) ? "Upload process is completed. All Property Units are uploaded successfully." :
                    "Upload process is completed. Some of the Property Units are not uploaded, Please check Failure records.";
                setSuccessMessage(msg);
                
                failureList.AddRange(getUploadFailedList());
                ViewState[VS_UPLOAD_FAILED] = failureList;
                ViewState[VS_UPLOAD_SUCCESS] = successList;
                populateUnitUploadGrid(successList, "SUCCESS");
                
                lbSuccessUploadUnitsCount.Text = successList.Count +"";
                lbSuccessUploadUnitsText.Text = Constants.UPLOAD_SUCCESS;
                lbFailedUploadUnitsCount.Text = failureList.Count +"";
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }

    public void validatePropertyUnits(object sender, EventArgs e)
    {
    	try
        {
    	    pnlUploadUnitDetail.Visible = false;
    	    HttpFileCollection uploadedFiles = Request.Files;
            List<PropertyUnitDTO> validationFailedList = new List<PropertyUnitDTO>();
            List<PropertyUnitDTO> validationSuccessList = new List<PropertyUnitDTO>();
            for (int i = 0; i < uploadedFiles.Count; i++)
            {
                HttpPostedFile userPostedFile = uploadedFiles[i];
                if (userPostedFile.ContentLength > 0)
                {
                    string filename = Path.GetFileName(userPostedFile.FileName);
                    string extension = Path.GetExtension(filename);
                    HttpPostedFile file = fileUploadUnits.PostedFile;
                    if (validateFileType(extension))
                    {
                        using (file.InputStream)
                        {
                            ExcelPackage excel = new ExcelPackage(file.InputStream);
                            var workSheet = excel.Workbook.Worksheets[1];
                            IEnumerable<PropertyUnitMapperDTO> newcollection = workSheet.ConvertSheetToObjects<PropertyUnitMapperDTO>();
                            foreach (PropertyUnitMapperDTO propertyUnitMapperDTO in newcollection)
                            {
                                if (!string.IsNullOrWhiteSpace(propertyUnitMapperDTO.PropertyName))
                                {
                                    PropertyUnitDTO propertyUnitDTO = populatePropertyUnitDTO(validationSuccessList, propertyUnitMapperDTO);
                                    if(propertyUnitDTO.isError) {
                                        validationFailedList.Add(propertyUnitDTO);
                                    } else {
                                        validationSuccessList.Add(propertyUnitDTO);
                                    }
                                }
                            }
                        }
                        pnlUploadUnitDetail.Visible = true;
                        ViewState[VS_UPLOAD_FAILED] = validationFailedList;
                        ViewState[VS_UPLOAD_SUCCESS] = validationSuccessList;
                        
                        lbTotalUploadUnitsCount.Text = (validationFailedList.Count + validationSuccessList.Count) +"";
                        lbSuccessUploadUnitsCount.Text = validationSuccessList.Count +"";
                        lbSuccessUploadUnitsText.Text = Constants.UPLOAD_VALIDATED;
                        lbFailedUploadUnitsCount.Text = validationFailedList.Count +"";
                        btnUploadUnitSubmit.Visible = isUploadSubmitToEnabled();
                        populateUnitUploadGrid(validationSuccessList, "SUCCESS");
                    }
                } else {
                    setErrorMessage("Please Select valid file to upload.", commonError);
                }
            }
        }catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    public void showUploadUnits(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            string mode = rd.Attributes["data-show"];
            btnUploadUnitSubmit.Visible = false;
            if("ALL".Equals(mode)) {
                List<PropertyUnitDTO> allUnits = new List<PropertyUnitDTO>();
                allUnits.AddRange(getUploadFailedList());
                allUnits.AddRange(getUploadSuccessList());
                btnUploadUnitSubmit.Visible = isUploadSubmitToEnabled();
                populateUnitUploadGrid(allUnits, mode);
            } else if("SUCCESS".Equals(mode)) {
                btnUploadUnitSubmit.Visible = isUploadSubmitToEnabled();
                populateUnitUploadGrid(getUploadSuccessList(), mode);
            } else if("ERROR".Equals(mode)) {
                populateUnitUploadGrid(getUploadFailedList(), mode);
            }
        }catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    private void populateUnitUploadGrid(IList<PropertyUnitDTO> results, string mode)
    {
        unitUploadGrid.Columns[6].Visible = "ALL".Equals(mode) && Constants.UPLOAD_SUCCESS.Equals(lbSuccessUploadUnitsText.Text);
        unitUploadGrid.Columns[7].Visible = !"SUCCESS".Equals(mode);
        assignUiIndexToTaxDetail(results);
        unitUploadGrid.DataSource = results;
        unitUploadGrid.DataBind();        
    }

    private void assignUiIndexToTaxDetail(IList<PropertyUnitDTO> results)
    {
        if (results != null && results.Count > 0)
        {
            long uiIndex = 1;
            foreach (PropertyUnitDTO unitDto in results)
            {
                unitDto.UiIndex = uiIndex++;
                unitDto.RowInfo = CommonUIConverter.getGridViewRowInfo(unitDto);
            }
        }
    }
    public PropertyUnitDTO populatePropertyUnitDTO(List<PropertyUnitDTO> unitList, PropertyUnitMapperDTO propertyUnitMapperDTO)
    {
        PropertyUnitDTO propertyUnitDTO = new PropertyUnitDTO();
        StringBuilder sb = new StringBuilder();
        try
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            if (!propertyUnitMapperDTO.PropertyName.Equals(txtUploadUnitProperty.Text))
            {
                sb.Append("Unit Belongs to different Property.");
            }
            propertyUnitDTO.Wing = propertyUnitMapperDTO.Wing;
            if (propertyUnitMapperDTO.FloorNo == null)
            {
                sb.Append("Floor Number Missing. ");
            }
            else
            {
                propertyUnitDTO.FloorNo = propertyUnitMapperDTO.FloorNo;
            }
            if (propertyUnitMapperDTO.UnitNo == null)
            {
                sb.Append("UnitNo Number Missing. ");
            }
            else
            {
                propertyUnitDTO.UnitNo = propertyUnitMapperDTO.UnitNo;
            }
            if (propertyUnitMapperDTO.UnitType == null)
            {
                sb.Append("Unit Type Missing. ");
            }
            else
            {
                foreach (ListItem li in drpUnitType.Items)
                {
                    if (li.Text.Equals(propertyUnitMapperDTO.UnitType))
                    {
                        propertyUnitDTO.UnitType = CommonUIConverter.getMasterControlDTO(li.Value, propertyUnitMapperDTO.UnitType);
                    }
                }
            }
            if (propertyUnitMapperDTO.BuildupArea == null)
            {
                sb.Append("Builtup Area is Missing. ");
            }
            else
            {
                propertyUnitDTO.BuildupArea = CommonUtil.getDecimalWithoutExt(propertyUnitMapperDTO.BuildupArea);
            }
            if (propertyUnitMapperDTO.CarpetArea == null)
            {
                sb.Append("Carpet Area is Missing. ");
            }
            else
            {
                propertyUnitDTO.CarpetArea = CommonUtil.getDecimalWithoutExt(propertyUnitMapperDTO.CarpetArea);
            }
            if (propertyUnitMapperDTO.BalconyArea == null)
            {
                sb.Append("Balcony Area is Missing. ");
            }
            else
            {
                propertyUnitDTO.BalconyArea = CommonUtil.getDecimalWithoutExt(propertyUnitMapperDTO.BalconyArea);
            }
            if (propertyUnitMapperDTO.Facing != null)
            {
                foreach (ListItem li in drpFacing.Items)
                {
                    if (li.Text.Equals(propertyUnitMapperDTO.Facing))
                    {
                        propertyUnitDTO.Facing = CommonUIConverter.getMasterControlDTO(li.Value, propertyUnitMapperDTO.Facing);
                    }
                }
            }
            if (propertyUnitMapperDTO.Status == null)
            {
                sb.Append("Status is Missing. ");
            }
            else
            {
                propertyUnitDTO.Status = EnumHelper.ToEnum<PRUnitStatus>(propertyUnitMapperDTO.Status);
            }
            if (propertyUnitMapperDTO.Direction != null)
            {
                foreach (ListItem li in drpDirection.Items)
                {
                    if (li.Text.Equals(propertyUnitMapperDTO.Direction))
                    {
                        propertyUnitDTO.Direction = CommonUIConverter.getMasterControlDTO(li.Value, propertyUnitMapperDTO.Direction);
                    }
                }
            }
            if (propertyUnitMapperDTO.NoOfBalcony == null)
            {
                sb.Append("Number Of Balcony is Missing. ");
            }
            else
            {
                propertyUnitDTO.NoOfBalcony = Convert.ToInt32(propertyUnitMapperDTO.NoOfBalcony);
            }
            propertyUnitDTO.FirmNumber = userDefDto.FirmNumber;
            propertyUnitDTO.Version = userDefDto.Version;
            propertyUnitDTO.UpdateUser = userDefDto.Username;
            if (propertyUnitMapperDTO.TowerName == null)
            {
                sb.Append("Tower Name is Missing. ");
            }
            else
            {
                propertyUnitDTO.PropertyTower = new PropertyTowerDTO();
                foreach (ListItem li in drpTowerFilter.Items)
                {
                    if (li.Text.Equals(propertyUnitMapperDTO.TowerName))
                        propertyUnitDTO.PropertyTower.Id = long.Parse(li.Value);
                    propertyUnitDTO.TowerName = propertyUnitMapperDTO.TowerName;
                }
            }
            propertyUnitDTO.FirmNumber = userDefDto.FirmNumber;
            propertyUnitDTO.InsertUser = userDefDto.Username;
            if (prUnitBO.isAlreadyExist(propertyUnitDTO))
            {
                sb.Append(string.Format(Resources.Messages.ERROR_SAME_NAME_EXIST, propertyUnitDTO.UnitNo));
            }
            else
            {
                foreach (PropertyUnitDTO unitDTO in unitList)
                {
                    if (unitDTO.Wing.Equals(propertyUnitDTO.Wing) && unitDTO.UnitNo.Equals(propertyUnitDTO.UnitNo))
                    {
                        sb.Append("Duplicate Unit with same UnitNo and Wing.");
                    }
                }
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            sb.Append(exp.Message);
        }
        if(!string.IsNullOrWhiteSpace(sb.ToString())) {
            propertyUnitDTO.isError = true;
            propertyUnitDTO.ErrorMessage = sb.ToString();
        }
        return propertyUnitDTO;
    }
    //Bulk Upload - End
}