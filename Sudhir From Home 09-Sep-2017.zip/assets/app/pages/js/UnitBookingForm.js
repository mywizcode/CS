﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
	initTaxGrid();
	initCMTaxGrid();
    formatFields();
    showModal();
}

function initTaxGrid() {
    var dtOptions = {
        tableId: "taxDetailGrid",
        responsiveModalTitle: "Tax Details",
        isViewOnly: false
    };
    var dtTable = applySimpleDataTable(dtOptions);
}
function initCMTaxGrid() {
    var dtOptions = {
        tableId: "cmTaxDetailGrid",
        responsiveModalTitle: "Tax Details",
        isViewOnly: false
    };
    var dtTable = applySimpleDataTable(dtOptions);
}



