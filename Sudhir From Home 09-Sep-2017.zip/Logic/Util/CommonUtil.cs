﻿
/// <summary>
/// Summary description for CommonUtil
/// </summary>
using ConstroSoft;
using System.Collections.Generic;
using NHibernate.Criterion;
using System.Linq.Expressions;
using System.Linq;
using NHibernate.Impl;
using System;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Web;
using OfficeOpenXml;
using OfficeOpenXml.DataValidation;
namespace ConstroSoft
{
    public class CommonUtil
    {
        public CommonUtil() { }
        public static string getRandomRefNo()
        {
            Random rd = new Random();
            return "" + rd.Next(100, 10000);
        }
        public static string getCustomerRefNo(long Id)
        {
            return "C" + (1000 + Id).ToString();
        }
        public static string getMasterTxRefNo(long Id)
        {
            return "" + (1000 + Id).ToString();
        }
        public static string getBookingRefNo(string propertyName, string towerName, long saleId)
        {
            return propertyName[0].ToString() + towerName[0].ToString() + (1000 + saleId).ToString();
        }
        public static bool isSessionActive(System.Web.SessionState.HttpSessionState Session)
        {
            return (Session[Constants.Session.USERNAME] != null && (Session[Constants.Session.USERNAME]).ToString().Trim() != "") ? true : false;
        }
        public static string getSessionNotyMsg(System.Web.SessionState.HttpSessionState Session)
        {
            string msg = "";
            if(Session[Constants.Session.NOTY_MSG] != null && (Session[Constants.Session.NOTY_MSG]).ToString().Trim() != "") {
                msg = (Session[Constants.Session.NOTY_MSG]).ToString();
                Session.Remove(Constants.Session.NOTY_MSG);
            }
            return msg;
        }
        public static string getAppendedNotyMsg(string msg1, string msg2)
        {
            if (string.IsNullOrWhiteSpace(msg1)) return msg2;
            else if (string.IsNullOrWhiteSpace(msg2)) return msg1;
            return msg1 + Constants.SEP1 + msg2;
        }
        public static string getNotySuccessMsg(string msg)
        {
            return Constants.NOTY_TYPE.SUCCESS + Constants.SEP2 + msg;
        }
        public static string getNotyErrorMsg(string msg)
        {
            return Constants.NOTY_TYPE.ERROR + Constants.SEP2 + msg;
        }
        public static string getNotyWarningMsg(string msg)
        {
            return Constants.NOTY_TYPE.WARNING + Constants.SEP2 + msg;
        }
        public static string getNotyInfoMsg(string msg)
        {
            return Constants.NOTY_TYPE.INFO + Constants.SEP2 + msg;
        }
        public static void clearSession(System.Web.SessionState.HttpSessionState Session, HttpApplicationState Application)
        {
            string userLoggedIn = Session["USERNAME"] == null ? string.Empty : (string)Session["USERNAME"];
            if (userLoggedIn.Length > 0)
            {
                System.Collections.Generic.List<string> d = Application["LOGGED_IN_USERS"]
                    as System.Collections.Generic.List<string>;
                if (d != null)
                {
                    lock (d)
                    {
                        d.Remove(userLoggedIn);
                    }
                }
            }
            Session["USERNAME"] = "";
            Session[Constants.Session.USERDEFINITION] = "";
        }
        public static string getErrorMessage(Exception exp)
        {
            string message = Resources.Messages.system_error;
            if (exp is CustomException) message = exp.Message;
            return message;
        }
        public static bool hasEntitlement(UserDefinitionDTO userDefDto, string entitlement)
        {
            return userDefDto != null && userDefDto.UserRole.entitlements != null && userDefDto.UserRole.entitlements.Contains(entitlement);
        }
        public static bool hasAnyEntitlement(UserDefinitionDTO userDefDto, string[] entitlements)
        {
            bool result = false;
            if(userDefDto != null && userDefDto.UserRole.entitlements != null) {
                foreach (string str in entitlements)
                {
                    result = userDefDto.UserRole.entitlements.Contains(str);
                    if (result) break;
                }
            }
            return result;
        }
        public static PropertyProjection BuildProjection<T>(Expression<Func<object>> aliasExpression, Expression<Func<T, object>> propertyExpression)
        {
            string alias = ExpressionProcessor.FindMemberExpression(aliasExpression.Body);
            string property = ExpressionProcessor.FindMemberExpression(propertyExpression.Body);

            return Projections.Property(string.Format("{0}.{1}", alias, property));
        }
        public static string removeAppenders(string strTemp)
        {
            string result = "";
            if (!string.IsNullOrWhiteSpace(strTemp))
            {
                foreach(string appender in Constants.APPENDERS) {
                    strTemp = strTemp.Replace(appender, "");
                }
                result = strTemp.Trim();
            }
            return result;
        }
        public static decimal? getDecimalWithoutExt(string strVal)
        {
            return getDecimal(removeAppenders(strVal));
        }
        public static decimal? getDecimal(string strVal)
        {
            decimal? result = null;
            if (!string.IsNullOrWhiteSpace(strVal)) result = decimal.Parse(strVal);
            return result;
        }
        public static decimal getDecimaNotNulllWithoutExt(string strVal)
        {
            return getNotNullDecimal(removeAppenders(strVal));
        }
        public static decimal getNotNullDecimal(string strVal)
        {
            decimal result = decimal.Zero;
            if (!string.IsNullOrWhiteSpace(strVal)) result = decimal.Parse(strVal);
            return result;
        }
        public static string getCSDate(DateTime? date)
        {
            return (date != null) ? date.Value.ToString(Constants.DATE_FORMAT) : null;
        }
        public static string getTallyDate(DateTime? date)
        {
            return (date != null) ? date.Value.ToString(Constants.TALLY_DATE_FORMAT) : null;
        }
        public static DateTime? getCSDate(string strDate) {
            DateTime? date = null;
            if (!string.IsNullOrWhiteSpace(strDate)) date = DateTime.ParseExact(strDate, Constants.DATE_FORMAT, CultureInfo.InvariantCulture);
            return date;
        }
        public static DateTime getCSDateNotNull(string strDate)
        {
            DateTime date = DateTime.Today;
            if (!string.IsNullOrWhiteSpace(strDate)) date = DateTime.ParseExact(strDate, Constants.DATE_FORMAT, CultureInfo.InvariantCulture);
            return date;
        }
        public static string getTodayDate()
        {
            return DateTime.Today.ToString(Constants.DATE_FORMAT);
        }
        public static string getAcntTransCommentPymtMethod(PaymentMethod pymtMethod, string mediaNo)
        {
            string tmpComment = "";
            if (pymtMethod == PaymentMethod.CASH)
                tmpComment = Constants.CASH_PYMT_MODE;
            else if (pymtMethod == PaymentMethod.CHEQUE)
                tmpComment = string.Format(Constants.CHQ_PYMT_MODE, mediaNo);
            else if (pymtMethod == PaymentMethod.DD)
                tmpComment = Constants.DD_PYMT_MODE;
            else if (pymtMethod == PaymentMethod.NEFT)
                tmpComment = Constants.NEFT_PYMT_MODE;
            else if (pymtMethod == PaymentMethod.RTGS)
                tmpComment = Constants.RTGS_PYMT_MODE;
            return tmpComment;
        }
        public static bool isGreaterThanToday(DateTime? date)
        {
            DateTime today = DateTime.Now;
            return (date != null) ? date.Value.CompareTo(today) > 0 : false;
        }
        public static PropertyDTO getCurrentPropertyDTO(UserDefinitionDTO userDTO)
        {
            return userDTO.AssignedProperties.Find(x => x.isUISelected);
        }
        public static PropertyTowerDTO getStickyPrTowerDTO(UserDefinitionDTO userDTO)
        {
            PropertyDTO propertyDTO = getCurrentPropertyDTO(userDTO);
            if (userDTO.StickyTowerDTO == null || userDTO.StickyTowerDTO.Property.Id != propertyDTO.Id)
            {
                PropertyBO propertyBO = new PropertyBO();
                IList<PropertyTowerDTO> prTowerList = propertyBO.fetchPropertyTowerSelective(userDTO.FirmNumber, propertyDTO.Id);
                userDTO.StickyTowerDTO = prTowerList.ToList<PropertyTowerDTO>()[0];
            }
            return userDTO.StickyTowerDTO;
        }
        public static void setStickyPrTowerDTO(UserDefinitionDTO userDTO, long Id, string Name)
        {
            PropertyTowerDTO towerDTO = new PropertyTowerDTO();
            towerDTO.Id = Id;
            towerDTO.Name = Name;
            towerDTO.Property = getCurrentPropertyDTO(userDTO);
            userDTO.StickyTowerDTO = towerDTO;
        }
        public static void copyDropDownItems(DropDownList toDrp, DropDownList fromDrp) {
        	toDrp.Items.Clear();
            for (int i=0; i < fromDrp.Items.Count; i++) {
                toDrp.Items.Add(fromDrp.Items[i]);
            }
        }
        public static void copyDropDownItems(DropDownList toDrp, DropDownList fromDrp, bool excludeSelectItem)
        {
            toDrp.Items.Clear();
            for (int i = 0; i < fromDrp.Items.Count; i++)
            {
                if (!excludeSelectItem || !fromDrp.Items[i].Text.Equals(Constants.SELECT_ITEM[0]))
                {
                    toDrp.Items.Add(fromDrp.Items[i]);
                }
            }
        }
        public static  string addFilterToken(string filter, string token) {
        	return (string.IsNullOrWhiteSpace(filter)) ? token : filter + Constants.TOKEN_FIELD_DELIMITER + token;
        }
        public static string getRecordAddSuccessMsg(string recordName) {
        	return string.Format(Resources.Messages.RECORD_ADDED_DB_SUCCESS, recordName);
        }
        public static string getRecordModifySuccessMsg(string recordName) {
        	return string.Format(Resources.Messages.RECORD_MODIFY_DB_SUCCESS, recordName);
        }
        public static string getRecordDeleteSuccessMsg(string recordName) {
        	return string.Format(Resources.Messages.RECORD_DELETE_DB_SUCCESS, recordName);
        }
        public static string getRecordSoftDeleteSuccessMsg(string recordName) {
        	return string.Format(Resources.Messages.RECORD_DELETE_DB_SUCCESS, recordName);
        }
        public static void addListValidation(ExcelWorksheet worksheet, string cellNo, List<string> results)
        {
            var validation = worksheet.DataValidations.AddListValidation(cellNo);
            validation.ShowErrorMessage = true;
            validation.ErrorStyle = ExcelDataValidationWarningStyle.stop;
            validation.ErrorTitle = "Invalid value was entered";
            validation.Error = "Select a value from the list";
            foreach (string tmpStr in results)
            {
                validation.Formula.Values.Add(tmpStr);
            }
        }
        public static List<string> getDropdownItemNames(DropDownList drp) {
            List<string> list = new List<string>();
            foreach (ListItem li in drp.Items)
            {
                if (li.Text != "--Select--")
                    list.Add(li.Text);
            }
            return list;
        }
        public static List<string> getMasterDataNames(List<MasterControlDataDTO> results) {
            List<string> list = new List<string>();
            foreach (MasterControlDataDTO masterControlDataDTO in results)
            {
                list.Add(masterControlDataDTO.Name);
            }
            return list;
        }
        public static List<string> getEnumValues(Type enumType)
        {   
            if(!typeof(Enum).IsAssignableFrom(enumType))
                throw new ArgumentException("enumType should describe enum");
            Array names = Enum.GetNames(enumType);
            List<string> result = new List<string>(capacity:names.Length);
            for (int i = 0; i < names.Length; i++)
            {
                result.Add((string)names.GetValue(i));
            }

            return result;
        }
        public static List<string> getStepsToValidate(string startStep, string endStep) {
            List<string> steps = new List<string>();
            if(startStep.StartsWith("step") && endStep.StartsWith("step")) {
                long start = long.Parse(startStep.Replace("step", "").Trim());
                long end = long.Parse(endStep.Replace("step", "").Trim());
                do {
                    steps.Add("step" + start);
                    start++;
                } while(start < end);
            }
            return steps;
        }
        public static string appendCommaIfNot(string str) {
            string newStr = "";
            if (!string.IsNullOrWhiteSpace(str)) {
                newStr = (str.Trim().EndsWith(",")) ? str.Trim() : str.Trim()+",";
            }
            return newStr;
        }
        public static string appendBreakLine(string str) {
            return (!string.IsNullOrWhiteSpace(str)) ? str.Trim()+"<br/>" : "";
        }
    }
}