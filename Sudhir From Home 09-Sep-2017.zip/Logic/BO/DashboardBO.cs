﻿using System;
using NHibernate;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using ConstroSoft;
using System.Collections.Generic;
using NHibernate.Criterion;
using NHibernate.Transform;
using System.Net.Mail;
using System.Net.Mime;
using System.Linq;

/// <summary>
/// Summary description for SupplierBO
/// </summary>
namespace ConstroSoft
{
    public class DashboardBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public DashboardBO() { }
        public IList<EnquiryDetailDTO> fetchEnquiryFollowupGridData(string firmNumber, long propertyId)
        {
            ISession session = null;
            IList<EnquiryDetailDTO> results = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                EnquiryDetail ed = null;
                ContactInfo c = null;
                FirmMember fm = null;
                EnquiryDetailDTO enDto = null;
                MasterControlData dg = null;
                MasterControlData dge = null;
                Property pr = null;

                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => ed.Id).WithAlias(() => enDto.Id))
                            .Add(Projections.SqlFunction("concat",
                                        NHibernateUtil.String,
                                        Projections.Property(() => ed.FirstName),
                                        Projections.Constant(" "),
                                        Projections.Property(() => ed.LastName)
                                    ).WithAlias(() => ed.FirstName))
                            .Add(Projections.Property(() => ed.EnquiryRefNo).WithAlias(() => enDto.EnquiryRefNo))
                            .Add(Projections.Property(() => ed.Status).WithAlias(() => enDto.Status))
                            .Add(Projections.Property(() => ed.FollowupDate).WithAlias(() => enDto.FollowupDate))
                            .Add(Projections.Property(() => c.Contact), "ContactInfo.Contact")
                            .Add(Projections.Property(() => c.Email), "ContactInfo.Email")
                            .Add(Projections.SqlFunction("concat",
                                        NHibernateUtil.String,
                                        Projections.Property(() => fm.FirstName),
                                        Projections.Constant(" "),
                                        Projections.Property(() => fm.LastName)
                                    ).WithAlias(() => fm.FirstName), "FirmMember.FirstName");
                var query = session.QueryOver<EnquiryDetail>(() => ed)
                    .Inner.JoinAlias(() => ed.ContactInfo, () => c)
                    .Left.JoinAlias(() => ed.FirmMember, () => fm)
                    .Left.JoinAlias(() => ed.Property, () => pr);
                DateTime cutOffDate = DateTime.Now.AddDays(5);

                results = query.Where(() => ed.FirmNumber == firmNumber && ed.FollowupDate <= cutOffDate && ed.Status == EnquiryStatus.Open
                    && pr.Id == propertyId)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<EnquiryDetailDTO>()).List<EnquiryDetailDTO>();

                foreach (EnquiryDetailDTO enqDetailDto in results)
                {
                    TimeSpan span = (TimeSpan)(enqDetailDto.FollowupDate - DateTime.Now);
                    int days = (int)Math.Ceiling(span.TotalDays);
                    if (days == 0)
                    {
                        enqDetailDto.DaysLeft = "Today";
                        enqDetailDto.DaysLeftCss = "text-success-700";
                    }
                    else if (days < 0)
                    {
                        enqDetailDto.DaysLeft = "Overdue";
                        enqDetailDto.DaysLeftCss = "text-danger-700";
                    }
                    else
                    {
                        enqDetailDto.DaysLeft = days + " days left";
                        enqDetailDto.DaysLeftCss = "text-success-300";
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating enquiry followup grid:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }
        public List<DashboardEventDTO> fetchEventGridData(string firmNumber, long propertyId, long towerId)
        {
            ISession session = null;
            IList<PrUnitSaleDetailDTO> results = null;
            List<DashboardEventDTO> events = new List<DashboardEventDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                PrUnitSaleDetail psd = null;
                PropertyUnit pu = null;
                PropertyTower pt = null;
                Property p = null;
                Customer c = null;
                ContactInfo con = null;

                PrUnitSaleDetailDTO psdDto = null;

                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => psd.Id).WithAlias(() => psdDto.Id))
                            .Add(Projections.Property(() => c.FirstName), "Customer.FirstName")
                            .Add(Projections.Property(() => c.LastName), "Customer.LastName")
                            .Add(Projections.Property(() => con.Contact), "Customer.ContactInfo.Contact")
                            .Add(Projections.Property(() => pt.Name), "PropertyUnit.PropertyTower.Name")
                            .Add(Projections.Property(() => pu.Wing), "PropertyUnit.Wing")
                            .Add(Projections.Property(() => pu.UnitNo), "PropertyUnit.UnitNo")
                            .Add(Projections.Property(() => psd.PossessionDate), "PossessionDate")
                            .Add(Projections.Property(() => psd.AgreementDate), "AgreementDate")
                            .Add(Projections.Property(() => psd.BookingDate).WithAlias(() => psdDto.BookingDate))
                            .Add(Projections.Property(() => psd.IsAgreementDone).WithAlias(() => psdDto.IsAgreementDone))
                            .Add(Projections.Property(() => psd.IsPossessionDone).WithAlias(() => psdDto.IsPossessionDone))
                            .Add(Projections.Property(() => psd.AgreementNo).WithAlias(() => psdDto.AgreementNo));
                var query = session.QueryOver<PrUnitSaleDetail>(() => psd)
                    .Inner.JoinAlias(() => psd.Customer, () => c)
                    .Inner.JoinAlias(() => psd.Customer.ContactInfo, () => con)
                    .Inner.JoinAlias(() => psd.PropertyUnit, () => pu)
                    .Inner.JoinAlias(() => psd.PropertyUnit.PropertyTower, () => pt)
                    .Inner.JoinAlias(() => psd.PropertyUnit.PropertyTower.Property, () => p);
                if (towerId > 0) query.Where(() => pt.Id == towerId);
                DateTime cutOffDate = DateTime.Now.AddDays(5);
                results = query.Where(() => psd.FirmNumber == firmNumber && p.Id == propertyId
                               && ((psd.IsAgreementDone == IsAgreementDone.No && psd.AgreementDate <= cutOffDate) 
                                        || (psd.IsPossessionDone == IsPossessionDone.No && psd.PossessionDate <= cutOffDate)))
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<PrUnitSaleDetailDTO>()).List<PrUnitSaleDetailDTO>();
                foreach (PrUnitSaleDetailDTO saleDetailDto in results)
                {
                    DashboardEventDTO eventDto = new DashboardEventDTO();
                    eventDto.Id = saleDetailDto.Id;
                    eventDto.Customer = CommonUIConverter.getCustomerFullName(saleDetailDto.Customer.FirstName, saleDetailDto.Customer.LastName);
                    eventDto.Contact = saleDetailDto.Customer.ContactInfo.Contact;
                    eventDto.TowerName = saleDetailDto.PropertyUnit.PropertyTower.Name;
                    eventDto.UnitNo = CommonUIConverter.getPropertyUnitFormattedNo(saleDetailDto.PropertyUnit.Wing, saleDetailDto.PropertyUnit.UnitNo);
                    eventDto.PrUnitSaleDetail = saleDetailDto;
                    if (saleDetailDto.PossessionDate != null)
                    {
                        eventDto.Date = saleDetailDto.PossessionDate;
                        eventDto.EventType = DashboardEvent.POSSESSION;
                    }
                    else
                    {
                        eventDto.Date = saleDetailDto.AgreementDate;
                        eventDto.EventType = DashboardEvent.AGREEMENT;
                    }
                    TimeSpan span = (TimeSpan)(eventDto.Date - DateTime.Now);
                    int days = (int)Math.Ceiling(span.TotalDays);
                    if (days == 0)
                    {
                        eventDto.DaysLeft = "Today";
                        eventDto.DaysLeftCss = "text-success-700";
                    } else if (days < 0)
                    {
                        eventDto.DaysLeft = "Overdue";
                        eventDto.DaysLeftCss = "text-danger-700";
                    }
                    else
                    {
                        eventDto.DaysLeft = days + " days left";
                        eventDto.DaysLeftCss = "text-success-300";
                    }
                    events.Add(eventDto);
                }
                events = events.OrderBy(o => o.Date).ToList();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating Dashboard Event grid:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return events;
        }
        public IList<MasterPymtTransactionDTO> fetchPdcForDashboard(string firmNumber, long propertyId, long prTowerId)
        {
            ISession session = null;
            IList<MasterPymtTransactionDTO> result = new List<MasterPymtTransactionDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        MasterPymtTransactionDTO mptDto = null;

                        MasterPymtTransaction mpt = null;
                        Property p = null;
                        PropertyTower pt = null;

                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => mpt.Id).WithAlias(() => mptDto.Id))
                                    .Add(Projections.Property(() => mpt.MediaNo).WithAlias(() => mptDto.MediaNo))
                                    .Add(Projections.Property(() => mpt.ChequeDate).WithAlias(() => mptDto.ChequeDate))
                                    .Add(Projections.Property(() => mpt.ChequeStatus).WithAlias(() => mptDto.ChequeStatus))
                                    .Add(Projections.Property(() => p.Id), "Property.Id")
                                    .Add(Projections.Property(() => p.Name), "Property.Name")
                                    .Add(Projections.Property(() => pt.Id), "PrTower.Id")
                                    .Add(Projections.Property(() => pt.Name), "PrTower.Name");
                        var query = session.QueryOver<MasterPymtTransaction>(() => mpt)
                            .Left.JoinAlias(() => mpt.Property, () => p);
                        DateTime cutOffDate = DateTime.Now.AddDays(5);
                        result = query.Where(() => mpt.FirmNumber == firmNumber
                            && (mpt.ChequeStatus == ChequeStatus.Collected || mpt.ChequeStatus == ChequeStatus.Deposited)
                            && mpt.ChequeDate <= cutOffDate
                            && p.Id == propertyId)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<MasterPymtTransactionDTO>()).List<MasterPymtTransactionDTO>();
                        foreach (MasterPymtTransactionDTO chqDto in result)
                        {
                            TimeSpan span = (TimeSpan)(chqDto.ChequeDate - DateTime.Now);
                            int days = (int)Math.Ceiling(span.TotalDays);
                            if (days == 0)
                            {
                                //chqDto.DaysLeft = "Today";
                                //chqDto.DaysLeftCss = "text-success-700";
                            }
                            else if (days < 0)
                            {
                                //chqDto.DaysLeft = "Overdue";
                                //chqDto.DaysLeftCss = "text-danger-700";
                            }
                            else
                            {
                                //chqDto.DaysLeft = days + " days left";
                                //chqDto.DaysLeftCss = "text-success-300";
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading PDC for dashboard:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public IList<DashboardUnitCountDTO> fetchPrUnitCount(string firmNumber, long propertyId, long prTowerId)
        {
            ISession session = null;
            IList<DashboardUnitCountDTO> result = new List<DashboardUnitCountDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit pu = null;
                        Property p = null;
                        PropertyTower pt = null;

                        DashboardUnitCountDTO PrUnitDto = null;
                        var query = session.QueryOver<PropertyUnit>(() => pu)
                                        .Left.JoinAlias(() => pu.PropertyTower, () => pt)
                                        .Left.JoinAlias(() => pu.PropertyTower.Property, () => p)
                                            .SelectList(list => list
                                              .SelectGroup(m => m.Status).WithAlias(() => PrUnitDto.Status)
                                              .SelectCount(m => m.Id).WithAlias(() => PrUnitDto.Count));
                        if(prTowerId > 0) query.Where(() => pt.Id == prTowerId);
                        result = query.SelectList(list => list
                                              .SelectGroup(m => m.Status).WithAlias(() => PrUnitDto.Status)
                                              .SelectCount(m => m.Id).WithAlias(() => PrUnitDto.Count))
                                            .Where(() => pu.FirmNumber == firmNumber && p.Id == propertyId)
                                            .TransformUsing(Transformers.AliasToBean<DashboardUnitCountDTO>())
                                            .List<DashboardUnitCountDTO>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Pr Unit Count:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public void updateAgreementDetails(long PrUnitSaleId, DateTime AgreementDate, string AgreementNo, IsAgreementDone IsAgreementDone)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        StringBuilder builder = new StringBuilder("update PrUnitSaleDetail prs set prs.AgreementDate = :AgreementDate");
                        if (IsAgreementDone.Yes == IsAgreementDone)
                        {
                            builder.Append(" ,prs.IsAgreementDone = :IsAgreementDone, prs.AgreementNo = :AgreementNo");
                        }
                        builder.Append(" where prs.Id = :PrUnitSaleId");
                        IQuery query = session.CreateQuery(builder.ToString());
                        query.SetDateTime("AgreementDate", AgreementDate);
                        query.SetInt64("PrUnitSaleId", PrUnitSaleId);
                        if (IsAgreementDone.Yes == IsAgreementDone)
                        {
                            query.SetString("AgreementNo", AgreementNo);
                            query.SetParameter("IsAgreementDone", IsAgreementDone.Yes);
                        }
                        query.ExecuteUpdate();
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Updating Agreement Details from dashboard:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void updatePossessionDetails(long PrUnitSaleId, DateTime PossessionDate, IsPossessionDone IsPossessionDone)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        StringBuilder builder = new StringBuilder("update PrUnitSaleDetail prs set prs.PossessionDate = :PossessionDate");
                        if (IsPossessionDone.Yes == IsPossessionDone)
                        {
                            builder.Append(" ,prs.IsPossessionDone = :IsPossessionDone");
                        }
                        builder.Append(" where prs.Id = :PrUnitSaleId");
                        IQuery query = session.CreateQuery(builder.ToString());
                        query.SetDateTime("PossessionDate", PossessionDate);
                        query.SetInt64("PrUnitSaleId", PrUnitSaleId);
                        if (IsPossessionDone.Yes == IsPossessionDone)
                        {
                            query.SetParameter("IsPossessionDone", IsPossessionDone.Yes);
                        }
                        query.ExecuteUpdate();
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Updating Possession Details from dashboard:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
    }
}