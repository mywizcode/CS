﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initPaymentGrid();
    formatFields();
    showModal();
}

function initPaymentGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        pageLength: 10
    };

    $("[id$='paymentSearchGrid']").CSBasicDatatable(dtOptions);
}




