﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Net;
using System.IO;
using System.Windows.Forms;
using System.Net.Mail;
using ConstroSoft;
using ConstroSoft.Logic.BO;
using OfficeOpenXml;
using OfficeOpenXml.DataValidation;
using OfficeOpenXml.Style;
using System.Drawing;
using ConstroSoft.Logic.Util;
using System.Text;

public partial class PropertyParking : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifyStep1Error = "addModifyStep1Error";
    string addMasterDataError = "addMasterDataError";
    string addMasterDataModal = "addMasterDataModal";
    string SearchFilterModal = "SearchFilterModal";
    string step1 = "step1";
    string step2 = "step2";
    DropdownBO drpBO = new DropdownBO();
    PropertyBO propertyBO = new PropertyBO();
    PropertyUnitManagementBO prUnitBO = new PropertyUnitManagementBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    public enum PrParkingPageMode { ADD, MODIFY, VIEW, UPLOAD_PARKING, NONE }

    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Form.Attributes.Add("enctype", "multipart/form-data");
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                Session.Remove(Constants.Session.PAGE_DATA);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), false);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        lnkAddPropertyParkingBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_ADD);
        if (propertyParkingSearchGrid.Rows.Count > 0)
        {
            for (var i = 0; i < propertyParkingSearchGrid.Rows.Count; i++)
            {
                LinkButton tmpModifyBtn = (LinkButton)propertyParkingSearchGrid.Rows[i].FindControl("lnkModifyPropertyParkingBtn");
                if (tmpModifyBtn != null)
                {
                    tmpModifyBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_MODIFY);
                }
                LinkButton tmpDeleteBtn = (LinkButton)propertyParkingSearchGrid.Rows[i].FindControl("lnkDeletePropertyParkingBtn");
                if (tmpDeleteBtn != null)
                {
                    tmpDeleteBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_DELETE);
                }
            }
        }
    }
    private PrParkingPageMode getModifyModeIfEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        return CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_UNIT_MODIFY) ? PrParkingPageMode.MODIFY : PrParkingPageMode.VIEW;
    }
    private void preRenderInitFormElements()
    {
        renderPageLayout();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpTowerFilter, DrpDataType.PROPERTY_TOWER, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(), null, userDefDto.FirmNumber);
        drpTowerFilter.Text = CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Id.ToString();
        drpBO.drpDataBase(drpParkingType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_PARKING_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        CommonUtil.copyDropDownItems(drpParkingTypeFilter, drpParkingType);
        drpBO.drpEnum<CommonParking>(drpCommonParking, Constants.SELECT_ITEM);
        CommonUtil.copyDropDownItems(drpCommonParkingFilter, drpCommonParking);
        drpBO.drpEnum<ParkingStatus>(drpStatus, Constants.SELECT_ITEM);
        CommonUtil.copyDropDownItems(drpParkingStatusFilter, drpStatus);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit()
    {
        Session[Constants.Session.PAGE_DATA] = new PropertyParkingPageDTO();
        setSearchFilter(null);
        initPageInfo(PrParkingPageMode.NONE);
        clearSearchGrid();
        initDropdowns();
        loadPropertyParkingSearchGrid();
    }
    private void initPageInfo(PrParkingPageMode pageMode)
    {
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        pageModeHdn.Value = pageMode.ToString();
        activeStepHdn.Value = step1;
        if (PrParkingPageMode.NONE == pageMode)
        {
            getSessionPageData().SelectedParking = null;
        }
    }
    private void renderPageLayout()
    {
        PrParkingPageMode pageMode = EnumHelper.ToEnum<PrParkingPageMode>(pageModeHdn.Value);
        liReturnToList.Visible = (PrParkingPageMode.NONE != pageMode);
        pnlPropertyParkingSearch.Visible = (PrParkingPageMode.NONE == pageMode);
        pnlPropertyParkingAddModify.Visible = (PrParkingPageMode.ADD == pageMode || PrParkingPageMode.MODIFY == pageMode || PrParkingPageMode.VIEW == pageMode);
        liUploadParkings.Visible = (PrParkingPageMode.NONE == pageMode);
        pnlUploadParkings.Visible = (PrParkingPageMode.UPLOAD_PARKING == pageMode);
        initFormFields();
        resetPageTitle(pageMode);
    }
    private void resetPageTitle(PrParkingPageMode pageMode)
    {
        if (PrParkingPageMode.NONE == pageMode) lbPageTitle.Text = Constants.ICON.SEARCH + Resources.Labels.SEARCH_PROPERTY_PARKING;
        else if (PrParkingPageMode.ADD == pageMode) lbPageTitle.Text = Constants.ICON.ADD + Resources.Labels.ADD_PROPERTY_PARKING;
        else if (PrParkingPageMode.MODIFY == pageMode) lbPageTitle.Text = Constants.ICON.MODIFY + Resources.Labels.MODIFY_PROPERTY_PARKING;
        else if (PrParkingPageMode.VIEW == pageMode) lbPageTitle.Text = Constants.ICON.VIEW_DTL + Resources.Labels.PROPERTY_PARKING_DETAILS;
        else if (PrParkingPageMode.UPLOAD_PARKING == pageMode) lbPageTitle.Text = Constants.ICON.UPLOAD + Resources.Labels.UPLOAD_PARKINGS;
    }
    private void initFormFields()
    {
        bool isReadOnly = isViewMode();
        bool visible = !isViewMode();
        bool isEnabled = !isReadOnly;
        if (pnlPropertyParkingAddModify.Visible)
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            //Fields
            txtParkingNo.ReadOnly = isReadOnly || isModifyMode();
            drpParkingType.Enabled = isEnabled;
            txtParkingArea.ReadOnly = isReadOnly;
            drpStatus.Enabled = isEnabled;
            drpCommonParking.Enabled = isEnabled;
            //Buttons
            btnAddModifyPrParkingSubmit.Visible = visible;
            addParkingTypeBtn.Visible = visible;
        }
    }
    private void clearSearchGrid()
    {
        List<PropertyParkingDTO> tmpList = new List<PropertyParkingDTO>();
        getSessionPageData().SearchResult = tmpList;
        propertyParkingSearchGrid.DataSource = tmpList;
        propertyParkingSearchGrid.DataBind();
    }
    private bool isAddMode()
    {
        return PrParkingPageMode.ADD.ToString().Equals(pageModeHdn.Value);
    }
    private bool isModifyMode()
    {
        return PrParkingPageMode.MODIFY.ToString().Equals(pageModeHdn.Value);
    }
    private bool isViewMode()
    {
        return PrParkingPageMode.VIEW.ToString().Equals(pageModeHdn.Value);
    }
    private PropertyParkingPageDTO getSessionPageData()
    {
        return (PropertyParkingPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<PropertyParkingDTO> getSearchPropertyParkingList()
    {
        return getSessionPageData().SearchResult;
    }
    private PropertyParkingDTO getSearchPropertyParkingDTO(long Id)
    {
        List<PropertyParkingDTO> searchList = getSearchPropertyParkingList();
        PropertyParkingDTO selectedPropertyParkingDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            selectedPropertyParkingDTO = searchList.Find(c => c.Id == Id);
        }
        return selectedPropertyParkingDTO;
    }
    private PropertyParkingDTO getDBPropertyParkingDTO()
    {
        return getSessionPageData().SelectedParking;
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private void loadPropertyParkingSearchGrid()
    {
        IList<PropertyParkingDTO> results = propertyBO.fetchPropertyParkingGridData(getUserDefinitionDTO().FirmNumber, getSearchFilter(), long.Parse(drpTowerFilter.Text));
        getSessionPageData().SearchResult = results.ToList<PropertyParkingDTO>();
        propertyParkingSearchGrid.DataSource = results;
        propertyParkingSearchGrid.DataBind();
    }
    private void fetchSelectedPropertyParking(long Id)
    {
        PropertyParkingDTO propertyParkingDTO = null;
        if (isAddMode())
        {
            propertyParkingDTO = populatePropertyParkingDTOAdd();
        }
        else if (isModifyMode() || isViewMode())
        {
            propertyParkingDTO = propertyBO.fetchPropertyParkingDetails(Id);
        }
        getSessionPageData().SelectedParking = propertyParkingDTO;
    }
    private void doViewModifyAction(PrParkingPageMode pageMode, long Id)
    {
        initPageInfo(pageMode);
        fetchSelectedPropertyParking(Id);
        populateUIFieldsFromDTO(getDBPropertyParkingDTO());
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            initPageInfo(PrParkingPageMode.NONE);
            loadPropertyParkingSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickAddPropertyParkingBtn(object sender, EventArgs e)
    {
        try
        {
            initPageInfo(PrParkingPageMode.ADD);
            fetchSelectedPropertyParking(0);
            populateUIFieldsFromDTO(null);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickViewPropertyParkingBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            string selectedId = rd.Attributes["data-pid"];
            doViewModifyAction(PrParkingPageMode.VIEW, long.Parse(selectedId));
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyPropertyParkingBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            if (isValidForModify(selectedId))
            {
                PropertyParkingDTO propertyParkingDto = getSearchPropertyParkingDTO(selectedId);
                doViewModifyAction(PrParkingPageMode.MODIFY, selectedId);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //protected void onSelectParkingStatus(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        PRUnitStatus status = EnumHelper.ToEnum<PRUnitStatus>(drpStatus.Text);
    //        divReverseComments.Visible = (PRUnitStatus.Reserved == status);
    //    }
    //    catch (Exception exp)
    //    {
    //        log.Error(exp.Message, exp);
    //        setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    //    }
    //}
    protected void addOrModifyPropertyParking(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyParkingAddOrModify())
            {
                PropertyParkingDTO propertyParkingDTO = getDBPropertyParkingDTO();
                populatePropertyParkingDTOFromUI(propertyParkingDTO);
                long Id = propertyParkingDTO.Id;
                if (isAddMode())
                {
                    Id = propertyBO.savePropertyParkingDetails(propertyParkingDTO);
                    setSuccessMessage(CommonUtil.getRecordAddSuccessMsg("Property Parking"));
                }
                else if (isModifyMode())
                {
                    propertyBO.updatePropertyParkingDetails(propertyParkingDTO);
                    setSuccessMessage(CommonUtil.getRecordModifySuccessMsg("Property Parking"));
                }
                loadPropertyParkingSearchGrid();
                doViewModifyAction(getModifyModeIfEntitlement(), Id);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addModifyStep1Error);
        }
    }
    protected void deletePropertyParking(object sender, EventArgs e)
    {
        try
        {
            long selectedId = getDeleteRecordHdnId();
            if (validatePrParkingDelete(selectedId))
            {
                BusinessOutputTO outputTO = propertyBO.deletePropertyParkingDetails(selectedId);
                if (outputTO.status == BusinessOutputTO.Status.SUCCESS)
                {
                    setSuccessMessage(CommonUtil.getRecordDeleteSuccessMsg("Property Parking"));
                }
                else
                {
                    propertyBO.updateParkingAsDeleted(selectedId);
                    setSuccessMessage(CommonUtil.getRecordSoftDeleteSuccessMsg("Property Parking"));
                }
                initPageInfo(PrParkingPageMode.NONE);
                loadPropertyParkingSearchGrid();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelPropertyParking(object sender, EventArgs e)
    {
        try
        {
            initPageInfo(PrParkingPageMode.NONE);
            loadPropertyParkingSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validatePrParkingDelete(long selectedId)
    {
        bool isValid = true;
        PropertyParkingDTO propertyParkingDTO = getSearchPropertyParkingDTO(selectedId);
        if (propertyParkingDTO.Status != ParkingStatus.Available)
        {
            isValid = false;
            setErrorMessage("Only Available property parkings can be deleted.", commonError);
        }
        return isValid;
    }
    /**
     * Define all validation which will be done before add or Modify property.
     * */
    private bool validatePropertyParkingAddOrModify()
    {
        bool isValid = validateStep(step1);
        return isValid;
    }
    /**
     * Validates given step.
     * */
    private bool validateStep(string step)
    {
        bool isValid = true;
        if (!isViewMode())
        {
            if (step.Equals(step1))
            {
                isValid = validateAllStep1Group();
            }
            else if (step.Equals(step2))
            {

            }
        }
        return isValid;
    }
    private bool validateAllStep1Group()
    {
        bool isValid = true;
        Page.Validate(addModifyStep1Error);
        isValid = Page.IsValid;
        if (isValid) isValid = validateParkingAddOrModifyOther();
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    private bool validateParkingAddOrModifyOther()
    {
        bool isValid = true;
        ParkingStatus status = EnumHelper.ToEnum<ParkingStatus>(drpStatus.Text);
        if (!(ParkingStatus.Available == status || ParkingStatus.Reserved == status))
        {
            isValid = false;
            setErrorMessage("Please select Status as 'Available' or 'Reserved'.", addModifyStep1Error);
        }
        if (isAddMode())
        {
            if (propertyBO.validateParkingExist(getUserDefinitionDTO().FirmNumber, long.Parse(drpTowerFilter.Text), txtParkingNo.Text))
            {
                setErrorMessage("Property Parking already exist.", addModifyStep1Error);
                isValid = false;
            }
        }
        return isValid;
    }
    private bool isValidForModify(long Id)
    {
        bool isValid = true;
        PropertyParkingDTO propertyParkingDto = getSearchPropertyParkingDTO(Id);
        if (propertyParkingDto.Status == ParkingStatus.Deleted)
        {
            isValid = false;
            initPageInfo(PrParkingPageMode.NONE);
            setErrorMessage("Selected Property Parking is deleted, cannot be modified.", commonError);
        }
        else if (propertyParkingDto.Status == ParkingStatus.Allotted)
        {
            isValid = false;
            initPageInfo(PrParkingPageMode.NONE);
            setErrorMessage("Selected Property Parking is Allotted, cannot be modified.", commonError);
        }
        return isValid;
    }
    private PropertyParkingDTO populatePropertyParkingDTOAdd()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        PropertyParkingDTO propertyParkingDto = new PropertyParkingDTO();
        propertyParkingDto.PropertyTower = new PropertyTowerDTO();
        propertyParkingDto.PropertyTower.Id = long.Parse(drpTowerFilter.Text);
        propertyParkingDto.FirmNumber = userDefDto.FirmNumber;
        propertyParkingDto.InsertUser = userDefDto.Username;
        return propertyParkingDto;
    }
    private void populatePropertyParkingDTOFromUI(PropertyParkingDTO propertyParkingDTO)
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        if (isAddMode())
        {
            propertyParkingDTO.ParkingNo = txtParkingNo.Text;
        }
        propertyParkingDTO.ParkingType = CommonUIConverter.getMasterControlDTO(drpParkingType.Text, null);
        propertyParkingDTO.Area = CommonUtil.getDecimalWithoutExt(txtParkingArea.Text);
        propertyParkingDTO.Status = EnumHelper.ToEnum<ParkingStatus>(drpStatus.Text);
        propertyParkingDTO.CommonParking = EnumHelper.ToEnum<CommonParking>(drpCommonParking.Text);
        propertyParkingDTO.FirmNumber = userDefDto.FirmNumber;
        propertyParkingDTO.Version = userDefDto.Version;
        propertyParkingDTO.UpdateUser = userDefDto.Username;
    }
    private void populateUIFieldsFromDTO(PropertyParkingDTO propertyParkingDTO)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        txtProperty.Text = CommonUtil.getCurrentPropertyDTO(userDefDto).Name;
        txtTower.Text = drpTowerFilter.SelectedItem.Text;
        if (propertyParkingDTO != null) drpParkingType.Text = propertyParkingDTO.ParkingType.Id.ToString(); else drpParkingType.Text = null;
        if (propertyParkingDTO != null && propertyParkingDTO.ParkingNo != null) txtParkingNo.Text = propertyParkingDTO.ParkingNo; else txtParkingNo.Text = null;
        if (propertyParkingDTO != null && propertyParkingDTO.Area != null) txtParkingArea.Text = propertyParkingDTO.Area.ToString(); else txtParkingArea.Text = null;
        if (propertyParkingDTO != null) drpStatus.Text = propertyParkingDTO.Status.ToString(); else drpStatus.Text = ParkingStatus.Available.ToString();
        if (propertyParkingDTO != null) drpCommonParking.Text = propertyParkingDTO.CommonParking.ToString(); else drpCommonParking.Text = CommonParking.No.ToString();
    }
    //Filter Criteria - Property Search - Start
    private PropertyParkingFilterDTO getSearchFilter()
    {
        return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            PropertyParkingFilterDTO filterDTO = getSearchFilter();
            drpBO.drpDataBase(drpParkingNoFilter, DrpDataType.PR_PARKING_SEARCH_BY_PARKINGNO, drpTowerFilter.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            if (filterDTO.ParkingId > 0) drpParkingNoFilter.Text = filterDTO.ParkingId.ToString(); else drpParkingNoFilter.ClearSelection();
            if (filterDTO.ParkingType != null) drpParkingTypeFilter.Text = filterDTO.ParkingType.Id.ToString(); else drpParkingTypeFilter.ClearSelection();
            if (filterDTO.Status != null) drpParkingStatusFilter.Text = filterDTO.Status.ToString(); else drpParkingStatusFilter.ClearSelection();
            if (filterDTO.CommonParking != null) drpCommonParking.Text = filterDTO.CommonParking.ToString(); else drpCommonParking.ClearSelection();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onSelectFilterTower(object sender, EventArgs e)
    {
        try
        {
            drpBO.drpDataBase(drpParkingNoFilter, DrpDataType.PR_PARKING_SEARCH_BY_PARKINGNO, drpTowerFilter.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            activeModalHdn.Value = SearchFilterModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            CommonUtil.setStickyPrTowerDTO(getUserDefinitionDTO(), long.Parse(drpTowerFilter.Text), drpTowerFilter.SelectedItem.Text);
            PropertyParkingFilterDTO filterDTO = new PropertyParkingFilterDTO();
            if (!string.IsNullOrWhiteSpace(drpParkingNoFilter.Text))
            {
                filterDTO.ParkingId = long.Parse(drpParkingNoFilter.Text);
                filterDTO.ParkingNo = drpParkingNoFilter.SelectedItem.Text;
            }
            if (!string.IsNullOrWhiteSpace(drpParkingTypeFilter.Text))
            {
                filterDTO.ParkingType = CommonUIConverter.getMasterControlDTO(drpParkingTypeFilter.Text, drpParkingTypeFilter.SelectedItem.Text);
            }
            if (!string.IsNullOrWhiteSpace(drpParkingStatusFilter.Text))
            {
                filterDTO.Status = EnumHelper.ToEnum<ParkingStatus>(drpParkingStatusFilter.Text);
            }
            if (!string.IsNullOrWhiteSpace(drpCommonParking.Text))
            {
                filterDTO.CommonParking = EnumHelper.ToEnum<CommonParking>(drpCommonParking.Text);
            }
            setSearchFilter(filterDTO);
            loadPropertyParkingSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            loadPropertyParkingSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(PropertyParkingFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new PropertyParkingFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {
            drpTowerFilter.Text = CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Id.ToString();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            PropertyParkingFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.PARKING_NO))
            {
                filterDTO.ParkingId = 0;
                filterDTO.ParkingNo = "";
            }
            else if (token.StartsWith(Constants.FILTER.PARKING_TYPE)) filterDTO.ParkingType = null;
            else if (token.StartsWith(Constants.FILTER.STATUS)) filterDTO.Status = null;
            else if (token.StartsWith(Constants.FILTER.COMMON_PARKING)) filterDTO.CommonParking = null;
            else if (token.StartsWith(Constants.FILTER.TOWER_NAME)) setNotyMsg(CommonUtil.getNotyInfoMsg(Resources.Messages.TOWER_FILTER_DEFAULT));
            setSearchFilterTokens();
            loadPropertyParkingSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        PropertyParkingFilterDTO filterDTO = getSearchFilter();
        string filter = CommonUtil.addFilterToken("", Constants.FILTER.TOWER_NAME + CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Name);
        if (filterDTO != null)
        {
            if (filterDTO.ParkingId > 0) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.PARKING_NO + filterDTO.ParkingNo);
            if (filterDTO.ParkingType != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.PARKING_TYPE + filterDTO.ParkingType.Name);
            if (filterDTO.Status != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.STATUS + filterDTO.Status.ToString());
            if (filterDTO.CommonParking != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.COMMON_PARKING + filterDTO.CommonParking.ToString());
        }
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - PropertyParking Search - End
    //Master Data Modal save logic - Start
    protected void saveMasterData(object sender, EventArgs e)
    {
        try
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (masterDataModalTypeHdn.Value == "PROPERTY_PARKING_TYPE")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_PARKING_TYPE, txtMasterDataInput1.Text,
                        txtMasterDataInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Parking Type");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpParkingType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_PARKING_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    CommonUtil.copyDropDownItems(drpParkingTypeFilter, drpParkingType);
                }
            }
            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                activeModalHdn.Value = addMasterDataModal;
                setErrorMessage(errorMsg, addMasterDataError);
            }
            else
            {
                resetMasterDataModalFields();
                setParentModalFlag();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            activeModalHdn.Value = "";
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    protected void cancelMasterDataModal(object sender, EventArgs e)
    {
        try
        {
            resetMasterDataModalFields();
            setParentModalFlag();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    private void resetMasterDataModalFields()
    {
        txtMasterDataInput1.Text = "";
        txtMasterDataInput2.Text = "";
        masterDataModalTypeHdn.Value = "";
    }
    private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
    {
        string errorMsg = "";
        if (string.IsNullOrWhiteSpace(masterDataDto.Name))
        {
            errorMsg = string.Format(Resources.Messages.TEXTFIELD_REQUIRED, type);
        }
        else if (masterDataBO.isAlreadyExist(masterDataDto))
        {
            errorMsg = string.Format(Resources.Messages.ALREADY_EXIST_DB_ERROR, type);
        }
        return errorMsg;
    }
    private void setParentModalFlag()
    {
        activeModalHdn.Value = masterDataParentModalHdn.Value;
        masterDataParentModalHdn.Value = "";
    }
    //Master Data Modal save logic - End
    //Bulk Upload - Start
    protected void onClickDownloadTemplate(object sender, EventArgs e)
    {
        try
        {
            List<MasterControlDataDTO> resultsParkingType;
            fetchMaster(out resultsParkingType);
            if (resultsParkingType == null || resultsParkingType.Count <= 0)
            {
                setErrorMessage("Please add property parking types before downloading unit template.", commonError);
            }
            else
            {
                setResponse();
                using (ExcelPackage package = new ExcelPackage())
                {
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.Add(CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()).Name);

                    using (var range = worksheet.Cells["A1: k1048576"])
                    {
                        range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Top.Color.SetColor(Color.Black);
                        range.Style.Border.Bottom.Color.SetColor(Color.Green);
                        range.Style.Border.Left.Color.SetColor(Color.Blue);
                        range.Style.Border.Right.Color.SetColor(Color.Yellow);
                    }
                    prepareHeader(worksheet);
                    addValidationLists(resultsParkingType, worksheet);
                    package.Save();
                    using (MemoryStream MyMemoryStream = new MemoryStream())
                    {
                        package.SaveAs(MyMemoryStream);
                        MyMemoryStream.WriteTo(Response.OutputStream);
                        Response.Flush();
                        Response.End();
                    }
                }
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void addValidationLists(List<MasterControlDataDTO> resultsParkingType, ExcelWorksheet worksheet)
    {
        List<string> propertyList = new List<String>();
        propertyList.Add(CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()).Name);
        CommonUtil.addListValidation(worksheet, "A2:A1048576", propertyList);//Property
        CommonUtil.addListValidation(worksheet, "B2:B1048576", CommonUtil.getDropdownItemNames(drpTowerFilter));//Property Tower
        CommonUtil.addListValidation(worksheet, "D2:D1048576", CommonUtil.getMasterDataNames(resultsParkingType));//Parking Type
        CommonUtil.addListValidation(worksheet, "F2:F1048576", CommonUtil.getEnumValues(typeof(CommonParking)));//Common Parking
        CommonUtil.addListValidation(worksheet, "G2:G1048576", CommonUtil.getEnumValues(typeof(ParkingStatus)));//Parking Status
    }

    private void setResponse()
    {
        Response.Clear();
        Response.Buffer = true;
        Response.Charset = "";
        Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        Response.AddHeader("content-disposition", "attachment;filename=" + CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()).Name + ".xlsx");
    }

    private void fetchMaster(out List<MasterControlDataDTO> resultsParkingType)
    {
        resultsParkingType = masterDataBO.fetchMasterData(getUserDefinitionDTO().FirmNumber, Constants.MCDType.PR_PARKING_TYPE.ToString());
    }

    private void prepareHeader(ExcelWorksheet worksheet)
    {
        worksheet.Cells[1, 1].Value = "Property Name";
        worksheet.Cells[1, 2].Value = "Tower Name";
        worksheet.Cells[1, 3].Value = "Parking Number";
        worksheet.Cells[1, 4].Value = "Parking Type";
        worksheet.Cells[1, 5].Value = "Parking Area";
        worksheet.Cells[1, 6].Value = "Common Parking";
        worksheet.Cells[1, 7].Value = "Status";
        using (var range = worksheet.Cells[1, 1, 1, 7])
        {
            range.Style.Font.Bold = true;
            range.Style.Fill.PatternType = ExcelFillStyle.Solid;
            range.Style.Fill.BackgroundColor.SetColor(Color.Blue);
            range.Style.Font.Color.SetColor(Color.White);
        }
        worksheet.Cells["A1:G1048576"].AutoFilter = true;
        worksheet.Cells.AutoFitColumns(0);
    }
    protected void onClickUploadParkings(object sender, EventArgs e)
    {
        try
        {
            initPageInfo(PrParkingPageMode.UPLOAD_PARKING);
            txtUploadParkingProperty.Text = CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()).Name;
            pnlUploadParkingDetail.Visible = false;
            getSessionPageData().UploadFailedResult = new List<PropertyParkingDTO>();
            getSessionPageData().UploadSuccessResult = new List<PropertyParkingDTO>();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateFileType(string extension)
    {
        bool isValid = true;
        if (extension != ".xlsx" && extension != ".xls")
        {
            isValid = false;
            setErrorMessage("Please Select Property Parking Excel with extension xlsx or xls.", commonError);
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;

    }
    private List<PropertyParkingDTO> getUploadFailedList()
    {
        return getSessionPageData().UploadFailedResult;
    }
    private List<PropertyParkingDTO> getUploadSuccessList()
    {
        return getSessionPageData().UploadSuccessResult;
    }
    private bool isUploadSubmitToEnabled()
    {
        return getUploadSuccessList().Count > 0 && Constants.UPLOAD_VALIDATED.Equals(lbSuccessUploadParkingsText.Text);
    }
    public void addPropertyParkings(object sender, EventArgs e)
    {
        try
        {
            List<PropertyParkingDTO> uploadList = getUploadSuccessList();
            if (uploadList != null && uploadList.Count > 0)
            {
                List<PropertyParkingDTO> successList = new List<PropertyParkingDTO>();
                List<PropertyParkingDTO> failureList = new List<PropertyParkingDTO>();
                foreach (PropertyParkingDTO propertyParkingDTO in uploadList)
                {
                    if (!propertyParkingDTO.isError)
                    {
                        try
                        {
                            propertyBO.savePropertyParkingDetails(propertyParkingDTO);
                            successList.Add(propertyParkingDTO);
                        }
                        catch (Exception exp)
                        {
                            propertyParkingDTO.isError = true;
                            propertyParkingDTO.ErrorMessage = "Failed to upload, Please contact support for more details. ";
                            failureList.Add(propertyParkingDTO);
                        }
                    }
                }
                btnUploadParkingSubmit.Visible = false;
                string msg = (uploadList.Count == successList.Count) ? "Upload process is completed. All Property Parkings are uploaded successfully." :
                    "Upload process is completed. Some of the Property Parkings are not uploaded, Please check Failure records.";
                setSuccessMessage(msg);

                failureList.AddRange(getUploadFailedList());
                getSessionPageData().UploadFailedResult = failureList;
                getSessionPageData().UploadSuccessResult = successList;
                populateParkingUploadGrid(successList, "SUCCESS");

                lbSuccessUploadParkingsCount.Text = successList.Count + "";
                lbSuccessUploadParkingsText.Text = Constants.UPLOAD_SUCCESS;
                lbFailedUploadParkingsCount.Text = failureList.Count + "";
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }

    public void validatePropertyParkings(object sender, EventArgs e)
    {
        try
        {
            pnlUploadParkingDetail.Visible = false;
            HttpFileCollection uploadedFiles = Request.Files;
            List<PropertyParkingDTO> validationFailedList = new List<PropertyParkingDTO>();
            List<PropertyParkingDTO> validationSuccessList = new List<PropertyParkingDTO>();
            for (int i = 0; i < uploadedFiles.Count; i++)
            {
                HttpPostedFile userPostedFile = uploadedFiles[i];
                if (userPostedFile.ContentLength > 0)
                {
                    string filename = Path.GetFileName(userPostedFile.FileName);
                    string extension = Path.GetExtension(filename);
                    HttpPostedFile file = fileUploadParkings.PostedFile;
                    if (validateFileType(extension))
                    {
                        using (file.InputStream)
                        {
                            ExcelPackage excel = new ExcelPackage(file.InputStream);
                            var workSheet = excel.Workbook.Worksheets[1];
                            IEnumerable<PropertyParkingMapperDTO> newcollection = workSheet.ConvertSheetToObjects<PropertyParkingMapperDTO>();
                            foreach (PropertyParkingMapperDTO propertyParkingMapperDTO in newcollection)
                            {
                                if (!string.IsNullOrWhiteSpace(propertyParkingMapperDTO.PropertyName))
                                {
                                    PropertyParkingDTO propertyParkingDTO = populatePropertyParkingDTO(validationSuccessList, propertyParkingMapperDTO);
                                    if (propertyParkingDTO.isError)
                                    {
                                        validationFailedList.Add(propertyParkingDTO);
                                    }
                                    else
                                    {
                                        validationSuccessList.Add(propertyParkingDTO);
                                    }
                                }
                            }
                        }
                        pnlUploadParkingDetail.Visible = true;
                        getSessionPageData().UploadFailedResult = validationFailedList;
                        getSessionPageData().UploadSuccessResult = validationSuccessList;

                        lbTotalUploadParkingsCount.Text = (validationFailedList.Count + validationSuccessList.Count) + "";
                        lbSuccessUploadParkingsCount.Text = validationSuccessList.Count + "";
                        lbSuccessUploadParkingsText.Text = Constants.UPLOAD_VALIDATED;
                        lbFailedUploadParkingsCount.Text = validationFailedList.Count + "";
                        btnUploadParkingSubmit.Visible = isUploadSubmitToEnabled();
                        populateParkingUploadGrid(validationSuccessList, "SUCCESS");
                    }
                }
                else
                {
                    setErrorMessage("Please Select valid file to upload.", commonError);
                }
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    public void showUploadParkings(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            string mode = rd.Attributes["data-show"];
            btnUploadParkingSubmit.Visible = false;
            if ("ALL".Equals(mode))
            {
                List<PropertyParkingDTO> allParkings = new List<PropertyParkingDTO>();
                allParkings.AddRange(getUploadFailedList());
                allParkings.AddRange(getUploadSuccessList());
                btnUploadParkingSubmit.Visible = isUploadSubmitToEnabled();
                populateParkingUploadGrid(allParkings, mode);
            }
            else if ("SUCCESS".Equals(mode))
            {
                btnUploadParkingSubmit.Visible = isUploadSubmitToEnabled();
                populateParkingUploadGrid(getUploadSuccessList(), mode);
            }
            else if ("ERROR".Equals(mode))
            {
                populateParkingUploadGrid(getUploadFailedList(), mode);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    private void populateParkingUploadGrid(IList<PropertyParkingDTO> results, string mode)
    {
        parkingUploadGrid.Columns[6].Visible = "ALL".Equals(mode) && Constants.UPLOAD_SUCCESS.Equals(lbSuccessUploadParkingsText.Text);
        parkingUploadGrid.Columns[7].Visible = !"SUCCESS".Equals(mode);
        assignUiIndexToTaxDetail(results);
        parkingUploadGrid.DataSource = results;
        parkingUploadGrid.DataBind();
    }

    private void assignUiIndexToTaxDetail(IList<PropertyParkingDTO> results)
    {
        if (results != null && results.Count > 0)
        {
            long uiIndex = 1;
            foreach (PropertyParkingDTO parkingDto in results)
            {
                parkingDto.UiIndex = uiIndex++;
                parkingDto.RowInfo = CommonUIConverter.getGridViewRowInfo(parkingDto);
            }
        }
    }
    public PropertyParkingDTO populatePropertyParkingDTO(List<PropertyParkingDTO> parkingList, PropertyParkingMapperDTO propertyParkingMapperDTO)
    {
        PropertyParkingDTO propertyParkingDTO = new PropertyParkingDTO();
            StringBuilder sb = new StringBuilder();
            try
            {
                UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
                if (!propertyParkingMapperDTO.PropertyName.Equals(txtUploadParkingProperty.Text))
                {
                    sb.Append("Unit Belongs to different Property.");
                }
                if (propertyParkingMapperDTO.ParkingNumber == null)
                {
                    sb.Append("Parking Number Missing. ");
                }
                else
                {
                    propertyParkingDTO.ParkingNo = propertyParkingMapperDTO.ParkingNumber;
                }
                if (propertyParkingMapperDTO.ParkingType == null)
                {
                    sb.Append("Parking Type Missing. ");
                }
                else
                {
                    foreach (ListItem li in drpParkingType.Items)
                    {
                        if (li.Text.Equals(propertyParkingMapperDTO.ParkingType))
                        {
                            propertyParkingDTO.ParkingType = CommonUIConverter.getMasterControlDTO(li.Value, propertyParkingMapperDTO.ParkingType);
                        }
                    }
                }
                if (propertyParkingMapperDTO.ParkingArea == null)
                {
                    sb.Append("Parking Area Missing. ");
                }
                else
                {
                    propertyParkingDTO.Area = CommonUtil.getDecimalWithoutExt(propertyParkingMapperDTO.ParkingArea);
                }

                if (propertyParkingMapperDTO.Status == null)
                {
                    sb.Append("Status Missing. ");
                }
                else
                {
                    propertyParkingDTO.Status = EnumHelper.ToEnum<ParkingStatus>(propertyParkingMapperDTO.Status);
                }
                if (propertyParkingMapperDTO.CommonParking == null)
                {
                    sb.Append("Common Parking Missing. ");
                }
                else
                {
                    propertyParkingDTO.CommonParking = EnumHelper.ToEnum<CommonParking>(propertyParkingMapperDTO.CommonParking);

                }
                propertyParkingDTO.FirmNumber = userDefDto.FirmNumber;
                propertyParkingDTO.Version = userDefDto.Version;
                propertyParkingDTO.UpdateUser = userDefDto.Username;
                if (propertyParkingMapperDTO.TowerName == null)
                {
                    sb.Append("Tower Name Missing. ");
                }
                else
                {
                    propertyParkingDTO.PropertyTower = new PropertyTowerDTO();
                    foreach (ListItem li in drpTowerFilter.Items)
                    {
                        if (li.Text.Equals(propertyParkingMapperDTO.TowerName))
                        {
                            propertyParkingDTO.PropertyTower.Id = long.Parse(li.Value);
                            propertyParkingDTO.TowerName = propertyParkingMapperDTO.TowerName;
                        }
                    }
                }
                propertyParkingDTO.InsertUser = userDefDto.Username;
                if (propertyBO.validateParkingExist(propertyParkingDTO.FirmNumber, propertyParkingDTO.PropertyTower.Id, propertyParkingDTO.ParkingNo))
                {
                    sb.Append(string.Format(Resources.Messages.ERROR_SAME_NAME_EXIST, propertyParkingDTO.ParkingNo));
                }
                else
                {
                    foreach (PropertyParkingDTO parkingDTO in parkingList)
                    {
                        if (parkingDTO.ParkingNo.Equals(propertyParkingDTO.ParkingNo))
                        {
                            sb.Append("Duplicate Parking with same Parking No.");
                        }
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                sb.Append(exp.Message);
            }
            propertyParkingDTO.ErrorMessage = sb.ToString();
            return propertyParkingDTO;
        }
    //Bulk Upload - End
}