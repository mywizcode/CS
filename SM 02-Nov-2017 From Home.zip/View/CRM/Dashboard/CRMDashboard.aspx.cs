﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using System.Web.Script.Serialization;

public partial class CRMDashboard : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string VS_PROPERTY_LIST = "VS_PROPERTY_LIST";
    DropdownBO drpBO = new DropdownBO();
    DashboardBO dashboardBO = new DashboardBO();
    PropertyBO propertyBO = new PropertyBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                CRMDashboardNavDTO navDto = (CRMDashboardNavDTO)Session[Constants.Session.NAV_DTO];
                Session.Remove(Constants.Session.NAV_DTO);
                Session.Remove(Constants.Session.PAGE_DATA);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), false);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
        * This method is called just before the page is rendered. So any change in state of the element is applied.
        **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(CRMDashboardNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new CRMDashboardPageDTO();
        initDropdowns();
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(CRMDashboardNavDTO navDto)
    {
        try
        {
        	UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            int noOfMonths = (navDto != null) ? navDto.NoOfMonths : 1;
            setLdEnqTimePeriodText(noOfMonths);
            initLeadAndEnquiryStats(noOfMonths);
            
            PropertyTowerDTO towerDTO = CommonUtil.getStickyPrTowerDTO(userDefDto);
            long towerId = (navDto != null) ? navDto.TowerId : towerDTO.Id;
            CRMDashboardPageDTO PageDTO = getSessionPageData();
            PageDTO.NoOfMonths = noOfMonths;
            PageDTO.TowerId = towerId;
            initPostSaleStats(towerId);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageFieldsWithEntitlement()
    {
    }
    private CRMDashboardPageDTO getSessionPageData()
    {
        return (CRMDashboardPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private void initLeadAndEnquiryStats(int noOfMonths)
    {
        initLeadStats(noOfMonths);
        initEnquiryStats(noOfMonths);
    }
    private void initLeadStats(int noOfMonths) {
        PropertyDTO propertyDTO = CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO());
        object[] leadStats = dashboardBO.fetchLeadStatsForDashboard(propertyDTO.Id, noOfMonths);
    	LeadsOpenedGadgetDTO leadsOpenedGadgetDTO = (LeadsOpenedGadgetDTO)leadStats[0];
        List<EnquiryLeadSourceWiseCountDTO> LeadSrcDistList = (List<EnquiryLeadSourceWiseCountDTO>)leadStats[1];
        LeadsProcessedCountDTO leadsProcessedDto = (LeadsProcessedCountDTO)leadStats[2];
        //Init New leads opened gadget
        lbLeadsOpenGadgetTotalCount.Text = leadsOpenedGadgetDTO.TotalCount + "";
        lbLeadsOpenGadgetAverage.Text = leadsOpenedGadgetDTO.AverageOpened.ToString();
        var jsonSerialiser = new JavaScriptSerializer();
        LeadsNewOpenedDataHdn.Value = jsonSerialiser.Serialize(leadsOpenedGadgetDTO.LeadsOpenedList);
        //Init Lead stats gadget
        lbLeadsStatsGadgetTotalClosed.Text = leadsProcessedDto.TotalProcessed + "";
        lbLeadsStatsGadgetTotalConverted.Text = leadsProcessedDto.TotalConverted + "";
        lbLeadsStatsGadgetTotalLost.Text = leadsProcessedDto.TotalLost + "";
        //Init Source wise distribution
        LeadDistSrcWiseDataHdn.Value = jsonSerialiser.Serialize(LeadSrcDistList);
    }
    private void initEnquiryStats(int noOfMonths)
    {
        PropertyDTO propertyDTO = CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO());
        object[] enquiryStats = dashboardBO.fetchEnquiryStatsForDashboard(propertyDTO.Id, noOfMonths);
        List<EnquiryLeadSourceWiseCountDTO> enqSrcDistList = (List<EnquiryLeadSourceWiseCountDTO>)enquiryStats[0];
        List<EnquiryNewOpenAndCloseCountDTO> enqOpenClosedCountList = (List<EnquiryNewOpenAndCloseCountDTO>)enquiryStats[1];
        List<EnquiryCurrentOpenCountDTO> enqCurrentOpenList = (List<EnquiryCurrentOpenCountDTO>)enquiryStats[2];
        EnquiryCountStatsDTO enqCountStatsDTO = (EnquiryCountStatsDTO)enquiryStats[3];
        
        //Init New open and closed enquiries
        lbEnqStatsGadgetTotalLogged.Text = enqCountStatsDTO.TotalLogged + "";
        lbEnqStatsGadgetTotalClosed.Text = enqCountStatsDTO.TotalClosed + "";
        lbEnqStatsGadgetTotalOpen.Text = enqCountStatsDTO.TotalOpen + "";
        var jsonSerialiser = new JavaScriptSerializer();
        EnqNewOpenAndClosedDataHdn.Value = jsonSerialiser.Serialize(enqOpenClosedCountList);
        EnqDailyOpenDataHdn.Value = jsonSerialiser.Serialize(enqCurrentOpenList);
        
        //Init Source wise distribution
        EnqDistSrcWiseDataHdn.Value = jsonSerialiser.Serialize(enqSrcDistList);     
    }
    private void initPostSaleStats(long TowerId)
    {
    	UserDefinitionDTO userDefDto = getUserDefinitionDTO();
    	long propertyId = CommonUtil.getCurrentPropertyDTO(userDefDto).Id;
    	IList<PropertyTowerDTO> TowerList = propertyBO.fetchPropertyTowerSelective(userDefDto.FirmNumber, propertyId);
    	towerGrid.DataSource = TowerList;
    	towerGrid.DataBind();
        PropertyTowerDTO towerDTO = TowerList.ToList<PropertyTowerDTO>().Find(x => x.Id == TowerId);
    	lbSelectedTower.Text = towerDTO.Name;
    	//Fetch post sale property unit statistics for current tower
    	PropertyUnitStatsDTO UnitStatsDTO = dashboardBO.fetchPropertyUnitStats(towerDTO.Id);
        lbAvailableUnits.Text = UnitStatsDTO.Available + "";
        lbSoldUnits.Text = UnitStatsDTO.Sold + "";
        lbReservedUnits.Text = UnitStatsDTO.Reserved + "";
        var jsonSerialiser = new JavaScriptSerializer();
        UnitAvailableTypeWiseDataHdn.Value = jsonSerialiser.Serialize(UnitStatsDTO.UnitTypeCountList);
    }
    protected void onClickLeadEnqTimePeriodBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            int selectedId = int.Parse(rd.Attributes["data-pid"]);
            CRMDashboardNavDTO navDTO = new CRMDashboardNavDTO();
            navDTO.NoOfMonths = selectedId;
            navDTO.TowerId = getSessionPageData().TowerId;
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.CRM_DASHBOARD, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setLdEnqTimePeriodText(int noOfMOnths)
    {
        if (noOfMOnths == 1) lbSelectedLeadEnqTimePeriod.Text = "Last One Month";
        else if (noOfMOnths == 2) lbSelectedLeadEnqTimePeriod.Text = "Last Two Month";
        else lbSelectedLeadEnqTimePeriod.Text = "Last Three Month";
    }
    protected void onClickPostSaleTowerBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            int selectedId = int.Parse(rd.Attributes["data-pid"]);
            //TODO - set new selected tower as sticky key
            CRMDashboardNavDTO navDTO = new CRMDashboardNavDTO();
            navDTO.NoOfMonths = getSessionPageData().NoOfMonths;
            navDTO.TowerId = selectedId;
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.CRM_DASHBOARD, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
}
