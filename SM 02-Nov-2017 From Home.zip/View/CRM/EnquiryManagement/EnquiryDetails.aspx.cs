﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using ConstroSoft.Logic.BO;

public partial class EnquiryDetails : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addMasterDataError = "addMasterDataError";
    string addModifyStep1Error = "addModifyStep1Error";
    string addModifyAddressError = "addModifyAddressError";
    string addMasterDataModal = "addMasterDataModal";
    string addModifyAddressModal = "addModifyAddressModal";
    DropdownBO drpBO = new DropdownBO();
    EnquiryBO enquiryBO = new EnquiryBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    public enum AddressAction { ADD, MODIFY }
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                EnquiryDetailNavDTO navDto = (EnquiryDetailNavDTO)Session[Constants.Session.NAV_DTO];
                Session.Remove(Constants.Session.NAV_DTO);
                Session.Remove(Constants.Session.PAGE_DATA);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), false);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();

    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
        setPageTitle();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpSalutation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.SALUTATION, null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpOccupation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.OCCUPATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpUnitType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<Gender>(drpGender, Constants.SELECT_ITEM);
        drpBO.drpEnum<MaritalStatus>(drpMaritalStatus, Constants.SELECT_ITEM);

        drpBO.drpEnum<EnquiryStatus>(drpEnquiryStatus, null);
        drpBO.drpDataBase(drpEnquirySource, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ENQUIRY_SOURCE, Constants.SELECT_ITEM, userDefDto.FirmNumber);

        drpBO.drpDataBase(drpAddressCountry, DrpDataType.COUNTRY, null, null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAddressState, DrpDataType.STATE, Constants.DEFAULT_COUNTRY, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        initCityDrp(drpAddressCity, Constants.DEFAULT_STATE);
        drpBO.drpDataBase(drpAddressType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ADDRESS_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<PreferredAddress>(drpPreferredAddress, null);
    }
    private void initCityDrp(DropDownList drp, string stateId)
    {
        drpBO.drpDataBase(drp, DrpDataType.CITY, stateId, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(EnquiryDetailNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(EnquiryDetailNavDTO navDto)
    {
        try
        {
            EnquiryDetailPageDTO PageDTO = new EnquiryDetailPageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            pageModeHdn.Value = navDto.Mode.ToString();
            if (isAddMode())
            {
                PageDTO.EnquiryDTO = populateEnquiryDTOAdd();
                if (navDto.ConvertedLeadId > 0)
                {
                    PageDTO.LeadDTO = enquiryBO.fetchLeadDetails(navDto.ConvertedLeadId, false);
                }
                populateUIFieldsFromEnquiryDTO(null, PageDTO.LeadDTO);
            }
            else
            {
                PageDTO.EnquiryDTO = enquiryBO.fetchEnquiryDetails(navDto.EnquiryId, false);
                if (PageDTO.EnquiryDTO.Status != EnquiryStatus.Open) pageModeHdn.Value = PageMode.VIEW.ToString();
                populateUIFieldsFromEnquiryDTO(PageDTO.EnquiryDTO, null);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void setPageTitle()
    {
        if (isModifyMode()) lbPageTitle.Text = Constants.ICON.MODIFY + Resources.Labels.MODIFY_ENQUIRY;
        if (isAddMode()) lbPageTitle.Text = Constants.ICON.MODIFY + Resources.Labels.ADD_ENQUIRY;
        else if (isViewMode()) lbPageTitle.Text = Constants.ICON.VIEW_DTL + Resources.Labels.ENQUIRY_DETAILS;
    }
    private void renderPageFieldsWithEntitlement()
    {
    	bool modifyMode = isModifyMode();
    	bool viewMode = isViewMode();
    	bool addMode = isAddMode();
    	
    	//Fields
        drpSalutation.Enabled = addMode;
        txtFirstName.ReadOnly = !addMode;
        txtMiddleName.ReadOnly = !addMode;
        txtLastName.ReadOnly = !addMode;
        drpGender.Enabled = !viewMode;
        txtDOB.ReadOnly = viewMode;
        drpMaritalStatus.Enabled = !viewMode;
        txtContact.ReadOnly = viewMode;
        txtAltContact.ReadOnly = viewMode;
        txtEmail.ReadOnly = viewMode;
        txtAltEmailID.ReadOnly = viewMode;
        drpOccupation.Enabled = !viewMode;

        txtEnquiryDate.ReadOnly = !addMode;
        drpEnquirySource.Enabled = addMode;
        drpUnitType.Enabled = !viewMode;
        txtEnquiryBudget.ReadOnly = viewMode;
        drpEnquiryStatus.Enabled = false;
        txtComments.ReadOnly = viewMode;

        lnkAddAddress.Visible = !viewMode;
        if (addressGrid.Items.Count > 0)
        {
            foreach (ListViewItem item in addressGrid.Items)
            {
                LinkButton modifyBtn = (LinkButton)item.FindControl("lnkModifyAddress");
                if (modifyBtn != null) modifyBtn.Visible = !viewMode;
                LinkButton deleteBtn = (LinkButton)item.FindControl("lnkDeleteAddress");
                if (deleteBtn != null) deleteBtn.Visible = !viewMode;
            }
        }
        //Buttons
        btnAddModifyEnquirySubmit.Visible = !viewMode;
        lnkAddOccupation.Visible = !viewMode;
        lnkAddLeadSource.Visible = addMode;

        //SubHeader links/Other btns with entitlement
        EnquiryDetailDTO enquiryDTO = getEnquiryDTO();
        lnkModifyEnquiry.Visible = viewMode && (enquiryDTO.Status == EnquiryStatus.Open);
        lnkNavToSoldUnit.Visible = !addMode && (enquiryDTO.Status != EnquiryStatus.Open && enquiryDTO.PrUnitSaleDetail != null);
    	
    }
    private void navigateToPreviousPage()
    {
        EnquiryDetailPageDTO PageDTO = getSessionPageData();
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is EnquirySearchPageDTO)
            {
                EnquirySearchPageDTO navDTO = (EnquirySearchPageDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.ENQUIRY_SEARCH, true);
            } else if (obj is MyLeadsNavDTO)
            {
            	MyLeadsNavDTO navDTO = (MyLeadsNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.MY_LEADS, true);
            }
            else if (obj is UserEnquiryHistoryNavDTO)
            {
                UserEnquiryHistoryNavDTO navDTO = (UserEnquiryHistoryNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.USER_ENQUIRY_HISTORY, true);
            }
            else if (obj is UserLeadHistoryNavDTO)
            {
                UserLeadHistoryNavDTO navDTO = (UserLeadHistoryNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.USER_LEAD_HISTORY, true);
            }
            else if (obj is LeadActivityHistoryNavDTO)
            {
                LeadActivityHistoryNavDTO navDTO = (LeadActivityHistoryNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.LEAD_ACTIVITY_HISTORY, true);
            }
        }
        Response.Redirect(Constants.URL.ENQUIRY_SEARCH, true);
    }
    private EnquiryDetailPageDTO getSessionPageData()
    {
        return (EnquiryDetailPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private EnquiryDetailDTO getEnquiryDTO()
    {
        return getSessionPageData().EnquiryDTO;
    }
    private bool isModifyMode()
    {
        return PageMode.MODIFY.ToString().Equals(pageModeHdn.Value);
    }
    private bool isViewMode()
    {
        return PageMode.VIEW.ToString().Equals(pageModeHdn.Value);
    }
    private bool isAddMode()
    {
        return PageMode.ADD.ToString().Equals(pageModeHdn.Value);
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private EnquiryDetailNavDTO getCurrentPageNavigation()
    {
        EnquiryDetailPageDTO PageDTO = getSessionPageData();
        EnquiryDetailNavDTO navDTO = new EnquiryDetailNavDTO();
        navDTO.Mode = EnumHelper.ToEnum<PageMode>(pageModeHdn.Value);
        navDTO.EnquiryId = PageDTO.EnquiryDTO.Id;
        navDTO.PrevNavDto = PageDTO.PrevNavDTO;
        return navDTO;
    }
    protected void onClickModifyEnquiryBtn(object sender, EventArgs e)
    {
        try
        {
        	pageModeHdn.Value = PageMode.MODIFY.ToString();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickNavToEnqActivityHistory(object sender, EventArgs e)
    {
        try
        {
        	EnquiryDetailPageDTO PageDTO = getSessionPageData();
        	EnquiryActivityHistoryNavDTO navDTO = new EnquiryActivityHistoryNavDTO();
            navDTO.EnquiryId = PageDTO.EnquiryDTO.Id;
            navDTO.PrevNavDto = getCurrentPageNavigation();
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.ENQUIRY_ACTIVITY_HISTORY, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickNavToSoldUnit(object sender, EventArgs e)
    {
        try
        {
        	EnquiryDetailDTO enquiryDTO = getEnquiryDTO();
        	if (enquiryDTO.Status != EnquiryStatus.Open && enquiryDTO.PrUnitSaleDetail != null) {
        		if(enquiryDTO.PrUnitSaleDetail.Status == PRUnitSaleStatus.Sold) {
        			SoldUnitDetailNavDTO navDTO = new SoldUnitDetailNavDTO();
                    navDTO.Mode = PageMode.VIEW;
                    navDTO.PrUnitSaleDetailId = enquiryDTO.PrUnitSaleDetail.Id;
                    navDTO.PrevNavDto = getCurrentPageNavigation();
                    Session[Constants.Session.NAV_DTO] = navDTO;
                    Response.Redirect(Constants.URL.SOLD_UNIT_DETAILS, true);
        		} else {
        			CancelledUnitDetailNavDTO navDTO = new CancelledUnitDetailNavDTO();
                    navDTO.Mode = PageMode.VIEW;
                    navDTO.PrUnitSaleDetailId = enquiryDTO.PrUnitSaleDetail.Id;
                    navDTO.PrevNavDto = getCurrentPageNavigation();
                    Session[Constants.Session.NAV_DTO] = navDTO;
                    Response.Redirect(Constants.URL.CANCELLED_UNIT_DETAILS, true);
        		}
        	} else {
        		setNotyMsg(CommonUtil.getNotySuccessMsg("Property Unit is not Booked against this Enquiry."));
        	}
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void addOrModifyEnquiry(object sender, EventArgs e)
    {
        try
        {
            if (validateEnquiryAddOrModify())
            {
                EnquiryDetailPageDTO PageDTO = getSessionPageData();
                EnquiryDetailDTO enquiryDTO = PageDTO.EnquiryDTO;
                populateEnquiryDTOFromUI(enquiryDTO);
                string enquiryRefNo = enquiryDTO.EnquiryRefNo;
                if (isAddMode())
                {
                    enquiryRefNo = enquiryBO.addEnquiryDetails(enquiryDTO, getUserDefinitionDTO());
                    Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg(string.Format("Enquiry #{0} is added successfully.", enquiryRefNo)));
                }
                else if (isModifyMode())
                {
                    enquiryBO.updateEnquiry(enquiryDTO);
                    Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg(string.Format("Enquiry #{0} is updated successfully.", enquiryRefNo)));
                }
                EnquiryDetailNavDTO navDTO = new EnquiryDetailNavDTO();
                navDTO.Mode = PageMode.VIEW;
                navDTO.EnquiryId = enquiryDTO.Id;
                navDTO.PrevNavDto = PageDTO.PrevNavDTO;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.ENQUIRY_DETAILS, true);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelEnquiryDetail(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateEnquiryAddOrModify()
    {
        return validateMandatoryFields(addModifyStep1Error);
    }
    private bool validateAddressMandatory()
    {
        bool isValid = true;
        List<AddressDTO> addressList = getEnquiryDTO().ContactInfo.Addresses.ToList<AddressDTO>();
        if (addressList == null || addressList.Count == 0)
        {
            setErrorMessage(Resources.Messages.ADDRESS_MANDATORY, addModifyStep1Error);
            isValid = false;
        }
        else
        {
            int preferredCount = 0;
            foreach (AddressDTO addressDto in addressList)
            {
                if (PreferredAddress.Yes == addressDto.PreferredAddress) preferredCount++;
            }
            if (preferredCount == 0)
            {
                setErrorMessage(Resources.Messages.PRIMARY_ADDRESS_MANDATORY, addModifyStep1Error);
                isValid = false;
            }
            else if (preferredCount > 1)
            {
                setErrorMessage(Resources.Messages.PRIMARY_ADDRESS_MULTIPLE_NOT_ALLOWED, addModifyStep1Error);
                isValid = false;
            }
        }
        return isValid;
    }
    private bool validateMandatoryFields(string valGrp)
    {
        Page.Validate(valGrp);
        bool isValid = Page.IsValid;
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    private EnquiryDetailDTO populateEnquiryDTOAdd()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        EnquiryDetailDTO enquiryDTO = new EnquiryDetailDTO();
        enquiryDTO.ContactInfo = new ContactInfoDTO();
        enquiryDTO.ContactInfo.Addresses = new HashSet<AddressDTO>();
        enquiryDTO.FirmNumber = userDefDto.FirmNumber;
        enquiryDTO.InsertUser = userDefDto.Username;
        return enquiryDTO;
    }
    private void populateEnquiryDTOFromUI(EnquiryDetailDTO enquiryDTO)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        if (isAddMode())
        {
            enquiryDTO.Salutation = CommonUIConverter.getMasterControlDTO(drpSalutation.Text, null);
            enquiryDTO.FirstName = txtFirstName.Text;
            enquiryDTO.MiddleName = txtMiddleName.Text;
            enquiryDTO.LastName = txtLastName.Text;

            enquiryDTO.Assignee = CommonUIConverter.getFirmMemberDTO(userDefDto.FirmMember.Id.ToString(), null);
            enquiryDTO.AssignedDate = DateTime.Today;
            enquiryDTO.EnquiryDate = CommonUtil.getCSDateNotNull(txtEnquiryDate.Text);
            enquiryDTO.EnquirySource = CommonUIConverter.getMasterControlDTO(drpEnquirySource.Text, null);
            enquiryDTO.Property = CommonUIConverter.getPropertyDTO(CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(), null);
            enquiryDTO.Status = EnquiryStatus.Open;

            enquiryDTO.Lead = getSessionPageData().LeadDTO;
        }
        enquiryDTO.Occupation = CommonUIConverter.getMasterControlDTO(drpOccupation.Text, null);
        enquiryDTO.ContactInfo.Gender = EnumHelper.ToEnumNullable<Gender>(drpGender.Text);
        enquiryDTO.ContactInfo.Dob = CommonUtil.getCSDate(txtDOB.Text);
        enquiryDTO.ContactInfo.MaritalStatus = EnumHelper.ToEnumNullable<MaritalStatus>(drpMaritalStatus.Text);
        enquiryDTO.ContactInfo.Contact = txtContact.Text;
        enquiryDTO.ContactInfo.AltContact = txtAltContact.Text;
        enquiryDTO.ContactInfo.Email = txtEmail.Text;
        enquiryDTO.ContactInfo.AltEmail = txtAltEmailID.Text;

        enquiryDTO.PrUnitType = CommonUIConverter.getMasterControlDTO(drpUnitType.Text, null);
        enquiryDTO.Budget = CommonUtil.getDecimaNotNulllWithoutExt(txtEnquiryBudget.Text);
        enquiryDTO.Comments = txtComments.Text;

        enquiryDTO.UpdateUser = userDefDto.Username;
        enquiryDTO.Version = userDefDto.Version;
    }
    private void populateUIFieldsFromEnquiryDTO(EnquiryDetailDTO enquiryDTO, LeadDetailDTO leadDTO)
    {
        if (enquiryDTO != null && enquiryDTO.Salutation != null) drpSalutation.Text = enquiryDTO.Salutation.Id.ToString(); else drpSalutation.ClearSelection();
        if (enquiryDTO != null) txtFirstName.Text = enquiryDTO.FirstName; else txtFirstName.Text = null;
        if (enquiryDTO != null) txtMiddleName.Text = enquiryDTO.MiddleName; else txtMiddleName.Text = null;
        if (enquiryDTO != null) txtLastName.Text = enquiryDTO.LastName; else txtLastName.Text = null;
        if (enquiryDTO != null && enquiryDTO.ContactInfo.Gender != null) drpGender.Text = enquiryDTO.ContactInfo.Gender.ToString(); else drpGender.ClearSelection();
        if (enquiryDTO != null) txtDOB.Text = CommonUtil.getCSDate(enquiryDTO.ContactInfo.Dob); else txtDOB.Text = null;
        if (enquiryDTO != null && enquiryDTO.ContactInfo.MaritalStatus != null) drpMaritalStatus.Text = enquiryDTO.ContactInfo.MaritalStatus.ToString(); else drpMaritalStatus.ClearSelection();
        if (enquiryDTO != null) txtContact.Text = enquiryDTO.ContactInfo.Contact; else txtContact.Text = null;
        if (enquiryDTO != null) txtAltContact.Text = enquiryDTO.ContactInfo.AltContact; else txtAltContact.Text = null;
        if (enquiryDTO != null) txtEmail.Text = enquiryDTO.ContactInfo.Email; else txtEmail.Text = null;
        if (enquiryDTO != null) txtAltEmailID.Text = enquiryDTO.ContactInfo.AltEmail; else txtAltEmailID.Text = null;
        if (enquiryDTO != null && enquiryDTO.Occupation != null) drpOccupation.Text = enquiryDTO.Occupation.Id.ToString(); else drpOccupation.ClearSelection();

        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        if (enquiryDTO != null) txtAssignee.Text = CommonUIConverter.getCustomerFullName(enquiryDTO.Assignee.FirstName, enquiryDTO.Assignee.LastName);
        else txtAssignee.Text = CommonUIConverter.getCustomerFullName(userDefDTO.FirmMember.FirstName, userDefDTO.FirmMember.LastName);
        if (enquiryDTO != null) txtEnquiryDate.Text = CommonUtil.getCSDate(enquiryDTO.EnquiryDate); else txtEnquiryDate.Text = CommonUtil.getTodayDate();
        if (enquiryDTO != null && enquiryDTO.EnquirySource != null) drpEnquirySource.Text = enquiryDTO.EnquirySource.Id.ToString(); else drpEnquirySource.ClearSelection();
        if (enquiryDTO != null) txtEnquiryProperty.Text = enquiryDTO.Property.Name;
        else txtEnquiryProperty.Text = CommonUtil.getCurrentPropertyDTO(userDefDTO).Name;
        if (enquiryDTO != null && enquiryDTO.PrUnitType != null) drpUnitType.Text = enquiryDTO.PrUnitType.Id.ToString(); else drpUnitType.ClearSelection();
        if (enquiryDTO != null && enquiryDTO.Budget != null) txtEnquiryBudget.Text = enquiryDTO.Budget.ToString(); else txtEnquiryBudget.Text = null;
        if (enquiryDTO != null) drpEnquiryStatus.Text = enquiryDTO.Status.ToString(); else drpEnquiryStatus.Text = EnquiryStatus.Open.ToString();
        if (enquiryDTO != null) txtComments.Text = enquiryDTO.Comments; else txtComments.Text = null;

        if (isAddMode())
        {
            lbLeadRefNo.Visible = (leadDTO != null);
            lbLeadRefNo.Text = (leadDTO != null) ? "Lead# "+ leadDTO.LeadRefNo : "";
            populateFormFromLead(leadDTO);
        }
        else
        {
            lbLeadRefNo.Visible = (enquiryDTO.Lead != null && !string.IsNullOrWhiteSpace(enquiryDTO.Lead.LeadRefNo));
            lbLeadRefNo.Text = (enquiryDTO.Lead != null) ? "Lead# " + enquiryDTO.Lead.LeadRefNo : "";
            lbEnquiryRefNo.Visible = true;
            lbEnquiryRefNo.Text = "Enquiry# " + enquiryDTO.EnquiryRefNo;
        }
        pnlEnquiryLeadRefNo.Visible = lbEnquiryRefNo.Visible || lbLeadRefNo.Visible;

        populateAddressGrid(enquiryDTO);
    }
    private void populateFormFromLead(LeadDetailDTO leadDTO)
    {
        if (leadDTO != null)
        {
            drpSalutation.Text = leadDTO.Salutation.Id.ToString();
            txtFirstName.Text = leadDTO.FirstName;
            txtMiddleName.Text = leadDTO.MiddleName;
            txtLastName.Text = leadDTO.LastName;
            txtContact.Text = leadDTO.ContactInfo.Contact;
            txtAltContact.Text = leadDTO.ContactInfo.AltContact;
            txtEmail.Text = leadDTO.ContactInfo.Email;
            txtEnquiryBudget.Text = (leadDTO.Budget != null) ? leadDTO.Budget.ToString() : null;
            drpEnquirySource.Text = leadDTO.Source.Id.ToString();
        }
    }
    private void populateAddressGrid(EnquiryDetailDTO enquiryDTO)
    {
        ContactInfoDTO conactInfoDto = enquiryDTO != null ? enquiryDTO.ContactInfo : null;
        addressGrid.DataSource = new List<AddressDTO>();
        if (conactInfoDto != null)
        {
            assignUiIndexToAddress(conactInfoDto.Addresses);
            addressGrid.DataSource = conactInfoDto.Addresses;
        }
        addressGrid.DataBind();
        pnlAddressEmpty.Visible = (conactInfoDto == null || conactInfoDto.Addresses == null || conactInfoDto.Addresses.Count == 0);
    }

    private void assignUiIndexToAddress(ISet<AddressDTO> addressDtos)
    {
        if (addressDtos != null && addressDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (AddressDTO addressDto in addressDtos)
            {
                addressDto.UiIndex = uiIndex++;
                addressDto.UiFullAddress = CommonUIConverter.getUiFullAddress(addressDto);
            }
        }
    }
    //Master Data Modal save logic - Start
    protected void saveMasterData(object sender, EventArgs e)
    {
        try
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (masterDataModalTypeHdn.Value == "OCCUPATION")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.OCCUPATION, txtMasterDataInput1.Text,
                        txtMasterDataInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Occupation");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpOccupation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.OCCUPATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
            }
            else if (masterDataModalTypeHdn.Value == "ENQUIRY_SOURCE")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.ENQUIRY_SOURCE, txtMasterDataInput1.Text,
                        txtMasterDataInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Enquiry/Lead Source");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpEnquirySource, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ENQUIRY_SOURCE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
            }

            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                activeModalHdn.Value = addMasterDataModal;
                setErrorMessage(errorMsg, addMasterDataError);
            }
            else
            {
                resetMasterDataModalFields();
                setParentModalFlag();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            activeModalHdn.Value = "";
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    protected void cancelMasterDataModal(object sender, EventArgs e)
    {
        try
        {
            resetMasterDataModalFields();
            setParentModalFlag();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    private void resetMasterDataModalFields()
    {
        txtMasterDataInput1.Text = "";
        txtMasterDataInput2.Text = "";
        masterDataModalTypeHdn.Value = "";
    }
    private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
    {
        string errorMsg = "";
        if (string.IsNullOrWhiteSpace(masterDataDto.Name))
        {
            errorMsg = string.Format(Resources.Messages.TEXTFIELD_REQUIRED, type);
        }
        else if (masterDataBO.isAlreadyExist(masterDataDto))
        {
            errorMsg = string.Format(Resources.Messages.ALREADY_EXIST_DB_ERROR, type);
        }
        return errorMsg;
    }
    private void setParentModalFlag()
    {
        activeModalHdn.Value = masterDataParentModalHdn.Value;
        masterDataParentModalHdn.Value = "";
    }
    //Master Data Modal save logic - End
    //Address Modal - Start
    protected void loadAddressCities(object sender, EventArgs e)
    {
        try
        {
            initCityDrp(drpAddressCity, drpAddressState.Text);
            SetFocus(drpAddressCity);
            activeModalHdn.Value = addModifyAddressModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void initAddressModalFields()
    {
        lbAddressModalTitle.Text = (AddressAction.ADD.ToString().Equals(addressModalActionHdnBtn.Value))
            ? Constants.ICON.ADD + Resources.Labels.ADD_ADDRESS : Constants.ICON.MODIFY + Resources.Labels.MODIFY_ADDRESS;
    }
    private void initAddressSectionFields(AddressDTO addressDto)
    {
        if (addressDto != null) txtAddressLine1.Text = addressDto.AddressLine1; else txtAddressLine1.Text = null;
        if (addressDto != null) txtAddressLine2.Text = addressDto.AddressLine2; else txtAddressLine2.Text = null;
        if (addressDto != null) txtTown.Text = addressDto.Town; else txtTown.Text = null;
        if (addressDto != null && addressDto.City != null) drpAddressCity.Text = addressDto.City.Id.ToString(); else drpAddressCity.ClearSelection();
        if (addressDto != null && addressDto.State != null) drpAddressState.Text = addressDto.State.Id.ToString(); else drpAddressState.ClearSelection();
        if (addressDto != null && addressDto.Country != null) drpAddressCountry.Text = addressDto.Country.Id.ToString(); else drpAddressCountry.ClearSelection();
        if (addressDto != null) txtPin.Text = addressDto.Pin; else txtPin.Text = null;
        if (addressDto != null && addressDto.AddressType != null) drpAddressType.Text = addressDto.AddressType.Id.ToString(); else drpAddressType.ClearSelection();
        if (addressDto != null && addressDto.PreferredAddress != null) drpPreferredAddress.Text = addressDto.PreferredAddress.ToString(); else drpPreferredAddress.ClearSelection();
    }
    private void populateAddressFromUI(AddressDTO addressDto)
    {
        addressDto.AddressLine1 = txtAddressLine1.Text;
        addressDto.AddressLine2 = txtAddressLine2.Text;
        addressDto.Town = txtTown.Text;
        addressDto.City = CommonUIConverter.getCityDTO(drpAddressCity.Text, drpAddressCity.SelectedItem.Text);
        addressDto.State = CommonUIConverter.getStateDTO(drpAddressState.Text, drpAddressState.SelectedItem.Text);
        addressDto.Country = CommonUIConverter.getCountryDTO(drpAddressCountry.Text, drpAddressCountry.SelectedItem.Text);
        addressDto.Pin = txtPin.Text;
        addressDto.AddressType = CommonUIConverter.getMasterControlDTO(drpAddressType.Text, drpAddressType.SelectedItem.Text);
        addressDto.PreferredAddress = EnumHelper.ToEnumNullable<PreferredAddress>(drpPreferredAddress.Text);
    }
    private AddressDTO populateAddressAdd()
    {
        AddressDTO addressDto = new AddressDTO();
        return addressDto;
    }
    private void setSelectedAddress(long UiIndex)
    {
        List<AddressDTO> addressList = getEnquiryDTO().ContactInfo.Addresses.ToList<AddressDTO>();
        addressList.ForEach(c => c.isUISelected = false);
        if (UiIndex > 0) addressList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
    }
    private AddressDTO getSelectedAddress(long UiIndex)
    {
        List<AddressDTO> addressList = getEnquiryDTO().ContactInfo.Addresses.ToList<AddressDTO>();
        return (UiIndex > 0) ? addressList.Find(c => c.UiIndex == UiIndex) : addressList.Find(c => c.isUISelected);
    }
    protected void onClickAddAddressBtn(object sender, EventArgs e)
    {
        try
        {
            addressModalActionHdnBtn.Value = AddressAction.ADD.ToString();
            initAddressModalFields();
            setSelectedAddress(-1);
            initAddressSectionFields(null);
            activeModalHdn.Value = addModifyAddressModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyAddressBtn(object sender, EventArgs e)
    {
        try
        {
            addressModalActionHdnBtn.Value = AddressAction.MODIFY.ToString();
            initAddressModalFields();
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedAddress(selectedIndex);
            initAddressSectionFields(getSelectedAddress(0));
            activeModalHdn.Value = addModifyAddressModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void deleteAddress(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            AddressDTO addressDTO = getSelectedAddress(selectedIndex);
            getEnquiryDTO().ContactInfo.Addresses.Remove(addressDTO);
            populateAddressGrid(getEnquiryDTO());
            setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECORD_DELETE_SUCCESS, "Address")));
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void saveAddress(object sender, EventArgs e)
    {
        try
        {
            if (validateAddressAddModify())
            {
                AddressDTO addressDTO = null;
                string msg = "";
                if (AddressAction.ADD.ToString().Equals(addressModalActionHdnBtn.Value))
                {
                    addressDTO = populateAddressAdd();
                    getEnquiryDTO().ContactInfo.Addresses.Add(addressDTO);
                    msg = string.Format(Resources.Messages.RECORD_ADDED_SUCCESS, "Address");
                }
                else
                {
                    addressDTO = getSelectedAddress(0);
                    msg = string.Format(Resources.Messages.RECORD_MODIFY_SUCCESS, "Address");
                }
                populateAddressFromUI(addressDTO);
                populateAddressGrid(getEnquiryDTO());
                setNotyMsg(CommonUtil.getNotySuccessMsg(msg));
            }
            else
            {
                activeModalHdn.Value = addModifyAddressModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelAddressModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateAddressAddModify()
    {
        bool isValid = true;
        Page.Validate(addModifyAddressError);
        isValid = Page.IsValid;
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    //Address Modal - End
}