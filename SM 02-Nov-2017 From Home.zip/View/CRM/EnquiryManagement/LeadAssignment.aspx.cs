﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using ConstroSoft.Logic.BO;

public partial class LeadAssignment : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string NEW_LEAD_TAB = "NEW_LEAD_TAB";
    string ASSIGNED_LEAD_TAB = "ASSIGNED_LEAD_TAB";
    DropdownBO drpBO = new DropdownBO();
    EnquiryBO enquiryBO = new EnquiryBO();

    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                LeadAssignmentNavDTO navDto = (LeadAssignmentNavDTO)Session[Constants.Session.NAV_DTO];
                Session.Remove(Constants.Session.NAV_DTO);
                Session.Remove(Constants.Session.PAGE_DATA);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), false);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        drpBO.drpDataBase(drpNewAssignee, DrpDataType.ACTIVE_USERS_WITH_PR_ACCESS, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(),
           Constants.SELECT_ITEM, userDefDto.FirmNumber);
    }
    private void preRenderInitFormElements()
    {
        renderPageLayout();
        addCheckBoxAttributes();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpNewAssignee, DrpDataType.ACTIVE_USERS_WITH_PR_ACCESS, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(),
           Constants.SELECT_ITEM, userDefDto.FirmNumber);
    }
    private void addCheckBoxAttributes()
    {
        foreach (ListViewItem item in newLeadsGrid.Items)
        {
            CheckBox chBox = (CheckBox)item.FindControl("cbSelectNewLead");
            if (chBox != null)
            {
                chBox.InputAttributes.Add("class", "styled block-ui-change");
                chBox.InputAttributes.Add("data-panel", "blockui-panel-1");
            }
        }

        foreach (ListViewItem item in assignedLeadsGrid.Items)
        {
            CheckBox chBox = (CheckBox)item.FindControl("cbSelectAssignedLead");
            if (chBox != null)
            {
                chBox.InputAttributes.Add("class", "styled block-ui-change");
                chBox.InputAttributes.Add("data-panel", "blockui-panel-1");
            }
        }

        foreach (GridViewRow item in allEnquiryLeadSearchGrid.Rows)
        {
            GroupRadioButton rd = (GroupRadioButton)item.FindControl("rdUserSelect");
            if (rd != null)
            {
                rd.InputAttributes.Add("class", "block-ui-change");
                rd.InputAttributes.Add("data-panel", "blockui-panel-1");
            }
        }
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(LeadAssignmentNavDTO navDto)
    {
        LeadAssignmentPageDTO PageDTO = new LeadAssignmentPageDTO();
        PageDTO.NewLeads = new List<UserLeadHistoryUIDTO>();
        PageDTO.AssignedLeads = new List<UserLeadHistoryUIDTO>();
        Session[Constants.Session.PAGE_DATA] = PageDTO;
        initDropdowns();
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(LeadAssignmentNavDTO navDto)
    {
        try
        {
            loadAndInitPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageLayout()
    {
    	enableTab();
    }
    private LeadAssignmentPageDTO getSessionPageData()
    {
        return (LeadAssignmentPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<AllEnquiryLeadUIDTO> getSearchList()
    {
        return getSessionPageData().SearchResult;
    }
    private void setTabEnabled(string tabName)
    {
    	btnActiveTabHdn.Value = tabName;
    }
    private void enableTab()
    {
    	bool isNewLeads = (NEW_LEAD_TAB.Equals(btnActiveTabHdn.Value));
        LeadAssignmentPageDTO PageDTO = getSessionPageData();
        liNewLeads.Attributes["class"] = (isNewLeads) ? "active" : "";
        liReassignLeads.Attributes["class"] = (isNewLeads) ? "" : "active";
        pnlNewLeadsEmpty.Visible = (isNewLeads && PageDTO.NewLeads.Count == 0);
        pnlNewLeads.Visible = (isNewLeads && PageDTO.NewLeads.Count > 0);
        pnlAssignedLeadsEmpty.Visible = (!isNewLeads && PageDTO.AssignedLeads.Count == 0);
        pnlAssignedLeads.Visible = (!isNewLeads && PageDTO.AssignedLeads.Count > 0);
    }
    private AllEnquiryLeadUIDTO getSearchEnquiryLeadDTO(long Id)
    {
        List<AllEnquiryLeadUIDTO> searchList = getSearchList();
        AllEnquiryLeadUIDTO selectedDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            selectedDTO = searchList.Find(c => c.FirmMemberId == Id);
        }
        return selectedDTO;
    }
    private void loadAndInitPage()
    {
        setTabEnabled(NEW_LEAD_TAB);
        LeadAssignmentPageDTO PageDTO = getSessionPageData();
        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        PropertyDTO property = CommonUtil.getCurrentPropertyDTO(userDefDTO);
        List<AllEnquiryLeadUIDTO> allEnqLeadList = enquiryBO.fetchAllEnquiryLeadData(property.Id);
        PageDTO.SearchResult = (allEnqLeadList != null) ? allEnqLeadList : new List<AllEnquiryLeadUIDTO>();
        allEnquiryLeadSearchGrid.DataSource = PageDTO.SearchResult;
        allEnquiryLeadSearchGrid.DataBind();

        List<UserLeadHistoryUIDTO> unassignedLeadList = enquiryBO.fetchUnAssignedLeads(property.Id);
        PageDTO.NewLeads = (unassignedLeadList != null) ? unassignedLeadList : new List<UserLeadHistoryUIDTO>();
        setNewLeadGrid(PageDTO.NewLeads);
        
        loadAssignedLeadsForUser();
    }
    private void setNewLeadGrid(List<UserLeadHistoryUIDTO> list) {
    	newLeadsGrid.DataSource = list;
    	newLeadsGrid.DataBind();
    }
    private void loadAssignedLeadsForUser() {
    	LeadAssignmentPageDTO PageDTO = getSessionPageData();
        AllEnquiryLeadUIDTO selectedUserDTO = getUserSelected();
        List<UserLeadHistoryUIDTO> assignedLeadList = null;
        if (selectedUserDTO != null)
        {
            UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
            PropertyDTO property = CommonUtil.getCurrentPropertyDTO(userDefDTO);
            assignedLeadList = enquiryBO.fetchOpenLeadsForUser(property.Id, selectedUserDTO.FirmMemberId);
        }
        PageDTO.AssignedLeads = (assignedLeadList != null) ? assignedLeadList : new List<UserLeadHistoryUIDTO>();
        setAssignedLeadGrid(PageDTO.AssignedLeads);
    }
    private void setAssignedLeadGrid(List<UserLeadHistoryUIDTO> list) {
    	assignedLeadsGrid.DataSource = list;
        assignedLeadsGrid.DataBind();
    }
    private AllEnquiryLeadUIDTO getUserSelected()
    {
        return getSearchList().Find(x => x.isUISelected);
    }
    private void setUserSelected(long FirmMemberId)
    {
        List<AllEnquiryLeadUIDTO> userList = getSearchList();
        userList.ForEach(x => x.isUISelected = false);
        txtAssignee.Text = null;
        if (FirmMemberId > 0)
        {
            AllEnquiryLeadUIDTO selectedUserDTO = userList.Find(x => x.FirmMemberId == FirmMemberId);
            selectedUserDTO.isUISelected = true;
            txtAssignee.Text = CommonUIConverter.getCustomerFullName(selectedUserDTO.FirstName, selectedUserDTO.LastName);
        }
    }
    protected void onSelectUser(object sender, EventArgs e)
    {
        try
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            if (rd.Checked)
            {
                string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnUserRowIdentifier"))).Attributes["row-identifier"];
                setUserSelected(long.Parse(strId));
            }
            loadAssignedLeadsForUser();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickNewLeadsTab(object sender, EventArgs e)
    {
        try
        {
        	setTabEnabled(NEW_LEAD_TAB);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onChangeNewLeadSelection(object sender, EventArgs e)
    {
        try
        {
            CheckBox cb = (CheckBox)sender;
            long selectedId = long.Parse(cb.Attributes["data-pid"]);
            getSessionPageData().NewLeads.Find(x => x.LeadId == selectedId).isUISelected = cb.Checked;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void assignNewLeads(object sender, EventArgs e)
    {
        try
        {
            List<UserLeadHistoryUIDTO> selectedLeadList = getSessionPageData().NewLeads.FindAll(x => x.isUISelected);
            if (validateAssignNewLeads(selectedLeadList))
            {
            	AllEnquiryLeadUIDTO selectedUserDTO = getUserSelected();
                enquiryBO.AssignAllLeads(selectedLeadList, selectedUserDTO.FirmMemberId, getUserDefinitionDTO());
                setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format("Selected leads are assigned successfully to user {0}", txtAssignee.Text)));
                loadAndInitPage();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelNewLeadAssignment(object sender, EventArgs e)
    {
        try
        {
        	LeadAssignmentPageDTO PageDTO = getSessionPageData();
        	PageDTO.NewLeads.ForEach(x => x.isUISelected = false);
        	setNewLeadGrid(PageDTO.NewLeads);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateAssignNewLeads(List<UserLeadHistoryUIDTO> selectedLeadList)
    {
    	AllEnquiryLeadUIDTO selectedUserDTO = getUserSelected();
        if (selectedUserDTO == null)
        {
            setNotyMsg(CommonUtil.getNotyErrorMsg("Please select User."));
            return false;
        }
        if (selectedLeadList.Count == 0)
        {
            setNotyMsg(CommonUtil.getNotyErrorMsg("Please select atleast one lead to assign."));
            return false;
        }
        return true;
    }
    protected void onClickReassignLeadsTab(object sender, EventArgs e)
    {
        try
        {
            AllEnquiryLeadUIDTO selectedUserDTO = getUserSelected();
            if (selectedUserDTO != null)
            {
            	setTabEnabled(ASSIGNED_LEAD_TAB);
            }
            else
            {
                setNotyMsg(CommonUtil.getNotyErrorMsg("Please select User."));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onChangeAssignedLeadSelection(object sender, EventArgs e)
    {
        try
        {
            CheckBox cb = (CheckBox)sender;
            long selectedId = long.Parse(cb.Attributes["data-pid"]);
            getSessionPageData().AssignedLeads.Find(x => x.LeadId == selectedId).isUISelected = cb.Checked;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void reAssignLeads(object sender, EventArgs e)
    {
        try
        {
            List<UserLeadHistoryUIDTO> selectedLeadList = getSelectedAssignedLeads();
            if (validateReassignLeads(selectedLeadList))
            {
                long newAssigneeId = long.Parse(drpNewAssignee.Text);
                enquiryBO.ReAssignAllLeads(selectedLeadList, newAssigneeId, getUserDefinitionDTO());
                setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format("Selected leads are reassigned successfully to user {0}", drpNewAssignee.Text)));
                loadAndInitPage();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelLeadReassignment(object sender, EventArgs e)
    {
        try
        {
        	LeadAssignmentPageDTO PageDTO = getSessionPageData();
        	PageDTO.AssignedLeads.ForEach(x => x.isUISelected = false);
        	setAssignedLeadGrid(PageDTO.AssignedLeads);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateReassignLeads(List<UserLeadHistoryUIDTO> selectedLeadList)
    {
        if (string.IsNullOrWhiteSpace(drpNewAssignee.Text))
        {
            setNotyMsg(CommonUtil.getNotyErrorMsg("Please select new Assignee."));
            return false;
        }
        if (selectedLeadList.Count == 0)
        {
            setNotyMsg(CommonUtil.getNotyErrorMsg("Please select atleast one assigned lead."));
            return false;
        }
        return true;
    }
    private List<UserLeadHistoryUIDTO> getSelectedAssignedLeads()
    {
        return new List<UserLeadHistoryUIDTO>(getSessionPageData().AssignedLeads.FindAll(x => x.isUISelected));
    }
}
