﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using ConstroSoft.Logic.BO;

public partial class EnquiryActivityHistory : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addMasterDataError = "addMasterDataError";
    string addActivityModalError = "addActivityModalError";
    string addEventTaskModalError = "addEventTaskModalError";
    string addEventTaskModalError1 = "addEventTaskModalError1";
    string selectUserAssigneeModalError = "selectUserAssigneeModalError";

    string addMasterDataModal = "addMasterDataModal";
    string addActivityModal = "addActivityModal";
    string addEventTaskModal = "addEventTaskModal";
    string selectUserAssigneeModal = "selectUserAssigneeModal";
    DropdownBO drpBO = new DropdownBO();
    EnquiryBO enquiryBO = new EnquiryBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                EnquiryActivityHistoryNavDTO navDto = (EnquiryActivityHistoryNavDTO)Session[Constants.Session.NAV_DTO];
                Session.Remove(Constants.Session.NAV_DTO);
                Session.Remove(Constants.Session.PAGE_DATA);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), false);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();

    }
    private void preRenderInitFormElements()
    {
        renderPageLayout();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        drpBO.drpDataBase(drpActivityCommunicationMedia, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.COMMUNICATION_MEDIA, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.populateDrpEnqActivity(drpActivityType);
        drpBO.populateDrpEnqEventActivity(drpEventActivityType);

        drpBO.drpDataBase(drpUserAssignee, DrpDataType.ACTIVE_USERS_WITH_PR_ACCESS, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(),
           Constants.SELECT_ITEM, userDefDto.FirmNumber);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(EnquiryActivityHistoryNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(EnquiryActivityHistoryNavDTO navDto)
    {
        try
        {
        	EnquiryActivityHistoryPageDTO PageDTO = new EnquiryActivityHistoryPageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            fetchEnquiryAndInitHistory(navDto.EnquiryId);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageLayout()
    {
    }
    private EnquiryActivityHistoryPageDTO getSessionPageData()
    {
        return (EnquiryActivityHistoryPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private EnquiryDetailDTO getEnquiryDetailDTO()
    {
        return getSessionPageData().EnquiryDTO;
    }
    private void navigateToPreviousPage()
    {
        EnquiryActivityHistoryPageDTO pageDTO = getSessionPageData();
        if (pageDTO != null && pageDTO.PrevNavDTO != null)
        {
            object obj = pageDTO.PrevNavDTO;
            if (obj is EnquirySearchNavDTO)
            {
            	EnquirySearchNavDTO navDTO = (EnquirySearchNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.ENQUIRY_SEARCH, true);
            }
            else if (obj is UserEnquiryHistoryNavDTO)
            {
            	UserEnquiryHistoryNavDTO navDTO = (UserEnquiryHistoryNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.USER_ENQUIRY_HISTORY, true);
            }
            else if (obj is EnquiryDetailNavDTO)
            {
                EnquiryDetailNavDTO navDTO = (EnquiryDetailNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.ENQUIRY_DETAILS, true);
            }
        }
        Response.Redirect(Constants.URL.ENQUIRY_SEARCH, true);
    }
    private void fetchEnquiryAndInitHistory(long EnquiryId) {
        EnquiryDetailDTO enquiryDTO = enquiryBO.fetchEnquiryDetails(EnquiryId, true);
        EnquiryActivityHistoryPageDTO pageDTO = getSessionPageData();
        pageDTO.EnquiryDTO = enquiryDTO;
        initPageInfo(enquiryDTO);
    }
    private void initPageInfo(EnquiryDetailDTO enquiryDTO)
    {
        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        enquiryDTO.Assignee.FullName = CommonUIConverter.getCustomerFullName(enquiryDTO.Assignee.FirstName, enquiryDTO.Assignee.LastName);
        if (enquiryDTO.EnquiryActivities.Count > 0)
        {
            List<EnquiryActivityDTO> list = new List<EnquiryActivityDTO>(enquiryDTO.EnquiryActivities);
            enquiryDTO.EnquiryActivities.Clear();
            enquiryDTO.EnquiryActivities = new HashSet<EnquiryActivityDTO>(list.OrderByDescending(x => x.DateLogged).ThenByDescending(x => x.InsertDate));
        }
        //Enquiry Detail Panel
        lnkReassignEnquiryBtn.Visible = (enquiryDTO.Status == EnquiryStatus.Open);
        lnkReopenEnquiry.Visible = (enquiryDTO.Status == EnquiryStatus.Lost);
        lnkCloseEnquiry.Visible = (enquiryDTO.Status == EnquiryStatus.Open);
        lbCustomerName.Text = CommonUIConverter.getCustomerFullName(enquiryDTO.Salutation.Name, enquiryDTO.FirstName, "", enquiryDTO.LastName);
        lbCustomerContact.Text = enquiryDTO.ContactInfo.Contact;
        btnEnquiryInfoHdn.Attributes["row-info"] = CommonUIConverter.getGridViewRowInfo(enquiryDTO);
        lbEnqAssignee.Text = enquiryDTO.Assignee.FullName;
        lbEnquiryRefNo.Text = enquiryDTO.EnquiryRefNo;
        lbLeadRefNo.Text = (enquiryDTO.Lead != null) ? enquiryDTO.Lead.LeadRefNo : null;
        pnlLeadRefNo.Visible = enquiryDTO.Lead != null;
        lbEnqUnitType.Text = (enquiryDTO.PrUnitType != null) ? enquiryDTO.PrUnitType.Name : null;
        lbEnqSource.Text = (enquiryDTO.EnquirySource != null) ? enquiryDTO.EnquirySource.Name : null;
        lbEnqBudget.Text = (enquiryDTO.Budget != null) ? enquiryDTO.Budget.ToString() : null;
        lbEnqStatus.Text = enquiryDTO.Status.ToString();
        //Populate Activity History
        populateActivityGrid(enquiryDTO);
        //Upcoming Event Panel
        populateUpcomingEvents(enquiryDTO);
    }
    private void populateUpcomingEvents(EnquiryDetailDTO enquiryDTO)
    {
        enquiryDTO.UpcomingEvents = new List<EnquiryActivityDTO>();
        ISet<EnquiryActivityDTO> activities = enquiryDTO.EnquiryActivities;
        if (activities != null && activities.Count > 0)
        {
            foreach (EnquiryActivityDTO activityDTO in activities)
            {
                if ((activityDTO.RecordType == EnqActivityRecordType.Event || activityDTO.RecordType == EnqActivityRecordType.Task)
                    && activityDTO.Status == EnqLeadActivityStatus.Open)
                {
                    enquiryDTO.UpcomingEvents.Add(activityDTO);
                }
            }
        }
        ulUpcomingEventTaskOptions.Visible = (enquiryDTO.Status == EnquiryStatus.Open);
        pnlUpcomingEventTaskEmpty.Visible = enquiryDTO.UpcomingEvents.Count == 0;
        upcomingEventTaskGrid.Visible = enquiryDTO.UpcomingEvents.Count > 0;
        upcomingEventTaskGrid.DataSource = enquiryDTO.UpcomingEvents;
        upcomingEventTaskGrid.DataBind();
    }
    private void populateActivityGrid(EnquiryDetailDTO enquiryDTO)
    {
        activityHistoryGrid.DataSource = new List<LeadActivityDTO>();
        if (enquiryDTO != null && enquiryDTO.EnquiryActivities.Count > 0)
        {
        	assignUiIndexToActivity(enquiryDTO);
            activityHistoryGrid.DataSource = enquiryDTO.EnquiryActivities;
        }
        activityHistoryGrid.DataBind();
    }
    private void assignUiIndexToActivity(EnquiryDetailDTO enquiryDTO)
    {
        ISet<EnquiryActivityDTO> activities = enquiryDTO.EnquiryActivities;
        if (activities != null && activities.Count > 0)
        {
            long uiIndex = 1;
            foreach (EnquiryActivityDTO activityDTO in activities)
            {
                activityDTO.UiIndex = uiIndex++;
                activityDTO.RowInfo = CommonUIConverter.getGridViewRowInfo(activityDTO);
                activityDTO.LoggedBy.FullName = CommonUIConverter.getCustomerFullName(activityDTO.LoggedBy.FirstName, activityDTO.LoggedBy.LastName);
                activityDTO.EnquiryDetail = enquiryDTO;
                if ((activityDTO.RecordType == EnqActivityRecordType.Event || activityDTO.RecordType == EnqActivityRecordType.Task) 
                        && !string.IsNullOrWhiteSpace(activityDTO.RevRefNo)) {
                    EnquiryActivityDTO eventDTO = activities.ToList<EnquiryActivityDTO>().Find(x => !string.IsNullOrWhiteSpace(x.RefNo) && x.RefNo == activityDTO.RevRefNo);
                    activityDTO.PrevScheduledDate = eventDTO.ScheduledDate;
                }
            }
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
        	navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickReassignEnquiryBtn(object sender, EventArgs e)
    {
        try
        {
            EnquiryDetailDTO enquiryDTO = getEnquiryDetailDTO();
            if (enquiryDTO.Status == EnquiryStatus.Open)
            {
                drpUserAssignee.ClearSelection();
                activeModalHdn.Value = selectUserAssigneeModal;
            }
            else
            {
                setNotyMsg(CommonUtil.getNotyErrorMsg(Resources.Messages.ERROR_ENQUIRY_REASSIGN_NOT_OPEN));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickCloseEnquiryBtn(object sender, EventArgs e)
    {
        try
        {
            //TODO- we would need confirmation from user before closing lead.
            EnquiryDetailDTO enquiryDTO = getEnquiryDetailDTO();
            if (enquiryDTO.Status == EnquiryStatus.Open)
            {
                enquiryBO.closeEnquiry(enquiryDTO.Id, getUserDefinitionDTO());
                fetchEnquiryAndInitHistory(enquiryDTO.Id);
                setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format("Enquiry# {0} is closed successfully.", enquiryDTO.EnquiryRefNo)));
            }
            else
            {
                setNotyMsg(CommonUtil.getNotyErrorMsg(Resources.Messages.ERROR_ENQUIRY_CLOSE_NOT_OPEN));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickReopenEnquiryBtn(object sender, EventArgs e)
    {
        try
        {
            EnquiryDetailDTO enquiryDTO = getEnquiryDetailDTO();
            if(validateReopenEnquiry(enquiryDTO)) {
                enquiryBO.reOpenEnquiry(enquiryDTO.Id, getUserDefinitionDTO());
                fetchEnquiryAndInitHistory(enquiryDTO.Id);
                setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format("Enquiry# {0} is reopened successfully.", enquiryDTO.EnquiryRefNo)));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void selectUpcomingEvent(long EventId)
    {
        EnquiryDetailDTO enquiryDetailDTO = getEnquiryDetailDTO();
        enquiryDetailDTO.UpcomingEvents.ForEach(x => x.isUISelected = false);
        if (EventId > 0)
        {
            enquiryDetailDTO.UpcomingEvents.Find(x => x.Id == EventId).isUISelected = true;
        }
    }
    private bool validateReopenEnquiry(EnquiryDetailDTO enquiryDTO)
    {
        string msg = "";
        if (enquiryDTO.Status != EnquiryStatus.Lost) msg = Resources.Messages.ERROR_ENQUIRY_REOPEN_NOT_CLOSED;
        else if (enquiryDTO.PrUnitSaleDetail != null && enquiryDTO.PrUnitSaleDetail.Id > 0) msg = Resources.Messages.ERROR_ENQUIRY_REOPEN_UNIT_BOOKED;
        if (!string.IsNullOrWhiteSpace(msg))
        {
            setNotyMsg(CommonUtil.getNotyErrorMsg(msg));
            return false;
        }
        return true;
    }
    private EnqActivityMode getEnqActivityMode()
    {
        return EnumHelper.ToEnum<EnqActivityMode>(enqActivityModeHdn.Value);
    }
    private void setEnqActivityMode(EnqActivityMode action)
    {
        enqActivityModeHdn.Value = action.ToString();
    }
    protected string getActivityDesc(string activityType)
    {
        return EnumHelper.ToEnum<EnqActivityType>(activityType).GetDescription();
    }
    //User Assignee Selection logic - start
    protected void ReassignEnquiry(object sender, EventArgs e)
    {
        try
        {
            Page.Validate(selectUserAssigneeModalError);
            bool isValid = Page.IsValid;
            if (isValid)
            {
                long AssigneeId = long.Parse(drpUserAssignee.Text);
                EnquiryDetailDTO EnquiryDTO = getEnquiryDetailDTO();
                enquiryBO.ReAssignEnquiry(EnquiryDTO.Id, AssigneeId, DateTime.Today, getUserDefinitionDTO());
                Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg(string.Format("Enquiry# {0} is reassigneed successfully.", EnquiryDTO.EnquiryRefNo)));
                navigateToPreviousPage();
            }
            else
            {
                activeModalHdn.Value = selectUserAssigneeModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelUserAssigneeModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //User Assignee Selection logic - end
    //Add Activity Modal - Start
    private EnquiryActivityDTO getSelectedUpcomingEvent()
    {
        List<EnquiryActivityDTO> upcomingEventList = getEnquiryDetailDTO().UpcomingEvents.ToList<EnquiryActivityDTO>();
        return upcomingEventList.Find(c => c.isUISelected);
    }
    private void resetActivityModalFields()
    {
        txtActivityDate.Text = CommonUtil.getTodayDate();
        drpActivityCommunicationMedia.Text = null;
        txtActivityComments.Text = null;
        drpActivityType.Text = null;
        drpActivityType.Enabled = true;
        pnlActivityEventRefNo.Visible = false;
        if (getEnqActivityMode() == EnqActivityMode.ADD_EVENT_ACTIVITY)
        {
            EnquiryActivityDTO eventDTO = getSelectedUpcomingEvent();
            drpActivityType.Text = eventDTO.ActivityType.ToString();
            drpActivityType.Enabled = false;
            lbAddActivityModalHeader.Text = Constants.ICON.ENQUIRY_ADD_ACTIVITY + Resources.Labels.ADD_ACTIVITY;
            pnlActivityEventRefNo.Visible = true;
            lbActivityEventRefNo.Text = eventDTO.RefNo;
        }
        else
        {
            lbAddActivityModalHeader.Text = Constants.ICON.ENQUIRY_ADD_ACTIVITY + Resources.Labels.ADD_ACTIVITY;
        }
    }
    private void initActivityModalAction(EnqActivityMode mode, long selectedIndex) {
        setEnqActivityMode(mode);
        selectUpcomingEvent(selectedIndex);
        resetActivityModalFields();
        activeModalHdn.Value = addActivityModal;
    }
    protected void onClickAddEventActivityBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            initActivityModalAction(EnqActivityMode.ADD_EVENT_ACTIVITY, selectedIndex);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickAddActivityBtn(object sender, EventArgs e)
    {
        try
        {
            initActivityModalAction(EnqActivityMode.ADD_ACTIVITY, 0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void addActivity(object sender, EventArgs e)
    {
        try
        {
            if (validateAddActivity())
            {
                UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
                EnquiryDetailDTO enquiryDTO = getEnquiryDetailDTO();
                EnquiryActivityDTO activityDTO = CommonUtil.createNewEnquiryActivityDTO(enquiryDTO.Id, EnqActivityRecordType.Activity, userDefDTO);
                activityDTO.EventTaskMode = EventTaskMode.None;
                activityDTO.DateLogged = CommonUtil.getCSDateNotNull(txtActivityDate.Text);
                activityDTO.LoggedBy = userDefDTO.FirmMember;
                activityDTO.ActivityType = EnumHelper.ToEnum<EnqActivityType>(drpActivityType.Text);
                activityDTO.CommunicationMedia = CommonUIConverter.getMasterControlDTO(drpActivityCommunicationMedia.Text, null);
                activityDTO.Comments = txtActivityComments.Text;
                activityDTO.Status = EnqLeadActivityStatus.Completed;

                long parentId = 0;
                EnquiryActivityDTO eventDTO = getSelectedUpcomingEvent();
                if (eventDTO != null)
                {
                    parentId = eventDTO.Id;
                    activityDTO.RevRefNo = eventDTO.RefNo;
                }

                enquiryBO.addEnquiryActivity(enquiryDTO.Id, activityDTO, getEnqActivityMode(), parentId);
                setActivityModalSuccessMsg(activityDTO);
                setEnqActivityMode(EnqActivityMode.NONE);
                fetchEnquiryAndInitHistory(enquiryDTO.Id);
            }
            else
            {
                activeModalHdn.Value = addActivityModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setActivityModalSuccessMsg(EnquiryActivityDTO activityDTO) {
        string msg = "";
        EnqActivityMode mode = getEnqActivityMode();
        if (mode == EnqActivityMode.ADD_ACTIVITY) msg = "New activity is added successfully.";
        else if (mode == EnqActivityMode.ADD_EVENT_ACTIVITY) msg = string.Format("New activity for event# {0} is added successfully.", activityDTO.RevRefNo);
        
        setNotyMsg(CommonUtil.getNotySuccessMsg(msg));
    }
    protected void cancelAddActivityModal(object sender, EventArgs e)
    {
        try
        {
            setEnqActivityMode(EnqActivityMode.NONE);
            selectUpcomingEvent(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateAddActivity()
    {
        Page.Validate(addActivityModalError);
        bool isValid = Page.IsValid;
        if (!isValid)
        {
            DateTime dateLogged = CommonUtil.getCSDateNotNull(txtActivityDate.Text);
            isValid = validateDateLogged(dateLogged, addEventTaskModalError);
        }
        return isValid;
    }
    //Add Activity Modal - End
    //Add Event Modal - Start
    private void resetEventTaskModalFields()
    {
        txtEventLoggedDate.Text = CommonUtil.getTodayDate();
        txtEventScheduledDate.Text = null;
        txtEventComments.Text = null;
        drpEventActivityType.Text = null;
        drpEventActivityType.Enabled = true;
        pnlEventTaskInfo.Visible = false;
        pnlEventScheduleDate.Visible = true;
        EnqActivityMode mode = getEnqActivityMode();
        if (mode == EnqActivityMode.ADD_TASK)
        {
            drpEventActivityType.Text = EnqActivityType.TASK.ToString();
            drpEventActivityType.Enabled = false;
            lbEventTaskModalHeader.Text = Constants.ICON.ENQUIRY_ADD_TASK + Resources.Labels.ADD_TASK;
        }
        else if (mode == EnqActivityMode.RESCHEDULE_TASK)
        {
            EnquiryActivityDTO eventDTO = getSelectedUpcomingEvent();
            drpEventActivityType.Text = eventDTO.ActivityType.ToString();
            drpEventActivityType.Enabled = false;
            lbEventTaskModalHeader.Text = Constants.ICON.RESCHEDULE_TASK + Resources.Labels.RESCHEDULE_TASK;
            pnlEventTaskInfo.Visible = true;
            lbEventTaskInfoLabel.Text = "Current Scheduled Date: ";
            lbEventTaskInfoValue.Text = CommonUtil.getCSDateTime(eventDTO.ScheduledDate);
        }
        else if (mode == EnqActivityMode.COMPLETE_TASK)
        {
            EnquiryActivityDTO eventDTO = getSelectedUpcomingEvent();
            drpEventActivityType.Text = eventDTO.ActivityType.ToString();
            drpEventActivityType.Enabled = false;
            pnlEventScheduleDate.Visible = false;
            lbEventTaskModalHeader.Text = Constants.ICON.COMPLETE_TASK + Resources.Labels.TASK_COMPLETED;
            pnlEventTaskInfo.Visible = true;
            lbEventTaskInfoLabel.Text = "Task# ";
            lbEventTaskInfoValue.Text = eventDTO.RefNo;
        }
        else if (mode == EnqActivityMode.CANCEL_TASK)
        {
            EnquiryActivityDTO eventDTO = getSelectedUpcomingEvent();
            drpEventActivityType.Text = eventDTO.ActivityType.ToString();
            drpEventActivityType.Enabled = false;
            pnlEventScheduleDate.Visible = false;
            lbEventTaskModalHeader.Text = Constants.ICON.CANCEL_TASK + Resources.Labels.CANCEL_TASK;
            pnlEventTaskInfo.Visible = true;
            lbEventTaskInfoLabel.Text = "Task# ";
            lbEventTaskInfoValue.Text = eventDTO.RefNo;
        }
        else if (mode == EnqActivityMode.RESCHEDULE_EVENT)
        {
            EnquiryActivityDTO eventDTO = getSelectedUpcomingEvent();
            drpEventActivityType.Text = eventDTO.ActivityType.ToString();
            drpEventActivityType.Enabled = false;
            lbEventTaskModalHeader.Text = Constants.ICON.RESCHEDULE_EVENT + Resources.Labels.RESCHEDULE_EVENT;
            pnlEventTaskInfo.Visible = true;
            lbEventTaskInfoLabel.Text = "Current Scheduled Date: ";
            lbEventTaskInfoValue.Text = CommonUtil.getCSDateTime(eventDTO.ScheduledDate);
        }
        else if (mode == EnqActivityMode.CANCEL_EVENT)
        {
            EnquiryActivityDTO eventDTO = getSelectedUpcomingEvent();
            drpEventActivityType.Text = eventDTO.ActivityType.ToString();
            drpEventActivityType.Enabled = false;
            pnlEventScheduleDate.Visible = false;
            lbEventTaskModalHeader.Text = Constants.ICON.CANCEL_EVENT + Resources.Labels.CANCEL_EVENT;
            pnlEventTaskInfo.Visible = true;
            lbEventTaskInfoLabel.Text = "Event# ";
            lbEventTaskInfoValue.Text = eventDTO.RefNo;
        }
        else {
            lbEventTaskModalHeader.Text = Constants.ICON.ENQUIRY_ADD_EVENT + Resources.Labels.ADD_EVENT;
        }
    }
    private void initEventModalAction(EnqActivityMode mode, long selectedIndex) {
        setEnqActivityMode(mode);
        selectUpcomingEvent(selectedIndex);
        resetEventTaskModalFields();
        activeModalHdn.Value = addEventTaskModal;
    }
    protected void onClickAddEventBtn(object sender, EventArgs e)
    {
        try
        {
            initEventModalAction(EnqActivityMode.ADD_EVENT, 0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickRescheduleEventBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            initEventModalAction(EnqActivityMode.RESCHEDULE_EVENT, selectedIndex);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickCancelEventBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            initEventModalAction(EnqActivityMode.CANCEL_EVENT, selectedIndex);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickAddTaskBtn(object sender, EventArgs e)
    {
        try
        {
            initEventModalAction(EnqActivityMode.ADD_TASK, 0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickRescheduleTaskBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            initEventModalAction(EnqActivityMode.RESCHEDULE_TASK, selectedIndex);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickCompleteTaskBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            initEventModalAction(EnqActivityMode.COMPLETE_TASK, selectedIndex);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickCancelTaskBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            initEventModalAction(EnqActivityMode.CANCEL_TASK, selectedIndex);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void addEventTask(object sender, EventArgs e)
    {
        try
        {
            if (validateAddEventTask())
            {
                EnquiryDetailDTO enquiryDTO = getEnquiryDetailDTO();
                EnqActivityRecordType recordType = (getEnqActivityMode() == EnqActivityMode.ADD_TASK || getEnqActivityMode() == EnqActivityMode.CANCEL_TASK
                                  || getEnqActivityMode() == EnqActivityMode.COMPLETE_TASK  || getEnqActivityMode() == EnqActivityMode.RESCHEDULE_TASK) ? EnqActivityRecordType.Task : EnqActivityRecordType.Event;
                EnquiryActivityDTO eventTaskDTO = CommonUtil.createNewEnquiryActivityDTO(enquiryDTO.Id, recordType, getUserDefinitionDTO());
                eventTaskDTO.EventTaskMode = getEventTaskMode();
                eventTaskDTO.DateLogged = CommonUtil.getCSDateNotNull(txtEventLoggedDate.Text);
                eventTaskDTO.LoggedBy = getUserDefinitionDTO().FirmMember;
                eventTaskDTO.ActivityType = EnumHelper.ToEnum<EnqActivityType>(drpEventActivityType.Text);
                eventTaskDTO.ScheduledDate = CommonUtil.getCSDateTime(txtEventScheduledDate.Text); ;
                eventTaskDTO.Comments = txtEventComments.Text;
                eventTaskDTO.Status = (getEnqActivityMode() == EnqActivityMode.CANCEL_EVENT || getEnqActivityMode() == EnqActivityMode.CANCEL_TASK || getEnqActivityMode() == EnqActivityMode.COMPLETE_TASK) ?
                                        EnqLeadActivityStatus.Completed : EnqLeadActivityStatus.Open;

                long parentId = 0;
                EnquiryActivityDTO parentEventDTO = getSelectedUpcomingEvent();
                if (parentEventDTO != null)
                {
                    parentId = parentEventDTO.Id;
                    eventTaskDTO.RevRefNo = parentEventDTO.RefNo;
                }

                eventTaskDTO.RefNo = enquiryBO.addEnquiryActivity(enquiryDTO.Id, eventTaskDTO, getEnqActivityMode(), parentId);
                setEventTaskModalSuccessMsg(eventTaskDTO);
                setEnqActivityMode(EnqActivityMode.NONE);
                fetchEnquiryAndInitHistory(enquiryDTO.Id);
            }
            else
            {
                activeModalHdn.Value = addEventTaskModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setEventTaskModalSuccessMsg(EnquiryActivityDTO eventTaskDTO) {
        string msg = "";
        EnqActivityMode mode = getEnqActivityMode();
        if (mode == EnqActivityMode.ADD_TASK) msg = string.Format("Task# {0} is scheduled successfully.", eventTaskDTO.RefNo);
        else if (mode == EnqActivityMode.RESCHEDULE_TASK) msg = string.Format("Task# {0} is rescheduled successfully.", eventTaskDTO.RevRefNo);
        else if (mode == EnqActivityMode.COMPLETE_TASK) msg = string.Format("Task# {0} is completed successfully.", eventTaskDTO.RevRefNo);
        else if (mode == EnqActivityMode.CANCEL_TASK) msg = string.Format("Task# {0} is cancelled successfully.", eventTaskDTO.RevRefNo);
        else if (mode == EnqActivityMode.ADD_EVENT) msg = string.Format("Event# {0} is scheduled successfully.", eventTaskDTO.RefNo);
        else if (mode == EnqActivityMode.RESCHEDULE_EVENT) msg = string.Format("Event# {0} is rescheduled successfully.", eventTaskDTO.RevRefNo);
        else if (mode == EnqActivityMode.CANCEL_EVENT) msg = string.Format("Event# {0} is cancelled successfully.", eventTaskDTO.RevRefNo);
        
        setNotyMsg(CommonUtil.getNotySuccessMsg(msg));
    }
    private EventTaskMode getEventTaskMode()
    {
        EventTaskMode eventTaskMode = EventTaskMode.None;
        EnqActivityMode mode = getEnqActivityMode();
        if (mode == EnqActivityMode.ADD_TASK) eventTaskMode = EventTaskMode.Scheduled;
        else if (mode == EnqActivityMode.RESCHEDULE_TASK) eventTaskMode = EventTaskMode.Rescheduled;
        else if (mode == EnqActivityMode.COMPLETE_TASK) eventTaskMode = EventTaskMode.None;
        else if (mode == EnqActivityMode.CANCEL_TASK) eventTaskMode = EventTaskMode.Cancelled;
        else if (mode == EnqActivityMode.ADD_EVENT) eventTaskMode = EventTaskMode.Scheduled;
        else if (mode == EnqActivityMode.RESCHEDULE_EVENT) eventTaskMode = EventTaskMode.Rescheduled;
        else if (mode == EnqActivityMode.CANCEL_EVENT) eventTaskMode = EventTaskMode.Cancelled;

        return eventTaskMode;
    }
    protected void cancelAddEventTaskModal(object sender, EventArgs e)
    {
        try
        {
            setEnqActivityMode(EnqActivityMode.NONE);
            selectUpcomingEvent(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateAddEventTask()
    {
        string valGrp = addEventTaskModalError;
        if (getEnqActivityMode() == EnqActivityMode.CANCEL_EVENT || getEnqActivityMode() == EnqActivityMode.CANCEL_TASK) valGrp = addEventTaskModalError1;
        Page.Validate(valGrp);
        bool isValid = Page.IsValid;
        if (!isValid)
        {
            DateTime dateLogged = CommonUtil.getCSDateNotNull(txtEventLoggedDate.Text); ;
            isValid = validateDateLogged(dateLogged, addEventTaskModalError);
        }
        return isValid;
    }
    private bool validateDateLogged(DateTime dateLogged, string errorGrp)
    {
        bool isValid = true;
        EnqActivityMode mode = getEnqActivityMode();
        if (mode != EnqActivityMode.ADD_ACTIVITY && mode != EnqActivityMode.ADD_EVENT)
        {
            EnquiryActivityDTO parentEventDTO = getSelectedUpcomingEvent();
            if (parentEventDTO != null && parentEventDTO.DateLogged.CompareTo(dateLogged) < 0)
            {
                string msg = (mode == EnqActivityMode.ADD_EVENT_ACTIVITY) ? "Activity Date cannot less than {0}" : "Date Logged cannot be less than {0}";
                setErrorMessage(string.Format(msg, parentEventDTO.RefNo), errorGrp);
                isValid = false;
            }
        }
        return isValid;
    }
    //Add Event Modal - End
    //Master Data Modal save logic - Start
    protected void saveMasterData(object sender, EventArgs e)
    {
        try
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (Constants.MCDType.COMMUNICATION_MEDIA.Equals(masterDataModalTypeHdn.Value))
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.COMMUNICATION_MEDIA, txtMasterDataInput1.Text,
                       txtMasterDataInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Communication Media");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpActivityCommunicationMedia, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.COMMUNICATION_MEDIA, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
            }
            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                activeModalHdn.Value = addMasterDataModal;
                setErrorMessage(errorMsg, addMasterDataError);
            }
            else
            {
                resetMasterDataModalFields();
                setParentModalFlag();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            activeModalHdn.Value = "";
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    protected void cancelMasterDataModal(object sender, EventArgs e)
    {
        try
        {
            resetMasterDataModalFields();
            setParentModalFlag();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    private void resetMasterDataModalFields()
    {
        txtMasterDataInput1.Text = "";
        txtMasterDataInput2.Text = "";
        masterDataModalTypeHdn.Value = "";
    }
    private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
    {
        string errorMsg = "";
        if (string.IsNullOrWhiteSpace(masterDataDto.Name))
        {
            errorMsg = string.Format(Resources.Messages.TEXTFIELD_REQUIRED, type);
        }
        else if (masterDataBO.isAlreadyExist(masterDataDto))
        {
            errorMsg = string.Format(Resources.Messages.ALREADY_EXIST_DB_ERROR, type);
        }
        return errorMsg;
    }
    private void setParentModalFlag()
    {
        activeModalHdn.Value = masterDataParentModalHdn.Value;
        masterDataParentModalHdn.Value = "";
    }
    //Master Data Modal save logic - End
}
