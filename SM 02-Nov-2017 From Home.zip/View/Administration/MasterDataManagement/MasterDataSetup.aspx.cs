﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Net;
using System.IO;
using System.Windows.Forms;
using System.Net.Mail;
using ConstroSoft;
using ConstroSoft.Logic.BO;
using ConstroSoft.Logic.Util;
using System.Text;

public partial class MasterDataSetup : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifyMasterDataError = "addModifyMasterDataError";
    string addModifyMasterDataModal = "addModifyMasterDataModal";
    DropdownBO drpBO = new DropdownBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    public enum MCDModalAction { ADD, MODIFY }

    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                MasterDataSetupNavDTO navDto = (MasterDataSetupNavDTO)Session[Constants.Session.NAV_DTO];
                Session.Remove(Constants.Session.NAV_DTO);
                Session.Remove(Constants.Session.PAGE_DATA);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), false);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpEnum<MasterDataType>(drpMasterDataType, null);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(MasterDataSetupNavDTO navDTO)
    {
        Session[Constants.Session.PAGE_DATA] = new MasterDataSetupPageDTO();
        initDropdowns();
        loadMasterDataGrid();
    }
    private void renderPageFieldsWithEntitlement()
    {

    }
    private MasterDataSetupPageDTO getSessionPageData()
    {
        return (MasterDataSetupPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<MasterControlDataDTO> getMasterDataList()
    {
        return getSessionPageData().SearchResult;
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private void loadMasterDataGrid()
    {
        MasterDataSetupPageDTO PageDTO = getSessionPageData();
        IList<MasterControlDataDTO> results = masterDataBO.fetchMasterData(getUserDefinitionDTO().FirmNumber, drpMasterDataType.Text);
        PageDTO.SearchResult = (results != null) ? results.ToList<MasterControlDataDTO>() : new List<MasterControlDataDTO>();
        populateMasterDataSearchGrid(PageDTO.SearchResult);
        lnkAddMasterDataBtn.Visible = !(results.Any(item => item.SystemDefined.Equals("YES"))); 
    }
    private void populateMasterDataSearchGrid(List<MasterControlDataDTO> tmpList)
    {
        masterDataGrid.DataSource = new List<MasterControlDataDTO>();
        if (tmpList != null)
        {
            assignUiIndexToMasterData(tmpList);
            masterDataGrid.DataSource = tmpList;
        }
        masterDataGrid.DataBind();
    }
    private void assignUiIndexToMasterData(List<MasterControlDataDTO> tmpList)
    {
        if (tmpList != null && tmpList.Count > 0)
        {
            long uiIndex = 1;
            foreach (MasterControlDataDTO tmpDTO in tmpList)
            {
                tmpDTO.UiIndex = uiIndex++;
            }
        }
    }
    protected void onChangeMasterDataType(object sender, EventArgs e)
    {
        try
        {
            loadMasterDataGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected string getMCDTypeDesc(string type)
    {
        return EnumHelper.ToEnum<MasterDataType>(type).GetDescription();
    }
    //Master Data Modal - Start
    private void initMasterDataModalFields()
    {
        lbMasterDataModalTitle.Text = (MCDModalAction.ADD.ToString().Equals(masterDataModalActionHdnBtn.Value))
            ? Constants.ICON.ADD + Resources.Labels.ADD_MASTER_DATA : Constants.ICON.MODIFY + Resources.Labels.MODIFY_MASTER_DATA;
    }
    private void initMasterDataSectionFields(MasterControlDataDTO mcdDTO)
    {
        lbMasterDataType.Text = getMCDTypeDesc(drpMasterDataType.Text);
        if (mcdDTO != null) txtName.Text = mcdDTO.Name; else txtName.Text = null;
        if (mcdDTO != null) txtDescription.Text = mcdDTO.Description; else txtDescription.Text = null;
    }
    private MasterControlDataDTO populateMasterDataUpdate()
    {
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        MasterControlDataDTO masterDataDto = getSelectedMasterData(0);
        masterDataDto.Name = txtName.Text;
        masterDataDto.Description = txtDescription.Text;
        return masterDataDto;
    }
    private void setSelectedMasterData(long Id)
    {
        List<MasterControlDataDTO> tmpList = getMasterDataList();
        tmpList.ForEach(c => c.isUISelected = false);
        if (Id > 0) tmpList.Find(c => c.Id == Id).isUISelected = true;
    }
    private MasterControlDataDTO getSelectedMasterData(long Id)
    {
        List<MasterControlDataDTO> tmpList = getMasterDataList();
        return (Id > 0) ? tmpList.Find(c => c.Id == Id) : tmpList.Find(c => c.isUISelected);
    }
    protected void onClickAddMasterDataBtn(object sender, EventArgs e)
    {
        try
        {
            masterDataModalActionHdnBtn.Value = MCDModalAction.ADD.ToString();
            initMasterDataModalFields();
            setSelectedMasterData(-1);
            initMasterDataSectionFields(null);
            activeModalHdn.Value = addModifyMasterDataModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyMasterDataBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            masterDataModalActionHdnBtn.Value = MCDModalAction.MODIFY.ToString();
            setSelectedMasterData(selectedIndex);
            initMasterDataModalFields();
            initMasterDataSectionFields(getSelectedMasterData(selectedIndex));
            activeModalHdn.Value = addModifyMasterDataModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void deleteMasterData(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            MasterControlDataDTO tmpDTO = getSelectedMasterData(selectedIndex);
            masterDataBO.deleteMasterData(tmpDTO.Id);
            loadMasterDataGrid();
            string msg = string.Format(Resources.Messages.RECORD_DELETE_DB_SUCCESS, tmpDTO.Name);
            setNotyMsg(CommonUtil.getNotySuccessMsg(msg));
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void saveMasterData(object sender, EventArgs e)
    {
        try
        {
            string errorMsg = null;
            string msg = null;
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (MCDModalAction.ADD.ToString().Equals(masterDataModalActionHdnBtn.Value))
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(drpMasterDataType.Text, txtName.Text,
                        txtDescription.Text, userDefDto);
                 errorMsg = validateMasterDataModalInput(masterDataDto, getMCDTypeDesc(drpMasterDataType.Text));
                 if (string.IsNullOrWhiteSpace(errorMsg))
                 {
                     masterDataBO.saveMasterData(masterDataDto);
                     msg = string.Format(Resources.Messages.RECORD_ADDED_DB_SUCCESS, getMCDTypeDesc(drpMasterDataType.Text));
                 }
            }
            if (MCDModalAction.MODIFY.ToString().Equals(masterDataModalActionHdnBtn.Value))
            {
                 MasterControlDataDTO masterDataDto = populateMasterDataUpdate();
                 errorMsg = validateMasterDataModalInputforModify(masterDataDto, getMCDTypeDesc(drpMasterDataType.Text));
                 if (string.IsNullOrWhiteSpace(errorMsg))
                 {
                     masterDataBO.updateMasterData(masterDataDto);
                     msg = string.Format(Resources.Messages.RECORD_MODIFY_DB_SUCCESS, getMCDTypeDesc(drpMasterDataType.Text));
                 }
            }
            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                activeModalHdn.Value = addModifyMasterDataModal;
                SetFocus(txtName);
                setErrorMessage(errorMsg, addModifyMasterDataError);
            }
            else
            {
                resetMasterDataModalFields();
                loadMasterDataGrid();
                setNotyMsg(CommonUtil.getNotySuccessMsg(msg));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
    {
        string errorMsg = "";
        if (string.IsNullOrWhiteSpace(masterDataDto.Name))
        {
            errorMsg = string.Format(Resources.Messages.TEXTFIELD_REQUIRED, type);
        }
        else if (masterDataBO.isAlreadyExist(masterDataDto))
        {
            errorMsg = string.Format(Resources.Messages.ALREADY_EXIST_DB_ERROR, type);
        }
        return errorMsg;
    }
    private string validateMasterDataModalInputforModify(MasterControlDataDTO masterDataDto, string type)
    {
        string errorMsg = "";
        if (string.IsNullOrWhiteSpace(masterDataDto.Name))
        {
            errorMsg = string.Format(Resources.Messages.TEXTFIELD_REQUIRED, type);
        }
        List<MasterControlDataDTO> tmpList = getMasterDataList();
        int index = tmpList.FindIndex(item => (item.Name == masterDataDto.Name) && (item.Id != masterDataDto.Id));
        if (index >= 0)
        {
            errorMsg = string.Format(Resources.Messages.ALREADY_EXIST_DB_ERROR, type);
        }
        return errorMsg;
    }
    protected void cancelMasterDataStage(object sender, EventArgs e)
    {
        try
        {
            setSelectedMasterData(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateMasterDataAddModify()
    {
        bool isValid = true;
        Page.Validate(addModifyMasterDataError);
        isValid = Page.IsValid;
        return isValid;
    }
    protected void cancelMasterData(object sender, EventArgs e)
    {
        try
        {
            resetMasterDataModalFields();
           
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addModifyMasterDataError);
        }
    }
    private void resetMasterDataModalFields() {
        txtName.Text = "";
        txtDescription.Text = "";
        masterDataModalActionHdnBtn.Value = "";
    }
    
    //Master Data Modal - End
}