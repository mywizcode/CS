﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using ConstroSoft.Logic.BO;

public partial class UserEnquiryHistory : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string selectUserAssigneeModalError = "selectUserAssigneeModalError";
    string SearchFilterModal = "SearchFilterModal";
    string selectUserAssigneeModal = "selectUserAssigneeModal";
    DropdownBO drpBO = new DropdownBO();
    EnquiryBO enquiryBO = new EnquiryBO();
    SoldPropertyUnitBO soldUnitBO = new SoldPropertyUnitBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                UserEnquiryHistoryNavDTO navDto = (UserEnquiryHistoryNavDTO)Session[Constants.Session.NAV_DTO];
                Session.Remove(Constants.Session.NAV_DTO);
                Session.Remove(Constants.Session.PAGE_DATA);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        drpBO.drpDataBase(drpUserAssignee, DrpDataType.ACTIVE_USERS_WITH_PR_ACCESS, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(),
            Constants.SELECT_ITEM, userDefDto.FirmNumber);
    }
    private void preRenderInitFormElements()
    {
        renderPageLayout();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        drpBO.drpDataBase(drpSourceFilter, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ENQUIRY_SOURCE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<EnquiryStatus>(drpStatusFilter, Constants.SELECT_ITEM);

        drpBO.drpDataBase(drpUserAssignee, DrpDataType.ACTIVE_USERS_WITH_PR_ACCESS, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(),
            Constants.SELECT_ITEM, userDefDto.FirmNumber);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(UserEnquiryHistoryNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(UserEnquiryHistoryNavDTO navDto)
    {
        try
        {
        	UserEnquiryHistoryPageDTO PageDTO = new UserEnquiryHistoryPageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            PageDTO.FirmMemberId = navDto.FirmMemberId;
            setSearchFilter(navDto.FilterDTO);
            loadSummaryAndHistory();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageLayout()
    {
    }
    private void navigateToPreviousPage()
    {
        UserEnquiryHistoryPageDTO PageDTO = getSessionPageData();
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is AllEnquiryLeadHistoryPageDTO)
            {
                AllEnquiryLeadHistoryPageDTO navDTO = (AllEnquiryLeadHistoryPageDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.ALL_ENQUIRY_LEAD_HISTORY, true);
            }
        }
        Response.Redirect(Constants.URL.ALL_ENQUIRY_LEAD_HISTORY, true);
    }
    private void setSearchGrid(IList<UserEnquiryHistoryUIDTO> tmpList)
    {
        getSessionPageData().SearchResult = (tmpList != null) ? tmpList.ToList<UserEnquiryHistoryUIDTO>() : new List<UserEnquiryHistoryUIDTO>();
        userEnquiryHistorySearchGrid.DataSource = getSearchList();
        userEnquiryHistorySearchGrid.DataBind();
    }
    private UserEnquiryHistoryPageDTO getSessionPageData()
    {
        return (UserEnquiryHistoryPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<UserEnquiryHistoryUIDTO> getSearchList()
    {
        return getSessionPageData().SearchResult;
    }
    private UserEnquiryHistoryUIDTO getSearchDTO(long Id)
    {
        List<UserEnquiryHistoryUIDTO> searchList = getSearchList();
        UserEnquiryHistoryUIDTO selectedUnitDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            selectedUnitDTO = searchList.Find(c => c.EnquiryId == Id);
        }
        return selectedUnitDTO;
    }
    private void loadSummaryAndHistory()
    {
    	UserEnquiryHistoryPageDTO PageDTO = getSessionPageData();
    	long FirmMemberId = PageDTO.FirmMemberId;
        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        PropertyDTO property = CommonUtil.getCurrentPropertyDTO(userDefDTO);
    	AllEnquiryLeadUIDTO EnquirySummaryDTO = enquiryBO.fetchEnquiryHistorySummaryForUser(property.Id, FirmMemberId);
    	PageDTO.EnquirySummary = EnquirySummaryDTO;
    	lbUserFullName.Text = CommonUIConverter.getCustomerFullName(EnquirySummaryDTO.FirstName, EnquirySummaryDTO.LastName);
    	lbUserContact.Text = EnquirySummaryDTO.Contact;
    	lbUserEmail.Text = EnquirySummaryDTO.Email;
    	lbEnquiryOpen.Text = EnquirySummaryDTO.EnquiriesOpen.ToString();
        lbEnquiryWon.Text = EnquirySummaryDTO.EnquiriesWon.ToString();
        lbEnquiryLost.Text = EnquirySummaryDTO.EnquiriesLost.ToString();
    	
    	loadEnquiryHistoryGrid();
    }
    private void loadEnquiryHistoryGrid()
    {
    	UserEnquiryHistoryPageDTO PageDTO = getSessionPageData();
    	long FirmMemberId = PageDTO.FirmMemberId;
        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        PropertyDTO property = CommonUtil.getCurrentPropertyDTO(userDefDTO);
    	IList<UserEnquiryHistoryUIDTO> results = enquiryBO.fetchEnquiryHistoryForUser(property.Id, FirmMemberId);
        setSearchGrid(results);
    }
    private UserEnquiryHistoryNavDTO getCurrentPageNavigation()
    {
    	UserEnquiryHistoryPageDTO PageDTO = getSessionPageData();
    	UserEnquiryHistoryNavDTO navDTO = new UserEnquiryHistoryNavDTO();
        navDTO.FirmMemberId = PageDTO.FirmMemberId;
        navDTO.FilterDTO = getSearchFilter();
        navDTO.PrevNavDto = PageDTO.PrevNavDTO;
        return navDTO;
    }
    protected void onClickActiveHistoryBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            EnquiryActivityHistoryNavDTO navDTO = new EnquiryActivityHistoryNavDTO();
            navDTO.EnquiryId = selectedId;
            navDTO.PrevNavDto = getCurrentPageNavigation();
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.ENQUIRY_ACTIVITY_HISTORY, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickEnquiryDetailBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            EnquiryDetailNavDTO navDTO = new EnquiryDetailNavDTO();
            navDTO.Mode = PageMode.VIEW;
            navDTO.EnquiryId = selectedId;
            navDTO.PrevNavDto = getCurrentPageNavigation();
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.ENQUIRY_DETAILS, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickReassignEnquiryBtn(object sender, EventArgs e)
    {
        try
        {
        	LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            selectEnquiry(selectedId);
            drpUserAssignee.ClearSelection();
    		activeModalHdn.Value = selectUserAssigneeModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickBookingDetailsBtn(object sender, EventArgs e)
    {
        try
        {
        	LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            UserEnquiryHistoryUIDTO enquiryHistoryUIDTO = getSearchDTO(selectedId);
            if(enquiryHistoryUIDTO.PrUnitSaleId > 0) {
            	if(enquiryHistoryUIDTO.UnitSaleStatus == PRUnitSaleStatus.Sold) {
                    SoldUnitDetailNavDTO navDTO = new SoldUnitDetailNavDTO();
                    navDTO.Mode = PageMode.VIEW;
                    navDTO.PrUnitSaleDetailId = enquiryHistoryUIDTO.PrUnitSaleId;
                    navDTO.PrevNavDto = getCurrentPageNavigation();
                    Session[Constants.Session.NAV_DTO] = navDTO;
                    Response.Redirect(Constants.URL.SOLD_UNIT_DETAILS, true);
                } else {
                	CancelledUnitDetailNavDTO navDTO = new CancelledUnitDetailNavDTO();
                	navDTO.Mode = PageMode.VIEW;
                	navDTO.PrUnitSaleDetailId = enquiryHistoryUIDTO.PrUnitSaleId;
                	navDTO.PrevNavDto = getCurrentPageNavigation();
                	Session[Constants.Session.NAV_DTO] = navDTO;
                	Response.Redirect(Constants.URL.CANCELLED_UNIT_DETAILS, true);
                }
            } else {
            	setNotyMsg(CommonUtil.getNotyErrorMsg(string.Format("Property Unit was not booked against Enquiry# {0}.", enquiryHistoryUIDTO.EnquiryRefNo)));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //User Assignee Selection logic - start
    private void selectEnquiry(long EnquiryId) {
    	List<UserEnquiryHistoryUIDTO> searchResult = getSessionPageData().SearchResult;
    	searchResult.ForEach(c => c.isUISelected = false);
    	if (EnquiryId > 0) searchResult.Find(x => x.EnquiryId == EnquiryId).isUISelected = true;
    }
    private UserEnquiryHistoryUIDTO getSelectedEnquiry() {
    	List<UserEnquiryHistoryUIDTO> searchResult = getSessionPageData().SearchResult;
        return searchResult.Find(c => c.isUISelected);
    }
    protected void ReassignEnquiry(object sender, EventArgs e)
    {
    	try
    	{
    		Page.Validate(selectUserAssigneeModalError);
    		bool isValid = Page.IsValid;
    		if (isValid)
    		{
                long AssigneeId = long.Parse(drpUserAssignee.Text);
    			UserEnquiryHistoryUIDTO	EnquiryUIDTO = getSelectedEnquiry();
    			enquiryBO.ReAssignEnquiry(EnquiryUIDTO.EnquiryId, AssigneeId, DateTime.Today, getUserDefinitionDTO());
    			selectEnquiry(0);
    			setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format("Enquiry# {0} is reassigneed successfully.", EnquiryUIDTO.EnquiryRefNo)));
    			loadSummaryAndHistory();
    		}
    		else
    		{
    			activeModalHdn.Value = selectUserAssigneeModal;
    		}
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    protected void cancelUserAssigneeModal(object sender, EventArgs e)
    {
    	try
    	{
    		selectEnquiry(0);
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    //User Assignee Selection logic - end
    //Filter Criteria - Enquiry Search - Start
    private EnquiryFilterDTO getSearchFilter()
    {
        return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            EnquiryFilterDTO filterDTO = getSearchFilter();
            if (filterDTO.EnquiryRefNo != null) txtEnquiryRefNoFilter.Text = filterDTO.EnquiryRefNo; else txtEnquiryRefNoFilter.Text = null;
            if (filterDTO.LeadRefNo != null) txtLeadRefNoFilter.Text = filterDTO.LeadRefNo; else txtLeadRefNoFilter.Text = null;
            if (filterDTO.FirstName != null) txtFirstNameFilter.Text = filterDTO.FirstName; else txtFirstNameFilter.Text = null;
            if (filterDTO.LastName != null) txtLastNameFilter.Text = filterDTO.LastName; else txtLastNameFilter.Text = null;
            if (filterDTO.Contact != null) txtContactFilter.Text = filterDTO.Contact; else txtContactFilter.Text = null;
            if (filterDTO.Status != null) drpStatusFilter.Text = filterDTO.Status.ToString(); else drpStatusFilter.ClearSelection();
            if (filterDTO.SourceId > 0) drpSourceFilter.Text = filterDTO.SourceId.ToString(); else drpSourceFilter.ClearSelection();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            EnquiryFilterDTO filterDTO = new EnquiryFilterDTO();
            if (!string.IsNullOrWhiteSpace(txtEnquiryRefNoFilter.Text))
            {
                filterDTO.EnquiryRefNo = txtEnquiryRefNoFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(txtFirstNameFilter.Text))
            {
                filterDTO.FirstName = txtFirstNameFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(txtLastNameFilter.Text))
            {
                filterDTO.LastName = txtLastNameFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(txtContactFilter.Text))
            {
                filterDTO.Contact = txtContactFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(txtLeadRefNoFilter.Text))
            {
                filterDTO.LeadRefNo = txtLeadRefNoFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(drpSourceFilter.Text))
            {
                filterDTO.SourceId = long.Parse(drpSourceFilter.Text);
                filterDTO.Source = drpSourceFilter.SelectedItem.Text;
            }
            if (!string.IsNullOrWhiteSpace(drpStatusFilter.Text))
            {
                filterDTO.Status = EnumHelper.ToEnum<EnquiryStatus>(drpStatusFilter.SelectedItem.Text);
            }
            setSearchFilter(filterDTO);
            loadEnquiryHistoryGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }

    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            loadEnquiryHistoryGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(EnquiryFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new EnquiryFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            EnquiryFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.ENQUIRY_REF_NO))
            {
                filterDTO.EnquiryRefNo = null;
            }
            else if (token.StartsWith(Constants.FILTER.LEAD_REF_NO)) filterDTO.LeadRefNo = null;
            else if (token.StartsWith(Constants.FILTER.CONTACT))
            {
                filterDTO.Contact = null;
            }
            else if (token.StartsWith(Constants.FILTER.FIRST_NAME))
            {
                filterDTO.FirstName = null;
            }
            else if (token.StartsWith(Constants.FILTER.LAST_NAME))
            {
                filterDTO.LastName = null;
            }
            else if (token.StartsWith(Constants.FILTER.ENQUIRY_SOURCE))
            {
                filterDTO.SourceId = 0;
                filterDTO.Source = null;
            }
            else if (token.StartsWith(Constants.FILTER.ENQUIRY_STATUS))
            {
                filterDTO.Status = null;
            }

            setSearchFilterTokens();
            loadEnquiryHistoryGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        EnquiryFilterDTO filterDTO = getSearchFilter();
        string filter = null;
        if (filterDTO != null)
        {
            if (filterDTO.EnquiryRefNo != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.ENQUIRY_REF_NO + filterDTO.EnquiryRefNo);
            if (filterDTO.LeadRefNo != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.LEAD_REF_NO + filterDTO.LeadRefNo);
            if (filterDTO.FirstName != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.FIRST_NAME + filterDTO.FirstName);
            if (filterDTO.LastName != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.LAST_NAME + filterDTO.LastName);
            if (filterDTO.Contact != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.CONTACT + filterDTO.Contact);
            if (filterDTO.Source != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.ENQUIRY_SOURCE + filterDTO.Source);
            if (filterDTO.Status != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.ENQUIRY_STATUS + filterDTO.Status);
        }
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - Enquiry Search - End
}
