﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using ConstroSoft.Logic.BO;

public partial class AllEnquiryLeadSearch : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    DropdownBO drpBO = new DropdownBO();
    EnquiryBO enquiryBO = new EnquiryBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                AllEnquiryLeadHistoryNavDTO navDto = (AllEnquiryLeadHistoryNavDTO)Session[Constants.Session.NAV_DTO];
                Session.Remove(Constants.Session.NAV_DTO);
                Session.Remove(Constants.Session.PAGE_DATA);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();

    }
    private void preRenderInitFormElements()
    {
        renderPageLayout();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(AllEnquiryLeadHistoryNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new AllEnquiryLeadHistoryPageDTO();
        initDropdowns();
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(AllEnquiryLeadHistoryNavDTO navDto)
    {
        try
        {
            loadAllEnquiryLeadGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageLayout()
    {
    }
    private void setSearchGrid(List<AllEnquiryLeadUIDTO> tmpList)
    {
        getSessionPageData().SearchResult = (tmpList != null) ? tmpList : new List<AllEnquiryLeadUIDTO>();
        allEnquiryLeadSearchGrid.DataSource = getSearchList();
        allEnquiryLeadSearchGrid.DataBind();
    }
    private AllEnquiryLeadHistoryPageDTO getSessionPageData()
    {
        return (AllEnquiryLeadHistoryPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<AllEnquiryLeadUIDTO> getSearchList()
    {
        return getSessionPageData().SearchResult;
    }
    private AllEnquiryLeadUIDTO getSearchEnquiryLeadDTO(long Id)
    {
        List<AllEnquiryLeadUIDTO> searchList = getSearchList();
        AllEnquiryLeadUIDTO selectedDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            selectedDTO = searchList.Find(c => c.FirmMemberId == Id);
        }
        return selectedDTO;
    }
    private void loadAllEnquiryLeadGrid()
    {
        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        PropertyDTO property = CommonUtil.getCurrentPropertyDTO(userDefDTO);
        List<AllEnquiryLeadUIDTO> results = enquiryBO.fetchAllEnquiryLeadData(property.Id);
        setSearchGrid(results);
    }
    private AllEnquiryLeadHistoryNavDTO getCurrentPageNavigation()
    {
        AllEnquiryLeadHistoryNavDTO navDTO = new AllEnquiryLeadHistoryNavDTO();
        return navDTO;
    }
    protected void onClickViewEnquiryHistoryBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            List<AllEnquiryLeadUIDTO> searchResult = getSessionPageData().SearchResult;
            AllEnquiryLeadUIDTO AllEnquiryUIDTO = searchResult.Find(x => x.FirmMemberId == selectedId);
            if(AllEnquiryUIDTO.EnquiriesOpen > 0 || AllEnquiryUIDTO.EnquiriesLost > 0 || AllEnquiryUIDTO.EnquiriesWon > 0) {
            	UserEnquiryHistoryNavDTO navDTO = new UserEnquiryHistoryNavDTO();
                navDTO.FirmMemberId = selectedId;
                navDTO.PrevNavDto = getCurrentPageNavigation();
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.USER_ENQUIRY_HISTORY, true);
            } else {
            	setNotyMsg(CommonUtil.getNotyErrorMsg("No Enquiry is assigned to User."));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickViewLeadHistoryBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            List<AllEnquiryLeadUIDTO> searchResult = getSessionPageData().SearchResult;
            AllEnquiryLeadUIDTO AllEnquiryUIDTO = searchResult.Find(x => x.FirmMemberId == selectedId);
            if(AllEnquiryUIDTO.LeadsOpen > 0 || AllEnquiryUIDTO.LeadsConverted > 0 || AllEnquiryUIDTO.LeadsLost > 0) {
                UserLeadHistoryNavDTO navDTO = new UserLeadHistoryNavDTO();
                navDTO.FirmMemberId = selectedId;
                navDTO.PrevNavDto = getCurrentPageNavigation();
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.USER_LEAD_HISTORY, true);
            } else {
            	setNotyMsg(CommonUtil.getNotyErrorMsg("No Lead is assigned to User."));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
}
