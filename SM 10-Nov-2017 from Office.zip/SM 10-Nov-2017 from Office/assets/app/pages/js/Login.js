$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    Ladda.bind('.btn-ladda-spinner');
    $('input.submitForm').on('keypress', function (e) {
        if (e.which == 10 || e.which == 13) {
            if (document.getElementById("ContentPlaceHolder1_btnLogin") != null) {
                document.getElementById("ContentPlaceHolder1_btnLogin").click();
            } else if (document.getElementById("ContentPlaceHolder1_btnFPUsernameSubmit") != null) {
                document.getElementById("ContentPlaceHolder1_btnFPUsernameSubmit").click();
            } else if (document.getElementById("ContentPlaceHolder1_btnFPSecQuesitonSubmit") != null) {
                document.getElementById("ContentPlaceHolder1_btnFPSecQuesitonSubmit").click();
            } else if (document.getElementById("ContentPlaceHolder1_btnResetPwdSubmit") != null) {
                document.getElementById("ContentPlaceHolder1_btnResetPwdSubmit").click();
            }
        }
    });
    initNotification();
}
