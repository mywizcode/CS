﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initPymtScheduleGrid();
    formatFields();
    showModal();
}

function initPymtScheduleGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: isViewOnly,
        customBtnGrpId: "#pymtScheduleGridBtnDiv",
        pageLength: 10,
        hideSearch: true,
        sortable: false
    };

    $("[id$='pymtScheduleGrid']").CSBasicDatatable(dtOptions);
}




