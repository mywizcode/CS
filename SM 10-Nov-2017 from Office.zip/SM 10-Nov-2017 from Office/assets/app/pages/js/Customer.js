﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initCustomerSearchGrid();
    initSoldUnitGrid();
    formatFields();
    showModal();
}

function initCustomerSearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        customBtnGrpId: "#customerSearchBtnDiv",
        pageLength: 10
    };

    $("[id$='customerSearchGrid']").CSBasicDatatable(dtOptions);
}
function initSoldUnitGrid() {
    var dtOptions = {
        pageLength: 5,
        hideSearch: true
    };

    $("[id$='soldUnitsGrid']").CSBasicDatatable(dtOptions);
}




