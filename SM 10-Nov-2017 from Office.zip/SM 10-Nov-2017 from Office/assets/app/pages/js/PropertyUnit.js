﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initUnitSearchGrid();
    initPropertyUnitUploadGrid();
    formatFields();
    showModal();
}

function initUnitSearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#propertyUnitSearchBtnDiv",
        pageLength: 10
    };

    $("[id$='propertyUnitSearchGrid']").CSBasicDatatable(dtOptions);
}
function initPropertyUnitUploadGrid() {
    var dtOptions = {
        hasActionColumn: false,
        rowInfoModalTitle: "Unit Details",
        pageLength: 10
    };

    $("[id$='unitUploadGrid']").CSBasicDatatable(dtOptions);
}




