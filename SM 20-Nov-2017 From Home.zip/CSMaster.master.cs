﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using ConstroSoft;

public partial class CSMaster : System.Web.UI.MasterPage
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            try
            {
                if (CommonUtil.isSessionActive(Session))
                {
                    UserDefinitionDTO userDef = getUserDefinitionDTO();
                    lbUserName.Text = userDef.Username;
                    if (userDef.ProfileImg != null)
                    {
                        byte[] bytes = (byte[])userDef.ProfileImg;
                        string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                        imgProfilePic.ImageUrl= "data:image/png;base64," + base64String;
                    }                    
                    setFunctionName();
                    initSidebar();
                    initPropertyGrid();
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
            catch (Exception ex)
            {
            }
        }
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void setFunctionName()
    {
        string[] fnAndPageName = getFunctionAndPageName();
        functionName.Value = fnAndPageName[0].ToUpper();
        pageName.Value = fnAndPageName[1].ToUpper();
    }
    private string[] getFunctionAndPageName()
    {
        string[] fnAndPageName = new string[2];
        string absPath = HttpContext.Current.Request.Url.AbsolutePath;
        string appPath = HttpContext.Current.Request.ApplicationPath;
        int index = absPath.IndexOf(appPath);
        string expPath = (index < 0) ? absPath : absPath.Remove(index, appPath.Length);
        string[] arrUrl = expPath.TrimStart('/').Split('/');
        fnAndPageName[0] = (arrUrl.Length > 0) ? arrUrl[0] : "";
        fnAndPageName[1] = (arrUrl.Length > 1) ? arrUrl[1] : "";
        return fnAndPageName;
    }
    private bool isCRM()
    {
        return (Constants.Function.CRM.ToUpper().Equals(functionName.Value));
    }
    private bool isERP()
    {
        return (Constants.Function.ERP.ToUpper().Equals(functionName.Value));
    }
    private bool isAcntFianance()
    {
        return (Constants.Function.ACNT_FINANCE.ToUpper().Equals(functionName.Value));
    }
    private bool isFirmPropertySetup()
    {
        return (Constants.Function.FIRM_PROPERTY_SETUP.ToUpper().Equals(functionName.Value));
    }
    private bool isAdministration()
    {
        return (Constants.Function.ADMINISTRATION.ToUpper().Equals(functionName.Value));
    }
    private void initSidebar()
    {
        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        CrmMenu.Visible = CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_FN_CRM);
        ErpMenu.Visible = false;
        AcntFinanceMenu.Visible = CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_FN_ACCOUNT_FINANCE);
        FirmPropertySetupMenu.Visible = CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_FIRM_PROPERTY_SETUP);
        AdministrationMenu.Visible = CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_ADMINISTRATION);
        bool isCRMEnabled = isCRM() && CrmMenu.Visible;
        bool isERPEnabled = isERP() && ErpMenu.Visible;
        bool isAcntFinanceEnabled = isAcntFianance() && AcntFinanceMenu.Visible;
        bool isPropertySetupEnabled = isFirmPropertySetup() && FirmPropertySetupMenu.Visible;
        bool isAdministrationEnabled = isAdministration() && AdministrationMenu.Visible;
        //CRM Functional Menu
        CRMDashboard.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_FN_CRM);
        //Enquiry Management
        EnquiryManagementMenu.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_ENQUIRY_MANAGEMENT);
        AllEnquiryLeadSearch.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_ALL_ENQ_LEADS);
        LeadAssignment.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_LEAD_ASSIGNMENT);
        MyLeads.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_MY_LEADS);
        MyEnquiry.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_MY_ENQUIRIES);
        //Promotion Management
        PromoManagementMenu.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_PROMOTION_MANAGEMENT);
        Promotion.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_PROMOTIONS);
        PreSaleMenuHeader.Visible = EnquiryManagementMenu.Visible || PromoManagementMenu.Visible;
        //Sale Management
        SaleManagementMenu.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_SALE_MANAGEMENT);
        AvailablePropertyUnit.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_AVAILABLE_PR_UNIT);
        SoldPropertyUnit.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_SOLD_PR_UNIT);
        CancelledPropertyUnit.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_CANCELLED_PR_UNIT);
        Customer.Visible = isCRMEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_CUSTOMER);
        PostSaleMenuHeader.Visible = SaleManagementMenu.Visible;
        //ERP Functional Menu
        ERPDashboard.Visible = isERP();
        //Account and Finance Functional Menu
        AcntFinanceDashboard.Visible = isAcntFinanceEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_FN_ACCOUNT_FINANCE);
        //Account Management
        AccountManagementMenu.Visible = isAcntFinanceEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_ACCOUNT_MANAGEMENT);
        ManageAccounts.Visible = isAcntFinanceEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_ACCOUNTS);
        TallyManagement.Visible = isAcntFinanceEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_TALLY_MANAGEMENT);
        //Payment Management
        PaymentManagementMenu.Visible = isAcntFinanceEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_PAYMENT_MANAGEMENT);
        CustomerPayment.Visible = isAcntFinanceEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_CUSTOMER_PAYMENTS);
        AgencyPayment.Visible = false;
        //Property Funds
        PropertyFund.Visible = isAcntFinanceEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_PROPERTY_FUND_MANAGEMENT);
        AcntFinanceMenuHeader.Visible = AccountManagementMenu.Visible || PaymentManagementMenu.Visible || PropertyFund.Visible;
        //Expense Management
        ExpenseManagementMenu.Visible = false;
        Agency.Visible = false;
        PropertyExpense.Visible = false;
        ExpensesMenuHeader.Visible = false;
        //Account and Finance Reports
        AcntFinanceReportMenu.Visible = isAcntFinanceEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_ACNTFN_REPORT_AND_ANALYTICS);
        PymtDueReport.Visible = isAcntFinanceEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.PAYMENT_DUE_REPORT);
        PymtScheduleReort.Visible = isAcntFinanceEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.PAYMENT_SHEDULE_REPORT);
        AcntFinanceReportMenuHeader.Visible = AcntFinanceReportMenu.Visible;
        //Firm and Property Setup functional menu
        FirmSetup.Visible = isPropertySetupEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_FIRM); ;
        FirmMenuHeader.Visible = FirmSetup.Visible;
        Property.Visible = isPropertySetupEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_PROPERTY); ;
        PropertyUnit.Visible = isPropertySetupEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_PROPERTY_UNIT); ;
        PymtSchedule.Visible = isPropertySetupEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_PROPERTY_PARKING); ;
        PropertyParking.Visible = isPropertySetupEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_PROPERTY_PYMT_SCHEDULE); ;
        PropertySetupMenuHeader.Visible = Property.Visible || PropertyUnit.Visible || PymtSchedule.Visible || PropertyParking.Visible;
        //Adminitstration Functional menu
        MasterData.Visible = isAdministrationEnabled && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.MENU_MANAGE_MASTER); ;

        //Set sidebar menu header
        setSidebarMenuText();
    }
    private void setSidebarMenuText()
    {
    	divSiderbar.Visible = true;
        if (isCRM() && CrmMenu.Visible)
        {
            lbSidebarMenuIcon.Text = Constants.ICON.CRM_FN_MENU;
            lbSidebarMenuText.Text = Resources.Labels.CRM_MENU;
            lbSidebarMenuDesc.Text = "Pre and Post Sale";
        }
        else if (isERP() && ErpMenu.Visible)
        {
            lbSidebarMenuIcon.Text = Constants.ICON.ERP_FN_MENU;
            lbSidebarMenuText.Text = Resources.Labels.ERP_MENU;
            lbSidebarMenuDesc.Text = "Enterprise Resource Planning";
        }
        else if (isAcntFianance() && AcntFinanceMenu.Visible)
        {
            lbSidebarMenuIcon.Text = Constants.ICON.ACNTFINANCE_FN_MENU;
            lbSidebarMenuText.Text = Resources.Labels.ACCNT_FINANCE_MENU;
            lbSidebarMenuDesc.Text = "Account and Payments";
        }
        else if (isFirmPropertySetup() && FirmPropertySetupMenu.Visible)
        {
            lbSidebarMenuIcon.Text = Constants.ICON.PR_SETUP_FN_MENU;
            lbSidebarMenuText.Text = Resources.Labels.FIRM_PROPERTY_SETUP_MENU;
            lbSidebarMenuDesc.Text = "Firm and Property settings";
        }
        else if (isAdministration() && AdministrationMenu.Visible)
        {
            lbSidebarMenuIcon.Text = Constants.ICON.ADMIN_FN_MENU;
            lbSidebarMenuText.Text = Resources.Labels.ADMINISTRATION_MENU;
            lbSidebarMenuDesc.Text = "Application settings";
        } else {
        	divSiderbar.Visible = false;
        }
    }
    public void logoutUser(object sender, EventArgs e)
    {
        CommonUtil.clearSession(Session, Application);
        Response.Redirect(Constants.URL.LOGIN, true);
    }
    public void initPropertyGrid()
    {
        UserDefinitionDTO userDTO = getUserDefinitionDTO();
        propertySelectionGrid.DataSource = userDTO.AssignedProperties;
        propertySelectionGrid.DataBind();
        long defaultPropertyId = 0;
        if (userDTO.AssignedProperties.Count > 0)
        {
            PropertyDTO selectedProperty = userDTO.AssignedProperties.Find(c => c.isUISelected);
            defaultPropertyId = (selectedProperty != null) ? selectedProperty.Id : userDTO.AssignedProperties[0].Id;
        }
         
        selectHeaderProperty(defaultPropertyId);
    }
    protected void onClickSelectNavbarProperty(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            selectHeaderProperty(selectedIndex);
            Response.Redirect(Constants.URL.CRM_DASHBOARD, true);
            /*
             * TODO - We need to define function which will redirect to default page of the User.
             * OR create common landing page of the application where all users will land after login and thereafter they can select function(Horizontal menu) for further navigation.
             * So when user changes Property he will navigate to this common landing page.
             * */
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
        }
    }
    private void selectHeaderProperty(long selectedIndex)
    {
        UserDefinitionDTO userDTO = getUserDefinitionDTO();
        userDTO.AssignedProperties.ForEach(x => x.isUISelected = false);
        foreach (PropertyDTO propertyDTO in userDTO.AssignedProperties)
        {
            if (propertyDTO.Id == selectedIndex)
            {
                propertyDTO.isUISelected = true;
                lbHeaderPropertyName.Text = propertyDTO.Name;
                lbHeaderMobilePropertyName.Text = propertyDTO.Name;
                break;
            }
        }
    }
}
