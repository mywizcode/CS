﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initDLHistoryGrid();
	formatFields();
    showModal();
}
function initDLHistoryGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        hideSearch: true,
        pageLength: 10
    };

    $("[id$='dlHistoryGrid']").CSBasicDatatable(dtOptions);
}