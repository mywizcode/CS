﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.BO;

public partial class PropertyUnitDetails : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifyStep1Error = "addModifyStep1Error";
    string addMasterDataError = "addMasterDataError";
    string addMasterDataModal = "addMasterDataModal";
    DropdownBO drpBO = new DropdownBO();
    PropertyUnitManagementBO prUnitBO = new PropertyUnitManagementBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                PropertyUnitDetailNavDTO navDto = CommonUtil.getPageNavDTO<PropertyUnitDetailNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_PROPERTY_UNIT)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        setPageTitle();
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpUnitType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpDirection, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_DIRECTION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpFacing, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_FACING, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<PRUnitStatus>(drpStatus, Constants.SELECT_ITEM);
    }
    private void setPageTitle()
    {
        if (isAddMode()) lbPageTitle.Text = Constants.ICON.ADD + Resources.Labels.ADD_PROPERTY_UNIT; 
        else if (isModifyMode()) lbPageTitle.Text = Constants.ICON.MODIFY + Resources.Labels.MODIFY_PROPERTY_UNIT;
        else lbPageTitle.Text = Constants.ICON.VIEW_DTL + Resources.Labels.PROPERTY_UNIT_DETAILS;
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void renderPageFieldsWithEntitlement()
    {
        bool modifyMode = isModifyMode();
        bool viewMode = isViewMode();
        bool isAvailable = getSessionPageData().UnitDTO.Status == PRUnitStatus.Available;
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        //Fields
        txtWing.ReadOnly = viewMode || modifyMode;
        txtFloorNo.ReadOnly = viewMode || modifyMode;
        txtUnitNo.ReadOnly = viewMode || modifyMode;
        drpUnitType.Enabled = !viewMode;
        txtNoOfBalcony.ReadOnly = viewMode;
        txtBuiltupArea.ReadOnly = viewMode;
        txtCarpetArea.ReadOnly = viewMode;
        txtBalconyArea.ReadOnly = viewMode;
        drpDirection.Enabled = !viewMode;
        drpFacing.Enabled = !viewMode;
        drpStatus.Enabled = !viewMode;
        txtReserveComments.ReadOnly = viewMode;
        //Buttons
        btnAddModifyPrUnitSubmit.Visible = !viewMode;
        addUnitTypeBtn.Visible = !viewMode && CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_MANAGE_MASTER);
        addDirectionBtn.Visible = !viewMode && CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_MANAGE_MASTER);
        addFacingBtn.Visible = !viewMode && CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_MANAGE_MASTER);

        liModifyPropertyUnit.Visible = viewMode && isAvailable && CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_UNIT_MODIFY);
    }
    private void doInit(PropertyUnitDetailNavDTO navDto)
    {
        initDropdowns();
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(PropertyUnitDetailNavDTO navDto)
    {
        if (navDto != null)
        {
            PropertyUnitDetailPageDTO PageDTO = new PropertyUnitDetailPageDTO();
            pageModeHdn.Value = navDto.Mode.ToString();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            if (isAddMode())
            {
                PageDTO.UnitDTO = populatePropertyUnitDTOAdd();
                populateUIFieldsFromDTO(null);
            }
            else
            {
                PageDTO.UnitDTO = prUnitBO.fetchPropertyUnitDetails(navDto.PrUnitId);
                populateUIFieldsFromDTO(PageDTO.UnitDTO);
            }
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void navigateToPreviousPage()
    {
        PropertyUnitDetailPageDTO PageDTO = getSessionPageData();
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is PropertyUnitSearchNavDTO)
            {
                PropertyUnitSearchNavDTO navDTO = (PropertyUnitSearchNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.PROPERTY_UNIT_SEARCH, true);
            }
        }
        Response.Redirect(Constants.URL.PROPERTY_UNIT_SEARCH, true);
    }
    private bool isViewMode()
    {
        return PageMode.VIEW.ToString().Equals(pageModeHdn.Value);
    }
    private bool isAddMode()
    {
        return PageMode.ADD.ToString().Equals(pageModeHdn.Value);
    }
    private bool isModifyMode()
    {
        return PageMode.MODIFY.ToString().Equals(pageModeHdn.Value);
    }
    private PropertyUnitDetailPageDTO getSessionPageData()
    {
        return (PropertyUnitDetailPageDTO)Session[Constants.Session.PAGE_DATA];
    }

    protected void onSelectUnitStatus(object sender, EventArgs e)
    {
        try
        {
            PRUnitStatus status = EnumHelper.ToEnum<PRUnitStatus>(drpStatus.Text);
            divReverseComments.Visible = (PRUnitStatus.Reserved == status);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void addOrModifyPropertyUnit(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyUnitAddOrModify())
            {
            	PropertyUnitDetailPageDTO PageDTO = getSessionPageData();
                PropertyUnitDTO propertyUnitDTO = PageDTO.UnitDTO;
                populatePropertyUnitDTOFromUI(propertyUnitDTO);
                long Id = propertyUnitDTO.Id;
                string msg = "";
                if (isAddMode())
                {
                    Id = prUnitBO.savePropertyUnitDetails(propertyUnitDTO);
                    msg = string.Format("Property Unit '{0}' is added successfully.", CommonUIConverter.getPropertyUnitFormattedNo(propertyUnitDTO.Wing, propertyUnitDTO.UnitNo));
                }
                else if (isModifyMode())
                {
                    prUnitBO.updatePropertyUnitDetails(propertyUnitDTO);
                    msg = string.Format("Property Unit '{0}' is updated successfully.", CommonUIConverter.getPropertyUnitFormattedNo(propertyUnitDTO.Wing, propertyUnitDTO.UnitNo));
                }
                Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg(msg));
                navigateToPreviousPage();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addModifyStep1Error);
        }
    }
    protected void onClickModifyPropertyUnitBtn(object sender, EventArgs e)
    {
        try
        {
            PropertyUnitDetailPageDTO PageDTO = getSessionPageData();
            PropertyUnitDTO unitDTO = PageDTO.UnitDTO;
            PropertyUnitDetailNavDTO navDTO = new PropertyUnitDetailNavDTO();
            navDTO.Mode = PageMode.MODIFY;
            if (unitDTO != null) navDTO.PrUnitId = unitDTO.Id;
            navDTO.PrevNavDto = PageDTO.PrevNavDTO;
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.PROPERTY_UNIT_DETAILS, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelPropertyUnit(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    /**
     * Define all validation which will be done before add or Modify property.
     * */
    private bool validatePropertyUnitAddOrModify()
    {
        bool isValid = validateAllStep1Group();
        return isValid;
    }
    private bool validateAllStep1Group()
    {
        bool isValid = true;
        Page.Validate(addModifyStep1Error);
        isValid = Page.IsValid;
        if (isValid) isValid = validateUnitAddOrModifyOther();
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    private bool validateUnitAddOrModifyOther()
    {
        bool isValid = true;
        PRUnitStatus status = EnumHelper.ToEnum<PRUnitStatus>(drpStatus.Text);
        if (!(PRUnitStatus.Available == status || PRUnitStatus.Reserved == status))
        {
            isValid = false;
            setErrorMessage("Please select Status as 'Available' or 'Reserved'.", addModifyStep1Error);
        }
        if (PRUnitStatus.Reserved == status && string.IsNullOrWhiteSpace(txtReserveComments.Text))
        {
            isValid = false;
            setErrorMessage("Please enter Reserve Comments.", addModifyStep1Error);
        }
        if (isAddMode())
        {
            PropertyUnitDTO unitDto = getSessionPageData().UnitDTO;
            if (prUnitBO.validateUnitExist(getUserDefinitionDTO().FirmNumber, unitDto.Id, txtWing.Text,
                txtFloorNo.Text, txtUnitNo.Text))
            {
                setErrorMessage("Property Unit already exist.", addModifyStep1Error);
                isValid = false;
            }
        }
        return isValid;
    }
    private PropertyUnitDTO populatePropertyUnitDTOAdd()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        PropertyUnitDTO propertyUnitDto = new PropertyUnitDTO();
        PropertyTowerDTO towerDto = CommonUtil.getStickyPrTowerDTO(userDefDto);
        propertyUnitDto.PropertyTower = new PropertyTowerDTO();
        propertyUnitDto.PropertyTower.Id = towerDto.Id;
        propertyUnitDto.PropertyTower.Name = towerDto.Name;
        propertyUnitDto.FirmNumber = userDefDto.FirmNumber;
        propertyUnitDto.InsertUser = userDefDto.Username;
        return propertyUnitDto;
    }
    private void populatePropertyUnitDTOFromUI(PropertyUnitDTO propertyUnitDTO)
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        if (isAddMode())
        {
            propertyUnitDTO.Wing = txtWing.Text;
            propertyUnitDTO.FloorNo = txtFloorNo.Text;
            propertyUnitDTO.UnitNo = txtUnitNo.Text;
        }
        propertyUnitDTO.UnitType = CommonUIConverter.getMasterControlDTO(drpUnitType.Text, null);
        propertyUnitDTO.BuildupArea = CommonUtil.getDecimalWithoutExt(txtBuiltupArea.Text);
        propertyUnitDTO.CarpetArea = CommonUtil.getDecimalWithoutExt(txtCarpetArea.Text);
        propertyUnitDTO.BalconyArea = CommonUtil.getDecimalWithoutExt(txtBalconyArea.Text);
        propertyUnitDTO.Facing = CommonUIConverter.getMasterControlDTO(drpFacing.Text, null);
        propertyUnitDTO.Status = EnumHelper.ToEnum<PRUnitStatus>(drpStatus.Text);
        propertyUnitDTO.Direction = CommonUIConverter.getMasterControlDTO(drpDirection.Text, null);
        propertyUnitDTO.ReserveComments = (propertyUnitDTO.Status == PRUnitStatus.Reserved) ? txtReserveComments.Text : "";
        propertyUnitDTO.NoOfBalcony = Convert.ToInt32(txtNoOfBalcony.Text);
        propertyUnitDTO.FirmNumber = userDefDto.FirmNumber;
        propertyUnitDTO.Version = userDefDto.Version;
        propertyUnitDTO.UpdateUser = userDefDto.Username;
    }
    private void populateUIFieldsFromDTO(PropertyUnitDTO propertyUnitDto)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        txtProperty.Text = CommonUtil.getCurrentPropertyDTO(userDefDto).Name;
        txtTower.Text = CommonUtil.getStickyPrTowerDTO(userDefDto).Name;
        divReverseComments.Visible = false;
        if (!isAddMode())
        {
            if (propertyUnitDto != null) drpUnitType.Text = propertyUnitDto.UnitType.Id.ToString(); else drpUnitType.Text = null;
            if (propertyUnitDto != null) txtWing.Text = propertyUnitDto.Wing; else txtWing.Text = null;
            if (propertyUnitDto != null) txtReserveComments.Text = propertyUnitDto.ReserveComments; else txtReserveComments.Text = null;
            if (propertyUnitDto != null) txtNoOfBalcony.Text = propertyUnitDto.NoOfBalcony.ToString(); else txtNoOfBalcony.Text = null;
            if (propertyUnitDto != null) txtFloorNo.Text = propertyUnitDto.FloorNo; else txtFloorNo.Text = null;
            if (propertyUnitDto != null) txtUnitNo.Text = propertyUnitDto.UnitNo; else txtUnitNo.Text = null;
            if (propertyUnitDto != null && propertyUnitDto.BuildupArea != null) txtBuiltupArea.Text = propertyUnitDto.BuildupArea.ToString(); else txtBuiltupArea.Text = null;
            if (propertyUnitDto != null && propertyUnitDto.CarpetArea != null) txtCarpetArea.Text = propertyUnitDto.CarpetArea.ToString(); else txtCarpetArea.Text = null;
            if (propertyUnitDto != null && propertyUnitDto.BalconyArea != null) txtBalconyArea.Text = propertyUnitDto.BalconyArea.ToString(); else txtBalconyArea.Text = null;
            if (propertyUnitDto != null && propertyUnitDto.Facing != null) drpFacing.Text = propertyUnitDto.Facing.Id.ToString(); else drpFacing.Text = null;
            if (propertyUnitDto != null) drpStatus.Text = propertyUnitDto.Status.ToString(); else drpStatus.Text = PRUnitStatus.Available.ToString();
            if (propertyUnitDto != null && propertyUnitDto.Direction != null) drpDirection.Text = propertyUnitDto.Direction.Id.ToString(); else drpDirection.ClearSelection();
            divReverseComments.Visible = (propertyUnitDto != null && PRUnitStatus.Reserved == propertyUnitDto.Status);
        }
    }
    //Master Data Modal save logic - Start
    protected void saveMasterData(object sender, EventArgs e)
    {
        try
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (masterDataModalTypeHdn.Value == "UNIT_TYPE")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_UNIT_TYPE, txtMasterDataInput1.Text,
                        txtMasterDataInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Unit Type");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpUnitType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
            }
            else if (masterDataModalTypeHdn.Value == "DIRECTION")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_UNIT_DIRECTION, txtMasterDataInput1.Text,
                        txtMasterDataInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Direction");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpDirection, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_DIRECTION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
            }
            else if (masterDataModalTypeHdn.Value == "FACING")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_UNIT_FACING, txtMasterDataInput1.Text,
                        txtMasterDataInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Facing");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpFacing, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_FACING, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
            }

            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                activeModalHdn.Value = addMasterDataModal;
                setErrorMessage(errorMsg, addMasterDataError);
            }
            else
            {
                resetMasterDataModalFields();
                setParentModalFlag();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            activeModalHdn.Value = "";
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    protected void cancelMasterDataModal(object sender, EventArgs e)
    {
        try
        {
            resetMasterDataModalFields();
            setParentModalFlag();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    private void resetMasterDataModalFields()
    {
        txtMasterDataInput1.Text = "";
        txtMasterDataInput2.Text = "";
        masterDataModalTypeHdn.Value = "";
    }
    private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
    {
        string errorMsg = "";
        if (string.IsNullOrWhiteSpace(masterDataDto.Name))
        {
            errorMsg = string.Format(Resources.Messages.TEXTFIELD_REQUIRED, type);
        }
        else if (masterDataBO.isAlreadyExist(masterDataDto))
        {
            errorMsg = string.Format(Resources.Messages.ALREADY_EXIST_DB_ERROR, type);
        }
        return errorMsg;
    }
    private void setParentModalFlag()
    {
        activeModalHdn.Value = masterDataParentModalHdn.Value;
        masterDataParentModalHdn.Value = "";
    }
    //Master Data Modal save logic - End
}