﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
	initLeadUploadGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}
function initLeadUploadGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        pageLength: 10
    };

    $("[id$='leadUploadGrid']").CSBasicDatatable(dtOptions);
}




