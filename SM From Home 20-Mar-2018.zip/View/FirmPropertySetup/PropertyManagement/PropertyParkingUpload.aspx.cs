﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.BO;
using ConstroSoft.Logic.Util;
using OfficeOpenXml;

public partial class PropertyParkingUpload : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    DropdownBO drpBO = new DropdownBO();
    PropertyBO propertyBO = new PropertyBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                PropertyParkingUploadNavDTO navDto = ApplicationUtil.getPageNavDTO<PropertyParkingUploadNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.PROPERTY_PARKING_ADD)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
    	ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
    }
    public void setErrorMessage(string message, string group)
    {
    	string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        } else CommonUtil.getCustomValidator(Page, message, group);
    }
    private void renderPageFieldsWithEntitlement()
    {

    }
    private void doInit(PropertyParkingUploadNavDTO navDto)
    {
        initDropdowns();
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(PropertyParkingUploadNavDTO navDto)
    {
        if (navDto != null)
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            PropertyParkingUploadPageDTO PageDTO = new PropertyParkingUploadPageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            //Reset page details
            txtUploadParkingProperty.Text = CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()).Name;
            pnlUploadParkingDetail.Visible = false;
            PageDTO.UploadFailedResult = new List<PropertyParkingMapperDTO>();
            PageDTO.UploadSuccessResult = new List<PropertyParkingMapperDTO>();
            DropDownList drpParkingType = new DropDownList();
            DropDownList drpTower = new DropDownList();
            drpBO.drpDataBase(drpParkingType, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.PR_PARKING_TYPE.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpTower, DrpDataType.PROPERTY_TOWER, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(), null, userDefDto.FirmNumber);
            PageDTO.drpParkingType = drpParkingType;
            PageDTO.drpTower = drpTower;
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void navigateToPreviousPage()
    {
        PropertyParkingUploadPageDTO PageDTO = getSessionPageData();
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is PropertyParkingSearchNavDTO)
            {
                PropertyParkingSearchNavDTO navDTO = (PropertyParkingSearchNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.PROPERTY_PARKING_SEARCH, true);
            }
        }
        Response.Redirect(Constants.URL.PROPERTY_UNIT_SEARCH, true);
    }
    private PropertyParkingUploadPageDTO getSessionPageData()
    {
        return (PropertyParkingUploadPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<PropertyParkingMapperDTO> getUploadFailedList()
    {
        return getSessionPageData().UploadFailedResult;
    }
    private List<PropertyParkingMapperDTO> getUploadSuccessList()
    {
        return getSessionPageData().UploadSuccessResult;
    }
    private bool isUploadSubmitToEnabled()
    {
        return getUploadSuccessList().Count > 0 && Constants.UPLOAD_VALIDATED.Equals(lbSuccessUploadParkingsText.Text);
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelPropertyParking(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    public void validatePropertyParkings(object sender, EventArgs e)
    {
        try
        {
            pnlUploadParkingDetail.Visible = false;
            HttpFileCollection uploadedFiles = Request.Files;
            List<PropertyParkingMapperDTO> validationFailedList = new List<PropertyParkingMapperDTO>();
            List<PropertyParkingMapperDTO> validationSuccessList = new List<PropertyParkingMapperDTO>();
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            for (int i = 0; i < uploadedFiles.Count; i++)
            {
                HttpPostedFile userPostedFile = uploadedFiles[i];
                if (userPostedFile.ContentLength > 0)
                {
                    string filename = Path.GetFileName(userPostedFile.FileName);
                    string extension = Path.GetExtension(filename);
                    HttpPostedFile file = fileUploadParkings.PostedFile;
                    if (validateFileType(extension))
                    {
                        using (file.InputStream)
                        {
                            ExcelPackage excel = new ExcelPackage(file.InputStream);
                            var workSheet = excel.Workbook.Worksheets[1];
                            IEnumerable<PropertyParkingMapperDTO> newcollection = workSheet.ConvertSheetToObjects<PropertyParkingMapperDTO>();
                            int RowNumber = 2;
                            foreach (PropertyParkingMapperDTO inputDTO in newcollection)
                            {
                            	inputDTO.RowNumber = RowNumber++;
                            	validateInputDTO(inputDTO, validationSuccessList);
                            	if (inputDTO.IsError) validationFailedList.Add(inputDTO);
                                else validationSuccessList.Add(inputDTO);
                            }
                        }
                        pnlUploadParkingDetail.Visible = true;
                        getSessionPageData().UploadFailedResult = validationFailedList;
                        getSessionPageData().UploadSuccessResult = validationSuccessList;

                        lbTotalUploadParkingsCount.Text = (validationFailedList.Count + validationSuccessList.Count) + "";
                        lbSuccessUploadParkingsCount.Text = validationSuccessList.Count + "";
                        lbSuccessUploadParkingsText.Text = Constants.UPLOAD_VALIDATED;
                        lbFailedUploadParkingsCount.Text = validationFailedList.Count + "";
                        btnUploadParkingSubmit.Visible = isUploadSubmitToEnabled();
                        populateParkingUploadGrid(validationSuccessList, "SUCCESS");
                    }
                }
                else
                {
                    setErrorMessage("Please Select valid file to upload.", commonError);
                }
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    public void showUploadParkings(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            string mode = rd.Attributes["data-show"];
            btnUploadParkingSubmit.Visible = false;
            if ("ALL".Equals(mode))
            {
                List<PropertyParkingMapperDTO> allParkings = new List<PropertyParkingMapperDTO>();
                allParkings.AddRange(getUploadFailedList());
                allParkings.AddRange(getUploadSuccessList());
                btnUploadParkingSubmit.Visible = isUploadSubmitToEnabled();
                populateParkingUploadGrid(allParkings, mode);
            }
            else if ("SUCCESS".Equals(mode))
            {
                btnUploadParkingSubmit.Visible = isUploadSubmitToEnabled();
                populateParkingUploadGrid(getUploadSuccessList(), mode);
            }
            else if ("ERROR".Equals(mode))
            {
                populateParkingUploadGrid(getUploadFailedList(), mode);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    public void addPropertyParkings(object sender, EventArgs e)
    {
        try
        {
            List<PropertyParkingMapperDTO> uploadList = getUploadSuccessList();
            if (uploadList != null && uploadList.Count > 0)
            {
                List<PropertyParkingMapperDTO> successList = new List<PropertyParkingMapperDTO>();
                List<PropertyParkingMapperDTO> failureList = new List<PropertyParkingMapperDTO>();
                foreach (PropertyParkingMapperDTO inputDTO in uploadList)
                {
                    if (!inputDTO.IsError)
                    {
                        try
                        {
                        	propertyBO.savePropertyParkingDetails(populateUnitDTO(inputDTO));
                            successList.Add(inputDTO);
                        }
                        catch (Exception exp)
                        {
                        	inputDTO.IsError = true;
                        	inputDTO.AllErrorMessage.Add("Failed to upload, Unexpected error has occurred.");
                            failureList.Add(inputDTO);
                        }
                    }
                }
                btnUploadParkingSubmit.Visible = false;
                string msg = (uploadList.Count == successList.Count) ? "Upload process is completed. All Property Parkings are uploaded successfully." :
                    "Upload process is completed. Some of the Property Parkings are not uploaded, Please check Failure records.";
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(msg));

                failureList.AddRange(getUploadFailedList());
                getSessionPageData().UploadFailedResult = failureList;
                getSessionPageData().UploadSuccessResult = successList;
                populateParkingUploadGrid(successList, "SUCCESS");

                lbSuccessUploadParkingsCount.Text = successList.Count + "";
                lbSuccessUploadParkingsText.Text = Constants.UPLOAD_SUCCESS;
                lbFailedUploadParkingsCount.Text = failureList.Count + "";
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    private void populateParkingUploadGrid(IList<PropertyParkingMapperDTO> results, string mode)
    {
        parkingUploadGrid.Columns[5].Visible = "ALL".Equals(mode) && Constants.UPLOAD_SUCCESS.Equals(lbSuccessUploadParkingsText.Text);
        parkingUploadGrid.Columns[6].Visible = !"SUCCESS".Equals(mode);
        assignUiIndexToTaxDetail(results);
        parkingUploadGrid.DataSource = results;
        parkingUploadGrid.DataBind();
    }

    private void assignUiIndexToTaxDetail(IList<PropertyParkingMapperDTO> results)
    {
        if (results != null && results.Count > 0)
        {
            long uiIndex = 1;
            foreach (PropertyParkingMapperDTO tmpDto in results)
            {
            	tmpDto.RowInfo = CommonUIConverter.getGridViewRowInfo(tmpDto);
                if(tmpDto.IsError) {
                	tmpDto.ErrorMessage = (tmpDto.AllErrorMessage.Count > 1) ? "Multiple errors occurred." : tmpDto.AllErrorMessage[0];
                }
            }
        }
    }
    private PropertyParkingDTO populateUnitDTO(PropertyParkingMapperDTO inputDTO)
    {
    	PropertyParkingDTO tmpDTO = new PropertyParkingDTO();
        try
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            tmpDTO.PropertyTower = CommonUIConverter.getPropertyTowerDTO(drpBO.getListItem(getSessionPageData().drpTower, inputDTO.TowerName).Value, "");
            tmpDTO.ParkingNo = inputDTO.ParkingNumber.TrimNullable();
            tmpDTO.ParkingType = CommonUIConverter.getMasterControlDTO(drpBO.getListItem(getSessionPageData().drpParkingType, inputDTO.ParkingType).Value, "");
            tmpDTO.Area = CommonUtil.getDecimalWithoutExt(inputDTO.ParkingArea);
            tmpDTO.CommonParking = EnumHelper.ToEnum<CommonParking>(inputDTO.CommonParking);
            tmpDTO.Status = EnumHelper.ToEnum<ParkingStatus>(inputDTO.Status);
            tmpDTO.FirmNumber = userDefDto.FirmNumber;
            tmpDTO.InsertUser = userDefDto.Username;
            tmpDTO.UpdateUser = userDefDto.Username;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw new CustomException("Unexpected error while parsing record. Row:"+inputDTO.RowNumber);
        }
        return tmpDTO;
    }
    private void validateInputDTO(PropertyParkingMapperDTO inputDTO, List<PropertyParkingMapperDTO> inputList) 
    {
        List<string> errorList = new List<string>();
        try
        {
        	//1. Mandatory Validations
        	//2. Format validations (Date/Amount)
        	//3. Valid values
        	//4. Length validations
        	UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        	 //Property
        	if(string.IsNullOrWhiteSpace(inputDTO.PropertyName)) errorList.Add("Property Name is required.");
        	else if(!inputDTO.PropertyName.Equals(txtUploadParkingProperty.Text))  errorList.Add("Property name does not match with selected Property.");
        	//Tower
        	if(string.IsNullOrWhiteSpace(inputDTO.TowerName)) errorList.Add("Tower Name is required.");
        	else if(!drpBO.containsItem(getSessionPageData().drpTower, inputDTO.TowerName)) errorList.Add("Tower Name is invalid.");
        	//Parking Number
        	if(string.IsNullOrWhiteSpace(inputDTO.ParkingNumber)) errorList.Add("Parking No is required.");
        	else if(!StringUtil.isValidLength(inputDTO.ParkingNumber, 20)) errorList.Add("Length of Parking No must be less than 20 characters.");
        	//Parking Type
            if(string.IsNullOrWhiteSpace(inputDTO.ParkingType)) errorList.Add("Parking Type is required.");
            else if (!drpBO.containsItem(getSessionPageData().drpParkingType, inputDTO.ParkingType)) errorList.Add("Parking Type is invalid.");
            //Parking Area
            if(!StringUtil.isValidDecimalNullable(inputDTO.ParkingArea)) errorList.Add("Parking Area is not valid.");
            //Status
            if(string.IsNullOrWhiteSpace(inputDTO.CommonParking)) errorList.Add("Common Parking is required.");
        	else if(!EnumHelper.isValidEnum<CommonParking>(inputDTO.CommonParking)) errorList.Add("Common Parking is invalid.");
            //Status
            if(string.IsNullOrWhiteSpace(inputDTO.Status)) errorList.Add("Status is required.");
        	else if(!EnumHelper.isValidEnum<ParkingStatus>(inputDTO.Status)) errorList.Add("Status is invalid.");
            
            if(errorList.Count == 0) {
                if (propertyBO.validateParkingExist(userDefDto.FirmNumber, long.Parse(drpBO.getListItem(getSessionPageData().drpTower, inputDTO.TowerName).Value), 
            			inputDTO.ParkingNumber.TrimNullable())) {
            		 errorList.Add(string.Format("Parking {0} already exist.", inputDTO.ParkingNumber.Trim()));
            	} else {
            		foreach (PropertyParkingMapperDTO tmpDTO in inputList)
                    {
                        if (tmpDTO.TowerName.Equals(inputDTO.TowerName) && tmpDTO.ParkingNumber.Trim().Equals(inputDTO.ParkingNumber.Trim()))
                        {
                        	errorList.Add(string.Format("Duplicate Parking with same Parking No.", tmpDTO.ParkingNumber.Trim()));
                        }
                    }
            	}
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            errorList.Add("Unexpected error while parsing record.");
        }
        inputDTO.IsError = (errorList.Count > 0);
    	inputDTO.AllErrorMessage = errorList;
    }
    private bool validateFileType(string extension)
    {
        bool isValid = true;
        if (extension != ".xlsx" && extension != ".xls")
        {
            isValid = false;
            setErrorMessage("Please use valid Property Parking upload template.", commonError);
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;

    }
}