﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.TelephonyProvider;
using System.Web;

public partial class LeadActivityHistory : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string selectUserAssigneeModalError = "selectUserAssigneeModalError";
    string addReminderModalError = "addReminderModalError";
    string addReminderModalError1 = "addReminderModalError1";
    string addCommentModalError = "addCommentModalError";

    string selectUserAssigneeModal = "selectUserAssigneeModal";
    string addReminderModal = "addReminderModal";
    string addCommentModal = "addCommentModal";
    string ClickToCallModal = "ClickToCallModal";
    string clickToCallModalError = "clickToCallModalError";
    string closeLeadModal = "closeLeadModal";
    string closeLeadModalError = "closeLeadModalError";
    string editActivityCommentModal = "editActivityCommentModal";
    string editActivityCommentModalError = "editActivityCommentModalError";
    string ShowActivityLogModal = "ShowActivityLogModal";
    string SearchFilterModal = "SearchFilterModal";
    string ShowAttachmentModal = "ShowAttachmentModal";
    DropdownBO drpBO = new DropdownBO();
    EnquiryBO enquiryBO = new EnquiryBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    PropertyUserBO propertyUserBO = new PropertyUserBO();
    DocumentBO documentBO = new DocumentBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                LeadActivityHistoryNavDTO navDto = ApplicationUtil.getPageNavDTO<LeadActivityHistoryNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_MY_LEADS)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
    	renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        drpBO.drpEnum<ActivityTypeFilter>(drpRecordTypeFilter, Constants.SELECT_ITEM, ActivityTypeFilter.Activity.GetDescription());
    }
    public void setErrorMessage(string message, string group)
    {
    	string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
	        CustomValidator val = new CustomValidator();
	        val.IsValid = false;
	        val.ErrorMessage = message;
	        val.ValidationGroup = group;
	        this.Page.Validators.Add(val);
        }
    }
    private void doInit(LeadActivityHistoryNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(LeadActivityHistoryNavDTO navDto)
    {
        try
        {
            LeadActivityHistoryPageDTO PageDTO = new LeadActivityHistoryPageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            setSearchFilter(null);
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            fetchLeadAndInitHistory(navDto.LeadId);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageFieldsWithEntitlement()
    {
    	LeadDetailDTO leadDTO = getLeadDetailDTO();
        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        liCicktoCall.Visible = (leadDTO.Status == LeadStatus.Open && CommonUtil.hasEntitlement(userDefDTO, Constants.Entitlement.LEAD_CLICK_TO_CALL));
    }
    private LeadActivityHistoryPageDTO getSessionPageData()
    {
        return (LeadActivityHistoryPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private LeadDetailDTO getLeadDetailDTO()
    {
        return getSessionPageData().LeadDTO;
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private void navigateToPreviousPage()
    {
        LeadActivityHistoryPageDTO pageDTO = getSessionPageData();
        if (pageDTO != null && pageDTO.PrevNavDTO != null)
        {
            object obj = pageDTO.PrevNavDTO;
            if (obj is MyLeadsNavDTO)
            {
                MyLeadsNavDTO navDTO = (MyLeadsNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.MY_LEADS, true);
            }
            else if (obj is UserLeadHistoryNavDTO)
            {
                UserLeadHistoryNavDTO navDTO = (UserLeadHistoryNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.USER_LEAD_HISTORY, true);
            }
        }
        Response.Redirect(Constants.URL.MY_LEADS, true);
    }
    private void fetchLeadAndInitHistory(long LeadId)
    {
        LeadDetailDTO leadDTO = enquiryBO.fetchLeadDetails(LeadId, true);
        LeadActivityHistoryPageDTO pageDTO = getSessionPageData();
        pageDTO.LeadDTO = leadDTO;
        initPageInfo(leadDTO);
        initContactDrp(leadDTO);
    }
    private void initPageInfo(LeadDetailDTO leadDTO)
    {
        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        leadDTO.Assignee.FullName = CommonUIConverter.getCustomerFullName(leadDTO.Assignee.FirstName, leadDTO.Assignee.LastName);
        if (leadDTO.LeadActivities != null && leadDTO.LeadActivities.Count > 0)
        {
            List<LeadActivityDTO> list = new List<LeadActivityDTO>(leadDTO.LeadActivities);
            leadDTO.LeadActivities.Clear();
            leadDTO.LeadActivities = new HashSet<LeadActivityDTO>(list.OrderByDescending(x => x.DateLogged).ThenByDescending(x => x.InsertDate));
        }
        //Lead Detail Panel
        ulLeadDetailOptions.Visible = (leadDTO.Status == LeadStatus.Open);
        lbCustomerName.Text = CommonUIConverter.getCustomerFullName(leadDTO.Salutation.Name, leadDTO.FirstName, "", leadDTO.LastName);
        lbCustomerContact.Text = leadDTO.ContactInfo.Contact;
        btnLeadInfoHdn.Attributes["row-info"] = CommonUIConverter.getGridViewRowInfo(leadDTO);
        lbLeadAssignee.Text = leadDTO.Assignee.FullName;
        lbLeadRefNo.Text = leadDTO.LeadRefNo;
        lbEnquiryRefNo.Text = (leadDTO.EnquiryDetail != null) ? leadDTO.EnquiryDetail.EnquiryRefNo : null;
        pnlEnquiryRefNo.Visible = leadDTO.EnquiryDetail != null;
        lbLeadSource.Text = (leadDTO.Source != null) ? leadDTO.Source.Name : null;
        lbLeadBudget.Text = (leadDTO.Budget != null) ? leadDTO.Budget.ToString() : null;
        lbLeadStatus.Text = leadDTO.Status.ToString();
        //Populate Activity History
        assignUiIndexToActivity(leadDTO);
        populateActivityGrid(leadDTO);
        //Upcoming Reminder Panel
        populateUpcomingReminders(leadDTO);
    }
    private void populateUpcomingReminders(LeadDetailDTO leadDTO)
    {
        leadDTO.UpcomingEvents = new List<LeadActivityDTO>();
        ISet<LeadActivityDTO> activities = leadDTO.LeadActivities;
        if (activities != null && activities.Count > 0)
        {
            foreach (LeadActivityDTO activityDTO in activities)
            {
                if (activityDTO.RecordType == EnqActivityRecordType.Task && activityDTO.Status == EnqLeadActivityStatus.Open)
                {
                    leadDTO.UpcomingEvents.Add(activityDTO);
                }
            }
        }
        ulUpcomingReminderOptions.Visible = (leadDTO.Status == LeadStatus.Open);
        pnlUpcomingReminderEmpty.Visible = leadDTO.UpcomingEvents.Count == 0;
        upcomingReminderGrid.Visible = leadDTO.UpcomingEvents.Count > 0;
        upcomingReminderGrid.DataSource = leadDTO.UpcomingEvents;
        upcomingReminderGrid.DataBind();
    }
    private void initContactDrp(LeadDetailDTO leadDetailDTO)
    {
        drpCustomerContact.Items.Clear();
        if (!String.IsNullOrEmpty(leadDetailDTO.ContactInfo.Contact))
        {
            drpCustomerContact.Items.Add(new ListItem("Primary Contact: " + leadDetailDTO.ContactInfo.Contact, 
            		leadDetailDTO.ContactInfo.Contact));
        }
        if (!String.IsNullOrEmpty(leadDetailDTO.ContactInfo.AltContact))
        {
            drpCustomerContact.Items.Add(new ListItem("Alternate Contact: " + leadDetailDTO.ContactInfo.AltContact, 
            		leadDetailDTO.ContactInfo.AltContact));
        }
    }
    private void initVirtualPhoneDrp(IList<VirtualPhoneDTO> phoneDTOList) {
    	drpVirtualPhone.Items.Clear();
    	foreach(VirtualPhoneDTO tmpDTO in phoneDTOList) {
    		drpVirtualPhone.Items.Add(new ListItem(tmpDTO.PhoneNumber, tmpDTO.PhoneNumber));
    	}
    }
    private void populateActivityGrid(LeadDetailDTO leadDTO)
    {
        activityHistoryGrid.DataSource = new List<LeadActivityDTO>();
        if (leadDTO != null && leadDTO.LeadActivities != null && leadDTO.LeadActivities.Count > 0)
        {
            activityHistoryGrid.DataSource = leadDTO.LeadActivities;
            ActivityFilterDTO FilterDTO = getSearchFilter();
            List<LeadActivityDTO> tmpList = leadDTO.LeadActivities.ToList();
            if (FilterDTO.ActivityTypeList != null && FilterDTO.ActivityTypeList.Count > 0)
            {
                tmpList = new List<LeadActivityDTO>();
                foreach (LeadActivityDTO tmpDTO in leadDTO.LeadActivities)
                {
                    if (FilterDTO.ActivityTypeList.Contains(tmpDTO.RecordType.GetDescription())
                        || (FilterDTO.ActivityTypeList.Contains(Constants.FILTER.ATTACHMENT) && tmpDTO.NoOfAttachments > 0))
                    {
                        tmpList.Add(tmpDTO);
                    }
                }
            }
            activityHistoryGrid.DataSource = tmpList;
        }
        activityHistoryGrid.DataBind();
    }
    private void assignUiIndexToActivity(LeadDetailDTO leadDTO)
    {
        ISet<LeadActivityDTO> activities = leadDTO.LeadActivities;
        if (activities != null && activities.Count > 0)
        {
            long uiIndex = 1;
            foreach (LeadActivityDTO activityDTO in activities)
            {
                activityDTO.UiIndex = uiIndex++;
                activityDTO.RowInfo = CommonUIConverter.getGridViewRowInfo(activityDTO);
                activityDTO.LoggedBy.FullName = CommonUIConverter.getCustomerFullName(activityDTO.LoggedBy.FirstName, activityDTO.LoggedBy.LastName);
                activityDTO.LeadDetail = leadDTO;
                if (activityDTO.RecordType == EnqActivityRecordType.Task && !string.IsNullOrWhiteSpace(activityDTO.RevRefNo))
                {
                    LeadActivityDTO tmpDTO = activities.ToList<LeadActivityDTO>().Find(x => !string.IsNullOrWhiteSpace(x.RefNo) && x.RefNo == activityDTO.RevRefNo);
                    activityDTO.PrevScheduledDate = tmpDTO.ScheduledDate;
                }
            }
        }
    }
    private LeadActivityHistoryNavDTO getCurrentPageNavigation()
    {
        LeadActivityHistoryPageDTO PageDTO = getSessionPageData();
        LeadActivityHistoryNavDTO navDTO = new LeadActivityHistoryNavDTO();
        navDTO.LeadId = PageDTO.LeadDTO.Id;
        navDTO.PrevNavDto = PageDTO.PrevNavDTO;
        return navDTO;
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickReassignLeadBtn(object sender, EventArgs e)
    {
        try
        {
            LeadDetailDTO leadDTO = getLeadDetailDTO();
            if (leadDTO.Status == LeadStatus.Open)
            {
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                drpBO.drpDataBase(drpUserAssignee, DrpDataType.ACTIVE_USERS_WITH_PR_ACCESS, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(),
                    Constants.SELECT_ITEM, userDefDto.FirmNumber);
                drpBO.removeSelectedItem(drpUserAssignee, leadDTO.Assignee.Id.ToString());
                activeModalHdn.Value = selectUserAssigneeModal;
            }
            else
            {
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(Resources.Messages.ERROR_LEAD_REASSIGN_NOT_OPEN));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickConvertToEnquiryBtn(object sender, EventArgs e)
    {
        try
        {
            LeadDetailDTO leadDTO = getLeadDetailDTO();
            if (validateConvertToEnquiry(leadDTO))
            {
                EnquiryDetailNavDTO navDTO = new EnquiryDetailNavDTO();
                navDTO.Mode = PageMode.ADD;
                navDTO.ConvertedLeadId = leadDTO.Id;
                navDTO.PrevNavDto = getCurrentPageNavigation();
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.ENQUIRY_DETAILS, true);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateConvertToEnquiry(LeadDetailDTO leadDTO)
    {
        if (leadDTO.Status != LeadStatus.Open)
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(Resources.Messages.ERROR_LEAD_CONVERT_NOT_OPEN));
            return false;
        }
        return true;
    }
    private void selectUpcomingReminder(long Id)
    {
        LeadDetailDTO leadDetailDTO = getLeadDetailDTO();
        leadDetailDTO.UpcomingEvents.ForEach(x => x.isUISelected = false);
        if (Id > 0)
        {
            leadDetailDTO.UpcomingEvents.Find(x => x.Id == Id).isUISelected = true;
        }
    }
    private EnqActivityMode getEnqActivityMode()
    {
        return EnumHelper.ToEnum<EnqActivityMode>(leadActivityModeHdn.Value);
    }
    private void setEnqActivityMode(EnqActivityMode action)
    {
        leadActivityModeHdn.Value = action.ToString();
    }
    protected string getActivityDesc(string activityType)
    {
        return EnumHelper.ToEnum<EnqActivityType>(activityType).GetDescription();
    }
    //Edit Activity Comments Modal - start
    private LeadActivityDTO getSelectedActivity()
    {
        List<LeadActivityDTO> tmpList = getLeadDetailDTO().LeadActivities.ToList<LeadActivityDTO>();
        return tmpList.Find(c => c.isUISelected);
    }
    private void setSelectedActivity(long Id)
    {
        LeadDetailDTO tmpDTO = getLeadDetailDTO();
        tmpDTO.LeadActivities.ToList<LeadActivityDTO>().ForEach(x => x.isUISelected = false);
        if (Id > 0)
        {
            tmpDTO.LeadActivities.ToList<LeadActivityDTO>().Find(x => x.Id == Id).isUISelected = true;
        }
    }
    protected void onClickModifyActivityComments(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedActivity(selectedIndex);
            LeadActivityDTO selectedActivityDTO = getSelectedActivity();
            activeModalHdn.Value = editActivityCommentModal;
            txtActivityEditComments.Text = getSelectedActivity().Comments;
            divAttchmentEditActModalRow.Visible = (selectedActivityDTO.ActivityType != EnqActivityType.TASK);
            clearTempUploadFields();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void modifyActivityComments(object sender, EventArgs e)
    {
        try
        {
            string comments = txtActivityEditComments.Text.TrimNullable();
            if (!string.IsNullOrWhiteSpace(comments))
            {
                LeadActivityDTO tmpDTO = getSelectedActivity();
                List<LeadActAttachmentDTO> tmpAttachments = getAttachmentFromTempFolder();
                if (!tmpDTO.Comments.Equals(comments) || tmpAttachments.Count > 0)
                {
                    tmpDTO.Comments = comments;
                    tmpDTO.Attachments = tmpAttachments;
                    enquiryBO.editLeadActivity(tmpDTO, getUserDefinitionDTO());
                    clearTempUploadFields();
                    (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("Activity is updated successfully."));
                    fetchLeadAndInitHistory(getLeadDetailDTO().Id);
                }
            }
            else
            {
                setErrorMessage("Please enter Comment.", editActivityCommentModalError);
                activeModalHdn.Value = editActivityCommentModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickActivityCommentLogs(object sender, EventArgs e)
    {
        try
        {
        	LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            IList<LeadActCommentLogDTO> result = enquiryBO.fetchLeadActCommentLog(selectedIndex);
            ActivityLogGrid.DataSource = (result != null) ? result : new List<LeadActCommentLogDTO>();
            ActivityLogGrid.DataBind();
            activeModalHdn.Value = ShowActivityLogModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelActivityLogModal(object sender, EventArgs e)
    {
        try
        {
            setSelectedActivity(0);
            clearTempUploadFields();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Edit Activity Comments Modal - end
    //Attachment Logs - Start
    private void bindAttachments(List<LeadActAttachmentDTO> result)
    {
        AttachmentGrid.DataSource = (result != null) ? result : new List<LeadActAttachmentDTO>();
        AttachmentGrid.DataBind();
    }
    protected void attachmentRowBinding(Object sender, GridViewRowEventArgs e)
    {
        LinkButton lnkDownloadBtn = (LinkButton)e.Row.FindControl("lnkDownloadBtn");
        if (lnkDownloadBtn != null)
        {
            ScriptManager mgr = ScriptManager.GetCurrent(this.Page);
            mgr.RegisterPostBackControl(lnkDownloadBtn);
        }
    }
    protected void onClickActivityAttachments(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedActivity(selectedIndex);
            bindAttachments(enquiryBO.fetchLeadActAttachments(selectedIndex));
            activeModalHdn.Value = ShowAttachmentModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickDownloadAttachmentBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            LeadActAttachmentDTO attachmentDTO = enquiryBO.fetchLeadActAttachment(selectedIndex);
            Response.Buffer = true;
            Response.Charset = "";
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + attachmentDTO.FileName);
            Response.BinaryWrite(attachmentDTO.Content);
            Response.Flush();
            UpdatePanel1.Update();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickDeleteAttachmentBtn(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            enquiryBO.deleteLeadActAttachment(selectedIndex);
            long selectedActivity = getSelectedActivity().Id;
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("Attachment is deleted successfully."));
            fetchLeadAndInitHistory(getLeadDetailDTO().Id);
            setSelectedActivity(selectedActivity);
            bindAttachments(enquiryBO.fetchLeadActAttachments(selectedActivity));
            if (getSelectedActivity().NoOfAttachments > 0)
            {
                activeModalHdn.Value = ShowAttachmentModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelAttachmentModal(object sender, EventArgs e)
    {
        try
        {
            setSelectedActivity(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Attachments logs - End
    //Add Reminder Modal - Start
    private LeadActivityDTO getSelectedUpcomingReminder()
    {
        List<LeadActivityDTO> upcomingReminderList = getLeadDetailDTO().UpcomingEvents.ToList<LeadActivityDTO>();
        return upcomingReminderList.Find(c => c.isUISelected);
    }
    private void resetReminderModalFields()
    {
        txtReminderScheduledDate.Text = null;
        txtReminderComments.Text = null;
        pnlReminderInfo.Visible = false;
        divScheduledDate.Visible = true;
        EnqActivityMode mode = getEnqActivityMode();
        if (mode == EnqActivityMode.ADD_TASK)
        {
            lbReminderModalHeader.Text = Constants.ICON.ADD_REMINDER + Resources.Labels.ADD_TASK;
        }
        else if (mode == EnqActivityMode.RESCHEDULE_TASK)
        {
            LeadActivityDTO eventDTO = getSelectedUpcomingReminder();
            lbReminderModalHeader.Text = Constants.ICON.RESCHEDULE_REMINDER + Resources.Labels.RESCHEDULE_TASK;
            pnlReminderInfo.Visible = true;
            lbReminderInfoLabel.Text = "Current Scheduled Date: ";
            lbReminderInfoValue.Text = DateUtil.getCSDateTime(eventDTO.ScheduledDate);
        }
    }
    private void initReminderModalAction(EnqActivityMode mode, long selectedIndex)
    {
        setEnqActivityMode(mode);
        selectUpcomingReminder(selectedIndex);
        resetReminderModalFields();
        activeModalHdn.Value = addReminderModal;
    }
    protected void onClickAddReminderBtn(object sender, EventArgs e)
    {
        try
        {
            initReminderModalAction(EnqActivityMode.ADD_TASK, 0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickRescheduleReminderBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            initReminderModalAction(EnqActivityMode.RESCHEDULE_TASK, selectedIndex);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void addReminder(object sender, EventArgs e)
    {
        try
        {
            if (validateAddReminder())
            {
                LeadDetailDTO leadDTO = getLeadDetailDTO();
                EnqActivityRecordType recordType = EnqActivityRecordType.Task;
                LeadActivityDTO reminderDTO = CommonUtil.createNewLeadActivityDTO(leadDTO.Id, recordType, getUserDefinitionDTO());
                reminderDTO.ReminderMode = getReminderMode();
                reminderDTO.DateLogged = DateUtil.getUserLocalDateTime();
                reminderDTO.LoggedBy = getUserDefinitionDTO().FirmMember;
                reminderDTO.ActivityType = EnqActivityType.TASK;
                reminderDTO.ScheduledDate = DateUtil.getCSDateTime(txtReminderScheduledDate.Text); ;
                reminderDTO.Comments = txtReminderComments.Text.TrimNullable();
                reminderDTO.Status = (getEnqActivityMode() == EnqActivityMode.CANCEL_TASK || getEnqActivityMode() == EnqActivityMode.COMPLETE_TASK) ?
                                        EnqLeadActivityStatus.Completed : EnqLeadActivityStatus.Open;

                long parentId = 0;
                LeadActivityDTO parentReminderDTO = getSelectedUpcomingReminder();
                if (parentReminderDTO != null)
                {
                    parentId = parentReminderDTO.Id;
                    reminderDTO.RevRefNo = parentReminderDTO.RefNo;
                }

                reminderDTO.RefNo = enquiryBO.addLeadActivity(reminderDTO, getEnqActivityMode(), parentId, getUserDefinitionDTO());
                setReminderModalSuccessMsg(reminderDTO);
                setEnqActivityMode(EnqActivityMode.NONE);
                fetchLeadAndInitHistory(leadDTO.Id);
            }
            else
            {
                activeModalHdn.Value = addReminderModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setReminderModalSuccessMsg(LeadActivityDTO reminderDTO)
    {
        string msg = "";
        EnqActivityMode mode = getEnqActivityMode();
        if (mode == EnqActivityMode.ADD_TASK) msg = string.Format("Task# {0} is added successfully.", reminderDTO.RefNo);
        else if (mode == EnqActivityMode.RESCHEDULE_TASK) msg = string.Format("Task# {0} is rescheduled successfully.", reminderDTO.RevRefNo);
        else if (mode == EnqActivityMode.COMPLETE_TASK) msg = string.Format("Task# {0} is marked completed successfully.", reminderDTO.RevRefNo);
        else if (mode == EnqActivityMode.CANCEL_TASK) msg = string.Format("Task# {0} is cancelled successfully.", reminderDTO.RevRefNo);

        (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(msg));
    }
    private ReminderMode getReminderMode()
    {
        ReminderMode reminderMode = ReminderMode.None;
        EnqActivityMode mode = getEnqActivityMode();
        if (mode == EnqActivityMode.ADD_TASK) reminderMode = ReminderMode.Scheduled;
        else if (mode == EnqActivityMode.RESCHEDULE_TASK) reminderMode = ReminderMode.Rescheduled;
        else if (mode == EnqActivityMode.COMPLETE_TASK) reminderMode = ReminderMode.None;
        else if (mode == EnqActivityMode.CANCEL_TASK) reminderMode = ReminderMode.Cancelled;

        return reminderMode;
    }
    protected void cancelAddReminderModal(object sender, EventArgs e)
    {
        try
        {
            setEnqActivityMode(EnqActivityMode.NONE);
            selectUpcomingReminder(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateAddReminder()
    {
        string valGrp = addReminderModalError;
        EnqActivityMode activityMode = getEnqActivityMode();
        if (activityMode == EnqActivityMode.CANCEL_TASK || activityMode == EnqActivityMode.COMPLETE_TASK) valGrp = addReminderModalError1;
        Page.Validate(valGrp);
        return Page.IsValid;
    }
    //Add Reminder Modal - End
    //Close Reminder Modal - Start
    private void resetAddCommentModalFields()
    {
    	txtAddComments.Text = null;
        EnqActivityMode mode = getEnqActivityMode();
        divCommentInfoModalRow.Visible = true;
        divAttachmentCommentModalRow.Visible = false;
        if (mode == EnqActivityMode.ADD_NOTE)
        {
            LeadActivityDTO eventDTO = getSelectedUpcomingReminder();
            lbAddCommentModalHeader.Text = Constants.ICON.ADD_NOTE + Resources.Labels.ADD_NOTE;
            divCommentInfoModalRow.Visible = false;
            divAttachmentCommentModalRow.Visible = true;
        } 
        else if (mode == EnqActivityMode.COMPLETE_TASK)
        {
            LeadActivityDTO eventDTO = getSelectedUpcomingReminder();
            lbAddCommentModalHeader.Text = Constants.ICON.COMPLETE_REMINDER + Resources.Labels.MARK_AS_COMPLETED;
            lbAddCommentInfoLabel.Text = EnqActivityType.TASK.GetDescription();
            lbAddCommentInfoValue.Text = eventDTO.Comments;
        }
        else if (mode == EnqActivityMode.CANCEL_TASK)
        {
            LeadActivityDTO eventDTO = getSelectedUpcomingReminder();
            lbAddCommentModalHeader.Text = Constants.ICON.CANCEL_REMINDER + Resources.Labels.CANCEL_TASK;
            lbAddCommentInfoLabel.Text = EnqActivityType.TASK.GetDescription();
            lbAddCommentInfoValue.Text = eventDTO.Comments;
        }
    }
    private void initAddCommentModalAction(EnqActivityMode mode, long selectedIndex)
    {
        setEnqActivityMode(mode);
        selectUpcomingReminder(selectedIndex);
        resetAddCommentModalFields();
        activeModalHdn.Value = addCommentModal;
    }
    protected void onClickAddNoteBtn(object sender, EventArgs e)
    {
        try
        {
        	initAddCommentModalAction(EnqActivityMode.ADD_NOTE, 0);
            clearTempUploadFields();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickCompleteReminderBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            initAddCommentModalAction(EnqActivityMode.COMPLETE_TASK, selectedIndex);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickCancelReminderBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            initAddCommentModalAction(EnqActivityMode.CANCEL_TASK, selectedIndex);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void addComment(object sender, EventArgs e)
    {
        try
        {
            if (validateAddComment())
            {
                LeadDetailDTO leadDTO = getLeadDetailDTO();
                EnqActivityMode enqActivityMode = getEnqActivityMode();
                EnqActivityRecordType recordType = (enqActivityMode == EnqActivityMode.ADD_NOTE) ? EnqActivityRecordType.Note : EnqActivityRecordType.Task;
                LeadActivityDTO reminderDTO = CommonUtil.createNewLeadActivityDTO(leadDTO.Id, recordType, getUserDefinitionDTO());
                reminderDTO.ReminderMode = getReminderMode();
                reminderDTO.DateLogged = DateUtil.getUserLocalDateTime();
                reminderDTO.LoggedBy = getUserDefinitionDTO().FirmMember;
                reminderDTO.ActivityType = (enqActivityMode == EnqActivityMode.ADD_NOTE) ? EnqActivityType.NOTE : EnqActivityType.TASK;
                reminderDTO.Comments = txtAddComments.Text.TrimNullable();
                reminderDTO.Status = EnqLeadActivityStatus.Completed;
                reminderDTO.Attachments = getAttachmentFromTempFolder();

                long parentId = 0;
                LeadActivityDTO parentReminderDTO = getSelectedUpcomingReminder();
                if (parentReminderDTO != null)
                {
                    parentId = parentReminderDTO.Id;
                    reminderDTO.RevRefNo = parentReminderDTO.RefNo;
                }

                reminderDTO.RefNo = enquiryBO.addLeadActivity(reminderDTO, enqActivityMode, parentId, getUserDefinitionDTO());
                clearTempUploadFields();
                setReminderModalSuccessMsg(reminderDTO);
                setEnqActivityMode(EnqActivityMode.NONE);
                fetchLeadAndInitHistory(leadDTO.Id);
            }
            else
            {
                activeModalHdn.Value = addCommentModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelAddCommentModal(object sender, EventArgs e)
    {
        try
        {
            setEnqActivityMode(EnqActivityMode.NONE);
            selectUpcomingReminder(0);
            clearTempUploadFields();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateAddComment()
    {
        Page.Validate(addCommentModalError);
        return Page.IsValid;
    }
    private void clearTempUploadFields()
    {
        hasFilesUploaded.Value = "";
        TmpUploadfileCntrlTarget.Value = "";
        documentBO.clearTempFileUploadDirectory(getUserDefinitionDTO().Username);
    }
    private List<LeadActAttachmentDTO> getAttachmentFromTempFolder()
    {
        List<LeadActAttachmentDTO> uploadList = new List<LeadActAttachmentDTO>();
        if (hasFilesUploaded.Value.Equals("Y"))
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            List<FileUIDTO> tmpList = documentBO.downloadTempUploadedFiles(
                string.Format(Constants.DOCUMENT_MANAGEMENT.TMP_FILE_UPLOAD_PATH, userDefDto.Username));
            if (tmpList != null && tmpList.Count > 0)
            {
                foreach (FileUIDTO tmpFile in tmpList)
                {
                    LeadActAttachmentDTO tmpDTO = new LeadActAttachmentDTO();
                    tmpDTO.FileName = tmpFile.Name;
                    tmpDTO.FileType = MimeMapping.GetMimeMapping(tmpFile.Name);
                    tmpDTO.Content = tmpFile.Content;
                    tmpDTO.UploadDate = DateUtil.getUserLocalDateTime();
                    tmpDTO.UploadedBy = CommonUIConverter.getFirmMemberDTO(userDefDto.FirmMember.Id.ToString(), null);
                    tmpDTO.FirmNumber = userDefDto.FirmNumber;
                    tmpDTO.InsertUser = userDefDto.Username;
                    tmpDTO.UpdateUser = userDefDto.Username;
                    uploadList.Add(tmpDTO);
                }
            }
        }
        return uploadList;
    }
    //Close Reminder Modal - End
    //User Assignee Selection logic - start
    protected void ReassignLead(object sender, EventArgs e)
    {
        try
        {
            Page.Validate(selectUserAssigneeModalError);
            bool isValid = Page.IsValid;
            if (isValid)
            {
                long AssigneeId = long.Parse(drpUserAssignee.Text);
                LeadDetailDTO LeadDTO = getLeadDetailDTO();
                enquiryBO.ReAssignLead(LeadDTO.Id, AssigneeId, DateUtil.getUserLocalDateTime(), getUserDefinitionDTO());
                fetchLeadAndInitHistory(LeadDTO.Id);
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format("Lead# {0} is reassigneed successfully.", LeadDTO.LeadRefNo)));
            }
            else
            {
                activeModalHdn.Value = selectUserAssigneeModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelUserAssigneeModal(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }  
    //User Assignee Selection logic - end
    //Close Lead Modal - start
    protected void onClickCloseLeadBtn(object sender, EventArgs e)
    {
        try
        {
        	activeModalHdn.Value = closeLeadModal;
        	txtLeadCloseReason.Text = null;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void closeLead(object sender, EventArgs e)
    {
        try
        {
        	if(validateCloseLead()) {
        		LeadDetailDTO leadDTO = getLeadDetailDTO();
                if (leadDTO.Status == LeadStatus.Open)
                {
                    enquiryBO.closeLead(leadDTO.Id, txtLeadCloseReason.Text.TrimNullable(), getUserDefinitionDTO());
                    fetchLeadAndInitHistory(leadDTO.Id);
                    (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format("Lead# {0} is closed successfully.", leadDTO.LeadRefNo)));
                }
                else
                {
                    (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(Resources.Messages.ERROR_LEAD_CLOSE_NOT_OPEN));
                }
        	} else {
        		activeModalHdn.Value = closeLeadModal;
        	}
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelLeadLostReasonModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateCloseLead() {
    	Page.Validate(closeLeadModalError);
        return Page.IsValid;
    }
    //Close Enquiry Modal - end
    //Click to Call modal - start
    protected void onClickConnectCall(object sender, EventArgs e)
    {
    	try
        {
    		UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
    		IList<VirtualPhoneDTO> vPhoneList = propertyUserBO.fetchOutgoingVitualPhonesAllocattedToUser(userDefDTO.FirmMember.Id, CommonUtil.getCurrentPropertyDTO(userDefDTO).Id);
    		if(vPhoneList != null && vPhoneList.Count > 0) {
    			if (drpCustomerContact.Items.Count == 1 && vPhoneList.Count == 1) {
    				makeCallToCustomer(userDefDTO.FirmMember.ContactInfo.Contact, drpCustomerContact.Text, vPhoneList[0].PhoneNumber);
    			} else {
    				drpCustomerContact.ClearSelection();
    				initVirtualPhoneDrp(vPhoneList);
    				
    				divCustomerNumber.Visible = (drpCustomerContact.Items.Count > 1);
    				lbCustomerNumberField.Visible = !divCustomerNumber.Visible;
    				lbCustomerNumber.Text = drpCustomerContact.Text;
    				
    				divVirtualPhone.Visible = (vPhoneList.Count > 1);
    				lbVirtualPhoneField.Visible = !divVirtualPhone.Visible;
    				lbVirtualPhone.Text = vPhoneList[0].PhoneNumber;
    				
    				activeModalHdn.Value = ClickToCallModal;
    			}    			
    		} else {
    			(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Virtual Phone is not assigned to you. Please contact your supervisor."));
    		}
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void makeCallToCustomer(string agentNumber, string customerNumber, string virtualPhone) {
    	UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        OutboundCallDialDTO callDialDTO = new OutboundCallDialDTO();
        callDialDTO.AgentNumber = agentNumber;
        callDialDTO.CustomerNumber = customerNumber;
        callDialDTO.VirtualPhone = virtualPhone;
        callDialDTO.PropertyId = CommonUtil.getCurrentPropertyDTO(userDefDTO).Id;

        CallClient callClient = new CallClient();
        CallHistoryDTO callHistoryDTO = callClient.placeOutBoundCall(callDialDTO, userDefDTO);
        //Add Call Activity
        LeadDetailDTO leadDTO = getLeadDetailDTO();
        LeadActivityDTO activityDTO = CommonUtil.createNewCallLeadActivityDTO(leadDTO.Id, EnqActivityRecordType.Call, userDefDTO, callHistoryDTO);
        enquiryBO.addLeadActivity(activityDTO, EnqActivityMode.MAKE_CALL, 0, getUserDefinitionDTO());
        setEnqActivityMode(EnqActivityMode.NONE);
        (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("Call is placed and New activity is added successfully."));
        fetchLeadAndInitHistory(leadDTO.Id);
    }
    protected void connectToCall(object sender, EventArgs e)
    {
        try
        {
            Page.Validate(clickToCallModalError);
            bool isValid = Page.IsValid;
            if (isValid)
            {
            	UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
            	makeCallToCustomer(userDefDTO.FirmMember.ContactInfo.Contact, drpCustomerContact.Text, drpVirtualPhone.Text);
            }
            else
            {
                activeModalHdn.Value = ClickToCallModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelCall(object sender, EventArgs e)
    {
    }   
    //Click to Call modal - end
    //Filter Criteria - Enquiry Search - Start
    private ActivityFilterDTO getSearchFilter()
    {
        return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            drpRecordTypeFilter.ClearSelection();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            ActivityFilterDTO filterDTO = getSearchFilter();
            if (!string.IsNullOrWhiteSpace(drpRecordTypeFilter.Text))
            {
                if (!filterDTO.ActivityTypeList.Contains(drpRecordTypeFilter.Text)) filterDTO.ActivityTypeList.Add(drpRecordTypeFilter.Text);
            }
            setSearchFilterTokens();
            populateActivityGrid(getSessionPageData().LeadDTO);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }

    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            populateActivityGrid(getSessionPageData().LeadDTO);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(ActivityFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new ActivityFilterDTO();
        if (getSessionPageData().FilterDTO.ActivityTypeList == null) getSessionPageData().FilterDTO.ActivityTypeList = new List<string>();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            getSearchFilter().ActivityTypeList.Remove(token);
            setSearchFilterTokens();
            populateActivityGrid(getSessionPageData().LeadDTO);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        ActivityFilterDTO filterDTO = getSearchFilter();
        string filter = null;
        if (filterDTO != null)
        {
            foreach (string type in filterDTO.ActivityTypeList)
            {
                filter = CommonUtil.addFilterToken(filter, type);
            }
        }
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - Enquiry Search - End
}