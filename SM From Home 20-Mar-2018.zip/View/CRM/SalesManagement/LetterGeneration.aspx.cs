﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.BO;
using CrystalDecisions.CrystalReports.Engine;

public partial class LetterGeneration : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string uploadDemandLetterModalError = "uploadDemandLetterModalError";
    string uploadDemandLetterModal = "uploadDemandLetterModal";
    DropdownBO drpBO = new DropdownBO();
    PropertyBO propertyBO = new PropertyBO();
    SoldPropertyUnitBO soldUnitBO = new SoldPropertyUnitBO();
    DocumentBO documentBO = new DocumentBO();
    DemandLetterBO demandLetterBO = new DemandLetterBO();
    MortguageLetterBO mortguageLetterBO = new MortguageLetterBO();
    PossessionLetterBO possessionLetterBO = new PossessionLetterBO();
    ReportConfigBO reportConfigBO = new ReportConfigBO();

    protected void Page_Load(object sender, EventArgs e)
    {
    	Page.Form.Attributes.Add("enctype", "multipart/form-data");
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                LetterGenerationNavDTO navDto = ApplicationUtil.getPageNavDTO<LetterGenerationNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.GENERATE_LETTERS)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
    	renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
    	ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.populateSoldUnitLetters(drpSelectLetter);
        drpSelectLetter.Text = SoldUnitLetterType.DEMAND_LETTER.ToString();
        drpBO.drpDataBase(drpStage, DrpDataType.COMPLETED_SCHEDULE_STAGE, CommonUtil.getStickyPrTowerDTO(userDefDto).Id.ToString(), null, userDefDto.FirmNumber);
    }
    
    public void setErrorMessage(string message, string group)
    {
    	string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        } else CommonUtil.getCustomValidator(Page, message, group);
    }
    private void doInit(LetterGenerationNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(LetterGenerationNavDTO navDto)
    {
        try
        {
            LetterGenerationPageDTO letterGenerationPageDTO = new LetterGenerationPageDTO();
            Session[Constants.Session.PAGE_DATA] = letterGenerationPageDTO;
            letterGenerationPageDTO.PrevNavDTO = navDto.PrevNavDto;
            PrUnitSaleDetailDTO prUnitSaleDetailDto = soldUnitBO.fetchPrUnitSaleDetail(navDto.PrUnitSaleDetailId, false);
            letterGenerationPageDTO.UnitDTO = propertyBO.fetchPropertyUnitWithParent(prUnitSaleDetailDto.PropertyUnit.Id, true);
            prUnitSaleDetailDto.PropertyUnit = getSoldUnit();
            letterGenerationPageDTO.PrUnitSaleDTO = prUnitSaleDetailDto;

            initHeaderInfo(getSoldUnitDetails());
            initDLHistory();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void navigateToPreviousPage()
    {
        LetterGenerationPageDTO letterGenerationPageDTO = getSessionPageData();
        if (letterGenerationPageDTO != null && letterGenerationPageDTO.PrevNavDTO != null)
        {
            object obj = letterGenerationPageDTO.PrevNavDTO;
            if (obj is SoldUnitSearchNavDTO)
            {
                SoldUnitSearchNavDTO navDTO = (SoldUnitSearchNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.SOLD_UNIT_SEARCH, true);
            }
        }
        Response.Redirect(Constants.URL.SOLD_UNIT_SEARCH, true);
    }
    private void renderPageFieldsWithEntitlement()
    {
        
    }    
    private LetterGenerationPageDTO getSessionPageData()
    {
        return (LetterGenerationPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private PrUnitSaleDetailDTO getSoldUnitDetails()
    {
        return getSessionPageData().PrUnitSaleDTO;
    }
    private PropertyUnitDTO getSoldUnit()
    {
        return getSessionPageData().UnitDTO;
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private void initHeaderInfo(PrUnitSaleDetailDTO prUnitSaleDetailDto)
    {
        PropertyUnitDTO propertyUnitDto = prUnitSaleDetailDto.PropertyUnit;
        PropertyTowerDTO propertyTowerDto = prUnitSaleDetailDto.PropertyUnit.PropertyTower;
        //Populate Customer Fields
        CustomerDTO customerDto = prUnitSaleDetailDto.Customer;
        lbCustomerName.Text = CommonUIConverter.getCustomerFullName(customerDto.Salutation.Name, customerDto.FirstName, customerDto.LastName);
        lbContact.Text = customerDto.ContactInfo.Contact;
        lbEmail.Text = customerDto.ContactInfo.Email;
        //Populate Unit Details
        lbTowerName.Text = propertyTowerDto.Name;
        lbUnitNumber.Text = CommonUIConverter.getPropertyUnitFormattedNo(propertyUnitDto.Wing, propertyUnitDto.UnitNo);
        lbUnitType.Text = propertyUnitDto.UnitType.Name;
        lbBookingDate.Text = DateUtil.getCSDate(prUnitSaleDetailDto.BookingDate);
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }    
    private bool validateMandatoryFields()
    {
        bool isValid = true;
        Page.Validate(commonError);
        isValid = Page.IsValid;
        if (!isValid)
        {
        	(this.Master as CSMaster).setPageErrorInNotyMsg(Page.Validators);
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
   
    }
    protected void onChangeLetter(object sender, EventArgs e)
    {
        try
        {
            initDLHistory();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void initDLHistory()
    {
        pnlDemandLetterHistory.Visible = false;
        SoldUnitLetterType selectedLetter = EnumHelper.ToEnum<SoldUnitLetterType>(drpSelectLetter.Text);
        if (selectedLetter == SoldUnitLetterType.DEMAND_LETTER)
        {
            pnlDemandLetterHistory.Visible = true;
            LetterGenerationPageDTO PageDTO = getSessionPageData();
            PropertyScheduleDTO latestStageDTO = propertyBO.fetchPropertyScheduleCurrentCompletedStage(PageDTO.PrUnitSaleDTO.PropertyUnit.PropertyTower.Id);
            if (latestStageDTO != null)
            {
                lbCurrentStageTotalPercentage.Text = latestStageDTO.TotalPercentage.ToString();
                lbCurrentStageAbbr.Text = latestStageDTO.StageAbbr;
                lbCurrentStageName.Text = latestStageDTO.Stage;
            }
            PageDTO.StageDTO = latestStageDTO;
            IList<DemandLetterHistoryDTO> dlHistoryList = demandLetterBO.fetchDemandLetterHistory(PageDTO.PrUnitSaleDTO.Id);
            dlHistoryGrid.DataSource = (dlHistoryList != null) ? dlHistoryList : new List<DemandLetterHistoryDTO>();
            dlHistoryGrid.DataBind();
            PageDTO.dlHistoryList = dlHistoryList.ToList<DemandLetterHistoryDTO>();
        }
    }
    public void onClickGenerateLetter(object sender, EventArgs e)
    {
        try
        {
            if(validateMandatoryFields()){
            SoldUnitLetterType searchBy = EnumHelper.ToEnum<SoldUnitLetterType>(drpSelectLetter.Text);
            LetterGenerationPageDTO letterGenerationPageDTO = getSessionPageData();
            PrUnitSaleDetailDTO selectedPrUnitSaleDetailDto = letterGenerationPageDTO.PrUnitSaleDTO;
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            BusinessOutputTO businessOutputTO = null;
            ReportTemplateMasterDTO reportConfigDTO = null;
            ReportDocument letterReportDocument = new ReportDocument();
            if (SoldUnitLetterType.DEMAND_LETTER == searchBy)
            {
                businessOutputTO = demandLetterBO.processDemandLetter(userDefDto.FirmNumber, selectedPrUnitSaleDetailDto);
                reportConfigDTO = reportConfigBO.fetchReportConfiguration(userDefDto.FirmNumber, SoldUnitLetterType.DEMAND_LETTER.GetDescription());
            }
            else if (SoldUnitLetterType.POSSESSION == searchBy)
            {
                businessOutputTO = possessionLetterBO.processPossessionLetter(userDefDto.FirmNumber, selectedPrUnitSaleDetailDto);
                reportConfigDTO = reportConfigBO.fetchReportConfiguration(userDefDto.FirmNumber, SoldUnitLetterType.POSSESSION.GetDescription());
            }
            else if (SoldUnitLetterType.MORTGUAGE == searchBy)
            {
                businessOutputTO = mortguageLetterBO.processMortguageLetter(userDefDto.FirmNumber, selectedPrUnitSaleDetailDto);
                reportConfigDTO = reportConfigBO.fetchReportConfiguration(userDefDto.FirmNumber, SoldUnitLetterType.MORTGUAGE.GetDescription());
            }
            if (businessOutputTO.status == BusinessOutputTO.Status.FAILURE)
            {
                setErrorMessage(businessOutputTO.errorMessage, commonError);
            }
            else
            {
                string reportPath = Server.MapPath(reportConfigDTO.Path);
                letterReportDocument.Load(reportPath);
                letterReportDocument.Database.Tables["DemandLetter"].SetDataSource(businessOutputTO.result);
                try
                {
                    letterReportDocument.ExportToHttpResponse
                    (CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, true,businessOutputTO.successMessage);
                }
                catch (Exception exp)
                {

                }
            }
           }
        }
        catch (Exception exp) {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
       }
    }
    private void navigateToCurrentPage()
    {
        LetterGenerationPageDTO PageDTO = getSessionPageData();
        LetterGenerationNavDTO navDTO = new LetterGenerationNavDTO();
        navDTO.PrUnitSaleDetailId = PageDTO.PrUnitSaleDTO.Id;
        navDTO.PrevNavDto = PageDTO.PrevNavDTO;
        Session[Constants.Session.NAV_DTO] = navDTO;
        Response.Redirect(Constants.URL.GENERATE_LETTERS, true);
    }
    private DemandLetterHistoryDTO populateDemandLetterHistoryDTOAdd()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        LetterGenerationPageDTO PageDTO = getSessionPageData();
        DemandLetterHistoryDTO dlHistDTO = new DemandLetterHistoryDTO();
        dlHistDTO.PrUnitSaleDetail = new PrUnitSaleDetailDTO();
        dlHistDTO.PrUnitSaleDetail.Id = PageDTO.PrUnitSaleDTO.Id;
        dlHistDTO.Stage = new PropertyScheduleDTO();
        dlHistDTO.Stage.Id = PageDTO.StageDTO.Id;
        dlHistDTO.UploadDate = DateUtil.getUserLocalDate();
        dlHistDTO.DeliveryDate = DateUtil.getCSDateNotNull(txtDeliveryDate.Text);
        dlHistDTO.UploadBy = new FirmMemberDTO();
        dlHistDTO.UploadBy.Id = userDefDto.FirmMember.Id;

        dlHistDTO.FirmNumber = userDefDto.FirmNumber;
        dlHistDTO.InsertUser = userDefDto.Username;
        dlHistDTO.UpdateUser = userDefDto.Username;
        return dlHistDTO;
    }
    protected void onClickUploadDemandLetterBtn(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = uploadDemandLetterModal;
            drpStage.ClearSelection();
            txtDeliveryDate.Text = null;
            clearTempUploadFields();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void bindDLHistoryRowEvents(Object sender, GridViewRowEventArgs e)
    {
        LinkButton lnkDownloadBtn = (LinkButton)e.Row.FindControl("lnkDownloadDLHistBtn");
        if (lnkDownloadBtn != null)
        {
            ScriptManager mgr = ScriptManager.GetCurrent(this.Page);
            mgr.RegisterPostBackControl(lnkDownloadBtn);
        }
    }
    protected void onClickDownloadDLHistBtn(object sender, EventArgs e)
    {
        try
        {
        	LetterGenerationPageDTO PageDTO = getSessionPageData();
        	LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            DemandLetterHistoryDTO dlHistoryDTO = PageDTO.dlHistoryList.Find(x => x.Id == selectedId);
        	string FullPath = CommonUtil.appendNameToPath(dlHistoryDTO.DocumentPath, dlHistoryDTO.FileName);
        	byte[] fileContent = documentBO.downloadFile(FullPath);
            Response.Buffer = true;
            Response.Charset = "";
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + dlHistoryDTO.FileName);
            Response.BinaryWrite(fileContent);
            Response.Flush();
            UpdatePanel1.Update();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickDeleteDemandLetterBtn(object sender, EventArgs e)
    {
        try
        {
        	LetterGenerationPageDTO PageDTO = getSessionPageData();
        	long selectedId = getDeleteRecordHdnId();
        	DemandLetterHistoryDTO dlHistoryDTO = PageDTO.dlHistoryList.Find(x => x.Id == selectedId);
        	demandLetterBO.deleteDemandLetterHistory(dlHistoryDTO.Id);
        	documentBO.deleteFile(CommonUtil.appendNameToPath(dlHistoryDTO.DocumentPath, dlHistoryDTO.FileName));
        	Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg("Demand Letter is deleted successfully."));
            initDLHistory();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void clearTempUploadFields()
    {
        hasFilesUploaded.Value = "";
        TmpUploadfileCntrlTarget.Value = "";
        documentBO.clearTempFileUploadDirectory(getUserDefinitionDTO().Username);
    }
    public void uploadDemandLetter(object sender, EventArgs e)
    {
        try
        {
            LetterGenerationPageDTO PageDTO = getSessionPageData();
            if (validateDemandLetterUpload())
            {
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                List<FileUIDTO> tmpList = documentBO.downloadTempUploadedFiles(string.Format(Constants.DOCUMENT_MANAGEMENT.TMP_FILE_UPLOAD_PATH, userDefDto.Username));
                if (tmpList != null && tmpList.Count > 0)
                {
                    string bookingPath = CommonUtil.appendNameToPath(Constants.DOCUMENT_MANAGEMENT.BOOKING_UNIT_DOC_PATH, PageDTO.PrUnitSaleDTO.BookingRefNo);
                    string dlFolder = CommonUtil.appendNameToPath(bookingPath, Constants.DOCUMENT_MANAGEMENT.DEMAND_LETTER_FOLDER);
                    documentBO.createFolderIfNotExist(bookingPath);
                    documentBO.createFolderIfNotExist(dlFolder);
                    foreach (FileUIDTO tmpUIDTO in tmpList)
                    {
                        documentBO.saveDocument(tmpUIDTO.Content, CommonUtil.appendNameToPath(dlFolder, tmpUIDTO.Name));

                        DemandLetterHistoryDTO tmpHistDTO = populateDemandLetterHistoryDTOAdd();
                        tmpHistDTO.FileName = tmpUIDTO.Name;
                        tmpHistDTO.DocumentPath = dlFolder;
                        demandLetterBO.saveDemandLetterHistory(tmpHistDTO);
                    }
                    clearTempUploadFields();
                    (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("Demand Letter is uploaded successfully."));
                    initDLHistory();
                }
            }
            else
            {
                activeModalHdn.Value = uploadDemandLetterModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    protected void cancelUploadDemandLetterModal(object sender, EventArgs e)
    {
        try
        {
            clearTempUploadFields();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateDemandLetterUpload()
    {
        Page.Validate(uploadDemandLetterModalError);
        bool result = Page.IsValid;
        if (result && !hasFilesUploaded.Value.Equals("Y"))
        {
            setErrorMessage("Please select Demand Letter.", uploadDemandLetterModalError);
            result = false;
        }
        return result;
    }
}