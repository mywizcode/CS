﻿using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;

namespace ConstroSoft.Logic.Job
{
    public class EmailJob : IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            
        }
    }
}