﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;


/// <summary>
/// Summary description for PropertyAlertBO
/// </summary>
namespace ConstroSoft
{
    public class PropertyAlertBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public PropertyAlertBO() { }

        public IList<PropertyAlertConfigDTO> fetchEmailSmsAlertGridData(string firmNumber, long propertyId)
        {
            ISession session = null;
            IList<PropertyAlertConfigDTO> result = new List<PropertyAlertConfigDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                PropertyAlertConfig esc = null;
                EmailConfig ec = null;
                PropertyAlertConfigDTO esdto = null;
                var proj = Projections.ProjectionList()
                             .Add(Projections.Property(() => esc.Id).WithAlias(() => esdto.Id))
                             .Add(Projections.Property(() => esc.FunctionName).WithAlias(() => esdto.FunctionName))
                             .Add(Projections.Property(() => ec.Email), "EmailConfigDTO.Email")
                             .Add(Projections.Property(() => esc.EmailEnabled).WithAlias(() => esdto.EmailEnabled))
                             .Add(Projections.Property(() => ec.Id), "EmailConfigDTO.Id")
                             .Add(Projections.Property(() => esc.SmsEnabled).WithAlias(() => esdto.SmsEnabled));
                var query = session.QueryOver<PropertyAlertConfig>(() => esc)
                            .Left.JoinAlias(() => esc.EmailConfig, () => ec);
                result = query.Where(() => esc.FirmNumber == firmNumber && esc.Property.Id == propertyId)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<PropertyAlertConfigDTO>()).List<PropertyAlertConfigDTO>();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating property Alerts Setup:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }

        public void updatePropertyAssignedAlerts(ISet<PropertyAlertConfigDTO> assignedDtos)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        foreach (PropertyAlertConfigDTO propertyAlertConfigDTO in assignedDtos)
                        {
                            PropertyAlertConfig propertyAlertConfig = session.Get<PropertyAlertConfig>(propertyAlertConfigDTO.Id);
                            DTOToDomainUtil.populatePropertyAlertUpdateFields(propertyAlertConfig, propertyAlertConfigDTO);
                            session.Update(propertyAlertConfig);
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating property email and SMS Config details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }

    }
}