﻿using System;
using System.Collections.Generic;
using System.Runtime.Caching; 
namespace ConstroSoft.Logic.CachingProvider
{
    public sealed class UserCacheProvider
    {
    	#region Singleton
        private static readonly log4net.ILog log =
                log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private static volatile UserCacheProvider instance;
        private static object syncUserCache = new Object();
        private MemoryCache cache = new MemoryCache("UserCache");

        private UserCacheProvider() {}

        public static UserCacheProvider Instance
        {
           get 
           {
              if (instance == null) 
              {
                 lock (syncUserCache) 
                 {
                    if (instance == null) 
                       instance = new UserCacheProvider();
                 }
              }

              return instance;
           }
        }
        
        #endregion
        /**
         * check whether USERNAME<->SESSION_ID entry is exist in memory cache.
         */
        public bool IsUserLoggedInWithOtherSession(string key, string value)
        {
        	lock (syncUserCache)
            {
        		bool IsLoggedInOtherSession = false;
        		if (!string.IsNullOrWhiteSpace(key)) {
        			string tmpValue = (string)cache[key];
        			IsLoggedInOtherSession = !string.IsNullOrWhiteSpace(tmpValue) && !tmpValue.Equals(value);
        		}
        		return IsLoggedInOtherSession;
            }
        }
        /**
         * check whether USERNAME<->SESSION_ID entry is exist in memory cache.
         */
        public bool IsUserSessionValid(string key, string value)
        {
        	lock (syncUserCache)
            {
        		bool IsValid = false;
        		if (!string.IsNullOrWhiteSpace(key)) {
        			string tmpValue = (string)cache[key];
        			IsValid = !string.IsNullOrWhiteSpace(tmpValue) && tmpValue.Equals(value);
        		}
        		return IsValid;
            }
        }
        /**
         * This method is used to add USERNAME<->SESSION_ID entry into memory cache. If entry already present for given key/username then it removes that entry.
         */
        public bool RegisterUserLogin(string key, string value)
        {
        	lock (syncUserCache)
            {
        		bool isAlreadyExist = false;
        		if (!string.IsNullOrWhiteSpace(key)) {
	        		//Remove existing entry for user
	        		if(cache.Contains(key)) {
	        			isAlreadyExist = true;
	        			cache.Remove(key);
	        		}
	        		//Add new entry for user
	        		cache.Add(key, value, DateTimeOffset.MaxValue);
        		}
        		return isAlreadyExist;
            }
        }
        /**
         * This method is used to remove USERNAME<->SESSION_ID entry from memory cache.
         */
        public void RegisterUserLogout(string key, string value)
        {
        	lock (syncUserCache)
            {
                if (!string.IsNullOrWhiteSpace(key))
                {
                    string tmpValue = (string)cache[key];
                    if (!string.IsNullOrWhiteSpace(tmpValue) && tmpValue.Equals(value))
                    {
                        cache.Remove(key);
                    }
                }
            }
        }
    } 
}