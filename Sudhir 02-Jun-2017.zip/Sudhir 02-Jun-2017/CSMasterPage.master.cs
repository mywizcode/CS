﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using ConstroSoft;

public partial class CSMasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            try
            {
                if (Session["USERNAME"] != null)
                {
                    UserDefinitionDTO userDef = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
                    lbUserName.Text = userDef.Username;
                    lbFullName.Text = userDef.FirmMember.FirstName + " " + userDef.FirmMember.LastName;
                    if (userDef.ProfileImg != null)
                    {
                        byte[] bytes = (byte[])userDef.ProfileImg;
                        string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                        imgProfileImage.ImageUrl = "data:image/png;base64," + base64String;
                        userprofilepic.ImageUrl = "data:image/png;base64," + base64String;
                    }
                    applyEntitlement();
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
            catch (Exception ex)
            {
            }
        }
    }
    public void logoutUser(object sender, System.EventArgs e)
    {
        CommonUtil.clearSession(Session, Application);
        Response.Redirect(Constants.URL.LOGIN, true);
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        //Dashboard
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_DASHBOARD)) { dashBoard.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_APPLICATION_SETUP)) { applicationSetUp.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_FIRM_AND_ACCOUNTS)) { firmDetails.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_MANAGE_MASTER)) { ManageMaster.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_PROPERTY_USER_ACCESS)) { ManagePropUser.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_EMAIL_SMS_CONFIG)) { ManageEmailSMS.Visible = false; }

        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_ACCOUNT_MANAGEMENT)) { accountManagement.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_ACCOUNT_SUMMARY)) { accountSummary.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_ACCOUNT_DEPOSIT)) { accountDeposits.Visible = false; }

        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_PROPERTY_MANAGEMENT)) { propertyManagement.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_MANAGE_PROPERTY)) { manageProperty.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_PROPERTY_PYMT_SCHEDULE)) { paymentSchedules.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_PROPERTY_UNIT)) { propertyUnits.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_PROPERTY_PARKING)) { PropertParking.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_PROPERTY_EXPENSE)) { propertyExepnses.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_AGENCY)) { Agency.Visible = false; }

        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_ENQUIRY_MANAGEMENT)) { enquiryManagement.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_MANAGE_ENQUIRY)) { manageEnquiry.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MANAGE_ENQUIRY_FOLLOWUP)) { enquiryFollowUp.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_MANAGE_CUSTOMERS)) { manageCustomers.Visible = false; }

        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_SALES_MANAGEMENT)) { salesManagement.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_AVAILABLE_PROPERTY_UNITS)) { availablePropertyUnits.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_SOLD_PROPERTY_UNITS)) { soldPropertyUnits.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_CANCELLED_PROPERTY_UNITS)) { cancelledPropertyUnits.Visible = false; }

        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_PAYMENT_MANAGEMENT)) { paymentManagement.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_PAYMENTS)) { payments.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_MANAGE_PDC)) { managePdc.Visible = false; }

        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_PROMOTION_MANAGEMENT)) { promotionManagement.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_MANAGE_PROMOTIONS)) { managePromotion.Visible = false; }

        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_REPORTS_AND_ANALYTICS)) { reportAndAnalytics.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_PYMT_DUE_REPORT)) { PaymentDueReports.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_PYMT_SCHEDULE_REPORT)) { PaymentScheduleReports.Visible = false; }

        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_DOCUMENT_MANAGEMENT)) { documentManagement.Visible = false; }
        if (!CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_MANAGE_DOCUMENT)) { manageDocument.Visible = false; }
    }
}
