﻿
/// <summary>
/// Summary description for CommonUIConverter
/// </summary>
using ConstroSoft;
using System.Collections.Generic;
using NHibernate.Criterion;
using System.Linq.Expressions;
using NHibernate.Impl;
using System;
namespace ConstroSoft
{
    public class CommonUIConverter
    {
        public CommonUIConverter() { }
        public static string getPropertyUnitFormattedNo(string wing, string unitNo)
        {
            return (wing != null && !string.IsNullOrWhiteSpace(wing)) ? wing + " - " + unitNo : unitNo;
        }
        public static string getCustomerFullName(string FirstName, string LastName)
        {
            return FirstName + " " + LastName;
        }
        public static string getCustomerFullName(string FirstName, string middleName, string LastName)
        {
            return FirstName + " " + middleName + " " + LastName;
        }
        public static string getRowInfo(string col1Value, string col2Value)
        {
            string td = "<tr><td style=\"width:30%;\">{0}</td><td>{1}</td></tr>";
            return string.Format(td, col1Value, (col2Value != null) ? col2Value : "");
        }
        public static string getRowInfo(string col1Value, string col2Value, string valueClass)
        {
            string td = "<tr><td style=\"width:30%;\">{0}</td><td class=\"{2}\">{1}</td></tr>";
            return string.Format(td, col1Value, (col2Value != null) ? col2Value : "", valueClass);
        }
        public static string getGridViewRowInfo(AddressDTO addressDto)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.label_addressline1, addressDto.AddressLine1)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_addressline2, addressDto.AddressLine2)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_town, addressDto.Town)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_city, addressDto.City.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_state, addressDto.State.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_country, addressDto.Country.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_pin, addressDto.Pin)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_addresstype, (addressDto.AddressType != null) ? addressDto.AddressType.Name : "")
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_preferred_address, addressDto.PreferredAddress.ToString());
        }

        public static string getGridViewRowInfo(CoCustomerDTO cocustomerDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.label_name, CommonUIConverter.getCustomerFullName(cocustomerDTO.FirstName, cocustomerDTO.MiddleName, cocustomerDTO.LastName))
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_gender, cocustomerDTO.ContactInfo.Gender.ToString())
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_dob, CommonUtil.getCSDate(cocustomerDTO.ContactInfo.Dob))
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_maritalstatus, cocustomerDTO.ContactInfo.MaritalStatus.ToString())
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_contact, cocustomerDTO.ContactInfo.Contact)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_email, cocustomerDTO.ContactInfo.Email)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_Ocupation, (cocustomerDTO.Occupation != null) ? cocustomerDTO.Occupation.Name : "")
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_Pan, cocustomerDTO.Pan)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_relationwithcustomer, cocustomerDTO.RelationWhPrimCust.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_powerofatorny, cocustomerDTO.IsPoa.ToString());
                    
        }


        public static string getGridViewRowInfo(FirmAccountDTO firmAcntDto)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.label_accountname, firmAcntDto.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_accountnumber, firmAcntDto.AccountNo)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_accounttype, (firmAcntDto.AccountType != null) ? firmAcntDto.AccountType.Name : "")
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_accountbalance, firmAcntDto.AccountBalance.ToString(), "csamount")
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_ifsccode, firmAcntDto.IfscCode)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_bankname, firmAcntDto.BankName)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_branch, firmAcntDto.Branch)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_city, (firmAcntDto.City != null) ? firmAcntDto.City.Name : "")
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_state, (firmAcntDto.State != null) ? firmAcntDto.State.Name : "")
                    +CommonUIConverter.getRowInfo(Resources.Labels.label_country, (firmAcntDto.Country != null) ? firmAcntDto.Country.Name : "");
        }
        public static string getGridViewRowInfo(PropertyTowerDTO propertyTowerDto)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.label_towername, propertyTowerDto.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_launchdate, CommonUtil.getCSDate(propertyTowerDto.LaunchDate))
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_propertyrate, (propertyTowerDto.Rate != null) ? propertyTowerDto.Rate.ToString() : "", "csamount")
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_possession, CommonUtil.getCSDate(propertyTowerDto.Possession))
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_description, propertyTowerDto.Description);
        }
        public static string getGridViewRowInfo(PropertyTaxDetailDTO propertyTaxDetailDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.label_taxtype, propertyTaxDetailDTO.TaxType.Name)
                + CommonUIConverter.getRowInfo(Resources.Labels.label_taxrate, propertyTaxDetailDTO.TaxPercentage.ToString(), "cspercentaged3")
                + CommonUIConverter.getRowInfo(Resources.Labels.label_taxlimit, propertyTaxDetailDTO.TaxAmtLimit.ToString(), "csamount")
                + CommonUIConverter.getRowInfo(Resources.Labels.label_tax_inpclude_in_pymt, propertyTaxDetailDTO.IncludeInTotalPymt.ToString());
        }
        public static string getGridViewRowInfo(PropertyChargeDTO propertyChargesDetailDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.label_PropertyChargesType, propertyChargesDetailDTO.ChargeType.ToString())
                + CommonUIConverter.getRowInfo(Resources.Labels.label_propertyCharges, propertyChargesDetailDTO.ChargeValue.ToString(), "csamount");
                
        }
        public static string getGridViewRowInfo(PropertyScheduleDTO propertyScheduleDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.label_stageno, propertyScheduleDTO.StageNumber.ToString())
                + CommonUIConverter.getRowInfo(Resources.Labels.label_stage, propertyScheduleDTO.Stage)
                + CommonUIConverter.getRowInfo(Resources.Labels.label_pymt_sched_percentage, propertyScheduleDTO.Percentage.ToString(), "cspercentaged0")
                + CommonUIConverter.getRowInfo(Resources.Labels.label_pymt_sched_status, propertyScheduleDTO.Status.ToString());
        }
        public static string getGridViewRowInfo(PrUnitSaleTaxDetailDTO prUnitSaleTaxDetailDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.label_taxtype, prUnitSaleTaxDetailDTO.TaxType.Name)
                + CommonUIConverter.getRowInfo(Resources.Labels.label_taxrate, prUnitSaleTaxDetailDTO.TaxPercentage.ToString(), "cspercentaged3")
                + CommonUIConverter.getRowInfo(Resources.Labels.label_taxlimit, prUnitSaleTaxDetailDTO.TaxAmtLimit.ToString(), "csamount")
                + CommonUIConverter.getRowInfo(Resources.Labels.label_amount, prUnitSaleTaxDetailDTO.TaxAmt.ToString(), "csamount");
        }
        public static string getGridViewRowInfo(PrUnitSalePymtDTO prUnitSalePymtDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.label_paymenttype, prUnitSalePymtDTO.PymtType.Name)
                + CommonUIConverter.getRowInfo(Resources.Labels.label_PaymentDate, CommonUtil.getCSDate(prUnitSalePymtDTO.PymtDate))
                + CommonUIConverter.getRowInfo(Resources.Labels.label_paymentamount, prUnitSalePymtDTO.PymtAmt.ToString(), "csamount")
                + CommonUIConverter.getRowInfo(Resources.Labels.label_totalpaid, prUnitSalePymtDTO.PaymentMaster.TotalPaid.ToString(), "csamount")
                + CommonUIConverter.getRowInfo(Resources.Labels.label_PaymentTo, prUnitSalePymtDTO.PymtTo.ToString())
                + CommonUIConverter.getRowInfo(Resources.Labels.label_Status, prUnitSalePymtDTO.PaymentMaster.Status.ToString())
                + CommonUIConverter.getRowInfo(Resources.Labels.label_description, prUnitSalePymtDTO.Description);
        }
        public static string getGridViewRowInfo(EnquiryFollowupDTO enquiryFollowupDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.label_employeename, enquiryFollowupDTO.FirmMember.FirstName)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_Followup_date, CommonUtil.getCSDate(enquiryFollowupDTO.FollowupDate))
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_Communication_Media, enquiryFollowupDTO.CommunicationMedia.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_comment, enquiryFollowupDTO.Comments);
        }
        public static string getGridViewRowInfo(PropertyUnitDTO propertyUnitDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.label_stageno, propertyUnitDTO.UnitNo.ToString())
                + CommonUIConverter.getRowInfo(Resources.Labels.label_stage, propertyUnitDTO.CarpetArea.ToString(), "cssqlft0")
                + CommonUIConverter.getRowInfo(Resources.Labels.label_pymt_sched_percentage, propertyUnitDTO.BalconyArea.ToString(), "cssqlft0")
                + CommonUIConverter.getRowInfo(Resources.Labels.label_pymt_sched_status, propertyUnitDTO.BalconyArea.ToString());
        }

        public static string getGridViewRowInfo(PropertyParkingDTO propertyParkingtDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.label_parkingNo, propertyParkingtDTO.ParkingNo.ToString())
                + CommonUIConverter.getRowInfo(Resources.Labels.label_parkingType, propertyParkingtDTO.ParkingType!=null?propertyParkingtDTO.ParkingType.Name:null)
                + CommonUIConverter.getRowInfo(Resources.Labels.label_parkingArea, propertyParkingtDTO.Area.ToString(), "cssqlft0")
                + CommonUIConverter.getRowInfo(Resources.Labels.label_Status, propertyParkingtDTO.Status.ToString())
                + CommonUIConverter.getRowInfo(Resources.Labels.label_commonParking, propertyParkingtDTO.CommonParking.ToString());
        }
        public static string getGridViewRowInfo(PaymentTransactionDTO paymentTransactionDto)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.label_txno, paymentTransactionDto.Id.ToString())
                + CommonUIConverter.getRowInfo(Resources.Labels.label_transactiondate, CommonUtil.getCSDate(paymentTransactionDto.TxDate))
                + CommonUIConverter.getRowInfo(Resources.Labels.label_amount, paymentTransactionDto.Amount.ToString(), "csamount")
                + CommonUIConverter.getRowInfo(Resources.Labels.label_paymentmode, paymentTransactionDto.PymtMode.ToString())
                + CommonUIConverter.getRowInfo(Resources.Labels.label_chequedate, CommonUtil.getCSDate(paymentTransactionDto.ChequeDate))
                + CommonUIConverter.getRowInfo(Resources.Labels.label_chequeno, paymentTransactionDto.ChequeNo)
                + CommonUIConverter.getRowInfo(Resources.Labels.label_bankname, paymentTransactionDto.BankName)
                + CommonUIConverter.getRowInfo(Resources.Labels.label_branch, paymentTransactionDto.Branch)
                + CommonUIConverter.getRowInfo(Resources.Labels.label_Status, paymentTransactionDto.Status.ToString())
                + CommonUIConverter.getRowInfo(Resources.Labels.label_comment, paymentTransactionDto.Comments);
        }
        public static string getGridViewRowInfo(PdcPymtDTO pdcPymtDto, string pymtDirection)
        {
            if (pymtDirection == Constants.PYMT_DIRECTION.FIRM_AGENCY)
            {
                return CommonUIConverter.getRowInfo(Resources.Labels.label_agency, pdcPymtDto.PymtFor)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_ExpensesDate, CommonUtil.getCSDate(pdcPymtDto.ExpenseDate))
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_ExpensesType, pdcPymtDto.PymtType.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_totalamount, pdcPymtDto.TotalPymtAmt.ToString(), "csamount")
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_totalpaid, pdcPymtDto.TotalPaidAmt.ToString(), "csamount")
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_paymentamount, pdcPymtDto.PaymentTransaction.Amount.ToString(), "csamount")
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_pdctxstatus, pdcPymtDto.PaymentTransaction.Status.ToString())
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_paymentstatus, pdcPymtDto.PymtMstStatus.ToString())
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_comment, pdcPymtDto.PaymentTransaction.Comments);
            }
            else
            {
                return CommonUIConverter.getRowInfo(Resources.Labels.label_unitno, pdcPymtDto.UnitNo)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_paymenttype, pdcPymtDto.PymtType.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_totalamount, pdcPymtDto.TotalPymtAmt.ToString(), "csamount")
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_totalpaid, pdcPymtDto.TotalPaidAmt.ToString(), "csamount")
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_paymentamount, pdcPymtDto.PaymentTransaction.Amount.ToString(), "csamount")
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_pdctxstatus, pdcPymtDto.PaymentTransaction.Status.ToString())
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_paymentstatus, pdcPymtDto.PymtMstStatus.ToString())
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_comment, pdcPymtDto.PaymentTransaction.Comments);
            }
        }
        public static string getGridViewRowInfo(MasterControlDataDTO masterControlDataDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.label_masterDataType, masterControlDataDTO.Type != null ? masterControlDataDTO.Type : null)
                + CommonUIConverter.getRowInfo(Resources.Labels.label_masterDataName, masterControlDataDTO.Name.ToString(), null)
                + CommonUIConverter.getRowInfo(Resources.Labels.label_systemdefined, masterControlDataDTO.SystemDefined.ToString())
                + CommonUIConverter.getRowInfo(Resources.Labels.label_description, masterControlDataDTO.Description.ToString());         
        }

        public static CityDTO getCityDTO(string Id, string Name)
        {
            CityDTO dto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                dto = new CityDTO();
                dto.Id = long.Parse(Id);
                dto.Name = Name;
            }
            return dto;
        }
        public static StateDTO getStateDTO(string Id, string Name)
        {
            StateDTO dto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                dto = new StateDTO();
                dto.Id = long.Parse(Id);
                dto.Name = Name;
            }
            return dto;
        }
        public static CountryDTO getCountryDTO(string Id, string Name)
        {
            CountryDTO dto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                dto = new CountryDTO();
                dto.Id = long.Parse(Id);
                dto.Name = Name;
            }
            return dto;
        }
        public static MasterControlDataDTO getMasterControlDTO(string Id, string Name)
        {
            MasterControlDataDTO mdDto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                mdDto = new MasterControlDataDTO();
                mdDto.Id = long.Parse(Id);
                mdDto.Name = Name;
            }
            return mdDto;
        }
        public static AgencyDTO getAgencyDTO(string Id, string Name)
        {
            AgencyDTO agencyDto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                agencyDto = new AgencyDTO();
                agencyDto.Id = long.Parse(Id);
                agencyDto.AgencyName = Name;
            }
            return agencyDto;
        }
		 public static AccountTransactionDTO getAccountTransactionDTO(string Id, string accountno)
        {
            AccountTransactionDTO mdDto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                mdDto = new AccountTransactionDTO();
                mdDto.Id = long.Parse(Id);
                mdDto.FirmAccount.AccountNo = accountno;
            }
            return mdDto;
        }
        public static FirmAccountDTO getFirmAccountDTO(string Id, string Name)
        {
            FirmAccountDTO dto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                dto = new FirmAccountDTO();
                dto.Id = long.Parse(Id);
                dto.Name = Name;
            }
            return dto;
        }
        public static FirmMemberDTO getFirmMemberDTO(string Id, string Name)
        {
            FirmMemberDTO dto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                dto = new FirmMemberDTO();
                dto.Id = long.Parse(Id);
                dto.FirstName = Name;
            }
            return dto;
        }
        public static CustomerDTO getCustomerDTO(string Id, string Name)
        {
            CustomerDTO dto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                dto = new CustomerDTO();
                dto.Id = long.Parse(Id);
                dto.FirstName = Name;
            }
            return dto;
        }
        public static PropertyDTO getPropertyDTO(string Id, string Name)
        {
            PropertyDTO dto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                dto = new PropertyDTO();
                dto.Id = long.Parse(Id);
                dto.Name = Name;
            }
            return dto;
        }
        public static PropertyTowerDTO getPropertyTowerDTO(string Id, string Name)
        {
            PropertyTowerDTO dto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                dto = new PropertyTowerDTO();
                dto.Id = long.Parse(Id);
                dto.Name = Name;
            }
            return dto;
        }
        public static PropertyParkingDTO getPropertyParkingDTO(string Id, string Name)
        {
            PropertyParkingDTO dto = null;
            if (!string.IsNullOrWhiteSpace(Id))
            {
                dto = new PropertyParkingDTO();
                dto.Id = long.Parse(Id);
                dto.ParkingNo = Name;
            }
            return dto;
        }
        public static MasterControlDataDTO populateMasterDataDTOAdd(string type, string name, string description, UserDefinitionDTO userDefDto)
        {
            MasterControlDataDTO masterDataDto = new MasterControlDataDTO();
            masterDataDto.Name = name;
            masterDataDto.Description = description;
            masterDataDto.FirmNumber = userDefDto.FirmNumber;
            masterDataDto.InsertUser = userDefDto.Username;
            masterDataDto.UpdateUser = userDefDto.Username;
            masterDataDto.Type = type;
            masterDataDto.SystemDefined = SystemDefined.No;
            return masterDataDto;
        }
        public static string getGridViewRowInfo(DocumentDTO documentDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.label_document_name, documentDTO.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_document_type, documentDTO.DocumentType.Name)
                    + CommonUIConverter.getRowInfo(Resources.Labels.label_description, documentDTO.Description);
        }
        public static string getGridViewRowInfo(FirmAcntDepositeDTO firmAcntDepositeDTO)
        {
            return CommonUIConverter.getRowInfo(Resources.Labels.label_account, firmAcntDepositeDTO.FirmAccount.Name)
                + CommonUIConverter.getRowInfo(Resources.Labels.label_paymentmode, firmAcntDepositeDTO.PymtMode)
                + CommonUIConverter.getRowInfo(Resources.Labels.label_amount, firmAcntDepositeDTO.Amount.ToString(), "csamount")
                + CommonUIConverter.getRowInfo(Resources.Labels.label_transactiondate, CommonUtil.getCSDate(firmAcntDepositeDTO.DepositeDate))
                + CommonUIConverter.getRowInfo(Resources.Labels.label_chequeno, firmAcntDepositeDTO.ChequeNo)
                + CommonUIConverter.getRowInfo(Resources.Labels.label_bankname, firmAcntDepositeDTO.BankName)
                + CommonUIConverter.getRowInfo(Resources.Labels.label_branch, firmAcntDepositeDTO.Branch)
                + CommonUIConverter.getRowInfo(Resources.Labels.label_Status, firmAcntDepositeDTO.Status.ToString())
                + CommonUIConverter.getRowInfo(Resources.Labels.label_comment, firmAcntDepositeDTO.Description);
        }
    }
}