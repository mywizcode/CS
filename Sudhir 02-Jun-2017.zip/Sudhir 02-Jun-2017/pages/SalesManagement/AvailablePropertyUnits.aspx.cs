﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using CrystalDecisions.CrystalReports.Engine;
using System.Data;

public partial class AvailablePropertyUnits : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string tab1ValidationGrp = "tab1Error";
    string tab3BzStep1Error = "tab3BzStep1Error";
    string tab3BzStep2Error = "tab3BzStep2Error";
    string tab3BzStep1 = "bzstep1";
    string tab3BzStep2 = "bzstep2";
    string VS_PROPERTY_UNIT_LIST = "PROPERTY_UNIT_LIST";
    string VS_MASTER_PROPERTY_UNIT_LIST = "ALL_PROPERTY_UNIT_LIST";
    string VS_SELECTED_UNIT = "SELECTED_PROPERTY_UNIT";
    string VS_BOOK_UNIT = "BOOK_UNIT";
    DropdownBO drpBO = new DropdownBO();
    PropertyBO propertyBO = new PropertyBO();
    AvailablePropertyUnitBO availableUnitBO = new AvailablePropertyUnitBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    public enum AvailableUnitPageMode { ADD, GETQUOTE, VIEW, NONE }
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                resetTabInfo(AvailableUnitPageMode.NONE);
                initDropdowns();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        QuotationViewer.ReportSource = (ReportDocument)Session["QuotationReport"];
        QuotationViewer.RefreshReport();
        QuotationViewer.DataBind();
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpSelectProperty, DrpDataType.PROPERTY_NAME, userDefDto.Id.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<AvailableUnitSearchBy>(drpSearchBy, null);
        drpBO.drpDataBase(drpCustomer, DrpDataType.CUSTOMER_SEARCH_BY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpEnquiryRefNo, DrpDataType.ENQUIRY_REFERENCE_NUMBER, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpEmployee, DrpDataType.EMPLOYEE_SEARCH_BY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpCocustomerSalutation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.SALUTATION, null, userDefDto.FirmNumber);
        drpBO.drpEnum<Gender>(drpcocustomergender, Constants.SELECT_ITEM);
        drpBO.drpEnum<MaritalStatus>(drpCocustomerMaritalstatus, Constants.SELECT_ITEM);
        drpBO.drpDataBase(drpCoCustomerOccupation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.OCCUPATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<PowerOfAtorny>(drpPowerOfAtorny, Constants.SELECT_ITEM);
        drpBO.drpDataBase(drprelationwithcustomer, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.RELATION_WITH_CUSTOMER, Constants.SELECT_ITEM, userDefDto.FirmNumber);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        bookAvailableUnitBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_UNIT_BOOK);
    }
    private void preRenderInitFormElements()
    {
        PropertyUnitDTO propertyUnitDto = getCurrentPropertyUnit();
        PrUnitSaleDetailDTO prUnitSaleDetailDto = getCurrentPropertyUnitSale();
        jumpToAvailableUnitsHdnId.Value = "";
        jumpToTaxDetailHdnId.Value = "";
        jumpToCMTaxDetailHdnId.Value = "";
        if (propertyUnitDto != null)
        {
            jumpToAvailableUnitsHdnId.Value = propertyUnitDto.Id.ToString();
            if (prUnitSaleDetailDto != null && prUnitSaleDetailDto.uiTaxDetails != null && prUnitSaleDetailDto.uiTaxDetails.Count > 0)
            {
                PrUnitSaleTaxDetailDTO prUnitSaleTaxDetailDto = prUnitSaleDetailDto.uiTaxDetails.Find(a => a.isUISelected);
                if (prUnitSaleTaxDetailDto != null) jumpToTaxDetailHdnId.Value = prUnitSaleTaxDetailDto.UiIndex.ToString();
            }
            if (prUnitSaleDetailDto != null && prUnitSaleDetailDto.uiCMTaxDetails != null && prUnitSaleDetailDto.uiCMTaxDetails.Count > 0)
            {
                PrUnitSaleTaxDetailDTO prUnitSaleTaxDetailDto = prUnitSaleDetailDto.uiCMTaxDetails.Find(a => a.isUISelected);
                if (prUnitSaleTaxDetailDto != null) jumpToCMTaxDetailHdnId.Value = prUnitSaleTaxDetailDto.UiIndex.ToString();
            }
            if (prUnitSaleDetailDto != null && prUnitSaleDetailDto.CoCustomers != null && prUnitSaleDetailDto.CoCustomers.Count > 0)
            {
                CoCustomerDTO selectedCoCustomer = prUnitSaleDetailDto.CoCustomers.ToList<CoCustomerDTO>().Find(a => a.isUISelected);
                if (selectedCoCustomer != null) jumpToCoCustHdnId.Value = selectedCoCustomer.UiIndex.ToString();
            }
        }
        if (AvailableUnitPageMode.VIEW.ToString() == pageModeHdn.Value)
        {
            populateUIFieldsFromUnitDTO(getCurrentPropertyUnit());
        }
        else if (AvailableUnitPageMode.ADD.ToString() == pageModeHdn.Value)
        {
            populateTab3UnitInfoSection(getCurrentPropertyUnitSale());
        }
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        if (group.Equals(tab3BzStep1Error)) tab3ContentBzHdn.Value = tab3BzStep1;
        else if (group.Equals(tab3BzStep2Error)) tab3ContentBzHdn.Value = tab3BzStep2;
    }

    public void setSuccessMessage(string msg, string tabId, string bzStep)
    {
        activeTabHdn.Value = tabId;
        if (tabId.Equals(tab1Anchor.ID))
        {
            lbTab1Success.Text = msg;
            tab1SuccessPanel.Visible = true;
        }
        else if (tabId.Equals(tab3Anchor.ID))
        {
            if (tab3BzStep1.Equals(bzStep))
            {
                lbTab3BzStep1Success.Text = msg;
                tab3BzStep1SuccessPanel.Visible = true;
                tab3ContentBzHdn.Value = tab3BzStep1;
            }
            else
            {
                lbTab3BzStep2Success.Text = msg;
                tab3BzStep2SuccessPanel.Visible = true;
                tab3ContentBzHdn.Value = tab3BzStep2;
            }
        }
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private void clearMessages()
    {
        tab1SuccessPanel.Visible = false;
        lbTab1Success.Text = "";
        tab3BzStep1SuccessPanel.Visible = false;
        lbTab3BzStep1Success.Text = "";
        tab3BzStep2SuccessPanel.Visible = false;
        lbTab3BzStep2Success.Text = "";
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }

    private void resetTabInfo(AvailableUnitPageMode pageMode)
    {
        pageModeHdn.Value = pageMode.ToString();
        initFormFields();
        pnlTaxDetailAdd.Visible = false;
        pnlCMTaxDetailAdd.Visible = false;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        tab3ContentBzHdn.Value = "";
        tab2Anchor.Visible = false;
        tab3Anchor.Visible = false;
        tab4Anchor.Visible = false;
        if (AvailableUnitPageMode.ADD == pageMode)
        {
            tab3ContentBzHdn.Value = tab3BzStep1;
            activeTabHdn.Value = tab3Anchor.ID;
            tab3Anchor.Visible = true;
            initFormFields();
        }
        else if (AvailableUnitPageMode.VIEW == pageMode)
        {
            activeTabHdn.Value = tab2Anchor.ID;
            tab2Anchor.Visible = true;
            ViewState[VS_BOOK_UNIT] = null;
            initFormFields();
        }
        else if (AvailableUnitPageMode.GETQUOTE == pageMode)
        {
            activeTabHdn.Value = tab4Anchor.ID;
            tab4Anchor.Visible = true;
            ViewState[VS_BOOK_UNIT] = null;
            initFormFields();
        }
        else
        {
            activeTabHdn.Value = tab1Anchor.ID;
            ViewState[VS_SELECTED_UNIT] = null;
            ViewState[VS_BOOK_UNIT] = null;
        }
    }
    private void initFormFields()
    {
        
    }
    private List<PropertyUnitDTO> getMatserAvailableUnits()
    {
        return (List<PropertyUnitDTO>)ViewState[VS_MASTER_PROPERTY_UNIT_LIST];
    }
    private List<PropertyUnitDTO> getCurrentGridAvailableUnits()
    {
        return (List<PropertyUnitDTO>)ViewState[VS_PROPERTY_UNIT_LIST];
    }
    private PrUnitSaleDetailDTO getCurrentPropertyUnitSale()
    {
        return (PrUnitSaleDetailDTO)ViewState[VS_BOOK_UNIT];
    }
    private PropertyUnitDTO getCurrentPropertyUnit()
    {
        return (PropertyUnitDTO)ViewState[VS_SELECTED_UNIT];
    }
    private IsAgreementDone getAgreementDoneUIValue()
    {
        return (cbAgreementDone.Checked) ? IsAgreementDone.Yes : IsAgreementDone.No;
    }
    private IsPossessionDone getPossessionDoneUIValue()
    {
        return (cbPossessionGiven.Checked) ? IsPossessionDone.Yes : IsPossessionDone.No;
    }
    private void setSelectedPropertyUnit(long selectedId)
    {
        List<PropertyUnitDTO> propertyUnitList = getCurrentGridAvailableUnits();
        if (propertyUnitList != null)
        {
            propertyUnitList.ForEach(c => c.isUISelected = false);
            if (selectedId > 0) propertyUnitList.Find(c => c.Id == selectedId).isUISelected = true;
        }
    }
    private bool validatePropertyUnitSelected()
    {
        bool isSelected = true;
        List<PropertyUnitDTO> propertyUnitList = getCurrentGridAvailableUnits();
        if (propertyUnitList != null)
        {
            isSelected = propertyUnitList.Any(c => c.isUISelected);
            if (!isSelected)
            {
                resetTabInfo(AvailableUnitPageMode.NONE);
                setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Property Unit"), tab1ValidationGrp);
            }
        }
        return isSelected;
    }
    private void selectPropertyUnitGridRdBtn(long Id)
    {
        if (availableUnitsGrid.Rows.Count > 0)
        {
            setSelectedPropertyUnit(0);
            foreach (GridViewRow row in availableUnitsGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdAvailableUnitsSelect");
                Button rowIdenBtn = (Button)row.FindControl("btnAviailUnitRowIdentifier");
                if (radioBtn != null)
                {
                    radioBtn.Checked = false;
                    if (rowIdenBtn != null && Id > 0 && Id.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                    {
                        radioBtn.Checked = true;
                        setSelectedPropertyUnit(Id);
                    }
                }
            }
        }
    }
    private void loadSearchGridAndReSelect(long Id)
    {
        try
        {
            List<PropertyUnitDTO> matserList = (List<PropertyUnitDTO>)getMatserAvailableUnits();
            List<PropertyUnitDTO> filterResults = new List<PropertyUnitDTO>(matserList);
            AvailableUnitSearchBy searchBy = EnumHelper.ToEnum<AvailableUnitSearchBy>(drpSearchBy.Text);
            if (!string.IsNullOrWhiteSpace(drpSearchByValue.Text))
            {
                if (AvailableUnitSearchBy.PROPERTY_UNIT == searchBy)
                {
                    filterResults = matserList.FindAll(u => u.Id == long.Parse(drpSearchByValue.Text));
                }
                else if (AvailableUnitSearchBy.UNIT_TYPE == searchBy)
                {
                    filterResults = matserList.FindAll(u => u.UnitType.Id == long.Parse(drpSearchByValue.Text));
                }
                else if (AvailableUnitSearchBy.FLOOR == searchBy)
                {
                    filterResults = matserList.FindAll(u => u.FloorNo == drpSearchByValue.Text);
                }
                else if (AvailableUnitSearchBy.FACING == searchBy)
                {
                    filterResults = matserList.FindAll(u => u.Facing.Id == long.Parse(drpSearchByValue.Text));
                }
                else if (AvailableUnitSearchBy.DIRECTION == searchBy)
                {
                    filterResults = matserList.FindAll(u => u.Direction.Id == long.Parse(drpSearchByValue.Text));
                }
            }
            ViewState[VS_PROPERTY_UNIT_LIST] = filterResults;
            availableUnitsGrid.DataSource = filterResults;
            availableUnitsGrid.DataBind();
            if (Id > 0)
            {
                selectPropertyUnitGridRdBtn(Id);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private void fetchAvailableUnits() {
        try
        {
            IList<PropertyUnitDTO> results = new List<PropertyUnitDTO>();
            if (!(string.IsNullOrWhiteSpace(drpSelectProperty.Text) || string.IsNullOrWhiteSpace(drpSelectPropertyTower.Text))) {
                long propertyId = long.Parse(drpSelectProperty.Text);
                long towerId = long.Parse(drpSelectPropertyTower.Text);
                results = availableUnitBO.fetchAvailablePropertyUnits(getUserDefinitionDTO().FirmNumber, towerId);
            }
            ViewState[VS_MASTER_PROPERTY_UNIT_LIST] = results;
            ViewState[VS_PROPERTY_UNIT_LIST] = results;
            availableUnitsGrid.DataSource = results;
            availableUnitsGrid.DataBind();
            selectPropertyUnitGridRdBtn(0);
        } 
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private void fetchSelectedPropertyUnit()
    {
        try
        {
            long Id = getCurrentGridAvailableUnits().Find(c => c.isUISelected).Id;
            bool isBooking = AvailableUnitPageMode.ADD.ToString().Equals(pageModeHdn.Value);
            PropertyUnitDTO propertyUnitDto = propertyBO.fetchPropertyUnitWithParent(Id, isBooking);
            ViewState[VS_SELECTED_UNIT] = propertyUnitDto;
            if (isBooking)
            {
                drpBO.drpDataBase(drpPrParking, DrpDataType.PR_AVAILABLE_PARKING, propertyUnitDto.PropertyTower.Id.ToString(),
                    Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
                PrUnitSaleDetailDTO prUnitSaleDetailDto = populatePrUnitSaleDetailDTOAdd();
                ViewState[VS_BOOK_UNIT] = prUnitSaleDetailDto;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSelectProperty(object sender, EventArgs e)
    {
        try
        {
            resetTabInfo(AvailableUnitPageMode.NONE);
            drpBO.drpDataBase(drpSelectPropertyTower, DrpDataType.PROPERTY_TOWER, drpSelectProperty.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            if (drpSelectPropertyTower.Items.Count == 2)
            {
                drpSelectPropertyTower.Items[1].Selected = true;
                pnlAvailableUnitGrid.Visible = true;
            }
            fetchAvailableUnits();
        } 
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSelectPropertyTower(object sender, EventArgs e)
    {
        try
        {
            resetTabInfo(AvailableUnitPageMode.NONE);
            pnlAvailableUnitGrid.Visible = !string.IsNullOrWhiteSpace(drpSelectPropertyTower.Text);
            fetchAvailableUnits();
        } 
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSearchBy(object sender, EventArgs e)
    {
        try
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            AvailableUnitSearchBy searchBy = EnumHelper.ToEnum<AvailableUnitSearchBy>(drpSearchBy.Text);
            drpSearchByValue.Visible = true;
            lbSearchByValue.Visible = true;
            lbSearchByValue.Text = EnumHelper.GetEnumDescription<AvailableUnitSearchBy>(searchBy.ToString());
            if (AvailableUnitSearchBy.PROPERTY_UNIT == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.AVAIL_UNIT_SEARCH_BY_PR_UNIT, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else if (AvailableUnitSearchBy.UNIT_TYPE == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else if (AvailableUnitSearchBy.FLOOR == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.PROPERTY_UNIT_FLOOR, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else if (AvailableUnitSearchBy.FACING == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_FACING, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else if (AvailableUnitSearchBy.DIRECTION == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_DIRECTION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else
            {
                drpSearchByValue.ClearSelection();
                drpSearchByValue.Visible = false;
                lbSearchByValue.Visible = false;
            }
            loadSearchGridAndReSelect(0);
            resetTabInfo(AvailableUnitPageMode.NONE);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSearchByValue(object sender, EventArgs e)
    {
        loadSearchGridAndReSelect(0);
        resetTabInfo(AvailableUnitPageMode.NONE);
    }
    protected void onSelectAvailableUnit(object sender, EventArgs e)
    {
        try
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            resetTabInfo(AvailableUnitPageMode.NONE);
            if (rd.Checked)
            {
                string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnAviailUnitRowIdentifier"))).Attributes["row-identifier"];
                setSelectedPropertyUnit(long.Parse(strId));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickViewAvailableUnitsBtn(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyUnitSelected())
            {
                resetTabInfo(AvailableUnitPageMode.VIEW);
                fetchSelectedPropertyUnit();
                populateUIFieldsFromUnitDTO(getCurrentPropertyUnit());
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickBookAvailableUnitsBtn(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyUnitSelected())
            {
                resetTabInfo(AvailableUnitPageMode.ADD);
                fetchSelectedPropertyUnit();
                populateUIFieldsFromSaleUnitDTO(getCurrentPropertyUnitSale());
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickGetQuoteAvailableUnitsBtn(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyUnitSelected())
            {
                resetTabInfo(AvailableUnitPageMode.GETQUOTE);
                long Id = getCurrentGridAvailableUnits().Find(c => c.isUISelected).Id;
                generateQuotation(Id);

            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }

    public void generateQuotation(long UnitId)
    {
        PropertyBO propertyBO = new PropertyBO();
        FirmBO firmBO = new FirmBO();

        PropertyUnitDTO propertyUnitDto = propertyBO.fetchPropertyUnitWithParent(UnitId, true);
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        FirmDTO firmDto = firmBO.fetchFirmDetails(userDefDto.FirmNumber);
        PropertyDTO propertyDTO = propertyBO.fetchProperty(propertyUnitDto.PropertyTower.Property.Id);
        List<PropertyScheduleDTO> propertyScheduleList = propertyBO.fetchPropertySchedule(userDefDto.FirmNumber, propertyUnitDto.PropertyTower.Id);
        lbQuotationHeader.Text = "Quotation for Unit " + CommonUIConverter.getPropertyUnitFormattedNo(propertyUnitDto.Wing, propertyUnitDto.UnitNo);

        DataTable PropertyUnit = new DataTable();
        DataRow prUnitRow = PropertyUnit.NewRow();
        populatePropertyUnit(propertyUnitDto, firmDto, propertyDTO, PropertyUnit, prUnitRow);

        DataTable PropertyTax = new DataTable();
        PropertyDTO propertyDto = populatePropertyTax(propertyUnitDto, PropertyTax);

        DataTable PropertyPymtSchd = new DataTable();
        populatePropertySchd(propertyScheduleList, PropertyPymtSchd);

        DataTable PropertyCharge = new DataTable();
        populatePropertyCharges(propertyDTO, PropertyCharge);

        ReportDocument quotationReportDocument = new ReportDocument();
        string reportPath = Server.MapPath("Reports//Quotation//UnitQuotation.rpt");
        quotationReportDocument.Load(reportPath);
        quotationReportDocument.Database.Tables["PropertyUnit"].SetDataSource(PropertyUnit);
        quotationReportDocument.Subreports["PropertyCharges"].SetDataSource(PropertyCharge);
        quotationReportDocument.Subreports["PropertyTaxes"].SetDataSource(PropertyTax);
        quotationReportDocument.Subreports["PROPERTYPAYSCHD"].SetDataSource(PropertyPymtSchd);
        Session["QuotationReport"] = quotationReportDocument;
        QuotationViewer.ReportSource = quotationReportDocument;
        QuotationViewer.Zoom(100);
    }
    private static void populatePropertyCharges(PropertyDTO propertyDto, DataTable PropertyCharge)
    {
        PropertyCharge.Columns.Add("ChargeType", typeof(string));
        PropertyCharge.Columns.Add("ChargeValue", typeof(string));

        if (propertyDto.PropertyCharges != null && propertyDto.PropertyCharges.Count > 0)
        {
            foreach (PropertyChargeDTO propertyChargeDTO in propertyDto.PropertyCharges)
            {
                DataRow chargeRow = PropertyCharge.NewRow();
                chargeRow["ChargeType"] = propertyChargeDTO.ChargeType.Name;
                chargeRow["ChargeValue"] = Convert.ToDecimal(propertyChargeDTO.ChargeValue);
                PropertyCharge.Rows.Add(chargeRow);
            }
        }
        else
        {
            DataRow chargeRow = PropertyCharge.NewRow();
            PropertyCharge.Rows.Add(chargeRow);
        }
    }

    private static void populatePropertySchd(List<PropertyScheduleDTO> propertyScheduleList, DataTable PropertyPymtSchd)
    {
        PropertyPymtSchd.Columns.Add("STAGE", typeof(string));
        PropertyPymtSchd.Columns.Add("PERCENTAGE", typeof(decimal));
        PropertyPymtSchd.Columns.Add("STATUS", typeof(string));
        PropertyPymtSchd.Columns.Add("STAGE_NUMBER", typeof(Int32));
        if (propertyScheduleList != null && propertyScheduleList.Count() > 0)
        {
            foreach (PropertyScheduleDTO propertySchdDto in propertyScheduleList)
            {
                DataRow stageRow = PropertyPymtSchd.NewRow();
                stageRow["STAGE"] = propertySchdDto.Stage.ToString();
                stageRow["PERCENTAGE"] = propertySchdDto.Percentage;
                stageRow["STATUS"] = propertySchdDto.Status.ToString();
                stageRow["STAGE_NUMBER"] = propertySchdDto.StageNumber;
                PropertyPymtSchd.Rows.Add(stageRow);
            }

        }
        else
        {
            DataRow stageRow = PropertyPymtSchd.NewRow();
            PropertyPymtSchd.Rows.Add(stageRow);
        }
    }

    private static PropertyDTO populatePropertyTax(PropertyUnitDTO propertyUnitDto, DataTable PropertyTax)
    {
        PropertyTax.Columns.Add("TaxType", typeof(string));
        PropertyTax.Columns.Add("TaxPercentage", typeof(string));
        PropertyDTO propertyDto = propertyUnitDto.PropertyTower.Property;
        if (propertyDto.PropertyTaxDetails != null && propertyDto.PropertyTaxDetails.Count > 0)
        {
            foreach (PropertyTaxDetailDTO propertyTaxDetailDto in propertyDto.PropertyTaxDetails)
            {
                if (IncludeInPymtTotal.Yes == propertyTaxDetailDto.IncludeInTotalPymt)
                {
                    DataRow taxRow = PropertyTax.NewRow();

                    taxRow["TaxType"] = propertyTaxDetailDto.TaxType.Name;
                    taxRow["TaxPercentage"] = propertyTaxDetailDto.TaxPercentage.ToString();
                    PropertyTax.Rows.Add(taxRow);
                }
            }
        }
        return propertyDto;
    }

    private static void populatePropertyUnit(PropertyUnitDTO propertyUnitDto, FirmDTO firmDto, PropertyDTO propertyDTO, DataTable PropertyUnit, DataRow prUnitRow)
    {
        PropertyUnit.Columns.Add("PropertyName", typeof(string));
        PropertyUnit.Columns.Add("PropertyAddress", typeof(string));
        PropertyUnit.Columns.Add("PrTowerName", typeof(string));
        PropertyUnit.Columns.Add("PrWing", typeof(string));
        PropertyUnit.Columns.Add("PrFloorNo", typeof(string));
        PropertyUnit.Columns.Add("PrFlatNo", typeof(string));
        PropertyUnit.Columns.Add("BuiltupArea", typeof(decimal));
        PropertyUnit.Columns.Add("CarpetArea", typeof(decimal));
        PropertyUnit.Columns.Add("BookingRate", typeof(decimal));
        PropertyUnit.Columns.Add("FirmName", typeof(string));

        prUnitRow["PropertyName"] = propertyUnitDto.PropertyTower.Property.Name;
        prUnitRow["PrTowerName"] = propertyUnitDto.PropertyTower.Name;
        string address = null;
        if (propertyDTO.ContactInfo.Addresses != null)
        {
            List<AddressDTO> addressList = propertyDTO.ContactInfo.Addresses.ToList();
            AddressDTO addressDTO = addressList[0];
            address = addressDTO.AddressLine1 + " " + addressDTO.AddressLine2 + " " + addressDTO.Town + " "
                + addressDTO.City.Name + " " + addressDTO.State.Name + " " + addressDTO.Country.Name;
        }
        prUnitRow["PropertyAddress"] = address;
        prUnitRow["PrWing"] = propertyUnitDto.Wing;
        prUnitRow["PrFloorNo"] = propertyUnitDto.FloorNo;
        prUnitRow["PrFlatNo"] = propertyUnitDto.UnitNo;
        prUnitRow["BuiltupArea"] = propertyUnitDto.BuildupArea;
        prUnitRow["CarpetArea"] = propertyUnitDto.CarpetArea;
        prUnitRow["BookingRate"] = propertyUnitDto.PropertyTower.Rate;
        prUnitRow["FirmName"] = firmDto.Name;

        PropertyUnit.Rows.Add(prUnitRow);
    }
    protected void bookPropertyUnit(object sender, EventArgs e)
    {
        try
        {
            if (validateBookPropertyUnit())
            {
                long Id = 0;
                PrUnitSaleDetailDTO prUnitSaleDetailDTO = populatePropertySaleDTOFromUI();
                Id = availableUnitBO.bookPropertyUnitDetails(prUnitSaleDetailDTO);
                resetTabInfo(AvailableUnitPageMode.NONE);
                string unitName = CommonUIConverter.getPropertyUnitFormattedNo(prUnitSaleDetailDTO.PropertyUnit.Wing, prUnitSaleDetailDTO.PropertyUnit.UnitNo);
                setSuccessMessage(string.Format("Property Unit '{0}' is booked successfully", unitName), tab1Anchor.ID, null);
                fetchAvailableUnits();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab3BzStep1Error);
        }
    }
    protected void cancelTab3Changes(object sender, EventArgs e)
    {
        PropertyUnitDTO propertyUnitDto = getCurrentPropertyUnit();
        resetTabInfo(AvailableUnitPageMode.NONE);
        loadSearchGridAndReSelect(propertyUnitDto.Id);
    }
    protected void cancelUnitView(object sender, EventArgs e)
    {
        PropertyUnitDTO propertyUnitDto = getCurrentPropertyUnit();
        resetTabInfo(AvailableUnitPageMode.NONE);
        loadSearchGridAndReSelect(propertyUnitDto.Id);
    }
    protected void reCalculateTotal(object sender, EventArgs e)
    {
        PrUnitSaleDetailDTO prUnitSaleDetailTO = getCurrentPropertyUnitSale();
        clearTaxSectionSelection(true);
        clearTaxSectionSelection(false);
        calculateAllSaleAmounts(prUnitSaleDetailTO);
        scrollToFieldHdn.Value = txtAgreementValue.ID;
    }
    protected void gotoTab3StepyWizard(object sender, EventArgs e)
    {
        bool isValid = validateTab3Step(tab3ContentBzHdn.Value);
        if (isValid)
        {
            setCurrentStep(goToStepHdn.Value);
        }
    }
    /**
     * Define all validation which will be done before add or update property.
     * */
    private bool validateBookPropertyUnit()
    {
        bool isValid = validateTab3Step(tab3BzStep1);
        if (!isValid) return false;
        string errorMsg = CommonValidations.validateUnitSaleDates(CommonUtil.getCSDateNotNull(txtBookingDate.Text), CommonUtil.getCSDate(txtPossesionDate.Text),
            CommonUtil.getCSDate(txtAgreementDate.Text), txtAgreementNo.Text, getAgreementDoneUIValue(), getPossessionDoneUIValue());
        if (!string.IsNullOrWhiteSpace(errorMsg))
        {
            setErrorMessage(errorMsg, tab3BzStep2Error);
            return false;
        }
        decimal agreementValue = CommonUtil.getDecimaNotNulllWithoutExt(txtAgreementValue.Text);
        if (agreementValue <= 0)
        {
            setErrorMessage(Resources.Messages.validation_agreementvalue_required, tab3BzStep1Error);
            return false;
        }
        return true;
    }
    /**
     * Validates given step.
     * */
    private bool validateTab3Step(string step)
    {
        bool isValid = true;
        if (!AvailableUnitPageMode.VIEW.ToString().Equals(pageModeHdn.Value))
        {
            if (step.Equals(tab3BzStep1))
            {
                isValid = validateAllStep1Group();
            }
            else if (step.Equals(tab3BzStep2))
            {

            }
        }
        return isValid;
    }
    private bool validateAllStep1Group()
    {
        Page.Validate(tab3BzStep1Error);
        bool isValid = Page.IsValid;
        if (!isValid)
        {
            tab3ContentBzHdn.Value = tab3BzStep1;
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    private void setCurrentStep(string step)
    {
        tab3ContentBzHdn.Value = step;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void calculateAllSaleAmounts(PrUnitSaleDetailDTO prUnitSaleDetailDto) {
        decimal agreementValue = CommonUtil.getDecimaNotNulllWithoutExt(txtAgreementValue.Text);
        decimal totalTax = Decimal.Zero;
        foreach (PrUnitSaleTaxDetailDTO prUnitSaleTaxDetailDto in prUnitSaleDetailDto.uiTaxDetails) {
            decimal tmpPercentage = Decimal.Divide(prUnitSaleTaxDetailDto.TaxPercentage, 100);
            decimal taxAmt = Math.Round(Decimal.Multiply(agreementValue, tmpPercentage), 2);
            if (prUnitSaleTaxDetailDto.TaxAmtLimit > 0 && taxAmt > prUnitSaleTaxDetailDto.TaxAmtLimit) taxAmt = prUnitSaleTaxDetailDto.TaxAmtLimit;
             prUnitSaleTaxDetailDto.TaxAmt = taxAmt;
             totalTax = totalTax + taxAmt;
        }
        txtBookTotalTax.Text = totalTax.ToString();
        txtBookTotalUnitCost.Text = (totalTax + agreementValue).ToString();
        foreach (PrUnitSaleTaxDetailDTO prUnitSaleTaxDetailDto in prUnitSaleDetailDto.uiCMTaxDetails) {
            decimal tmpPercentage = Decimal.Divide(prUnitSaleTaxDetailDto.TaxPercentage, 100);
            decimal taxAmt = Math.Round(Decimal.Multiply(agreementValue, tmpPercentage), 2);
            if (prUnitSaleTaxDetailDto.TaxAmtLimit > 0 && taxAmt > prUnitSaleTaxDetailDto.TaxAmtLimit) taxAmt = prUnitSaleTaxDetailDto.TaxAmtLimit;
            prUnitSaleTaxDetailDto.TaxAmt = taxAmt;
        }
        populateTaxDetailGrid(prUnitSaleDetailDto);
        populateCMTaxDetailGrid(prUnitSaleDetailDto);
    }
    private PrUnitSaleDetailDTO populatePrUnitSaleDetailDTOAdd()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        PropertyUnitDTO propertyUnitDto = getCurrentPropertyUnit();
        PrUnitSaleDetailDTO prUnitSaleDetailDto = new PrUnitSaleDetailDTO();
        prUnitSaleDetailDto.AgreementAmt = Decimal.Zero;
        prUnitSaleDetailDto.BookingDate = DateTime.Today;
        prUnitSaleDetailDto.TotalTaxAmt = Decimal.Zero;
        prUnitSaleDetailDto.TotalPymtAmt = Decimal.Zero;
        prUnitSaleDetailDto.PropertyUnit = propertyUnitDto;
        prUnitSaleDetailDto.uiTaxDetails = new List<PrUnitSaleTaxDetailDTO>();
        prUnitSaleDetailDto.uiCMTaxDetails = new List<PrUnitSaleTaxDetailDTO>();
        prUnitSaleDetailDto.CoCustomers = new HashSet<CoCustomerDTO>();
        PropertyDTO propertyDto = propertyUnitDto.PropertyTower.Property;
        if (propertyDto.PropertyTaxDetails != null && propertyDto.PropertyTaxDetails.Count > 0)
        {
            foreach (PropertyTaxDetailDTO propertyTaxDetailDto in propertyDto.PropertyTaxDetails)
            {
                if(IncludeInPymtTotal.Yes == propertyTaxDetailDto.IncludeInTotalPymt) prUnitSaleDetailDto.uiTaxDetails.Add(populatePrSaleTaxDetail(propertyTaxDetailDto));
                else prUnitSaleDetailDto.uiCMTaxDetails.Add(populatePrSaleTaxDetail(propertyTaxDetailDto));
            }
        }
        prUnitSaleDetailDto.PrParkings = new HashSet<PropertyParkingDTO>();
        prUnitSaleDetailDto.FirmNumber = userDefDto.FirmNumber;
        prUnitSaleDetailDto.InsertUser = userDefDto.Username;
        prUnitSaleDetailDto.UpdateUser = userDefDto.Username;
        parkingDetailsHdn.Value = "";
        return prUnitSaleDetailDto;
    }
    private PrUnitSaleTaxDetailDTO populatePrSaleTaxDetail(PropertyTaxDetailDTO propertyTaxDetailDto) {
        PrUnitSaleTaxDetailDTO taxDetailDto = new PrUnitSaleTaxDetailDTO();
        taxDetailDto.TaxType = propertyTaxDetailDto.TaxType;
        taxDetailDto.TaxPercentage = propertyTaxDetailDto.TaxPercentage;
        taxDetailDto.TaxAmtLimit = propertyTaxDetailDto.TaxAmtLimit;
        taxDetailDto.IncludeInTotalPymt = propertyTaxDetailDto.IncludeInTotalPymt;
        taxDetailDto.TaxAmt = Decimal.Zero;
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        taxDetailDto.FirmNumber = userDef.FirmNumber;
        taxDetailDto.InsertUser = userDef.Username;
        taxDetailDto.UpdateUser = userDef.Username;

        return taxDetailDto;
    }
    private PrUnitSaleDetailDTO populatePropertySaleDTOFromUI()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        PrUnitSaleDetailDTO prUnitSaleDetailDto = getCurrentPropertyUnitSale();
        prUnitSaleDetailDto.Customer = CommonUIConverter.getCustomerDTO(drpCustomer.Text, null);
        if (drpEnquiryRefNo.SelectedItem != null && drpEnquiryRefNo.SelectedItem.Text != "--Select--")
        {
            prUnitSaleDetailDto.EnquiryRefNo = drpEnquiryRefNo.SelectedItem.Text;
        }
        prUnitSaleDetailDto.FirmMember = CommonUIConverter.getFirmMemberDTO(drpEmployee.Text, null);
        prUnitSaleDetailDto.BookingDate = CommonUtil.getCSDateNotNull(txtBookingDate.Text);
        prUnitSaleDetailDto.SaleRate = CommonUtil.getDecimaNotNulllWithoutExt(txtBookingRate.Text);
        prUnitSaleDetailDto.AgreementAmt = CommonUtil.getDecimaNotNulllWithoutExt(txtAgreementValue.Text);
        prUnitSaleDetailDto.IsAgreementDone = getAgreementDoneUIValue();
        prUnitSaleDetailDto.AgreementDate = CommonUtil.getCSDate(txtAgreementDate.Text);
        prUnitSaleDetailDto.AgreementNo = txtAgreementNo.Text;
        prUnitSaleDetailDto.IsPossessionDone = getPossessionDoneUIValue();
        prUnitSaleDetailDto.PossessionDate = CommonUtil.getCSDate(txtPossesionDate.Text);
        prUnitSaleDetailDto.LoanBankName = txtLoanBankName.Text;
        prUnitSaleDetailDto.LoanBankBranch = txtLoanBranch.Text;
        prUnitSaleDetailDto.LoanAmt = CommonUtil.getDecimalWithoutExt(txtLoanAmount.Text);
        prUnitSaleDetailDto.TotalTaxAmt = CommonUtil.getDecimaNotNulllWithoutExt(txtBookTotalTax.Text);
        prUnitSaleDetailDto.TotalPymtAmt = CommonUtil.getDecimaNotNulllWithoutExt(txtBookTotalUnitCost.Text);
        prUnitSaleDetailDto.TotalPackageCost = prUnitSaleDetailDto.TotalPymtAmt;
        prUnitSaleDetailDto.PrUnitSaleTaxDetails = new HashSet<PrUnitSaleTaxDetailDTO>();
        prUnitSaleDetailDto.uiTaxDetails.ForEach(t => prUnitSaleDetailDto.PrUnitSaleTaxDetails.Add(t));
        prUnitSaleDetailDto.uiCMTaxDetails.ForEach(t => prUnitSaleDetailDto.PrUnitSaleTaxDetails.Add(t));
        prUnitSaleDetailDto.Status = PRUnitSaleStatus.Sold;

        PaymentMasterDTO paymentMasterDto = new PaymentMasterDTO();
        paymentMasterDto.TotalAmt = prUnitSaleDetailDto.TotalPymtAmt;
        paymentMasterDto.TotalPaid = Decimal.Zero;
        paymentMasterDto.TotalPending = prUnitSaleDetailDto.TotalPymtAmt;
        paymentMasterDto.TotalPdcAmt = Decimal.Zero;
        paymentMasterDto.Status = PymtMasterStatus.Pending;
        paymentMasterDto.FirmNumber = userDefDto.FirmNumber;
        paymentMasterDto.InsertUser = userDefDto.Username;
        paymentMasterDto.UpdateUser = userDefDto.Username;

        PrUnitSalePymtDTO prUnitSalePymDto = new PrUnitSalePymtDTO();
        prUnitSalePymDto.PymtDate = DateTime.Today;
        prUnitSalePymDto.PymtType = masterDataBO.getMasterDataType(userDefDto.FirmNumber, Constants.MCDType.PR_UNIT_PYMT_TYPE, Constants.MCD_SALE_PAYMENT);
        prUnitSalePymDto.PymtAmt = prUnitSaleDetailDto.TotalPymtAmt;
        prUnitSalePymDto.PymtTo = PRUnitSalePymtTo.Builder;
        prUnitSalePymDto.Description = "";
        prUnitSalePymDto.FirmNumber = userDefDto.FirmNumber;
        prUnitSalePymDto.InsertUser = userDefDto.Username;
        prUnitSalePymDto.UpdateUser = userDefDto.Username;
        prUnitSalePymDto.PaymentMaster = paymentMasterDto;

        prUnitSaleDetailDto.PrUnitSalePymts = new HashSet<PrUnitSalePymtDTO>();
        prUnitSaleDetailDto.PrUnitSalePymts.Add(prUnitSalePymDto);

        return prUnitSaleDetailDto;
    }
    private void populateUIFieldsFromUnitDTO(PropertyUnitDTO propertyUnitDTO)
    {
        if (propertyUnitDTO != null) txtUnitViewPropertyName.Text = propertyUnitDTO.PropertyTower.Property.Name; else txtUnitViewPropertyName.Text = null;
        if (propertyUnitDTO != null) txtUnitViewPropertyTower.Text = propertyUnitDTO.PropertyTower.Name; else txtUnitViewPropertyTower.Text = null;
        if (propertyUnitDTO != null) txtUnitViewWing.Text = propertyUnitDTO.Wing; else txtUnitViewWing.Text = null;
        if (propertyUnitDTO != null) txtUnitViewFloorno.Text = propertyUnitDTO.FloorNo; else txtUnitViewFloorno.Text = null;
        if (propertyUnitDTO != null) txtUnitViewUnitNo.Text = propertyUnitDTO.UnitNo; else txtUnitViewUnitNo.Text = null;
        if (propertyUnitDTO != null && propertyUnitDTO.UnitType != null) txtUnitViewUnitType.Text = propertyUnitDTO.UnitType.Name; else txtUnitViewUnitType.Text = null;
        if (propertyUnitDTO != null) txtUnitViewNoOfBalcony.Text = propertyUnitDTO.NoOfBalcony.ToString(); else txtUnitViewNoOfBalcony.Text = null;
        if (propertyUnitDTO != null) txtUnitViewBuiltupArea.Text = propertyUnitDTO.BuildupArea.ToString(); else txtUnitViewBuiltupArea.Text = null;
        if (propertyUnitDTO != null) txtUnitViewCarpetArea.Text = propertyUnitDTO.CarpetArea.ToString(); else txtUnitViewCarpetArea.Text = null;
        if (propertyUnitDTO != null && propertyUnitDTO.BalconyArea != null) txtUnitViewBalconyArea.Text = propertyUnitDTO.BalconyArea.ToString(); else txtUnitViewBalconyArea.Text = null;
        if (propertyUnitDTO != null && propertyUnitDTO.Direction != null) txtUnitViewDirection.Text = propertyUnitDTO.Direction.Name; else txtUnitViewDirection.Text = null;
        if (propertyUnitDTO != null && propertyUnitDTO.Facing != null) txtUnitViewFacing.Text = propertyUnitDTO.Facing.Name; else txtUnitViewFacing.Text = null;
    }
    private void populateUIFieldsFromSaleUnitDTO(PrUnitSaleDetailDTO prUnitSaleDetailDto)
    {
        PropertyUnitDTO propertyUnitDto = prUnitSaleDetailDto.PropertyUnit;
        PropertyTowerDTO propertyTowerDto = prUnitSaleDetailDto.PropertyUnit.PropertyTower;
        populateTab3UnitInfoSection(prUnitSaleDetailDto);
        drpCustomer.ClearSelection();
        drpEmployee.ClearSelection();
        drpEnquiryRefNo.ClearSelection();
        txtBookingDate.Text = CommonUtil.getCSDate(prUnitSaleDetailDto.BookingDate);
        txtBookingRate.Text = (propertyTowerDto.Rate != null) ? propertyTowerDto.Rate.ToString() : null;
        txtAgreementValue.Text = prUnitSaleDetailDto.AgreementAmt.ToString();
        txtBookTotalTax.Text = prUnitSaleDetailDto.TotalTaxAmt.ToString();
        txtBookTotalUnitCost.Text = prUnitSaleDetailDto.TotalPymtAmt.ToString();
        cbAgreementDone.Checked = false;
        cbPossessionGiven.Checked = false;
        txtAgreementDate.Text = null;
        txtAgreementNo.Text = null;
        txtPossesionDate.Text = null;
        txtLoanBankName.Text = null;
        txtLoanBranch.Text = null;
        txtLoanAmount.Text = null;
        populateTaxDetailGrid(prUnitSaleDetailDto);
        populateCMTaxDetailGrid(prUnitSaleDetailDto);
        populateCoCustomerGrid(prUnitSaleDetailDto);
    }
    private void populateTab3UnitInfoSection(PrUnitSaleDetailDTO prUnitSaleDetailDto)
    {
        PropertyUnitDTO propertyUnitDto = prUnitSaleDetailDto.PropertyUnit;
        PropertyTowerDTO propertyTowerDto = prUnitSaleDetailDto.PropertyUnit.PropertyTower;
        txtBookPropertyName.Text = propertyTowerDto.Property.Name;
        txtBookPropertyTower.Text = propertyTowerDto.Name;
        txtBookPropertyRate.Text = (propertyTowerDto.Rate != null) ? propertyTowerDto.Rate.ToString() : null;
        txtBookTowerPossession.Text = (propertyTowerDto.Possession != null) ? CommonUtil.getCSDate(propertyTowerDto.Possession) : null;
        txtBookUnitNo.Text = CommonUIConverter.getPropertyUnitFormattedNo(prUnitSaleDetailDto.PropertyUnit.Wing, prUnitSaleDetailDto.PropertyUnit.UnitNo);
        txtBookUnitType.Text = (propertyUnitDto.UnitType != null) ? propertyUnitDto.UnitType.Name : null;
        txtBookBuiltupArea.Text = propertyUnitDto.BuildupArea.ToString();
        txtBookCarpetArea.Text = propertyUnitDto.CarpetArea.ToString();
    }
    private void populateTaxDetailGrid(PrUnitSaleDetailDTO prUnitSaleDetailDTO)
    {
        taxDetailGrid.DataSource = new List<PrUnitSaleTaxDetailDTO>();
        if (prUnitSaleDetailDTO != null && prUnitSaleDetailDTO.uiTaxDetails != null)
        {
            assignUiIndexToTaxDetail(prUnitSaleDetailDTO.uiTaxDetails);
            taxDetailGrid.DataSource = prUnitSaleDetailDTO.uiTaxDetails;
        }
        taxDetailGrid.DataBind();
    }
    private void populateCMTaxDetailGrid(PrUnitSaleDetailDTO prUnitSaleDetailDTO)
    {
        cmTaxDetailGrid.DataSource = new List<PrUnitSaleTaxDetailDTO>();
        if (prUnitSaleDetailDTO != null && prUnitSaleDetailDTO.uiTaxDetails != null)
        {
            assignUiIndexToTaxDetail(prUnitSaleDetailDTO.uiCMTaxDetails);
            cmTaxDetailGrid.DataSource = prUnitSaleDetailDTO.uiCMTaxDetails;
        }
        cmTaxDetailGrid.DataBind();
    }
    private void assignUiIndexToTaxDetail(List<PrUnitSaleTaxDetailDTO> taxDetailDtos)
    {
        if (taxDetailDtos != null && taxDetailDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (PrUnitSaleTaxDetailDTO taxDetailDto in taxDetailDtos)
            {
                taxDetailDto.UiIndex = uiIndex++;
                taxDetailDto.RowInfo = CommonUIConverter.getGridViewRowInfo(taxDetailDto);
            }
        }
    }
  //TaxDetail Combined Table actions - Start
    private bool isCMTax(string currentTax) {
        return currentTax.Equals("CMTax");
    }
    private void clearTaxSectionSelection(bool isCMTaxSextion) {
        PrUnitSaleDetailDTO prUnitSaleDetailDto = getCurrentPropertyUnitSale();
        if (isCMTaxSextion) {
            pnlCMTaxDetailAdd.Visible = false;
            if (cmTaxDetailGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in cmTaxDetailGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdCMTaxDetailSelect");
                    if (radioBtn != null) radioBtn.Checked = false;
                }
            }
            if (prUnitSaleDetailDto.uiCMTaxDetails != null) prUnitSaleDetailDto.uiCMTaxDetails.ForEach(c => c.isUISelected = false);
        } else {
            pnlTaxDetailAdd.Visible = false;
            if (taxDetailGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in taxDetailGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdTaxDetailSelect");
                    if (radioBtn != null) radioBtn.Checked = false;
                }
            }
            if (prUnitSaleDetailDto.uiTaxDetails != null) prUnitSaleDetailDto.uiTaxDetails.ForEach(c => c.isUISelected = false);
        }
    }
    private void selectTaxDetail(PrUnitSaleTaxDetailDTO taxDetailDto, bool isCMTaxSection)
    {
        GridView currentGrid = taxDetailGrid;
        string radioBtselector = "rdTaxDetailSelect";
        string rowBtselector = "btnTaxDetailRowIdentifier";
        if (isCMTaxSection) {
            currentGrid = cmTaxDetailGrid;
            radioBtselector = "rdCMTaxDetailSelect";
            rowBtselector = "btnCMTaxDetailRowIdentifier";
        }
        if (currentGrid.Rows.Count > 0)
        {
            taxDetailDto.isUISelected = true;
            foreach (GridViewRow row in currentGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl(radioBtselector);
                Button rowIdenBtn = (Button)row.FindControl(rowBtselector);
                radioBtn.Checked = false;
                if (rowIdenBtn != null && taxDetailDto.UiIndex.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                {
                    radioBtn.Checked = true;
                }
            }
        }
    }
    private void initTaxDetailSection(bool isCMTaxSection)
    {
        if(isCMTaxSection) {
            lbCMTaxDetailAddUpdateSectionHeader.Text = Resources.Labels.label_sectionheader_add_tax;
            pnlCMTaxDetailAdd.Visible = true;
        } else {
            lbTaxDetailAddUpdateSectionHeader.Text = Resources.Labels.label_sectionheader_add_tax;
            pnlTaxDetailAdd.Visible = true;
        }
    }
    private void initTaxDetailSectionFields(bool isCMTaxSection)
    {
        initTaxDetailSection(isCMTaxSection);
        populateDrpTaxType(isCMTaxSection);
        if(isCMTaxSection) {
            drpCMTaxType.ClearSelection();
            txtCMTaxRate.Text = null;
            txtCMTaxLimit.Text = null;
            txtCMTaxAmount.Text = null;
            SetFocus(drpCMTaxType);
            scrollToFieldHdn.Value = pnlCMTaxDetailAdd.ID;
        } else {
            drpTaxType.ClearSelection();
            txtTaxRate.Text = null;
            txtTaxLimit.Text = null;
            txtTaxAmount.Text = null;
            SetFocus(drpTaxType);
            scrollToFieldHdn.Value = pnlTaxDetailAdd.ID;
        }
    }
    private bool populateDrpTaxType(bool isCMTaxSection)
    {
        bool hasTax = false;
        DropDownList tmpTaxDrp = (isCMTaxSection) ? drpCMTaxType : drpTaxType;
        PropertyDTO propertyDTO = getCurrentPropertyUnit().PropertyTower.Property;
        tmpTaxDrp.Items.Clear();
        tmpTaxDrp.Items.Insert(0, new ListItem(Constants.SELECT_ITEM[0], Constants.SELECT_ITEM[1]));
        if (propertyDTO.PropertyTaxDetails != null && propertyDTO.PropertyTaxDetails.Count > 0) {
            PrUnitSaleDetailDTO prUnitSaleDetailDTO = getCurrentPropertyUnitSale();
            foreach (PropertyTaxDetailDTO propertyTaxDetailDto in propertyDTO.PropertyTaxDetails) {
                if (!(prUnitSaleDetailDTO.uiTaxDetails.Any(t => t.TaxType.Id == propertyTaxDetailDto.TaxType.Id) 
                        || prUnitSaleDetailDTO.uiCMTaxDetails.Any(t => t.TaxType.Id == propertyTaxDetailDto.TaxType.Id))) {
                    tmpTaxDrp.Items.Add(new ListItem(propertyTaxDetailDto.TaxType.Name, propertyTaxDetailDto.TaxType.Id.ToString()));
                    hasTax = true;
                }
            }
        }
        return hasTax;
    }
    private PrUnitSaleTaxDetailDTO getSelectedTaxDetail(bool isCMTaxSection)
    {
        if(isCMTaxSection) 
            return getCurrentPropertyUnitSale().uiCMTaxDetails.Find(c => c.isUISelected);
        else 
            return getCurrentPropertyUnitSale().uiTaxDetails.Find(c => c.isUISelected);
    }
    private bool validateTaxDetailSelected(bool isCMTaxSection)
    {
        bool isSelected = true;
        PrUnitSaleTaxDetailDTO taxDetailDto = getSelectedTaxDetail(isCMTaxSection);
        if (taxDetailDto == null)
        {
            isSelected = false;
            clearTaxSectionSelection(isCMTaxSection);
            setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Tax Detail"), tab3BzStep1Error);
        }
        return isSelected;
    }
    private PrUnitSaleTaxDetailDTO populatePropertyTaxDetailAdd(PrUnitSaleDetailDTO prUnitSaleDetailDTO, bool isCMTaxSection)
    {
        PropertyDTO propertyDTO = getCurrentPropertyUnit().PropertyTower.Property;
        long selectedTaxId = (isCMTaxSection) ? long.Parse(drpCMTaxType.Text) : long.Parse(drpTaxType.Text);
        PropertyTaxDetailDTO selectedTaxDetailDto = propertyDTO.PropertyTaxDetails.FirstOrDefault(t => t.TaxType.Id == selectedTaxId);
        PrUnitSaleTaxDetailDTO taxDetailDto = populatePrSaleTaxDetail(selectedTaxDetailDto);
        taxDetailDto.TaxPercentage = CommonUtil.getDecimaNotNulllWithoutExt((isCMTaxSection) ? txtCMTaxRate.Text : txtTaxRate.Text);
        taxDetailDto.TaxAmtLimit = CommonUtil.getDecimaNotNulllWithoutExt((isCMTaxSection) ? txtCMTaxLimit.Text : txtTaxLimit.Text);
        taxDetailDto.TaxAmt = CommonUtil.getDecimaNotNulllWithoutExt((isCMTaxSection) ? txtCMTaxAmount.Text : txtTaxAmount.Text);
        taxDetailDto.UpdateUser = getUserDefinitionDTO().Username;
        if (isCMTaxSection)
        {
            taxDetailDto.IncludeInTotalPymt = IncludeInPymtTotal.No;
            prUnitSaleDetailDTO.uiCMTaxDetails.Add(taxDetailDto);
        }
        else
        {
            taxDetailDto.IncludeInTotalPymt = IncludeInPymtTotal.Yes;
            prUnitSaleDetailDTO.uiTaxDetails.Add(taxDetailDto);
        }
        return taxDetailDto;
    }
    protected void onSelectTaxDetail(object sender, EventArgs e)
    {
        GroupRadioButton rd = (GroupRadioButton)sender;
        bool isCMTaxSection = isCMTax(rd.Attributes["data-taxsection"]);
        clearTaxSectionSelection(!isCMTaxSection);
        if (isCMTaxSection) {
            pnlCMTaxDetailAdd.Visible = false;
            if (rd.Checked)
            {
                long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnCMTaxDetailRowIdentifier"))).Attributes["row-identifier"]);
                List<PrUnitSaleTaxDetailDTO> taxDetailList = getCurrentPropertyUnitSale().uiCMTaxDetails;
                taxDetailList.ForEach(c => c.isUISelected = false);
                taxDetailList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
            }
        }
        else {
            pnlTaxDetailAdd.Visible = false;
            if (rd.Checked)
            {
                long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnTaxDetailRowIdentifier"))).Attributes["row-identifier"]);
                List<PrUnitSaleTaxDetailDTO> taxDetailList = getCurrentPropertyUnitSale().uiTaxDetails;
                taxDetailList.ForEach(c => c.isUISelected = false);
                taxDetailList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
            }
        }
    }
    protected void onClickAddTaxDetailBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            bool isCMTaxSection = isCMTax(rd.Attributes["data-taxsection"]);
            clearTaxSectionSelection(!isCMTaxSection);
            clearTaxSectionSelection(isCMTaxSection);
            if (populateDrpTaxType(isCMTaxSection))
            {
                initTaxDetailSectionFields(isCMTaxSection);
            }
            else
            {
                setErrorMessage("Tax type not available for add", tab3BzStep1Error);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab3BzStep1Error);
        }
    }
    protected void onTaxRateChanged(object sender, EventArgs e)
    {
        TextBox tmpTxtBox = (TextBox)sender;
        bool isCMTaxSection = isCMTax(tmpTxtBox.Attributes["data-taxsection"]);
        DropDownList tmpDrp = (isCMTaxSection) ? drpCMTaxType : drpTaxType;
        if (!(string.IsNullOrWhiteSpace(tmpDrp.Text) || string.IsNullOrWhiteSpace(tmpTxtBox.Text)))
        {
            decimal agreementValue = CommonUtil.getDecimaNotNulllWithoutExt(txtAgreementValue.Text);
            decimal taxPercentage = Decimal.Divide(CommonUtil.getDecimaNotNulllWithoutExt(tmpTxtBox.Text), 100);
            decimal tmpTaxLimit = (isCMTaxSection) ? CommonUtil.getDecimaNotNulllWithoutExt(txtCMTaxLimit.Text) : CommonUtil.getDecimaNotNulllWithoutExt(txtTaxLimit.Text);
            decimal taxAmt = Math.Round(Decimal.Multiply(agreementValue, taxPercentage), 2);
            if (tmpTaxLimit > 0 && taxAmt > tmpTaxLimit) taxAmt = tmpTaxLimit;
            if (isCMTaxSection) txtCMTaxAmount.Text = taxAmt.ToString(); else txtTaxAmount.Text = taxAmt.ToString();
        }
        else
        {
            if (isCMTaxSection) txtCMTaxAmount.Text = null; else txtTaxAmount.Text = null;
        }
    }
    protected void onTaxTypeChanged(object sender, EventArgs e)
    {
        DropDownList tmpDrp = (DropDownList)sender;
        bool isCMTaxSection = isCMTax(tmpDrp.Attributes["data-taxsection"]);
        if (!string.IsNullOrWhiteSpace(tmpDrp.Text))
        {
            PropertyDTO propertyDTO = getCurrentPropertyUnit().PropertyTower.Property;
            long selectedTaxId = long.Parse(tmpDrp.Text);
            PropertyTaxDetailDTO selectedTaxDetailDto = propertyDTO.PropertyTaxDetails.FirstOrDefault(t => t.TaxType.Id == selectedTaxId);
            decimal agreementValue = CommonUtil.getDecimaNotNulllWithoutExt(txtAgreementValue.Text);
            decimal tmpPercentage = Decimal.Divide(selectedTaxDetailDto.TaxPercentage, 100);
            decimal taxAmt = Math.Round(Decimal.Multiply(agreementValue, tmpPercentage), 2);
            if (selectedTaxDetailDto.TaxAmtLimit > 0 && taxAmt > selectedTaxDetailDto.TaxAmtLimit) taxAmt = selectedTaxDetailDto.TaxAmtLimit;
            if (isCMTaxSection) txtCMTaxRate.Text = selectedTaxDetailDto.TaxPercentage.ToString(); else txtTaxRate.Text = selectedTaxDetailDto.TaxPercentage.ToString();
            if (isCMTaxSection) txtCMTaxLimit.Text = selectedTaxDetailDto.TaxAmtLimit.ToString(); else txtTaxLimit.Text = selectedTaxDetailDto.TaxAmtLimit.ToString();
            if (isCMTaxSection) txtCMTaxAmount.Text = taxAmt.ToString(); else txtTaxAmount.Text = taxAmt.ToString();
        }
        else
        {
            if (isCMTaxSection) txtCMTaxRate.Text = null; else txtTaxRate.Text = null;
            if (isCMTaxSection) txtCMTaxLimit.Text = null; else txtTaxLimit.Text = null;
            if (isCMTaxSection) txtCMTaxAmount.Text = null; else txtTaxAmount.Text = null;
        }
    }
    protected void deleteTaxDetail(object sender, EventArgs e)
    {
        try
        {
            Button rd = (Button)sender;
            bool isCMTaxSection = isCMTax(rd.Attributes["data-taxsection"]);
            clearTaxSectionSelection(!isCMTaxSection);
            if (validateTaxDetailSelected(isCMTaxSection))
            {
                PrUnitSaleDetailDTO prUnitSaleDetailDTO = getCurrentPropertyUnitSale();
                PrUnitSaleTaxDetailDTO taxDetailDto = getSelectedTaxDetail(isCMTaxSection);
                if (isCMTaxSection) prUnitSaleDetailDTO.uiCMTaxDetails.Remove(taxDetailDto); 
                else prUnitSaleDetailDTO.uiTaxDetails.Remove(taxDetailDto); 
                clearTaxSectionSelection(isCMTaxSection);
                calculateAllSaleAmounts(prUnitSaleDetailDTO);
                setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, taxDetailDto.TaxType.Name), tab3Anchor.ID, tab3BzStep1);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab3BzStep1Error);
        }
    }
    protected void addNewTaxDetail(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            bool isCMTaxSection = isCMTax(rd.Attributes["data-taxsection"]);
            clearTaxSectionSelection(!isCMTaxSection);
            if (validateTaxDetail(isCMTaxSection))
            {
                PrUnitSaleDetailDTO prUnitSaleDetailDTO = getCurrentPropertyUnitSale();
                PrUnitSaleTaxDetailDTO taxDetailDto = populatePropertyTaxDetailAdd(prUnitSaleDetailDTO, isCMTaxSection);
                calculateAllSaleAmounts(prUnitSaleDetailDTO);
                selectTaxDetail(taxDetailDto, isCMTaxSection);
                clearTaxSectionSelection(isCMTaxSection);
                setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, taxDetailDto.TaxType.Name), tab3Anchor.ID, tab3BzStep1);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab3BzStep1Error);
        }
    }
    protected void cancelTaxDetail(object sender, EventArgs e)
    {
        LinkButton rd = (LinkButton)sender;
        bool isCMTaxSection = isCMTax(rd.Attributes["data-taxsection"]);
        clearTaxSectionSelection(isCMTaxSection);
        scrollToFieldHdn.Value = (isCMTaxSection) ? lbCMTaxSectionHeader.ID : lbTaxSectionHeader.ID;
    }
    //TaxDetail Combined Table actions - END
    private bool validateTaxDetail(bool isCMTaxSection)
    {
        bool isValid = true;
        string vGroup = (isCMTaxSection) ? "tab3BzStep1ErrorGrid2" : "tab3BzStep1ErrorGrid1";
        Page.Validate(vGroup);
        isValid = Page.IsValid;
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }

   
    //TaxDetail Table actions - END
    //Parking Functionaity - Start
    protected void addNewParking(object sender, EventArgs e)
    {
        try
        {
            PropertyParkingDTO tmpParkingDto = getSelectedParkingDto(prParkingHdn.Value);
            string errorMsg = validateAddParking(tmpParkingDto);
            if (string.IsNullOrWhiteSpace(errorMsg))
            {
                PropertyParkingDTO prParkingDto = propertyBO.fetchPropertyParkingDetails(tmpParkingDto.Id);
                PrUnitSaleDetailDTO prUnitSaleDto = getCurrentPropertyUnitSale();
                prUnitSaleDto.PrParkings.Add(prParkingDto);
                parkingDetailsHdn.Value = CommonUtil.getUiParkingDetails(getCurrentPropertyUnitSale());
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "closeParkingDialogClient", "closeParkingDialogClient()", true);
                drpPrParking.ClearSelection();
                prParkingHdn.Value = "";
            }
            else
            {
                modalErrorMsg.Value = errorMsg;
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "setModalErrorMsg", "setModalErrorMsg()", true);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab3BzStep2Error);
        }
    }
    protected void editParking(object sender, EventArgs e)
    {
        try
        {
            CommonUtil.updateParking(getCurrentPropertyUnitSale(), parkingDetailsHdn.Value);
            parkingDetailsHdn.Value = CommonUtil.getUiParkingDetails(getCurrentPropertyUnitSale());
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab3BzStep2Error);
        }
    }
    protected void cancelEditParking(object sender, EventArgs e)
    {
        try
        {
            parkingDetailsHdn.Value = CommonUtil.getUiParkingDetails(getCurrentPropertyUnitSale());
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab3BzStep2Error);
        }
    }
    private string validateAddParking(PropertyParkingDTO prParkingDto)
    {
        if (prParkingDto == null) return "Please select Parking.";
        PrUnitSaleDetailDTO prUnitSaleDto = getCurrentPropertyUnitSale();
        if (prUnitSaleDto.PrParkings != null)
        {
            if (prUnitSaleDto.PrParkings.Any(x => x.Id == prParkingDto.Id))
            {
                return "Selected Parking is already added.";
            }
        }
        return "";
    }
    private PropertyParkingDTO getSelectedParkingDto(string parkingNo)
    {
        PropertyParkingDTO prParkingDto = null;
        if (drpPrParking.Items.Count > 1)
        {
            ListItem item = drpPrParking.Items.FindByText(parkingNo);
            //txtLoanBankName.Text = (item != null) ? item.Value+"|"+item.Text : "NOT FOUND";
            if (item != null)
            {
                prParkingDto = CommonUIConverter.getPropertyParkingDTO(item.Value, item.Text);
            }
        }
        return prParkingDto;
    }
    //Parking Functionaity - End
    //Co Customer Table actions - Start
      private void initCocustomerAddUpdateSection(bool isAdd)
      {
          lbAddUpdateCoCustSectionHeader.Text = (isAdd) ? Resources.Labels.label_sectionheader_add_cocustomer : Resources.Labels.label_sectionheader_modify_cocustomer;
          pnlCoCustomer.Visible = true;
          btnAddCoCustomerIntoGrid.Visible = isAdd;
          btnUpdateCoCustomer.Visible = !isAdd;
      }
      private void initCocustomerSectionFields(CoCustomerDTO cocustomerDTO)
      {
          if (cocustomerDTO != null) txtCoCustomerFirstname.Text = cocustomerDTO.FirstName; else txtCoCustomerFirstname.Text = null;
          if (cocustomerDTO != null) txtcocustomermiddlename.Text = cocustomerDTO.MiddleName; else txtcocustomermiddlename.Text = null;
          if (cocustomerDTO != null) txtcocustomerlastname.Text = cocustomerDTO.LastName; else txtcocustomerlastname.Text = null;
          if (cocustomerDTO != null && cocustomerDTO.Occupation != null) drpCoCustomerOccupation.Text = cocustomerDTO.Occupation.Id.ToString(); else drpCoCustomerOccupation.ClearSelection();
          if (cocustomerDTO != null && cocustomerDTO.ContactInfo.Dob != null) txtCocustomerDOB.Text = cocustomerDTO.ContactInfo.Dob.Value.ToString(Constants.DATE_FORMAT); else txtCocustomerDOB.Text = null;
          if (cocustomerDTO != null) txtCoCustomerContact.Text = cocustomerDTO.ContactInfo.Contact; else txtCoCustomerContact.Text = null;
          if (cocustomerDTO != null && cocustomerDTO.SalutationId != null) drpCocustomerSalutation.Text = cocustomerDTO.SalutationId.Id.ToString(); else drpCocustomerSalutation.ClearSelection();
          if (cocustomerDTO != null && cocustomerDTO.ContactInfo.MaritalStatus != null) drpCocustomerMaritalstatus.Text = cocustomerDTO.ContactInfo.MaritalStatus.ToString(); else drpCocustomerMaritalstatus.ClearSelection();
          if (cocustomerDTO != null && cocustomerDTO.ContactInfo.Gender != null) drpcocustomergender.Text = cocustomerDTO.ContactInfo.Gender.ToString(); else drpcocustomergender.ClearSelection();
          if (cocustomerDTO != null) txtCoCustomerPan.Text = cocustomerDTO.Pan; else txtCoCustomerPan.Text = null;
          if (cocustomerDTO != null) txtCoCustomerAlternateContact.Text = cocustomerDTO.ContactInfo.AltContact; else txtCoCustomerAlternateContact.Text = null;
          if (cocustomerDTO != null) txtCoCustomerEmail.Text = cocustomerDTO.ContactInfo.Email; else txtCoCustomerEmail.Text = null;
          if (cocustomerDTO != null) txtCocustomerAltEmailId.Text = cocustomerDTO.ContactInfo.AltEmail; else txtCocustomerAltEmailId.Text = null;
          if (cocustomerDTO != null && cocustomerDTO.RelationWhPrimCust != null) drprelationwithcustomer.Text = cocustomerDTO.RelationWhPrimCust.Id.ToString(); else drprelationwithcustomer.ClearSelection();
          if (cocustomerDTO != null && cocustomerDTO.IsPoa != null) drpPowerOfAtorny.Text = cocustomerDTO.IsPoa.ToString(); else drpPowerOfAtorny.ClearSelection();
      }

      private void clearCoCustomerViewState()
      {
          if (coCustomerGrid.Rows.Count > 0)
          {
              foreach (GridViewRow row in coCustomerGrid.Rows)
              {
                  GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdCoCustomerSelect");
                  if (radioBtn != null) radioBtn.Checked = false;
              }
          }
          getCurrentPropertyUnitSale().CoCustomers.ToList<CoCustomerDTO>().ForEach(c => c.isUISelected = false);
      }
      private void reSelectCoCustomer(CoCustomerDTO coCustomerDto)
      {
          if (coCustomerGrid.Rows.Count > 0)
          {
              coCustomerDto.isUISelected = true;
              foreach (GridViewRow row in coCustomerGrid.Rows)
              {
                  GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdCoCustomerSelect");
                  Button rowIdenBtn = (Button)row.FindControl("btnCoCustomerRowIdentifier");
                  radioBtn.Checked = false;
                  if (rowIdenBtn != null && coCustomerDto.UiIndex.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                  {
                      radioBtn.Checked = true;
                  }
              }
          }
      }
      private CoCustomerDTO getSelectedCoCustomer()
      {
          return getCurrentPropertyUnitSale().CoCustomers.ToList<CoCustomerDTO>().Find(c => c.isUISelected);
      }
      private bool validateCoCustomerSelected()
      {
          bool isSelected = true;
          CoCustomerDTO cocustomerdto = getSelectedCoCustomer();
          if (cocustomerdto == null)
          {
              isSelected = false;
              pnlCoCustomer.Visible = false;
              clearCoCustomerViewState();
              setErrorMessage(string.Format(Resources.Messages.validation_record_select, "CoCustomer"), tab3BzStep2Error);
          }
          return isSelected;
      }

      private void populateCoCustomerFromUI(CoCustomerDTO cocustomerDTO)
      {
          UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
          cocustomerDTO.SalutationId = CommonUIConverter.getMasterControlDTO(drpCocustomerSalutation.Text, drpCoCustomerOccupation.SelectedItem.Text);
          cocustomerDTO.FirstName = txtCoCustomerFirstname.Text;
          cocustomerDTO.MiddleName = txtcocustomermiddlename.Text;
          cocustomerDTO.FirmNumber = userDefDto.FirmNumber;
          cocustomerDTO.LastName = txtcocustomerlastname.Text;
          cocustomerDTO.FullName = CommonUIConverter.getCustomerFullName(cocustomerDTO.FirstName, cocustomerDTO.LastName);
          cocustomerDTO.Occupation = CommonUIConverter.getMasterControlDTO(drpCoCustomerOccupation.Text, drpCoCustomerOccupation.SelectedItem.Text);
          cocustomerDTO.Pan = txtCoCustomerPan.Text;
          cocustomerDTO.ContactInfo = new ContactInfoDTO();
          cocustomerDTO.ContactInfo.Gender = EnumHelper.ToEnumNullable<Gender>(drpcocustomergender.Text);
          cocustomerDTO.ContactInfo.Dob = CommonUtil.getCSDateNotNull(txtCocustomerDOB.Text);
          cocustomerDTO.ContactInfo.MaritalStatus = EnumHelper.ToEnumNullable<MaritalStatus>(drpCocustomerMaritalstatus.Text);
          cocustomerDTO.ContactInfo.Contact = txtCoCustomerContact.Text;
          cocustomerDTO.ContactInfo.AltContact = txtCoCustomerAlternateContact.Text;
          cocustomerDTO.ContactInfo.Email = txtCoCustomerEmail.Text;
          cocustomerDTO.ContactInfo.AltEmail = txtCocustomerAltEmailId.Text;
          cocustomerDTO.IsPoa = EnumHelper.ToEnumNullable<PowerOfAtorny>(drpPowerOfAtorny.Text);
          cocustomerDTO.RelationWhPrimCust = CommonUIConverter.getMasterControlDTO(drprelationwithcustomer.Text, drprelationwithcustomer.SelectedItem.Text);
      }

      private void setDefaultOnCoCocustomer()
      {
          
      }
      private void populateCoCustomerGrid(PrUnitSaleDetailDTO prSaleDetailDTO)
      {
          coCustomerGrid.DataSource = new List<CoCustomerDTO>();
          if (prSaleDetailDTO != null)
          {
              assignUiIndexToCoCustomer(prSaleDetailDTO.CoCustomers);
              coCustomerGrid.DataSource = prSaleDetailDTO.CoCustomers;
          }
          coCustomerGrid.DataBind();
      }

      protected void onSelectCocustomer(object sender, EventArgs e)
      {
          GroupRadioButton rd = (GroupRadioButton)sender;
          pnlCoCustomer.Visible = false;
          if (rd.Checked)
          {
              long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnCoCustomerRowIdentifier"))).Attributes["row-identifier"]);
              List<CoCustomerDTO> cocustomerList = getCurrentPropertyUnitSale().CoCustomers.ToList<CoCustomerDTO>();
              cocustomerList.ForEach(c => c.isUISelected = false);
              cocustomerList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
          }
      }
      protected void onClickAddCoCustomerBtn(object sender, EventArgs e)
      {
          try
          {
              initCocustomerAddUpdateSection(true);
              initCocustomerSectionFields(null);
              setDefaultOnCoCocustomer();
              SetFocus(txtCoCustomerFirstname);
              scrollToFieldHdn.Value = pnlCoCustomer.ID;
          }
          catch (Exception exp)
          {
              log.Error(exp.Message, exp);
              setErrorMessage(Resources.Messages.system_error, tab3BzStep2Error);
          }
      }
      protected void onClickModifyCoCustomerBtn(object sender, EventArgs e)
      {
          try
          {
              if (validateCoCustomerSelected())
              {
                  initCocustomerAddUpdateSection(false);
                  initCocustomerSectionFields(getSelectedCoCustomer());
                  SetFocus(txtCoCustomerFirstname);
                  scrollToFieldHdn.Value = pnlCoCustomer.ID;
              }
          }
          catch (Exception exp)
          {
              log.Error(exp.Message, exp);
              setErrorMessage(Resources.Messages.system_error, tab3BzStep2Error);
          }
      }
      protected void deleteCoCustomer(object sender, EventArgs e)
      {
          try
          {
              if (validateCoCustomerSelected())
              {
                  PrUnitSaleDetailDTO prSaleDetailDTO = getCurrentPropertyUnitSale();
                  CoCustomerDTO cocustomerDto = getSelectedCoCustomer();
                  prSaleDetailDTO.CoCustomers.Remove(cocustomerDto);
                  pnlCoCustomer.Visible = false;
                  clearCoCustomerViewState();
                  populateCoCustomerGrid(prSaleDetailDTO);
                  setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, "CoCustomer"), tab3Anchor.ID, tab3BzStep2);
              }
          }
          catch (Exception exp)
          {
              log.Error(exp.Message, exp);
              setErrorMessage(Resources.Messages.system_error, tab3BzStep2Error);
          }
      }
      protected void addNewCoCustomer(object sender, EventArgs e)
      {
          try
          {
              if (validateCoCustomer())
              {
                  PrUnitSaleDetailDTO prSaleDetailDTO = getCurrentPropertyUnitSale();
                  CoCustomerDTO CocustomerDto = new CoCustomerDTO();
                  populateCoCustomerFromUI(CocustomerDto);
                  prSaleDetailDTO.CoCustomers.Add(CocustomerDto);
                  pnlCoCustomer.Visible = false;
                  populateCoCustomerGrid(prSaleDetailDTO);
                  reSelectCoCustomer(CocustomerDto);               
                  setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, "CoCustomer"), tab3Anchor.ID, tab3BzStep2);
              }
          }
          catch (Exception exp)
          {
              log.Error(exp.Message, exp);
              setErrorMessage(Resources.Messages.system_error, tab3BzStep2Error);
          }
      }
      protected void updateCoCustomer(object sender, EventArgs e)
      {
          try
          {
              if (validateCoCustomer())
              {
                  PrUnitSaleDetailDTO prSaleDetailDTO = getCurrentPropertyUnitSale();
                  CoCustomerDTO CocustomerDto = getSelectedCoCustomer();
                  populateCoCustomerFromUI(CocustomerDto);
                  pnlCoCustomer.Visible = false;
                  populateCoCustomerGrid(prSaleDetailDTO);
                  reSelectCoCustomer(CocustomerDto);
                  setSuccessMessage(string.Format(Resources.Messages.success_record_updatedtotable, "Co-Customer"), tab3Anchor.ID, tab3BzStep2);
              }
          }
          catch (Exception exp)
          {
              log.Error(exp.Message, exp);
              setErrorMessage(Resources.Messages.system_error, tab3BzStep2Error);
          }
      }
      protected void cancelCoCustomer(object sender, EventArgs e)
      {
          pnlCoCustomer.Visible = false;
          clearCoCustomerViewState();
      }
      private bool validateCoCustomer()
      {
          bool isValid = true;
          Page.Validate("tab3BzStep2Error");
          isValid = Page.IsValid;
          if (!isValid)
          {
              scrollToFieldHdn.Value = Constants.SCROLL_TOP;
          }
          return isValid;
      }
      private void assignUiIndexToCoCustomer(ISet<CoCustomerDTO> CocustomerDtos)
      {
          if (CocustomerDtos != null && CocustomerDtos.Count > 0)
          {
              long uiIndex = 1;
              foreach (CoCustomerDTO cocustomerDto in CocustomerDtos)
              {
                  cocustomerDto.FullName = CommonUIConverter.getCustomerFullName(cocustomerDto.FirstName, cocustomerDto.LastName);
                  cocustomerDto.UiIndex = uiIndex++;
                  cocustomerDto.RowInfo = CommonUIConverter.getGridViewRowInfo(cocustomerDto);
              }
          }
      }
      protected void saveModalData(object sender, EventArgs e)
      {
          String errorMsg = "";
          UserDefinitionDTO userDefDto = getUserDefinitionDTO();
          if (modalHdnType.Value == "OCCUPATION")
          {
              MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.OCCUPATION, modalInput1.Text,
                     modalInput2.Text, userDefDto);
              errorMsg = validateMasterDataModalInput(masterDataDto, "Occupation");
              if (string.IsNullOrWhiteSpace(errorMsg))
              {
                  masterDataBO.saveMasterData(masterDataDto);
                  drpBO.drpDataBase(drpCoCustomerOccupation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.OCCUPATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                  modalIdentifierHdn.Value = "";
              }
          }
          else if (modalHdnType.Value == "RELATION_WITH_CUSTOMER")
          {
              MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.RELATION_WITH_CUSTOMER, modalInput1.Text,
                     modalInput2.Text, userDefDto);
              errorMsg = validateMasterDataModalInput(masterDataDto, "Relation With Customer");
              if (string.IsNullOrWhiteSpace(errorMsg))
              {
                  masterDataBO.saveMasterData(masterDataDto);
                  drpBO.drpDataBase(drprelationwithcustomer, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.RELATION_WITH_CUSTOMER, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                  modalIdentifierHdn.Value = "";
              }
          }
          if (!string.IsNullOrWhiteSpace(errorMsg))
          {
              modalErrorMsg.Value = errorMsg;
              ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "setModalErrorMsg", "setModalErrorMsg()", true);
          }
          else
          {
              //Reset the modal fields
              modalInput1.Text = "";
              modalInput2.Text = "";
              modalHdnType.Value = "";
              modalActionHdn.Value = "";
              ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "closeDialogClient", "closeDialogClient()", true);
          }
      }

      private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
      {
          string errorMsg = "";
          if (string.IsNullOrWhiteSpace(masterDataDto.Name))
          {
              errorMsg = Resources.Messages.validation_designationname_required;
          }
          else if (masterDataBO.isAlreadyExist(masterDataDto))
          {
              errorMsg = string.Format(Resources.Messages.validation_same_name_exist, type);
          }
          return errorMsg;
      }
}
