﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using System.Web;
using System.IO;

public partial class ManageDocument : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string tab1ValidationGrp = "tab1Error";
    string VS_CUSTOMER = "VS_CUSTOMER";
    string VS_PROPERTY = "VS_PROPERTY";
    DropdownBO drpBO = new DropdownBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    public enum DocumentPageMode { ADD, MODIFY, VIEW, NONE }
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Form.Attributes.Add("enctype", "multipart/form-data");
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                resetPageInfo(DocumentPageMode.NONE);
                initDropdowns();
                Page.MaintainScrollPositionOnPostBack = false;
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpEnum<DocumentOwner>(drpDocumentOwner, null);
        drpBO.drpDataBase(drpDocumentType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.DOCUMENT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
    }
    private CustomerDTO getCurrentCustomer()
    {
        return (CustomerDTO)ViewState[VS_CUSTOMER];
    }
    private PropertyDTO getCurrentProperty()
    {
        return (PropertyDTO)ViewState[VS_PROPERTY];
    }
    
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        addDocumentBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_ADD);
        downloadDocumentBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_MODIFY);
        deleteDocumentBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_DELETE);
        bool isReadOnly = !(addDocumentBtn.Visible || downloadDocumentBtn.Visible || deleteDocumentBtn.Visible);
        documentBtnGrp.Visible = !isReadOnly;
        documentGrid.Columns[0].Visible = !isReadOnly;

    }
    private void preRenderInitFormElements()
    {
        jumpToDocumentHdnId.Value = "";
        DocumentDTO documentDTO = getSelectedDocument();
        if (documentDTO != null)
        {
            jumpToDocumentHdnId.Value = documentDTO.UiIndex + "";
        }
    }
    public void setErrorMessage(string message, string group)
    {
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }

    public void setSuccessMessage(string msg)
    {
        lbTab1Success.Text = msg;
        tab1SuccessPanel.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private void clearMessages()
    {
        tab1SuccessPanel.Visible = false;
        lbTab1Success.Text = "";
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }

    private void resetPageInfo(DocumentPageMode pageMode)
    {
        pageModeHdn.Value = pageMode.ToString();
        initFormFields();
        pnlDocumentAdd.Visible = false;
        if (DocumentPageMode.NONE == pageMode)
        {
            pnlDocumentGrid.Visible = false;
            ViewState[VS_CUSTOMER] = new CustomerDTO();
            ViewState[VS_PROPERTY] = new PropertyDTO();
        }
        else
        {
            pnlDocumentGrid.Visible = true;
        }
    }
    private void initFormFields()
    {
        bool isReadOnly = (DocumentPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
        bool visible = !(DocumentPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
        //Buttons
        btnAddSubmit.Visible = visible;
    }
    private List<DocumentDTO> getDocumentList()
    {
        List<DocumentDTO> documentList = new List<DocumentDTO>();
        DocumentOwner searchBy = EnumHelper.ToEnum<DocumentOwner>(drpDocumentOwner.Text);
        if (DocumentOwner.CUSTOMER_NAME == searchBy)
        {
            CustomerDTO customerDTO = (CustomerDTO)ViewState[VS_CUSTOMER];
            if (customerDTO.DocumentInfo != null)
            {
                documentList = customerDTO.DocumentInfo.Documents.ToList();
            }
        }
        if (DocumentOwner.PROPERTY_NAME == searchBy)
        {
            PropertyDTO propertyDTO = (PropertyDTO)ViewState[VS_PROPERTY];
            if (propertyDTO.DocumentInfo != null)
            {
                documentList = propertyDTO.DocumentInfo.Documents.ToList();
            }
        }
        return documentList;
    }
    private DocumentDTO getSelectedDocument()
    {
        DocumentDTO selectedDocument = null;
        List<DocumentDTO> documentList = getDocumentList();
        if (documentList != null)
        {
            selectedDocument = documentList.Find(c => c.isUISelected);
        }
        return selectedDocument;
    }
    private void setSelectedDocument(long selectedUiIndex)
    {
        List<DocumentDTO> documentList = getDocumentList();
        if (documentList != null)
        {
            documentList.ForEach(c => c.isUISelected = false);
            if (selectedUiIndex != -1) documentList.Find(c => c.UiIndex == selectedUiIndex).isUISelected = true;
        }
    }
    private void initDocumentAddUpdateSection(bool isAdd)
    {
        lbDocumentAddUpdateSectionHeader.Text = (isAdd) ? Resources.Labels.label_sectionheader_document_add : Resources.Labels.label_sectionheader_document_modify;
        pnlDocumentAdd.Visible = true;
        btnDocumentAddToGrid.Visible = isAdd;
    }
    private void setDefaultOnAddPropertyTower()
    {

    }
    private void initDocumentSectionFields(DocumentDTO documentDto)
    {
        if (documentDto != null) txtDocumentName.Text = documentDto.Name; else txtDocumentName.Text = null;
        if (documentDto != null) drpDocumentType.Text = documentDto.DocumentType.Name + ""; else drpDocumentType.ClearSelection();
        if (documentDto != null) txtDescription.Text = documentDto.Description; else txtDescription.Text = null;
    }
    private void resetDocumentSelection(long uiIndex)
    {
        if (documentGrid.Rows.Count > 0)
        {
            foreach (GridViewRow row in documentGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdDocumentSelect");
                radioBtn.Checked = false;
                if (uiIndex > 0)
                {
                    Button rowIdenBtn = (Button)row.FindControl("btnDocumentRowIdentifier");
                    if (rowIdenBtn != null && uiIndex.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                    {
                        radioBtn.Checked = true;
                        setSelectedDocument(uiIndex);
                    }
                }
            }
        }
        if (uiIndex <= 0) setSelectedDocument(-1);
    }
    private bool validateDocumentSelected()
    {
        bool isSelected = true;
        DocumentDTO selectedDocument = getSelectedDocument();
        if (selectedDocument == null)
        {
            isSelected = false;
            setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Document"), tab1ValidationGrp);
        }
        return isSelected;
    }
    private void reBindDocumentGrid(List<DocumentDTO> documentList, DocumentDTO documentDTO)
    {
        if (documentList != null)
        {
            assignUiIndexToDocument(documentList);
            documentGrid.DataSource = documentList;
            documentGrid.DataBind();
            if (documentDTO != null) resetDocumentSelection(documentDTO.UiIndex);
        }
    }
    private void assignUiIndexToDocument(List<DocumentDTO> documentDtos)
    {
        if (documentDtos != null && documentDtos.Count > 0)
        {
            documentDtos.ForEach(c => c.isUISelected = false);
            long uiIndex = 1;
            foreach (DocumentDTO documentDto in documentDtos)
            {
                documentDto.UiIndex = uiIndex++;
                documentDto.RowInfo = CommonUIConverter.getGridViewRowInfo(documentDto);
            }
        }
    }
    private void loadDocumentGrid()
    {
        try
        {
            List<DocumentDTO> results = new List<DocumentDTO>();
            if (!(string.IsNullOrWhiteSpace(drpDocumentOwner.Text) || string.IsNullOrWhiteSpace(drpSearchByValue.Text)))
            {
                long id = long.Parse(drpSearchByValue.Text);
                DocumentOwner searchBy = EnumHelper.ToEnum<DocumentOwner>(drpDocumentOwner.Text);
                if (DocumentOwner.CUSTOMER_NAME == searchBy)
                {
                    CustomerBO customerBO = new CustomerBO();
                    CustomerDTO  customerDTO  = customerBO.fetchCustomer(id);
                    ViewState[VS_CUSTOMER] = customerDTO;
                    if (customerDTO.DocumentInfo != null)
                    {
                        results = customerDTO.DocumentInfo.Documents.ToList();
                    }
                }
                if (DocumentOwner.PROPERTY_NAME == searchBy)
                {
                    PropertyBO propertyBO = new PropertyBO();
                    PropertyDTO propertyDTO = propertyBO.fetchProperty(id);
                    ViewState[VS_PROPERTY] = propertyDTO;
                    if (propertyDTO.DocumentInfo != null)
                    {
                        results = propertyDTO.DocumentInfo.Documents.ToList();
                    }
                }
                assignUiIndexToDocument(results);
            }
            
            documentGrid.DataSource = results;
            documentGrid.DataBind();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }

    protected void onSelectDocumentOwner(object sender, EventArgs e)
    {
        try
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            DocumentOwner searchBy = EnumHelper.ToEnum<DocumentOwner>(drpDocumentOwner.Text);
            drpSearchByValue.Visible = true;
            lbSearchByValue.Visible = true;
            lbSearchByValue.Text = EnumHelper.GetEnumDescription<DocumentOwner>(searchBy.ToString());
            if (DocumentOwner.PROPERTY_NAME == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.PROPERTY_NAME, userDefDto.Id.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else if (DocumentOwner.CUSTOMER_NAME == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.CUSTOMER_SEARCH_BY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else if (DocumentOwner.EMPLOYEE_NAME == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.EMPLOYEE_SEARCH_BY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else if (DocumentOwner.CONTACTOR_NAME == searchBy)
            {
                //TODO Add Logic to populate CONTACTOR_NAME
            }
            else if (DocumentOwner.SUPPLIER_NAME == searchBy)
            {
                //TODO Add Logic to populate SUPPLIER_NAME
            }
            else
            {
                drpSearchByValue.ClearSelection();
                drpSearchByValue.Visible = false;
                lbSearchByValue.Visible = false;
            }
            //TO DO loadPropertyScheduleGrid();
            resetPageInfo(DocumentPageMode.NONE);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSearchByValue(object sender, EventArgs e)
    {
        try
        {
            if (!string.IsNullOrWhiteSpace(drpSearchByValue.Text))
            {
                resetPageInfo(DocumentPageMode.ADD);
                loadDocumentGrid();
            }
            else
            {
                resetPageInfo(DocumentPageMode.NONE);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSelectDocument(object sender, EventArgs e)
    {
        try
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            pnlDocumentAdd.Visible = false;
            if (rd.Checked)
            {
                long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnDocumentRowIdentifier"))).Attributes["row-identifier"]);
                setSelectedDocument(UiIndex);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickAddDocumentBtn(object sender, EventArgs e)
    {
        try
        {
            resetDocumentSelection(-1);
            initDocumentAddUpdateSection(true);
            initDocumentSectionFields(null);
            SetFocus(txtDocumentName);
            scrollToFieldHdn.Value = pnlDocumentAdd.ID;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickDownloadDocumentBtn(object sender, EventArgs e)
    {
        try
        {
            if (validateDocumentSelected())
            {
                DocumentDTO documentDTO = getSelectedDocument();
                registerPostBackControl();
                Response.Buffer = true;
                Response.Charset = "";
                Response.Cache.SetCacheability(HttpCacheability.NoCache);
                Response.ContentType = documentDTO.ContentType;
                Response.AppendHeader("Content-Disposition", "attachment; filename=" + documentDTO.FileName);
                Response.BinaryWrite(documentDTO.Content);
                Response.Flush();
                //Response.End();
                UpdatePanel1.Update();
                initBootstrapComponantsFromServer();
             }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private void registerPostBackControl()
    {
        ScriptManager.GetCurrent(this).RegisterPostBackControl(deleteDocumentBtn);
    }

    protected void deleteDocument(object sender, EventArgs e)
    {
        try
        {
            if (validateDocumentSelected())
            {
                DocumentOwner searchBy = EnumHelper.ToEnum<DocumentOwner>(drpDocumentOwner.Text);
                if (DocumentOwner.CUSTOMER_NAME == searchBy)
                {
                    CustomerDTO customerDTO = getCurrentCustomer();
                    DocumentDTO DocumentDto = getSelectedDocument();
                    customerDTO.DocumentInfo.Documents.Remove(DocumentDto);
                }
                if (DocumentOwner.PROPERTY_NAME == searchBy)
                {
                    PropertyDTO propertyDTO = getCurrentProperty();
                    DocumentDTO DocumentDto = getSelectedDocument();
                    propertyDTO.DocumentInfo.Documents.Remove(DocumentDto);
                }
               List<DocumentDTO> documentList = getDocumentList();
                reBindDocumentGrid(documentList, null);
                setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, "Document"));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void addNewDocument(object sender, EventArgs e)
    {
        try
        {
            if (validateDocument())
            {
                DocumentDTO documentDto = populateDocumentDTOAddFromUI();
                DocumentOwner searchBy = EnumHelper.ToEnum<DocumentOwner>(drpDocumentOwner.Text);
                List<DocumentDTO> documentList = new List<DocumentDTO>();
                if (DocumentOwner.CUSTOMER_NAME == searchBy)
                {
                    CustomerDTO customerDto = getCurrentCustomer();
                    if (customerDto.DocumentInfo == null) {
                        DocumentInfoDTO documentInfoDTO = new DocumentInfoDTO();
                        customerDto.DocumentInfo = documentInfoDTO;
                        customerDto.DocumentInfo.Documents = new HashSet<DocumentDTO>();
                    }
                    customerDto.DocumentInfo.Documents.Add(documentDto);
                    documentList = customerDto.DocumentInfo.Documents.ToList();
                }

                if (DocumentOwner.PROPERTY_NAME == searchBy)
                {
                    PropertyDTO propertyDTO = getCurrentProperty();
                    if (propertyDTO.DocumentInfo == null)
                    {
                        DocumentInfoDTO documentInfoDTO = new DocumentInfoDTO();
                        propertyDTO.DocumentInfo = documentInfoDTO;
                        propertyDTO.DocumentInfo.Documents = new HashSet<DocumentDTO>();
                    }
                    propertyDTO.DocumentInfo.Documents.Add(documentDto);
                    documentList = propertyDTO.DocumentInfo.Documents.ToList();
                }
                pnlDocumentAdd.Visible = false;
                reBindDocumentGrid(documentList, documentDto);
                setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, "Document"));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }

    protected void cancelDocument(object sender, EventArgs e)
    {
        pnlDocumentAdd.Visible = false;
        resetDocumentSelection(-1);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    protected void saveDocumentToDB(object sender, EventArgs e)
    {
        try
        {
            DocumentOwner searchBy = EnumHelper.ToEnum<DocumentOwner>(drpDocumentOwner.Text);
            List<DocumentDTO> documentList = new List<DocumentDTO>();
            if (DocumentOwner.CUSTOMER_NAME == searchBy)
            {
                CustomerBO customerBO = new CustomerBO();
                customerBO.updateCustomer(getCurrentCustomer());
            }
            if (DocumentOwner.PROPERTY_NAME == searchBy)
            {
                PropertyBO propertyBO = new PropertyBO();
                propertyBO.updateProperty(getCurrentProperty());
            }
            pnlDocumentAdd.Visible = false;
            loadDocumentGrid();
            setSuccessMessage(Resources.Messages.success_document_uploaded);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private DocumentDTO populateDocumentDTOAddFromUI()
    {
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        DocumentDTO documentDTO = new DocumentDTO();
        documentDTO.Name = txtDocumentName.Text;
        documentDTO.DocumentType = CommonUIConverter.getMasterControlDTO(drpDocumentType.Text, drpDocumentType.SelectedItem.Text);
        HttpFileCollection uploadedFiles = Request.Files;
        for (int i = 0; i < uploadedFiles.Count; i++)
            {
                HttpPostedFile userPostedFile = uploadedFiles[i];
                if (userPostedFile.ContentLength > 0)
                {
                    string filename = Path.GetFileName(userPostedFile.FileName);
                    string extension = Path.GetExtension(filename);
                    string contentType = fileUpload.PostedFile.ContentType;
                    HttpPostedFile file = fileUpload.PostedFile;
                    byte[] document = new byte[file.ContentLength];
                    file.InputStream.Read(document, 0, file.ContentLength);
                    documentDTO.Content = document;
                    documentDTO.FileName = filename;
                    documentDTO.Extension = extension;
                    documentDTO.ContentType = contentType;
                }
            }
        documentDTO.Description = txtDescription.Text;
        documentDTO.FirmNumber = userDef.FirmNumber;
        documentDTO.InsertUser = userDef.Username;
        documentDTO.UpdateUser = userDef.Username;
        documentDTO.InsertDate = DateTime.Now;
        documentDTO.UpdateDate = DateTime.Now;
        return documentDTO;
    }
    
    private bool validateDocument()
    {
        bool isValid = true;
        Page.Validate(tab1ValidationGrp);
        isValid = Page.IsValid;
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    protected void saveModalData(object sender, EventArgs e)
    {
        String errorMsg = "";
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        if (modalHdnType.Value == "DOCUMENTTYPE")
        {
            MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.DOCUMENT_TYPE, modalInput1.Text,
                   modalInput2.Text, userDefDto);
            errorMsg = validateMasterDataModalInput(masterDataDto, "DOCUMENTTYPE");
            if (string.IsNullOrWhiteSpace(errorMsg))
            {
                masterDataBO.saveMasterData(masterDataDto);
                drpBO.drpDataBase(drpDocumentType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.DOCUMENT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                modalIdentifierHdn.Value = "";
            }
        }
        if (!string.IsNullOrWhiteSpace(errorMsg))
        {
            modalErrorMsg.Value = errorMsg;
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "setModalErrorMsg", "setModalErrorMsg()", true);
        }
        else
        {
            //Reset the modal fields
            modalInput1.Text = "";
            modalInput2.Text = "";
            modalHdnType.Value = "";
            modalActionHdn.Value = "";
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "closeDialogClient", "closeDialogClient()", true);
        }
    }
    private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
    {
        string errorMsg = "";
        if (string.IsNullOrWhiteSpace(masterDataDto.Name))
        {
            errorMsg = Resources.Messages.validate_documenttype_required;
        }
        else if (masterDataBO.isAlreadyExist(masterDataDto))
        {
            errorMsg = string.Format(Resources.Messages.validation_same_name_exist, type);
        }
        return errorMsg;
    }
}
