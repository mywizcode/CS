﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Vladsm.Web.UI.WebControls;

namespace ConstroSoft.pages.CustomerManagement
{
    public partial class ManageCustomer : System.Web.UI.Page
    {
        private static readonly log4net.ILog log =
              log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string tab1ValidationGrp = "tab1Error";
        string tab2ValidationGrp = "tab2Error";
        string VS_CUSTOMER_LIST = "CUSTOMER_LIST";
        string VS_SELECTED_CUSTOMER = "SELECTED_CUSTOMER";
        DropdownBO drpBO = new DropdownBO();
        CustomerBO customerBO = new CustomerBO();
        MasterDataBO masterDataBO = new MasterDataBO();
        EmployeeBO firmMemberBO = new EmployeeBO();
        public enum CustomerPageMode { ADD, MODIFY, VIEW, NONE }
        protected void Page_Load(object sender, EventArgs e)
        {
            clearMessages();
            if (!IsPostBack)
            {
                if (CommonUtil.isSessionActive(Session))
                {
                    resetTabInfo(CustomerPageMode.NONE);
                    initDropdowns();
                    loadSearchGridAndReSelect(0);
                    Page.MaintainScrollPositionOnPostBack = false;
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
        }
        private void initDropdowns()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            drpBO.drpDataBase(drpSalutation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.SALUTATION, null, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpOccupation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.OCCUPATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpEnum<CustomerSearchBy>(drpSearchBy, null);
            drpBO.drpEnum<Gender>(drpGender, Constants.SELECT_ITEM);
            drpBO.drpEnum<MaritalStatus>(drpMaritalStatus, Constants.SELECT_ITEM);
            drpBO.drpDataBase(drpAddressCountry, DrpDataType.COUNTRY, null, null, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpAddressState, DrpDataType.STATE, Constants.DEFAULT_COUNTRY, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            initCityDrp(drpAddressCity, Constants.DEFAULT_STATE);
            drpBO.drpDataBase(drpAddressType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ADDRESS_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpEnum<PreferredAddress>(drpPreferredAddress, null);
        }
        /**
         * This method is called just before the page is rendered. So any change in state of the element is applied.
         **/
        protected void Page_PreRender(object sender, EventArgs e)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                applyEntitlement();
                preRenderInitFormElements();
                initBootstrapComponantsFromServer();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        private void applyEntitlement()
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            addCustomerBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.CUSTOMER_ADD);
            modifyCustomerBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.CUSTOMER_MODIFY);
            deleteCustomerBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.CUSTOMER_DELETE);
        }
        private void preRenderInitFormElements()
        {
            CustomerDTO selectedCustomer = getCurrentCustomer();
            jumpToCustHdnId.Value = null;
            jumpToAddressHdnId.Value = null;
            if (selectedCustomer != null)
            {
                jumpToCustHdnId.Value = selectedCustomer.Id.ToString();
                List<AddressDTO> addressList = selectedCustomer.ContactInfo.Addresses.ToList<AddressDTO>();
                if (addressList != null && addressList.Count > 0)
                {
                    AddressDTO selectedAddress = addressList.Find(a => a.isUISelected);
                    if (selectedAddress != null) jumpToAddressHdnId.Value = selectedAddress.UiIndex.ToString();
                }
            }
        }
        public void setErrorMessage(string message, string group)
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            this.Page.Validators.Add(val);
        }
        public void setSuccessMessage(string msg, string tabId)
        {
            activeTabHdn.Value = tabId;
            if (tabId.Equals(tab1Anchor.ID))
            {
                lbTab1Success.Text = msg;
                tab1SuccessPanel.Visible = true;
            }
            else if (tabId.Equals(tab2Anchor.ID))
            {
                lbTab2Success.Text = msg;
                tab2SuccessPanel.Visible = true;
            }
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        public void initBootstrapComponantsFromServer()
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
        }
        private void clearMessages()
        {
            tab1SuccessPanel.Visible = false;
            lbTab1Success.Text = "";
            tab2SuccessPanel.Visible = false;
            lbTab2Success.Text = "";
        }
        private UserDefinitionDTO getUserDefinitionDTO()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }

        private void resetTabInfo(CustomerPageMode pageMode)
        {
            tab2Anchor.Visible = true;
            activeTabHdn.Value = tab2Anchor.ID;
            pageModeHdn.Value = pageMode.ToString();
            initFormFields();
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            pnlAddressAdd.Visible = false;
            txtCustomerRefNo.Visible = false;
            lblCustomerRefNo.Visible = false;
            if (CustomerPageMode.ADD == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.empm_sm_manage_cust_tab2_add_name;
                initFormFields();
            }
            else if (CustomerPageMode.MODIFY == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.empm_sm_manage_cust_tab2_update_name;
                txtCustomerRefNo.Visible = true;
                lblCustomerRefNo.Visible = true;
                initFormFields();
            }
            else if (CustomerPageMode.VIEW == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.empm_sm_manage_cust_tab2_view_name;
                txtCustomerRefNo.Visible = true;
                lblCustomerRefNo.Visible = true;
                initFormFields();
            }
            else
            {
                activeTabHdn.Value = tab1Anchor.ID;
                tab2Anchor.Visible = false;
                ViewState[VS_SELECTED_CUSTOMER] = null;
            }
        }
        private void initFormFields()
        {
            bool isReadOnly = (CustomerPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            bool visible = !(CustomerPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            //Buttons
            // addOccupationBtn.Visible = visible;            
            addressBtnGrp.Visible = visible;
            addressGrid.Columns[0].Visible = visible;
        }
        private CustomerDTO getCurrentCustomer()
        {
            return (CustomerDTO)ViewState[VS_SELECTED_CUSTOMER];
        }
        private void setSelectedCustomer(long selectedId)
        {
            List<CustomerDTO> customerList = (List<CustomerDTO>)ViewState[VS_CUSTOMER_LIST];
            if (customerList != null)
            {
                customerList.ForEach(c => c.isUISelected = false);
                customerList.Find(c => c.Id == selectedId).isUISelected = true;
            }
        }
        private bool validateCustomerSelected()
        {
            bool isSelected = true;
            List<CustomerDTO> customerList = (List<CustomerDTO>)ViewState[VS_CUSTOMER_LIST];
            if (customerList != null)
            {
                isSelected = customerList.Any(c => c.isUISelected);
                if (!isSelected)
                {
                    resetTabInfo(CustomerPageMode.NONE);
                    setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Customer"), tab1ValidationGrp);
                }
            }
            return isSelected;
        }
        private void selectCustomerGridRdBtn(long Id)
        {
            if (customerGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in customerGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdCustomerSelect");
                    Button rowIdenBtn = (Button)row.FindControl("btnCustRowIdentifier");
                    if (radioBtn != null)
                    {
                        radioBtn.Checked = false;
                        if (rowIdenBtn != null && Id > 0 && Id.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                        {
                            radioBtn.Checked = true;
                        }
                    }
                }
            }
        }
        private void loadSearchGridAndReSelect(long Id)
        {
            try
            {
                CustomerSearchBy searchBy = EnumHelper.ToEnum<CustomerSearchBy>(drpSearchBy.Text);
                long searchByValId = -1;
                if (!string.IsNullOrWhiteSpace(drpSearchByValue.Text)) searchByValId = long.Parse(drpSearchByValue.Text);
                IList<CustomerDTO> results = customerBO.fetchCustomerGridData(getUserDefinitionDTO().FirmNumber, searchBy, searchByValId);
                ViewState[VS_CUSTOMER_LIST] = results;
                customerGrid.DataSource = results;
                customerGrid.DataBind();
                if (Id > 0)
                {
                    selectCustomerGridRdBtn(Id);
                    setSelectedCustomer(Id);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void fetchSelectedCustomer()
        {
            try
            {
                CustomerDTO customerDto = null;
                if (CustomerPageMode.ADD.ToString().Equals(pageModeHdn.Value))
                {
                    customerDto = populateCustomerDTOAdd();
                    selectCustomerGridRdBtn(0);
                }
                else if (CustomerPageMode.MODIFY.ToString().Equals(pageModeHdn.Value) || CustomerPageMode.VIEW.ToString().Equals(pageModeHdn.Value))
                {
                    long Id = ((List<CustomerDTO>)ViewState[VS_CUSTOMER_LIST]).Find(c => c.isUISelected).Id;
                    customerDto = customerBO.fetchCustomer(Id);
                }
                ViewState[VS_SELECTED_CUSTOMER] = customerDto;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void doViewModifyAction(CustomerPageMode pageMode)
        {
            resetTabInfo(pageMode);
            fetchSelectedCustomer();
            populateUIFieldsFromDTO((CustomerDTO)ViewState[VS_SELECTED_CUSTOMER]);
        }
        protected void onSearchBy(object sender, EventArgs e)
        {
            try
            {
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                CustomerSearchBy searchBy = EnumHelper.ToEnum<CustomerSearchBy>(drpSearchBy.Text);
                drpSearchByValue.Visible = true;
                lbSearchByValue.Visible = true;
                lbSearchByValue.Text = EnumHelper.GetEnumDescription<CustomerSearchBy>(searchBy.ToString());
                if (CustomerSearchBy.Customer_Name == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.CUSTOMER_SEARCH_BY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }

                else
                {
                    drpSearchByValue.ClearSelection();
                    drpSearchByValue.Visible = false;
                    lbSearchByValue.Visible = false;
                }
                loadSearchGridAndReSelect(0);
                resetTabInfo(CustomerPageMode.NONE);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onSearchByValue(object sender, EventArgs e)
        {
            loadSearchGridAndReSelect(0);
            resetTabInfo(CustomerPageMode.NONE);
        }
        protected void selectCustomer(object sender, EventArgs e)
        {
            try
            {
                GroupRadioButton rd = (GroupRadioButton)sender;
                resetTabInfo(CustomerPageMode.NONE);
                if (rd.Checked)
                {
                    string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnCustRowIdentifier"))).Attributes["row-identifier"];
                    setSelectedCustomer(long.Parse(strId));
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        /*
         * This method is called on click of ADD button in datatable top bar.
         */
        protected void onClickAddCustomerBtn(object sender, EventArgs e)
        {
            try
            {
                resetTabInfo(CustomerPageMode.ADD);
                fetchSelectedCustomer();
                populateUIFieldsFromDTO(null);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickViewCustomerBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateCustomerSelected())
                {
                    doViewModifyAction(CustomerPageMode.VIEW);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        protected void onClickModifyCustomerBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateCustomerSelected())
                {
                    doViewModifyAction(CustomerPageMode.MODIFY);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        protected void deleteCustomer(object sender, EventArgs e)
        {
            try
            {
                if (validateCustomerSelected())
                {
                    long Id = ((List<CustomerDTO>)ViewState[VS_CUSTOMER_LIST]).Find(c => c.isUISelected).Id;
                    customerBO.deleteCustomer(Id);
                    loadSearchGridAndReSelect(0);
                    resetTabInfo(CustomerPageMode.NONE);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_delete, "Customer"), tab1Anchor.ID);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        protected void addOrModifyCustomer(object sender, EventArgs e)
        {
            try
            {
                if (validateCustomer())
                {
                    CustomerDTO customerDto = getCurrentCustomer();
                    long Id = customerDto.Id;
                    populateCustomerDTOFromUI(customerDto);
                    if (CustomerPageMode.ADD.ToString().Equals(pageModeHdn.Value))
                    {
                        Id = customerBO.saveCustomer(customerDto);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_add, "Customer"), tab1Anchor.ID);
                    }
                    else if (CustomerPageMode.MODIFY.ToString().Equals(pageModeHdn.Value))
                    {
                        customerBO.updateCustomer(customerDto);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_update, "Customer"), tab1Anchor.ID);
                    }
                    resetTabInfo(CustomerPageMode.NONE);
                    loadSearchGridAndReSelect(Id);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        private bool validateCustomer()
        {
            bool isValid = true;
            Page.Validate("tab2Error");
            isValid = Page.IsValid;
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        protected void cancelCustomer(object sender, EventArgs e)
        {
            CustomerDTO customerDto = getCurrentCustomer();
            resetTabInfo(CustomerPageMode.NONE);
            loadSearchGridAndReSelect(customerDto.Id);
        }
        private CustomerDTO populateCustomerDTOAdd()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            CustomerDTO customerDto = new CustomerDTO();
            customerDto.ContactInfo = new ContactInfoDTO();
            customerDto.ContactInfo.Addresses = new HashSet<AddressDTO>();
            customerDto.DocumentInfo = new DocumentInfoDTO();
            customerDto.FirmNumber = userDefDto.FirmNumber;
            customerDto.InsertUser = userDefDto.Username;
            return customerDto;
        }
        private void populateCustomerDTOFromUI(CustomerDTO customerDto)
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            customerDto.Salutation = CommonUIConverter.getMasterControlDTO(drpSalutation.Text, null);
            customerDto.FirstName = txtFirstName.Text;
            customerDto.MiddleName = txtMiddleName.Text;
            customerDto.LastName = txtLastName.Text;
            customerDto.Occupation = CommonUIConverter.getMasterControlDTO(drpOccupation.Text, null);
            customerDto.Pan = txtPan.Text;
            customerDto.ContactInfo.Gender = EnumHelper.ToEnumNullable<Gender>(drpGender.Text);
            if (!string.IsNullOrWhiteSpace(txtDOB.Text)) 
                customerDto.ContactInfo.Dob = DateTime.ParseExact(txtDOB.Text, Constants.DATE_FORMAT, CultureInfo.InvariantCulture); 
            else customerDto.ContactInfo.Dob = null;
            customerDto.ContactInfo.MaritalStatus = EnumHelper.ToEnumNullable<MaritalStatus>(drpMaritalStatus.Text);
            customerDto.ContactInfo.Contact = txtContact.Text;
            customerDto.ContactInfo.AltContact = txtAltContact.Text;
            customerDto.ContactInfo.Email = txtEmail.Text;
            customerDto.ContactInfo.AltEmail = txtAltEmailID.Text;
            customerDto.CustRefNo = txtCustomerRefNo.Text;
            customerDto.UpdateUser = userDefDto.Username;
            customerDto.Version = userDefDto.Version;
        }
        private void populateUIFieldsFromDTO(CustomerDTO customerDto)
        {
            if (customerDto != null && customerDto.Salutation != null) drpSalutation.Text = customerDto.Salutation.Id.ToString(); else drpSalutation.ClearSelection();
            if (customerDto != null) txtFirstName.Text = customerDto.FirstName; else txtFirstName.Text = null;
            if (customerDto != null) txtMiddleName.Text = customerDto.MiddleName; else txtMiddleName.Text = null;
            if (customerDto != null) txtLastName.Text = customerDto.LastName; else txtLastName.Text = null;
            if (customerDto != null && customerDto.ContactInfo.Gender != null) drpGender.Text = customerDto.ContactInfo.Gender.ToString(); else drpGender.ClearSelection();
            if (customerDto != null && customerDto.ContactInfo.Dob != null) txtDOB.Text = customerDto.ContactInfo.Dob.Value.ToString(Constants.DATE_FORMAT); else txtDOB.Text = null;
            if (customerDto != null && customerDto.ContactInfo.MaritalStatus != null) drpMaritalStatus.Text = customerDto.ContactInfo.MaritalStatus.ToString(); else drpMaritalStatus.ClearSelection();
            if (customerDto != null) txtContact.Text = customerDto.ContactInfo.Contact; else txtContact.Text = null;
            if (customerDto != null) txtAltContact.Text = customerDto.ContactInfo.AltContact; else txtAltContact.Text = null;
            if (customerDto != null) txtEmail.Text = customerDto.ContactInfo.Email; else txtEmail.Text = null;
            if (customerDto != null) txtAltEmailID.Text = customerDto.ContactInfo.AltEmail; else txtAltEmailID.Text = null;
            if (customerDto != null) txtPan.Text = customerDto.Pan; else txtPan.Text = null;
            if (customerDto != null) txtCustomerRefNo.Text = customerDto.CustRefNo; else txtCustomerRefNo.Text = null;
            if (customerDto != null && customerDto.Occupation != null) drpOccupation.Text = customerDto.Occupation.Id.ToString(); else drpOccupation.ClearSelection();
            populateAddressGrid(customerDto);
        }
        private void populateAddressGrid(CustomerDTO customerDto)
        {
            addressGrid.DataSource = new List<AddressDTO>();
            if (customerDto != null)
            {
                assignUiIndexToAddress(customerDto.ContactInfo.Addresses);
                addressGrid.DataSource = customerDto.ContactInfo.Addresses;
            }
            addressGrid.DataBind();
        }

        private void assignUiIndexToAddress(ISet<AddressDTO> addressDtos)
        {
            if (addressDtos != null && addressDtos.Count > 0)
            {
                long uiIndex = 1;
                foreach (AddressDTO addressDto in addressDtos)
                {
                    addressDto.UiIndex = uiIndex++;
                    addressDto.RowInfo = CommonUIConverter.getGridViewRowInfo(addressDto);
                }
            }
        }
        protected void saveModalData(object sender, EventArgs e)
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (modalHdnType.Value == "OCCUPATION")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.OCCUPATION, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "OCCUPATION");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpOccupation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.OCCUPATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                modalErrorMsg.Value = errorMsg;
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "setModalErrorMsg", "setModalErrorMsg()", true);
            }
            else
            {
                //Reset the modal fields
                modalInput1.Text = "";
                modalInput2.Text = "";
                modalHdnType.Value = "";
                modalActionHdn.Value = "";
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "closeDialogClient", "closeDialogClient()", true);
            }
        }

        private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
        {
            string errorMsg = "";
            if (string.IsNullOrWhiteSpace(masterDataDto.Name))
            {
                errorMsg = Resources.Messages.validation_designationname_required;
            }
            else if (masterDataBO.isAlreadyExist(masterDataDto))
            {
                errorMsg = string.Format(Resources.Messages.validation_same_name_exist, type);
            }
            return errorMsg;
        }
        //Address Table actions - Start
        private void initAddressAddUpdateSection(bool isAdd)
        {
            lbAddUpdateSectionHeader.Text = (isAdd) ? Resources.Labels.label_sectionheader_add_address : Resources.Labels.label_sectionheader_modify_address;
            pnlAddressAdd.Visible = true;
            btnAddressAddToGrid.Visible = isAdd;
            btnAddressUpdateToGrid.Visible = !isAdd;
            drpAddressState.Text = Constants.DEFAULT_STATE;
        }
        private void setDefaultOnAddAddress()
        {
            drpAddressState.Text = Constants.DEFAULT_STATE;
            drpPreferredAddress.Text = PreferredAddress.No.ToString();
        }
        private void initAddressSectionFields(AddressDTO addressDto)
        {
            if (addressDto != null) txtAddressLine1.Text = addressDto.AddressLine1; else txtAddressLine1.Text = null;
            if (addressDto != null) txtAddressLine2.Text = addressDto.AddressLine2; else txtAddressLine2.Text = null;
            if (addressDto != null) txtTown.Text = addressDto.Town; else txtTown.Text = null;
            if (addressDto != null && addressDto.City != null) drpAddressCity.Text = addressDto.City.Id.ToString(); else drpAddressCity.ClearSelection();
            if (addressDto != null && addressDto.State != null) drpAddressState.Text = addressDto.State.Id.ToString(); else drpAddressState.ClearSelection();
            if (addressDto != null && addressDto.Country != null) drpAddressCountry.Text = addressDto.Country.Id.ToString(); else drpAddressCountry.ClearSelection();
            if (addressDto != null) txtPin.Text = addressDto.Pin; else txtPin.Text = null;
            if (addressDto != null && addressDto.AddressType != null) drpAddressType.Text = addressDto.AddressType.Id.ToString(); else drpAddressType.ClearSelection();
            if (addressDto != null && addressDto.PreferredAddress != null) drpPreferredAddress.Text = addressDto.PreferredAddress.ToString(); else drpPreferredAddress.ClearSelection();
        }
        private void clearAddressViewState()
        {
            if (addressGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in addressGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdAddressSelect");
                    if (radioBtn != null) radioBtn.Checked = false;
                }
            }
            getCurrentCustomer().ContactInfo.Addresses.ToList<AddressDTO>().ForEach(c => c.isUISelected = false);
        }
        private AddressDTO getSelectedAddress()
        {
            return getCurrentCustomer().ContactInfo.Addresses.ToList<AddressDTO>().Find(c => c.isUISelected);
        }
        private void initCityDrp(DropDownList drp, string stateId)
        {
            drpBO.drpDataBase(drp, DrpDataType.CITY, stateId, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
        }
        private bool validateAddressSelected()
        {
            bool isSelected = true;
            AddressDTO addressDto = getSelectedAddress();
            if (addressDto == null)
            {
                isSelected = false;
                pnlAddressAdd.Visible = false;
                clearAddressViewState();
                setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Address"), tab2ValidationGrp);
            }
            return isSelected;
        }

        private void populateAddressFromUI(AddressDTO addressDto)
        {
            addressDto.AddressLine1 = txtAddressLine1.Text;
            addressDto.AddressLine2 = txtAddressLine2.Text;
            addressDto.Town = txtTown.Text;
            addressDto.City = CommonUIConverter.getCityDTO(drpAddressCity.Text, drpAddressCity.SelectedItem.Text);
            addressDto.State = CommonUIConverter.getStateDTO(drpAddressState.Text, drpAddressState.SelectedItem.Text);
            addressDto.Country = CommonUIConverter.getCountryDTO(drpAddressCountry.Text, drpAddressCountry.SelectedItem.Text);
            addressDto.Pin = txtPin.Text;
            addressDto.AddressType = CommonUIConverter.getMasterControlDTO(drpAddressType.Text, drpAddressType.SelectedItem.Text);
            addressDto.PreferredAddress = EnumHelper.ToEnumNullable<PreferredAddress>(drpPreferredAddress.Text);
        }
        protected void loadCities(object sender, EventArgs e)
        {
            initCityDrp(drpAddressCity, drpAddressState.Text);
            SetFocus(drpAddressCity);
        }
        protected void selectAddress(object sender, EventArgs e)
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            pnlAddressAdd.Visible = false;
            if (rd.Checked)
            {
                long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnAddressRowIdentifier"))).Attributes["row-identifier"]);
                List<AddressDTO> addressList = getCurrentCustomer().ContactInfo.Addresses.ToList<AddressDTO>();
                addressList.ForEach(c => c.isUISelected = false);
                addressList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
            }
        }
        protected void onClickAddAddressBtn(object sender, EventArgs e)
        {
            try
            {
                initAddressAddUpdateSection(true);
                initAddressSectionFields(null);
                setDefaultOnAddAddress();
                SetFocus(txtAddressLine1);
                scrollToFieldHdn.Value = pnlAddressAdd.ID;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void onClickModifyAddressBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateAddressSelected())
                {
                    initAddressAddUpdateSection(false);
                    initAddressSectionFields(getSelectedAddress());
                    SetFocus(txtAddressLine1);
                    scrollToFieldHdn.Value = pnlAddressAdd.ID;
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void deleteAddress(object sender, EventArgs e)
        {
            try
            {
                if (validateAddressSelected())
                {
                    CustomerDTO customerDto = getCurrentCustomer();
                    AddressDTO addressDto = getSelectedAddress();
                    customerDto.ContactInfo.Addresses.Remove(addressDto);
                    pnlAddressAdd.Visible = false;
                    clearAddressViewState();
                    populateAddressGrid(customerDto);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, "Address"), tab2Anchor.ID);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void addNewAddress(object sender, EventArgs e)
        {
            try
            {
                if (validateAddress())
                {
                    CustomerDTO customerDto = getCurrentCustomer();
                    AddressDTO addressDto = new AddressDTO();
                    populateAddressFromUI(addressDto);
                    customerDto.ContactInfo.Addresses.Add(addressDto);
                    pnlAddressAdd.Visible = false;
                    clearAddressViewState();
                    populateAddressGrid(customerDto);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, "Address"), tab2Anchor.ID);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void updateAddress(object sender, EventArgs e)
        {
            try
            {
                if (validateAddress())
                {
                    CustomerDTO customerDto = getCurrentCustomer();
                    AddressDTO addressDto = getSelectedAddress();
                    populateAddressFromUI(addressDto);
                    pnlAddressAdd.Visible = false;
                    clearAddressViewState();
                    populateAddressGrid(customerDto);
                    setSuccessMessage(string.Format(Resources.Messages.success_record_updatedtotable, "Address"), tab2Anchor.ID);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        protected void cancelAddress(object sender, EventArgs e)
        {
            pnlAddressAdd.Visible = false;
            clearAddressViewState();
        }
        private bool validateAddress()
        {
            bool isValid = true;
            Page.Validate("tab2ErrorGrid1");
            isValid = Page.IsValid;
            if (drpPreferredAddress.Text.Equals(PreferredAddress.Yes.ToString()) && isValid)
            {
                List<AddressDTO> addressList = getCurrentCustomer().ContactInfo.Addresses.ToList<AddressDTO>();
                bool isPreferred = addressList.Any(c => (c.PreferredAddress == PreferredAddress.Yes && !c.isUISelected));
                if (isPreferred)
                {
                    isValid = false;
                    setErrorMessage(Resources.Messages.validation_address_one_preferred, tab2ValidationGrp);
                }
            }
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        //Address Table actions - END
    }
}