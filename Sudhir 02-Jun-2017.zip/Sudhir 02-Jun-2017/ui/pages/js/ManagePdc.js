$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initPdcSearchGrid();
    initPdcPymtGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("tab2Content");
    //This script will enable tabs which was last active even after postback call.
    enableTab(false);
    var isModify = ($("[id$='pageModeHdn']").val() == 'MODIFY');
    if (isModify) makeReadOnlySection("pnlChqDrawerAndPayee");
}

function initPdcPymtGrid() {
    var pymtDirection = $("[id$='pymtDirectionHdn']").val();
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    if (pymtDirection) {
        if ("CUSTOMER_FIRM" == pymtDirection || "FIRM_CUSTOMER" == pymtDirection) {
            var dtOptions = {
                tableId: "pdcPymtGrid",
                pageLength: 5,
                isViewOnly: isViewOnly,
                responsiveModalTitle: "Payment Transaction Details",
                customBtnGrpId: "#pdcPaymentBtnDiv",
                hideSearch: true
            };
            var dtTable = applyDataTable(dtOptions);
            jumpToTablePage(dtTable, "jumpToPdcPaymentHdnId");
        } else if ("FIRM_AGENCY" == pymtDirection) {
            var dtOptions = {
                tableId: "pdcAgencyPymtGrid",
                pageLength: 5,
                isViewOnly: isViewOnly,
                responsiveModalTitle: "Payment Transaction Details",
                customBtnGrpId: "#pdcPaymentBtnDiv",
                hideSearch: true
            };
            var dtTable = applyDataTable(dtOptions);
            jumpToTablePage(dtTable, "jumpToPdcPaymentHdnId");
        }
    }
}

function initPdcSearchGrid() {
    var dtOptions = {
        tableId: "pdcGrid",
        pageLength: 10,
        isViewOnly: false,
        customBtnGrpId: "#pdcSearchBtnDiv",
        hideSearch: false
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPdcHdnId");
}