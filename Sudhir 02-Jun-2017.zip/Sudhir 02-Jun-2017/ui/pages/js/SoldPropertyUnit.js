﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initSoldeUnitsGrid();
    initTaxGrid();
    initCMTaxGrid();
    initCoCustomerGrid();
    initPaymentGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("tab2Content");
    //This script will enable tabs which was last active even after postback call.
    enableTab(true);
    makeReadOnlySection("pnlTab2UnitInfo");
    var isCancelBooking = ($("[id$='pageModeHdn']").val() == 'CANCEL_BOOKING');
    if (isCancelBooking) {
        makeReadOnlySection("pnlTab3UnitInfo");
        initCancelInfoPymtGrid();
    }
    var isModifyLimitedMode = $("[id$='pageModeHdn']").val() == 'MODIFY_LIMITTED';
    if (isModifyLimitedMode) {
        makeReadOnlySection("pnlTab2BzStep1");
    }
    var isSoldUnitViewModifyMode = $("[id$='pageModeHdn']").val() == 'MODIFY_LIMITTED' || $("[id$='pageModeHdn']").val() == 'MODIFY' || $("[id$='pageModeHdn']").val() == 'VIEW';
    if (isSoldUnitViewModifyMode) initParking();
}

function initSoldeUnitsGrid() {
    var dtOptions = {
        tableId: "soldUnitsGrid",
        pageLength: 10,
        isViewOnly: false,
        customBtnGrpId: "#soldUnitsSearchBtnDiv",
        hideSearch: false
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToSoldUnitsHdnId");
}
function initTaxGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW' || $("[id$='pageModeHdn']").val() == 'MODIFY_LIMITTED');
    var dtOptions = {
        tableId: "taxDetailGrid",
        pageLength: 5,
        isViewOnly: isViewOnly,
        responsiveModalTitle: "Tax Details",
        customBtnGrpId: "#taxDetailGridBtnGrp",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToTaxDetailHdnId");
}
function initCMTaxGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW' || $("[id$='pageModeHdn']").val() == 'MODIFY_LIMITTED');
    var dtOptions = {
        tableId: "cmTaxDetailGrid",
        pageLength: 5,
        isViewOnly: isViewOnly,
        responsiveModalTitle: "Tax Details",
        customBtnGrpId: "#cmTaxDetailGridBtnGrp",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToCMTaxDetailHdnId");
}
function initCoCustomerGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW' || $("[id$='pageModeHdn']").val() == 'MODIFY_LIMITTED');
    var dtOptions = {
        tableId: "coCustomerGrid",
        pageLength: 5,
        isViewOnly: isViewOnly,
        responsiveModalTitle: "Co Customer Details",
        customBtnGrpId: "#cocustomerGridBtnGrp",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToCoCustHdnId");
}
function initPaymentGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "paymentGrid",
        pageLength: 5,
        isViewOnly: isViewOnly,
        responsiveModalTitle: "Payment Details",
        customBtnGrpId: "#paymentGridBtnGrp",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPaymentHdnId");
}
function initCancelInfoPymtGrid() {
    var dtOptions = {
        tableId: "cancelInfoPymtGrid",
        pageLength: 5,
        isViewOnly: true,
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
}