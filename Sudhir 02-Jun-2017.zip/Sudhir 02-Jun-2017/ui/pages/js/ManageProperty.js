$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initPropertyGrid();
    initTowerGrid();
    initTaxGrid();
    initPropertyChargesGrid();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("tab2Content");
    //This script will enable tabs which was last active even after postback call.
    enableTab(true);
}

function initTowerGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "propertyTowerGrid",
        pageLength: 5,
        isViewOnly: isViewOnly,
        responsiveModalTitle: "Tower Details",
        customBtnGrpId: "#propTowerGridBtnGrp",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPropertyTowerHdnId");
}
function initTaxGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "taxDetailGrid",
        pageLength: 5,
        isViewOnly: isViewOnly,
        responsiveModalTitle: "Tax Details",
        customBtnGrpId: "#taxDetailGridBtnGrp",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToTaxDetailHdnId");
}

function initPropertyGrid() {
    var dtOptions = {
        tableId: "propertyGrid",
        pageLength: 10,
        isViewOnly: false,
        customBtnGrpId: "#propSearchBtnDiv",
        hideSearch: false
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPropertyHdnId");
}
function initPropertyChargesGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "PropertyChargesGrid",
        pageLength: 5,
        isViewOnly: isViewOnly,
        responsiveModalTitle: "Property Charges Details",
        customBtnGrpId: "#chargesDetailGridBtnGrp",
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToChargesDetailHdnId");
}

