﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initDepositGrid();
    formatFields();
    initViewMode("tab2Content");
    //This script will enable tabs which was last active even after postback call.
    enableTab(true);
}

function initDepositGrid() {
    var dtOptions = {
        tableId: "DepositGrid",
        pageLength: 10,
        isViewOnly: false,
        customBtnGrpId: "#DepositSearchBtnDiv",
        hideSearch: false
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToDepositHdnId");
}