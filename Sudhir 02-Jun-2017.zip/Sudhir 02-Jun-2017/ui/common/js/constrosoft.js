/*
Datatable neds to recalculate when specific tab is shown. This will enable responsiveness of datatable.
*/
$(document).on('shown.bs.tab', 'a[data-toggle="tab"]', function (e) {
    $($.fn.dataTable.tables()).DataTable().columns.adjust().responsive.recalc();
})
$(document).on('click', 'a.storeTabName', function (e) {
    $("[id$='activeTabHdn']").val($(this).attr('id'));
})
$(document).on('show.bs.modal', 'div.dtr-bs-modal', function (e) {
    formatAutoNumeric("");
});
$(document).on('click', '.bzStepLink', function (e) {
    $this = $(this);
    if ($this) {
        $("[id$='goToStepHdn']").val($this.attr('data-step'));
        var isButton = $this.hasClass('btn');
        if (!isButton) $("[id$='btnGoToStepHdn']").click();
    }
    
})
$(document).ready(function () {
    //On load of page activate menu link
    activateCurrentMenuLink();
    var $sidebarNav = $('.sidebar');
    $(document).mouseup(function (e) {
        if (!$sidebarNav.is(e.target)) {
            //TODO - re-select menu for loaded page
            //e.stopPropagation();
            //activateCurrentMenuLink();
        }
    });
});
/*
    Enables active tab. If there are stepy wizard present on the tab then it also shows active stepy wizard (value present in hidden element having 
    Id ends with '<TabId>BzHdn'. Also responsive datatables are recalculated in order to make them responsive.
    NOTE: This function must be called at end of the 'initBootstrapComponants()' function on each page js.
*/
function enableTab(hasStepWizard) {
    if ($("[id$='activeTabHdn']").val() != "") {
        var tabId = $("[id$='activeTabHdn']").val();
        if (hasStepWizard) {
            var tabHref = $('a[id$="' + tabId + '"]').attr('href');
            var tabContent = (tabHref) ? tabHref.replace('#', '') : "";
            var bzHdnBtn = $("[id$='" + tabContent + "BzHdn']");
            if (bzHdnBtn != 'undefined' && tabContent != "") {
                var bzStep = bzHdnBtn.val();
                $("div[id$=" + tabContent + "]").find('ul.stepy-header > li').removeClass('stepy-active');
                $("div[id$=" + tabContent + "]").find("ul.stepy-header > li." + bzStep).addClass('stepy-active');
                $("div[id$=" + tabContent + "]").find("fieldset." + bzStep).fadeIn(0);
            }
        }
        if (tabId != "") $('a[id$="' + tabId + '"]').tab('show');
    }
    scrollToField($("[id$='scrollToFieldHdn']").val(), 10);
    $("[id$='scrollToFieldHdn']").val('');
}
/*
    This function will scoll to the given element (Id) so that it will be at top of the page OR scroller reaches at end. If 'elementId' value is 'TOP' 
    then it scrolls to top of the page.
*/
function scrollToField(elementId, removed_height) {
    var scrollTo = -1;
    if (elementId && elementId != "") {
        if (elementId == "TOP") {
            scrollTo = 0;
        } else {
            var $element = $("[id$='" + elementId + "']");
            if ($element) {
                scrollTo = $("[id$='" + elementId + "']").offset().top - removed_height;
            }
        }
    }
    if (scrollTo != -1) {
        $('html, body').animate({ scrollTop: scrollTo }, 'slow');
    }
}
function activateCurrentMenuLink() {
    var activeLink = $.AdminLTE.ConstroSoft.getLinkToActivate();
    var ul = activeLink.parent();
    if (ul != 'undefined') {
        if (ul.hasClass('treeview-menu') && !ul.hasClass('menu-open')) {
            var treeViewLI = ul.parent();
            treeViewLI.find('a').click();
        } else if (!activeLink.hasClass('active')){
            activeLink.addClass('active');
        }
    }
}

var dialog;

jQuery.fn.extend({
    disable: function (state) {
        return this.each(function () {
            var $this = $(this);
            if ($this.is('input, button, textarea, select'))
                this.disabled = state;
            else
                $this.toggleClass('disabled', state);
        });
    }
});

$.fn.mirror = function (selector) {
    return this.each(function () {
        var $this = $(this);
        var $selector = $(selector);
        $this.bind('change keyup', function () {
            $selector.val($this.val()).change();
        });
    });
};
/**
 * This function will take to the page where 'element' is present with attribute 'index' having value given in 'data'.
 * Usage - dtTable.api().page.jumpToIndex("6"); 
 */
jQuery.fn.dataTable.Api.register('page.jumpToIndex()', function (data) {
    var pos = -1;
    this.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var index = this.nodes().to$().find('.row-identifier').attr('row-identifier');
        if (index == data) {
            pos = rowLoop;
        }
    });
    if (pos >= 0) {
        var page = Math.floor(pos / this.page.info().length);
        this.page(page).draw(false);
    }
});
/**
 * This function will select the datatable row check box for given row identifier 'data'
 * Usage - dtTable.api().page.selectRecord("checkBoxId","1"); 
 */
jQuery.fn.dataTable.Api.register('page.selectRecord()', function (elementId, data) {
    var pos = -1;
    this.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var index = this.nodes().to$().find('.row-identifier').attr('row-identifier');
        if (index == data) {
            //Here rowIdx should be used as it is used to form checkbox element id.
            pos = rowIdx;
        }
    });
    if (pos >= 0) {
        var chBox = this.row(pos).nodes().to$().find("[id$='" + elementId + "_" + pos + "']");
        var value = $(chBox).prop('checked');
        if (value == false) {
            $(chBox).prop('checked', true);
        }
    }
});
function formatAutoNumeric(modalBody) {
    var body = (modalBody != "") ? modalBody : 'body';
    //Format input fields as indian currency amount which has class csamount.
    $(body).find('input.csaddresspin').autoNumeric('init', { aSep: '', vMax: 999999, vMin: 0, wEmpty: '' });
    $(body).find('.csnumber').autoNumeric("init", { aSep: ',', aDec: '.', dGroup: 2, vMin: '0', vMax: '100', mDec: 0, aSign: ' ', pSign: 's' });
    $(body).find('.csnumber').attr('placeholder', '');
    $(body).find('.csamount').autoNumeric("init", { aSep: ',', aDec: '.', dGroup: 2, aSign: 'Rs. ' });
    $(body).find('.csamount').attr('placeholder', 'Rs.');
    $(body).find('.cspercentaged3').autoNumeric("init", { aSep: ',', aDec: '.', dGroup: 2, vMin: '0.000', vMax: '100.000', aSign: ' %', pSign: 's' });
    $(body).find('.cspercentaged3').attr('placeholder', '%');
    $(body).find('.cspercentaged0').autoNumeric("init", { aSep: ',', aDec: '.', dGroup: 2, vMin: '0', vMax: '100', mDec: 0, aSign: ' %', pSign: 's' });
    $(body).find('.cspercentaged0').attr('placeholder', '%');
    $(body).find('.cssqftarea').autoNumeric("init", { aSep: ',', aDec: '.', dGroup: 2, mDec: 3, aSign: ' Sq.Ft. ', pSign: 's' });
    $(body).find('.cssqftarea').attr('placeholder', 'Sq.Ft.');
    $(body).find('.cssqmtarea').autoNumeric("init", { aSep: ',', aDec: '.', dGroup: 2, mDec: 3, vMin: '0.000', vMax: '9999999.000', aSign: ' Sq.Mtr. ', pSign: 's' });
    $(body).find('.cssqmtarea').attr('placeholder', 'Sq.Mtr.');
    $(body).find('td.csamountnotempty').each(function () {
        $this = $(this);
        if ($this.text().trim() != "") $this.autoNumeric("init", { aSep: ',', aDec: '.', dGroup: 2, aSign: '' });
    });
}
function formatFields() {
    formatAutoNumeric("");
    //Convert fields as select picker which has class csdrp.
    $('.csdrp').selectpicker({
        dropupAuto: false,
        selectOnTab: true,
        noneSelectedText:"Nothing to Select"
    });
    $('.csdrplive').selectpicker({
        dropupAuto: false,
        liveSearch: true,
        selectOnTab: true,
        noneSelectedText: "Nothing to Select"
    });
    $('div.bootstrap-select').addClass("dropdown-100-percent");
    $('div.bootstrap-select > button').addClass("btn-sm border-gray");
    $('div.bs-searchbox > input').addClass("input-sm");
    //Convert fields as date picker which has class csdt.
    $('div.date').datepicker({
        autoclose: true,
        todayBtn: true,
        todayHighlight: true,
        format: 'dd-M-yyyy'
    });
    Ladda.bind('.btn-ladda-spinner');
    $("input:radio, .styled").uniform({
        radioClass: 'choice'
    });
}

function toolTipOnTable(tableId) {
    $("[id$='" + tableId + "']" + ' tbody td').each(function () {
        var $td = $(this);
        $td.attr('title', '');
        $td.attr('title', $td.text());
    });
    /* Apply the tooltips */
    $("[id$='" + tableId + "']" + 'thead th[title]').tooltip({
        "container": 'body'
    });
}

function jumpToTablePage(dtTable, jumpToHdnId) {
    var index = $("[id$='" + jumpToHdnId + "']").val();
    if (index && index != "") {
        dtTable.page.jumpToIndex(index);
        $("[id$='" + jumpToHdnId + "']").val('');
    }
}
/*
This function is used to show dropdown menu inside tables(Row level actions). They are hidden when datatable is scrollable because of overflow:hidden CSS.
This function re-attach the dropdown menu and shows on top of the action button.
*/
function makeDropdownVisible() {
    $('.table-dropdown-menu').parent().on('shown.bs.dropdown', function () {
        var $menu = $("ul", this);
        offset = $menu.offset();
        position = $menu.position();
        $('body').append($menu);
        $menu.show();
        $menu.css('position', 'absolute');
        $menu.css('top', (offset.top) + 'px');
        $menu.css('left', (offset.left) + 'px');
        $menu.css('max-width', '20px');//max-width CSS keeps the size of the dropdown minumum
        $(this).data("myDropdownMenu", $menu);
    });
    $('.table-dropdown-menu').parent().on('hide.bs.dropdown', function () {
        $(this).append($(this).data("myDropdownMenu"));
        $(this).data("myDropdownMenu").removeAttr('style');

    });
}
function applyDataTable(dtOptions) {
    var tableId = dtOptions.tableId;
    var pageLength = (dtOptions.pageLength) ? dtOptions.pageLength : 10;
    $("[id$='" + tableId + "']").prepend($("<thead></thead>").append($("[id$='" + tableId + "']").find("tr:first")));
    var dtTable = $("[id$='" + tableId + "']").DataTable({
        autoWidth: false,
        dom: "<'row'<'col-md-6 col-sm-6 col-xs-3 tmpCustomBtn'l><'col-md-6 col-sm-6 col-xs-9'f>>" +
               "<'row'<'col-sm-12'<'datatable-scroll'tr>>>" +
               "<'row'<'col-sm-5'i><'col-sm-7'p>>",
        pageLength: pageLength,
        ordering: false,
        drawCallback: function () {
            $(this).find('tbody tr').slice(-3).find('.dropdown, .btn-group').addClass('dropup');
        },
        preDrawCallback: function () {
            $(this).find('tbody tr').slice(-3).find('.dropdown, .btn-group').removeClass('dropup');
        }
    });
    if (dtOptions.hideSearch) {
        $("[id$='" + tableId + "_wrapper']").find('.dataTables_filter').html('');
    }
    //If dtOptions has 'customBtnGrpId' then replace Page Length section with given button group.
    $("[id$='" + tableId + "_wrapper']").find('.tmpCustomBtn').html('');
    if (dtOptions.customBtnGrpId) {
        $("[id$='" + tableId + "_wrapper']").find('.tmpCustomBtn').html($(dtOptions.customBtnGrpId).html());
        $(dtOptions.customBtnGrpId).html('')
    }
    if (dtOptions.responsiveModalTitle) showRowInfo(dtOptions, dtTable);
    dtTable.on('draw.dt', function () { addShowRowInfoIcon(dtOptions, dtTable); formatAutoNumeric(""); });
    return dtTable;
}
function showRowInfo(dtOptions, dtTable) {
    var isViewOnly = dtOptions.isViewOnly ? true : false;
    var responsiveColumnIdx = (isViewOnly) ? 1 : 2;//Second column is default column on which + sign will be shown.
    addShowRowInfoIcon(dtOptions, dtTable);
    $("[id$='" + dtOptions.tableId + "']").find('span.show-row-info').off('click');
    $("[id$='" + dtOptions.tableId + "']").on("click", 'tbody tr td:nth-child(' + responsiveColumnIdx + ') span.show-row-info', function () {
        var tr = $(this).parents('tr');
        var tableContent = '<table class="table datatable-modal-table"><tbody>' + $(tr).find('.row-info').attr('row-info');
        var footer = '<tfoot><tr><th style="text-align: center;" colspan=2>' +
                    '<button type="button" class="btn btn-primary btn-sm" data-dismiss="modal">Close</button>' +
                    '</th></tr></tfoot>';
        tableContent = tableContent + footer + '</table>';
        BootstrapDialog.show({
            title: dtOptions.responsiveModalTitle,
            message: tableContent,
            nl2br: false,
            closable: true,
            buttons: [],
            onshown: function (dialogRef) {
                formatAutoNumeric(dialogRef.getModalBody());
            }
        });
    });
}
/*
 * This fucntion is called on whenever datatable is drawn. It is requried to add row info icon if not present on that page. When datatable is initialized it does not add
 * info icon on all pages but adds it on first page only.
*/
function addShowRowInfoIcon(dtOptions, dtTable) {
    if (dtOptions.responsiveModalTitle) {
        var isViewOnly = dtOptions.isViewOnly ? true : false;
        var responsiveColumnIdx = (isViewOnly) ? 1 : 2;//Second column is default column on which + sign will be shown.
        var alreadyExist = $("[id$='" + dtOptions.tableId + "']").find('tbody tr td:nth-child(' + responsiveColumnIdx + ') span.show-row-info').length > 0;
        if (!alreadyExist) {
            $("[id$='" + dtOptions.tableId + "']").find('tbody tr td:nth-child(' + responsiveColumnIdx + ')').each(function () {
                $this = $(this);
                if ($this.parents('tr').children('td').length > 1) $this.html('<span class="show-row-info"><i class="icon-eye8 text-light-blue"></i></span>' + $this.html());
            });
        }
    }
    $("[id$='" + dtOptions.tableId + "']").find("input:radio, .styled").uniform({
        radioClass: 'choice'
    });
}
/**
 * This function is used to apply datatable. It uses custom responsive feature (showing modal (+)). All columns in datatable are visible unlike datatatable
 * responsive behaviour where in last column is hidden.
 * dtOptions will have below variables.
 * 		tableId - Mandatory -> This is id of datatable table grid.
 * 		responsiveModalTitle - Mandatory -> Title of Responsive Modal.
 * 		isViewOnly - Mandatory -> true/false, Default true, Whether datatable to be initialized as view only. If true then first column (Action) need to be hide from server side.
 * 		pageLength - Not Mandatory -> PageLength for datatable. If not given default is 10
 * 		customBtnGrpId - Not mandatory -> Custom group button to be added in top left corner of datatable.
 *      hasRowInfo - true/false -> Not mandatory-> If set to true then it shows data from hidden field with class 'row-info' in each row else shows data from columns and row
 *      defaultColToOrder - int -> Not mandatory-> Default column to order. It is index of column (starting with 0 including select column) to be ordered by default. 
 *      defaultOrderAsc - true/false -> Not mandatory-> Default order as Asc. If true column will default to ASC else DESC.
 *      hideSearch - true/false -> Not Mandatory -> if true then hide search field
 * @param dtOptions Various options.
 * @returns dtTable Datatable instance.
 */
function applyResponsiveDtTable(dtOptions) {
    var pageLength = (dtOptions.pageLength) ? dtOptions.pageLength : 10;
    var isViewOnly = dtOptions.isViewOnly ? true : false;
    var firstColsearchable = isViewOnly;
    var defaultColToOrder = (dtOptions.defaultColToOrder) ? (isViewOnly ? dtOptions.defaultColToOrder - 1 : dtOptions.defaultColToOrder) : (isViewOnly ? 0 : 1);
    var responsiveModalCol = 1;
    var tableId = dtOptions.tableId; 
    var defaultOrder = (dtOptions.defaultOrderDesc) ? 'desc' : 'asc';
    var noOfRecords = ($("[id$='" + tableId + "']").find('tr').length) - 1;
    if (isViewOnly && noOfRecords > 0) {
        $("[id$='" + tableId + "']").addClass('col1-responsive');
        responsiveModalCol = 0;
    } else {
        $("[id$='" + tableId + "']").addClass('col2-responsive');
    }
    $("[id$='" + tableId + "']").prepend($("<thead></thead>").append($("[id$='" + tableId + "']").find("tr:first")));
    var dtTable = $("[id$='" + tableId + "']").DataTable({
        dom: "<'row'<'col-sm-6 col-xs-3 tmpCustomBtn'l><'col-sm-6 col-xs-9'f>>" +
			    "<'row'<'col-sm-12'tr>>" +
			    "<'row'<'col-sm-5'i><'col-sm-7'p>>",
        pageLength: pageLength,
        columnDefs: [{
            "targets": 0,
            "searchable": firstColsearchable,
            "orderable": firstColsearchable
        }
        ],
        order: [[defaultColToOrder, defaultOrder]],
        responsive: {
            details: {
                type: 'column',
                target: responsiveModalCol,
                display: $.fn.dataTable.Responsive.display.modal({
                    header: function (row) {
                        var data = row.data();
                        return dtOptions.responsiveModalTitle;
                    }
                }),
                renderer: function (api, rowIdx, columns) {
                    var data = "";
                    if (dtOptions.hasRowInfo) {
                        data = api.row(rowIdx).nodes().to$().find('.row-info').attr('row-info');
                    } else {
                        data = $.map(columns, function (col, i) {
                            var tdNo = (isViewOnly) ? col.columnIndex : col.columnIndex + 1;
                            var tdClass = api.row(rowIdx).nodes().to$().find("td:nth-child(" + tdNo + ")").attr('class');
                            return i != 0 ?
							    '<tr data-dt-row="' + col.rowIndex + '" data-dt-column="' + col.columnIndex + '">' +
								    '<td nowrap style="width: 20%;">' + col.title + '</td> ' +
								    "<td class=\"" + tdClass + "\">" + col.data + '</td>' +
							    '</tr>' :
							    '';
                        }).join('');
                    }
                    var footer = '<tfoot><tr><th style="text-align: center;" colspan=2>' +
									'<button type="button" class="btn btn-primary btn-sm" data-dismiss="modal">Close</button>' +
									'</th></tr></tfoot>';
                    var modalContent = data ? $('<table class="table datatable-modal-table">').append(data).append(footer) : false;
                    return modalContent;
                }
            }
        }
    });
    if (dtOptions.hideSearch) {
        $("[id$='" + tableId + "_wrapper']").find('.dataTables_filter').html('');
    }
    //If dtOptions has 'customBtnGrpId' then replace Page Length section with given button group.
    $("[id$='" + tableId + "_wrapper']").find('.tmpCustomBtn').html('');
    if (dtOptions.customBtnGrpId) {
        $("[id$='" + tableId + "_wrapper']").find('.tmpCustomBtn').html($(dtOptions.customBtnGrpId).html());
        $(dtOptions.customBtnGrpId).html('')
    }
    toolTipOnTable(tableId);
    dtTable.on('draw.dt', function () { formatAutoNumeric(""); });
    return dtTable;
}
function applyDtTable(dtOptions) {
    var pageLength = (dtOptions.pageLength) ? dtOptions.pageLength : 10;
    var isViewOnly = dtOptions.isViewOnly ? true : false;
    var firstColsearchable = isViewOnly;
    var defaultColToOrder = (dtOptions.defaultColToOrder) ? (isViewOnly ? dtOptions.defaultColToOrder - 1 : dtOptions.defaultColToOrder) : (isViewOnly ? 0 : 1);
    var tableId = dtOptions.tableId;
    var defaultOrder = (dtOptions.defaultOrderDesc) ? 'desc' : 'asc';
    if (isViewOnly) {
        $("[id$='" + tableId + "']").addClass('col1-responsive');
    } else {
        $("[id$='" + tableId + "']").addClass('col2-responsive');
    }

    $("[id$='" + tableId + "']").prepend($("<thead></thead>").append($("[id$='" + tableId + "']").find("tr:first")));
    var dtTable = $("[id$='" + tableId + "']").DataTable({
        dom: "<'row'<'col-sm-6 col-xs-3 tmpCustomBtn'l><'col-sm-6 col-xs-9'f>>" +
			    "<'row'<'col-sm-12'tr>>" +
			    "<'row'<'col-sm-5'i><'col-sm-7'p>>",
        pageLength: pageLength,
        columnDefs: [{
            "targets": 0,
            "searchable": firstColsearchable,
            "orderable": firstColsearchable
        }
        ],
        order: [[defaultColToOrder, defaultOrder]]
    });
    if (dtOptions.hideSearch) {
        $("[id$='" + tableId + "_wrapper']").find('.dataTables_filter').html('');
    }
    //If dtOptions has 'customBtnGrpId' then replace Page Length section with given button group.
    $("[id$='" + tableId + "_wrapper']").find('.tmpCustomBtn').html('');
    if (dtOptions.customBtnGrpId) {
        $("[id$='" + tableId + "_wrapper']").find('.tmpCustomBtn').html($(dtOptions.customBtnGrpId).html());
        $(dtOptions.customBtnGrpId).html('')
    }
    applyCustomResponsiveModal(dtOptions, dtTable);
    toolTipOnTable(tableId);
    dtTable.on('draw.dt', function () { formatAutoNumeric(""); });
    return dtTable;
}
function applyCustomResponsiveModal(dtOptions, dtTable) {
    var isViewOnly = dtOptions.isViewOnly ? true : false;
    var responsiveColumnIdx = (isViewOnly) ? 1 : 2;//Second column is default column on which + sign will be shown.
    $("[id$='" + dtOptions.tableId + "']").on("click", 'tbody tr td:nth-child(' + responsiveColumnIdx + ')', function () {
        var tr = $(this).parents('tr');
        var tableContent = '<table class="table datatable-modal-table"><tbody>';
        $(tr).find('td').each(function () {
            var idx = dtTable.cell(this).index().column;
            //If table is editable then do not show first column in modal.
            if (isViewOnly || (!isViewOnly && idx != 0)) {
                var colHeader = dtTable.column(idx).header();
                var row = '<tr><td style="width:30%;">' + $(colHeader).html() + '</td><td>' + $(this).html() + '</td></tr>';
                tableContent = tableContent + row;
            }
        });
        var footer = '<tfoot><tr><th style="text-align: center;" colspan=2>' +
				    '<button type="button" class="btn btn-primary btn-sm" data-dismiss="modal">Close</button>' +
				    '</th></tr></tfoot>';
        tableContent = tableContent + footer + '</table>';
        BootstrapDialog.show({
            title: dtOptions.responsiveModalTitle,
            message: tableContent,
            nl2br: false,
            closable: true,
            buttons: []
        });
    });
}
function getDeleteMessage(element) {
    var message = $(element).attr('data-delete-message');
    $(element).each(function () {
        $.each(this.attributes, function () {
            if (this.specified) {
                if (this.name.startsWith("data-delete-message-opt")) {
                    var index = this.name.split('-').pop();
                    var pos = "{" + index + "}";
                    message = message.split(pos).join(this.value);
                }
            }
        });
    });
    return message;
}
function confirmSelectedDelete(element) {
    var btnToClick = $(element).attr('data-delete-button');
    var deleteBtn = $("[id$=" + btnToClick + "]");
    var message = getDeleteMessage(deleteBtn);
    var title = deleteBtn.attr('data-delete-title');
    BootstrapDialog.confirm({
        title: title,
        message: message,
        btnOKClass: 'btn btn-primary btn-sm',
        btnCancelClass: 'btn btn-primary btn-sm',
        closable: false,
        callback: function (result) {
            if (result) {
                deleteBtn.click();
            } else {
                Ladda.stopAll();
            }
        }
    });
    return false;
}
function initViewMode(tabId) {
    var pageMode = $("[id$='pageModeHdn']").val();
    if ("VIEW" == pageMode) {
        makeReadOnlySection(tabId);
    }
}
function makeReadOnlySection(sectionId) {
    $("div[id$='" + sectionId + "']").find('input.form-control.input-sm').not('div.dataTables_wrapper input').each(function () {
        $this = $(this);
        var tmp = $('<label class="rdview-text" />').text($this.val());
        //If parent div is for input-group date then replace that div with label.
        if ($this.parent().hasClass('input-group date')) {
            $this.parent().replaceWith(tmp);
        } else {
            $this.replaceWith(tmp);
        }
    });
    $("div[id$='" + sectionId + "']").find('textarea.form-control.input-sm').each(function () {
        $this = $(this);
        var tmp = $('<label class="rdview-text" />').text($this.val());
        $this.replaceWith(tmp);
    });
    $("div[id$='" + sectionId + "']").find('div.btn-group.bootstrap-select').each(function () {
        $this = $(this);
        var value = $this.find('select :selected').val();
        var tmp = $('<label class="rdview-text" />').text((value != "") ? $this.find('select :selected').text() : "");
        $this.replaceWith(tmp);
    });
    $("div[id$='" + sectionId + "']").find('div.row').removeClass('margintop5');
}
function showModal(mdOptions) {

    dialog = new BootstrapDialog({
        title: mdOptions.modalTitle,
        message: $('#' + mdOptions.modalId).html(),
        nl2br: false,
        closable: false,
        buttons: [],
        onshown: function (dialogRef) {
            if (mdOptions.action == 'UPDATE') {
                dialog.getModalBody().find("[id$=saveModalBtnId]").html('Update');
            }
            dialog.getModalBody().find("[id$=modalHdnType]").val(mdOptions.modalName).change();
            dialog.getModalBody().find("[id$=modalActionHdn]").val(mdOptions.action).change();
            dialog.getModalBody().find("[id$=modalIdentifierHdn]").val(mdOptions.identifier).change();
            dialog.getModalBody().find("[id$=modalInput1Label]").html(mdOptions.input1Label);
            dialog.getModalBody().find("[id$=modalInput2Label]").html(mdOptions.input2Label);
            dialog.getModalBody().find("[id$=modalInput1]").val(mdOptions.input1Value).change();
            dialog.getModalBody().find("[id$=modalInput2]").val(mdOptions.input2Value).change();
            formatAutoNumeric(dialog.getModalBody());
            dialogRef.getModalBody().find("[id$=modalInput1]").focus();
        }
    });
    dialog.open();
}
//This method is called on click of Save button of Modal dialog
function saveModalDataClient() {

    $("[id$=modalHdnType]").val(dialog.getModalBody().find("[id$=modalHdnType]").val());
    $("[id$=modalActionHdn]").val(dialog.getModalBody().find("[id$=modalActionHdn]").val());
    $("[id$=modalIdentifierHdn]").val(dialog.getModalBody().find("[id$=modalIdentifierHdn]").val());
    $("[id$=modalInput1]").val(dialog.getModalBody().find("[id$=modalInput1]").val());
    $("[id$=modalInput2]").val(dialog.getModalBody().find("[id$=modalInput2]").val());

    //Invoke server side event for save.
    $("[id$=btSaveModalId]").click();
}
//This method is called on click of Cancel button of Modal dialog
function closeDialogClient() {
    if (dialog) {
        dialog.close();
    }
}

function setModalErrorMsg() {
    var errorMsg = $("[id$=modalErrorMsg]").val();
    $('.modal-body').find('.modalErrorMsgDiv').toggleClass('hidden show');
    $('.modal-body').find('.modalErrorMsg').html(errorMsg);
}

function addPropertyType() {
    var mdOptions = {
        modalId: "modalDialogue",
        modalName: "PROPERTY_TYPE",
        modalTitle: "Add Property Type",
        action: "ADD",
        identifier: "",
        input1Label: "Property Type",
        input2Label: "Description",
        input1Value: "",
        input2Value: ""
    };
    showModal(mdOptions);
    return false;
}
function addPropertyTax() {
    var mdOptions = {
        modalId: "modalDialogue",
        modalName: "PROPERTY_TAX",
        modalTitle: "Add Property Tax Type",
        action: "ADD",
        identifier: "",
        input1Label: "Tax Type",
        input2Label: "Description",
        input1Value: "",
        input2Value: ""
    };
    showModal(mdOptions);
}
function addPropUnitType() {
    var mdOptions = {
        modalId: "modalDialogue",
        modalName: "PROPERTY_UNIT_TYPE",
        modalTitle: "Add Property Unit Type",
        action: "ADD",
        identifier: "",
        input1Label: "Property Unit Type",
        input2Label: "Description",
        input1Value: "",
        input2Value: ""
    };
    showModal(mdOptions);
}
function addEnquirySource() {
    var mdOptions = {
        modalId: "modalDialogue",
        modalName: "ENQUIRY_SOURCE",
        modalTitle: "Add Enquiry Source",
        action: "ADD",
        identifier: "",
        input1Label: "Enquiry Source",
        input2Label: "Description",
        input1Value: "",
        input2Value: ""
    };
    showModal(mdOptions);
}
function addOccupation() {
    var mdOptions = {
        modalId: "modalDialogue",
        modalName: "OCCUPATION",
        modalTitle: "Add Occupation",
        action: "ADD",
        identifier: "",
        input1Label: "Occupation",
        input2Label: "Description",
        input1Value: "",
        input2Value: ""
    };
    showModal(mdOptions);
}
function addDepartment() {
    var mdOptions = {
        modalId: "modalDialogue",
        modalName: "DEPARTMENT",
        modalTitle: "Add Department",
        action: "ADD",
        identifier: "",
        input1Label: "Department Name",
        input2Label: "Description",
        input1Value: "",
        input2Value: ""
    };
    showModal(mdOptions);
}
function addDesignation() {
    var mdOptions = {
        modalId: "modalDialogue",
        modalName: "DESIGNATION",
        modalTitle: "Add Designation",
        action: "ADD",
        identifier: "",
        input1Label: "Designation",
        input2Label: "Description",
        input1Value: "",
        input2Value: ""
    };
    showModal(mdOptions);
}

function addPropertyType() {
    var mdOptions = {
        modalId: "modalDialogue",
        modalName: "PROPERTY_TYPE",
        modalTitle: "Add Property Type",
        action: "ADD",
        identifier: "",
        input1Label: "Property Type",
        input2Label: "Description",
        input1Value: "",
        input2Value: ""
    };
    showModal(mdOptions);
}

function addPropertyLocation() {
    var mdOptions = {
        modalId: "modalDialogue",
        modalName: "PROPERTY_LOCATION",
        modalTitle: "Add Property Location",
        action: "ADD",
        identifier: "",
        input1Label: "Property Location",
        input2Label: "Description",
        input1Value: "",
        input2Value: ""
    };
    showModal(mdOptions);
}
function addPropertyUnitType() {
    var mdOptions = {
        modalId: "modalDialogue",
        modalName: "PROPERTY_UNIT_TYPE",
        modalTitle: "Add Property Unit Type",
        action: "ADD",
        identifier: "",
        input1Label: "Property Unit Type",
        input2Label: "Description",
        input1Value: "",
        input2Value: ""
    };
    showModal(mdOptions);
}
function addRelation() {
    var mdOptions = {
        modalId: "modalDialogue",
        modalName: "RELATION_WITH_CUSTOMER",
        modalTitle: "Add Relation With Customer",
        action: "ADD",
        identifier: "",
        input1Label: "Relation With Customer",
        input2Label: "Description",
        input1Value: "",
        input2Value: ""
    };
    showModal(mdOptions);
}

function addUnitType() {
    var mdOptions = {
        modalId: "modalDialogue",
        modalName: "UNIT_TYPE",
        modalTitle: "Add Unit Type",
        action: "ADD",
        identifier: "",
        input1Label: "Unit Type",
        input2Label: "Description",
        input1Value: "",
        input2Value: ""
    };
    showModal(mdOptions);
}

function addDirection() {
    var mdOptions = {
        modalId: "modalDialogue",
        modalName: "DIRECTION",
        modalTitle: "Add Direction",
        action: "ADD",
        identifier: "",
        input1Label: "Direction",
        input2Label: "Description",
        input1Value: "",
        input2Value: ""
    };
    showModal(mdOptions);
}

function addFacing()
{
    var mdOptions = {
        modalId: "modalDialogue",
        modalName: "FACING",
        modalTitle: "Add Facing",
        action: "ADD",
        identifier: "",
        input1Label: "Facing",
        input2Label: "Description",
        input1Value: "",
        input2Value: ""
    };
    showModal(mdOptions);
}

function addCommunicationMedia() {
    var mdOptions = {
        modalId: "modalDialogue",
        modalName: "COMMUNICATION_MEDIA",
        modalTitle: "Add Communication Media",
        action: "ADD",
        identifier: "",
        input1Label: "Communication Media",
        input2Label: "Description",
        input1Value: "",
        input2Value: ""
    };
    showModal(mdOptions);
}

function addAgencyType() {
    var mdOptions = {
        modalId: "modalDialogue",
        modalName: "AGENCY_TYPE",
        modalTitle: "Add Agency Type",
        action: "ADD",
        identifier: "",
        input1Label: "Agency Type",
        input2Label: "Description",
        input1Value: "",
        input2Value: ""
    };
    showModal(mdOptions);
}

function closeEnquiry() {
    var mdOptions = {
        modalId: "modalDialogue",
        modalName: "CLOSE_ENQUIRY",
        modalTitle: "Close Enquiry",
        action: "ADD",
        identifier: "",
        input2Label: "Close Reason",
        input2Value: ""
    };
    showSingleInputModal(mdOptions);
}
function openEnquiry() {
    var mdOptions = {
        modalId: "modalDialogue",
        modalName: "OPEN_ENQUIRY",
        modalTitle: "Open Enquiry",
        action: "ADD",
        identifier: "",
        input2Label: "Reason",
        input2Value: ""
    };
    showSingleInputModal(mdOptions);
}
function showSingleInputModal(mdOptions) {

    dialog = new BootstrapDialog({
        title: mdOptions.modalTitle,
        message: $('#' + mdOptions.modalId).html(),
        nl2br: false,
        closable: false,
        buttons: [],
        onshown: function (dialogRef) {
            dialog.getModalBody().find("[id$=modalInput1Label]").hide();
            dialog.getModalBody().find("[id$=modalInput1]").hide();
            if (mdOptions.action == 'UPDATE') {
                dialog.getModalBody().find("[id$=saveModalBtnId]").html('Update');
            }
            dialog.getModalBody().find("[id$=modalHdnType]").val(mdOptions.modalName).change();
            dialog.getModalBody().find("[id$=modalActionHdn]").val(mdOptions.action).change();
            dialog.getModalBody().find("[id$=modalIdentifierHdn]").val(mdOptions.identifier).change();
            dialog.getModalBody().find("[id$=modalInput2Label]").html(mdOptions.input2Label);
            dialog.getModalBody().find("[id$=modalInput2]").val(mdOptions.input2Value).change();
            dialogRef.getModalBody().find("[id$=modalInput1]").focus();
        }
    });
    dialog.open();
}
function addParkingType() {
    var mdOptions = {
        modalId: "modalDialogue",
        modalName: "PARKINGTYPE",
        modalTitle: "Add Parking Type",
        action: "ADD",
        identifier: "",
        input1Label: "Parking Type",
        input2Label: "Description",
        input1Value: "",
        input2Value: ""
    };
    showModal(mdOptions);
}
function addDocumentType() {
    var mdOptions = {
        modalId: "modalDialogue",
        modalName: "DOCUMENTTYPE",
        modalTitle: "Add Document Type",
        action: "ADD",
        identifier: "",
        input1Label: "Document Type",
        input2Label: "Description",
        input1Value: "",
        input2Value: ""
    };
    showModal(mdOptions);
}
function addSalePymtType() {
    var mdOptions = {
        modalId: "modalDialogue",
        modalName: "PR_UNIT_PYMT_TYPE",
        modalTitle: "Add Sale Payment Type",
        action: "ADD",
        identifier: "",
        input1Label: "Payment Type",
        input2Label: "Description",
        input1Value: "",
        input2Value: ""
    };
    showModal(mdOptions);
}

function addExpensesType() {
    var mdOptions = {
        modalId: "modalDialogue",
        modalName: "EXPENSES_TYPE",
        modalTitle: "Add Expenses Type",
        action: "ADD",
        identifier: "",
        input1Label: "Expenses Type",
        input2Label: "Description",
        input1Value: "",
        input2Value: ""
    };
    showModal(mdOptions);
}

function addPropertyChargesType() {
    var mdOptions = {
        modalId: "modalDialogue",
        modalName: "PROPERTYCHARGE",
        modalTitle: "Add Property Charge",
        action: "ADD",
        identifier: "",
        input1Label: "Property Charge Name", 
        input2Label: "Description",
        input1Value: "",
        input2Value: ""
    };
    showModal(mdOptions);
}
function payPdcPayment() {
    var mdOptions = {
        modalId: "modalDialogue",
        modalName: "PDC_PYMT",
        modalTitle: "Pay Amount",
        action: "ADD",
        identifier: "",
        input1Label: "Payment Amount",
        input2Label: "Comments",
        input1Value: "",
        input2Value: ""
    };
    showModal(mdOptions);
}
function submitForm(element) {
    var $btn = $(element).button('loading');
}