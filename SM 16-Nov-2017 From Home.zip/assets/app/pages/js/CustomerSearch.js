﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initCustomerSearchGrid();
    formatFields();
    showModal();
}

function initCustomerSearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        customBtnGrpId: "#customerSearchBtnDiv",
        pageLength: 10
    };

    $("[id$='customerSearchGrid']").CSBasicDatatable(dtOptions);
}
