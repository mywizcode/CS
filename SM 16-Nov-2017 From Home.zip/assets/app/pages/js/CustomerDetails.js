﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initSoldUnitGrid();
    formatFields();
    showModal();
}
function initSoldUnitGrid() {
    var dtOptions = {
        pageLength: 5,
        hideSearch: true
    };

    $("[id$='soldUnitsGrid']").CSBasicDatatable(dtOptions);
}




