﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Net;
using System.IO;
using System.Windows.Forms;
using System.Net.Mail;
using ConstroSoft;
using ConstroSoft.Logic.BO;
using OfficeOpenXml;
using OfficeOpenXml.DataValidation;
using OfficeOpenXml.Style;
using System.Drawing;
using ConstroSoft.Logic.Util;
using System.Text;
using System.Web.UI.HtmlControls;

public partial class PropertyPymtSchedule : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifyPymtScheduleError = "addModifyPymtScheduleError";
    string addModifyPymtScheduleModal = "addModifyPymtScheduleModal";
    DropdownBO drpBO = new DropdownBO();
    PropertyBO propertyBO = new PropertyBO();
    PropertyUnitManagementBO prUnitBO = new PropertyUnitManagementBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    public enum PymtScheduleAction { ADD, MODIFY }

    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Form.Attributes.Add("enctype", "multipart/form-data");
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                PrPymtScheduleNavDTO navDto = CommonUtil.getPageNavDTO<PrPymtScheduleNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_PROPERTY_PYMT_SCHEDULE)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpEnum<PRScheduleStageStatus>(drpStageStatus, null);
        drpBO.drpDataBase(drpPrTower, DrpDataType.PROPERTY_TOWER, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(), null, userDefDto.FirmNumber);
        drpPrTower.Text = CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Id.ToString();
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(PrPymtScheduleNavDTO navDTO)
    {
        Session[Constants.Session.PAGE_DATA] = new PrPymtSchedulePageDTO();
        initDropdowns();
        loadPrPymtScheduleGrid();
    }
    private void renderPageFieldsWithEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
    	lnkAddStageBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PYMT_SCHEDULE_ADD);
    	if (pymtScheduleGrid.Rows.Count > 0)
        {
            bool isActionEnabled = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PYMT_SCHEDULE_MODIFY, Constants.Entitlement.PYMT_SCHEDULE_DELETE);
            for (var i = 0; i < pymtScheduleGrid.Rows.Count; i++)
            {
                HtmlGenericControl tmpBtn = (HtmlGenericControl)pymtScheduleGrid.Rows[i].FindControl("liModifyStageBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PYMT_SCHEDULE_MODIFY);
                tmpBtn = (HtmlGenericControl)pymtScheduleGrid.Rows[i].FindControl("liDeleteStageBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PYMT_SCHEDULE_DELETE);
                tmpBtn = (HtmlGenericControl)pymtScheduleGrid.Rows[i].FindControl("ulPymtShcheduleActionBtn");
                if (tmpBtn != null) tmpBtn.Visible = isActionEnabled;
            }
            pymtScheduleGrid.Columns[0].Visible = isActionEnabled;
        }
    }
    private PrPymtSchedulePageDTO getSessionPageData()
    {
        return (PrPymtSchedulePageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<PropertyScheduleDTO> getPymtScheduleList()
    {
        return getSessionPageData().SearchResult;
    }
    private PropertyScheduleDTO getPymtScheduleDTO(long Id)
    {
        List<PropertyScheduleDTO> searchList = getPymtScheduleList();
        PropertyScheduleDTO selectedPymtScheduleDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            selectedPymtScheduleDTO = searchList.Find(c => c.Id == Id);
        }
        return selectedPymtScheduleDTO;
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private void loadPrPymtScheduleGrid()
    {
        PrPymtSchedulePageDTO PageDTO = getSessionPageData();
        IList<PropertyScheduleDTO> results = propertyBO.fetchPropertySchedule(long.Parse(drpPrTower.Text));
        PageDTO.SearchResult = (results != null) ? results.ToList<PropertyScheduleDTO>() : new List<PropertyScheduleDTO>();
        populatePymtScheduleSearchGrid(PageDTO.SearchResult);
    }
    private void populatePymtScheduleSearchGrid(List<PropertyScheduleDTO> tmpList)
    {
        tmpList.Sort((x, y) => x.StageNumber.CompareTo(y.StageNumber));
        pymtScheduleGrid.DataSource = new List<PropertyScheduleDTO>();
        if (tmpList != null)
        {
            assignUiIndexToPymtSchedule(tmpList);
            pymtScheduleGrid.DataSource = tmpList;
        }
        pymtScheduleGrid.DataBind();
    }
    private void assignUiIndexToPymtSchedule(List<PropertyScheduleDTO> tmpList)
    {
        if (tmpList != null && tmpList.Count > 0)
        {
            long uiIndex = 1;
            foreach (PropertyScheduleDTO tmpDTO in tmpList)
            {
                tmpDTO.UiIndex = uiIndex++;
                tmpDTO.RowInfo = CommonUIConverter.getGridViewRowInfo(tmpDTO);
            }
        }
    }
    protected void onChangePrTower(object sender, EventArgs e)
    {
        try
        {
            loadPrPymtScheduleGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void addOrModifyPymtSchedule(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyScheduleBeforeSaveToDB())
            {
                propertyBO.saveOrUpdatePropertySchedule(long.Parse(drpPrTower.Text), getPymtScheduleList());
                setNotyMsg(CommonUtil.getNotySuccessMsg("Payment Schedule is saved successfully."));
                loadPrPymtScheduleGrid();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelPymtSchedule(object sender, EventArgs e)
    {
        try
        {
            loadPrPymtScheduleGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validatePropertyScheduleBeforeSaveToDB()
    {

        bool isValid = validatePercentageTotal() && validateStageNoSequence() && validateStageStatus();

        return isValid;
    }
    private bool validatePercentageTotal()
    {
        bool isValid = true;
        List<PropertyScheduleDTO> prSchedList = getPymtScheduleList();
        if (prSchedList == null || prSchedList.Count == 0)
        {
            setNotyMsg(CommonUtil.getNotyErrorMsg("Please add aleast one stage."));
            return false;
        }
        if (prSchedList != null)
        {
            decimal totalPercentage = decimal.Zero;
            foreach (PropertyScheduleDTO propertyScheduleDto in prSchedList)
            {
                totalPercentage = totalPercentage + propertyScheduleDto.Percentage;
            }
            if (totalPercentage != new decimal(100.00))
            {
                setNotyMsg(CommonUtil.getNotyErrorMsg("Total percentage sum should be 100."));
                isValid = false;
            }
        }
        return isValid;
    }
    private bool validateStageNoSequence()
    {
        bool isValid = true;
        List<PropertyScheduleDTO> prSchedList = getPymtScheduleList();
        if (prSchedList != null)
        {
            prSchedList.Sort((x, y) => x.StageNumber.CompareTo(y.StageNumber));
            int tmpStageNumber = 1;
            string missingStageNos = "";
            foreach (PropertyScheduleDTO propertyScheduleDto in prSchedList)
            {
                if (tmpStageNumber < propertyScheduleDto.StageNumber)
                {
                    for (int i = tmpStageNumber; i < propertyScheduleDto.StageNumber; i++)
                    {
                        missingStageNos += (string.IsNullOrWhiteSpace(missingStageNos)) ? i + "" : ", " + i;
                    }
                    isValid = false;
                }
                tmpStageNumber = propertyScheduleDto.StageNumber + 1;
            }
            if (!isValid)
            {
                string msg = string.Format("Stage No '{0}' are missing.", missingStageNos);
                setNotyMsg(CommonUtil.getNotyErrorMsg(msg));
            }
        }
        return isValid;
    }
    private bool validateStageStatus()
    {
        bool isValid = true;
        List<PropertyScheduleDTO> prSchedList = getPymtScheduleList();
        if (prSchedList != null)
        {
            prSchedList.Sort((x, y) => x.StageNumber.CompareTo(y.StageNumber));
            int minPendingStageNumber = -1;
            int maxCompletedStageNumber = -1;
            foreach (PropertyScheduleDTO propertyScheduleDto in prSchedList)
            {
                if (PRScheduleStageStatus.Completed == propertyScheduleDto.Status) maxCompletedStageNumber = propertyScheduleDto.StageNumber;
                if (minPendingStageNumber == -1 && PRScheduleStageStatus.Pending == propertyScheduleDto.Status) minPendingStageNumber = propertyScheduleDto.StageNumber;
            }
            if (minPendingStageNumber >= 0 && minPendingStageNumber < maxCompletedStageNumber)
            {
                setNotyMsg(CommonUtil.getNotyErrorMsg("Stage cannot marked as Completed if prior stage is Pending."));
                isValid = false;
            }
        }
        return isValid;
    }
    //Stage Modal - Start
    private void initPymtScheduleModalFields()
    {
        lbPymtScheduleModalTitle.Text = (PymtScheduleAction.ADD.ToString().Equals(pymtScheduleModalActionHdnBtn.Value))
            ? Constants.ICON.ADD + Resources.Labels.ADD_STAGE : Constants.ICON.MODIFY + Resources.Labels.MODIFY_STAGE;
        PropertyScheduleDTO tmpDTO = getSelectedPymtSchedule(0);
        if (tmpDTO != null && PymtScheduleAction.MODIFY.ToString().Equals(pymtScheduleModalActionHdnBtn.Value))
        {
            if (tmpDTO.Id > 0 && tmpDTO.Status == PRScheduleStageStatus.Completed)
            {
                txtStage.ReadOnly = true;
                txtPercentage.ReadOnly = true;
            }
        }
    }
    private void initPymtScheduleSectionFields(PropertyScheduleDTO propertyScheduleDTO)
    {
        if (propertyScheduleDTO != null) lbStageNo.Text = propertyScheduleDTO.StageNumber.ToString(); else lbStageNo.Text = getNextStageNo().ToString();
        if (propertyScheduleDTO != null) txtStage.Text = propertyScheduleDTO.Stage; else txtStage.Text = null;
        if (propertyScheduleDTO != null) txtPercentage.Text = propertyScheduleDTO.Percentage.ToString(); else txtPercentage.Text = null;
        if (propertyScheduleDTO != null) drpStageStatus.Text = propertyScheduleDTO.Status.ToString(); else drpStageStatus.ClearSelection();
    }
    private void populatePymtScheduleFromUI(PropertyScheduleDTO propertyScheduleDTO)
    {
        propertyScheduleDTO.StageNumber = int.Parse(lbStageNo.Text);
        propertyScheduleDTO.Stage = txtStage.Text;
        propertyScheduleDTO.Percentage = CommonUtil.getDecimaNotNulllWithoutExt(txtPercentage.Text);
        propertyScheduleDTO.Status = EnumHelper.ToEnum<PRScheduleStageStatus>(drpStageStatus.Text);
        propertyScheduleDTO.UpdateUser = getUserDefinitionDTO().Username;
    }
    private PropertyScheduleDTO populatePymtScheduleAdd()
    {
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        PropertyScheduleDTO propertyScheduleDTO = new PropertyScheduleDTO();
        PropertyTowerDTO propertyTowerDto = new PropertyTowerDTO();
        propertyTowerDto.Id = long.Parse(drpPrTower.Text);
        propertyScheduleDTO.PropertyTower = propertyTowerDto;
        propertyScheduleDTO.FirmNumber = userDef.FirmNumber;
        propertyScheduleDTO.InsertUser = userDef.Username;
        return propertyScheduleDTO;
    }
    private void setSelectedPymtSchedule(long UiIndex)
    {
        List<PropertyScheduleDTO> tmpList = getPymtScheduleList();
        tmpList.ForEach(c => c.isUISelected = false);
        if (UiIndex > 0) tmpList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
    }
    private PropertyScheduleDTO getSelectedPymtSchedule(long UiIndex)
    {
        List<PropertyScheduleDTO> tmpList = getPymtScheduleList();
        return (UiIndex > 0) ? tmpList.Find(c => c.UiIndex == UiIndex) : tmpList.Find(c => c.isUISelected);
    }
    protected void onClickAddStageBtn(object sender, EventArgs e)
    {
        try
        {
            pymtScheduleModalActionHdnBtn.Value = PymtScheduleAction.ADD.ToString();
            initPymtScheduleModalFields();
            setSelectedPymtSchedule(-1);
            initPymtScheduleSectionFields(null);
            activeModalHdn.Value = addModifyPymtScheduleModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyStageBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            pymtScheduleModalActionHdnBtn.Value = PymtScheduleAction.MODIFY.ToString();
            setSelectedPymtSchedule(selectedIndex);
            initPymtScheduleModalFields();
            initPymtScheduleSectionFields(getSelectedPymtSchedule(0));
            activeModalHdn.Value = addModifyPymtScheduleModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void deletePymtScheduleStage(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            PropertyScheduleDTO tmpDTO = getSelectedPymtSchedule(selectedIndex);
            if (tmpDTO.Id == 0 || tmpDTO.Status == PRScheduleStageStatus.Pending)
            {
                List<PropertyScheduleDTO> scheduleList = getPymtScheduleList();
                scheduleList.Remove(tmpDTO);
                populatePymtScheduleSearchGrid(scheduleList);
                setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_DELETED_FROM_TABLE, "Stage " + tmpDTO.StageNumber.ToString())));
            }
            else
            {
                setNotyMsg(CommonUtil.getNotyErrorMsg(string.Format("Stage {0} is marked as Completed, cannot delete stage.", tmpDTO.StageNumber.ToString())));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void savePymtScheduleStage(object sender, EventArgs e)
    {
        try
        {
            if (validatePymtScheduleAddModify())
            {
                PropertyScheduleDTO tmpDTO = null;
                string msg = "";
                List<PropertyScheduleDTO> scheduleList = getPymtScheduleList();
                if (PymtScheduleAction.ADD.ToString().Equals(pymtScheduleModalActionHdnBtn.Value))
                {
                    tmpDTO = populatePymtScheduleAdd();
                    scheduleList.Add(tmpDTO);
                    msg = string.Format(Resources.Messages.RECOED_ADDED_TO_TABLE, "Stage " + lbStageNo.Text);
                }
                else
                {
                    tmpDTO = getSelectedPymtSchedule(0);
                    msg = string.Format(Resources.Messages.RECOED_MODIFIED_TO_TABLE, "Stage " + lbStageNo.Text);
                }
                populatePymtScheduleFromUI(tmpDTO);
                populatePymtScheduleSearchGrid(scheduleList);
                setNotyMsg(CommonUtil.getNotySuccessMsg(msg));
            }
            else
            {
                activeModalHdn.Value = addModifyPymtScheduleModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelPymtScheduleStage(object sender, EventArgs e)
    {
        try
        {
            setSelectedPymtSchedule(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private int getNextStageNo()
    {
        List<PropertyScheduleDTO> scheduleList = getPymtScheduleList();
        int stageNo = 1;
        foreach (PropertyScheduleDTO tmpDTO in scheduleList)
        {
            if (stageNo != tmpDTO.StageNumber) break;
            stageNo++;
        }
        return stageNo;
    }
    private bool validatePymtScheduleAddModify()
    {
        bool isValid = true;
        Page.Validate(addModifyPymtScheduleError);
        isValid = Page.IsValid;
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    //Address Modal - End
}