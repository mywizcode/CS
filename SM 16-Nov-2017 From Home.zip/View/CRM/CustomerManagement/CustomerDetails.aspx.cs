﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.BO;

public partial class CustomerDetails : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifyStep1Error = "addModifyStep1Error";
    string addModifyStep1Error1 = "addModifyStep1Error1";
    string addMasterDataError = "addMasterDataError";
    string addModifyAddressError = "addModifyAddressError";
    string addMasterDataModal = "addMasterDataModal";
    string addModifyAddressModal = "addModifyAddressModal";
    DropdownBO drpBO = new DropdownBO();
    CustomerBO customerBO = new CustomerBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    public enum AddressAction { ADD, MODIFY }
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                CustomerDetailNavDTO navDto = CommonUtil.getPageNavDTO<CustomerDetailNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_CUSTOMER)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        setPageTitle();
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpSalutation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.SALUTATION, null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpOccupation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.OCCUPATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<Gender>(drpGender, Constants.SELECT_ITEM);
        drpBO.drpEnum<MaritalStatus>(drpMaritalStatus, Constants.SELECT_ITEM);

        drpBO.drpDataBase(drpAddressCountry, DrpDataType.COUNTRY, null, null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAddressState, DrpDataType.STATE, Constants.DEFAULT_COUNTRY, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        initCityDrp(drpAddressCity, Constants.DEFAULT_STATE);
        drpBO.drpDataBase(drpAddressType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ADDRESS_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<PreferredAddress>(drpPreferredAddress, null);
    }
    private void initCityDrp(DropDownList drp, string stateId)
    {
        drpBO.drpDataBase(drp, DrpDataType.CITY, stateId, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void renderPageFieldsWithEntitlement()
    {
        bool modifyMode = isModifyMode();
        bool viewMode = isViewMode();
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        //Fields
        drpSalutation.Enabled = !viewMode;
        txtFirstName.ReadOnly = viewMode;
        txtMiddleName.ReadOnly = viewMode;
        txtLastName.ReadOnly = viewMode;
        drpGender.Enabled = !viewMode;
        txtDOB.ReadOnly = viewMode;
        drpMaritalStatus.Enabled = !viewMode;
        txtContact.ReadOnly = viewMode;
        txtAltContact.ReadOnly = viewMode;
        txtEmail.ReadOnly = viewMode;
        txtAltEmailID.ReadOnly = viewMode;
        drpOccupation.Enabled = !viewMode;
        txtPan.ReadOnly = viewMode;

        lnkAddAddress.Visible = !viewMode;
        if (addressGrid.Items.Count > 0)
        {
            foreach (ListViewItem item in addressGrid.Items)
            {
                LinkButton modifyBtn = (LinkButton)item.FindControl("lnkModifyAddress");
                if (modifyBtn != null) modifyBtn.Visible = !viewMode;
                LinkButton deleteBtn = (LinkButton)item.FindControl("lnkDeleteAddress");
                if (deleteBtn != null) deleteBtn.Visible = !viewMode;
            }
        }
        //Buttons
        btnAddModifyCustomerSubmit.Visible = !viewMode;
        addOccupation.Visible = !viewMode && CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_MANAGE_MASTER);

        liModifyCustomer.Visible = viewMode && CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.CUSTOMER_MODIFY);
    }
    private void setPageTitle()
    {
        if (isAddMode()) lbPageTitle.Text = Constants.ICON.ADD + Resources.Labels.ADD_CUSTOMER;
        else if (isModifyMode()) lbPageTitle.Text = Constants.ICON.MODIFY + Resources.Labels.MODIFY_CUSTOMER;
        else lbPageTitle.Text = Constants.ICON.VIEW_DTL + Resources.Labels.CUSTOMER_DETAILS;
    }
    private void doInit(CustomerDetailNavDTO navDto)
    {
        initDropdowns();
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(CustomerDetailNavDTO navDto)
    {
        if (navDto != null)
        {
            CustomerDetailPageDTO PageDTO = new CustomerDetailPageDTO();
            pageModeHdn.Value = navDto.Mode.ToString();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            pnlSoldUnits.Visible = false;
            if (isAddMode())
            {
                PageDTO.CustomerDTO = populateCustomerDTOAdd();
            }
            else
            {
                PageDTO.CustomerDTO = customerBO.fetchCustomerWithUnits(navDto.CustomerId);
                if (PageDTO.CustomerDTO.PrUnitSaleDetails != null && PageDTO.CustomerDTO.PrUnitSaleDetails.Count > 0)
                {
                    pnlSoldUnits.Visible = true;
                    soldUnitsGrid.DataSource = PageDTO.CustomerDTO.PrUnitSaleDetails;
                    soldUnitsGrid.DataBind();
                }
            }
            populateUIFieldsFromDTO(PageDTO.CustomerDTO);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private void navigateToPreviousPage()
    {
        CustomerDetailPageDTO PageDTO = getSessionPageData();
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is CustomerSearchNavDTO)
            {
                CustomerSearchNavDTO navDTO = (CustomerSearchNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.CUSTOMER_SEARCH, true);
            }
        }
        Response.Redirect(Constants.URL.CUSTOMER_SEARCH, true);
    }
    private bool isViewMode()
    {
        return PageMode.VIEW.ToString().Equals(pageModeHdn.Value);
    }
    private bool isAddMode()
    {
        return PageMode.ADD.ToString().Equals(pageModeHdn.Value);
    }
    private bool isModifyMode()
    {
        return PageMode.MODIFY.ToString().Equals(pageModeHdn.Value);
    }
    private CustomerDetailPageDTO getSessionPageData()
    {
        return (CustomerDetailPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    protected void onClickModifyCustomerBtn(object sender, EventArgs e)
    {
        try
        {
            CustomerDetailPageDTO PageDTO = getSessionPageData();
            CustomerDTO customerDTO = PageDTO.CustomerDTO;
            CustomerDetailNavDTO navDTO = new CustomerDetailNavDTO();
            navDTO.Mode = PageMode.MODIFY;
            navDTO.CustomerId = customerDTO.Id;
            navDTO.PrevNavDto = PageDTO.PrevNavDTO;
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.CUSTOMER_DETAILS, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void addOrModifyCustomer(object sender, EventArgs e)
    {
        try
        {
            if (validateCustomerAddOrModify())
            {
                CustomerDTO customerDTO = getSessionPageData().CustomerDTO;
                populateCustomerDTOFromUI(customerDTO);
                long Id = customerDTO.Id;
                string msg = "";
                if (isAddMode())
                {
                    Id = customerBO.saveCustomer(customerDTO);
                    msg = string.Format("Customer '{0}' is added successfully.", CommonUIConverter.getCustomerFullName(customerDTO.FirstName, customerDTO.LastName));
                }
                else if (isModifyMode())
                {
                    customerBO.updateCustomer(customerDTO);
                    msg = string.Format("Customer '{0}' is updated successfully.", CommonUIConverter.getCustomerFullName(customerDTO.FirstName, customerDTO.LastName));
                }
                Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg(msg));
                navigateToPreviousPage();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addModifyStep1Error);
        }
    }
    protected void cancelCustomer(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    /**
     * Define all validation which will be done before add or Modify property.
     * */
    private bool validateCustomerAddOrModify()
    {
        return validateStep1();
    }
    private bool validateAddressMandatory()
    {
        bool isValid = true;
        List<AddressDTO> addressList = getSessionPageData().CustomerDTO.ContactInfo.Addresses.ToList<AddressDTO>();
        if (addressList == null || addressList.Count == 0)
        {
            setErrorMessage(Resources.Messages.ADDRESS_MANDATORY, addModifyStep1Error);
            isValid = false;
        }
        else
        {
            int preferredCount = 0;
            foreach (AddressDTO addressDto in addressList)
            {
                if (PreferredAddress.Yes == addressDto.PreferredAddress) preferredCount++;
            }
            if (preferredCount == 0)
            {
                setErrorMessage(Resources.Messages.PRIMARY_ADDRESS_MANDATORY, addModifyStep1Error);
                isValid = false;
            }
            else if (preferredCount > 1)
            {
                setErrorMessage(Resources.Messages.PRIMARY_ADDRESS_MULTIPLE_NOT_ALLOWED, addModifyStep1Error);
                isValid = false;
            }
        }
        return isValid;
    }
    private bool validateStep1()
    {
        return validateMandatoryFields(addModifyStep1Error) && validateAddressMandatory();
    }
    private bool validateMandatoryFields(string valGrp)
    {
        Page.Validate(valGrp);
        bool isValid = Page.IsValid;
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    private CustomerDTO populateCustomerDTOAdd()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.ContactInfo = new ContactInfoDTO();
        customerDTO.ContactInfo.Addresses = new HashSet<AddressDTO>();
        customerDTO.FirmNumber = userDefDto.FirmNumber;
        customerDTO.InsertUser = userDefDto.Username;
        return customerDTO;
    }
    private void populateCustomerDTOFromUI(CustomerDTO customerDTO)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        customerDTO.Salutation = CommonUIConverter.getMasterControlDTO(drpSalutation.Text, null);
        customerDTO.FirstName = txtFirstName.Text;
        customerDTO.MiddleName = txtMiddleName.Text;
        customerDTO.LastName = txtLastName.Text;
        customerDTO.Occupation = CommonUIConverter.getMasterControlDTO(drpOccupation.Text, null);
        customerDTO.Pan = txtPan.Text;
        customerDTO.Nationality = CommonUIConverter.getCountryDTO("1", null);//TODO- replace 1 with UI value
        customerDTO.ContactInfo.Gender = EnumHelper.ToEnumNullable<Gender>(drpGender.Text);
        customerDTO.ContactInfo.Dob = DateUtil.getCSDate(txtDOB.Text);
        customerDTO.ContactInfo.MaritalStatus = EnumHelper.ToEnumNullable<MaritalStatus>(drpMaritalStatus.Text);
        customerDTO.ContactInfo.Contact = txtContact.Text;
        customerDTO.ContactInfo.AltContact = txtAltContact.Text;
        customerDTO.ContactInfo.Email = txtEmail.Text;
        customerDTO.ContactInfo.AltEmail = txtAltEmailID.Text;

        customerDTO.UpdateUser = userDefDto.Username;
        customerDTO.Version = userDefDto.Version;
    }
    private void populateUIFieldsFromDTO(CustomerDTO customerDTO)
    {
        if (customerDTO != null && customerDTO.Salutation != null) drpSalutation.Text = customerDTO.Salutation.Id.ToString(); else drpSalutation.ClearSelection();
        if (customerDTO != null) txtFirstName.Text = customerDTO.FirstName; else txtFirstName.Text = null;
        if (customerDTO != null) txtMiddleName.Text = customerDTO.MiddleName; else txtMiddleName.Text = null;
        if (customerDTO != null) txtLastName.Text = customerDTO.LastName; else txtLastName.Text = null;
        if (customerDTO != null && customerDTO.ContactInfo.Gender != null) drpGender.Text = customerDTO.ContactInfo.Gender.ToString(); else drpGender.ClearSelection();
        if (customerDTO != null && customerDTO.ContactInfo.Dob != null) txtDOB.Text = DateUtil.getCSDate(customerDTO.ContactInfo.Dob); else txtDOB.Text = null;
        if (customerDTO != null && customerDTO.ContactInfo.MaritalStatus != null) drpMaritalStatus.Text = customerDTO.ContactInfo.MaritalStatus.ToString(); else drpMaritalStatus.ClearSelection();
        if (customerDTO != null) txtContact.Text = customerDTO.ContactInfo.Contact; else txtContact.Text = null;
        if (customerDTO != null) txtAltContact.Text = customerDTO.ContactInfo.AltContact; else txtAltContact.Text = null;
        if (customerDTO != null) txtEmail.Text = customerDTO.ContactInfo.Email; else txtEmail.Text = null;
        if (customerDTO != null) txtAltEmailID.Text = customerDTO.ContactInfo.AltEmail; else txtAltEmailID.Text = null;
        if (customerDTO != null) txtPan.Text = customerDTO.Pan; else txtPan.Text = null;
        if (customerDTO != null) txtCustomerRefNo.Text = customerDTO.CustRefNo; else txtCustomerRefNo.Text = null;
        if (customerDTO != null && customerDTO.Occupation != null) drpOccupation.Text = customerDTO.Occupation.Id.ToString(); else drpOccupation.ClearSelection();

        populateAddressGrid(customerDTO.ContactInfo);
    }
    private void populateAddressGrid(ContactInfoDTO conactInfoDto)
    {
        addressGrid.DataSource = new List<AddressDTO>();
        if (conactInfoDto != null)
        {
            assignUiIndexToAddress(conactInfoDto.Addresses);
            addressGrid.DataSource = conactInfoDto.Addresses;
        }
        addressGrid.DataBind();
        pnlAddressEmpty.Visible = (conactInfoDto.Addresses == null || conactInfoDto.Addresses.Count == 0);
    }

    private void assignUiIndexToAddress(ISet<AddressDTO> addressDtos)
    {
        if (addressDtos != null && addressDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (AddressDTO addressDto in addressDtos)
            {
                addressDto.UiIndex = uiIndex++;
                addressDto.UiFullAddress = CommonUIConverter.getUiFullAddress(addressDto);
            }
        }
    }
    //Master Data Modal save logic - Start
    protected void saveMasterData(object sender, EventArgs e)
    {
        try
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (masterDataModalTypeHdn.Value == "OCCUPATION")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.OCCUPATION, txtMasterDataInput1.Text,
                        txtMasterDataInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Occupation");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpOccupation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.OCCUPATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
            }

            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                activeModalHdn.Value = addMasterDataModal;
                setErrorMessage(errorMsg, addMasterDataError);
            }
            else
            {
                resetMasterDataModalFields();
                setParentModalFlag();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            activeModalHdn.Value = "";
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    protected void cancelMasterDataModal(object sender, EventArgs e)
    {
        try
        {
            resetMasterDataModalFields();
            setParentModalFlag();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    private void resetMasterDataModalFields()
    {
        txtMasterDataInput1.Text = "";
        txtMasterDataInput2.Text = "";
        masterDataModalTypeHdn.Value = "";
    }
    private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
    {
        string errorMsg = "";
        if (string.IsNullOrWhiteSpace(masterDataDto.Name))
        {
            errorMsg = string.Format(Resources.Messages.TEXTFIELD_REQUIRED, type);
        }
        else if (masterDataBO.isAlreadyExist(masterDataDto))
        {
            errorMsg = string.Format(Resources.Messages.ALREADY_EXIST_DB_ERROR, type);
        }
        return errorMsg;
    }
    private void setParentModalFlag()
    {
        activeModalHdn.Value = masterDataParentModalHdn.Value;
        masterDataParentModalHdn.Value = "";
    }
    //Master Data Modal save logic - End
    //Address Modal - Start
    protected void loadAddressCities(object sender, EventArgs e)
    {
        try
        {
            initCityDrp(drpAddressCity, drpAddressState.Text);
            SetFocus(drpAddressCity);
            activeModalHdn.Value = addModifyAddressModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void initAddressModalFields()
    {
        lbAddressModalTitle.Text = (AddressAction.ADD.ToString().Equals(addressModalActionHdnBtn.Value))
            ? Constants.ICON.ADD + Resources.Labels.ADD_ADDRESS : Constants.ICON.MODIFY + Resources.Labels.MODIFY_ADDRESS;
    }
    private void initAddressSectionFields(AddressDTO addressDto)
    {
        if (addressDto != null) txtAddressLine1.Text = addressDto.AddressLine1; else txtAddressLine1.Text = null;
        if (addressDto != null) txtAddressLine2.Text = addressDto.AddressLine2; else txtAddressLine2.Text = null;
        if (addressDto != null) txtTown.Text = addressDto.Town; else txtTown.Text = null;
        if (addressDto != null && addressDto.City != null) drpAddressCity.Text = addressDto.City.Id.ToString(); else drpAddressCity.ClearSelection();
        if (addressDto != null && addressDto.State != null) drpAddressState.Text = addressDto.State.Id.ToString(); else drpAddressState.ClearSelection();
        if (addressDto != null && addressDto.Country != null) drpAddressCountry.Text = addressDto.Country.Id.ToString(); else drpAddressCountry.ClearSelection();
        if (addressDto != null) txtPin.Text = addressDto.Pin; else txtPin.Text = null;
        if (addressDto != null && addressDto.AddressType != null) drpAddressType.Text = addressDto.AddressType.Id.ToString(); else drpAddressType.ClearSelection();
        if (addressDto != null && addressDto.PreferredAddress != null) drpPreferredAddress.Text = addressDto.PreferredAddress.ToString(); else drpPreferredAddress.ClearSelection();
    }
    private void populateAddressFromUI(AddressDTO addressDto)
    {
        addressDto.AddressLine1 = txtAddressLine1.Text;
        addressDto.AddressLine2 = txtAddressLine2.Text;
        addressDto.Town = txtTown.Text;
        addressDto.City = CommonUIConverter.getCityDTO(drpAddressCity.Text, drpAddressCity.SelectedItem.Text);
        addressDto.State = CommonUIConverter.getStateDTO(drpAddressState.Text, drpAddressState.SelectedItem.Text);
        addressDto.Country = CommonUIConverter.getCountryDTO(drpAddressCountry.Text, drpAddressCountry.SelectedItem.Text);
        addressDto.Pin = txtPin.Text;
        addressDto.AddressType = CommonUIConverter.getMasterControlDTO(drpAddressType.Text, drpAddressType.SelectedItem.Text);
        addressDto.PreferredAddress = EnumHelper.ToEnumNullable<PreferredAddress>(drpPreferredAddress.Text);
    }
    private AddressDTO populateAddressAdd()
    {
        AddressDTO addressDto = new AddressDTO();
        return addressDto;
    }
    private void setSelectedAddress(long UiIndex)
    {
        List<AddressDTO> addressList = getSessionPageData().CustomerDTO.ContactInfo.Addresses.ToList<AddressDTO>();
        addressList.ForEach(c => c.isUISelected = false);
        if (UiIndex > 0) addressList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
    }
    private AddressDTO getSelectedAddress(long UiIndex)
    {
        List<AddressDTO> addressList = getSessionPageData().CustomerDTO.ContactInfo.Addresses.ToList<AddressDTO>();
        return (UiIndex > 0) ? addressList.Find(c => c.UiIndex == UiIndex) : addressList.Find(c => c.isUISelected);
    }
    protected void onClickAddAddressBtn(object sender, EventArgs e)
    {
        try
        {
            addressModalActionHdnBtn.Value = AddressAction.ADD.ToString();
            initAddressModalFields();
            setSelectedAddress(-1);
            initAddressSectionFields(null);
            activeModalHdn.Value = addModifyAddressModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyAddressBtn(object sender, EventArgs e)
    {
        try
        {
            addressModalActionHdnBtn.Value = AddressAction.MODIFY.ToString();
            initAddressModalFields();
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedAddress(selectedIndex);
            initAddressSectionFields(getSelectedAddress(0));
            activeModalHdn.Value = addModifyAddressModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void deleteAddress(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            AddressDTO addressDTO = getSelectedAddress(selectedIndex);
            getSessionPageData().CustomerDTO.ContactInfo.Addresses.Remove(addressDTO);
            populateAddressGrid(getSessionPageData().CustomerDTO.ContactInfo);
            setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECORD_DELETE_SUCCESS, "Address")));
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void saveAddress(object sender, EventArgs e)
    {
        try
        {
            if (validateAddressAddModify())
            {
                AddressDTO addressDTO = null;
                string msg = "";
                if (AddressAction.ADD.ToString().Equals(addressModalActionHdnBtn.Value))
                {
                    addressDTO = populateAddressAdd();
                    getSessionPageData().CustomerDTO.ContactInfo.Addresses.Add(addressDTO);
                    msg = string.Format(Resources.Messages.RECORD_ADDED_SUCCESS, "Address");
                }
                else
                {
                    addressDTO = getSelectedAddress(0);
                    msg = string.Format(Resources.Messages.RECORD_MODIFY_SUCCESS, "Address");
                }
                populateAddressFromUI(addressDTO);
                populateAddressGrid(getSessionPageData().CustomerDTO.ContactInfo);
                setNotyMsg(CommonUtil.getNotySuccessMsg(msg));
            }
            else
            {
                activeModalHdn.Value = addModifyAddressModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelAddressModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateAddressAddModify()
    {
        bool isValid = true;
        Page.Validate(addModifyAddressError);
        isValid = Page.IsValid;
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    //Address Modal - End
}