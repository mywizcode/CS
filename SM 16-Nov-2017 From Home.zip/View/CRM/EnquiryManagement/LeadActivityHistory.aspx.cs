﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using ConstroSoft.Logic.BO;

public partial class LeadActivityHistory : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string selectUserAssigneeModalError = "selectUserAssigneeModalError";
    string addEventTaskModalError = "addEventTaskModalError";
    string addEventTaskModalError1 = "addEventTaskModalError1";

    string selectUserAssigneeModal = "selectUserAssigneeModal";
    string addEventTaskModal = "addEventTaskModal";
    DropdownBO drpBO = new DropdownBO();
    EnquiryBO enquiryBO = new EnquiryBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                LeadActivityHistoryNavDTO navDto = CommonUtil.getPageNavDTO<LeadActivityHistoryNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_MY_LEADS)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();

    }
    private void preRenderInitFormElements()
    {
        renderPageLayout();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        drpBO.populateDrpEnqEventActivity(drpEventActivityType);

        drpBO.drpDataBase(drpUserAssignee, DrpDataType.ACTIVE_USERS_WITH_PR_ACCESS, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(),
            Constants.SELECT_ITEM, userDefDto.FirmNumber);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(LeadActivityHistoryNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(LeadActivityHistoryNavDTO navDto)
    {
        try
        {
            LeadActivityHistoryPageDTO PageDTO = new LeadActivityHistoryPageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            fetchLeadAndInitHistory(navDto.LeadId);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageLayout()
    {
    }
    private LeadActivityHistoryPageDTO getSessionPageData()
    {
        return (LeadActivityHistoryPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private LeadDetailDTO getLeadDetailDTO()
    {
        return getSessionPageData().LeadDTO;
    }
    private void navigateToPreviousPage()
    {
        LeadActivityHistoryPageDTO pageDTO = getSessionPageData();
        if (pageDTO != null && pageDTO.PrevNavDTO != null)
        {
            object obj = pageDTO.PrevNavDTO;
            if (obj is MyLeadsNavDTO)
            {
                MyLeadsNavDTO navDTO = (MyLeadsNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.MY_LEADS, true);
            }
            else if (obj is UserLeadHistoryNavDTO)
            {
                UserLeadHistoryNavDTO navDTO = (UserLeadHistoryNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.USER_LEAD_HISTORY, true);
            }
        }
        Response.Redirect(Constants.URL.MY_LEADS, true);
    }
    private void fetchLeadAndInitHistory(long LeadId)
    {
        LeadDetailDTO leadDTO = enquiryBO.fetchLeadDetails(LeadId, true);
        LeadActivityHistoryPageDTO pageDTO = getSessionPageData();
        pageDTO.LeadDTO = leadDTO;
        initPageInfo(leadDTO);
    }
    private void initPageInfo(LeadDetailDTO leadDTO)
    {
        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        leadDTO.Assignee.FullName = CommonUIConverter.getCustomerFullName(leadDTO.Assignee.FirstName, leadDTO.Assignee.LastName);
        if (leadDTO.LeadActivities.Count > 0)
        {
            List<LeadActivityDTO> list = new List<LeadActivityDTO>(leadDTO.LeadActivities);
            leadDTO.LeadActivities.Clear();
            leadDTO.LeadActivities = new HashSet<LeadActivityDTO>(list.OrderByDescending(x => x.DateLogged).ThenByDescending(x => x.InsertDate));
        }
        //Lead Detail Panel
        ulLeadDetailOptions.Visible = (leadDTO.Status == LeadStatus.Open);
        lbCustomerName.Text = CommonUIConverter.getCustomerFullName(leadDTO.Salutation.Name, leadDTO.FirstName, "", leadDTO.LastName);
        lbCustomerContact.Text = leadDTO.ContactInfo.Contact;
        btnLeadInfoHdn.Attributes["row-info"] = CommonUIConverter.getGridViewRowInfo(leadDTO);
        lbLeadAssignee.Text = leadDTO.Assignee.FullName;
        lbLeadRefNo.Text = leadDTO.LeadRefNo;
        lbEnquiryRefNo.Text = (leadDTO.EnquiryDetail != null) ? leadDTO.EnquiryDetail.EnquiryRefNo : null;
        pnlEnquiryRefNo.Visible = leadDTO.EnquiryDetail != null;
        lbLeadSource.Text = (leadDTO.Source != null) ? leadDTO.Source.Name : null;
        lbLeadBudget.Text = (leadDTO.Budget != null) ? leadDTO.Budget.ToString() : null;
        lbLeadStatus.Text = leadDTO.Status.ToString();
        //Populate Activity History
        populateActivityGrid(leadDTO);
        //Upcoming Event Panel
        populateUpcomingTasks(leadDTO);
    }
    private void populateUpcomingTasks(LeadDetailDTO leadDTO)
    {
        leadDTO.UpcomingEvents = new List<LeadActivityDTO>();
        ISet<LeadActivityDTO> activities = leadDTO.LeadActivities;
        if (activities != null && activities.Count > 0)
        {
            foreach (LeadActivityDTO activityDTO in activities)
            {
                if (activityDTO.RecordType == EnqActivityRecordType.Task && activityDTO.Status == EnqLeadActivityStatus.Open)
                {
                    leadDTO.UpcomingEvents.Add(activityDTO);
                }
            }
        }
        ulUpcomingTaskOptions.Visible = (leadDTO.Status == LeadStatus.Open);
        pnlUpcomingEventTaskEmpty.Visible = leadDTO.UpcomingEvents.Count == 0;
        upcomingEventTaskGrid.Visible = leadDTO.UpcomingEvents.Count > 0;
        upcomingEventTaskGrid.DataSource = leadDTO.UpcomingEvents;
        upcomingEventTaskGrid.DataBind();
    }
    private void populateActivityGrid(LeadDetailDTO leadDTO)
    {
        activityHistoryGrid.DataSource = new List<LeadActivityDTO>();
        if (leadDTO != null && leadDTO.LeadActivities.Count > 0)
        {
            assignUiIndexToActivity(leadDTO);
            activityHistoryGrid.DataSource = leadDTO.LeadActivities;
        }
        activityHistoryGrid.DataBind();
    }
    private void assignUiIndexToActivity(LeadDetailDTO leadDTO)
    {
        ISet<LeadActivityDTO> activities = leadDTO.LeadActivities;
        if (activities != null && activities.Count > 0)
        {
            long uiIndex = 1;
            foreach (LeadActivityDTO activityDTO in activities)
            {
                activityDTO.UiIndex = uiIndex++;
                activityDTO.RowInfo = CommonUIConverter.getGridViewRowInfo(activityDTO);
                activityDTO.LoggedBy.FullName = CommonUIConverter.getCustomerFullName(activityDTO.LoggedBy.FirstName, activityDTO.LoggedBy.LastName);
                activityDTO.LeadDetail = leadDTO;
                if (activityDTO.RecordType == EnqActivityRecordType.Task && !string.IsNullOrWhiteSpace(activityDTO.RevRefNo))
                {
                    LeadActivityDTO eventDTO = activities.ToList<LeadActivityDTO>().Find(x => !string.IsNullOrWhiteSpace(x.RefNo) && x.RefNo == activityDTO.RevRefNo);
                    activityDTO.PrevScheduledDate = eventDTO.ScheduledDate;
                }
            }
        }
    }
    private LeadActivityHistoryNavDTO getCurrentPageNavigation()
    {
        LeadActivityHistoryPageDTO PageDTO = getSessionPageData();
        LeadActivityHistoryNavDTO navDTO = new LeadActivityHistoryNavDTO();
        navDTO.LeadId = PageDTO.LeadDTO.Id;
        navDTO.PrevNavDto = PageDTO.PrevNavDTO;
        return navDTO;
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickReassignLeadBtn(object sender, EventArgs e)
    {
        try
        {
            LeadDetailDTO leadDTO = getLeadDetailDTO();
            if (leadDTO.Status == LeadStatus.Open)
            {
                drpUserAssignee.ClearSelection();
                activeModalHdn.Value = selectUserAssigneeModal;
            }
            else
            {
                setNotyMsg(CommonUtil.getNotyErrorMsg(Resources.Messages.ERROR_LEAD_REASSIGN_NOT_OPEN));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickCloseLeadBtn(object sender, EventArgs e)
    {
        try
        {
            //TODO- we would need confirmation from user before closing lead.
            LeadDetailDTO leadDTO = getLeadDetailDTO();
            if (leadDTO.Status == LeadStatus.Open)
            {
                enquiryBO.closeLead(leadDTO.Id, getUserDefinitionDTO());
                fetchLeadAndInitHistory(leadDTO.Id);
                setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format("Lead# {0} is closed successfully.", leadDTO.LeadRefNo)));
            }
            else
            {
                setNotyMsg(CommonUtil.getNotyErrorMsg(Resources.Messages.ERROR_LEAD_CLOSE_NOT_OPEN));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickConvertToEnquiryBtn(object sender, EventArgs e)
    {
        try
        {
            LeadDetailDTO leadDTO = getLeadDetailDTO();
            if (validateConvertToEnquiry(leadDTO))
            {
                EnquiryDetailNavDTO navDTO = new EnquiryDetailNavDTO();
                navDTO.Mode = PageMode.ADD;
                navDTO.ConvertedLeadId = leadDTO.Id;
                navDTO.PrevNavDto = getCurrentPageNavigation();
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.ENQUIRY_DETAILS, true);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateConvertToEnquiry(LeadDetailDTO leadDTO)
    {
        if (leadDTO.Status != LeadStatus.Open)
        {
            setNotyMsg(CommonUtil.getNotyErrorMsg(Resources.Messages.ERROR_LEAD_CONVERT_NOT_OPEN));
            return false;
        }
        return true;
    }
    private void selectUpcomingEvent(long EventId)
    {
        LeadDetailDTO leadDetailDTO = getLeadDetailDTO();
        leadDetailDTO.UpcomingEvents.ForEach(x => x.isUISelected = false);
        if (EventId > 0)
        {
            leadDetailDTO.UpcomingEvents.Find(x => x.Id == EventId).isUISelected = true;
        }
    }
    private EnqActivityMode getEnqActivityMode()
    {
        return EnumHelper.ToEnum<EnqActivityMode>(leadActivityModeHdn.Value);
    }
    private void setEnqActivityMode(EnqActivityMode action)
    {
        leadActivityModeHdn.Value = action.ToString();
    }
    protected string getActivityDesc(string activityType)
    {
        return EnumHelper.ToEnum<EnqActivityType>(activityType).GetDescription();
    }

    //Add Event Modal - Start
    private LeadActivityDTO getSelectedUpcomingEvent()
    {
        List<LeadActivityDTO> upcomingEventList = getLeadDetailDTO().UpcomingEvents.ToList<LeadActivityDTO>();
        return upcomingEventList.Find(c => c.isUISelected);
    }
    private void resetEventTaskModalFields()
    {
        txtEventLoggedDate.Text = DateUtil.getTodayDate();
        txtEventScheduledDate.Text = null;
        txtEventComments.Text = null;
        drpEventActivityType.Text = null;
        drpEventActivityType.Enabled = true;
        pnlEventTaskInfo.Visible = false;
        pnlEventScheduleDate.Visible = true;
        EnqActivityMode mode = getEnqActivityMode();
        if (mode == EnqActivityMode.ADD_TASK)
        {
            drpEventActivityType.Text = EnqActivityType.TASK.ToString();
            drpEventActivityType.Enabled = false;
            lbEventTaskModalHeader.Text = Constants.ICON.ENQUIRY_ADD_TASK + Resources.Labels.ADD_TASK;
        }
        else if (mode == EnqActivityMode.RESCHEDULE_TASK)
        {
            LeadActivityDTO eventDTO = getSelectedUpcomingEvent();
            drpEventActivityType.Text = eventDTO.ActivityType.ToString();
            drpEventActivityType.Enabled = false;
            lbEventTaskModalHeader.Text = Constants.ICON.RESCHEDULE_TASK + Resources.Labels.RESCHEDULE_TASK;
            pnlEventTaskInfo.Visible = true;
            lbEventTaskInfoLabel.Text = "Current Scheduled Date: ";
            lbEventTaskInfoValue.Text = DateUtil.getCSDateTime(eventDTO.ScheduledDate);
        }
        else if (mode == EnqActivityMode.COMPLETE_TASK)
        {
            LeadActivityDTO eventDTO = getSelectedUpcomingEvent();
            drpEventActivityType.Text = eventDTO.ActivityType.ToString();
            drpEventActivityType.Enabled = false;
            pnlEventScheduleDate.Visible = false;
            lbEventTaskModalHeader.Text = Constants.ICON.COMPLETE_TASK + Resources.Labels.TASK_COMPLETED;
            pnlEventTaskInfo.Visible = true;
            lbEventTaskInfoLabel.Text = "Task# ";
            lbEventTaskInfoValue.Text = eventDTO.RefNo;
        }
        else if (mode == EnqActivityMode.CANCEL_TASK)
        {
            LeadActivityDTO eventDTO = getSelectedUpcomingEvent();
            drpEventActivityType.Text = eventDTO.ActivityType.ToString();
            drpEventActivityType.Enabled = false;
            pnlEventScheduleDate.Visible = false;
            lbEventTaskModalHeader.Text = Constants.ICON.CANCEL_TASK + Resources.Labels.CANCEL_TASK;
            pnlEventTaskInfo.Visible = true;
            lbEventTaskInfoLabel.Text = "Task# ";
            lbEventTaskInfoValue.Text = eventDTO.RefNo;
        }
    }
    private void initEventModalAction(EnqActivityMode mode, long selectedIndex)
    {
        setEnqActivityMode(mode);
        selectUpcomingEvent(selectedIndex);
        resetEventTaskModalFields();
        activeModalHdn.Value = addEventTaskModal;
    }
    protected void onClickAddTaskBtn(object sender, EventArgs e)
    {
        try
        {
            initEventModalAction(EnqActivityMode.ADD_TASK, 0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickRescheduleTaskBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            initEventModalAction(EnqActivityMode.RESCHEDULE_TASK, selectedIndex);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickCompleteTaskBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            initEventModalAction(EnqActivityMode.COMPLETE_TASK, selectedIndex);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickCancelTaskBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            initEventModalAction(EnqActivityMode.CANCEL_TASK, selectedIndex);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void addEventTask(object sender, EventArgs e)
    {
        try
        {
            if (validateAddEventTask())
            {
                LeadDetailDTO leadDTO = getLeadDetailDTO();
                EnqActivityRecordType recordType = EnqActivityRecordType.Task;
                LeadActivityDTO eventTaskDTO = CommonUtil.createNewLeadActivityDTO(leadDTO.Id, recordType, getUserDefinitionDTO());
                eventTaskDTO.EventTaskMode = getEventTaskMode();
                eventTaskDTO.DateLogged = DateUtil.getCSDateNotNull(txtEventLoggedDate.Text);
                eventTaskDTO.LoggedBy = getUserDefinitionDTO().FirmMember;
                eventTaskDTO.ActivityType = EnumHelper.ToEnum<EnqActivityType>(drpEventActivityType.Text);
                eventTaskDTO.ScheduledDate = DateUtil.getCSDateTime(txtEventScheduledDate.Text); ;
                eventTaskDTO.Comments = txtEventComments.Text;
                eventTaskDTO.Status = (getEnqActivityMode() == EnqActivityMode.CANCEL_TASK || getEnqActivityMode() == EnqActivityMode.COMPLETE_TASK) ?
                                        EnqLeadActivityStatus.Completed : EnqLeadActivityStatus.Open;

                long parentId = 0;
                LeadActivityDTO parentEventDTO = getSelectedUpcomingEvent();
                if (parentEventDTO != null)
                {
                    parentId = parentEventDTO.Id;
                    eventTaskDTO.RevRefNo = parentEventDTO.RefNo;
                }

                eventTaskDTO.RefNo = enquiryBO.addLeadActivity(leadDTO.Id, eventTaskDTO, getEnqActivityMode(), parentId);
                setEventTaskModalSuccessMsg(eventTaskDTO);
                setEnqActivityMode(EnqActivityMode.NONE);
                fetchLeadAndInitHistory(leadDTO.Id);
            }
            else
            {
                activeModalHdn.Value = addEventTaskModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setEventTaskModalSuccessMsg(LeadActivityDTO eventTaskDTO)
    {
        string msg = "";
        EnqActivityMode mode = getEnqActivityMode();
        if (mode == EnqActivityMode.ADD_TASK) msg = string.Format("Task# {0} is scheduled successfully.", eventTaskDTO.RefNo);
        else if (mode == EnqActivityMode.RESCHEDULE_TASK) msg = string.Format("Task# {0} is rescheduled successfully.", eventTaskDTO.RevRefNo);
        else if (mode == EnqActivityMode.COMPLETE_TASK) msg = string.Format("Task# {0} is completed successfully.", eventTaskDTO.RevRefNo);
        else if (mode == EnqActivityMode.CANCEL_TASK) msg = string.Format("Task# {0} is cancelled successfully.", eventTaskDTO.RevRefNo);

        setNotyMsg(CommonUtil.getNotySuccessMsg(msg));
    }
    private EventTaskMode getEventTaskMode()
    {
        EventTaskMode eventTaskMode = EventTaskMode.None;
        EnqActivityMode mode = getEnqActivityMode();
        if (mode == EnqActivityMode.ADD_TASK) eventTaskMode = EventTaskMode.Scheduled;
        else if (mode == EnqActivityMode.RESCHEDULE_TASK) eventTaskMode = EventTaskMode.Rescheduled;
        else if (mode == EnqActivityMode.COMPLETE_TASK) eventTaskMode = EventTaskMode.None;
        else if (mode == EnqActivityMode.CANCEL_TASK) eventTaskMode = EventTaskMode.Cancelled;

        return eventTaskMode;
    }
    protected void cancelAddEventTaskModal(object sender, EventArgs e)
    {
        try
        {
            setEnqActivityMode(EnqActivityMode.NONE);
            selectUpcomingEvent(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateAddEventTask()
    {
        string valGrp = addEventTaskModalError;
        if (getEnqActivityMode() == EnqActivityMode.CANCEL_TASK) valGrp = addEventTaskModalError1;
        Page.Validate(valGrp);
        bool isValid = Page.IsValid;
        if (!isValid)
        {
            DateTime dateLogged = DateUtil.getCSDateNotNull(txtEventLoggedDate.Text); ;
            isValid = validateDateLogged(dateLogged, addEventTaskModalError);
        }
        return isValid;
    }
    private bool validateDateLogged(DateTime dateLogged, string errorGrp)
    {
        bool isValid = true;
        EnqActivityMode mode = getEnqActivityMode();
        if (mode != EnqActivityMode.ADD_ACTIVITY)
        {
            LeadActivityDTO parentEventDTO = getSelectedUpcomingEvent();
            if (parentEventDTO != null && parentEventDTO.DateLogged.CompareTo(dateLogged) < 0)
            {
                string msg = "Date Logged cannot be less than {0}";
                setErrorMessage(string.Format(msg, parentEventDTO.RefNo), errorGrp);
                isValid = false;
            }
        }
        return isValid;
    }
    //Add Event Modal - End
    //User Assignee Selection logic - start
    protected void ReassignLead(object sender, EventArgs e)
    {
        try
        {
            Page.Validate(selectUserAssigneeModalError);
            bool isValid = Page.IsValid;
            if (isValid)
            {
                long AssigneeId = long.Parse(drpUserAssignee.Text);
                LeadDetailDTO LeadDTO = getLeadDetailDTO();
                enquiryBO.ReAssignLead(LeadDTO.Id, AssigneeId, DateTime.Today, getUserDefinitionDTO());
                Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotySuccessMsg(string.Format("Lead# {0} is reassigneed successfully.", LeadDTO.LeadRefNo)));
                navigateToPreviousPage();
            }
            else
            {
                activeModalHdn.Value = selectUserAssigneeModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelUserAssigneeModal(object sender, EventArgs e)
    {
        try
        {
            
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //User Assignee Selection logic - end
}
