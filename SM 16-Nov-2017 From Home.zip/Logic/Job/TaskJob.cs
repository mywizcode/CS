﻿using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;

namespace ConstroSoft.Logic.Job
{
    public class TaskJob : IJob
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        JobHistoryBO jobHistoryBO = new JobHistoryBO();
        private static readonly object locker = new object();

        public void Execute(IJobExecutionContext context)
        {
            JobHistoryDTO jobHistoryDTO = new JobHistoryDTO();
            string message = "Job Completed Successfully.";
            try{
               var schedulerContext = context.Scheduler.Context;
                JobDTO jobDTO = (JobDTO)schedulerContext.Get(Constants.TASK_JOB);
                UserDefinitionDTO userDefinitionDTO = (UserDefinitionDTO)schedulerContext.Get("UserDefinitionDTO");
                populateJobHistoryAddDto(jobHistoryDTO, jobDTO, userDefinitionDTO);
                long Id =jobHistoryBO.saveJobHistory(jobHistoryDTO);
                jobHistoryDTO.Id = Id;
                IList<TaskDTO> taskDtos = null;
                //TO DO Fetch New leads, due task & events & create TaskDTO.
                Dictionary<string, IList<TaskDTO>> taskDict = new Dictionary<string, IList<TaskDTO>>();
                foreach (TaskDTO taskDTO in taskDtos)
                {
                    IList<TaskDTO> tasks = new List<TaskDTO>();
                    string key = taskDTO.UserName + "-" + taskDTO.PropertyId;
                    if (taskDict.ContainsKey(key))
                    {
                        tasks = (IList<TaskDTO>)taskDict[key];
                        tasks.Add(taskDTO);
                    }
                    else
                    {
                        tasks.Add(taskDTO);
                        taskDict.Add(key, tasks);
                    }
                }
                lock (locker)
                {
                    foreach (KeyValuePair<string, IList<TaskDTO>> entry in taskDict)
                    {
                        HttpRuntime.Cache.Remove(entry.Key + "-Task");
                        HttpRuntime.Cache.Insert(entry.Key + "-Task", entry.Value);
                    }
                }
                
            }catch (Exception exp)
            {
                message = exp.Message;
                log.Error(exp.Message, exp);
            }finally{
                populateJobHistoryUpdateDto(jobHistoryDTO, message);
                jobHistoryBO.updatejobHistoryDetails(jobHistoryDTO);
            }
           
        }
        
        private void populateJobHistoryAddDto(JobHistoryDTO jobHistoryDTO, JobDTO jobDTO, UserDefinitionDTO userDefinitionDTO)
        {
            jobHistoryDTO.StartTime = DateTime.Now;
            jobHistoryDTO.JobRunStatus = JobRunStatus.INPROGRESS;
            jobHistoryDTO.Job = jobDTO;
            jobHistoryDTO.FirmNumber = userDefinitionDTO.FirmNumber;
            jobHistoryDTO.Version = userDefinitionDTO.Version;
            jobHistoryDTO.InsertUser = userDefinitionDTO.Username;
            jobHistoryDTO.UpdateUser = userDefinitionDTO.Username;
            jobHistoryDTO.InsertDate = DateTime.Now;
            jobHistoryDTO.UpdateDate = DateTime.Now;
        }

        private void populateJobHistoryUpdateDto(JobHistoryDTO jobHistoryDTO, string message)
        {
            jobHistoryDTO.EndTime = DateTime.Now;
            if(message != null){
                jobHistoryDTO.JobRunStatus = JobRunStatus.FAILURE;
                jobHistoryDTO.Message = message;
            }else{
                jobHistoryDTO.JobRunStatus = JobRunStatus.SUCCESS;
                jobHistoryDTO.Message = "Job execution completed successfully.";
            }
           jobHistoryDTO.UpdateDate = DateTime.Now;
        }
    }
}