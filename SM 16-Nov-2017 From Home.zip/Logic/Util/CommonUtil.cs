﻿
/// <summary>
/// Summary description for CommonUtil
/// </summary>
using ConstroSoft;
using System.Collections.Generic;
using NHibernate.Criterion;
using System.Linq.Expressions;
using System.Linq;
using NHibernate.Impl;
using System;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Web;
using OfficeOpenXml;
using OfficeOpenXml.DataValidation;
using System.Web.Hosting;
namespace ConstroSoft
{
    public class CommonUtil
    {
        public CommonUtil() { }
        public static string getRandomRefNo()
        {
            Random rd = new Random();
            return "" + rd.Next(100, 10000);
        }
        public static string getActivityRefNo(long Id, EnqActivityRecordType recordType)
        {
            string RefNo = (1000 + Id).ToString();
            if (recordType == EnqActivityRecordType.Activity) RefNo = "A" + RefNo;
            else if (recordType == EnqActivityRecordType.Action) RefNo = "S" + RefNo;
            else if (recordType == EnqActivityRecordType.Event) RefNo = "E" + RefNo;
            else if (recordType == EnqActivityRecordType.Task) RefNo = "T" + RefNo;
            return RefNo;
        }
        public static string getLeadRefNo(long Id)
        {
            return "LD" + (1000 + Id).ToString();
        }
        public static string getEnquiryRefNo(long Id)
        {
            return "EQ" + (1000 + Id).ToString();
        }
        public static string getCustomerRefNo(long Id)
        {
            return "C" + (1000 + Id).ToString();
        }
        public static string getMasterTxRefNo(long Id)
        {
            return "" + (1000 + Id).ToString();
        }
        public static string getBookingRefNo(string propertyName, string towerName, long saleId)
        {
            return propertyName[0].ToString() + towerName[0].ToString() + (1000 + saleId).ToString();
        }
        public static bool isSessionActive(System.Web.SessionState.HttpSessionState Session)
        {
            return (Session[Constants.Session.USERNAME] != null && (Session[Constants.Session.USERNAME]).ToString().Trim() != "") ? true : false;
        }
        public static string getSessionNotyMsg(System.Web.SessionState.HttpSessionState Session)
        {
            string msg = "";
            if(Session[Constants.Session.NOTY_MSG] != null && (Session[Constants.Session.NOTY_MSG]).ToString().Trim() != "") {
                msg = (Session[Constants.Session.NOTY_MSG]).ToString();
                Session.Remove(Constants.Session.NOTY_MSG);
            }
            return msg;
        }
        public static string getAppendedNotyMsg(string msg1, string msg2)
        {
            if (string.IsNullOrWhiteSpace(msg1)) return msg2;
            else if (string.IsNullOrWhiteSpace(msg2)) return msg1;
            return msg1 + Constants.SEP1 + msg2;
        }
        public static string getNotySuccessMsg(string msg)
        {
            return Constants.NOTY_TYPE.SUCCESS + Constants.SEP2 + msg;
        }
        public static string getNotyErrorMsg(string msg)
        {
            return Constants.NOTY_TYPE.ERROR + Constants.SEP2 + msg;
        }
        public static string getNotyWarningMsg(string msg)
        {
            return Constants.NOTY_TYPE.WARNING + Constants.SEP2 + msg;
        }
        public static string getNotyInfoMsg(string msg)
        {
            return Constants.NOTY_TYPE.INFO + Constants.SEP2 + msg;
        }
        public static void clearSession(System.Web.SessionState.HttpSessionState Session, HttpApplicationState Application)
        {
            string userLoggedIn = Session["USERNAME"] == null ? string.Empty : (string)Session["USERNAME"];
            if (userLoggedIn.Length > 0)
            {
                System.Collections.Generic.List<string> d = Application["LOGGED_IN_USERS"]
                    as System.Collections.Generic.List<string>;
                if (d != null)
                {
                    lock (d)
                    {
                        d.Remove(userLoggedIn);
                    }
                }
            }
            Session["USERNAME"] = "";
            Session[Constants.Session.USERDEFINITION] = "";
        }
        public static string getErrorMessage(Exception exp)
        {
            string message = Resources.Messages.system_error;
            if (exp is CustomException) message = exp.Message;
            return message;
        }
        public static T getPageNavDTO<T>(System.Web.SessionState.HttpSessionState Session)
        {
            object navObj = Session[Constants.Session.NAV_DTO];
            Session.Remove(Constants.Session.NAV_DTO);
            Session.Remove(Constants.Session.PAGE_DATA);
            if (navObj is T) return (T)navObj;
            else return default(T);
        }
        public static bool hasEntitlement(UserDefinitionDTO userDefDto, params string[] entitlements)
        {
            bool result = false;
            if (userDefDto != null && userDefDto.UserRole.EntitlementAssigned != null)
            {
                foreach (string str in entitlements)
                {
                    result = userDefDto.UserRole.EntitlementAssigned.Contains(str);
                    if (result) break;
                }
            }
            return result;
        }
        public static PropertyProjection BuildProjection<T>(Expression<Func<object>> aliasExpression, Expression<Func<T, object>> propertyExpression)
        {
            string alias = ExpressionProcessor.FindMemberExpression(aliasExpression.Body);
            string property = ExpressionProcessor.FindMemberExpression(propertyExpression.Body);

            return Projections.Property(string.Format("{0}.{1}", alias, property));
        }
        public static string removeAppenders(string strTemp)
        {
            string result = "";
            if (!string.IsNullOrWhiteSpace(strTemp))
            {
                foreach(string appender in Constants.APPENDERS) {
                    strTemp = strTemp.Replace(appender, "");
                }
                result = strTemp.Trim();
            }
            return result;
        }
        public static decimal? getDecimalWithoutExt(string strVal)
        {
            return getDecimal(removeAppenders(strVal));
        }
        public static decimal? getDecimal(string strVal)
        {
            decimal? result = null;
            if (!string.IsNullOrWhiteSpace(strVal)) result = decimal.Parse(strVal);
            return result;
        }
        public static decimal getDecimaNotNulllWithoutExt(string strVal)
        {
            return getNotNullDecimal(removeAppenders(strVal));
        }
        public static decimal getNotNullDecimal(string strVal)
        {
            decimal result = decimal.Zero;
            if (!string.IsNullOrWhiteSpace(strVal)) result = decimal.Parse(strVal);
            return result;
        }
        public static string getAcntTransCommentPymtMethod(PaymentMethod pymtMethod, string mediaNo)
        {
            string tmpComment = "";
            if (pymtMethod == PaymentMethod.CASH)
                tmpComment = Constants.CASH_PYMT_MODE;
            else if (pymtMethod == PaymentMethod.CHEQUE)
                tmpComment = string.Format(Constants.CHQ_PYMT_MODE, mediaNo);
            else if (pymtMethod == PaymentMethod.DD)
                tmpComment = Constants.DD_PYMT_MODE;
            else if (pymtMethod == PaymentMethod.NEFT)
                tmpComment = Constants.NEFT_PYMT_MODE;
            else if (pymtMethod == PaymentMethod.RTGS)
                tmpComment = Constants.RTGS_PYMT_MODE;
            return tmpComment;
        }
        public static bool isGreaterThanToday(DateTime? date)
        {
            DateTime today = DateTime.Now;
            return (date != null) ? date.Value.CompareTo(today) > 0 : false;
        }
        public static PropertyDTO getCurrentPropertyDTO(UserDefinitionDTO userDTO)
        {
            return userDTO.AssignedProperties.Find(x => x.isUISelected);
        }
        public static PropertyTowerDTO getStickyPrTowerDTO(UserDefinitionDTO userDTO)
        {
            PropertyDTO propertyDTO = getCurrentPropertyDTO(userDTO);
            if (userDTO.StickyTowerDTO == null || userDTO.StickyTowerDTO.Property.Id != propertyDTO.Id)
            {
                PropertyBO propertyBO = new PropertyBO();
                IList<PropertyTowerDTO> prTowerList = propertyBO.fetchPropertyTowerSelective(propertyDTO.Id);
                userDTO.StickyTowerDTO = prTowerList.ToList<PropertyTowerDTO>()[0];
            }
            return userDTO.StickyTowerDTO;
        }
        public static void setStickyPrTowerDTO(UserDefinitionDTO userDTO, long Id, string Name)
        {
            PropertyTowerDTO towerDTO = new PropertyTowerDTO();
            towerDTO.Id = Id;
            towerDTO.Name = Name;
            towerDTO.Property = getCurrentPropertyDTO(userDTO);
            userDTO.StickyTowerDTO = towerDTO;
        }
        public static void copyDropDownItems(DropDownList toDrp, DropDownList fromDrp) {
        	toDrp.Items.Clear();
            for (int i=0; i < fromDrp.Items.Count; i++) {
                toDrp.Items.Add(fromDrp.Items[i]);
            }
        }
        public static void copyDropDownItems(DropDownList toDrp, DropDownList fromDrp, bool excludeSelectItem)
        {
            toDrp.Items.Clear();
            for (int i = 0; i < fromDrp.Items.Count; i++)
            {
                if (!excludeSelectItem || !fromDrp.Items[i].Text.Equals(Constants.SELECT_ITEM[0]))
                {
                    toDrp.Items.Add(fromDrp.Items[i]);
                }
            }
        }
        public static  string addFilterToken(string filter, string token) {
        	return (string.IsNullOrWhiteSpace(filter)) ? token : filter + Constants.TOKEN_FIELD_DELIMITER + token;
        }
        public static string getRecordAddSuccessMsg(string recordName) {
        	return string.Format(Resources.Messages.RECORD_ADDED_DB_SUCCESS, recordName);
        }
        public static string getRecordModifySuccessMsg(string recordName) {
        	return string.Format(Resources.Messages.RECORD_MODIFY_DB_SUCCESS, recordName);
        }
        public static string getRecordDeleteSuccessMsg(string recordName) {
        	return string.Format(Resources.Messages.RECORD_DELETE_DB_SUCCESS, recordName);
        }
        public static string getRecordSoftDeleteSuccessMsg(string recordName) {
        	return string.Format(Resources.Messages.RECORD_DELETE_DB_SUCCESS, recordName);
        }
        public static void addListValidation(ExcelWorksheet worksheet, string cellNo, List<string> results)
        {
            var validation = worksheet.DataValidations.AddListValidation(cellNo);
            validation.ShowErrorMessage = true;
            validation.ErrorStyle = ExcelDataValidationWarningStyle.stop;
            validation.ErrorTitle = "Invalid value was entered";
            validation.Error = "Select a value from the list";
            foreach (string tmpStr in results)
            {
                validation.Formula.Values.Add(tmpStr);
            }
        }
        public static List<string> getDropdownItemNames(DropDownList drp) {
            List<string> list = new List<string>();
            foreach (ListItem li in drp.Items)
            {
                if (li.Text != "--Select--")
                    list.Add(li.Text);
            }
            return list;
        }
        public static List<string> getMasterDataNames(List<MasterControlDataDTO> results) {
            List<string> list = new List<string>();
            foreach (MasterControlDataDTO masterControlDataDTO in results)
            {
                list.Add(masterControlDataDTO.Name);
            }
            return list;
        }
        public static List<string> getEnumValues(Type enumType)
        {   
            if(!typeof(Enum).IsAssignableFrom(enumType))
                throw new ArgumentException("enumType should describe enum");
            Array names = Enum.GetNames(enumType);
            List<string> result = new List<string>(capacity:names.Length);
            for (int i = 0; i < names.Length; i++)
            {
                result.Add((string)names.GetValue(i));
            }

            return result;
        }
        public static List<string> getStepsToValidate(string startStep, string endStep) {
            List<string> steps = new List<string>();
            if(startStep.StartsWith("step") && endStep.StartsWith("step")) {
                long start = long.Parse(startStep.Replace("step", "").Trim());
                long end = long.Parse(endStep.Replace("step", "").Trim());
                do {
                    steps.Add("step" + start);
                    start++;
                } while(start < end);
            }
            return steps;
        }
        public static string appendCommaIfNot(string str) {
            string newStr = "";
            if (!string.IsNullOrWhiteSpace(str)) {
                newStr = (str.Trim().EndsWith(",")) ? str.Trim() : str.Trim()+",";
            }
            return newStr;
        }
        public static string appendBreakLine(string str) {
            return (!string.IsNullOrWhiteSpace(str)) ? str.Trim()+"<br/>" : "";
        }
        public static string appendNameToPath(string srcPath, string name)
        {
            return (srcPath.EndsWith("\\")) ? srcPath + name : srcPath + "\\" + name;
        }
        public static string getVirtualPath(string srcPath)
        {
            return srcPath.Replace(HostingEnvironment.MapPath(Constants.DOCUMENT_MANAGEMENT.DOC_MANAGEMENT_PATH), Constants.DOCUMENT_MANAGEMENT.DOC_MANAGEMENT_PATH);
        }
        public static bool isSystemManagedFolder(string folderName)
        {
            bool result = false;
            result = folderName.Equals(Constants.DOCUMENT_MANAGEMENT.CUSTOMER_TEMP_FOLDER);
            return result;
        }
        public static string getDirectoryPath(List<FilePathBreadCrumbDTO> pathList)
        {
            string result = "";
            foreach (FilePathBreadCrumbDTO tmpDTO in pathList)
            {
                result = (string.IsNullOrWhiteSpace(result)) ? tmpDTO.Name : result + "\\" + tmpDTO.Name;
            }
            return result;
        }
        public static EnquiryActivity getEnquiryActivityAction(long EnquiryId, EnqActivityType enqActivityType, string assignee, DateTime dateLogged, UserDefinitionDTO userDefDTO)
        {
            EnquiryActivity action = createNewEnquiryActivity(EnquiryId, EnqActivityRecordType.Action, userDefDTO);
            action.LoggedBy = new FirmMember();
            action.LoggedBy.Id = userDefDTO.FirmMember.Id;
            action.DateLogged = dateLogged;
            action.ActivityType = enqActivityType;
            action.Status = EnqLeadActivityStatus.Completed;
            action.RefNo = CommonUtil.getRandomRefNo();
            string comments = "";
            if (enqActivityType == EnqActivityType.CREATE) comments = Constants.ENQ_ACTIVITY_ACTION_COMMENT.CREATE;
            else if (enqActivityType == EnqActivityType.ASSIGNMENT) comments = string.Format(Constants.ENQ_ACTIVITY_ACTION_COMMENT.ASSIGNMENT, assignee);
            else if (enqActivityType == EnqActivityType.RE_ASSIGNMENT) comments = string.Format(Constants.ENQ_ACTIVITY_ACTION_COMMENT.REASSIGNMENT, assignee);
            else if (enqActivityType == EnqActivityType.CONVERTED) comments = string.Format(Constants.ENQ_ACTIVITY_ACTION_COMMENT.CONVERTED, assignee);
            else if (enqActivityType == EnqActivityType.BOOKING_CANCELLED) comments = Constants.ENQ_ACTIVITY_ACTION_COMMENT.BOOKING_CANCELLED;
            else if (enqActivityType == EnqActivityType.LOST) comments = Constants.ENQ_ACTIVITY_ACTION_COMMENT.LOST;
            else if (enqActivityType == EnqActivityType.RE_OPENED) comments = Constants.ENQ_ACTIVITY_ACTION_COMMENT.REOPENED;
            else if (enqActivityType == EnqActivityType.WON) comments = Constants.ENQ_ACTIVITY_ACTION_COMMENT.WON;

            action.Comments = comments;
            return action;
        }
        public static EnquiryActivity createNewEnquiryActivity(long EnquiryId, EnqActivityRecordType recordType, UserDefinitionDTO userDefDto)
        {
            EnquiryActivity activity = new EnquiryActivity();
            activity.RecordType = recordType;
            activity.EnquiryDetail = new EnquiryDetail();
            activity.EnquiryDetail.Id = EnquiryId;
            activity.FirmNumber = userDefDto.FirmNumber;
            activity.InsertUser = userDefDto.Username;
            activity.UpdateUser = userDefDto.Username;
            return activity;
        }
        public static LeadActivity getLeadActivityAction(long LeadId, EnqActivityType enqActivityType, string assignee, DateTime dateLogged, UserDefinitionDTO userDefDTO)
        {
            LeadActivity action = createNewLeadActivity(LeadId, EnqActivityRecordType.Action, userDefDTO);
            action.LoggedBy = new FirmMember();
            action.LoggedBy.Id = userDefDTO.FirmMember.Id;
            action.DateLogged = dateLogged;
            action.ActivityType = enqActivityType;
            action.Status = EnqLeadActivityStatus.Completed;
            action.RefNo = CommonUtil.getRandomRefNo();
            string comments = "";
            if (enqActivityType == EnqActivityType.CREATE) comments = Constants.LEAD_ACTIVITY_ACTION_COMMENT.CREATE;
            else if (enqActivityType == EnqActivityType.ASSIGNMENT) comments = string.Format(Constants.LEAD_ACTIVITY_ACTION_COMMENT.ASSIGNMENT, assignee);
            else if (enqActivityType == EnqActivityType.RE_ASSIGNMENT) comments = string.Format(Constants.LEAD_ACTIVITY_ACTION_COMMENT.REASSIGNMENT, assignee);
            else if (enqActivityType == EnqActivityType.CONVERTED) comments = string.Format(Constants.LEAD_ACTIVITY_ACTION_COMMENT.CONVERTED, assignee);
            else if (enqActivityType == EnqActivityType.LOST) comments = Constants.LEAD_ACTIVITY_ACTION_COMMENT.LOST;
            
            action.Comments = comments;
            return action;
        }
        public static LeadActivity createNewLeadActivity(long LeadId, EnqActivityRecordType recordType, UserDefinitionDTO userDefDto)
        {
            LeadActivity activity = new LeadActivity();
            activity.RecordType = recordType;
            activity.LeadDetail = new LeadDetail();
            activity.LeadDetail.Id = LeadId;
            activity.FirmNumber = userDefDto.FirmNumber;
            activity.InsertUser = userDefDto.Username;
            activity.UpdateUser = userDefDto.Username;
            return activity;
        }
        public static EnquiryActivityDTO createNewEnquiryActivityDTO(long EnquiryId, EnqActivityRecordType recordType, UserDefinitionDTO userDefDto)
        {
            EnquiryActivityDTO activityDTO = new EnquiryActivityDTO();
            activityDTO.RecordType = recordType;
            activityDTO.EnquiryDetail = new EnquiryDetailDTO();
            activityDTO.EnquiryDetail.Id = EnquiryId;
            activityDTO.FirmNumber = userDefDto.FirmNumber;
            activityDTO.InsertUser = userDefDto.Username;
            activityDTO.UpdateUser = userDefDto.Username;
            return activityDTO;
        }
        public static LeadActivityDTO createNewLeadActivityDTO(long LeadId, EnqActivityRecordType recordType, UserDefinitionDTO userDefDto)
        {
            LeadActivityDTO activityDTO = new LeadActivityDTO();
            activityDTO.RecordType = recordType;
            activityDTO.LeadDetail = new LeadDetailDTO();
            activityDTO.LeadDetail.Id = LeadId;
            activityDTO.FirmNumber = userDefDto.FirmNumber;
            activityDTO.InsertUser = userDefDto.Username;
            activityDTO.UpdateUser = userDefDto.Username;
            return activityDTO;
        }
        public static string redirectToDefaultPage(UserDefinitionDTO userDefDto, System.Web.SessionState.HttpSessionState Session) {
        	string redirectPage = Constants.URL.DEFAULT_HOME_PAGE;
        	string msg = "You do not have access to any of the Property. Please contact your supervisor.";
            List<String> UserEntitlements = userDefDto.UserRole.EntitlementAssigned;
        	bool hasAddPropertyEntitlement = UserEntitlements.Any(x => x == Constants.Entitlement.PROPERTY_ADD);
        	if(hasAddPropertyEntitlement) {
                PropertyDetailNavDTO navDTO = new PropertyDetailNavDTO();
                navDTO.Mode = PageMode.ADD;
                Session[Constants.Session.NAV_DTO] = navDTO;
        		redirectPage = Constants.URL.PROPERTY_DETAILS;
        		msg = "Please add new Property.";
        	}
        	Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotyErrorMsg(msg));
        	return redirectPage;
        }
        public static Notification getNotification(long LeadId, long PropertyId ,NotificationType notificationType, string assignee, string token, UserDefinitionDTO userDefDTO)
        {
            Notification notification = createNotification(userDefDTO);
            notification.NotificationType = notificationType;
            notification.PropertyId = PropertyId;
            notification.NotificationMessage = LeadId.ToString()+"¶"+token;
            notification.Status = NotificationStatus.OPEN;
            notification.UserName = assignee;
            return notification;
        }
        public static Notification createNotification(UserDefinitionDTO userDefDto)
        {
            Notification notification = new Notification();
            notification.FirmNumber = userDefDto.FirmNumber;
            notification.InsertUser = userDefDto.Username;
            notification.InsertDate = DateTime.Now;
            notification.UpdateUser = userDefDto.Username;
            notification.UpdateDate = DateTime.Now;
            return notification;
        }
    }
}