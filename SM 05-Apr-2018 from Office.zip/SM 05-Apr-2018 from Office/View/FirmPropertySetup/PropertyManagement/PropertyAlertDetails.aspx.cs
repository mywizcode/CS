﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using ConstroSoft;

public partial class PropertyAlertDetails : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
            log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string selectProviderModal = "selectProviderModal";
    string selectProviderModalError = "selectProviderModalError";
    string selectTemplateModal = "selectTemplateModal";
    string selectTemplateModalError = "selectTemplateModalError";
    string testEmailSMSModal = "testEmailSMSModal";
    string testEmailModalError = "testEmailModalError";
    string testSMSModalError = "testSMSModalError";
    DropdownBO drpBO = new DropdownBO();
    PropertyAlertBO propertyAlertBO = new PropertyAlertBO();
    DocumentBO documentBO = new DocumentBO();
    MarketingCampaignBO marketingCampaignBO = new MarketingCampaignBO();
    EmailAndSMSProviderBO emailSmsProviderBO = new EmailAndSMSProviderBO();
    public enum AlertPageMode { EMAIL, SMS }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                PropertyAlertDetailsNavDTO navDto = ApplicationUtil.getPageNavDTO<PropertyAlertDetailsNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.PROPERTY_ALERT_CONFIG)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
        * This method is called just before the page is rendered. So any change in state of the element is applied.
        **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
            RegisterPostBackControl();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    public void setErrorMessage(string message, string group)
    {
        string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }
    }
    private void doInit(PropertyAlertDetailsNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(PropertyAlertDetailsNavDTO navDto)
    {
        try
        {
            PropertyAlertDetailsPageDTO PageDTO = new PropertyAlertDetailsPageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            PageDTO.PropertyId = navDto.PropertyId;

            PageDTO.AlertDTO = propertyAlertBO.fetchPropertyAlertDetails(navDto.AlertId);
            loadAlertDetails();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageFieldsWithEntitlement()
    {

    }
    private void RegisterPostBackControl() 
    {
    	if (attachmentGrid.Items.Count > 0)
        {
            foreach(System.Web.UI.WebControls.ListViewItem itemRow in attachmentGrid.Items)
            {
            	LinkButton tmpBtn = (LinkButton)itemRow.FindControl("lnkDownloadAttachmentBtn");
            	if (tmpBtn != null)
                {
                    ScriptManager mgr = ScriptManager.GetCurrent(this.Page);
                    mgr.RegisterPostBackControl(tmpBtn);
                }
            }
        }
    }
    private void navigateToPreviousPage()
    {
        PropertyAlertDetailsPageDTO PageDTO = getSessionPageData();
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is PropertyAlertsNavDTO)
            {
                PropertyAlertsNavDTO navDTO = (PropertyAlertsNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.PROPERTY_ALERTS, true);
            }
        }
        Response.Redirect(Constants.URL.PROPERTY_SEARCH, true);
    }
    private PropertyAlertDetailsPageDTO getSessionPageData()
    {
        return (PropertyAlertDetailsPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private PropertyAlertConfigDTO getAlertConfigDTO()
    {
        return getSessionPageData().AlertDTO;
    }
    private bool isEmailPageMode() {
    	return pageModeHdn.Value.Equals(AlertPageMode.EMAIL.ToString());
    }
    private bool isSMSPageMode() {
    	return pageModeHdn.Value.Equals(AlertPageMode.SMS.ToString());
    }
    private void loadAlertDetails()
    {
        PropertyAlertConfigDTO configDTO = getAlertConfigDTO();
        lbAlertFunctionName.Text = configDTO.FunctionName.GetDescription();
        lbAlertFunctionDescription.Text = CommonUtil.getPrAlertFunctionDescription(configDTO.FunctionName.ToString());

        EnableTab(true);
        loadAllAlertDetails(configDTO);
        
        loadPersonalization();
    }
    private void loadPersonalization()
    {
        personalizationGrid.DataSource = CommonUIConverter.getEmailPersonalization();
        personalizationGrid.DataBind();
    }
    private void EnableTab(bool isEmailTab)
    {
    	clearTempUploadFields();
    	
        PropertyAlertDetailsPageDTO PageDTO = getSessionPageData();
        liEmailAlert.Attributes["class"] = (isEmailTab) ? "active" : "";
        liSMSAlert.Attributes["class"] = (isEmailTab) ? "" : "active";
        pnlEmailAlert.Visible = isEmailTab;
        pnlSMSAlert.Visible = !isEmailTab;
        pageModeHdn.Value = (isEmailTab) ? AlertPageMode.EMAIL.ToString() : AlertPageMode.SMS.ToString();

        setEnableDisableFlag(PageDTO.AlertDTO);
    }
    private void loadAllAlertDetails(PropertyAlertConfigDTO configDTO) {
    	
    	txtEmailProvider.Text = (configDTO.EmailConfig != null) ? configDTO.EmailConfig.Name : null;
    	txtEmailSubject.Text = configDTO.Subject;
        txtEmailBody.Text = StringUtil.getBytesAsString(configDTO.EmailContent);
    	loadEmailAttachments(configDTO.Attachments);
    	
    	txtSMSProvider.Text = (configDTO.SmsConfig != null) ? configDTO.SmsConfig.Name : null;
        txtSMSContent.Text = configDTO.SmsContent;
    }
    private void setEnableDisableFlag(PropertyAlertConfigDTO configDTO) {
    	if (isEmailPageMode()) {
    		cbEmailOrSMSConfigEnabled.Checked = (configDTO.EmailEnabled == EmailSmsEnabled.Yes);
    	} else {
    		cbEmailOrSMSConfigEnabled.Checked = (configDTO.SmsEnabled == EmailSmsEnabled.Yes);
    	}
    	
    	lbEmailOrSMSConfigEnabled.Text = (cbEmailOrSMSConfigEnabled.Checked) ? Resources.Labels.ENABLED : Resources.Labels.DISABLED;
    }
    private void loadEmailAttachments(List<PropertyAlertConfigAttachmentDTO> attachments) {
    	if (attachments != null && attachments.Count > 0)
        {
            long uiIndex = 1;
            foreach (PropertyAlertConfigAttachmentDTO tmpDTO in attachments)
            {
                tmpDTO.UiIndex = uiIndex++;
            	tmpDTO.Icon = IconUtil.GetFileIcon2x(tmpDTO.FileName);
            }
        }
        lbEmailNoOfAttachments.Text = (attachments != null) ? attachments.Count + "" : "";
        divAttachmentDetails.Visible = (attachments != null && attachments.Count > 0);
    	attachmentGrid.DataSource = (attachments != null) ? attachments : new List<PropertyAlertConfigAttachmentDTO>();
    	attachmentGrid.DataBind();
    }
    protected void onClickEmailTab(object sender, EventArgs e)
    {
        try
        {
        	EnableTab(true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickSMSTab(object sender, EventArgs e)
    {
        try
        {
        	EnableTab(false);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickSaveEmailOrSMSChanges(object sender, EventArgs e)
    {
        try
        {
            if (!validateEmailDetailsOnSave(false)) EnableTab(true);
            else if (!validateSMSDetailsOnSave(false)) EnableTab(false);
            else {
        		PropertyAlertConfigDTO configDTO = getAlertConfigDTO();
        		populateAlertConfigDTOFromUI(configDTO);
        		propertyAlertBO.savePropertyAlertDetails(configDTO);
        		(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("Email and SMS details are saved successfully."));
        	}
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickCancelChanges(object sender, EventArgs e)
    {
        try
        {
        	navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onChangeEmailOrSMSEnable(object sender, EventArgs e)
    {
        try
        {
        	lbEmailOrSMSConfigEnabled.Text = (cbEmailOrSMSConfigEnabled.Checked) ? Resources.Labels.ENABLED : Resources.Labels.DISABLED;
        	if (isEmailPageMode()) {
        		getAlertConfigDTO().EmailEnabled = (cbEmailOrSMSConfigEnabled.Checked) ? EmailSmsEnabled.Yes : EmailSmsEnabled.No;
        	} else {
                getAlertConfigDTO().SmsEnabled = (cbEmailOrSMSConfigEnabled.Checked) ? EmailSmsEnabled.Yes : EmailSmsEnabled.No;
        	}
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateEmailDetailsOnSave(bool skipEnableCheck) {
    	bool isValid = true;
    	PropertyAlertConfigDTO configDTO = getAlertConfigDTO();
        if (configDTO.EmailEnabled == EmailSmsEnabled.Yes || skipEnableCheck)
        {
    		if(configDTO.EmailConfig == null) {
    			(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please select Provider."));
    			isValid = false;
    		}
    		if(string.IsNullOrWhiteSpace(txtEmailSubject.Text.TrimNullable())) {
    			(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please enter Subject."));
    			isValid = false;
    		}
    		if(string.IsNullOrWhiteSpace(txtEmailBody.Text.TrimNullable())) {
    			(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please enter email content."));
    			isValid = false;
    		}
    	}
    	long totalSize = 0; 
		foreach(PropertyAlertConfigAttachmentDTO tmpDTO in configDTO.Attachments) {
			totalSize += tmpDTO.Content.Length;
		}
		if(totalSize > Constants.EMAIL_ATTACHMENT_SIZE) {
			(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(string.Format("Total attachment size should not exceed {0}MB.",
                (Constants.EMAIL_ATTACHMENT_SIZE / 1000000))));
			isValid = false;
		}
        return isValid;
    }
    private bool validateSMSDetailsOnSave(bool skipEnableCheck) {
    	bool isValid = true;
    	PropertyAlertConfigDTO configDTO = getAlertConfigDTO();
        if (configDTO.SmsEnabled == EmailSmsEnabled.Yes || skipEnableCheck)
        {
    		if(configDTO.SmsConfig == null) {
    			(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please select Provider."));
    			isValid = false;
    		}
    		if(string.IsNullOrWhiteSpace(txtSMSContent.Text.TrimNullable())) {
    			(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Please enter SMS content."));
    			isValid = false;
    		}
    	}
        return isValid;
    }
    private void populateAlertConfigDTOFromUI(PropertyAlertConfigDTO configDTO) {
    	UserDefinitionDTO userDefDto = getUserDefinitionDTO();
    	configDTO.Subject = txtEmailSubject.Text.TrimNullable();
        configDTO.EmailContent = StringUtil.getStringAsBytes(txtEmailBody.Text);

        configDTO.SmsContent = txtSMSContent.Text.TrimNullable();
        
    	configDTO.UpdateUser = userDefDto.Username;
    }
    private void clearTempUploadFields()
    {
        documentBO.clearTempFileUploadDirectory(getUserDefinitionDTO().Username);
    }
    private PropertyAlertConfigAttachmentDTO createAttachmentDTO(FileUIDTO fileDTO) {
    	UserDefinitionDTO userDefDto = getUserDefinitionDTO();
    	PropertyAlertConfigAttachmentDTO tmpDTO = new PropertyAlertConfigAttachmentDTO();
    	tmpDTO.FileName = fileDTO.Name;
    	tmpDTO.Content = fileDTO.Content;
        tmpDTO.AlertConfig = new PropertyAlertConfigDTO();
        tmpDTO.AlertConfig.Id = getAlertConfigDTO().Id;

    	tmpDTO.FirmNumber = userDefDto.FirmNumber;
    	tmpDTO.InsertUser = userDefDto.Username;
    	tmpDTO.UpdateUser = userDefDto.Username;
    	tmpDTO.InsertDate = DateUtil.getUserLocalDateTime();
    	tmpDTO.UpdateDate = DateUtil.getUserLocalDateTime();
    	
    	tmpDTO.Size = fileDTO.Content.Length.ToSize(SizeUnits.KB);
    			
    	return tmpDTO;
    }
    protected void onClickUploadAttachmentBtn(object sender, EventArgs e)
    {
        try
        {
        	UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        	PropertyAlertConfigDTO configDTO = getAlertConfigDTO();
            List<FileUIDTO> tmpList = documentBO.downloadTempUploadedFiles(string.Format(Constants.DOCUMENT_MANAGEMENT.TMP_FILE_UPLOAD_PATH, userDefDto.Username));
            if (tmpList != null && tmpList.Count > 0)
            {
                foreach (FileUIDTO tmpUIDTO in tmpList)
                {
                	configDTO.Attachments.Add(createAttachmentDTO(tmpUIDTO));
                }
                clearTempUploadFields();
                loadEmailAttachments(configDTO.Attachments);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    protected void onClickDownloadAttachment(object sender, EventArgs e)
    {
        try
        {
        	LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            PropertyAlertConfigDTO configDTO = getAlertConfigDTO();
            PropertyAlertConfigAttachmentDTO tmpDTO = configDTO.Attachments.Find(x => x.UiIndex == selectedId);
            Response.Buffer = true;
            Response.Charset = "";
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + tmpDTO.FileName);
            Response.BinaryWrite(tmpDTO.Content);
            Response.Flush();
            UpdatePanel1.Update();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickRemoveAttachment(object sender, EventArgs e)
    {
        try
        {
        	LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            PropertyAlertConfigDTO configDTO = getAlertConfigDTO();
            PropertyAlertConfigAttachmentDTO tmpDTO = configDTO.Attachments.Find(x => x.UiIndex == selectedId);
            if(tmpDTO != null) {
            	configDTO.Attachments.Remove(tmpDTO);
            	loadEmailAttachments(configDTO.Attachments);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Provider Selection logic - start
    protected void onClickProvider(object sender, EventArgs e)
    {
        try
        {
            drpBO.drpDataBase(drpProvider, (isEmailPageMode()) ? DrpDataType.EMAIL_PROVIDER : DrpDataType.SMS_PROVIDER, null, 
                Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            PropertyAlertConfigDTO configDTO = getAlertConfigDTO();
            if (isEmailPageMode() && configDTO.EmailConfig != null) drpProvider.Text = configDTO.EmailConfig.Id.ToString();
            else if (isSMSPageMode() && configDTO.SmsConfig != null) drpProvider.Text = configDTO.SmsConfig.Id.ToString();
            activeModalHdn.Value = selectProviderModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void AssignProvider(object sender, EventArgs e)
    {
        try
        {
            PropertyAlertConfigDTO configDTO = getAlertConfigDTO();
            if (!string.IsNullOrWhiteSpace(drpProvider.Text))
            {
                long Provider = long.Parse(drpProvider.Text);
                if (isEmailPageMode())
                {
                    txtEmailProvider.Text = drpProvider.SelectedItem.Text;
                    configDTO.EmailConfig = CommonUIConverter.getEmailConfigDTO(drpProvider.Text, drpProvider.SelectedItem.Text);
                }
                else
                {
                    txtSMSProvider.Text = drpProvider.SelectedItem.Text;
                    configDTO.SmsConfig = CommonUIConverter.getSmsConfigDTO(drpProvider.Text, drpProvider.SelectedItem.Text);
                }
            }
            else
            {
                if (isEmailPageMode())
                {
                    txtEmailProvider.Text = null;
                    configDTO.EmailConfig = null;
                }
                else
                {
                    txtSMSProvider.Text = null;
                    configDTO.SmsConfig = null;
                }
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelProviderModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Provider Selection logic - end
    //Template Selection logic - start
    protected void onClickLoadTemplate(object sender, EventArgs e)
    {
        try
        {
            drpBO.drpDataBase(drpTemplate, (isEmailPageMode()) ? DrpDataType.EMAIL_STORE_TEMPLATE : DrpDataType.SMS_STORE_TEMPLATE, null, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            activeModalHdn.Value = selectTemplateModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void LoadTemplate(object sender, EventArgs e)
    {
        try
        {
            Page.Validate(selectTemplateModalError);
            bool isValid = Page.IsValid;
            if (isValid)
            {
                long TemplateId = long.Parse(drpTemplate.Text);
                EmailSmsStoreDTO templateDTO = marketingCampaignBO.fetchEmailSmsTemplate(TemplateId);
                if(isEmailPageMode()) {
                	txtEmailSubject.Text = templateDTO.Subject;
                	txtEmailBody.Text = StringUtil.getBytesAsString(templateDTO.EmailContent);
                	
                	PropertyAlertConfigDTO configDTO = getAlertConfigDTO();
                	configDTO.Attachments.Clear();
                	configDTO.Attachments.AddRange(copyAllAttachmentDTOs(templateDTO.Attachments));
                	loadEmailAttachments(configDTO.Attachments);
                } else {
                	txtSMSContent.Text = templateDTO.SmsContent;
                }
            }
            else
            {
                activeModalHdn.Value = selectTemplateModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelTemplateModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private List<PropertyAlertConfigAttachmentDTO> copyAllAttachmentDTOs(List<EmailSmsStoreAttachmentDTO> tmpSrcDTOList) {
    	List<PropertyAlertConfigAttachmentDTO> tmpList = new List<PropertyAlertConfigAttachmentDTO>();
    	UserDefinitionDTO userDefDto = getUserDefinitionDTO();
    	if(tmpSrcDTOList != null) {
    		foreach(EmailSmsStoreAttachmentDTO tmpSrcDTO in tmpSrcDTOList) {
    			PropertyAlertConfigAttachmentDTO tmpDTO = new PropertyAlertConfigAttachmentDTO();
    	    	tmpDTO.FileName = tmpSrcDTO.FileName;
    			tmpDTO.Content = tmpSrcDTO.Content;
    			tmpDTO.Size = tmpSrcDTO.Content.Length.ToSize(SizeUnits.KB);
    			tmpDTO.AlertConfig = new PropertyAlertConfigDTO();
    	        tmpDTO.AlertConfig.Id = getAlertConfigDTO().Id;
    	        
    			tmpDTO.FirmNumber = userDefDto.FirmNumber;
    			tmpDTO.InsertUser = userDefDto.Username;
    	    	tmpDTO.UpdateUser = userDefDto.Username;
    	    	tmpDTO.InsertDate = DateUtil.getUserLocalDateTime();
    	    	tmpDTO.UpdateDate = DateUtil.getUserLocalDateTime();
    	    	
    	    	tmpList.Add(tmpDTO);
        	}
    	}
    	return tmpList;
    }
    //Template Selection logic - end
    //Test Email/SMS logic - start
    protected void onClickTestEmailOrSMS(object sender, EventArgs e)
    {
        try
        {
        	if(isEmailPageMode()) {
        		lbTestEmailSMSModalHeader.Text = Constants.ICON.TEST_EMAIL_SMS + "Test Email";
        		txtTestEmail.Text = "";
        	} else {
        		lbTestEmailSMSModalHeader.Text = Constants.ICON.TEST_EMAIL_SMS + "Test SMS";
        		txtTestSMSMobileNo.Text = "";
        	}
        	divTestEmailInput.Visible = isEmailPageMode();
        	divTestSMSInput.Visible = isSMSPageMode();
            activeModalHdn.Value = testEmailSMSModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void sendTestEmailOrSMS(object sender, EventArgs e)
    {
        try
        {
            if (validateTestEmailSMSModal())
            {
                if(isEmailPageMode()) {
                    PropertyAlertConfigDTO alertConfigDTO = getAlertConfigDTO();
                    EmailConfigDTO configDTO = emailSmsProviderBO.fetchEmailProvider(alertConfigDTO.EmailConfig.Id);

                    EmailDTO emailDTO = new EmailDTO();
                    emailDTO.FromEmail = configDTO.Email;
                    emailDTO.Password = configDTO.Password;
                    emailDTO.SmtpHost = configDTO.SmtpHost;
                    emailDTO.SmtpPort = configDTO.SmtpPort;
                    emailDTO.EnableSsl = (configDTO.EnableSsl == EmailEnableSSL.Yes);
                    emailDTO.Subject = txtEmailSubject.Text.TrimNullable();
                    emailDTO.EmailContent = StringUtil.getUnEscapedEmailContent(txtEmailBody.Text.TrimNullable());
                    emailDTO.Attachments = new List<AttachmentDTO>();
                    if (alertConfigDTO.Attachments != null)
                    {
                        foreach (PropertyAlertConfigAttachmentDTO tmpDTO in alertConfigDTO.Attachments)
                        {
                            emailDTO.Attachments.Add(new AttachmentDTO(tmpDTO.FileName, tmpDTO.Content));
                        }
                    }
                    emailDTO.RecipientList = new List<string>();
                    emailDTO.RecipientList.Add(txtTestEmail.Text.TrimNullable());

                    EmailSMSUtil.SendEmail(emailDTO);
                    (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format("Email is sent to {0}", txtTestEmail.Text.TrimNullable())));
                } else {
                    PropertyAlertConfigDTO alertConfigDTO = getAlertConfigDTO();
                    SmsConfigDTO configDTO = emailSmsProviderBO.fetchSmsProvider(alertConfigDTO.SmsConfig.Id);
                    SmsDTO smsDTO = new SmsDTO();
                    smsDTO.UserId = configDTO.UserId;
                    smsDTO.Password = configDTO.Password;
                    smsDTO.URL = configDTO.Url;
                    smsDTO.SenderId = configDTO.UserId;
                    smsDTO.Content = txtSMSContent.Text.TrimNullable();
                    smsDTO.RecipientList = new List<string>();
                    smsDTO.RecipientList.Add(txtTestSMSMobileNo.Text.TrimNullable());

                    EmailSMSUtil.SendSMS(smsDTO);
                    (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format("SMS is sent to {0}", txtTestSMSMobileNo.Text.TrimNullable())));
                }
            }
            else
            {
                activeModalHdn.Value = testEmailSMSModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelTestEmailSMSModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateTestEmailSMSModal() {
    	Page.Validate((isEmailPageMode()) ? testEmailModalError : testSMSModalError);
    	bool isValid = Page.IsValid;
    	if(isValid) {
    		if(isEmailPageMode()) {
    			isValid = validateEmailDetailsOnSave(true);
        	} else {
        		isValid = validateSMSDetailsOnSave(true);
        	}
    	}
    	return isValid;
    }
    //Test Email/SMS Selection logic - end
}