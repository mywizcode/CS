﻿using ConstroSoft.Logic.Job;
using Quartz;
using Quartz.Impl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ConstroSoft.Logic.Scheduler
{
    public class JobTrigger
    {
        private static readonly log4net.ILog log =
                log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        
        public JobTrigger() { }
        
        public ITrigger CreateSimpleSchedule(string triggerName, string group)
        {
            ITrigger trigger = null;
            try{
                trigger = TriggerBuilder.Create()
                        .WithIdentity(triggerName, group)
                        .StartNow()
                        .WithSimpleSchedule(x => x
                            .WithIntervalInMinutes(2)
                            .RepeatForever())
                    .Build();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error creating Simple trigger:" ,exp);
                throw new Exception(Resources.Messages.system_error);
            }
            finally
            {

            }
            return trigger;
        }
        public ITrigger GetTriggerNow(string triggerName, string group)
        {
            ITrigger trigger = null;
            try{
                trigger = TriggerBuilder.Create().WithIdentity(triggerName, group).StartNow().Build();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error creating trigger with time immediately:" ,exp);
                throw new Exception(Resources.Messages.system_error);
            }
            finally
            {

            }
            return trigger;
        }
        public ITrigger GetTriggerForTime(string triggerName, string group, DateTime ScheduleDate)
        {
            ITrigger trigger = null;
            try{
                trigger = TriggerBuilder.Create().WithIdentity(triggerName, group).StartAt(ScheduleDate).Build();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error creating trigger for given Date:" ,exp);
                throw new Exception(Resources.Messages.system_error);
            }
            finally
            {

            }

            return trigger;
        }
    }
}