﻿using System;
using NHibernate;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using ConstroSoft;
using System.Collections.Generic;
using NHibernate.Criterion;
using NHibernate.Transform;

/// <summary>
/// Summary description for FirmBO
/// </summary>
namespace ConstroSoft
{
    public class FirmBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public FirmBO() { }
        public FirmDTO fetchFirmDetails(string firmNumber)
        {
            ISession session = null;
            FirmDTO firmDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Firm firm = session.QueryOver<Firm>().Where(f => f.FirmNumber == firmNumber).SingleOrDefault<Firm>();
                        firmDto = populateFirmDTO(firm);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Firm details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return firmDto;
        }
        public ExotelDTO fetchExotelDetails(string firmNumber)
        {
            ISession session = null;
            ExotelDTO exotelDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Exotel e = null;
                        Firm f = null;
                    	Exotel exotel = session.QueryOver<Exotel>(() => e)
                            .Inner.JoinAlias(() => e.Firm, () => f)
                            .Where(() => f.FirmNumber == firmNumber).SingleOrDefault<Exotel>();
                    	exotelDto = new ExotelDTO();
                    	exotelDto.Id = exotel.Id;
                    	exotelDto.Sid = exotel.Sid;
                    	exotelDto.Token = exotel.Token;
                    	exotelDto.OutCallBackURL = exotel.OutCallBackURL;
                    	exotelDto.OutCallURL = exotel.OutCallURL;
                    	exotelDto.CallType = exotel.CallType;
                    	exotelDto.CallDetailsURL = exotel.CallDetailsURL;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Exotel details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return exotelDto;
        }
        public CallProvider fetchCallProvider(string firmNumber)
        {
            ISession session = null;
            CallProvider callProvider = CallProvider.EXOTEL;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Firm firm = session.QueryOver<Firm>().Where(f => f.FirmNumber == firmNumber).SingleOrDefault<Firm>();
                        callProvider = firm.CallProvider;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Call Provider:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return callProvider;
        }
        public List<FirmAccountDTO> fetchAccounts(string firmNumber)
        {
            ISession session = null;
            List<FirmAccountDTO> result = new List<FirmAccountDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	IList<FirmAccount> dbResult = session.QueryOver<FirmAccount>().Where(f => f.FirmNumber == firmNumber).List<FirmAccount>();
                    	if(dbResult != null) {
                    		foreach(FirmAccount tmpAcnt in dbResult) {
                    			result.Add(DomainToDTOUtil.convertToFirmAccountDTO(tmpAcnt, true));
                    		}
                    	}
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching accounts:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public List<FirmDTO> fetchAllFirms()
        {
            ISession session = null;
            List<FirmDTO> firmDTOList = new List<FirmDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        IList<Firm> firmList = session.QueryOver<Firm>().List<Firm>();
                        foreach (Firm firm in firmList)
                        {
                        	firmDTOList.Add(populateFirmDTO(firm));
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading all Firms:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return firmDTOList;
        }
        public void updateFirm(FirmDTO firmDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Firm firm = session.Get<Firm>(firmDto.Id);
                        populateFirm(firm, firmDto);
                        session.Update(firm);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Updating Firm:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public bool validateAccountExist(string firmNumber, string AccountName, string AccountNumber)
        {
            ISession session = null;
            bool exist = false;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	FirmAccount p = null;
                        exist = session.QueryOver<FirmAccount>(() => p)
                            .Where(() => p.FirmNumber == firmNumber && (p.Name.IsInsensitiveLike(AccountName) || p.AccountNo.IsInsensitiveLike(AccountNumber)))
                            .RowCount() > 0;
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while validating unique Account:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return exist;
        }
        public void saveFirmAccount(FirmAccountDTO firmAccountDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        FirmAccount firmAccount = DTOToDomainUtil.populateFirmAccountAddFields(firmAccountDto);
                        Firm firm = session.QueryOver<Firm>().Where(f => f.FirmNumber == firmAccountDto.FirmNumber).SingleOrDefault<Firm>();
                        firmAccount.Firm = firm;
                        session.Save(firmAccount);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Updating Account:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void updateFirmAccount(FirmAccountDTO firmAccountDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        FirmAccount firmAccount = session.Get<FirmAccount>(firmAccountDto.Id);
                        DTOToDomainUtil.populateFirmAccountUpdateFields(firmAccount, firmAccountDto);
                        session.Update(firmAccount);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Updating Account:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void deleteFirmAccount(long accountId)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        //TODO - need to validate whether account cannot be deleted is account balance is not 0
                        FirmAccount firmAccount = session.Get<FirmAccount>(accountId);
                        session.Delete(firmAccount);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Deleting Account:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        private void populateFirm(Firm firm, FirmDTO firmDto)
        {
            firm.RegistrationNo = firmDto.RegistrationNo;
            firm.WebSite = firmDto.WebSite;
            firm.Description = firmDto.Description;
            DTOToDomainUtil.copyToContactInfo(firm.ContactInfo, firmDto.ContactInfo);
            firm.UpdateDate = DateUtil.getUserLocalDateTime();
            firm.UpdateUser = firmDto.UpdateUser;
        }
        public FirmDTO populateFirmDTO(Firm firm)
        {
            FirmDTO firmDto = DomainToDTOUtil.convertToFirmDTO(firm, true);
            firmDto.FirmAccounts = new HashSet<FirmAccountDTO>();
            foreach (FirmAccount firmAcnt in firm.FirmAccounts)
            {
                firmDto.FirmAccounts.Add(DomainToDTOUtil.convertToFirmAccountDTO(firmAcnt, true));
            }
            return firmDto;
        }
        public FirmAccountDTO fetchFirmAccount(long Id)
        {
            ISession session = null;
            FirmAccountDTO firmAccountDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        FirmAccount firmAccount = session.Get<FirmAccount>(Id);
                        firmAccountDto = DomainToDTOUtil.convertToFirmAccountDTO(firmAccount, true);
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while fetching Account:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return firmAccountDto;
        }
        public IList<AccountTransactionDTO> fetchAccountTransactions(string firmNumber, long Id, DateTime startDate)
        {
            ISession session = null;
            IList<AccountTransactionDTO> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        FirmAccount fa = null;
                        AccountTransaction a = null;

                        AccountTransactionDTO aDto = null;
                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => a.Id).WithAlias(() => aDto.Id))
                                    .Add(Projections.Property(() => a.TxDate).WithAlias(() => aDto.TxDate))
                                    .Add(Projections.Property(() => a.Amount).WithAlias(() => aDto.Amount))
                                    .Add(Projections.Property(() => a.TxType).WithAlias(() => aDto.TxType))
                                    .Add(Projections.Property(() => a.Comments).WithAlias(() => aDto.Comments));
                        var query = session.QueryOver<AccountTransaction>(() => a)
                            .Left.JoinAlias(() => a.FirmAccount, () => fa);
                        result = query.Where(() => a.FirmNumber == firmNumber && fa.Id == Id && a.TxDate >= startDate)
                                    .OrderBy(() => a.TxDate).Desc().ThenBy(() => a.InsertDate).Desc()
                                    .Select(proj)
                                    .TransformUsing(new DeepTransformer<AccountTransactionDTO>()).List<AccountTransactionDTO>();
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while fetching Account transactions:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
    }
}