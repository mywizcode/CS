﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initCancelledUnitSearchGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initCancelledUnitSearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        pageLength: 10
    };

    $("[id$='cancelledUnitSearchGrid']").CSBasicDatatable(dtOptions);
}




