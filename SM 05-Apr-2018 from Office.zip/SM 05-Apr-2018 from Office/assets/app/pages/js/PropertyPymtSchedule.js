﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initPymtScheduleGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initPymtScheduleGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: isViewOnly,
        customBtnGrpId: "#pymtScheduleGridBtnDiv",
        pageLength: 10,
        hideSearch: true,
        sorting: false
    };

    $("[id$='pymtScheduleGrid']").CSBasicDatatable(dtOptions);
}




