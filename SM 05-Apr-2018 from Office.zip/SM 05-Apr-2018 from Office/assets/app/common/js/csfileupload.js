var attachment = "<li class=\"media uploaded-file\"><div class=\"media-left media-middle\"><i class=\"icon-checkmark-circle text-success\"></i></div><div class=\"media-body\">" +
                 "<span class=\"media-heading text-semibold\" title=\"FILENAME\">FILENAME</span><span class=\"text-size-mini text-muted display-block\">SIZE</span>" +
				 "</div><div class=\"media-right media-middle\"><a href=\"javascript:void(0)\" data-filename=\"FILENAME\" data-error=\"ERROR_CNTRL_ID\"" +
                 "data-ajax-blockui=\"BLOCKUI_PANEL\" data-upload-container=\"UPLOAD_CONTAINDER\" data-src-elementid=\"SRC_ELEMENT_ID\" onclick=\"deleteTmpUploadedFile(this);\">" +
                 "<i class=\"icon-bin text-warning-400\"></i></a></div></li>";

function uploadFiles(element) {
    var formData = new FormData();
    var totalFiles = element.files.length;
    if (totalFiles == 0) return;
    var blockPanel = $(element).attr('data-ajax-blockui');
    formData.append("Function", $(element).attr('data-function'));//Function name used to validate files
    formData.append("Path", $("[id$='currentAbsPathHdn']").val());//Path to upload files
    formData.append("UserName", $("[id$='hdnUserName']").val());
    for (var i = 0; i < totalFiles; i++) {
        formData.append("Files", element.files[i]);
    }
    blockMe(blockPanel, "Uploading...");
    $.ajax({
        type: 'post',
        url: '/api/FileUpload/UploadFiles',
        data: formData,
        dataType: 'json',
        contentType: false,
        processData: false,
        success: function (data, textStatus, xhr) {
            unblockMe(blockPanel);
            $("[id$='btnPostFileUploadAction']").click();
        },
        error: function (xhr, textStatus, errorThrown) {
            unblockMe(blockPanel);
            createNotyMsg(errorThrown, "error", false);
        }
    });
}

function uploadTmpFile(element) {
    var formData = new FormData();
    var totalFiles = element.files.length;
    if (totalFiles == 0) return;
    var blockPanel = $(element).attr('data-ajax-blockui');
    var uploadContainer = $(element).attr('data-upload-container');
    var errorCntrlId = $(element).attr('data-error');
    var elementId = $(element).attr('id');
    formData.append("UserName", $("[id$='hdnUserName']").val());
    formData.append("Function", $(element).attr('data-function'));//Function name used to validate files

    for (var i = 0; i < totalFiles; i++) {
        formData.append("Files", element.files[i]);
    }
    showError(errorCntrlId, "");
    blockMe(blockPanel, "Uploading...");
    $.ajax({
        type: 'post',
        url: '/api/FileUpload/UploadFiles',
        data: formData,
        dataType: 'json',
        contentType: false,
        processData: false,
        success: function (data, textStatus, xhr) {
            unblockMe(blockPanel);
            showUploadedFiles(elementId, $.parseJSON(data), blockPanel, uploadContainer, errorCntrlId);
        },
        error: function (xhr, textStatus, errorThrown) {
            unblockMe(blockPanel);
            showError(errorCntrlId, errorThrown);
        }
    });
}
function deleteTmpUploadedFile(element) {
    var formData = new FormData();
    formData.append("FileName", $(element).attr('data-filename'));
    formData.append("UserName", $("[id$='hdnUserName']").val());
    var blockPanel = $(element).attr('data-ajax-blockui');
    var errorCntrlId = $(element).attr('data-error');
    var uploadContainer = $(element).attr('data-upload-container');
    var errorCntrlId = $(element).attr('data-src-elementid');
    showError(errorCntrlId, "");
    blockMe(blockPanel, "Deleting...");
    $.ajax({
        type: 'post',
        url: '/api/FileUpload/DeleteFile',
        data: formData,
        dataType: 'json',
        contentType: false,
        processData: false,
        success: function (data, textStatus, xhr) {
            unblockMe(blockPanel);
            showUploadedFiles(errorCntrlId, $.parseJSON(data), blockPanel, uploadContainer, errorCntrlId);
        },
        error: function (xhr, textStatus, errorThrown) {
            unblockMe(blockPanel);
            showError(errorCntrlId, errorThrown);
        }
    });
}
/**
This function is called when any modal is shown after postback and 'TmpUploadfileCntrlTarget' is not empty. It is called from constrosoft.js
When files are uploaded in temporary folder and any partial postback call is doen then after modal is rendered back then temporary uploaded files need to show again.
This is achieved through calling GetFiles web api and it is called when modal is shown.
*/
function fetchTmpUploadedFiles(elementId) {
    var $element = $("[id$='" + elementId + "']");
    var formData = new FormData();
    formData.append("UserName", $("[id$='hdnUserName']").val());
    var blockPanel = $element.attr('data-ajax-blockui');
    var errorCntrlId = $element.attr('data-error');
    var uploadContainer = $element.attr('data-upload-container');
    
    blockMe(blockPanel, "Fetching uploaded files...");
    $.ajax({
        type: 'post',
        url: '/api/FileUpload/GetFiles',
        data: formData,
        dataType: 'json',
        contentType: false,
        processData: false,
        success: function (data, textStatus, xhr) {
            unblockMe(blockPanel);
            showUploadedFiles(elementId, $.parseJSON(data), blockPanel, uploadContainer, errorCntrlId);
        },
        error: function (xhr, textStatus, errorThrown) {
            unblockMe(blockPanel);
            //If there is no error(may present through code behind validation) then only show error caused during retrieving files.
            if ($("[id$='" + errorCntrlId + "']").find('ul').length == 0) showError(errorCntrlId, errorThrown);
        }
    });
}
function showUploadedFiles(srcElementId, data, blockuiPanel, uploadContainer, errorCntrlId) {
    var fileContainer = "";
    var tmpSrcElementId = "";
    if (data.length > 0) {
        tmpSrcElementId = srcElementId;
        var files = "";
        $.each(data, function (index, value) {
            files += attachment.replace(/FILENAME/g, value.FileName)
                    .replace(/SIZE/g, value.Size)
                    .replace(/BLOCKUI_PANEL/g, blockuiPanel)
                    .replace(/UPLOAD_CONTAINDER/g, uploadContainer)
                    .replace(/ERROR_CNTRL_ID/g, errorCntrlId)
                    .replace(/SRC_ELEMENT_ID/g, srcElementId);
        });
        fileContainer = "<ul class=\"media-list mt-10\">" + files + "</ul>";
    }
    //It is used to check whether any file is present in temporary upload folder.
    $("[id$='hasFilesUploaded']").val((tmpSrcElementId != "") ? "Y" : "N");
    //It is used find file input which is active/used to upload temporary files
    $("[id$='TmpUploadfileCntrlTarget']").val(tmpSrcElementId);
    $('.' + uploadContainer).html(fileContainer);
}
function showError(errorCntrlId, msg) {
    if (msg && msg != "") {
        $("[id$='" + errorCntrlId + "']").html("<ul><li>" + msg + "</li></ul>");
        $("[id$='" + errorCntrlId + "']").css("display", "block");
    } else {
        $("[id$='" + errorCntrlId + "']").html("");
        $("[id$='" + errorCntrlId + "']").css("display", "none");
    }
}
