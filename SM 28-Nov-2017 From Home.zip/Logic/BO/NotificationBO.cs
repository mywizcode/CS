﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;
using ConstroSoft.Logic.CachingProvider;


/// <summary>
/// Summary description for PropertyAlertBO
/// </summary>
namespace ConstroSoft
{
    public class NotificationBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public NotificationBO() { }

        public void fetchAndCacheUserNotifications(UserDefinitionDTO userDefDTO, long propertyId)
        {
            ISession session = null;
            List<NotificationDTO> allNotificationList = new List<NotificationDTO>();
            try
            {
            	session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	Notification notification = null;
                        //Fetch all notifications which are open for given user and property
                        var query = session.QueryOver<Notification>(() => notification);
                        IList<Notification> result = query.Where(() => notification.UserName == userDefDTO.Username 
                                && notification.PropertyId == propertyId && notification.Status == NotificationStatus.OPEN).List<Notification>();
                        foreach (Notification tmpObj in result)
                        {
                            allNotificationList.Add(DomainToDTOUtil.convertToNotificationDTO(tmpObj, true));
                        }
                        //Fetch qualifying Tasks scheduled
                       /* DateTime cutOffDate = DateTime.Now.AddDays(1);
                        LeadActivity leadActivity = null;
                        var query = session.QueryOver<LeadActivity>(() => leadActivity);
                        IList<LeadActivity> tmpLeadTaskList = query.Where(() => leadActivity.RecordType == EnqActivityRecordType.Task 
                        		&& leadActivity.ScheduledDate <= cutOffDate).List<LeadActivity>();
                        foreach (LeadActivity lActivity in result)
                        {
                        	NotificationDTO tmpDTO = new NotificationDTO();
                        	tmpDTO.Type = NotificationType.TASK;
                        	tmpDTO.SubType = NotificationSubType.LEAD_TASK_SCHEDULED;
                        	tmpDTO.Message = lActivity.RefNo+"¶"+lActivity.LeadDetail.LeadRefNo+"¶"+lActivity.ScheduledDate;
                        	tmpDTO.Status = NotificationStatus.OPEN;
                        	taskDto.PropertyId = propertyId;
                        	taskDto.UserName = userDefDTO.Username;
                        	
                        }*/
                        
                        NotificationCacheProvider.Instance.clearAndAddNotifications(
                            NotificationUtil.getNotificationUserKey(userDefDTO.Username, propertyId), allNotificationList);
                    }
                    catch (Exception e)
                    {
                    	log.Error("Unexpected error populating Notification for given user: " + userDefDTO.Username +", and property:" + propertyId, e);
                        log.Error(e.Message, e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void markNotificationClosed(long Id)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	Notification dbNotification = session.Get<Notification>(Id);
                        if(dbNotification != null && (dbNotification.Status == NotificationStatus.OPEN)) {
                        	dbNotification.Status = NotificationStatus.CLOSED;
                        	session.Update(dbNotification);
                            tx.Commit();
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while marking notification as closed:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void addNotification(NotificationDTO notificationDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Notification notification = DTOToDomainUtil.populateNotificationAddFields(notificationDTO);
                        session.Save(notification);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while adding Notification:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }

    }
}