﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using ConstroSoft.Logic.BO;

public partial class UserLeadHistory : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string selectUserAssigneeModalError = "selectUserAssigneeModalError";
    string SearchFilterModal = "SearchFilterModal";
    string selectUserAssigneeModal = "selectUserAssigneeModal";
    DropdownBO drpBO = new DropdownBO();
    EnquiryBO enquiryBO = new EnquiryBO();
    SoldPropertyUnitBO soldUnitBO = new SoldPropertyUnitBO();
    protected void Page_Load(object sender, EventArgs e)
    {
    	if (ApplicationUtil.isSubPageRendered(Page)) clearMessages();
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                UserLeadHistoryNavDTO navDto = CommonUtil.getPageNavDTO<UserLeadHistoryNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_ALL_ENQ_LEADS)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageLayout();
    }
    public void initBootstrapComponantsFromServer()
    {
    	ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        drpBO.drpDataBase(drpSourceFilter, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ENQUIRY_SOURCE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<LeadStatus>(drpStatusFilter, Constants.SELECT_ITEM);

        drpBO.drpDataBase(drpUserAssignee, DrpDataType.ACTIVE_USERS_WITH_PR_ACCESS, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(), 
            Constants.SELECT_ITEM, userDefDto.FirmNumber);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(UserLeadHistoryNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(UserLeadHistoryNavDTO navDto)
    {
        try
        {
            UserLeadHistoryPageDTO PageDTO = new UserLeadHistoryPageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            PageDTO.FirmMemberId = navDto.FirmMemberId;
            setSearchFilter(navDto.FilterDTO);
            loadSummaryAndHistory();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageLayout()
    {
    }
    private void navigateToPreviousPage()
    {
        UserLeadHistoryPageDTO PageDTO = getSessionPageData();
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is AllEnquiryLeadHistoryPageDTO)
            {
                AllEnquiryLeadHistoryPageDTO navDTO = (AllEnquiryLeadHistoryPageDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.ALL_ENQUIRY_LEAD_HISTORY, true);
            }
        }
        Response.Redirect(Constants.URL.ALL_ENQUIRY_LEAD_HISTORY, true);
    }
    private void setSearchGrid(IList<UserLeadHistoryUIDTO> tmpList)
    {
        getSessionPageData().SearchResult = (tmpList != null) ? tmpList.ToList<UserLeadHistoryUIDTO>() : new List<UserLeadHistoryUIDTO>();
        userLeadHistorySearchGrid.DataSource = getSearchList();
        userLeadHistorySearchGrid.DataBind();
    }
    private UserLeadHistoryPageDTO getSessionPageData()
    {
        return (UserLeadHistoryPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<UserLeadHistoryUIDTO> getSearchList()
    {
        return getSessionPageData().SearchResult;
    }
    private UserLeadHistoryUIDTO getSearchDTO(long Id)
    {
        List<UserLeadHistoryUIDTO> searchList = getSearchList();
        UserLeadHistoryUIDTO selectedUnitDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            selectedUnitDTO = searchList.Find(c => c.LeadId == Id);
        }
        return selectedUnitDTO;
    }
    private void loadSummaryAndHistory()
    {
        UserLeadHistoryPageDTO PageDTO = getSessionPageData();
        long FirmMemberId = PageDTO.FirmMemberId;
        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        PropertyDTO property = CommonUtil.getCurrentPropertyDTO(userDefDTO);
        AllEnquiryLeadUIDTO LeadSummaryDTO = enquiryBO.fetchLeadHistorySummaryForUser(property.Id, FirmMemberId);
        PageDTO.LeadSummary = LeadSummaryDTO;
        lbUserFullName.Text = CommonUIConverter.getCustomerFullName(LeadSummaryDTO.Salutation, LeadSummaryDTO.FirstName, "", LeadSummaryDTO.LastName);
        lbUserContact.Text = LeadSummaryDTO.Contact;
        lbUserEmail.Text = LeadSummaryDTO.Email;
        lbLeadOpen.Text = LeadSummaryDTO.LeadsOpen.ToString();
        lbLeadConverted.Text = LeadSummaryDTO.LeadsConverted.ToString();
        lbLeadLost.Text = LeadSummaryDTO.LeadsLost.ToString();

        loadLeadHistoryGrid();
    }
    private void loadLeadHistoryGrid()
    {
        UserLeadHistoryPageDTO PageDTO = getSessionPageData();
        long FirmMemberId = PageDTO.FirmMemberId;
        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();
        PropertyDTO property = CommonUtil.getCurrentPropertyDTO(userDefDTO);
        IList<UserLeadHistoryUIDTO> results = enquiryBO.fetchLeadHistoryForUser(property.Id, FirmMemberId, getSearchFilter());
        setSearchGrid(results);
    }
    private UserLeadHistoryNavDTO getCurrentPageNavigation()
    {
        UserLeadHistoryPageDTO PageDTO = getSessionPageData();
        UserLeadHistoryNavDTO navDTO = new UserLeadHistoryNavDTO();
        navDTO.FirmMemberId = PageDTO.FirmMemberId;
        navDTO.FilterDTO = getSearchFilter();
        navDTO.PrevNavDto = PageDTO.PrevNavDTO;
        return navDTO;
    }
    protected void onClickActiveHistoryBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            LeadActivityHistoryNavDTO navDTO = new LeadActivityHistoryNavDTO();
            navDTO.LeadId = selectedId;
            navDTO.PrevNavDto = getCurrentPageNavigation();
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.LEAD_ACTIVITY_HISTORY, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickEnquiryDetailsBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            UserLeadHistoryUIDTO leadDTO = getSearchList().Find(x => x.LeadId == selectedId);
            if (leadDTO.Status == LeadStatus.Converted && !string.IsNullOrWhiteSpace(leadDTO.EnquiryRefNo))
            {
                EnquiryDetailNavDTO navDTO = new EnquiryDetailNavDTO();
                navDTO.Mode = PageMode.VIEW;
                navDTO.EnquiryId = leadDTO.EnquiryId;
                navDTO.PrevNavDto = getCurrentPageNavigation();
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.ENQUIRY_DETAILS, true);
            }
            else
            {
                setNotyMsg(CommonUtil.getNotyErrorMsg(string.Format("Lead# {0} is is not Converted.", leadDTO.LeadRefNo)));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickReassignLeadBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            selectLead(selectedId);
            UserLeadHistoryUIDTO leadDTO = getSelectedLead();
            if (leadDTO.Status == LeadStatus.Open)
            {
                drpUserAssignee.ClearSelection();
                activeModalHdn.Value = selectUserAssigneeModal;
            }
            else
            {
                setNotyMsg(CommonUtil.getNotyErrorMsg(Resources.Messages.ERROR_LEAD_REASSIGN_NOT_OPEN));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //User Assignee Selection logic - start
    private void selectLead(long LeadId)
    {
        List<UserLeadHistoryUIDTO> searchResult = getSessionPageData().SearchResult;
        searchResult.ForEach(c => c.isUISelected = false);
        if (LeadId > 0) searchResult.Find(x => x.LeadId == LeadId).isUISelected = true;
    }
    private UserLeadHistoryUIDTO getSelectedLead()
    {
        List<UserLeadHistoryUIDTO> searchResult = getSessionPageData().SearchResult;
        return searchResult.Find(c => c.isUISelected);
    }
    protected void ReassignLead(object sender, EventArgs e)
    {
        try
        {
            Page.Validate(selectUserAssigneeModalError);
            bool isValid = Page.IsValid;
            if (isValid)
            {
                long AssigneeId = long.Parse(drpUserAssignee.Text);
                UserLeadHistoryUIDTO LeadUIDTO = getSelectedLead();
                enquiryBO.ReAssignLead(LeadUIDTO.LeadId, AssigneeId, DateTime.Now, getUserDefinitionDTO());
                selectLead(0);
                setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format("Lead# {0} is reassigneed successfully.", LeadUIDTO.LeadRefNo)));
                loadSummaryAndHistory();
            }
            else
            {
                activeModalHdn.Value = selectUserAssigneeModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelUserAssigneeModal(object sender, EventArgs e)
    {
        try
        {
            selectLead(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //User Assignee Selection logic - end
    //Filter Criteria - Lead Search - Start
    private LeadFilterDTO getSearchFilter()
    {
        return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            LeadFilterDTO filterDTO = getSearchFilter();
            if (filterDTO.FirstName != null) txtFirstName.Text = filterDTO.FirstName; else txtFirstName.Text = null;
            if (filterDTO.LastName != null) txtLastName.Text = filterDTO.LastName; else txtLastName.Text = null;
            if (filterDTO.Contact != null) txtContact.Text = filterDTO.Contact; else txtContact.Text = null;
            if (filterDTO.LeadRefNo != null) txtLeadRefNo.Text = filterDTO.LeadRefNo; else txtLeadRefNo.Text = null;
            if (filterDTO.SourceId > 0) drpSourceFilter.Text = filterDTO.SourceId.ToString(); else drpSourceFilter.ClearSelection();
            if (filterDTO.Status != null) drpStatusFilter.Text = filterDTO.Status.ToString(); else drpStatusFilter.Text = null;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            LeadFilterDTO filterDTO = new LeadFilterDTO();
            if (!string.IsNullOrWhiteSpace(txtFirstName.Text))
            {
                filterDTO.FirstName = txtFirstName.Text;
            }
            if (!string.IsNullOrWhiteSpace(txtLastName.Text))
            {
                filterDTO.LastName = txtLastName.Text;
            }
            if (!string.IsNullOrWhiteSpace(txtContact.Text))
            {
                filterDTO.Contact = txtContact.Text;
            }
            if (!string.IsNullOrWhiteSpace(txtLeadRefNo.Text))
            {
                filterDTO.LeadRefNo = txtLeadRefNo.Text;
            }
            if (!string.IsNullOrWhiteSpace(drpSourceFilter.Text))
            {
                filterDTO.SourceId = long.Parse(drpSourceFilter.Text);
                filterDTO.Source = drpSourceFilter.SelectedItem.Text;
            }
            if (!string.IsNullOrWhiteSpace(drpStatusFilter.Text))
            {
                filterDTO.Status = EnumHelper.ToEnum<LeadStatus>(drpStatusFilter.SelectedItem.Text);
            }
            setSearchFilter(filterDTO);
            loadLeadHistoryGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }

    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            loadLeadHistoryGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(LeadFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new LeadFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            LeadFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.FIRST_NAME))
            {
                filterDTO.FirstName = null;
            }
            else if (token.StartsWith(Constants.FILTER.LAST_NAME))
            {
                filterDTO.LastName = null;
            }
            else if (token.StartsWith(Constants.FILTER.CONTACT))
            {
                filterDTO.Contact = null;
            }
            else if (token.StartsWith(Constants.FILTER.LEAD_REF_NO))
            {
                filterDTO.LeadRefNo = null;
            }
            else if (token.StartsWith(Constants.FILTER.SOURCE))
            {
                filterDTO.SourceId = 0;
                filterDTO.Source = null;
            }
            else if (token.StartsWith(Constants.FILTER.STATUS))
            {
                filterDTO.Status = null;
            }

            setSearchFilterTokens();
            loadLeadHistoryGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        LeadFilterDTO filterDTO = getSearchFilter();
        string filter = null;
        if (filterDTO != null)
        {
            if (filterDTO.FirstName != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.FIRST_NAME + filterDTO.FirstName);
            if (filterDTO.LastName != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.LAST_NAME + filterDTO.LastName);
            if (filterDTO.Contact != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.CONTACT + filterDTO.Contact);
            if (filterDTO.LeadRefNo != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.LEAD_REF_NO + filterDTO.LeadRefNo);
            if (filterDTO.Source != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.SOURCE + filterDTO.Source);
            if (filterDTO.Status != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.STATUS + filterDTO.Status);
        }
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - Enquiry Search - End
}
