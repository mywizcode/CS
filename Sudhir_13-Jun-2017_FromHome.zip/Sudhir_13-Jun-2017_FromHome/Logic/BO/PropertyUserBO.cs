﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;


/// <summary>
/// Summary description for EmployeeBO
/// </summary>
namespace ConstroSoft
{
    public class PropertyUserBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public PropertyUserBO() { }

        public IList<UserDefinitionDTO> fetchUserGridData(string firmNumber, long propertyId)
        {
            ISession session = null;
            IList<UserDefinitionDTO> result = new List<UserDefinitionDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                UserDefinition ud = null;
                UserDefinitionDTO udt = null;
                Property p = null;
                FirmMember fm = null;
                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => ud.Id).WithAlias(() => udt.Id))
                            .Add(Projections.Property(() => ud.Username).WithAlias(() => udt.Username))
                            .Add(Projections.Property(() => fm.FirstName), "FirmMember.FirstName")
                            .Add(Projections.Property(() => fm.LastName), "FirmMember.LastName")
                            .Add(Projections.Property(() => ud.ActivationDate).WithAlias(() => udt.ActivationDate))
                            .Add(Projections.Property(() => ud.ExpirationDate).WithAlias(() => udt.ExpirationDate))
                            .Add(Projections.Property(() => ud.Status).WithAlias(() => udt.Status));
                var query = session.QueryOver<UserDefinition>(() => ud)
                            .Inner.JoinAlias(() => ud.FirmMember, () => fm);
                result = query.Where(() => ud.FirmNumber == firmNumber && ud.Status == UserStatus.Active)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<UserDefinitionDTO>()).List<UserDefinitionDTO>();
                var proj1 = Projections.ProjectionList()
                            .Add(Projections.Property(() => ud.Id).WithAlias(() => udt.Id))
                            .Add(Projections.Property(() => ud.Username).WithAlias(() => udt.Username));
                var query1 = session.QueryOver<UserDefinition>(() => ud)
                            .Inner.JoinAlias(() => ud.FirmMember, () => fm)
                            .Left.JoinAlias(() => ud.AssignedProperties, () => p);
                IList<UserDefinitionDTO> assignedUsers = query1.Where(() => ud.FirmNumber == firmNumber && ud.Status == UserStatus.Active && p.Id == propertyId)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<UserDefinitionDTO>()).List<UserDefinitionDTO>();
                result.ToList<UserDefinitionDTO>().ForEach(x => x.isUISelected = assignedUsers.Any(y => y.Id == x.Id));
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating property user access:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public void updatePropertyAssignedUsers(ISet<UserDefinitionDTO> assignedDtos, long propertyId)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Property property = session.Get<Property>(propertyId);
                        ISet<UserDefinition> assignedUsers = property.AssignedUsers;
                        if (assignedDtos != null)
                        {
                            for (int i = 0; i < assignedUsers.Count; i++)
                            {
                                UserDefinition userDefinition = assignedUsers.ElementAt(i);
                                if (!(assignedDtos.Any(x => x.Id == userDefinition.Id && x.isUISelected)))
                                {
                                    assignedUsers.Remove(userDefinition);
                                    i--;
                                }
                            }
                            foreach (UserDefinitionDTO userDefinitionDTO in assignedDtos)
                            {
                                if (userDefinitionDTO.isUISelected && !assignedUsers.Any(x => x.Id == userDefinitionDTO.Id))
                                {
                                    UserDefinition newUserDefinition = new UserDefinition();
                                    newUserDefinition.Id = userDefinitionDTO.Id;
                                    property.AssignedUsers.Add(newUserDefinition);
                                }
                            }
                        }
                        else
                        {
                            property.AssignedUsers.Clear();
                        }
                        session.Update(property);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating property user access details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        
    }
}