﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ConstroSoft.pages.Login
{
    public partial class ChangePassword : System.Web.UI.Page
    {
        private static readonly log4net.ILog log =
         log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private string oldPasswordErrorGrp = "oldPasswordErrorGrp";
        private string changePasswordErrorGrp = "changePasswordGrp";        
        private string USERDEFINITION = "USERDEFINITION";
        LoginBO loginBO = new LoginBO();
        string username = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                UserDefinitionDTO userDef = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
                if (userDef.Username != null) username = userDef.Username; else username = null;
            }
        }
        protected void Page_PreRender(object sender, EventArgs e)
        {
            initBootstrapComponantsFromServer();
        }
        public void setErrorMessage(string message, string group)
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }
        public void initBootstrapComponantsFromServer()
        {
            
        }
        protected void validateOldPassword(object sender, EventArgs e)
        {
            try
            {
                UserDefinitionDTO userDef = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
                if (userDef.Username != null) username = userDef.Username; else username = null;
                if (!string.IsNullOrWhiteSpace(username))
                {
                    BusinessOutputTO outputTO = loginBO.validateUser(username, txtOldPassword.Text);
                    if (outputTO.status == BusinessOutputTO.Status.SUCCESS)
                    {
                        UserDefinitionDTO userDefDto = (UserDefinitionDTO)outputTO.result;
                        ViewState[USERDEFINITION] = userDefDto;

                        pnlChangePassword.Visible = true;
                        pnlOldPassword.Visible = false;

                    }
                    else
                    {
                        setErrorMessage("Old password not matching", oldPasswordErrorGrp);
                    }
                }
                else
                {
                    setErrorMessage("Invalid user name", oldPasswordErrorGrp);
                }
            }
            catch (Exception ex)
            {
                log.Error("Unexpected error:", ex);
                setErrorMessage(Resources.Messages.system_error, oldPasswordErrorGrp);
            }
        }   
     
        protected void resetPassword(object sender, EventArgs e)
        {
            try
            {
                if (validateResetPassword())
                {
                    UserDefinitionDTO userDefDto = (UserDefinitionDTO)ViewState[USERDEFINITION];
                    loginBO.resetPassword(userDefDto.Username, txtNewPassword.Text);
                    Session.Add(Constants.Session.SUCCESS_MSG, "Password is reset successfully");
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
            catch (Exception ex)
            {
                log.Error("Unexpected error:", ex);
                Session.Add(Constants.Session.ERROR_MSG, CommonUtil.getErrorMessage(ex));
                Response.Redirect(Constants.URL.LOGIN, false);

            }
        }
        private bool validateResetPassword()
        {
            Page.Validate(changePasswordErrorGrp);
            bool result = Page.IsValid;
            if (result)
            {
                if (!txtNewPassword.Text.Equals(txtConfirmPassword.Text.Trim()))
                {
                    result = false;
                    setErrorMessage("New Password and Confirm Password does not match", changePasswordErrorGrp);
                }
            }
            return result;
        }
        protected void goToLoginPage(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                log.Error("Unexpected error:", ex);
                setErrorMessage(Resources.Messages.system_error, changePasswordErrorGrp);
            }
        }
    }
}