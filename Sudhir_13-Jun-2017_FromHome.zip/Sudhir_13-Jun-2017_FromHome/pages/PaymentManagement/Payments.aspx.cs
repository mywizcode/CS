﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;

public partial class Payments : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string tab1ValidationGrp = "tab1Error";
    string tab2ValidationGrp = "tab2Error";
    string tab2ChqPymtValidationGrp = "tab2ChqPymtError";
    string VS_SEARCH_GRIDDATA = "VS_SEARCH_GRIDDATA";
    string VS_PYMT_MATSER = "VS_PYMT_MASTER";
    enum PymtPageMode { ADD_PYMT, PYMT_HISTORY, PYMT_HISTORY_READONLY, NONE }
    PaymentBO paymentBO = new PaymentBO();
    DropdownBO drpBO = new DropdownBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                resetTabInfo(PymtPageMode.NONE);
                initDropdowns();
                Page.MaintainScrollPositionOnPostBack = false;
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpSelectProperty, DrpDataType.PROPERTY_NAME, userDefDto.Id.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpInit(drpSelectPropertyTower, Constants.SELECT_ITEM);
        drpBO.drpDataBase(drpAccount, DrpDataType.FIRM_ACCOUNT, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<PaymentFromSearchBy>(drpSelectPymtFrom, null);
        drpBO.populateDrpPymtToSearchBy(drpSelectPymtTo, PaymentFromSearchBy.NONE);
        drpBO.drpEnum<PaymentMode>(drpPaymentMode, null);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        addPymtTransBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MAKE_PAYMENT);
    }
    private void preRenderInitFormElements()
    {
        populateTab2Info();
        setJumpToField();
        jumpToPymtHistoryHdnId.Value = "";
        PaymentMasterDTO pymtMasterDto = getCurrentPymtMaster();
        if (pymtMasterDto != null)
        {
            PaymentTransactionDTO pymtTransDto = pymtMasterDto.PaymentTransactions.ToList<PaymentTransactionDTO>().Find(p => p.isUISelected);
            if (pymtTransDto != null) jumpToPymtHistoryHdnId.Value = pymtTransDto.UiIndex + "";
        }
    }
    private void setJumpToField()
    {
        jumpToCustToFromBuilderHdnId.Value = "";
        string pymtDirection = getPaymentDirection();
        if (Constants.PYMT_DIRECTION.CUSTOMER_FIRM.Equals(pymtDirection) || Constants.PYMT_DIRECTION.FIRM_CUSTOMER.Equals(pymtDirection))
        {
            PrUnitSalePymtDTO prUnitSalePymtDto = getCurrentCustToFromBuilderPymt();
            if (prUnitSalePymtDto != null) jumpToCustToFromBuilderHdnId.Value = prUnitSalePymtDto.PaymentMaster.Id + "";
        }
        else if (Constants.PYMT_DIRECTION.FIRM_CONTRACTOR.Equals(pymtDirection))
        {
        }
        else if (Constants.PYMT_DIRECTION.FIRM_SUPPLIER.Equals(pymtDirection))
        {
        }
        else if (Constants.PYMT_DIRECTION.FIRM_AGENCY.Equals(pymtDirection))
        {
            PropertyExpenseDTO prExpenseDto = getCurrentFirmToAgencyPymt();
            if (prExpenseDto != null) jumpToFirmToAgencyHdnId.Value = prExpenseDto.PaymentMaster.Id + "";
        }
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }

    public void setSuccessMessage(string msg, string tabId)
    {
        activeTabHdn.Value = tabId;
        if (tabId.Equals(tab1Anchor.ID))
        {
            lbTab1Success.Text = msg;
            tab1SuccessPanel.Visible = true;
        }
        if (tabId.Equals(tab2Anchor.ID))
        {
            lbTab2Success.Text = msg;
            tab2SuccessPanel.Visible = true;
        }
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private void clearMessages()
    {
        tab1SuccessPanel.Visible = false;
        lbTab1Success.Text = "";
        tab2SuccessPanel.Visible = false;
        lbTab2Success.Text = "";

    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }

    private void resetTabInfo(PymtPageMode pageMode)
    {
        tab2Anchor.Visible = false;
        activeTabHdn.Value = tab1Anchor.ID;
        pageModeHdn.Value = pageMode.ToString();
        initFormFields();
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        ViewState[VS_PYMT_MATSER] = null;
        pnlCustToFromBuilderInfo.Visible = false;
        pnlFirmToAgencyInfo.Visible = false;
        if (PymtPageMode.ADD_PYMT == pageMode || PymtPageMode.PYMT_HISTORY == pageMode || PymtPageMode.PYMT_HISTORY_READONLY == pageMode)
        {
            tab2Anchor.Visible = true;
            activeTabHdn.Value = tab2Anchor.ID;
            initFormFields();
            initTab2(pageMode);
        }
        else
        {

            tab2Anchor.Visible = false;
        }
    }
    private void initFormFields()
    {
        bool visible = !(PymtPageMode.PYMT_HISTORY_READONLY.ToString().Equals(pageModeHdn.Value));
        //Buttons
        pymtTransBtnGrp.Visible = visible;
        pymtHistoryGrid.Columns[0].Visible = visible;

    }
    private void initTab2(PymtPageMode pageAction)
    {
        if (PymtPageMode.PYMT_HISTORY == pageAction || PymtPageMode.PYMT_HISTORY_READONLY == pageAction)
        {
            tab2Anchor.Text = Resources.Labels.pymt_sm_payments_tab2_pymt_history;
            pnlPymtHistoryGrid.Visible = true;
            pnlAddPayment.Visible = false;
        }
        else if (PymtPageMode.ADD_PYMT == pageAction)
        {
            tab2Anchor.Text = Resources.Labels.pymt_sm_payments_tab2_add_pymt;
            pnlPymtHistoryGrid.Visible = false;
            pnlAddPayment.Visible = true;
            pnlChequeAdditionInfo.Visible = false;
        }
    }
    private void populateTab2Info()
    {
        if (tab2Anchor.Visible)
        {
            string pymtDirection = getPaymentDirection();
            if (Constants.PYMT_DIRECTION.CUSTOMER_FIRM.Equals(pymtDirection) || Constants.PYMT_DIRECTION.FIRM_CUSTOMER.Equals(pymtDirection))
            {
                populateCustToFromBuilderInfo(getCurrentCustToFromBuilderPymt());
            }
            else if (Constants.PYMT_DIRECTION.FIRM_CONTRACTOR.Equals(pymtDirection))
            {
            }
            else if (Constants.PYMT_DIRECTION.FIRM_SUPPLIER.Equals(pymtDirection))
            {
            }
            else if (Constants.PYMT_DIRECTION.FIRM_AGENCY.Equals(pymtDirection))
            {
                populateFirmToAgencyInfo(getCurrentFirmToAgencyPymt());
            }
        }
    }
    private List<PrUnitSalePymtDTO> getCustToFromBuilderGridList()
    {
        return (List<PrUnitSalePymtDTO>)ViewState[VS_SEARCH_GRIDDATA];
    }
    private PrUnitSalePymtDTO getCurrentCustToFromBuilderPymt()
    {
        return (getCustToFromBuilderGridList() != null) ? getCustToFromBuilderGridList().Find(c => c.isUISelected) : null;
    }
    private List<PropertyExpenseDTO> getFirmToAgencyGridList()
    {
        return (List<PropertyExpenseDTO>)ViewState[VS_SEARCH_GRIDDATA];
    }
    private PropertyExpenseDTO getCurrentFirmToAgencyPymt()
    {
        return (getFirmToAgencyGridList() != null) ? getFirmToAgencyGridList().Find(c => c.isUISelected) : null;
    }
    private PaymentMasterDTO getCurrentPymtMaster()
    {
        return (PaymentMasterDTO)ViewState[VS_PYMT_MATSER];
    }
    private void fetchAllPayments(long id)
    {
        pnlPymtSearchGrid.Visible = false;
        if (isValidPymtSearchSelection())
        {
            pnlPymtSearchGrid.Visible = true;
            custToFromBuilderPymtGrid.Visible = false;
            firmToAgencyPymtGrid.Visible = false;
            string pymtDirection = getPaymentDirection();
            pymtDirectionHdn.Value = pymtDirection;
            long propertyId = long.Parse(drpSelectProperty.Text);
            long propertyTowerId = long.Parse(drpSelectPropertyTower.Text);
            PaymentSearchBy searchBy = EnumHelper.ToEnum<PaymentSearchBy>(drpSearchBy.Text);
            long searchByValue = (!string.IsNullOrWhiteSpace(drpSearchByValue.Text)) ? long.Parse(drpSearchByValue.Text) : -1;
            if (Constants.PYMT_DIRECTION.CUSTOMER_FIRM.Equals(pymtDirection) || Constants.PYMT_DIRECTION.FIRM_CUSTOMER.Equals(pymtDirection))
            {
                PRUnitSalePymtTo pymtTo = Constants.PYMT_DIRECTION.CUSTOMER_FIRM.Equals(pymtDirection) ? PRUnitSalePymtTo.Builder : PRUnitSalePymtTo.Customer;
                IList<PrUnitSalePymtDTO> result = paymentBO.fetchCustomerToFromFirmPayments(getUserDefinitionDTO().FirmNumber, propertyTowerId, pymtTo,
                        searchBy, searchByValue);
                custToFromBuilderPymtGrid.Visible = true;
                ViewState[VS_SEARCH_GRIDDATA] = result;
                custToFromBuilderPymtGrid.DataSource = result;
                custToFromBuilderPymtGrid.DataBind();
                if (id > 0) selectCustToFromBuilderSearchGridRdBtn(id);
            }
            else if (Constants.PYMT_DIRECTION.FIRM_CONTRACTOR.Equals(pymtDirection))
            {

            }
            else if (Constants.PYMT_DIRECTION.FIRM_SUPPLIER.Equals(pymtDirection))
            {
            }
            else if (Constants.PYMT_DIRECTION.FIRM_AGENCY.Equals(pymtDirection))
            {
                IList<PropertyExpenseDTO> result = paymentBO.fetchFirmToAgencyPayments(getUserDefinitionDTO().FirmNumber, propertyId, searchBy, searchByValue);
                firmToAgencyPymtGrid.Visible = true;
                ViewState[VS_SEARCH_GRIDDATA] = result;
                firmToAgencyPymtGrid.DataSource = result;
                firmToAgencyPymtGrid.DataBind();
                if (id > 0) selectFirmToAgencySearchGridRdBtn(id);
            }
        }
    }
    private bool isValidPymtSearchSelection()
    {
        bool isValid = true;
        PaymentFromSearchBy pymtFromSearchBy = EnumHelper.ToEnum<PaymentFromSearchBy>(drpSelectPymtFrom.Text);
        PaymentToSearchBy pymtToSearchBy = EnumHelper.ToEnum<PaymentToSearchBy>(drpSelectPymtTo.Text);
        if (string.IsNullOrWhiteSpace(drpSelectProperty.Text) || string.IsNullOrWhiteSpace(drpSelectPropertyTower.Text)
            || PaymentFromSearchBy.NONE == pymtFromSearchBy || PaymentToSearchBy.NONE == pymtToSearchBy)
        {
            isValid = false;
        }
        return isValid;
    }
    private string getPaymentDirection()
    {
        string pymtDirection = Constants.PYMT_DIRECTION.INVALID_PYMT_DIRECTION;
        PaymentFromSearchBy pymtFromSearchBy = EnumHelper.ToEnum<PaymentFromSearchBy>(drpSelectPymtFrom.Text);
        PaymentToSearchBy pymtToSearchBy = EnumHelper.ToEnum<PaymentToSearchBy>(drpSelectPymtTo.Text);
        if (PaymentFromSearchBy.FIRM == pymtFromSearchBy && PaymentToSearchBy.CUSTOMER == pymtToSearchBy) pymtDirection = Constants.PYMT_DIRECTION.FIRM_CUSTOMER;
        else if (PaymentFromSearchBy.FIRM == pymtFromSearchBy && PaymentToSearchBy.CONTRACTOR == pymtToSearchBy) pymtDirection = Constants.PYMT_DIRECTION.FIRM_CONTRACTOR;
        else if (PaymentFromSearchBy.FIRM == pymtFromSearchBy && PaymentToSearchBy.SUPPLIER == pymtToSearchBy) pymtDirection = Constants.PYMT_DIRECTION.FIRM_SUPPLIER;
        else if (PaymentFromSearchBy.FIRM == pymtFromSearchBy && PaymentToSearchBy.AGENCY == pymtToSearchBy) pymtDirection = Constants.PYMT_DIRECTION.FIRM_AGENCY;
        else if (PaymentFromSearchBy.CUSTOMER == pymtFromSearchBy && PaymentToSearchBy.FIRM == pymtToSearchBy) pymtDirection = Constants.PYMT_DIRECTION.CUSTOMER_FIRM;
        return pymtDirection;
    }
    protected void onSearchBy(object sender, EventArgs e)
    {
        try
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            PaymentSearchBy searchBy = EnumHelper.ToEnum<PaymentSearchBy>(drpSearchBy.Text);
            initSearchByValue(true);
            lbSearchByValue.Text = EnumHelper.GetEnumDescription<PaymentSearchBy>(searchBy.ToString());
            if (PaymentSearchBy.CUSTOMER_NAME == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.PYMT_SEARCH_BY_CUSTOMER_NAME, drpSelectPropertyTower.Text, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else if (PaymentSearchBy.UNIT_NO == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.PYMT_SEARCH_BY_UNITNO, drpSelectPropertyTower.Text, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else if (PaymentSearchBy.AGENCY == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.AGENCY, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else if (PaymentSearchBy.EXPENSE_TYPE == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_EXPENSE_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else
            {
                initSearchByValue(false);
            }
            fetchAllPayments(0);
            resetTabInfo(PymtPageMode.NONE);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private void initSearchByValue(bool isVisible)
    {
        drpSearchByValue.ClearSelection();
        drpSearchByValue.Visible = isVisible;
        lbSearchByValue.Visible = isVisible;
    }
    private void loadDrpSearchBy()
    {
        string pymtDirection = getPaymentDirection();
        drpSearchBy.Items.Clear();
        drpSearchBy.Items.Add(new ListItem(PaymentSearchBy.NONE.GetDescription(), PaymentSearchBy.NONE.ToString()));
        drpBO.drpInit(drpSearchByValue, Constants.SELECT_ITEM);
        initSearchByValue(false);
        if (Constants.PYMT_DIRECTION.CUSTOMER_FIRM.Equals(pymtDirection) || Constants.PYMT_DIRECTION.FIRM_CUSTOMER.Equals(pymtDirection))
        {
            drpSearchBy.Items.Add(new ListItem(PaymentSearchBy.CUSTOMER_NAME.GetDescription(), PaymentSearchBy.CUSTOMER_NAME.ToString()));
            drpSearchBy.Items.Add(new ListItem(PaymentSearchBy.UNIT_NO.GetDescription(), PaymentSearchBy.UNIT_NO.ToString()));
        }
        else if (Constants.PYMT_DIRECTION.FIRM_CONTRACTOR.Equals(pymtDirection))
        {
        }
        else if (Constants.PYMT_DIRECTION.FIRM_SUPPLIER.Equals(pymtDirection))
        {
        }
        else if (Constants.PYMT_DIRECTION.FIRM_AGENCY.Equals(pymtDirection))
        {
            drpSearchBy.Items.Add(new ListItem(PaymentSearchBy.AGENCY.GetDescription(), PaymentSearchBy.AGENCY.ToString()));
            drpSearchBy.Items.Add(new ListItem(PaymentSearchBy.EXPENSE_TYPE.GetDescription(), PaymentSearchBy.EXPENSE_TYPE.ToString()));
        }
    }
    protected void onSearchByValue(object sender, EventArgs e)
    {
        resetTabInfo(PymtPageMode.NONE);
        fetchAllPayments(0);
    }
    protected void onSelectPymtFrom(object sender, EventArgs e)
    {
        try
        {
            resetTabInfo(PymtPageMode.NONE);
            PaymentFromSearchBy pymtFromSearchBy = EnumHelper.ToEnum<PaymentFromSearchBy>(drpSelectPymtFrom.Text);
            drpBO.populateDrpPymtToSearchBy(drpSelectPymtTo, pymtFromSearchBy);
            loadDrpSearchBy();
            fetchAllPayments(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSelectPymtTo(object sender, EventArgs e)
    {
        try
        {
            resetTabInfo(PymtPageMode.NONE);
            loadDrpSearchBy();
            fetchAllPayments(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSelectProperty(object sender, EventArgs e)
    {
        try
        {
            resetTabInfo(PymtPageMode.NONE);
            drpBO.drpDataBase(drpSelectPropertyTower, DrpDataType.PROPERTY_TOWER, drpSelectProperty.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            if (drpSelectPropertyTower.Items.Count == 2)
            {
                drpSelectPropertyTower.Items[1].Selected = true;
            }
            loadDrpSearchBy();
            fetchAllPayments(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSelectPropertyTower(object sender, EventArgs e)
    {
        try
        {
            resetTabInfo(PymtPageMode.NONE);
            loadDrpSearchBy();
            fetchAllPayments(0);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    //Customer to Firm Payment - START
    private void selectCustToFromBuilderSearchGridRdBtn(long Id)
    {
        if (custToFromBuilderPymtGrid.Rows.Count > 0)
        {
            setSelectedCustToFromBuilderPymt(0);
            foreach (GridViewRow row in custToFromBuilderPymtGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdCustToFromBuilderSelect");
                Button rowIdenBtn = (Button)row.FindControl("btnCustToFromBuilderRowIdentifier");
                if (radioBtn != null)
                {
                    radioBtn.Checked = false;
                    if (rowIdenBtn != null && Id > 0 && Id.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                    {
                        radioBtn.Checked = true;
                        setSelectedCustToFromBuilderPymt(Id);
                    }
                }
            }
        }
    }
    protected void onSelectCustToFromBuilderPayment(object sender, EventArgs e)
    {
        try
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            resetTabInfo(PymtPageMode.NONE);
            if (rd.Checked)
            {
                string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnCustToFromBuilderRowIdentifier"))).Attributes["row-identifier"];
                setSelectedCustToFromBuilderPymt(long.Parse(strId));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private void setSelectedCustToFromBuilderPymt(long selectedId)
    {
        List<PrUnitSalePymtDTO> salePymtDtoList = getCustToFromBuilderGridList();
        if (salePymtDtoList != null)
        {
            salePymtDtoList.ForEach(c => c.isUISelected = false);
            if (selectedId > 0) salePymtDtoList.Find(c => c.PaymentMaster.Id == selectedId).isUISelected = true;
        }
    }
    private void populateCustToFromBuilderInfo(PrUnitSalePymtDTO prUnitSalePymtDto)
    {
        pnlCustToFromBuilderInfo.Visible = true;
        txtViewPropertyName.Text = prUnitSalePymtDto.PrUnitSaleDetail.PropertyUnit.PropertyTower.Property.Name;
        txtViewPropertyTower.Text = prUnitSalePymtDto.PrUnitSaleDetail.PropertyUnit.PropertyTower.Name;
        txtViewUnitNo.Text = prUnitSalePymtDto.PrUnitSaleDetail.PropertyUnit.UnitNo;
        txtViewUnitType.Text = prUnitSalePymtDto.PrUnitSaleDetail.PropertyUnit.UnitType.Name;
        txtViewCustomerName.Text = prUnitSalePymtDto.PrUnitSaleDetail.Customer.FirstName + " " + prUnitSalePymtDto.PrUnitSaleDetail.Customer.LastName;
        txtViewBookingDate.Text = CommonUtil.getCSDate(prUnitSalePymtDto.PrUnitSaleDetail.BookingDate);
        txtViewSaleRate.Text = prUnitSalePymtDto.PrUnitSaleDetail.SaleRate.ToString();
        txtViewAgreementAmount.Text = prUnitSalePymtDto.PrUnitSaleDetail.AgreementAmt.ToString();
        txtViewSalePymtType.Text = prUnitSalePymtDto.PymtType.Name;
        txtViewTotalAmount.Text = prUnitSalePymtDto.PaymentMaster.TotalAmt.ToString();
        txtViewTotalPaid.Text = prUnitSalePymtDto.PaymentMaster.TotalPaid.ToString();
        txtViewTotalPending.Text = prUnitSalePymtDto.PaymentMaster.TotalPending.ToString();
    }
    //Customer to Firm Payment - END
    //Firm to Agency Payment - START
    protected void onSelectFirmToAgencyPayment(object sender, EventArgs e)
    {
        try
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            resetTabInfo(PymtPageMode.NONE);
            if (rd.Checked)
            {
                string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnFirmToAgencyRowIdentifier"))).Attributes["row-identifier"];
                setSelectedFirmToAgencyPymt(long.Parse(strId));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private void selectFirmToAgencySearchGridRdBtn(long Id)
    {
        if (firmToAgencyPymtGrid.Rows.Count > 0)
        {
            setSelectedFirmToAgencyPymt(0);
            foreach (GridViewRow row in firmToAgencyPymtGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdFirmToAgencySelect");
                Button rowIdenBtn = (Button)row.FindControl("btnFirmToAgencyRowIdentifier");
                if (radioBtn != null)
                {
                    radioBtn.Checked = false;
                    if (rowIdenBtn != null && Id > 0 && Id.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                    {
                        radioBtn.Checked = true;
                        setSelectedFirmToAgencyPymt(Id);
                    }
                }
            }
        }
    }
    private void setSelectedFirmToAgencyPymt(long selectedId)
    {
        List<PropertyExpenseDTO> propExpenseDtoList = getFirmToAgencyGridList();
        if (propExpenseDtoList != null)
        {
            propExpenseDtoList.ForEach(c => c.isUISelected = false);
            if (selectedId > 0) propExpenseDtoList.Find(c => c.PaymentMaster.Id == selectedId).isUISelected = true;
        }
    }
    private void populateFirmToAgencyInfo(PropertyExpenseDTO prExpenseDto)
    {
        pnlFirmToAgencyInfo.Visible = true;
        txtViewFirmToAgencyPrName.Text = drpSelectProperty.SelectedItem.Text;
        txtViewFirmToAgencyPrTower.Text = drpSelectPropertyTower.SelectedItem.Text;
        txtViewFirmToAgencyAgencyName.Text = prExpenseDto.Agency.AgencyName;
        txtViewFirmToAgencyExpType.Text = prExpenseDto.ExpenseType.Name;
        txtViewFirmToAgencyExpDate.Text = CommonUtil.getCSDate(prExpenseDto.ExpenseDate);
        txtViewFirmToAgencyTotAmt.Text = prExpenseDto.PaymentMaster.TotalAmt.ToString();
        txtViewFirmToAgencyTotPaid.Text = prExpenseDto.PaymentMaster.TotalPaid.ToString();
        txtViewFirmToAgencyTotPending.Text = prExpenseDto.PaymentMaster.TotalPending.ToString();
    }
    //Firm to Agency Payment - END
    private bool validatePaymentSelected()
    {
        bool isSelected = true;
        string pymtDirection = getPaymentDirection();
        if (Constants.PYMT_DIRECTION.CUSTOMER_FIRM.Equals(pymtDirection) || Constants.PYMT_DIRECTION.FIRM_CUSTOMER.Equals(pymtDirection))
        {
            PrUnitSalePymtDTO prUnitSalePymtDto = getCurrentCustToFromBuilderPymt();
            isSelected = (prUnitSalePymtDto != null);
        }
        else if (Constants.PYMT_DIRECTION.FIRM_CONTRACTOR.Equals(pymtDirection))
        {
        }
        else if (Constants.PYMT_DIRECTION.FIRM_SUPPLIER.Equals(pymtDirection))
        {
        }
        else if (Constants.PYMT_DIRECTION.FIRM_AGENCY.Equals(pymtDirection))
        {
            PropertyExpenseDTO prExpenseDto = getCurrentFirmToAgencyPymt();
            isSelected = (prExpenseDto != null);
        }
        if (!isSelected)
        {
            resetTabInfo(PymtPageMode.NONE);
            setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Payment"), tab1ValidationGrp);
        }
        return isSelected;
    }
    private bool validatePaymentStatus(bool showError)
    {
        bool isValid = true;
        string pymtDirection = getPaymentDirection();
        if (Constants.PYMT_DIRECTION.CUSTOMER_FIRM.Equals(pymtDirection) || Constants.PYMT_DIRECTION.FIRM_CUSTOMER.Equals(pymtDirection))
        {
            PrUnitSalePymtDTO prUnitSalePymtDto = getCurrentCustToFromBuilderPymt();
            if (prUnitSalePymtDto != null && prUnitSalePymtDto.PaymentMaster.Status == PymtMasterStatus.Deleted)
            {
                if (showError) setErrorMessage("Cannot add payment transaction, Selected payment is deleted.", tab1ValidationGrp);
                isValid = false;
            }
            if (prUnitSalePymtDto != null && prUnitSalePymtDto.PaymentMaster.Status == PymtMasterStatus.Suspended)
            {
                if (showError) setErrorMessage(Resources.Messages.validation_pymt_cancelled_addpymt, tab1ValidationGrp);
                isValid = false;
            }
        }
        else if (Constants.PYMT_DIRECTION.FIRM_CONTRACTOR.Equals(pymtDirection))
        {
        }
        else if (Constants.PYMT_DIRECTION.FIRM_SUPPLIER.Equals(pymtDirection))
        {
        }
        else if (Constants.PYMT_DIRECTION.FIRM_AGENCY.Equals(pymtDirection))
        {
            PropertyExpenseDTO prExpenseDto = getCurrentFirmToAgencyPymt();
            if (prExpenseDto != null && prExpenseDto.PaymentMaster.Status == PymtMasterStatus.Deleted)
            {
                if (showError) setErrorMessage("Cannot add payment transaction, Selected payment is deleted.", tab1ValidationGrp);
                isValid = false;
            }
        }
        return isValid;
    }
    private void fetchSelectedPayment(PymtPageMode pageAction)
    {
        try
        {
            string pymtDirection = getPaymentDirection();
            string defaultAcnt = "";
            if (Constants.PYMT_DIRECTION.CUSTOMER_FIRM.Equals(pymtDirection) || Constants.PYMT_DIRECTION.FIRM_CUSTOMER.Equals(pymtDirection))
            {
                PrUnitSalePymtDTO prUnitSalePymtDto = getCurrentCustToFromBuilderPymt();
                PaymentMasterDTO paymentMasterDto = paymentBO.fetchPaymentMaster(prUnitSalePymtDto.PaymentMaster.Id);
                ViewState[VS_PYMT_MATSER] = paymentMasterDto;
                populateCustToFromBuilderInfo(prUnitSalePymtDto);
                if (PymtPageMode.ADD_PYMT == pageAction) defaultAcnt = prUnitSalePymtDto.PrUnitSaleDetail.PropertyUnit.PropertyTower.Property.FirmAccount.Id + "";
            }
            else if (Constants.PYMT_DIRECTION.FIRM_CONTRACTOR.Equals(pymtDirection))
            {
            }
            else if (Constants.PYMT_DIRECTION.FIRM_SUPPLIER.Equals(pymtDirection))
            {
            }
            else if (Constants.PYMT_DIRECTION.FIRM_AGENCY.Equals(pymtDirection))
            {
                PropertyExpenseDTO prExpenseDto = getCurrentFirmToAgencyPymt();
                PaymentMasterDTO paymentMasterDto = paymentBO.fetchPaymentMaster(prExpenseDto.PaymentMaster.Id);
                ViewState[VS_PYMT_MATSER] = paymentMasterDto;
                populateFirmToAgencyInfo(prExpenseDto);
                if (PymtPageMode.ADD_PYMT == pageAction) defaultAcnt = prExpenseDto.Property.FirmAccount.Id + "";
            }
            if (PymtPageMode.ADD_PYMT == pageAction)
            {
                initPaymentFields(defaultAcnt);
            }
            else
            {
                loadPaymentHistoryGrid(getCurrentPymtMaster());
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private void initPaymentFields(string defaultAcnt)
    {
        drpAccount.ClearSelection();
        drpAccount.Text = defaultAcnt;
        drpPaymentMode.ClearSelection();
        txtTransactionDate.Text = CommonUtil.getTodayDate();
        txtPaymentAmount.Text = null;
        txtPaymentComment.Text = null;
        initChequeAdditionalInfo();
    }
    private void initChequeAdditionalInfo()
    {
        txtBankName.Text = "";
        txtChequeDate.Text = "";
        txtChequeNo.Text = "";
        txtBranch.Text = "";
    }
    private void loadPaymentHistoryGrid(PaymentMasterDTO paymentMaster)
    {
        paymentMaster.PendingTransactions = new HashSet<PaymentTransactionDTO>();
        ISet<PaymentTransactionDTO> pymtTransactions = paymentMaster.PaymentTransactions;
        for (int i = 0; i < pymtTransactions.Count; i++)
        {
            PaymentTransactionDTO pymtTransaction = pymtTransactions.ElementAt(i);
            if (PymtTransStatus.Pending == pymtTransaction.Status)
            {
                paymentMaster.PendingTransactions.Add(pymtTransaction);
                pymtTransactions.Remove(pymtTransaction);
                i--;
            }
        }
        assignUiIndexToPendingTx(paymentMaster.PaymentTransactions);
        pymtHistoryGrid.DataSource = paymentMaster.PaymentTransactions;
        pymtHistoryGrid.DataBind();
        pnlPendingTransaction.Visible = false;
        if (paymentMaster.PendingTransactions.Count > 0)
        {
            pnlPendingTransaction.Visible = true;
            assignUiIndexToPendingTx(paymentMaster.PendingTransactions);
            pendingPymtGrid.DataSource = paymentMaster.PendingTransactions;
            pendingPymtGrid.DataBind();
        }
    }
    private void assignUiIndexToPendingTx(ISet<PaymentTransactionDTO> paymentTransList)
    {
        if (paymentTransList != null && paymentTransList.Count > 0)
        {
            long uiIndex = 1;
            foreach (PaymentTransactionDTO paymentTransactionDto in paymentTransList)
            {
                paymentTransactionDto.UiIndex = uiIndex++;
                paymentTransactionDto.RowInfo = CommonUIConverter.getGridViewRowInfo(paymentTransactionDto);
            }
        }
    }
    protected void onClickMakePymtBtn(object sender, EventArgs e)
    {
        try
        {
            if (validatePaymentSelected() && validatePaymentStatus(true))
            {
                resetTabInfo(PymtPageMode.ADD_PYMT);
                fetchSelectedPayment(PymtPageMode.ADD_PYMT);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }

    protected void onClickViewPymtHistoryBtn(object sender, EventArgs e)
    {
        try
        {
            showPymtHistory();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private void showPymtHistory()
    {
        try
        {
            if (validatePaymentSelected())
            {
                PymtPageMode pageMode = validatePaymentStatus(false) ? PymtPageMode.PYMT_HISTORY : PymtPageMode.PYMT_HISTORY_READONLY;
                resetTabInfo(pageMode);
                fetchSelectedPayment(pageMode);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }

    private PaymentTransactionDTO createNewPaymentTransaction(PaymentMasterDTO tmpPaymentMasterDto, PaymentTransactionDTO deletedPymtTransDto)
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        PaymentTransactionDTO pymtTransDto = new PaymentTransactionDTO();
        if (deletedPymtTransDto == null)
        {
            copyPymtTransactionFromUI(pymtTransDto);
        }
        else
        {
            copyPymtTransForReversal(pymtTransDto, deletedPymtTransDto);
        }
        pymtTransDto.FirmNumber = userDefDto.FirmNumber;
        pymtTransDto.InsertUser = userDefDto.Username;
        pymtTransDto.UpdateUser = userDefDto.Username;
        updatePaymentMaster(tmpPaymentMasterDto, pymtTransDto, deletedPymtTransDto);
        pymtTransDto.PaymentMaster = tmpPaymentMasterDto;
        createAccountTransaction(pymtTransDto, deletedPymtTransDto);
        createPaymentVoucher(pymtTransDto, deletedPymtTransDto);
        return pymtTransDto;
    }
    private void copyPymtTransactionFromUI(PaymentTransactionDTO pymtTransDto)
    {
        pymtTransDto.TxDate = CommonUtil.getCSDateNotNull(txtTransactionDate.Text);
        pymtTransDto.Amount = CommonUtil.getDecimaNotNulllWithoutExt(txtPaymentAmount.Text);
        pymtTransDto.Status = PymtTransStatus.Paid;
        pymtTransDto.PymtMode = EnumHelper.ToEnum<PaymentMode>(drpPaymentMode.Text);
        if (PaymentMode.CHEQUE == pymtTransDto.PymtMode)
        {
            pymtTransDto.BankName = txtBankName.Text;
            pymtTransDto.Branch = txtBranch.Text;
            pymtTransDto.ChequeNo = txtChequeNo.Text;
            pymtTransDto.ChequeDate = CommonUtil.getCSDate(txtChequeDate.Text);
        }
        pymtTransDto.Comments = txtPaymentComment.Text;
    }
    private void copyPymtTransForReversal(PaymentTransactionDTO pymtTransDto, PaymentTransactionDTO pymtTransDeletedDto)
    {
        pymtTransDto.TxDate = DateTime.Today;
        pymtTransDto.Amount = pymtTransDeletedDto.Amount;
        pymtTransDto.Status = PymtTransStatus.Reversal;
        pymtTransDto.PymtMode = pymtTransDeletedDto.PymtMode;
        pymtTransDto.BankName = pymtTransDeletedDto.BankName;
        pymtTransDto.Branch = pymtTransDeletedDto.Branch;
        pymtTransDto.ChequeNo = pymtTransDeletedDto.ChequeNo;
        pymtTransDto.ChequeDate = pymtTransDeletedDto.ChequeDate;
        pymtTransDto.Comments = "Reversal Entry for Tx No - " + pymtTransDeletedDto.Id;
        pymtTransDto.CancelledPaymentTransaction = pymtTransDeletedDto;
    }
    private void updatePaymentMaster(PaymentMasterDTO paymentMasterDto, PaymentTransactionDTO pymtTransDto, PaymentTransactionDTO deletedPymtTransDto)
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        if (deletedPymtTransDto == null)
        {
            paymentMasterDto.TotalPaid = Decimal.Add(paymentMasterDto.TotalPaid, pymtTransDto.Amount);
            paymentMasterDto.TotalPending = Decimal.Subtract(paymentMasterDto.TotalAmt, paymentMasterDto.TotalPaid);
            if (paymentMasterDto.TotalPending < 0) paymentMasterDto.TotalPending = Decimal.Zero;
        }
        else
        {
            paymentMasterDto.TotalPaid = Decimal.Subtract(paymentMasterDto.TotalPaid, pymtTransDto.Amount);
            paymentMasterDto.TotalPending = Decimal.Subtract(paymentMasterDto.TotalAmt, paymentMasterDto.TotalPaid);
            if (paymentMasterDto.TotalPending < 0) paymentMasterDto.TotalPending = Decimal.Zero;
        }
        paymentMasterDto.Status = (paymentMasterDto.TotalPending > 0) ? PymtMasterStatus.Pending : PymtMasterStatus.Paid;
        paymentMasterDto.UpdateUser = userDefDto.Username;
    }
    private void createAccountTransaction(PaymentTransactionDTO pymtTransDto, PaymentTransactionDTO deletedPymtTransDto)
    {
        AccountTransactionDTO acntTransDto = new AccountTransactionDTO();
        string pymtDirection = getPaymentDirection();
        if (deletedPymtTransDto == null)
        {
            acntTransDto.FirmAccount = CommonUIConverter.getFirmAccountDTO(drpAccount.Text, null);
            acntTransDto.TxType = (pymtDirection.Equals(Constants.PYMT_DIRECTION.CUSTOMER_FIRM)) ? AcntTransStatus.Credit : AcntTransStatus.Debit;
            acntTransDto.Comments = getAccountTransactionComments(pymtTransDto, deletedPymtTransDto);
        }
        else
        {
            acntTransDto.FirmAccount = deletedPymtTransDto.AccountTransaction.FirmAccount;
            acntTransDto.TxType = (deletedPymtTransDto.AccountTransaction.TxType == AcntTransStatus.Credit) ? AcntTransStatus.Debit : AcntTransStatus.Credit;
            acntTransDto.Comments = getAccountTransactionComments(pymtTransDto, deletedPymtTransDto);
        }
        acntTransDto.TxDate = pymtTransDto.TxDate;
        acntTransDto.Amount = pymtTransDto.Amount;
        acntTransDto.FirmNumber = pymtTransDto.FirmNumber;
        acntTransDto.InsertUser = pymtTransDto.InsertUser;
        acntTransDto.UpdateUser = pymtTransDto.UpdateUser;
        pymtTransDto.AccountTransaction = acntTransDto;
    }
    private void createPaymentVoucher(PaymentTransactionDTO pymtTransDto, PaymentTransactionDTO deletedPymtTransDto)
    {
        PaymentVoucherDTO paymentVoucherDto = new PaymentVoucherDTO();
        PaymentLedgerDTO billPaymentLedgerDto = new PaymentLedgerDTO();
        BillAllocationDTO billAllocationDTO = new BillAllocationDTO();
        PaymentLedgerDTO bankPaymentLedgerDto = new PaymentLedgerDTO();
        BankAllocationDTO bankAllocationDTO = new BankAllocationDTO();
        paymentVoucherDto.PaymentLedgers = new HashSet<PaymentLedgerDTO>();
        string pymtDirection = getPaymentDirection();

        paymentVoucherDto.Action = Constants.VOUCHER_CREATE_ACTION;
        paymentVoucherDto.VoucherDate = pymtTransDto.TxDate;
        paymentVoucherDto.VoucherNaration = getAccountTransactionComments(pymtTransDto, deletedPymtTransDto);
        if (Constants.PYMT_DIRECTION.CUSTOMER_FIRM.Equals(pymtDirection))
        {
            PrUnitSalePymtDTO prUnitSalePymtDto = getCurrentCustToFromBuilderPymt();
            //string ledgerName = CommonUIConverter.getCustomerFullName(prUnitSalePymtDto.PrUnitSaleDetail.Customer.Salutation.Name
            //    , prUnitSalePymtDto.PrUnitSaleDetail.Customer.FirstName, prUnitSalePymtDto.PrUnitSaleDetail.Customer.MiddleName,
            //    prUnitSalePymtDto.PrUnitSaleDetail.Customer.LastName);
            string ledgerName = prUnitSalePymtDto.PrUnitSaleDetail.Customer.FirstName;
            paymentVoucherDto.VoucherType = Constants.VOUCHER_TYPE_RECEIPT;
            paymentVoucherDto.PartyLedgerName = ledgerName;
            billPaymentLedgerDto.LedgerName = ledgerName;
            billPaymentLedgerDto.Amount = pymtTransDto.Amount;
            bankPaymentLedgerDto.Amount = -pymtTransDto.Amount;
            if (pymtTransDto.PymtMode != PaymentMode.CASH)
            {
                billAllocationDTO.Amount = pymtTransDto.Amount;
                bankAllocationDTO.Amount = -pymtTransDto.Amount;
                bankAllocationDTO.BankPartyName = ledgerName;
            }
        }
        else if (Constants.PYMT_DIRECTION.FIRM_CUSTOMER.Equals(pymtDirection))
        {
            PrUnitSalePymtDTO prUnitSalePymtDto = getCurrentCustToFromBuilderPymt();
            string ledgerName = CommonUIConverter.getCustomerFullName(prUnitSalePymtDto.PrUnitSaleDetail.Customer.Salutation.Name
               , prUnitSalePymtDto.PrUnitSaleDetail.Customer.FirstName, prUnitSalePymtDto.PrUnitSaleDetail.Customer.MiddleName,
               prUnitSalePymtDto.PrUnitSaleDetail.Customer.LastName);
            paymentVoucherDto.VoucherType = Constants.VOUCHER_TYPE_PAYMENT;
            paymentVoucherDto.PartyLedgerName = ledgerName;
            billPaymentLedgerDto.LedgerName = ledgerName;
            billPaymentLedgerDto.Amount = -pymtTransDto.Amount;
            bankPaymentLedgerDto.Amount = pymtTransDto.Amount;
            if (pymtTransDto.PymtMode != PaymentMode.CASH)
            {
                billAllocationDTO.Amount = -pymtTransDto.Amount;
                bankAllocationDTO.Amount = pymtTransDto.Amount;
                bankAllocationDTO.BankPartyName = ledgerName;
            }
        }
        else if (Constants.PYMT_DIRECTION.FIRM_CONTRACTOR.Equals(pymtDirection))
        {
        }
        else if (Constants.PYMT_DIRECTION.FIRM_SUPPLIER.Equals(pymtDirection))
        {
        }
        else if (Constants.PYMT_DIRECTION.FIRM_AGENCY.Equals(pymtDirection))
        {
            PropertyExpenseDTO propExpDto = getCurrentFirmToAgencyPymt();
            paymentVoucherDto.VoucherType = Constants.VOUCHER_TYPE_PAYMENT;
            paymentVoucherDto.PartyLedgerName = propExpDto.Agency.AgencyName;
            billPaymentLedgerDto.LedgerName = propExpDto.Agency.AgencyName;
            billPaymentLedgerDto.Amount = -pymtTransDto.Amount;
            bankPaymentLedgerDto.Amount = pymtTransDto.Amount;
            if (pymtTransDto.PymtMode != PaymentMode.CASH)
            {
                billAllocationDTO.Amount = -pymtTransDto.Amount;
                bankAllocationDTO.Amount = pymtTransDto.Amount;
                bankAllocationDTO.BankPartyName = propExpDto.Agency.AgencyName; ;
            }
        }
        paymentVoucherDto.VoucherEffectiveDate = pymtTransDto.TxDate;
        paymentVoucherDto.HasCashFlow = Constants.VOUCHER_YES;
        paymentVoucherDto.PostingStatus = Constants.VOUCHER_PENDING;
        paymentVoucherDto.FirmNumber = pymtTransDto.FirmNumber;
        paymentVoucherDto.InsertUser = pymtTransDto.InsertUser;
        paymentVoucherDto.UpdateUser = pymtTransDto.UpdateUser;

        billPaymentLedgerDto.LedgerType = Constants.VOUCHER_BILL_LEDGERTYPE;
        billPaymentLedgerDto.IsDeemedPositive = Constants.VOUCHER_NO;
        billPaymentLedgerDto.LedgerFromItem = Constants.VOUCHER_NO;
        billPaymentLedgerDto.RemoveZeroEntries = Constants.VOUCHER_NO;
        billPaymentLedgerDto.IsPartyLedger = Constants.VOUCHER_YES;
        billPaymentLedgerDto.IsLastDeemedPositive = Constants.VOUCHER_NO;
        billPaymentLedgerDto.VatexpAmount = 0.0M;
        billPaymentLedgerDto.FirmNumber = pymtTransDto.FirmNumber;
        billPaymentLedgerDto.InsertUser = pymtTransDto.InsertUser;
        billPaymentLedgerDto.UpdateUser = pymtTransDto.UpdateUser;
        if (pymtTransDto.PymtMode != PaymentMode.CASH)
        {
            billAllocationDTO.Name = "InvoiceNumber";
            billAllocationDTO.BillType = "Invoice";
            billAllocationDTO.TdsDeductSpecialRate = Constants.VOUCHER_NO;
            billAllocationDTO.FirmNumber = pymtTransDto.FirmNumber;
            billAllocationDTO.InsertUser = pymtTransDto.InsertUser;
            billAllocationDTO.UpdateUser = pymtTransDto.UpdateUser;
            billPaymentLedgerDto.BillAllocations = new HashSet<BillAllocationDTO>();
            billPaymentLedgerDto.BillAllocations.Add(billAllocationDTO);

            bankAllocationDTO.BDate = pymtTransDto.TxDate;
            if (pymtTransDto.PymtMode == PaymentMode.CHEQUE)
            {
                bankAllocationDTO.InstrumentDate = (DateTime)pymtTransDto.ChequeDate;
                bankAllocationDTO.ChequeCrossComment = Constants.VOUCHER_CHEQUE_COMMENT;
                bankAllocationDTO.InstrumentNumber = pymtTransDto.ChequeNo;
            }
            else
            {
                bankAllocationDTO.InstrumentDate = pymtTransDto.TxDate;
                bankAllocationDTO.InstrumentNumber = pymtTransDto.Id.ToString();
            }
            bankAllocationDTO.Name = pymtTransDto.BankName!= null ? pymtTransDto.BankName:"NEFT/RTGS/DD";
            bankAllocationDTO.TransactionType = pymtTransDto.PymtMode.GetDescription();
            bankAllocationDTO.BankName = pymtTransDto.BankName;
            bankAllocationDTO.BankBranchName = pymtTransDto.Branch;
            bankAllocationDTO.UniqueReferenceNumber = pymtTransDto.Id.ToString();
            bankAllocationDTO.Status = Constants.VOUCHER_NO;
            bankAllocationDTO.PaymentMode = pymtTransDto.PymtMode.GetDescription();
            bankAllocationDTO.IsConnectedPayment = Constants.VOUCHER_NO;
            bankAllocationDTO.IsSplit = Constants.VOUCHER_NO;
            bankAllocationDTO.IsContractUsed = Constants.VOUCHER_NO;
            bankAllocationDTO.FirmNumber = pymtTransDto.FirmNumber;
            bankAllocationDTO.InsertUser = pymtTransDto.InsertUser;
            bankAllocationDTO.UpdateUser = pymtTransDto.UpdateUser;
            bankPaymentLedgerDto.BankAllocations = new HashSet<BankAllocationDTO>();
            bankPaymentLedgerDto.BankAllocations.Add(bankAllocationDTO);
        }
        if (pymtTransDto.PymtMode == PaymentMode.CASH)
        {
            bankPaymentLedgerDto.LedgerName = Constants.VOUCHER_LEDGERNAME_CASH;
        }
        else
        {
            bankPaymentLedgerDto.LedgerName = pymtTransDto.BankName!=null? pymtTransDto.BankName:"NEFT/RTGS/DD";
        }
        bankPaymentLedgerDto.LedgerType = Constants.VOUCHER_BANK_LEDGERTYPE;
        bankPaymentLedgerDto.IsDeemedPositive = Constants.VOUCHER_NO;
        bankPaymentLedgerDto.LedgerFromItem = Constants.VOUCHER_NO;
        bankPaymentLedgerDto.RemoveZeroEntries = Constants.VOUCHER_NO;
        bankPaymentLedgerDto.IsPartyLedger = Constants.VOUCHER_YES;
        bankPaymentLedgerDto.IsLastDeemedPositive = Constants.VOUCHER_NO;
        bankPaymentLedgerDto.VatexpAmount = 0.0M;
        bankPaymentLedgerDto.FirmNumber = pymtTransDto.FirmNumber;
        bankPaymentLedgerDto.InsertUser = pymtTransDto.InsertUser;
        bankPaymentLedgerDto.UpdateUser = pymtTransDto.UpdateUser;
        paymentVoucherDto.PaymentLedgers.Add(billPaymentLedgerDto);
        paymentVoucherDto.PaymentLedgers.Add(bankPaymentLedgerDto);
        pymtTransDto.PaymentVoucherDTO = paymentVoucherDto;
    }

    private string getAccountTransactionComments(PaymentTransactionDTO pymtTransDto, PaymentTransactionDTO deletedTransDto)
    {
        string comments = "";
        string pymtDirection = getPaymentDirection();
        string pymtModeComment = CommonUtil.getAcntTransCommentPymtMode(pymtTransDto);
        if (Constants.PYMT_DIRECTION.CUSTOMER_FIRM.Equals(pymtDirection))
        {
            PrUnitSalePymtDTO prUnitSalePymtDto = getCurrentCustToFromBuilderPymt();
            if (deletedTransDto == null)
                comments = string.Format(Constants.PYMT_FROM, prUnitSalePymtDto.PrUnitSaleDetail.Customer.FirstName) + "," + pymtModeComment
                    + "," + Constants.TX_REF + "," + string.Format(Constants.UNIT_SALE_TYPE + "{0}", prUnitSalePymtDto.PymtType.Name);
            else
                comments = string.Format(Constants.REV_PYMT_FROM, prUnitSalePymtDto.PrUnitSaleDetail.Customer.FirstName) + "," + pymtModeComment
                    + "," + Constants.TX_REF + "," + string.Format(Constants.REV_TX_REF, deletedTransDto.Id)
                    + "," + getPymtType(pymtDirection, deletedTransDto.AccountTransaction.Comments);

        }
        else if (Constants.PYMT_DIRECTION.FIRM_CUSTOMER.Equals(pymtDirection))
        {
            PrUnitSalePymtDTO prUnitSalePymtDto = getCurrentCustToFromBuilderPymt();
            if (deletedTransDto == null)
                comments = string.Format(Constants.PYMT_TO, prUnitSalePymtDto.PrUnitSaleDetail.Customer.FirstName) + "," + pymtModeComment
                    + "," + Constants.TX_REF + "," + string.Format(Constants.UNIT_SALE_TYPE + "{0}", prUnitSalePymtDto.PymtType.Name);
            else
                comments = string.Format(Constants.REV_PYMT_TO, prUnitSalePymtDto.PrUnitSaleDetail.Customer.FirstName) + "," + pymtModeComment
                    + "," + Constants.TX_REF + "," + string.Format(Constants.REV_TX_REF, deletedTransDto.Id)
                    + "," + getPymtType(pymtDirection, deletedTransDto.AccountTransaction.Comments);
        }
        else if (Constants.PYMT_DIRECTION.FIRM_CONTRACTOR.Equals(pymtDirection))
        {
        }
        else if (Constants.PYMT_DIRECTION.FIRM_SUPPLIER.Equals(pymtDirection))
        {
        }
        else if (Constants.PYMT_DIRECTION.FIRM_AGENCY.Equals(pymtDirection))
        {
            PropertyExpenseDTO propExpDto = getCurrentFirmToAgencyPymt();
            if (deletedTransDto == null)
                comments = string.Format(Constants.PYMT_TO, propExpDto.Agency.AgencyName) + "," + pymtModeComment
                    + "," + Constants.TX_REF + "," + string.Format(Constants.PROP_EXP_TYPE + "{0}", propExpDto.ExpenseType.Name);
            else
                comments = string.Format(Constants.REV_PYMT_TO, propExpDto.Agency.AgencyName) + "," + pymtModeComment
                    + "," + Constants.TX_REF + "," + string.Format(Constants.REV_TX_REF, deletedTransDto.Id)
                    + "," + getPymtType(pymtDirection, deletedTransDto.AccountTransaction.Comments);
        }
        return comments;
    }
    private string getPymtType(string pymtDirection, string fwComments)
    {
        string comments = "";
        if (Constants.PYMT_DIRECTION.CUSTOMER_FIRM.Equals(pymtDirection))
        {
            comments = fwComments.Substring(fwComments.IndexOf(Constants.UNIT_SALE_TYPE));
        }
        else if (Constants.PYMT_DIRECTION.FIRM_CUSTOMER.Equals(pymtDirection))
        {
            comments = fwComments.Substring(fwComments.IndexOf(Constants.UNIT_SALE_TYPE));
        }
        else if (Constants.PYMT_DIRECTION.FIRM_CONTRACTOR.Equals(pymtDirection))
        {
        }
        else if (Constants.PYMT_DIRECTION.FIRM_SUPPLIER.Equals(pymtDirection))
        {
        }
        else if (Constants.PYMT_DIRECTION.FIRM_AGENCY.Equals(pymtDirection))
        {
            comments = fwComments.Substring(fwComments.IndexOf(Constants.PROP_EXP_TYPE));
        }
        return comments;
    }
    protected void onSelectPymtMode(object sender, EventArgs e)
    {
        try
        {
            PaymentMode pymtMode = EnumHelper.ToEnum<PaymentMode>(drpPaymentMode.Text);
            if (PaymentMode.CHEQUE == pymtMode)
            {
                pnlChequeAdditionInfo.Visible = true;
                initChequeAdditionalInfo();
            }
            else
            {
                pnlChequeAdditionInfo.Visible = false;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void deletePymtHistory(object sender, EventArgs e)
    {
        try
        {
            if (validatePymtHistoryDelete())
            {
                PaymentMasterDTO paymentMasterDto = getCurrentPymtMaster();
                PaymentTransactionDTO selectedPymtTransDto = paymentMasterDto.PaymentTransactions.ToList<PaymentTransactionDTO>().Find(p => p.isUISelected);
                PaymentTransactionDTO pymtTransactionDto = createNewPaymentTransaction(paymentMasterDto, selectedPymtTransDto);
                paymentBO.addPymtTransaction(pymtTransactionDto);
                fetchAllPayments(paymentMasterDto.Id);
                showPymtHistory();
                setSuccessMessage(string.Format(Resources.Messages.success_record_delete, "Payment Transaction"), tab2Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    private bool validatePymtHistoryDelete()
    {
        PaymentTransactionDTO selectedPymtTransaction = getCurrentPymtMaster().PaymentTransactions.ToList<PaymentTransactionDTO>().Find(c => c.isUISelected);
        if (selectedPymtTransaction == null)
        {
            setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Payment Transaction"), tab2ValidationGrp);
            return false;
        }
        if (selectedPymtTransaction.Status == PymtTransStatus.Deleted)
        {
            setErrorMessage("Selected Payment Transaction is already deleted.", tab2ValidationGrp);
            return false;
        }
        if (selectedPymtTransaction.Status == PymtTransStatus.Pending || selectedPymtTransaction.Status == PymtTransStatus.Reversal)
        {
            setErrorMessage("Only Paid Transactions can be deleted.", tab2ValidationGrp);
            return false;
        }
        if (selectedPymtTransaction.Status == PymtTransStatus.Paid && selectedPymtTransaction.PostDatedCheque != null)
        {
            setErrorMessage("Payment is made through Post Dated Cheque, Please delete cheque to reverse the transaction.", tab2ValidationGrp);
            return false;
        }
        return true;
    }
    protected void onSelectPymtHistory(object sender, EventArgs e)
    {
        GroupRadioButton rd = (GroupRadioButton)sender;
        if (rd.Checked)
        {
            long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnPymtHistoryRowIdentifier"))).Attributes["row-identifier"]);
            List<PaymentTransactionDTO> pymtTransList = getCurrentPymtMaster().PaymentTransactions.ToList<PaymentTransactionDTO>();
            pymtTransList.ForEach(c => c.isUISelected = false);
            pymtTransList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
        }
    }
    protected void addPayment(object sender, EventArgs e)
    {
        try
        {
            if (validateAddPayment())
            {
                PaymentMasterDTO paymentMasterDto = getCurrentPymtMaster();
                PaymentTransactionDTO pymtTransactionDto = createNewPaymentTransaction(paymentMasterDto, null);
                paymentBO.addPymtTransaction(pymtTransactionDto);
                fetchAllPayments(paymentMasterDto.Id);
                showPymtHistory();
                setSuccessMessage(string.Format(Resources.Messages.success_record_add, "Payment Transaction"), tab2Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    private bool validateAddPayment()
    {
        Page.Validate(tab2ValidationGrp);
        bool isPymtValid = Page.IsValid;
        PaymentMode pymtMode = EnumHelper.ToEnum<PaymentMode>(drpPaymentMode.Text);
        bool isChequePymtValid = true;
        if (PaymentMode.CHEQUE == pymtMode)
        {
            Page.Validate(tab2ChqPymtValidationGrp);
            isChequePymtValid = Page.IsValid;
        }
        if (!(isPymtValid && isChequePymtValid))
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
            DateTime txDate = CommonUtil.getCSDateNotNull(txtTransactionDate.Text);
            if (CommonUtil.isGreaterThanToday(txDate))
            {
                setErrorMessage("Transaction date cannot be in future.", tab2ValidationGrp);
                isPymtValid = false;
            }
        }
        return isPymtValid && isChequePymtValid;
    }
    protected void cancelPayment(object sender, EventArgs e)
    {
        resetTabInfo(PymtPageMode.NONE);
    }
}
