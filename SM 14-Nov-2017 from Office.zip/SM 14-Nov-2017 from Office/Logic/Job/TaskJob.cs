﻿using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;

namespace ConstroSoft.Logic.Job
{
    public class TaskJob : IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            JobHistoryDTO jobHistoryDTO = new JobHistoryDTO();
            string message = null;
            try{
                var schedulerContext = context.Scheduler.Context;
                JobDTO jobDTO = (JobDTO)schedulerContext.Get(Constants.TASK_JOB);
                UserDefinitionDTO userDefinitionDTO = (UserDefinitionDTO)schedulerContext.Get("UserDefinitionDTO");
                populateJobHistoryAddDto(jobHistoryDTO, jobDTO, userDefinitionDTO);
                long Id =jobHistoryBO.saveJobHistory(jobHistoryDTO);
                jobHistoryDTO.Id = Id;
                IList<TaskDTO> taskDtos = null;
                //TO DO Get the count of unassigned leads. Create TaskDTO for all the users having entitlement to assign leads.
                //Get list of upcoming tasks & Events due. Create TaskDTO for each task & event for each user.
                //Task & Events which are not completed & whose due date is less than or equal to current date.
                //Create Dictionary with Key as UserName~PropertyID~Task
                //Add List NotificationTO agains cache[Key]
                /* var dictionary = taskDtos
                        .GroupBy(x => x.UserName)
                        .ToDictionary(x => x.UserName, x => x.ToList());
                foreach(KeyValuePair<string, IList<TaskDTO>> entry in dictionary)
                {
                    cache.Remove(entry.Key"-Task");
                    cache[entry.Key"-Task"] = entry.Value;                   
                }*/
                
            }catch (Exception exp)
            {
                message = exp.Message;
                log.Error(exp.Message, exp);
            }finally{
                populateJobHistoryUpdateDto(jobHistoryDTO, message);
                jobHistoryBO.updatejobHistoryDetails(jobHistoryDTO);
            }
           
        }
        
        private void populateJobHistoryAddDto(JobHistoryDTO jobHistoryDTO, JobDTO jobDTO, UserDefinitionDTO userDefinitionDTO)
        {
            jobHistoryDTO.StartTime = DateTime.Now;
            jobHistoryDTO.JobRunStatus = JobRunStatus.INPROGRESS;
            jobHistoryDTO.Job = jobDTO;
            jobHistoryDTO.FirmNumber = userDefinitionDTO.FirmNumber;
            jobHistoryDTO.Version = userDefinitionDTO.Version;
            jobHistoryDTO.InsertUser = userDefinitionDTO.Username;
            jobHistoryDTO.UpdateUser = userDefinitionDTO.Username;
            jobHistoryDTO.InsertDate = DateTime.Now;
            jobHistoryDTO.UpdateDate = DateTime.Now;
        }
        
        private void populateJobHistoryAddDto(JobHistoryDTO jobHistoryDTO, string message)
        {
            jobHistoryDTO.EndTime = DateTime.Now;
            if(message != null){
                jobHistoryDTO.JobRunStatus = JobRunStatus.FAILURE;
                jobHistoryDTO.Message = message;
            }else{
                jobHistoryDTO.JobRunStatus = JobRunStatus.SUCCESS;
                jobHistoryDTO.Message = "Job execution completed successfully.";
            }
            jobHistoryDTO.UpdateUser = userDefinitionDTO.Username;
            jobHistoryDTO.UpdateDate = DateTime.Now;
        }
    }
}