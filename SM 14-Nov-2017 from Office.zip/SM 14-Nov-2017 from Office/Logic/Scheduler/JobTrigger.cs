﻿using ConstroSoft.Logic.Job;
using Quartz;
using Quartz.Impl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ConstroSoft.Logic.Scheduler
{
    public class JobTrigger
    {
        private static readonly log4net.ILog log =
                log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        
        public JobTrigger() { }
        
        public static ITrigger CreateSimpleSchedule()
        {
            ITrigger trigger = null;
            try{
                trigger = TriggerBuilder.Create()
                        .WithIdentity("trigger", "group")
                        .StartNow()
                        .WithSimpleSchedule(x => x
                            .WithIntervalInMinutes(15)
                            .RepeatForever())
                    .Build();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error scheduling Job:" ,exp);
                throw new Exception(Resources.Messages.system_error);
            }
            finally
            {

            }

            return trigger;
        }
    }
}