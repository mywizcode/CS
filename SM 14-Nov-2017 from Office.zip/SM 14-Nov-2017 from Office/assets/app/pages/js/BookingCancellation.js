﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initPymtGrid();
    formatFields();
    showModal();
}
function initPymtGrid() {
    var dtOptions = {
        hasActionColumn: false,
        hideSearch: true,
        pagination: false,
        sorting: false
    };

    $("[id$='PymtDetailGrid']").CSBasicDatatable(dtOptions);
}