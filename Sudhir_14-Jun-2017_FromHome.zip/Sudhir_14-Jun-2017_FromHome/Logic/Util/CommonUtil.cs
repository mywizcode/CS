﻿
/// <summary>
/// Summary description for CommonUtil
/// </summary>
using ConstroSoft;
using System.Collections.Generic;
using NHibernate.Criterion;
using System.Linq.Expressions;
using System.Linq;
using NHibernate.Impl;
using System;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Web;
namespace ConstroSoft
{
    public class CommonUtil
    {
        public CommonUtil() { }
        public static string getCustomerRefNo(long Id)
        {
            return "C" + String.Format("{0:D5}", Id);
        }
        public static bool isSessionActive(System.Web.SessionState.HttpSessionState Session)
        {
            return (Session[Constants.Session.USERNAME] != null && (Session[Constants.Session.USERNAME]).ToString().Trim() != "") ? true : false;
        }
        public static string getSessionSuccessMsg(System.Web.SessionState.HttpSessionState Session)
        {
            string msg = "";
            if(Session[Constants.Session.SUCCESS_MSG] != null && (Session[Constants.Session.SUCCESS_MSG]).ToString().Trim() != "") {
                msg = (Session[Constants.Session.SUCCESS_MSG]).ToString();
                Session.Remove(Constants.Session.SUCCESS_MSG);
            }
            return msg;
        }
        public static string getSessionErrorMsg(System.Web.SessionState.HttpSessionState Session)
        {
            string msg = "";
            if (Session[Constants.Session.ERROR_MSG] != null && (Session[Constants.Session.ERROR_MSG]).ToString().Trim() != "")
            {
                msg = (Session[Constants.Session.ERROR_MSG]).ToString();
                Session.Remove(Constants.Session.ERROR_MSG);
            }
            return msg;
        }
        public static void clearSession(System.Web.SessionState.HttpSessionState Session, HttpApplicationState Application)
        {
            string userLoggedIn = Session["USERNAME"] == null ? string.Empty : (string)Session["USERNAME"];
            if (userLoggedIn.Length > 0)
            {
                System.Collections.Generic.List<string> d = Application["LOGGED_IN_USERS"]
                    as System.Collections.Generic.List<string>;
                if (d != null)
                {
                    lock (d)
                    {
                        d.Remove(userLoggedIn);
                    }
                }
            }
            Session["USERNAME"] = "";
            Session[Constants.Session.USERDEFINITION] = "";
        }
        public static string getErrorMessage(Exception exp)
        {
            string message = Resources.Messages.system_error;
            if (exp is CustomException) message = exp.Message;
            return message;
        }
        public static bool hasEntitlement(UserDefinitionDTO userDefDto, string entitlement)
        {
            return userDefDto != null && userDefDto.UserRole.entitlements != null && userDefDto.UserRole.entitlements.Contains(entitlement);
        }
        public static bool hasAnyEntitlement(UserDefinitionDTO userDefDto, string[] entitlements)
        {
            bool result = false;
            if(userDefDto != null && userDefDto.UserRole.entitlements != null) {
                foreach (string str in entitlements)
                {
                    result = userDefDto.UserRole.entitlements.Contains(str);
                    if (result) break;
                }
            }
            return result;
        }
        public static PropertyProjection BuildProjection<T>(Expression<Func<object>> aliasExpression, Expression<Func<T, object>> propertyExpression)
        {
            string alias = ExpressionProcessor.FindMemberExpression(aliasExpression.Body);
            string property = ExpressionProcessor.FindMemberExpression(propertyExpression.Body);

            return Projections.Property(string.Format("{0}.{1}", alias, property));
        }
        public static string removeAppenders(string strTemp)
        {
            string result = "";
            if (!string.IsNullOrWhiteSpace(strTemp))
            {
                foreach(string appender in Constants.APPENDERS) {
                    strTemp = strTemp.Replace(appender, "");
                }
                result = strTemp.Trim();
            }
            return result;
        }
        public static decimal? getDecimalWithoutExt(string strVal)
        {
            return getDecimal(removeAppenders(strVal));
        }
        public static decimal? getDecimal(string strVal)
        {
            decimal? result = null;
            if (!string.IsNullOrWhiteSpace(strVal)) result = decimal.Parse(strVal);
            return result;
        }
        public static decimal getDecimaNotNulllWithoutExt(string strVal)
        {
            return getNotNullDecimal(removeAppenders(strVal));
        }
        public static decimal getNotNullDecimal(string strVal)
        {
            decimal result = decimal.Zero;
            if (!string.IsNullOrWhiteSpace(strVal)) result = decimal.Parse(strVal);
            return result;
        }
        public static string getCSDate(DateTime? date)
        {
            return (date != null) ? date.Value.ToString(Constants.DATE_FORMAT) : null;
        }
        public static string getTallyDate(DateTime? date)
        {
            return (date != null) ? date.Value.ToString(Constants.TALLY_DATE_FORMAT) : null;
        }
        public static DateTime? getCSDate(string strDate) {
            DateTime? date = null;
            if (!string.IsNullOrWhiteSpace(strDate)) date = DateTime.ParseExact(strDate, Constants.DATE_FORMAT, CultureInfo.InvariantCulture);
            return date;
        }
        public static DateTime getCSDateNotNull(string strDate)
        {
            DateTime date = DateTime.Today;
            if (!string.IsNullOrWhiteSpace(strDate)) date = DateTime.ParseExact(strDate, Constants.DATE_FORMAT, CultureInfo.InvariantCulture);
            return date;
        }
        public static string getTodayDate()
        {
            return DateTime.Today.ToString(Constants.DATE_FORMAT);
        }
        public static string getAcntTransCommentPymtMode(PaymentTransactionDTO pymtTransDto)
        {
            string tmpComment = "";
            if (pymtTransDto.PymtMode == PaymentMode.CASH)
                tmpComment = Constants.CASH_PYMT_MODE;
            else if (pymtTransDto.PymtMode == PaymentMode.CHEQUE)
                tmpComment = string.Format(Constants.CHQ_PYMT_MODE, pymtTransDto.ChequeNo);
            else if (pymtTransDto.PymtMode == PaymentMode.DD)
                tmpComment = Constants.DD_PYMT_MODE;
            else if (pymtTransDto.PymtMode == PaymentMode.NEFT)
                tmpComment = Constants.NEFT_PYMT_MODE;
            else if (pymtTransDto.PymtMode == PaymentMode.RTGS)
                tmpComment = Constants.RTGS_PYMT_MODE;
            return tmpComment;
        }
        public static bool isGreaterThanToday(DateTime date)
        {
            DateTime today = DateTime.Now;
            return date.CompareTo(today) > 0;
        }
        public static void updateParking(PrUnitSaleDetailDTO prUnitSaleDto, string uiParkingDtls)
        {
            string[] arrParkings = uiParkingDtls.Split(new[] { "~~" }, StringSplitOptions.RemoveEmptyEntries);
            ISet<PropertyParkingDTO> pList = new HashSet<PropertyParkingDTO>(prUnitSaleDto.PrParkings);
            prUnitSaleDto.PrParkings.Clear();
            if (arrParkings != null && arrParkings.Count() > 0)
            {

                foreach (string parkingDtls in arrParkings)
                {
                    string[] arrPDtls = parkingDtls.Split(new[] { "~" }, StringSplitOptions.RemoveEmptyEntries);
                    PropertyParkingDTO tmpDto = pList.FirstOrDefault(x => x.ParkingNo.Equals(arrPDtls[0]));
                    if (tmpDto != null) prUnitSaleDto.PrParkings.Add(tmpDto);
                }
            }
        }
        public static string getUiParkingDetails(PrUnitSaleDetailDTO prUnitSaleDto)
        {
            string parkingDtls = "";
            if (prUnitSaleDto.PrParkings.Count > 0)
            {
                string tmpParkingDtls = "";
                foreach (PropertyParkingDTO parkingDto in prUnitSaleDto.PrParkings)
                {
                    string tmpStr = parkingDto.ParkingNo + "~" + parkingDto.ParkingType.Name + "," + parkingDto.Area + " Sq.Ft.";
                    tmpParkingDtls = (tmpParkingDtls == "") ? tmpStr : tmpParkingDtls + "~~" + tmpStr;
                }
                parkingDtls = tmpParkingDtls;
            }
            return parkingDtls;
        }
    }
}