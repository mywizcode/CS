﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});
function initBootstrapComponants() {
    var dtTable = initPropertyAlertManagement();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("tab2Content");
    $('span.switch').each(function () {
        var $span = $(this);
        var $chBox = $span.find('input');
        $.each(this.attributes, function (i, attrib) {
            var name = attrib.name;
            var value = attrib.value;
            $chBox.attr(name, value);
        });
        $span.html('');
        $chBox.appendTo($span.parent())
        $span.remove();
    });
    $('.switch').bootstrapSwitch();
    
    enableTab(true);
}
function initPropertyAlertManagement() {
    var dtOptions = {
        tableId: "propertyAlertGrid",
        pageLength: 10,
        isViewOnly: false,
        hideSearch: true
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPropertyAlertHdnId");
}
