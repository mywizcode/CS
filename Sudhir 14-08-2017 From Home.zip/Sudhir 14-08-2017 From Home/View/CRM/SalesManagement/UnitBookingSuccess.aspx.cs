﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.BO;

public partial class UnitBookingSuccess : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string VS_BOOKING_SUCCESS = "VS_BOOKING_SUCCESS";

    PropertyUnitManagementBO prUnitBO = new PropertyUnitManagementBO();
    CustomerBO customerBO = new CustomerBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                BookingSuccessNavDTO navDto = (BookingSuccessNavDTO)Session[Constants.Session.NAV_BOOKING_SUCCESS];
                Session.Remove(Constants.Session.NAV_BOOKING_SUCCESS);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void applyEntitlement()
    {

    }
    private void preRenderInitFormElements()
    {

    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {

    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
    }
    private void doInit(BookingSuccessNavDTO navDto)
    {
        if (navDto != null)
        {
            initPageAfterRedirect(navDto);
        }
        else
        {
            Response.Redirect(Constants.URL.AVAILABLE_UNIT_SEARCH, true);
        }
    }
    private void initPageAfterRedirect(BookingSuccessNavDTO navDto)
    {
        try
        {
            CustomerDTO customerDto = customerBO.fetchCustomer(navDto.customerId);
            lbCustomerName.Text = CommonUIConverter.getCustomerFullName(customerDto.Salutation.Name, customerDto.FirstName, "", customerDto.LastName);
            PropertyUnitDTO unitDto = prUnitBO.fetchPropertyUnitDetails(navDto.PrUnitId);
            ViewState[VS_BOOKING_SUCCESS] = navDto;
            btnBookUnitInfoHdn.Attributes["row-info"] = CommonUIConverter.getGridViewRowInfo(unitDto);
            lbBookProperty.Text = navDto.PropertyName;
            lbBookTower.Text = unitDto.PropertyTower.Name;
            lbBookWing.Text = unitDto.Wing;
            lbBookUnitNo.Text = unitDto.UnitNo;
            lbBookUnitType.Text = unitDto.UnitType.Name;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void initPageInfo()
    {

    }
    protected void goToSoldUnitPage(object sender, EventArgs e)
    {
        try
        {
            //TODO - Navigate to Sold Unit Page.
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void goToAddPaymentPage(object sender, EventArgs e)
    {
        try
        {
            //TODO - Navigate to Add Payment Page.
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
}