﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using ConstroSoft.Logic.BO;

public partial class SoldUnitSearch : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string SearchFilterModal = "SearchFilterModal";
    string VS_UNIT_LIST = "VS_UNIT_LIST";
    string VS_FILTER = "VS_FILTER";
    DropdownBO drpBO = new DropdownBO();
    SoldPropertyUnitBO soldUnitBO = new SoldPropertyUnitBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                SoldUnitNavDTO navDto = (SoldUnitNavDTO)Session[Constants.Session.NAV_SOLD_UNIT];
                Session.Remove(Constants.Session.NAV_SOLD_UNIT);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();

    }
    private void preRenderInitFormElements()
    {
        renderPageLayout();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpSearchProperty, DrpDataType.PROPERTY_NAME, userDefDto.Id.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpCustomerFilter, DrpDataType.CUSTOMER_SEARCH_BY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpUnitNoFilter, DrpDataType.AVAIL_UNIT_SEARCH_BY_PR_UNIT, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpSalesExecutiveFilter, DrpDataType.EMPLOYEE_SEARCH_BY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(SoldUnitNavDTO navDto)
    {
        ViewState[VS_FILTER] = new SoldUnitFilterDTO();
        setSearchGrid(null);
        initDropdowns();
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(SoldUnitNavDTO navDto)
    {
        try
        {
            if (navDto != null)
            {
                drpSearchProperty.Text = navDto.PropertyId.ToString();
                drpBO.drpDataBase(drpSearchTower, DrpDataType.PROPERTY_TOWER, drpSearchProperty.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
                drpSearchTower.Text = navDto.PrTowerId.ToString();
                pnlSoldUnitGrid.Visible = true;
                setSearchFilter(navDto.filterDTO);
                loadSoldUnitSearchGrid();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageLayout()
    {
    }
    private void setSearchGrid(List<PrUnitSaleDetailDTO> tmpList)
    {
        ViewState[VS_UNIT_LIST] = (tmpList != null) ? tmpList : new List<PrUnitSaleDetailDTO>();
        soldUnitSearchGrid.DataSource = getSearchPrSaleDetailList();
        soldUnitSearchGrid.DataBind();
    }
    private List<PrUnitSaleDetailDTO> getSearchPrSaleDetailList()
    {
        return (List<PrUnitSaleDetailDTO>)ViewState[VS_UNIT_LIST];
    }
    private PrUnitSaleDetailDTO getSearchPrSaleDetailDTO(long Id)
    {
        List<PrUnitSaleDetailDTO> searchList = getSearchPrSaleDetailList();
        PrUnitSaleDetailDTO selectedUnitDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            selectedUnitDTO = searchList.Find(c => c.Id == Id);
        }
        return selectedUnitDTO;
    }
    private void loadSoldUnitSearchGrid()
    {
        IList<PrUnitSaleDetailDTO> results = soldUnitBO.fetchSoldPropertyUnits(getUserDefinitionDTO().FirmNumber, long.Parse(drpSearchTower.Text), getSearchFilter());
        setSearchGrid(results.ToList());
    }
    protected void onSelectSearchByProperty(object sender, EventArgs e)
    {
        try
        {
            pnlSoldUnitGrid.Visible = false;
            drpSearchTower.Items.Clear();
            setSearchFilter(null);
            if (!string.IsNullOrWhiteSpace(drpSearchProperty.Text))
            {
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                drpBO.drpDataBase(drpSearchTower, DrpDataType.PROPERTY_TOWER, drpSearchProperty.Text, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                if (drpSearchTower.Items.Count == 2)
                {
                    pnlSoldUnitGrid.Visible = true;
                    drpSearchTower.Items[1].Selected = true;
                    loadSoldUnitSearchGrid();
                }
            }
            else
            {
                setSearchGrid(null);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onSelectSearchByTower(object sender, EventArgs e)
    {
        try
        {
            pnlSoldUnitGrid.Visible = false;
            if (!string.IsNullOrWhiteSpace(drpSearchTower.Text))
            {
                pnlSoldUnitGrid.Visible = true;
                loadSoldUnitSearchGrid();
            }
            else
            {
                setSearchGrid(null);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickViewSoldUnitBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            PrUnitSaleDetailDTO prUnitSaleDetailDTO = getSearchPrSaleDetailDTO(selectedId);
            BookingSuccessNavDTO navDTO = new BookingSuccessNavDTO();
            navDTO.PropertyId = prUnitSaleDetailDTO.PropertyUnit.PropertyTower.Property.Id;
            navDTO.PropertyName = prUnitSaleDetailDTO.PropertyUnit.PropertyTower.Property.Name;
            navDTO.PrTowerId = prUnitSaleDetailDTO.PropertyUnit.PropertyTower.Id;
            navDTO.PrUnitId = prUnitSaleDetailDTO.PropertyUnit.Id;
            navDTO.PrUnitSaleDetailId = prUnitSaleDetailDTO.Id;
            navDTO.customerId = prUnitSaleDetailDTO.Customer.Id;
            Session[Constants.Session.NAV_BOOKING_SUCCESS] = navDTO;
            Response.Redirect(Constants.URL.BOOKING_SUCCESS, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifySoldUnitBtn(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickCancelBookingBtn(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickGenerateLettersBtn(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Filter Criteria - Property Search - Start
    private SoldUnitFilterDTO getSearchFilter()
    {
        return (SoldUnitFilterDTO)ViewState[VS_FILTER];
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            SoldUnitFilterDTO filterDTO = getSearchFilter();
            if (filterDTO.CustomerId > 0) drpCustomerFilter.Text = filterDTO.CustomerId.ToString(); else drpCustomerFilter.ClearSelection();
            if (filterDTO.CustRefNo != null) txtCustRefNoFilter.Text = filterDTO.CustRefNo; else txtCustRefNoFilter.Text = null;
            if (filterDTO.UnitId > 0) drpUnitNoFilter.Text = filterDTO.UnitId.ToString(); else drpUnitNoFilter.ClearSelection();
            if (filterDTO.SalesExecutiveId > 0) drpSalesExecutiveFilter.Text = filterDTO.SalesExecutiveId.ToString(); else drpSalesExecutiveFilter.ClearSelection();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            SoldUnitFilterDTO filterDTO = new SoldUnitFilterDTO();
            if (!string.IsNullOrWhiteSpace(drpCustomerFilter.Text))
            {
                filterDTO.CustomerId = long.Parse(drpCustomerFilter.Text);
                filterDTO.CustomerName = drpCustomerFilter.SelectedItem.Text;
            }
            if (!string.IsNullOrWhiteSpace(txtCustRefNoFilter.Text))
            {
                filterDTO.CustRefNo = txtCustRefNoFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(drpUnitNoFilter.Text))
            {
                filterDTO.UnitId = long.Parse(drpUnitNoFilter.Text);
                filterDTO.UnitNo = drpUnitNoFilter.SelectedItem.Text;
            }
            if (!string.IsNullOrWhiteSpace(drpSalesExecutiveFilter.Text))
            {
                filterDTO.SalesExecutiveId = long.Parse(drpSalesExecutiveFilter.Text);
                filterDTO.SalesExecutiveName = drpSalesExecutiveFilter.SelectedItem.Text;
            }
            setSearchFilter(filterDTO);
            loadSoldUnitSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            loadSoldUnitSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(SoldUnitFilterDTO searchFilterDTO)
    {
        ViewState[VS_FILTER] = (searchFilterDTO != null) ? searchFilterDTO : new SoldUnitFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            SoldUnitFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.CUSTOMER))
            {
                filterDTO.CustomerId = 0;
                filterDTO.CustomerName = "";
            }
            else if (token.StartsWith(Constants.FILTER.CUST_REF_NO)) filterDTO.CustRefNo = null;
            else if (token.StartsWith(Constants.FILTER.UNIT_NO))
            {
                filterDTO.UnitId = 0;
                filterDTO.UnitNo = "";
            }
            else if (token.StartsWith(Constants.FILTER.SALES_EXECUTIVE))
            {
                filterDTO.SalesExecutiveId = 0;
                filterDTO.SalesExecutiveName = "";
            }

            setSearchFilterTokens();
            loadSoldUnitSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        SoldUnitFilterDTO filterDTO = getSearchFilter();
        string filter = "";
        if (filterDTO != null)
        {
            if (filterDTO.CustomerId > 0) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.CUSTOMER + filterDTO.CustomerName);
            if (filterDTO.CustRefNo != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.CUST_REF_NO + filterDTO.CustRefNo);
            if (filterDTO.UnitId > 0) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.UNIT_NO + filterDTO.UnitNo);
            if (filterDTO.SalesExecutiveId > 0) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.SALES_EXECUTIVE + filterDTO.SalesExecutiveName);
        }
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - PropertyUnit Search - End
}
