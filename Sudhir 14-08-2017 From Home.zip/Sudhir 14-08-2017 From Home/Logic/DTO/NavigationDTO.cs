﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ConstroSoft;

/// <summary>
/// </summary>
namespace ConstroSoft
{
    [Serializable]
    public class EnquiryFollowUpNavDTO
    {
        public EnquiryFollowUpNavDTO() { }
        public long EnquiryId { get; set; }
    }
    [Serializable]
    public class BookingFormNavDTO
    {
        public BookingFormNavDTO() { }
        public PageNavigation Navigation { get; set; }  
        public long PropertyId { get; set; }
        public long PrTowerId { get; set; }
        public long PrUnitId { get; set; }
        public long EnquiryId { get; set; }
        public bool copyCustomerDtls { get; set; }
        public object PrevNavDto { get; set; }
    }
    [Serializable]
    public class BookingSuccessNavDTO
    {
        public BookingSuccessNavDTO() { }
        public long PropertyId { get; set; }
        public string PropertyName { get; set; }
        public long PrTowerId { get; set; }
        public long PrUnitId { get; set; }
        public long PrUnitSaleDetailId { get; set; }
        public long customerId;
    }
    [Serializable]
    public class PaymentNavDTO
    {
        public PaymentNavDTO() { }
        public long PropertyId { get; set; }
        public long PrTowerId { get; set; }
        public long PrUnitId { get; set; }
    }
    [Serializable]
    public class PropertyUnitNavDTO
    {
        public PropertyUnitNavDTO() { }
        public PageNavigation Navigation { get; set; }  
        public long PropertyId { get; set; }
        public long PrTowerId { get; set; }
        public PropertyUnitFilterDTO filterDTO { get; set; }
    }
    [Serializable]
    public class SoldUnitNavDTO
    {
        public SoldUnitNavDTO() { }
        public PageNavigation Navigation { get; set; }  
        public long PropertyId { get; set; }
        public long PrTowerId { get; set; }
        public SoldUnitFilterDTO filterDTO { get; set; }
    }
}