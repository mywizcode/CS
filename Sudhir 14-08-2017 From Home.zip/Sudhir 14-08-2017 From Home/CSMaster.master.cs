﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using ConstroSoft;

public partial class CSMaster : System.Web.UI.MasterPage
{
    string fnName = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            try
            {
                if (CommonUtil.isSessionActive(Session))
                {
                    UserDefinitionDTO userDef = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
                    lbUserName.Text = userDef.Username;
                    setFunctionName();
                    initSidebar();
                    applyEntitlement();
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
            catch (Exception ex)
            {
            }
        }
    }
    private void setFunctionName()
    {
        string url = HttpContext.Current.Request.Url.AbsolutePath;
        string[] arrUrl = url.Split('/');
        functionName.Value = getURIPart(1).ToUpper();
        pageName.Value = getURIPart(2).ToUpper();
    }
    private string getURIPart(int index)
    {
        string url = HttpContext.Current.Request.Url.AbsolutePath;
        string[] arrUrl = url.Split('/');
        return (arrUrl.Length > index) ? arrUrl[index] : "";
    }
    private bool isCRM()
    {
        return (Constants.Function.CRM.ToUpper().Equals(functionName.Value));
    }
    private bool isERP()
    {
        return (Constants.Function.ERP.ToUpper().Equals(functionName.Value));
    }
    private bool isAcntFianance()
    {
        return (Constants.Function.ACNT_FINANCE.ToUpper().Equals(functionName.Value));
    }
    private bool isFirmPropertySetup()
    {
        return (Constants.Function.FIRM_PROPERTY_SETUP.ToUpper().Equals(functionName.Value));
    }
    private bool isAdministration()
    {
        return (Constants.Function.ADMINISTRATION.ToUpper().Equals(functionName.Value));
    }
    private void initSidebar()
    {
        CRMDashboard.Visible = isCRM();
        PreSaleMenuHeader.Visible = isCRM();
        PostSaleMenuHeader.Visible = isCRM();
        EnquiryManagementMenu.Visible = isCRM();
        SaleManagementMenu.Visible = isCRM();
        PromoManagementMenu.Visible = isCRM();
        ERPDashboard.Visible = isERP();
        AcntFinanceDashboard.Visible = isAcntFianance();
        AcntFinanceMenuHeader.Visible = isAcntFianance();
        AccountManagementMenu.Visible = isAcntFianance();
        PaymentManagementMenu.Visible = isAcntFianance();
        ExpensesMenuHeader.Visible = isAcntFianance();
        ExpenseManagementMenu.Visible = isAcntFianance();
        AcntFinanceReportMenuHeader.Visible = isAcntFianance();
        AcntFinanceReportMenu.Visible = isAcntFianance();
        FirmMenuHeader.Visible = isFirmPropertySetup();
        FirmSetup.Visible = isFirmPropertySetup();
        PropertySetupMenuHeader.Visible = isFirmPropertySetup();
        Property.Visible = isFirmPropertySetup();
        PropertyUnit.Visible = isFirmPropertySetup();
        PymtSchedule.Visible = isFirmPropertySetup();
        PropertyParking.Visible = isFirmPropertySetup();
        MasterData.Visible = isAdministration();

        //Set sidebar menu header
        setSidebarMenuText();
    }
    private void setSidebarMenuText()
    {
        divSidebarHeader.Visible = false;
        if (isCRM())
        {
            divSidebarHeader.Visible = true;
            lbSidebarMenuIcon.Text = Constants.ICON.CRM_FN_MENU;
            lbSidebarMenuText.Text = Resources.Labels.CRM_MENU;
            lbSidebarMenuDesc.Text = "Pre and Post Sale";
        }
        else if (isERP())
        {
            divSidebarHeader.Visible = true;
            lbSidebarMenuIcon.Text = Constants.ICON.ERP_FN_MENU;
            lbSidebarMenuText.Text = Resources.Labels.ERP_MENU;
            lbSidebarMenuDesc.Text = "Enterprise Resource Planning";
        }
        else if (isAcntFianance())
        {
            divSidebarHeader.Visible = true;
            lbSidebarMenuIcon.Text = Constants.ICON.ACNTFINANCE_FN_MENU;
            lbSidebarMenuText.Text = Resources.Labels.ACCNT_FINANCE_MENU;
            lbSidebarMenuDesc.Text = "Account and Payments";
        }
        else if (isFirmPropertySetup())
        {
            divSidebarHeader.Visible = true;
            lbSidebarMenuIcon.Text = Constants.ICON.PR_SETUP_FN_MENU;
            lbSidebarMenuText.Text = Resources.Labels.FIRM_PROPERTY_SETUP_MENU;
            lbSidebarMenuDesc.Text = "Firm and Property settings";
        }
        else if (isAdministration())
        {
            divSidebarHeader.Visible = true;
            lbSidebarMenuIcon.Text = Constants.ICON.ADMIN_FN_MENU;
            lbSidebarMenuText.Text = Resources.Labels.ADMINISTRATION_MENU;
            lbSidebarMenuDesc.Text = "Application settings";
        }
    }
    public void logoutUser(object sender, System.EventArgs e)
    {
        CommonUtil.clearSession(Session, Application);
        Response.Redirect(Constants.URL.LOGIN, true);
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        //Dashboard
        
    }
}
