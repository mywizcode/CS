﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ConstroSoft;

/// <summary>
/// Summary description for UserDefinitionDTO
/// </summary>
namespace ConstroSoft
{
    [Serializable]
    public class PropertyFilterDTO
    {
        public PropertyFilterDTO() { }
        public long PropertyId { get; set; }
        public string PropertyName { get; set; }
        public MasterControlDataDTO Type { get; set; }
        public MasterControlDataDTO Location { get; set; }
    }
    [Serializable]
    public class PropertyUnitFilterDTO
    {
        public PropertyUnitFilterDTO() { }
        public long UnitId { get; set; }
        public string UnitNo { get; set; }
        public string Wing { get; set; }
        public string FloorNo { get; set; }
        public MasterControlDataDTO UnitType { get; set; }
        public PRUnitStatus? Status { get; set; }
    }
    [Serializable]
    public class PropertyParkingFilterDTO
    {
        public PropertyParkingFilterDTO() { }
        public long ParkingId { get; set; }
        public string ParkingNo { get; set; }
        public MasterControlDataDTO ParkingType { get; set; }
        public CommonParking? CommonParking { get; set; }
        public ParkingStatus? Status { get; set; }
    }
    [Serializable]
    public class SoldUnitFilterDTO
    {
        public SoldUnitFilterDTO() { }
        public long UnitId { get; set; }
        public string UnitNo { get; set; }
        public long CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string CustRefNo { get; set; }
        public long SalesExecutiveId { get; set; }
        public string SalesExecutiveName { get; set; }
    }

    [Serializable]
    public class EnquiryFilterDTO
    {
        public EnquiryFilterDTO() { }
        public string EnquiryRef { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string ContactNo { get; set; }
        public MasterControlDataDTO EnquirySource { get; set; }
        public EnquiryStatus? Status { get; set; }
        public string LeadRef { get; set; }       
    }

    [Serializable]
    public class CustomerFilterDTO
    {
        public CustomerFilterDTO() { }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime? Dob { get; set; }
        public string Contact { get; set; }
        public string CustRefNo { get; set; }
    }
    [Serializable]
    public class CustomerPymtSearchFilterDTO
    {
        public CustomerPymtSearchFilterDTO() { }
        public long UnitId { get; set; }
        public string UnitNo { get; set; }
        public long CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string CustRefNo { get; set; }
        public string BookingRefNo {get; set;}
        public PRUnitSaleStatus? UnitSaleStatus { get; set; }
    }
    [Serializable]
    public class CustomerPymtTxHistoryFilterDTO
    {
        public CustomerPymtTxHistoryFilterDTO() { }
        public long PymtTypeId { get; set; }
        public string PymtType { get; set; }
        public PaymentMethod? PymtMethod { get; set; }
        public string TxRefNo { get; set; }
        public string MediaNo {get; set;}
    }
}