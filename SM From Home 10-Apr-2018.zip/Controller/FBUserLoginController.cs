﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ConstroSoft.Controller
{
    public class FBUserLoginController : ApiController
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        FBIntegrationBO fBIntegrationBO = new FBIntegrationBO();

        [HttpPost]
        [ActionName("LoginUser")]
        public string LoginUser([FromBody]PortalUserDTO inputDTO)
        {
        	List<string> responseJson = new List<string>();
        	try
            {
        		if(inputDTO == null) throw new CustomException("Input object cannot be NULL.");
        		
        		responseJson = validateInputMandatoryFields(inputDTO);
                if(responseJson.Count == 0) {
                	
                	BusinessOutputTO outputTO = fBIntegrationBO.validateFBUser(inputDTO);
                    if (BusinessOutputTO.Status.SUCCESS.Equals(outputTO.status))
                    {
                        PortalUserDTO tmpDTO = (PortalUserDTO)outputTO.result;
                        string tokenKey = fBIntegrationBO.saveFBToken(tmpDTO);
                        responseJson.Add("User log in successfully for " + tmpDTO.UserName);
                        responseJson.Add(" Token: " + tokenKey);
                        responseJson.Add(" Token Expiry: 1800000");
                    }
                    else
                    {
                        responseJson.Add(outputTO.errorMessage);
                    }
                }                
            }
        	catch (Exception exp)
            {
                log.Error("Unexpected error while login user from facebook.", exp);
                responseJson.Add(CommonUtil.getErrorMessage(exp));
            }
        	return JsonConvert.SerializeObject(responseJson);
        }
        private List<string> validateInputMandatoryFields(PortalUserDTO inputDTO)
        {
        	List<string> errMsgList = new List<string>();
            if (string.IsNullOrWhiteSpace(inputDTO.UserName)) errMsgList.Add("User Name is mandatory.");
            if (string.IsNullOrWhiteSpace(inputDTO.Password)) errMsgList.Add("Password is mandatory.");
            return errMsgList;
        }
    }
}