﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
	initTaxGrid();
	initCMTaxGrid();
	initPaymentGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initTaxGrid() {
    var dtOptions = {
        hasActionColumn: false,
        hideSearch: true,
        pagination: false,
        sorting: false
    };

    $("[id$='taxDetailGrid']").CSBasicDatatable(dtOptions);
}
function initCMTaxGrid() {
    var dtOptions = {
        hasActionColumn: false,
        hideSearch: true,
        pagination: false,
        sorting: false
    };

    $("[id$='cmTaxDetailGrid']").CSBasicDatatable(dtOptions);
}
function initPaymentGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: isViewOnly,
        customBtnGrpId: "#paymentGridBtnGrp",
        rowInfoModalTitle: "Payment Details",
        pageLength: 5,
        sortColumn: 2,
        hideSearch: true
    };

    $("[id$='paymentGrid']").CSBasicDatatable(dtOptions);
}



