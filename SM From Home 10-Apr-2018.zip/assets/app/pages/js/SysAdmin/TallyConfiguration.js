﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initTallyConfigGrid();
	formatFields(controlToFormat);
    showModal(controlToFormat);
}
function initTallyConfigGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#TallyConfigSearchBtnDiv",
        pageLength: 5,
        hideSearch: true
    };

    $("[id$='TallyConfigGrid']").CSBasicDatatable(dtOptions);
}