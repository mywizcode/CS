﻿
/// <summary>
/// Summary description for MyENUM
/// </summary>

using System;
using System.ComponentModel;
namespace ConstroSoft
{
    /*ENUMs which are used to map Only UI fields*/
	public enum DrpDataType
    {
        MASTER_CONTROL_DATA,////Fetch all records for given type
        MASTER_CONTROL_DATA_N,//Fetch records for given type with SYSTEM_DEFINED = "N"
        COUNTRY,
        STATE,
        CITY,
        SECURITY_QUESTION,
        ENQUIRY_REFERENCE_NUMBER,
        PROPERTY_NAME,
        PROPERTY_TOWER,
        FIRM_ACCOUNT,
        ACTIVE_USERS_WITH_PR_ACCESS,
        ALL_USERS_WITH_PR_ACCESS,
        PR_AVAILABLE_PARKING,
        CUSTOMER_SEARCH_BY_NAME_REF,
        CUSTOMER_SEARCH_BY_NAME,
        PR_AVAILABLE_UNIT,
        PR_TOWER_UNITS,
        PR_PARKING_SEARCH_BY_PARKINGNO,
        PR_TOWER_SOLD_UNITS,
        COMPLETED_SCHEDULE_STAGE,
        EMAIL_PROVIDER,
        SMS_PROVIDER,
        EMAIL_STORE_TEMPLATE,
        SMS_STORE_TEMPLATE
    }
    public enum AcntTransStmtOption
    {
        [Description("Current Month")]
        CURRENT_MONTH,
        [Description("Last Two Months")]
        LAST_TWO_MONTHS,
        [Description("Last Three Months")]
        LAST_THREE_MONTHS,
        [Description("Date Range")]
        DATE_RANGE
    }
    public enum ResetPasswordStep { USER_LOGIN, SECURITY_VALIDATION, RESET_PASSWORD, USER_LOGIN_SETUP }
    /*ENUMs which are used to map DB and UI fields. NOTE: If you add/remove any value then you need to modify corresponding DB mapping in EnumDBHelper.cs*/
    public enum UserStatus { Setup, Active, InActive }
    public enum PreferredAddress { Yes, No }
    public enum MaritalStatus { Single, Married }   
    public enum Gender { Male, Female }
    public enum CallProvider { NONE, EXOTEL }
    public enum EnquiryStatus { Open, Won, Lost}
    public enum EnqActivityRecordType { Activity, Task, Note, Action, Call}
    public enum ActivityTypeFilter { Activity, Task, Note, Action, Call, Attachment }
    public enum ReminderMode { None, Scheduled, Rescheduled, Cancelled }
    public enum EnqActivityType
    {
        [Description("Site Visit")]
        SITE_VISIT,
        [Description("Meeting")]
        MEETING,
        [Description("Followup")]
        FOLLOW_UP,
        [Description("Assignment")]
        ASSIGNMENT,
        [Description("Reassignment")]
        RE_ASSIGNMENT,
        [Description("Converted")]
        CONVERTED,
        [Description("Created")]
        CREATE,
        [Description("Lost")]
        LOST,
        [Description("Won")]
        WON,
        [Description("Booking Cancelled")]
        BOOKING_CANCELLED,
        [Description("Re-Opened")]
        RE_OPENED,
        [Description("Task")]
        TASK,
        [Description("Note")]
        NOTE,
        [Description("Call")]
        CALL,
        [Description("Facebook Enquiry")]
        FACEBOOK_ENQUIRY
    }
    public enum EnqLeadActivityStatus { Open, Deferred, Completed }
    public enum LeadStatus { Open, Converted, Lost}
	public enum PowerOfAtorny { Yes, No }
	public enum FamilyRelation
    {
        [Description("Son of")]
        SON_OF,
        [Description("Daughter of")]
        DAUGHTER_OF,
        [Description("Wife of")]
        WIFE_OF
    }
    public enum SystemDefined { Yes, No }
    public enum CommonParking { Yes, No }
    public enum ParkingStatus { Available, Reserved, Allotted, Deleted }
    public enum PRScheduleStageStatus { Pending, Completed }
    public enum IncludeInPymtTotal { Yes, No }
    public enum PRUnitStatus { Available, Reserved, Sold, Deleted }
    public enum PRUnitSaleStatus { Sold, Cancelled }
    public enum PrFMAccess { No, Yes }
    public enum VoucherType { Payment, Receipt }
    public enum TallyPostingStatus { [Description("Pending")]Pending, [Description("Posted")] Posted }
    public enum Action { Create, Cancel }
    public enum PaymentMode{ Receivable, Payable }
    public enum PrAlertFunctionName
    {
        [Description("New Enquiry Add")]
        ENQ_ADD_CUSTOMER,
        [Description("New Lead Add")]
        LD_ADD_CUSTOMER,
        [Description("Property Unit Booking")]
        UNIT_BOOKING_CUSTOMER,
        [Description("Property Unit Booking Cancellation")]
        UNIT_CANCELLATION_CUSTOMER
    }
    public enum EmailSmsType { Email, SMS }
    public enum EmailSmsStoreStatus { Draft, Published }
    public enum EmailSmsCampaignStage { Draft, Scheduled, Completed }
    public enum EmailSmsCampaignStatus { NotStarted, Success, Failed, Inprogress }
    public enum EmailSmsScheduleOption { Now, Scheduled }
    public enum EmailSmsRcpntType
    {
        [Description("All Leads and Customers")]
        ALL_LD_CUSTOMER,
        [Description("All Leads")]
        ALL_LEADS,
        [Description("All Customers")]
        ALL_CUSTOMERS,
        [Description("Only Sold Unit Customers")]
        ONLY_SOLD_UNIT_CUSTOMERS
    }
    public enum ReportTemplateType
    {
        [Description("Demand Letter")]
        DEMAND_LETTER,
        [Description("Possession Letter")]
        POSSESSION_LETTER,
        [Description("Mortgage Letter")]
        MORTGAGE_LETTER,
        [Description("Payment Receipt")]
        PAYMENT_RCPT,
        [Description("Unit Quotation")]
        UNIT_QUOTATION,
        [Description("Payment Due Report")]
        PAYMENT_DUE_REPORT,
        [Description("Payment Forecast Report")]
        PAYMENT_FORECAST_REPORT,
        [Description("Account Statement")]
        ACNT_STATEMENT,
        [Description("Lead and Enquiry Report")]
        ENQ_LEAD_REPORT
    }
    public enum EmailPersonalization
    {
        [Description("Salutation of customer to which email will be sent.")]
        CUSTOMER_SALUTATION,
        [Description("First name of customer to which email will be sent.")]
        CUSTOMER_FIRST_NAME,
        [Description("Middle name of customer to which email will be sent.")]
        CUSTOMER_MIDDLE_NAME,
        [Description("Last name of customer to which email will be sent.")]
        CUSTOMER_LAST_NAME,
        [Description("Name of the Property.")]
        PROPERTY_NAME,
        [Description("Name of the Property Tower.")]
        PROPERTY_TOWER_NAME,
        [Description("Property Unit number. It will be in format '{WING}-{UNIT_NO}'")]
        PROPERTY_UNIT_NO
    }
    public enum IsCustomReport { No, Yes }
    public enum PackagePurchaseStatus { New, Renew }
    public enum PackageStatus { Active, Consumed, Upcoming }
    public enum EmailSmsEnabled { No, Yes }
    public enum IsPossessionDone { No, Yes }
    public enum IsAgreementDone { No, Yes }
    public enum EmailEnableSSL { No, Yes }
    public enum IsEnabled { No, Yes }
    public enum IsDefault { No, Yes }
    public enum PymtTransStatus { Pending, Paid, Deleted, Reversal }
    public enum ChequeStatus { Collected, Deposited, Cleared, Bounced, Returned }
    public enum MPTPymtStatus { Pending, Paid, Deleted }
    public enum PymtMasterStatus
    {
        [Description("Paid")]
        Paid,
        [Description("Pending")]
        Pending,
        [Description("Deleted")]
        Deleted,
        [Description("Suspended")]
        Suspended
    }
    public enum PaymentMethod
    {
        [Description("Cash")]
        CASH,
        [Description("Cheque")]
        CHEQUE,
        [Description("RTGS")]
        RTGS,
        [Description("NEFT")]
        NEFT,
        [Description("Demand Draft")]
        DD
    }
    public enum AcntTransStatus { Credit, Debit }
    public enum PymtTransRcptDelivered { No, Yes}
    public enum PromoCustomerType { ENQUIRY, SALE, CO_CUSTOMER, ONLY_CUSTOMER }
    public enum PropertyFundStatus { Deposited, Reversed }

    public enum DocumentOwner
    {
        [Description("--Select--")]
        NONE,
        [Description("Property Name")]
        PROPERTY_NAME,
        [Description("Customer Name")]
        CUSTOMER_NAME,
        [Description("Supplier Name")]
        SUPPLIER_NAME,
        [Description("Contractor Name")]
        CONTACTOR_NAME,
        [Description("Employee Name")]
        EMPLOYEE_NAME
    }

    public enum MasterDataType
    {
    	//System Defined MCD
        [Description("Salutation")]
        SALUTATION,
        [Description("Address Type")]
        ADDRESS_TYPE,
        [Description("Account Type")]
        ACCOUNT_TYPE,
        //User Defined MCD
        [Description("Property Type")]
        PROPERTY_TYPE,
        [Description("Property Location")]
        PROPERTY_LOCATION,
        [Description("Property Tax Type")]
        PR_TAX_TYPE,
        [Description("Property Charges")]
        PROPERTY_CHARGES,
        [Description("Property Unit Type")]
        PR_UNIT_TYPE,
        [Description("Property Unit Direction")]
        PR_UNIT_DIRECTION,
        [Description("Unit Facing")]
        PR_UNIT_FACING,
        [Description("Expenses Type")]
        PR_EXPENSE_TYPE,
        [Description("Parking Type")]
        PR_PARKING_TYPE,
        [Description("Unit Payment Type")]
        PR_UNIT_PYMT_TYPE,//Partial System Defined
        [Description("Occupation")]
        OCCUPATION,
        [Description("Residential Status")]
        RESIDENTIAL_STATUS,
        [Description("Relation with Customer")]
        RELATION_WITH_CUSTOMER,
        [Description("Enquiry Source")]
        ENQUIRY_SOURCE,
        [Description("Communication Media")]
        COMMUNICATION_MEDIA,
        [Description("Document Type")]
        DOCUMENT_TYPE
    }

    public enum SoldUnitLetterType
    {
        [Description("Demand Letter")]
        DEMAND_LETTER,
        [Description("Possession Letter")]
        POSSESSION,
        [Description("NOC for Mortgage")]
        MORTGUAGE,
        [Description("Payment Receipt")]
        RECEIPT
    }
    public enum DashboardEvent
    {
        [Description("Possession")]
        POSSESSION,
        [Description("Agreement")]
        AGREEMENT
    }
    public enum PageMode {ADD, VIEW, MODIFY, GENERATELETTER}
    public enum EnqActivityMode { NONE, ADD_ACTIVITY, ADD_TASK, RESCHEDULE_TASK, COMPLETE_TASK, CANCEL_TASK, ADD_NOTE, MAKE_CALL}
    public enum FileType {Folder, File}
    public enum SizeUnits {Byte, KB, MB, GB}
    public enum NotificationType
    {
        [Description("Alert")]
        ALERT,
        [Description("Task")]
        TASK
    }
    public enum NotificationSubType
    {
    	//Enums saved to DB
        NEW_LEAD_ASSIGNED,//Alert
        LEAD_REASSIGNED_SELF,//Alert
        LEAD_REASSIGNED_USER,//Alert
        LEAD_CLOSED_USER,//Alert
        LEAD_ACTIVITY_LOGGED_BY_USER,//Alert
        LEAD_CONVERTED_BY_USER,//Alert
        ENQUIRY_REASSIGNED_SELF,//Alert
        ENQUIRY_REASSIGNED_USER,//Alert
        ENQUIRY_CLOSED_USER,//Alert
        ENQUIRY_REOPEN_USER,//Alert
        ENQUIRY_ACTIVITY_LOGGED_BY_USER,//Alert
        ENQUIRY_USED_FOR_BOOKING,//Alert
        LEAD_ACTIVITY_LOGGED_BY_FACEBOOK,//Alert
        ENQUIRY_ACTIVITY_LOGGED_BY_FACEBOOK,//Alert
        INCOMING_CALL_INTIMATION,//Alert
        //Enums NOT saved to DB
        UNASSIGNED_LEADS,//Task
        ENQUIRY_REMINDER,//Task
        LEAD_REMINDER,//Task
        UNRESOLVED_CALLS//Task        
    }
    public enum NotificationStatus { OPEN, CLOSED }
    public enum JobStatus { Active, InActive }
    public enum JobIntervalType { WithCalendarIntervalSchedule, WithCronSchedule,WithDailyTimeIntervalSchedule,WithSimpleSchedule}
    public enum JobExecutionStatus { Completed, Inprogress, Failed }
    public enum CallStatus { Queued, Inprogress, Completed, Failed, Busy, Noanswer, Free}
    public enum CallDirection { Outgoing, Incoming }
    public enum CallHistoryStatus { Unresolved, Resolved}
    public enum VwCustomerEntityType
    {
        [Description("Enquiry")]
        Enquiry,
        [Description("Lead")]
        Lead,
        [Description("Unit Owner")]
        UnitOwner,
        [Description("Unit Co-Owner")]
        UnitCoOwner
    }
    public enum IsSync { No, Yes }
    public enum PhoneType
    {
        [Description("Outgoing")]
        Outgoing,
        [Description("Incoming")]
        Incoming,
        [Description("Incoming and Outgoing")]
        Both
    }
}