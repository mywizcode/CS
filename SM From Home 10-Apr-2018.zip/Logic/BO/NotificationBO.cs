﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;
using ConstroSoft.Logic.CachingProvider;


/// <summary>
/// Summary description for PropertyAlertBO
/// </summary>
namespace ConstroSoft
{
    public class NotificationBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public NotificationBO() { }

        public void fetchAndCacheUserNotifications(UserDefinitionDTO userDefDTO, long propertyId)
        {
            ISession session = null;
            List<NotificationDTO> allNotificationList = new List<NotificationDTO>();
            List<NotificationDTO> propertyIndependentNotificationList = new List<NotificationDTO>();
            try
            {
            	session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	Notification notification = null;
                        //Fetch all notifications which are open for given user and property
                        var query = session.QueryOver<Notification>(() => notification);
                        IList<Notification> result = query.Where(() => notification.UserName == userDefDTO.Username 
                                && (notification.PropertyId == propertyId || notification.PropertyId == 0) && notification.Status == NotificationStatus.OPEN).List<Notification>();
                        foreach (Notification tmpObj in result)
                        {
                        	NotificationDTO tmpDTO = DomainToDTOUtil.convertToNotificationDTO(tmpObj, true);
                        	if(tmpDTO.PropertyId == 0) propertyIndependentNotificationList.Add(tmpDTO);
                        	else allNotificationList.Add(tmpDTO);
                        }
                        //Fetch qualifying Reminders scheduled on Lead and convert to task notifications
                        DateTime cutOffDate = DateUtil.getUserLocalDateTime().AddDays((int)(Constants.NOTIFICATIONS.REMINDER_TO_NOTIFY/24));
                        LeadActivity la = null;
                        LeadDetail ld = null;
                        FirmMember assignee = null;
                        Property p = null;
                        IList<LeadActivity> tmpLeadTaskList = session.QueryOver<LeadActivity>(() => la)
                        		.Left.JoinAlias(() => la.LeadDetail, () => ld)
                        		.Left.JoinAlias(() => ld.Assignee, () => assignee)
                                .Left.JoinAlias(() => ld.Property, () => p)
                                .Where(() => assignee.Id == userDefDTO.FirmMember.Id && p.Id == propertyId && la.RecordType == EnqActivityRecordType.Task 
                        			&& la.Status == EnqLeadActivityStatus.Open && la.ScheduledDate <= cutOffDate).List<LeadActivity>();
                        foreach(LeadActivity tmpActivity in tmpLeadTaskList)
                        {
                        	allNotificationList.Add(NotificationUtil.createLeadReminderNotification(userDefDTO, tmpActivity, userDefDTO.Username));
                        }
                        //Fetch qualifying Reminders scheduled on Enquiry and convert to task notifications
                        EnquiryActivity ea = null;
                        EnquiryDetail ed = null;
                        IList<EnquiryActivity> tmpEnquiryTaskList = session.QueryOver<EnquiryActivity>(() => ea)
                        		.Left.JoinAlias(() => ea.EnquiryDetail, () => ed)
                        		.Left.JoinAlias(() => ed.Assignee, () => assignee)
                                .Left.JoinAlias(() => ed.Property, () => p)
                        		.Where(() => assignee.Id == userDefDTO.FirmMember.Id && p.Id == propertyId && ea.RecordType == EnqActivityRecordType.Task 
                        			&& ea.Status == EnqLeadActivityStatus.Open && ea.ScheduledDate <= cutOffDate).List<EnquiryActivity>();
                        foreach(EnquiryActivity tmpActivity in tmpEnquiryTaskList)
                        {
                        	allNotificationList.Add(NotificationUtil.createEnquiryReminderNotification(userDefDTO, tmpActivity, userDefDTO.Username));
                        }
                        
                        NotificationCacheProvider.Instance.clearAndAddNotifications(
                            NotificationUtil.getNotificationUserKey(userDefDTO.Username, propertyId), allNotificationList);
                        NotificationCacheProvider.Instance.clearAndAddNotifications(
                                NotificationUtil.getNotificationUserKey(userDefDTO.Username, 0), propertyIndependentNotificationList);
                    }
                    catch (Exception e)
                    {
                    	log.Error("Unexpected error populating Notification for given user: " + userDefDTO.Username +", and property:" + propertyId, e);
                        log.Error(e.Message, e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void fetchAndCacheUnAssignedLeadCount()
        {
            ISession session = null;
            IList<Object[]> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        LeadDetail ld = null;
                        Property p = null;
                        result = session.QueryOver<LeadDetail>(() => ld)
                            .JoinAlias(() => ld.Property, () => p)
                            .SelectList(list => list
                                .SelectCount(() => ld.Id)
                                .SelectGroup(() => p.Id)
                            )
                            .Where(() => ld.Status == LeadStatus.Open && ld.Assignee == null)
                            .List<Object[]>();
                        NotificationCacheProvider.Instance.unMarkNewLeadFlag();
                        List<NotificationDTO> notificationList = new List<NotificationDTO>();
                        if (result != null && result.Count > 0)
                        {
                            foreach (object[] tmpObj in result)
                            {
                                NotificationDTO tmpNotificationDTO = NotificationUtil.createUnAssignedLeadsNotification(long.Parse(tmpObj[1].ToString()), int.Parse(tmpObj[0].ToString()));
                                notificationList.Add(tmpNotificationDTO);
                            }
                        }
                        NotificationCacheProvider.Instance.clearAndAddNotifications(Constants.Entitlement.MENU_LEAD_ASSIGNMENT, notificationList);
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while fetching unassigned lead count:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void markNotificationClosed(params long[] Ids)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	if(Ids != null && Ids.Count() > 0) {
                        	string hqlUpdate = "update Notification n set n.Status = :status where n.Id in (:IdList) and n.Status = :openStatus";
                            session.CreateQuery(hqlUpdate)
                                    .SetEnum("status", NotificationStatus.CLOSED)
                                    .SetEnum("openStatus", NotificationStatus.OPEN)
                                    .SetParameterList("IdList", Ids)
                                    .ExecuteUpdate();
                            tx.Commit();
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while marking notification as closed:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public long addNotification(NotificationDTO notificationDTO)
        {
            ISession session = null;
            long Id = 0;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Notification notification = DTOToDomainUtil.populateNotificationAddFields(notificationDTO);
                        session.Save(notification);
                        Id = notification.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while adding Notification:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }

        public void createUserNotificationsForInCall(UserDefinitionDTO userDefinitionDTO, CallHistoryDTO callHistoryDTO)
        {
            ISession session = null;
            IList<Notification> allNotificationList = new List<Notification>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                       Notification notification = null;
                       //Mark previous call intimations as closed - Fetch all notifications which are open for given user and property and mark as closed
                       allNotificationList = session.QueryOver<Notification>(() => notification)
                    		   .Where(() => notification.UserName == userDefinitionDTO.Username
	                                && notification.PropertyId == 0 && notification.Status == NotificationStatus.OPEN 
	                                && notification.SubType == NotificationSubType.INCOMING_CALL_INTIMATION).List<Notification>();
                       string key = null;
                       if(allNotificationList != null) {
	                       foreach (Notification dbNotification in allNotificationList)
	                       {
	                    	   dbNotification.Status = NotificationStatus.CLOSED;
	                           session.Update(dbNotification);
	                       }
                       }
                       //Add new INCOMING_CALL_INTIMATION notification in DB.
                       Notification newNotification = NotificationUtil.getAlertNotification(userDefinitionDTO,
                               "Incoming call from " + callHistoryDTO.CallerNumber, DateUtil.getUserLocalDateTime(),
                               NotificationSubType.INCOMING_CALL_INTIMATION, callHistoryDTO.CallerNumber, userDefinitionDTO.Username, callHistoryDTO.Id.ToString());
                       session.Save(newNotification);
                       NotificationDTO notificationDTO = DomainToDTOUtil.convertToNotificationDTO(newNotification, true);
                       //Convert new INCOMING_CALL_INTIMATION record to DTO and add to notification cache
                       key = NotificationUtil.getNotificationUserKey(newNotification.UserName, 0);
                       //It removes old call intimation notification and adds new.
                       NotificationCacheProvider.Instance.addCallIntimationForUser(key, notificationDTO);
                       tx.Commit();
                    }
                    catch (Exception e)
                    {
                        log.Error("Unexpected error populating Notification for given user: " + userDefinitionDTO.Username);
                        log.Error(e.Message, e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void removeUserNotificationsForInCall(UserDefinitionDTO userDefinitionDTO, long callHistoryId)
        {
            ISession session = null;
            IList<Notification> allNotificationList = new List<Notification>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Notification notification = null;
                        //Fetch all notifications which are open for given user and property
                        var query = session.QueryOver<Notification>(() => notification);
                        allNotificationList = query.Where(() => notification.UserName == userDefinitionDTO.Username && notification.CoIdentifier == callHistoryId.ToString()
                                 && notification.PropertyId == 0 && notification.Status == NotificationStatus.OPEN
                                 && notification.SubType == NotificationSubType.INCOMING_CALL_INTIMATION).List<Notification>();
                        string key = NotificationUtil.getNotificationUserKey(userDefinitionDTO.Username, 0);
                        //Find Notification where CoIdentifier = CALL_HISTORY.ID and mark as closed and update to DB
                        //Remove notification from Cache for key NotificationUtil.getNotificationUserKey() and UIUniqueKey = Notification.Id
                        foreach (Notification dbNotification in allNotificationList)
                        {
                            dbNotification.Status = NotificationStatus.CLOSED;
                            session.Update(dbNotification);
                            NotificationCacheProvider.Instance.removeNotification(key, dbNotification.Id.ToString());
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        log.Error("Unexpected error removing call intimation Notification for given user: " + userDefinitionDTO.Username);
                        log.Error(e.Message, e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void removeAllUserNotificationsForPassthrough(UserDefinitionDTO userDefinitionDTO, CallHistoryDTO callHistoryDTO)
        {
            ISession session = null;
            IList<Notification> allNotificationList = new List<Notification>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Notification notification = null;
                        //Fetch all notifications which are open for given user and property
                        allNotificationList = session.QueryOver<Notification>(() => notification)
                        		.Where(() => notification.UserName == userDefinitionDTO.Username && notification.CoIdentifier == callHistoryDTO.Id.ToString() 
	                                 && notification.PropertyId == 0 && notification.Status == NotificationStatus.OPEN 
	                                 && notification.SubType == NotificationSubType.INCOMING_CALL_INTIMATION).List<Notification>();
                        string key = NotificationUtil.getNotificationUserKey(userDefinitionDTO.Username, 0);
                        //Remove notification from Cache for key NotificationUtil.getNotificationUserKey() and UIUniqueKey = Notification.Id
                        Dictionary<string, string> dict = new Dictionary<string, string>();
                        foreach (Notification dbNotification in allNotificationList)
                        {
                            dbNotification.Status = NotificationStatus.CLOSED;
                            session.Update(dbNotification);
                            dict.Add(NotificationUtil.getNotificationUserKey(dbNotification.UserName, 0), dbNotification.Id.ToString());
                        }
                        if (dict.Count > 0)
                        {
                            NotificationCacheProvider.Instance.removeAllNotification(dict);
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        log.Error("Unexpected error removing Notification for given user: " + userDefinitionDTO.Username);
                        log.Error(e.Message, e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void fetchAndCacheUnResolvedCallCount()
        {
            ISession session = null;
            IList<Object[]> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        CallHistory callHistory = null;
                        result = session.QueryOver<CallHistory>(() => callHistory)
                                .SelectList(list => list
                                .SelectCount(() => callHistory.Id)
                                .SelectGroup(() => callHistory.FirmMember.User.Username)
                            )
                            .Where(() => callHistory.CallHistoryStatus == CallHistoryStatus.Unresolved)
                            .List<Object[]>();
                        NotificationCacheProvider.Instance.unMarkUnResolvedFlag();
                        List<NotificationDTO> notificationList = new List<NotificationDTO>();
                        if (result != null && result.Count > 0)
                        {
                            foreach (object[] tmpObj in result)
                            {
                                NotificationDTO tmpNotificationDTO = NotificationUtil.createUnResolvedCallNotification(tmpObj[1].ToString(), int.Parse(tmpObj[0].ToString()));
                                notificationList.Add(tmpNotificationDTO);
                                NotificationCacheProvider.Instance.clearAndAddNotifications(NotificationUtil.getNotificationUserKey(tmpObj[1].ToString(), 0), notificationList);
                                notificationList.Clear();
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while fetching unresolved call count:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
    }
}