﻿
using ConstroSoft.TelephonyProvider.ExotelProvider;
using RestSharp;
using System;


/// <summary>
/// Summary description for FBIntegrationBO
/// </summary>
namespace ConstroSoft.TelephonyProvider
{
    public class CallClient
    {

        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        FirmBO firmBO = new FirmBO();
        
        public CallClient()
        {

        }

        public CallHistoryDTO placeOutBoundCall(OutboundCallDialDTO callDialDTO, UserDefinitionDTO userDefDTO)
        {
            CallHistoryDTO callHistoryDTO = null;
            try
            {
            	CallProvider callProvider = firmBO.fetchCallProvider(userDefDTO.FirmNumber);
                if (callProvider == CallProvider.EXOTEL){
                   ExotelClient exotelClient = new ExotelClient();
                   callHistoryDTO = exotelClient.placeOutBoundCall(callDialDTO, userDefDTO);
                } else throw new CustomException("Unable to find Call Provider. Please conatct system administrator.");
            }
            catch (CustomException exp)
            {
                throw exp;
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while placing outbound call");
                log.Error(exp.Message, exp);
                throw new CustomException("Unable to place a call. Please contact system administrator.");
            }
            finally
            {
            }
            return callHistoryDTO;
        }
    }
}