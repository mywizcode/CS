﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using ConstroSoft;
using ConstroSoft.Logic.CachingProvider;

public partial class CSAdminMaster : System.Web.UI.MasterPage
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            try
            {
                if (ApplicationUtil.isSessionActive(Session) && ApplicationUtil.IsSessionKeyExistInCache(Session))
                {
                    UserDefinitionDTO userDef = getUserDefinitionDTO();
                    lbUserName.Text = userDef.Username;
                    hdnUserName.Value = userDef.Username;
                    imgProfilePic.ImageUrl = userDef.ProfileImagePath;

                    setFunctionName();
                    initSidebar();
                    initHeaderFirmGrid();
                }
                else
                {
                    doLogout(Constants.URL.LOGIN);
                }
            }
            catch (Exception ex)
            {
            }
        }
    }
    public void setPageErrorInNotyMsg(ValidatorCollection collection)
    {
        List<string> tmpList = new List<string>();
        if (collection != null)
        {
            List<IValidator> validatorList = collection.Cast<IValidator>().Where(v => !v.IsValid).ToList();
            if (validatorList != null && validatorList.Count > 0)
            {
                foreach (IValidator validator in validatorList)
                {
                    tmpList.Add(CommonUtil.getNotyErrorMsg(validator.ErrorMessage));
                    validator.IsValid = true;
                }
            }
        }
        if (tmpList.Count > 0) setNotyMsg(tmpList);
    }
    public void setNotyMsg(string msg)
    {
        if (!string.IsNullOrWhiteSpace(msg))
        {
            btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
            upNotyMsg.Update();
        }
    }
    public void setNotyMsg(List<string> msgList)
    {
        msgList.ForEach(x => btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, x));
        upNotyMsg.Update();
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void setFunctionName()
    {
        string[] fnAndPageName = ApplicationUtil.getFunctionAndPageName(HttpContext.Current.Request, 1);
        functionName.Value = fnAndPageName[0].ToUpper();
        pageName.Value = fnAndPageName[1].ToUpper();
    }
    private bool isCustomerFirmSetup()
    {
        return (Constants.Function.CUSTOMER_FIRM.ToUpper().Equals(functionName.Value));
    }
    private bool isDefaultFirmSetup()
    {
        return (Constants.Function.DEFAULT_FIRM.ToUpper().Equals(functionName.Value));
    }
    private void initSidebar()
    {
        UserDefinitionDTO userDefDTO = getUserDefinitionDTO();

        bool isCustomerFirmSetupEnabled = isCustomerFirmSetup();
        bool isDefaultFirmSetupEmabled = isDefaultFirmSetup();
        //Firm Setup Menu
        FirmSetup.Visible = isCustomerFirmSetupEnabled;
        //User Management
        UserRole.Visible = isCustomerFirmSetupEnabled;
        User.Visible = isCustomerFirmSetupEnabled;
        PortalUser.Visible = isCustomerFirmSetupEnabled;
        UserManagementMenu.Visible = UserRole.Visible || User.Visible || PortalUser.Visible;
        //Firm Report/Letter Templates
        FirmReportLetterTemplates.Visible = isCustomerFirmSetupEnabled;
        TallySetup.Visible = isCustomerFirmSetupEnabled;
        ExotelSetup.Visible = isCustomerFirmSetupEnabled;
        ManageFirmJobs.Visible = isCustomerFirmSetupEnabled;
        //System Administration Function
        SecurityQuestions.Visible = isDefaultFirmSetupEmabled;
        LocationData.Visible = isDefaultFirmSetupEmabled;
        Entitlements.Visible = isDefaultFirmSetupEmabled;
        EmailSmsProvider.Visible = isDefaultFirmSetupEmabled;
        EmailSmsTemplates.Visible = isDefaultFirmSetupEmabled;
        EmailAndSMSMenu.Visible = EmailSmsProvider.Visible || EmailSmsTemplates.Visible;
        ManageJobs.Visible = isDefaultFirmSetupEmabled;
        ReportLetterTemplates.Visible = isDefaultFirmSetupEmabled;
        MasterControlData.Visible = isDefaultFirmSetupEmabled;
        //Set sidebar menu header
        setSidebarMenuText();
    }
    private void setSidebarMenuText()
    {
        divSiderbar.Visible = true;
        if (isCustomerFirmSetup())
        {
            lbSidebarMenuIcon.Text = Constants.ICON.CUSTOMER_FIRM_SETUP_FN_MENU;
            lbSidebarMenuText.Text = "Customer Firm Setup";
            lbSidebarMenuDesc.Text = "Manage Customer Firms";
        }
        else if (isDefaultFirmSetup())
        {
            lbSidebarMenuIcon.Text = Constants.ICON.DEFAULT_FIRM_SETUP_FN_MENU;
            lbSidebarMenuText.Text = "Default Firm";
            lbSidebarMenuDesc.Text = "Default Firm Setup";
        }
        else
        {
            divSiderbar.Visible = false;
        }
    }
    public void logoutUser(object sender, EventArgs e)
    {
        doLogout(Constants.URL.LOGIN);
    }
    public void doLogout(string urlToRedirect)
    {
        //bool IsLoggedInWithOtherSession = ApplicationUtil.IsUserLoggedInWithOtherSession(Session);
        ApplicationUtil.clearSession(Session, Application);
        //TODO - IsLoggedInWithOtherSession use to show warning message for user. This requires understanding of session time out.
        Response.Redirect(urlToRedirect, true);
    }
    public void initHeaderFirmGrid()
    {
        UserDefinitionDTO userDTO = getUserDefinitionDTO();
        firmSelectionGrid.DataSource = userDTO.AllFirms;
        firmSelectionGrid.DataBind();
        long defaultFirmId = 0;
        if (userDTO.AllFirms.Count > 0)
        {
            FirmDTO selectedFirm = userDTO.AllFirms.Find(c => c.isUISelected);
            if (selectedFirm == null)
            {
                selectedFirm = userDTO.AllFirms[0];
            }
            defaultFirmId = selectedFirm.Id;
        }

        selectHeaderFirm(defaultFirmId);
    }
    protected void onClickSelectNavbarFirm(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            selectHeaderFirm(selectedIndex);
            Response.Redirect(Constants.URL.CUSTOMER_FIRM_HOME, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
        }
    }
    private void selectHeaderFirm(long selectedIndex)
    {
        UserDefinitionDTO userDTO = getUserDefinitionDTO();
        userDTO.AllFirms.ForEach(x => x.isUISelected = false);
        foreach (FirmDTO firmDTO in userDTO.AllFirms)
        {
            if (firmDTO.Id == selectedIndex)
            {
                firmDTO.isUISelected = true;
                lbHeaderFirmName.Text = firmDTO.Name;
                lbHeaderMobileFirmName.Text = firmDTO.Name;
                break;
            }
        }
    }
    
}
