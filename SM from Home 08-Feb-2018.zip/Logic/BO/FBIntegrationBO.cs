﻿using System;
using NHibernate;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using ConstroSoft;
using System.Collections.Generic;
using System.Globalization;

/// <summary>
/// Summary description for FBIntegrationBO
/// </summary>
namespace ConstroSoft
{
    public class FBIntegrationBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public FBIntegrationBO()
        {

            // TODO: Add constructor logic here
            //
        }
        public void saveFBuser(PortalUserDTO portalUserDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PortalUser portalUser = DTOToDomainUtil.populatePortalUserAddFields(portalUserDTO);
                        portalUser.Password = Encrypt(portalUser.Password);
                        session.Save(portalUser);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Adding User:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public BusinessOutputTO validateFBUser(PortalUserDTO portalUserDTO)
        {
            BusinessOutputTO businessTO = new BusinessOutputTO();
            ISession session = null;
            log.Debug("Validating user login");
            try
            {
                bool result = false;
                session = NHibertnateSession.OpenSession();
                PortalUser portalUser = session.QueryOver<PortalUser>().Where(x => x.UserName == portalUserDTO.UserName).SingleOrDefault();
                if (portalUser != null)
                {
                    if (portalUserDTO.Password.Equals(Decrypt(portalUser.Password)))
                    {
                        log.Debug("Login Successful for user:" + portalUserDTO.UserName);
                        businessTO.result = getPortalUserDTO(portalUser);
                        result = true;
                    }
                }
                if (!result)
                {
                    log.Debug("Login Failed for user:" + portalUserDTO.UserName);
                    businessTO.setErrorMessage(Resources.Messages.LOGIN_ERROR_FAILED);
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while login:" + portalUserDTO.UserName);
                log.Error(exp.Message, exp);
                businessTO.setErrorMessage(Resources.Messages.system_error);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return businessTO;
        }
        public bool isUserExists(string userName)
        {
            ISession session = null;
            bool exist = false;
            try
            {
                session = NHibertnateSession.OpenSession();
                exist = session.QueryOver<PortalUser>().Where(user => user.UserName == userName).RowCount() > 0;
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while registering:" + userName);
                log.Error(exp.Message, exp);
                throw new Exception(Resources.Messages.system_error);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return exist;
        }

        public bool isFirmExists(string firmNumber)
        {
            ISession session = null;
            bool exist = false;
            try
            {
                session = NHibertnateSession.OpenSession();
                exist = session.QueryOver<Firm>().Where(x => x.FirmNumber == firmNumber).RowCount() > 0;
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while registering:" + firmNumber);
                log.Error(exp.Message, exp);
                throw new Exception(Resources.Messages.system_error);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return exist;
        }
        private PortalUserDTO getPortalUserDTO(PortalUser portalUser)
        {
            PortalUserDTO portalUserDTO = new PortalUserDTO();
            portalUserDTO.UserName = portalUser.UserName;
            portalUserDTO.Password = portalUser.Password;
            portalUserDTO.Email = portalUser.Email;
            portalUserDTO.FirmNumber = portalUser.FirmNumber;
            portalUserDTO.Id = portalUser.Id;
            return portalUserDTO;
        }
        private string Encrypt(string clearText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    clearText = Convert.ToBase64String(ms.ToArray());
                }
            }
            return clearText;
        }
        private string Decrypt(string cipherText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }

        public string saveFBToken(PortalUserDTO portalUserDTO)
        {
            ISession session = null;
            string token = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        token = GetUniqueKey(100);
                        PortalTokenManager portalTokenManager = populatePortalTokenManager(portalUserDTO, token);
                        session.Save(portalTokenManager);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while generating token:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return token;
        }

        public static string GetUniqueKey(int maxSize = 15)
        {
            char[] chars = new char[62];
            chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890".ToCharArray();
            byte[] data = new byte[1];
            using (RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider())
            {
                crypto.GetNonZeroBytes(data);
                data = new byte[maxSize];
                crypto.GetNonZeroBytes(data);
            }
            StringBuilder result = new StringBuilder(maxSize);
            foreach (byte b in data)
            {
                result.Append(chars[b % (chars.Length)]);
            }
            return result.ToString();
        }

        public static PortalTokenManager populatePortalTokenManager(PortalUserDTO portalUserDTO, string token)
        {
            PortalTokenManager portalTokenManager = new PortalTokenManager();
            portalTokenManager.TokenKey = token;
            portalTokenManager.IssuedOn = DateUtil.getUserLocalDateTime();
            portalTokenManager.ExpiresOn = DateUtil.getUserLocalDateTime().AddMinutes(25);
            portalTokenManager.FirmNumber = portalUserDTO.FirmNumber;
            portalTokenManager.PortalUser = new PortalUser();
            portalTokenManager.PortalUser.Id = portalUserDTO.Id;
            portalTokenManager.InsertDate = DateUtil.getUserLocalDateTime();
            portalTokenManager.InsertUser = portalUserDTO.UserName;
            portalTokenManager.UpdateDate = DateUtil.getUserLocalDateTime();
            portalTokenManager.UpdateUser = portalUserDTO.UserName;
            return portalTokenManager;
        }
        public bool validatePortalToken(string TokenKey)
        {
            ISession session = null;
            bool exist = false;
            try
            {
            	 session = NHibertnateSession.OpenSession();
                 using (ITransaction tx = session.BeginTransaction())
                 {
                     try
                     {
                    	 session = NHibertnateSession.OpenSession();
                         exist = session.QueryOver<PortalTokenManager>().Where(token => token.TokenKey == TokenKey && token.ExpiresOn > DateUtil.getUserLocalDateTime())
                             .RowCount() > 0;
                     }
                     catch (Exception e)
                     {
                    	 log.Error("Unexpected error while fetching token:" + TokenKey , e);
                         throw new Exception(Resources.Messages.system_error);
                     }
                 }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return exist;
        }
    }
}