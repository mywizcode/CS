﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    formatActivityActionMsg(controlToFormat);
    formatFields(controlToFormat);
    showModal(controlToFormat);
}