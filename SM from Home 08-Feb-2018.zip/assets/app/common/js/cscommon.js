//Common Icons used 
var ICON_ADD = "<i class=\"icon-googleplus5 position-left\"></i>";
var ICON_VIEW_DTL = "<i class=\"icon-grid position-left\"></i>";
var ICON_DELETE = "<i class=\"icon-bin position-left\"></i>";
var ICON_CONFIRM = "<i class=\"icon-question4 position-left\"></i>";
var CONFIRM = "CONFIRM";
var DELETE = "DELETE";
var SEP1 = "~~";
var SEP2 = "~";
//Modal should not close when clicked on backdrop(outside modal)
$.fn.modal.prototype.constructor.Constructor.DEFAULTS.backdrop = 'static';
jQuery.fn.exists = function () { return this.length > 0; }

function initDate(controlToFormat) {
    $(controlToFormat).find('div.date').each(function () {
        $this = $(this);
        var isReadOnly = $this.is('[readonly]');
        if (isReadOnly == false) {
            $this.datetimepicker({
                format: 'DD-MMM-YYYY'
            });
        }
    });
}
function initDateTime(controlToFormat) {
    $(controlToFormat).find('div.datetime').each(function () {
        $this = $(this);
        var isReadOnly = $this.is('[readonly]');
        var strFormat = $this.hasClass('datetime-short') ? "DD-MMM-YYYY, hh:mm A" : "dddd, DD-MMM-YYYY, hh:mm A";
        if (isReadOnly == false) {
            $this.datetimepicker({
                format: strFormat
            });
        }
    });
    $(controlToFormat).find('div.datetime-inline').each(function () {
        $this = $(this);
        var isReadOnly = $this.is('[readonly]');
        if (isReadOnly == false) {
            $this.datetimepicker({
                format: 'dddd, DD-MMM-YYYY, hh:mm A',
                inline: true
            });
        }
    });
}
/**
 * This method is called from Enquiry activity and Lead activity pages. It formats the 'action' type activity system comments.
 */
function formatActivityActionMsg(controlToFormat) {
    $(controlToFormat).find('div.timeline-date.action').find('span.activity-action-comment').each(function(){
		var $this = $(this);
		var formattedMsg = getFormattedNotificationMsg($this.html());
		$this.html(formattedMsg);
	});
}

function replaceDefaultImageIfNotLoaded(controlToFormat) {
    $(controlToFormat).find('img.onerror-default').load(function () {
	    
	}).error(function () {
	    $(this).attr('src', '../../assets/app/images/default_img.jpg');
	});
}

function initFabMenu() {
    var $fabMenu = $("[id$='fabMenuRight']");
    if ($fabMenu.length) {
        $fabMenu.affix({
            offset: {
                top: $fabMenu.offset().top - 20
            }
        });
    }
}

function initDropdown(controlToFormat) {
	$(controlToFormat).find('.csdrp').select2({
        containerCssClass: 'select-sm',
        minimumResultsForSearch: Infinity
    });
    $(controlToFormat).find('.csdrplive').select2({
        containerCssClass: 'select-sm'
    });
    $(controlToFormat).find('div.bootstrap-select').addClass("dropdown-100-percent");
    $(controlToFormat).find('div.bootstrap-select > button').addClass("btn-sm border-gray");
    $(controlToFormat).find('div.bs-searchbox > input').addClass("input-sm");
}
function selectRow(controlToFormat) {
    $(controlToFormat).find('.cs-select-row').on('change', function () {
        var parentClass = $(this).attr('data-parent');
        if ($(this).is(':checked')) {
            $(this).parents('.'+parentClass).addClass('warning');
        }
        else {
            $(this).parents('.' + parentClass).removeClass('warning');
        }
    });
}

//Block UI -> This method blocks panel when any element (having class 'block-ui-click') is clicked.
function bindBlockUI(controlToFormat) {
    var blockUiContent = $("<div class=\"blockui-animation-container\"><span class=\"text-semibold\"><i class=\"icon-spinner10 spinner position-left\"></i>&nbsp; Please Wait...</span></div>");
    $(controlToFormat).find('.block-ui-click').on('click', function () {
        var block = $('.' + $(this).attr('data-panel'));
        $(block).block({
            message: blockUiContent,
            overlayCSS: {
                backgroundColor: '#fff',
                opacity: 0.8,
                cursor: 'wait'
            },
            css: {
                border: 0,
                padding: '10px 15px',
                color: '#fff',
                width: 'auto',
                '-webkit-border-radius': 2,
                '-moz-border-radius': 2,
                backgroundColor: 'transparent'
            }
        });
        blockUiContent.addClass("animated fadeInDown").one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function () {
            $(this).removeClass("animated fadeInDown");
        });
    });
    $(controlToFormat).find('.block-ui-change').on('change', function () {
        var block = $('.' + $(this).attr('data-panel'));
        $(block).block({
            message: blockUiContent,
            overlayCSS: {
                backgroundColor: '#fff',
                opacity: 0.8,
                cursor: 'wait'
            },
            css: {
                border: 0,
                padding: '10px 15px',
                color: '#fff',
                width: 'auto',
                '-webkit-border-radius': 2,
                '-moz-border-radius': 2,
                backgroundColor: 'transparent'
            }
        });
        blockUiContent.addClass("animated fadeInDown").one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function () {
            $(this).removeClass("animated fadeInDown");
        });
    });
    /*
    * Bind block UI to radio buttons. They need to handle separatelly. 
    * In order to block UI -> append block UI panel class to name attribute starting to '_'
    */
    $(controlToFormat).find('input:radio').each(function () {
        var $this = $(this);
        var groupName = $this.attr('name');
        if (groupName.indexOf('_') > 0) {
            $this.on('change', function () {
                var block = $('.' + groupName.substr(groupName.indexOf('_') + 1));
                $(block).block({
                    message: blockUiContent,
                    overlayCSS: {
                        backgroundColor: '#fff',
                        opacity: 0.8,
                        cursor: 'wait'
                    },
                    css: {
                        border: 0,
                        padding: '10px 15px',
                        color: '#fff',
                        width: 'auto',
                        '-webkit-border-radius': 2,
                        '-moz-border-radius': 2,
                        backgroundColor: 'transparent'
                    }
                });
                blockUiContent.addClass("animated fadeInDown").one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function () {
                    $(this).removeClass("animated fadeInDown");
                });
            });
        }
    });
}
function initNotyMsg() {
    var msgValue = $("[id$='btnNotyMsg']").val();
    if (msgValue && msgValue != "") {
        var arrMsgValue = msgValue.split(SEP1);
        var isKiller = true; //If true then kills previous messages.
        var errorMsgs = "";
        $.each(arrMsgValue, function (index, value) {
            var recs = value.split(SEP2);
            if (recs[0] == "error") errorMsgs = (errorMsgs == "") ? recs[1] : errorMsgs + SEP2 + recs[1];
            else {
                noty({
                    width: 200,
                    text: recs[1],
                    type: recs[0],
                    dismissQueue: true,
                    timeout: 6000,
                    layout: 'top',
                    killer: isKiller
                });
                isKiller = false;
            }
        });
        if (errorMsgs != "") {
            var tmpMsgs = errorMsgs.split(SEP2);
            var firstMsg = (tmpMsgs.length > 1) ? "Multiple errors has occurred, please click error icon to see all errors." : tmpMsgs[0];
            noty({
                width: 200,
                text: firstMsg,
                type: "error",
                dismissQueue: true,
                timeout: 6000,
                layout: 'top',
                killer: isKiller
            });
            if (tmpMsgs.length > 1) {
                var popoverContent = '<ul class="list list-inline cs-error-list text-danger">';
                $.each(tmpMsgs, function (index, value) {
                    popoverContent = popoverContent + '<li>' + value + '</li>';
                });
                popoverContent = popoverContent + '</ul>';
                var errorIndicator = '<span class="pull-right noty-error-extra" data-popup="popover-custom"><i class="fa fa-exclamation-triangle faa-flash animated text-danger"></i>'
		                            + '<span class="badge bg-warning-400">' + tmpMsgs.length + '</span></span>';
                $('div.page-title h6').html($('div.page-title h6').html() + errorIndicator);

                $('div.page-title h6').find('[data-popup=popover-custom]').popover({
                    template: '<div class="popover border-slate-400"><div class="arrow"></div><h3 class="popover-title bg-slate-400"></h3><div class="popover-content">'
                        + '</div></div>',
                    title: '<i class="icon-warning22 position-left"></i>Errors',
                    placement: 'left',
                    html: true,
                    content: popoverContent
                });
            }
        }
    }
    $("[id$='NotyMsg']").val('');
}

function setNotyErrorMsgs(errorMsgs) {

}

function initNotifications(controlToFormat) {
    if (controlToFormat == "ul.ulNotification" || controlToFormat == "body") {
        //Add notification bell animation
        $("#notificationLink").find('i.fa-bell').removeClass('faa-ring faa-slow animated');
        var $notificationCount = $("[id$='spNotificationAlertBadge']");
        if ($notificationCount.exists()) $("#notificationLink").find('i.fa-bell').addClass('faa-ring faa-slow animated');
        //Format Notification Messages
        $("ul.ulNotification").find('li.alert-notification,li.task-notification').each(function () {
            var $this = $(this);
            var unformattedMsg = $(this).find('div.message').html();
            //Format notification message.
            $this.find('div.message').html(getFormattedNotificationMsg(unformattedMsg));
        });
        //Show Call Intimation
        var callPresent = $("[id$='btnCallIntimationPresentHdn']").val();
        if(callPresent != 'undefined' && callPresent == "Y") {
        	showCallIntimation();
        }
    }
}
function getFormattedNotificationMsg(unformattedMsg) {
	var tmpMsg = "";
	if (unformattedMsg != 'undefined' && unformattedMsg != "") {
        var arrMsgValue = unformattedMsg.split(SEP1);
        tmpMsg = arrMsgValue[0];
        if (arrMsgValue.length > 1 && arrMsgValue[1] != "") {
            var params = arrMsgValue[1].split(SEP2);
            $.each(params, function (i, n) {
                tmpMsg = tmpMsg.replace(new RegExp("\\{" + i + "\\}", "g"), getNotificationMsgPlaceHolder(n));
            });
        }
    }
	return tmpMsg;
}
function getNotificationMsgPlaceHolder(param) {
    if (param.startsWith("LINK:")) {
        return "<a href=\"javascript:void(0)\" onclick=\"clickNotificationAlert(this);\">"+param.replace("LINK:", "")+"</a>"
    } else if (param.startsWith("BOLD:")) {
        return "<span class=\"text-semibold\">" + param.replace("BOLD:", "") + "</span>"
    }
    return "";
}
function clickNotificationAlert(element) {
    $(element).closest('div.media-body').find('.notificationAction').click();
}
var callNotice;
function showCallIntimation() {
    var $btn = $("[id$='btnCallIntimationNotificationAction']");
    if (callNotice) callNotice.remove();
    callNotice = new PNotify({
        title: 'Incoming Call',
        text: $btn.attr('data-message'),
		addclass: 'alert alert-styled-left alert-styled-custom alert-arrow-left alpha-teal text-teal-800',
		hide: false,
		animate: {
		    animate: true,
		    in_class: 'slideInLeft',
		    out_class: 'slideOutRight'
		},
        confirm: {
            confirm: true,
            buttons: [
                {
                    text: 'Answered?',
                    addClass: 'btn btn-sm bg-blue',
                    click: function(notice) {
                    	notice.remove();
                    	$btn.click();
                    }
                },
				{
                    text: 'Cancel',
                    addClass: 'hidden'
                }
            ]
        },
        buttons: {
            closer: true,
            sticker: false
        },
        history: {
            history: false
        }
    });
}
function copyFileName(element) {
	var $this = $(element);
	var index = $this.val().lastIndexOf('.');
	var fileName = (index > 0) ? $this.val().substr(0, index) : $this.val//Remove extension
	fileName = (fileName.lastIndexOf('\\') > 0) ? fileName.substr(fileName.lastIndexOf('\\') + 1) : fileName;//Remove fakepath.
	$("[id$='" + $this.attr('data-filename-field') + "']").val(fileName);
}
function ValidateNumberOnly(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 46 || charCode > 57)) {
        event.returnValue = false;
    }
}