﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;


public partial class SecurityValidation : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                ResetPasswordNavDTO navDto = ApplicationUtil.getPageNavDTO<ResetPasswordNavDTO>(Session);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSLoginMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    private void renderPageFieldsWithEntitlement()
    {

    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
    }
    private void doInit(ResetPasswordNavDTO navDto)
    {
        if (navDto == null || navDto.Step != ResetPasswordStep.SECURITY_VALIDATION)
        {
            ApplicationUtil.clearSession(Session, Application);
            Response.Redirect(Constants.URL.LOGIN, false);
        }
        else
        {
            lbSecurityQuestion.Text = getUserDefinitionDTO().SecurityQuestion.Question;
        }
    }
    protected void submitSecurityQuestions(object sender, EventArgs e)
    {
        try
        {
            bool isValid = true;
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (string.IsNullOrWhiteSpace(txtSecurityAnswer.Text) || string.IsNullOrWhiteSpace(txtDOB.Text))
            {
                (this.Master as CSLoginMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("All fields are mandatory."));
                isValid = false;
            }
            else
            {
                DateTime dob = DateUtil.getCSDateNotNull(txtDOB.Text);
                if (!(txtSecurityAnswer.Text.Equals(userDefDto.SecurityAnswer) && dob.CompareTo(userDefDto.FirmMember.ContactInfo.Dob) == 0))
                {
                    (this.Master as CSLoginMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Incorrect Security Answer or Date of Birth"));
                    isValid = false;
                }
            }
            
            if (isValid)
            {
                ResetPasswordNavDTO navDTO = new ResetPasswordNavDTO();
                navDTO.Step = ResetPasswordStep.RESET_PASSWORD;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.FP_RESET_PASSWORD, false);
            }
        }
        catch (Exception ex)
        {
            log.Error("Unexpected error:", ex);
            (this.Master as CSLoginMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(Resources.Messages.system_error));
        }
    }
}