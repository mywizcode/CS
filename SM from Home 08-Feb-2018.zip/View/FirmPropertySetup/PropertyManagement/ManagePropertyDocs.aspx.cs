﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.BO;

public partial class ManagePropertyDocs : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addFolderModalError = "addFolderModalError";
    string uploadDocumentModalError = "uploadDocumentModalError";
    string addFolderModal = "addFolderModal";
    string uploadDocumentModal = "uploadDocumentModal";
    DropdownBO drpBO = new DropdownBO();
    DocumentBO documentBO = new DocumentBO();
    PropertyBO propertyBO = new PropertyBO();

    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Form.Attributes.Add("enctype", "multipart/form-data");
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                ManagePropertyDocsNavDTO navDto = ApplicationUtil.getPageNavDTO<ManagePropertyDocsNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MANAGE_PROPERTY_DOCUMENTS)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
    	renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
    	ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }

    public void setErrorMessage(string message, string group)
    {
    	string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        } else CommonUtil.getCustomValidator(Page, message, group);
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private void doInit(ManagePropertyDocsNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(ManagePropertyDocsNavDTO navDto)
    {
        try
        {
            ManagePropertyDocsPageDTO PageDTO = new ManagePropertyDocsPageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            PropertyDTO propertyDTO = propertyBO.fetchPropertySelective(navDto.PropertyId);
            PageDTO.PropertyDTO = propertyDTO;
            PageDTO.PropertyHomePath = CommonUtil.appendNameToPath(Constants.DOCUMENT_MANAGEMENT.PROPERTY_DOC_PATH, propertyDTO.Name.Trim());
            populatePropertyFields(propertyDTO);
            createDocumentHomeIfNotExist(PageDTO);
            loadAllFilesInPath(PageDTO.PropertyHomePath);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void navigateToPreviousPage()
    {
        Response.Redirect(Constants.URL.PROPERTY_SEARCH, true);
    }
    private void renderPageFieldsWithEntitlement()
    {
    	UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        lnkAddFolder.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_DOC_CREATE_FOLDER);
        lnkUploadFile.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_DOC_UPLOAD_DOCUMENT);
        if (folderContentGrid.Rows.Count > 0)
        {
            for (var i = 0; i < folderContentGrid.Rows.Count; i++)
            {
                HtmlGenericControl tmpBtn = (HtmlGenericControl)folderContentGrid.Rows[i].FindControl("liDeleteFileBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_DOC_DELETE_DOCUMENT);
            }
        }
    }
    private ManagePropertyDocsPageDTO getSessionPageData()
    {
        return (ManagePropertyDocsPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private FileUIDTO getSelectedFileOrFolder(long UiIndex)
    {
        return getSessionPageData().FileList.Find(x => x.UiIndex == UiIndex);
    }
    private FilePathBreadCrumbDTO getSelectedPathFolder(long UiIndex)
    {
        return getSessionPageData().PathList.Find(x => x.UiIndex == UiIndex);
    }
    private void populatePropertyFields(PropertyDTO propertyDTO)
    {
    	lbPropertyName.Text = propertyDTO.Name;
        lbPropertyType.Text = propertyDTO.PropertyType.Name;
        lbPropertyLocation.Text = propertyDTO.PropertyLocation.Name;
        lbReraRegNo.Text = propertyDTO.ReraRegNo;
    }
    private void createDocumentHomeIfNotExist(ManagePropertyDocsPageDTO PageDTO)
    {
        documentBO.createFolderIfNotExist(PageDTO.PropertyHomePath);
    }
    private void loadAllFilesInPath(string srcPath)
    {
        ManagePropertyDocsPageDTO PageDTO = getSessionPageData();
        PageDTO.FileList = fetchAllFiles(srcPath);
        PageDTO.CurrentAbsPath = srcPath;
        populateFolderContentGrid(PageDTO.FileList);
        buildDirectoryPath(srcPath, PageDTO);
    }
    private List<FileUIDTO> fetchAllFiles(string srcPath)
    {
        List<FileUIDTO> fileList = new List<FileUIDTO>();
        fileList.AddRange(documentBO.fetchFileList(srcPath));
        return fileList;
    }
    private void buildDirectoryPath(string srcPath, ManagePropertyDocsPageDTO PageDTO)
    {
        List<FilePathBreadCrumbDTO> pathList = new List<FilePathBreadCrumbDTO>();
        pathList.Add(getFilePathDTO(Constants.DOCUMENT_MANAGEMENT.HOME, PageDTO.PropertyHomePath));
        string absPath = PageDTO.PropertyHomePath;
        string tmpSrcPath = formatForBreadCrumb(srcPath, PageDTO);
        string[] arrPath = tmpSrcPath.Split('\\');

        if (arrPath != null)
        {
            foreach (string tmpStr in arrPath)
            {
                if (!string.IsNullOrWhiteSpace(tmpStr))
                {
                    absPath = CommonUtil.appendNameToPath(absPath, tmpStr);
                    pathList.Add(getFilePathDTO(tmpStr, absPath));
                }
            }
        }
        pathList[pathList.Count - 1].isUISelected = true;
        PageDTO.PathList = (pathList != null) ? (List<FilePathBreadCrumbDTO>)pathList : new List<FilePathBreadCrumbDTO>();
        populateFilePathGrid(pathList);
    }
    private string formatForBreadCrumb(string srcPath, ManagePropertyDocsPageDTO PageDTO)
    {
        string result = srcPath;
        result = result.Replace(PageDTO.PropertyHomePath, "");
        return result;
    }
    private FilePathBreadCrumbDTO getFilePathDTO(string name, string fullPath)
    {
        FilePathBreadCrumbDTO tmpDTO = new FilePathBreadCrumbDTO();
        tmpDTO.Name = name;
        tmpDTO.FullPath = fullPath;
        return tmpDTO;
    }
    private void populateFolderContentGrid(List<FileUIDTO> fileList)
    {
        folderContentGrid.DataSource = new List<FileUIDTO>();
        if (fileList != null)
        {
            assignUiIndexToFolderContent(fileList);
            folderContentGrid.DataSource = fileList;
        }
        folderContentGrid.DataBind();
    }
    private void assignUiIndexToFolderContent(List<FileUIDTO> fileList)
    {
        if (fileList != null && fileList.Count > 0)
        {
            long uiIndex = 1;
            foreach (FileUIDTO tmpDTO in fileList)
            {
                tmpDTO.UiIndex = uiIndex++;
            }
        }
    }
    private void populateFilePathGrid(List<FilePathBreadCrumbDTO> pathList)
    {
        FilePathBreadCrumb.DataSource = new List<FilePathBreadCrumbDTO>();
        if (pathList != null)
        {
            assignUiIndexToFilePath(pathList);
            FilePathBreadCrumb.DataSource = pathList;
        }
        FilePathBreadCrumb.DataBind();
    }
    private void assignUiIndexToFilePath(List<FilePathBreadCrumbDTO> pathList)
    {
        if (pathList != null && pathList.Count > 0)
        {
            long uiIndex = 1;
            foreach (FilePathBreadCrumbDTO tmpDTO in pathList)
            {
                tmpDTO.UiIndex = uiIndex++;
            }
        }
    }
    private ManagePropertyDocsNavDTO navigateToCurrentPage()
    {
        ManagePropertyDocsNavDTO navDTO = new ManagePropertyDocsNavDTO();
        navDTO.PropertyId = getSessionPageData().PropertyDTO.Id;
        Session[Constants.Session.NAV_DTO] = navDTO;
        Response.Redirect(Constants.URL.PROPERTY_MANAGE_DOCUMENTS, true);
        return navDTO;
    }
    protected void onClickPathFolder(object sender, EventArgs e)
    {
        try
        {
            txtFileSearch.Text = null;
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            FilePathBreadCrumbDTO pathDTO = getSelectedPathFolder(selectedId);
            loadAllFilesInPath(pathDTO.FullPath);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void searchFileInDirectory(object sender, EventArgs e)
    {
        try
        {
            ManagePropertyDocsPageDTO PageDTO = getSessionPageData();
            if (!string.IsNullOrWhiteSpace(txtFileSearch.Text))
            {
                string searchText = txtFileSearch.Text.Trim();
                PageDTO.FileList = documentBO.searchFileInDirectory(PageDTO.CurrentAbsPath, searchText);
                foreach (FileUIDTO fileUIDTO in PageDTO.FileList)
                {
                    fileUIDTO.AdditionalInfo = fileUIDTO.ParentPath.Replace(PageDTO.CurrentAbsPath, CommonUtil.getDirectoryPath(PageDTO.PathList));
                }
                populateFolderContentGrid(PageDTO.FileList);
            }
            else
            {
                loadAllFilesInPath(PageDTO.CurrentAbsPath);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickAddFolder(object sender, EventArgs e)
    {
        try
        {
            txtFolderName.Text = null;
            activeModalHdn.Value = addFolderModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickUploadFile(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = uploadDocumentModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickFolder(object sender, EventArgs e)
    {
        try
        {
            txtFileSearch.Text = null;
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            FileUIDTO fileDTO = getSelectedFileOrFolder(selectedId);
            loadAllFilesInPath(fileDTO.FullPath);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void documentRowCreated(Object sender, GridViewRowEventArgs e)
    {
        LinkButton lnkDownloadBtn = (LinkButton)e.Row.FindControl("lnkDownloadBtn");
        if (lnkDownloadBtn != null)
        {
            ScriptManager mgr = ScriptManager.GetCurrent(this.Page);
            mgr.RegisterPostBackControl(lnkDownloadBtn);
        }
    }
    protected void onClickDownloadBtn(object sender, EventArgs e)
    {
        try
        {
            ManagePropertyDocsPageDTO PageDTO = getSessionPageData();
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            FileUIDTO fileDTO = getSelectedFileOrFolder(selectedId);
            byte[] fileContent = documentBO.downloadFile(fileDTO.FullPath);
            Response.Buffer = true;
            Response.Charset = "";
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + fileDTO.Name);
            Response.BinaryWrite(fileContent);
            Response.Flush();
            UpdatePanel1.Update();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickDeleteFileBtn(object sender, EventArgs e)
    {
        try
        {
            ManagePropertyDocsPageDTO PageDTO = getSessionPageData();
            long UiIndex = getDeleteRecordHdnId();
            FileUIDTO fileDTO = getSelectedFileOrFolder(UiIndex);
            if (validateFolderDelete(fileDTO))
            {
                documentBO.deleteFile(fileDTO);
                string msg = (fileDTO.FileType == FileType.Folder) ? "Folder is deleted successfully." : "Document is deleted successfully.";
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(msg));
                loadAllFilesInPath(PageDTO.CurrentAbsPath);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateFolderDelete(FileUIDTO fileDTO)
    {
        bool isValidToDelete = true;
        if (CommonUtil.isSystemManagedFolder(fileDTO.Name))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(string.Format("{0} folder is system managed folder, it is not allowed to delete.", fileDTO.Name)));
            isValidToDelete = false;
        }
        else if (fileDTO.FileType == FileType.Folder && documentBO.isDocumentExistInFolder(fileDTO.FullPath))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Folder cannot be deleted, Document is present inside folder."));
            isValidToDelete = false;
        }
        return isValidToDelete;
    }
    //Add new Folder Modal- start
    protected void AddNewFolder(object sender, EventArgs e)
    {
        try
        {
            if (validateAddFolder())
            {
                ManagePropertyDocsPageDTO PageDTO = getSessionPageData();
                string folderName = txtFolderName.Text.Trim();
                documentBO.createFolderIfNotExist(CommonUtil.appendNameToPath(PageDTO.CurrentAbsPath, folderName));
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("Folder is added successfully."));
                loadAllFilesInPath(PageDTO.CurrentAbsPath);
            }
            else
            {
                activeModalHdn.Value = addFolderModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelAddFolderModal(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateAddFolder()
    {
        Page.Validate(addFolderModalError);
        bool isValid = Page.IsValid;
        if (isValid)
        {
            string folderName = txtFolderName.Text.Trim();
            List<FileUIDTO> fileList = getSessionPageData().FileList;
            if (fileList.Find(x => x.Name == folderName && x.FileType == FileType.Folder) != null)
            {
                setErrorMessage("Folder with same name already exist.", addFolderModalError);
                isValid = false;
            }
        }
        return isValid;
    }
    //Add new Folder Modal - end
    //Upload Document Modal- start
    protected void UploadDocument(object sender, EventArgs e)
    {
        try
        {
            HttpFileCollection uploadedFiles = Request.Files;
            ManagePropertyDocsPageDTO PageDTO = getSessionPageData();
            if (uploadedFiles != null && uploadedFiles.Count > 0)
            {
                for (int i = 0; i < uploadedFiles.Count; i++)
                {
                    HttpPostedFile userPostedFile = uploadedFiles[i];
                    if (userPostedFile.ContentLength > 0)
                    {
                    	string filename = CommonUtil.getFileNameWithoutExtension(txtFileName.Text, Path.GetFileName(userPostedFile.FileName), Path.GetExtension(userPostedFile.FileName));
                        HttpPostedFile file = fileUpload.PostedFile;
                        if (validateUploadDocument(userPostedFile))
                        {
                            documentBO.saveDocument(userPostedFile, CommonUtil.appendNameToPath(PageDTO.CurrentAbsPath, filename));
                            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("Document is uploaded successfully."));
                            loadAllFilesInPath(PageDTO.CurrentAbsPath);
                        }
                    }
                    else
                    {
                        setErrorMessage("Please Select file to upload.", uploadDocumentModalError);
                        activeModalHdn.Value = uploadDocumentModal;
                    }
                }
            }
            else
            {
                setErrorMessage("Please Select file to upload.", uploadDocumentModalError);
                activeModalHdn.Value = uploadDocumentModal;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    protected void cancelUploadDocumentModal(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateUploadDocument(HttpPostedFile userPostedFile)
    {
        bool isValid = true;
        //TODO - Do we need file size limit
        return isValid;
    }
    //Upload Document Modal - end
}