﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initUserEnquiryHistorySearchGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initUserEnquiryHistorySearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        pageLength: 10,
        hideSearch: true
    };

    $("[id$='userEnquiryHistorySearchGrid']").CSBasicDatatable(dtOptions);
}




