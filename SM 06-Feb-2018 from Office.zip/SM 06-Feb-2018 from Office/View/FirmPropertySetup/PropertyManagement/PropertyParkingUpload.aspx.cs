﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.BO;
using ConstroSoft.Logic.Util;
using OfficeOpenXml;

public partial class PropertyParkingUpload : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    DropdownBO drpBO = new DropdownBO();
    PropertyBO propertyBO = new PropertyBO();
    protected void Page_Load(object sender, EventArgs e)
    {
    	if (ApplicationUtil.isSubPageRendered(Page)) clearMessages();
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                PropertyParkingUploadNavDTO navDto = ApplicationUtil.getPageNavDTO<PropertyParkingUploadNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.PROPERTY_PARKING_ADD)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
    	ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void renderPageFieldsWithEntitlement()
    {

    }
    private void doInit(PropertyParkingUploadNavDTO navDto)
    {
        initDropdowns();
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(PropertyParkingUploadNavDTO navDto)
    {
        if (navDto != null)
        {
            PropertyParkingUploadPageDTO PageDTO = new PropertyParkingUploadPageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            //Reset page details
            txtUploadParkingProperty.Text = CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()).Name;
            pnlUploadParkingDetail.Visible = false;
            PageDTO.UploadFailedResult = new List<PropertyParkingDTO>();
            PageDTO.UploadSuccessResult = new List<PropertyParkingDTO>();
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void navigateToPreviousPage()
    {
        PropertyParkingUploadPageDTO PageDTO = getSessionPageData();
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is PropertyParkingSearchNavDTO)
            {
                PropertyParkingSearchNavDTO navDTO = (PropertyParkingSearchNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.PROPERTY_PARKING_SEARCH, true);
            }
        }
        Response.Redirect(Constants.URL.PROPERTY_UNIT_SEARCH, true);
    }
    private PropertyParkingUploadPageDTO getSessionPageData()
    {
        return (PropertyParkingUploadPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<PropertyParkingDTO> getUploadFailedList()
    {
        return getSessionPageData().UploadFailedResult;
    }
    private List<PropertyParkingDTO> getUploadSuccessList()
    {
        return getSessionPageData().UploadSuccessResult;
    }
    private bool isUploadSubmitToEnabled()
    {
        return getUploadSuccessList().Count > 0 && Constants.UPLOAD_VALIDATED.Equals(lbSuccessUploadParkingsText.Text);
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelPropertyParking(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    public void validatePropertyParkings(object sender, EventArgs e)
    {
        try
        {
            pnlUploadParkingDetail.Visible = false;
            HttpFileCollection uploadedFiles = Request.Files;
            List<PropertyParkingDTO> validationFailedList = new List<PropertyParkingDTO>();
            List<PropertyParkingDTO> validationSuccessList = new List<PropertyParkingDTO>();
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            DropDownList drpParkingType = new DropDownList();
            DropDownList drpTower = new DropDownList();
            drpBO.drpDataBase(drpParkingType, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.PR_PARKING_TYPE.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpTower, DrpDataType.PROPERTY_TOWER, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(), null, userDefDto.FirmNumber);
            for (int i = 0; i < uploadedFiles.Count; i++)
            {
                HttpPostedFile userPostedFile = uploadedFiles[i];
                if (userPostedFile.ContentLength > 0)
                {
                    string filename = Path.GetFileName(userPostedFile.FileName);
                    string extension = Path.GetExtension(filename);
                    HttpPostedFile file = fileUploadParkings.PostedFile;
                    if (validateFileType(extension))
                    {
                        using (file.InputStream)
                        {
                            ExcelPackage excel = new ExcelPackage(file.InputStream);
                            var workSheet = excel.Workbook.Worksheets[1];
                            IEnumerable<PropertyParkingMapperDTO> newcollection = workSheet.ConvertSheetToObjects<PropertyParkingMapperDTO>();
                            foreach (PropertyParkingMapperDTO propertyParkingMapperDTO in newcollection)
                            {
                                if (!string.IsNullOrWhiteSpace(propertyParkingMapperDTO.PropertyName))
                                {
                                    PropertyParkingDTO propertyParkingDTO = populatePropertyParkingDTO(validationSuccessList, propertyParkingMapperDTO,
                                        drpParkingType, drpTower);
                                    if (propertyParkingDTO.isError)
                                    {
                                        validationFailedList.Add(propertyParkingDTO);
                                    }
                                    else
                                    {
                                        validationSuccessList.Add(propertyParkingDTO);
                                    }
                                }
                            }
                        }
                        pnlUploadParkingDetail.Visible = true;
                        getSessionPageData().UploadFailedResult = validationFailedList;
                        getSessionPageData().UploadSuccessResult = validationSuccessList;

                        lbTotalUploadParkingsCount.Text = (validationFailedList.Count + validationSuccessList.Count) + "";
                        lbSuccessUploadParkingsCount.Text = validationSuccessList.Count + "";
                        lbSuccessUploadParkingsText.Text = Constants.UPLOAD_VALIDATED;
                        lbFailedUploadParkingsCount.Text = validationFailedList.Count + "";
                        btnUploadParkingSubmit.Visible = isUploadSubmitToEnabled();
                        populateParkingUploadGrid(validationSuccessList, "SUCCESS");
                    }
                }
                else
                {
                    setErrorMessage("Please Select valid file to upload.", commonError);
                }
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    public void showUploadParkings(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            string mode = rd.Attributes["data-show"];
            btnUploadParkingSubmit.Visible = false;
            if ("ALL".Equals(mode))
            {
                List<PropertyParkingDTO> allParkings = new List<PropertyParkingDTO>();
                allParkings.AddRange(getUploadFailedList());
                allParkings.AddRange(getUploadSuccessList());
                btnUploadParkingSubmit.Visible = isUploadSubmitToEnabled();
                populateParkingUploadGrid(allParkings, mode);
            }
            else if ("SUCCESS".Equals(mode))
            {
                btnUploadParkingSubmit.Visible = isUploadSubmitToEnabled();
                populateParkingUploadGrid(getUploadSuccessList(), mode);
            }
            else if ("ERROR".Equals(mode))
            {
                populateParkingUploadGrid(getUploadFailedList(), mode);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    public void addPropertyParkings(object sender, EventArgs e)
    {
        try
        {
            List<PropertyParkingDTO> uploadList = getUploadSuccessList();
            if (uploadList != null && uploadList.Count > 0)
            {
                List<PropertyParkingDTO> successList = new List<PropertyParkingDTO>();
                List<PropertyParkingDTO> failureList = new List<PropertyParkingDTO>();
                foreach (PropertyParkingDTO propertyParkingDTO in uploadList)
                {
                    if (!propertyParkingDTO.isError)
                    {
                        try
                        {
                            propertyBO.savePropertyParkingDetails(propertyParkingDTO);
                            successList.Add(propertyParkingDTO);
                        }
                        catch (Exception exp)
                        {
                            propertyParkingDTO.isError = true;
                            propertyParkingDTO.ErrorMessage = "Failed to upload, Please contact support for more details. ";
                            failureList.Add(propertyParkingDTO);
                        }
                    }
                }
                btnUploadParkingSubmit.Visible = false;
                string msg = (uploadList.Count == successList.Count) ? "Upload process is completed. All Property Parkings are uploaded successfully." :
                    "Upload process is completed. Some of the Property Parkings are not uploaded, Please check Failure records.";
                setSuccessMessage(msg);

                failureList.AddRange(getUploadFailedList());
                getSessionPageData().UploadFailedResult = failureList;
                getSessionPageData().UploadSuccessResult = successList;
                populateParkingUploadGrid(successList, "SUCCESS");

                lbSuccessUploadParkingsCount.Text = successList.Count + "";
                lbSuccessUploadParkingsText.Text = Constants.UPLOAD_SUCCESS;
                lbFailedUploadParkingsCount.Text = failureList.Count + "";
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    private void populateParkingUploadGrid(IList<PropertyParkingDTO> results, string mode)
    {
        parkingUploadGrid.Columns[6].Visible = "ALL".Equals(mode) && Constants.UPLOAD_SUCCESS.Equals(lbSuccessUploadParkingsText.Text);
        parkingUploadGrid.Columns[7].Visible = !"SUCCESS".Equals(mode);
        assignUiIndexToTaxDetail(results);
        parkingUploadGrid.DataSource = results;
        parkingUploadGrid.DataBind();
    }

    private void assignUiIndexToTaxDetail(IList<PropertyParkingDTO> results)
    {
        if (results != null && results.Count > 0)
        {
            long uiIndex = 1;
            foreach (PropertyParkingDTO parkingDto in results)
            {
                parkingDto.UiIndex = uiIndex++;
                parkingDto.RowInfo = CommonUIConverter.getGridViewRowInfo(parkingDto);
            }
        }
    }
    public PropertyParkingDTO populatePropertyParkingDTO(List<PropertyParkingDTO> parkingList, PropertyParkingMapperDTO propertyParkingMapperDTO,
        DropDownList drpParkingType, DropDownList drpTower)
    {
        PropertyParkingDTO propertyParkingDTO = new PropertyParkingDTO();
        StringBuilder sb = new StringBuilder();
        try
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            if (!propertyParkingMapperDTO.PropertyName.Equals(txtUploadParkingProperty.Text))
            {
                sb.Append("Unit Belongs to different Property.");
            }
            if (propertyParkingMapperDTO.ParkingNumber == null)
            {
                sb.Append("Parking Number Missing. ");
            }
            else
            {
                propertyParkingDTO.ParkingNo = propertyParkingMapperDTO.ParkingNumber;
            }
            if (propertyParkingMapperDTO.ParkingType == null)
            {
                sb.Append("Parking Type Missing. ");
            }
            else
            {
                foreach (ListItem li in drpParkingType.Items)
                {
                    if (li.Text.Equals(propertyParkingMapperDTO.ParkingType))
                    {
                        propertyParkingDTO.ParkingType = CommonUIConverter.getMasterControlDTO(li.Value, propertyParkingMapperDTO.ParkingType);
                    }
                }
            }
            if (propertyParkingMapperDTO.ParkingArea == null)
            {
                sb.Append("Parking Area Missing. ");
            }
            else
            {
                propertyParkingDTO.Area = CommonUtil.getDecimalWithoutExt(propertyParkingMapperDTO.ParkingArea);
            }

            if (propertyParkingMapperDTO.Status == null)
            {
                sb.Append("Status Missing. ");
            }
            else
            {
                propertyParkingDTO.Status = EnumHelper.ToEnum<ParkingStatus>(propertyParkingMapperDTO.Status);
            }
            if (propertyParkingMapperDTO.CommonParking == null)
            {
                sb.Append("Common Parking Missing. ");
            }
            else
            {
                propertyParkingDTO.CommonParking = EnumHelper.ToEnum<CommonParking>(propertyParkingMapperDTO.CommonParking);

            }
            propertyParkingDTO.FirmNumber = userDefDto.FirmNumber;
            propertyParkingDTO.Version = userDefDto.Version;
            propertyParkingDTO.UpdateUser = userDefDto.Username;
            if (propertyParkingMapperDTO.TowerName == null)
            {
                sb.Append("Tower Name Missing. ");
            }
            else
            {
                propertyParkingDTO.PropertyTower = new PropertyTowerDTO();
                foreach (ListItem li in drpTower.Items)
                {
                    if (li.Text.Equals(propertyParkingMapperDTO.TowerName))
                    {
                        propertyParkingDTO.PropertyTower.Id = long.Parse(li.Value);
                        propertyParkingDTO.TowerName = propertyParkingMapperDTO.TowerName;
                    }
                }
            }
            propertyParkingDTO.InsertUser = userDefDto.Username;
            if (propertyBO.validateParkingExist(propertyParkingDTO.FirmNumber, propertyParkingDTO.PropertyTower.Id, propertyParkingDTO.ParkingNo))
            {
                sb.Append(string.Format(Resources.Messages.ERROR_SAME_NAME_EXIST, propertyParkingDTO.ParkingNo));
            }
            else
            {
                foreach (PropertyParkingDTO parkingDTO in parkingList)
                {
                    if (parkingDTO.ParkingNo.Equals(propertyParkingDTO.ParkingNo))
                    {
                        sb.Append("Duplicate Parking with same Parking No.");
                    }
                }
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            sb.Append(exp.Message);
        }
        propertyParkingDTO.ErrorMessage = sb.ToString();
        return propertyParkingDTO;
    }
    private bool validateFileType(string extension)
    {
        bool isValid = true;
        if (extension != ".xlsx" && extension != ".xls")
        {
            isValid = false;
            setErrorMessage("Please Select Property Parking Excel with extension xlsx or xls.", commonError);
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;

    }
}