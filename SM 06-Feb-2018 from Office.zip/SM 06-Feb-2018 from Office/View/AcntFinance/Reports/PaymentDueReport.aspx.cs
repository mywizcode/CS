﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.BO;
using CrystalDecisions.CrystalReports.Engine;
using System.Collections;
using System.Collections.Generic;

public partial class PaymentDueReport : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    DropdownBO drpBO = new DropdownBO();
    ReportConfigBO reportConfigBO = new ReportConfigBO();
    PaymentDueReportBO paymentDueReportBO = new PaymentDueReportBO();

    protected void Page_Load(object sender, EventArgs e)
    {
    	if (ApplicationUtil.isSubPageRendered(Page)) clearMessages();
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                PaymentDueReportNavDTO navDto = ApplicationUtil.getPageNavDTO<PaymentDueReportNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.PAYMENT_DUE_REPORT)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageLayout();
    }
    public void initBootstrapComponantsFromServer()
    {
    	ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpSelectTower, DrpDataType.PROPERTY_TOWER, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(), null, userDefDto.FirmNumber);
    }

    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }

    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(PaymentDueReportNavDTO navDto)
    {
        initDropdowns();
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(PaymentDueReportNavDTO navDto)
    {
        try
        {
            PaymentDueReportPageDTO PaymentDueReportPageDTO = new PaymentDueReportPageDTO();
            Session[Constants.Session.PAGE_DATA] = PaymentDueReportPageDTO;
            if (navDto != null) PaymentDueReportPageDTO.PrevNavDTO = navDto.PrevNavDto;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }

    private void renderPageLayout()
    {
        setPageTitle();
    }
    private void setPageTitle()
    {

    }

    private PaymentDueReportPageDTO getSessionPageData()
    {
        return (PaymentDueReportPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private bool validateMandatoryFields()
    {
        bool isValid = true;
        Page.Validate(commonError);
        isValid = Page.IsValid;
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;

    }
    public void onClickGenerateReport(object sender, EventArgs e)
    {
        try
        {
            if (validateMandatoryFields())
            {
                UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
                BusinessOutputTO businessOutputTO = null;
                ReportConfigDTO reportConfigDTO = null;
                long propertyId = 0, towerId = 0;
                propertyId = CommonUtil.getCurrentPropertyDTO(userDefDto).Id;
                towerId = long.Parse(drpSelectTower.Text);
                IList<PrUnitSaleDetailDTO> result = paymentDueReportBO.fetchSoldPropertyUnits(userDefDto.FirmNumber, propertyId, towerId);
                ReportDocument letterReportDocument = new ReportDocument();
                businessOutputTO = paymentDueReportBO.processPaymentDueLetter(userDefDto.FirmNumber, result, propertyId);
                reportConfigDTO = reportConfigBO.fetchReportConfiguration(userDefDto.FirmNumber, "Payment Due Report");
                if (businessOutputTO.status == BusinessOutputTO.Status.SUCCESS)
                {
                    if (result.Count > 0)
                    {
                        string reportPath = Server.MapPath(reportConfigDTO.ReportPath);
                        letterReportDocument.Load(reportPath);
                        letterReportDocument.Database.Tables["PropertyDetails"].SetDataSource(businessOutputTO.resultList[0]);
                        letterReportDocument.Database.Tables["PaymentDueReport"].SetDataSource(businessOutputTO.resultList[1]);
                        try
                        {

                            letterReportDocument.ExportToHttpResponse
                            (CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, true, "PaymentDueReport");
                        }
                        catch (Exception exp)
                        {

                        }
                    }
                    else
                    {
                        setErrorMessage(Resources.Messages.SOLD_UNIT_NOT_PRESENT, commonError);
                    }
                }
                else
                {
                    setErrorMessage(businessOutputTO.errorMessage, commonError);
                }
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }

}