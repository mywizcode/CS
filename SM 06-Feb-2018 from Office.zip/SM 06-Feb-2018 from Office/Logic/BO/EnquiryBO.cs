﻿using System;
using NHibernate;
using System.IO;
using System.Text;
using System.Collections.Generic;
using NHibernate.Criterion;
using ConstroSoft.Logic.CachingProvider;

/// <summary>
/// Summary description for SupplierBO
/// </summary>
namespace ConstroSoft
{
    public class EnquiryBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public EnquiryBO() { }

        public IList<EnquiryDetailDTO> fetchEnquiryGridData(long propertyId, long AssigneeId, bool fetchAllUser, EnquiryFilterDTO filterDTO)
        {
            ISession session = null;
            IList<EnquiryDetailDTO> results = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                EnquiryDetail ed = null;
                ContactInfo c = null;
                Property p = null;
                EnquiryDetailDTO enDto = null;
                MasterControlData src = null;
                MasterControlData salutation = null;
                LeadDetail ld = null;
                FirmMember fm = null;
                PrUnitSaleDetail pusd = null;

                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => ed.Id).WithAlias(() => enDto.Id))
                            .Add(Projections.Property(() => ed.EnquiryRefNo).WithAlias(() => enDto.EnquiryRefNo))
                            .Add(Projections.Property(() => salutation.Name), "Salutation.Name")
                            .Add(Projections.Property(() => ed.FirstName).WithAlias(() => enDto.FirstName))
                            .Add(Projections.Property(() => ed.MiddleName).WithAlias(() => enDto.MiddleName))
                            .Add(Projections.Property(() => ed.LastName).WithAlias(() => enDto.LastName))
                            .Add(Projections.Property(() => fm.FirstName), "Assignee.FirstName")
                            .Add(Projections.Property(() => fm.LastName), "Assignee.LastName")
                            .Add(Projections.Property(() => c.Contact), "ContactInfo.Contact")
                            .Add(Projections.Property(() => c.AltContact), "ContactInfo.AltContact")
                            .Add(Projections.Property(() => c.Email), "ContactInfo.Email")
                            .Add(Projections.Property(() => ed.EnquiryDate).WithAlias(() => enDto.EnquiryDate))
                            .Add(Projections.Property(() => src.Name), "EnquirySource.Name")
                            .Add(Projections.Property(() => ed.AssignedDate).WithAlias(() => enDto.AssignedDate))
                            .Add(Projections.Property(() => ed.Budget).WithAlias(() => enDto.Budget))
                            .Add(Projections.Property(() => ed.Status).WithAlias(() => enDto.Status))
                            .Add(Projections.Property(() => ld.Id), "Lead.Id")
                            .Add(Projections.Property(() => ld.LeadRefNo), "Lead.LeadRefNo")
                            .Add(Projections.Property(() => pusd.Id), "PrUnitSaleDetail.Id")
                            .Add(Projections.Property(() => pusd.Status), "PrUnitSaleDetail.Status")
                            .Add(Projections.Property(() => ed.Status).WithAlias(() => enDto.Status));
                var query = session.QueryOver<EnquiryDetail>(() => ed)
                    .Inner.JoinAlias(() => ed.ContactInfo, () => c)
                    .Inner.JoinAlias(() => ed.Property, () => p)
                    .Inner.JoinAlias(() => ed.EnquirySource, () => src)
                    .Inner.JoinAlias(() => ed.Salutation, () => salutation)
                    .Inner.JoinAlias(() => ed.Assignee, () => fm)
                    .Left.JoinAlias(() => ed.Lead, () => ld)
                    .Left.JoinAlias(() => ed.PrUnitSaleDetail, () => pusd);
                ICriteria criteria = query.RootCriteria;
                if(!fetchAllUser) {
                	criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<FirmMember>(() => fm, x => x.Id), AssigneeId));
                }
                if (filterDTO != null)
                {
                    if (!string.IsNullOrWhiteSpace(filterDTO.FirstName))
                    {
                        criteria.Add(Restrictions.InsensitiveLike(CommonUtil.BuildProjection<EnquiryDetail>(() => ed, x => x.FirstName), filterDTO.FirstName, MatchMode.Anywhere));
                    }
                    if (!string.IsNullOrWhiteSpace(filterDTO.LastName))
                    {
                        criteria.Add(Restrictions.InsensitiveLike(CommonUtil.BuildProjection<EnquiryDetail>(() => ed, x => x.LastName), filterDTO.LastName, MatchMode.Anywhere));
                    }
                    if (!string.IsNullOrWhiteSpace(filterDTO.EnquiryRefNo))
                    {
                        criteria.Add(Restrictions.InsensitiveLike(CommonUtil.BuildProjection<EnquiryDetail>(() => ed, x => x.EnquiryRefNo), filterDTO.EnquiryRefNo, MatchMode.Anywhere));
                    }
                    if (!string.IsNullOrWhiteSpace(filterDTO.Contact))
                    {
                    	criteria.Add(Restrictions.Like(CommonUtil.BuildProjection<ContactInfo>(() => c, x => x.Contact), filterDTO.Contact, MatchMode.Anywhere));
                    }
                    if (filterDTO.SourceId > 0)
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<MasterControlData>(() => src, x => x.Id), filterDTO.SourceId));
                    }
                    if (filterDTO.Status != null)
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<EnquiryDetail>(() => ed, x => x.Status), filterDTO.Status));
                    }
                }
                results = query.Where(() => p.Id == propertyId)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<EnquiryDetailDTO>()).List<EnquiryDetailDTO>();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating enquiry grid:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }
        public IList<LeadDetailDTO> fetchMyLeadsGridData(long propertyId, long AssigneeId, bool fetchAllUser, LeadFilterDTO filterDTO)
        {
            ISession session = null;
            IList<LeadDetailDTO> results = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	ContactInfo c = null;
                        MasterControlData src = null;
                        MasterControlData sal = null;
                        LeadDetail ld = null;
                        FirmMember fm = null;
                        Property p = null;
                        EnquiryDetail ed = null;
                        
                        LeadDetailDTO ldDto = null;

                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => ld.Id).WithAlias(() => ldDto.Id))
                                    .Add(Projections.Property(() => ld.LeadRefNo).WithAlias(() => ldDto.LeadRefNo))
                                    .Add(Projections.Property(() => sal.Name), "Salutation.Name")
                                    .Add(Projections.Property(() => ld.FirstName).WithAlias(() => ldDto.FirstName))
                                    .Add(Projections.Property(() => ld.MiddleName).WithAlias(() => ldDto.MiddleName))
                                    .Add(Projections.Property(() => ld.LastName).WithAlias(() => ldDto.LastName))
                                    .Add(Projections.Property(() => fm.FirstName), "Assignee.FirstName")
                                    .Add(Projections.Property(() => fm.LastName), "Assignee.LastName")
                                    .Add(Projections.Property(() => c.Contact), "ContactInfo.Contact")
                                    .Add(Projections.Property(() => c.AltContact), "ContactInfo.AltContact")
                                    .Add(Projections.Property(() => c.Email), "ContactInfo.Email")
                                    .Add(Projections.Property(() => ld.LeadDate).WithAlias(() => ldDto.LeadDate))
                                    .Add(Projections.Property(() => src.Id), "Source.Id")
                                    .Add(Projections.Property(() => src.Name), "Source.Name")
                                    .Add(Projections.Property(() => ld.AssignedDate).WithAlias(() => ldDto.AssignedDate))
                                    .Add(Projections.Property(() => ld.Budget).WithAlias(() => ldDto.Budget))
                                    .Add(Projections.Property(() => ld.Status).WithAlias(() => ldDto.Status))
                                    .Add(Projections.Property(() => ed.Id), "EnquiryDetail.Id")
                                    .Add(Projections.Property(() => ed.EnquiryRefNo), "EnquiryDetail.EnquiryRefNo");
                        var query = session.QueryOver<LeadDetail>(() => ld)
                            .Inner.JoinAlias(() => ld.ContactInfo, () => c)
                            .Inner.JoinAlias(() => ld.Salutation, () => sal)
                            .Inner.JoinAlias(() => ld.Source, () => src)
                            .Inner.JoinAlias(() => ld.Assignee, () => fm)
                            .Inner.JoinAlias(() => ld.Property, () => p)
                            .Left.JoinAlias(() => ld.EnquiryDetail, () => ed);
                        ICriteria criteria = query.RootCriteria;
                        if(!fetchAllUser) {
                        	criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<FirmMember>(() => fm, x => x.Id), AssigneeId));
                        }
                        if (filterDTO != null)
                        {
                            if (!string.IsNullOrWhiteSpace(filterDTO.FirstName))
                            {
                                criteria.Add(Restrictions.InsensitiveLike(CommonUtil.BuildProjection<LeadDetail>(() => ld, x => x.FirstName), filterDTO.FirstName, MatchMode.Anywhere));
                            }
                            if (!string.IsNullOrWhiteSpace(filterDTO.LastName))
                            {
                                criteria.Add(Restrictions.InsensitiveLike(CommonUtil.BuildProjection<LeadDetail>(() => ld, x => x.LastName), filterDTO.LastName, MatchMode.Anywhere));
                            }
                            if (!string.IsNullOrWhiteSpace(filterDTO.LeadRefNo))
                            {
                                criteria.Add(Restrictions.InsensitiveLike(CommonUtil.BuildProjection<LeadDetail>(() => ld, x => x.LeadRefNo), filterDTO.LeadRefNo, MatchMode.Anywhere));
                            }
                            if (!string.IsNullOrWhiteSpace(filterDTO.Contact))
                            {
                                criteria.Add(Restrictions.Like(CommonUtil.BuildProjection<ContactInfo>(() => c, x => x.Contact), filterDTO.Contact, MatchMode.Anywhere));
                            }
                            if (filterDTO.SourceId > 0)
                            {
                                criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<MasterControlData>(() => src, x => x.Id), filterDTO.SourceId));
                            }
                            if (filterDTO.Status != null)
                            {
                                criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<LeadDetail>(() => ld, x => x.Status), filterDTO.Status));
                            }
                        }
                        results = query.Where(() => p.Id == propertyId)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<LeadDetailDTO>()).List<LeadDetailDTO>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Leads assigned to user:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }
        public List<AllEnquiryLeadUIDTO> fetchAllEnquiryLeadData(long propertyId)
        {
            ISession session = null;
            List<AllEnquiryLeadUIDTO> resultList = new List<AllEnquiryLeadUIDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        string sqlQuery = "SELECT 'LEAD' AS RD_TYPE, FM.ID, FM.FIRST_NAME, FM.LAST_NAME, CI.CONTACT, CI.EMAIL, UD.STATUS AS USER_STATUS, PFA.HAS_ACCESS, "
                                + " UD.USERNAME, COUNT(case when LD.STATUS = 'O' then 1 end) AS OPEN_EL, COUNT(case when LD.STATUS = 'C' then 1 end) AS WON_EL, "
                                + " COUNT(case when LD.STATUS = 'L' then 1 end) AS LOST_EQ FROM FIRM_MEMBER FM INNER JOIN USER_DEFINITION UD "
                                + " ON UD.FIRM_MEMBER_ID = FM.ID INNER JOIN PROPERTY_FM_ACCESS PFA ON PFA.FIRM_MEMBER_ID = FM.ID AND PFA.PROPERTY_ID = :propertyId "
                                + " INNER JOIN CONTACT_INFO CI ON FM.CONTACT_INFO_ID = CI.ID LEFT JOIN LEAD_DETAILS LD "
                                + " ON LD.ASSIGNEE = FM.ID AND LD.PROPERTY = :propertyId GROUP BY FM.ID, FM.FIRST_NAME, FM.LAST_NAME, CI.CONTACT, CI.EMAIL, "
                                + " UD.STATUS, PFA.HAS_ACCESS, UD.USERNAME "
                                + " UNION "
                                + " SELECT 'ENQUIRY'AS RD_TYPE, FM.ID, FM.FIRST_NAME, FM.LAST_NAME, CI.CONTACT, CI.EMAIL, UD.STATUS AS USER_STATUS, PFA.HAS_ACCESS, "
                                + " UD.USERNAME, COUNT(case when ED.STATUS = 'O' then 1 end) AS OPEN_EL, COUNT(case when ED.STATUS = 'W' then 1 end) AS WON_EL,  "
                                + " COUNT(case when ED.STATUS = 'L' then 1 end) AS LOST_EL FROM FIRM_MEMBER FM INNER JOIN USER_DEFINITION UD "
                                + " ON UD.FIRM_MEMBER_ID = FM.ID INNER JOIN PROPERTY_FM_ACCESS PFA ON PFA.FIRM_MEMBER_ID = FM.ID AND PFA.PROPERTY_ID = :propertyId "
                                + " INNER JOIN CONTACT_INFO CI ON FM.CONTACT_INFO_ID = CI.ID LEFT JOIN ENQUIRY_DETAILS ED"
                                + " ON ED.ASSIGNEE = FM.ID AND ED.PROPERTY = :propertyId GROUP BY FM.ID, FM.FIRST_NAME, FM.LAST_NAME, CI.CONTACT, CI.EMAIL, UD.STATUS, "
                                + " PFA.HAS_ACCESS, UD.USERNAME";
                        IList<object[]> resultObjList = session.CreateSQLQuery(sqlQuery)
                                .SetInt64("propertyId", propertyId)
                        		.List<object[]>();

                        if (resultObjList != null)
                        {
                            List<AllEnquiryLeadUIDTO> tmpUIList = new List<AllEnquiryLeadUIDTO>();
                            foreach (object[] row in resultObjList)
                            {
                                long Id = (long)row[1];
                                AllEnquiryLeadUIDTO tmpDTO = tmpUIList.Find(x => x.FirmMemberId == Id);
                                if (tmpDTO == null)
                                {
                                    tmpDTO = new AllEnquiryLeadUIDTO();
                                    tmpDTO.FirmMemberId = Id;
                                    tmpDTO.FirstName = (string)row[2];
                                    tmpDTO.LastName = (string)row[3];
                                    tmpDTO.FullName = CommonUIConverter.getCustomerFullName(tmpDTO.FirstName, tmpDTO.LastName);
                                    tmpDTO.Contact = (string)row[4];
                                    tmpDTO.Email = (string)row[5];
                                    tmpDTO.Status = EnumHelper.getUserStatus((string)row[6]);
                                    tmpDTO.PropertyFMAccess = EnumHelper.getPrFMAccess((string)row[7]);
                                    tmpDTO.UserName = (string)row[8];
                                    tmpDTO.ProfileImgPath = CommonUtil.getUserProfileImagePathRelative(tmpDTO.UserName);
                                    tmpUIList.Add(tmpDTO);
                                }
                                if ((string)row[0] == "LEAD")
                                {
                                    tmpDTO.LeadsOpen = tmpDTO.LeadsOpen + (int)row[9];
                                    tmpDTO.LeadsConverted = tmpDTO.LeadsConverted + (int)row[10];
                                    tmpDTO.LeadsLost = tmpDTO.LeadsLost + (int)row[11];
                                    tmpDTO.LeadsClosed = tmpDTO.LeadsConverted + tmpDTO.LeadsLost;
                                }
                                else
                                {
                                    tmpDTO.EnquiriesOpen = tmpDTO.LeadsOpen + (int)row[9];
                                    tmpDTO.EnquiriesWon = tmpDTO.EnquiriesWon + (int)row[10];
                                    tmpDTO.EnquiriesLost = tmpDTO.EnquiriesLost + (int)row[11];
                                    tmpDTO.EnquiriesClosed = tmpDTO.EnquiriesWon + tmpDTO.EnquiriesLost;
                                }
                            }
                            foreach (AllEnquiryLeadUIDTO uiDTO in tmpUIList)
                            {
                                if (uiDTO.PropertyFMAccess == PrFMAccess.Yes ||
                                    uiDTO.LeadsOpen > 0 || uiDTO.LeadsClosed > 0 || uiDTO.EnquiriesOpen > 0 || uiDTO.EnquiriesClosed > 0)
                                {
                                    resultList.Add(uiDTO);
                                }
                            }
                        }

                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching all enquiry and leqads history:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return resultList;
        }
        public IList<UserEnquiryHistoryUIDTO> fetchEnquiryHistoryForUser(long Assignee, List<long> enquiryIdList)
        {
            ISession session = null;
            IList<UserEnquiryHistoryUIDTO> resultList = new List<UserEnquiryHistoryUIDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EnquiryDetail ed = null;
                        EnquiryActivity ea = null;
                        FirmMember fm = null;

                        UserEnquiryHistoryUIDTO tmpDTO = null;

                        resultList = session.QueryOver<EnquiryDetail>(() => ed)
                                    .Left.JoinAlias(() => ed.EnquiryActivities, () => ea)
                                    .Left.JoinAlias(() => ea.LoggedBy, () => fm)
                                    .SelectList(list => list
                                        .SelectGroup(() => ed.Id).WithAlias(() => tmpDTO.EnquiryId)
                                        .SelectMax(() => ea.DateLogged).WithAlias(() => tmpDTO.LastActivity))
                                    .Where(() => fm.Id == Assignee && ed.Id.IsIn(enquiryIdList))
                                    .TransformUsing(new DeepTransformer<UserEnquiryHistoryUIDTO>())
                                    .List<UserEnquiryHistoryUIDTO>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Enquiry activity details for user:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return resultList;
        }
        public IList<UserLeadHistoryUIDTO> fetchLeadHistoryForUser(long Assignee, List<long> leadIdList)
        {
            ISession session = null;
            IList<UserLeadHistoryUIDTO> resultList = new List<UserLeadHistoryUIDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        LeadDetail ld = null;
                        LeadActivity la = null;
                        FirmMember fm = null;
                        
                        UserLeadHistoryUIDTO tmpDTO = null;

                        resultList = session.QueryOver<LeadDetail>(() => ld)
                                    .Left.JoinAlias(() => ld.LeadActivities, () => la)
                                    .Left.JoinAlias(() => la.LoggedBy, () => fm)
                                    .SelectList(list => list
                                        .SelectGroup(() => ld.Id).WithAlias(() => tmpDTO.LeadId)
                                        .SelectMax(() => la.DateLogged).WithAlias(() => tmpDTO.LastActivity))
                                    .Where(() => fm.Id == Assignee && ld.Id.IsIn(leadIdList))
                                    .TransformUsing(new DeepTransformer<UserLeadHistoryUIDTO>())
                                    .List<UserLeadHistoryUIDTO>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Lead activity details for user:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return resultList;
        }
        private void appendFilter(StringBuilder filterStr, string connector, string clause)
        {
            if (filterStr.Length == 0) filterStr.Append("where");
            else filterStr.Append(connector);
            filterStr.Append(clause);
        }
        public AllEnquiryLeadUIDTO fetchEnquiryHistorySummaryForUser(long PropertyId, long AssigneeId)
        {
            ISession session = null;
            AllEnquiryLeadUIDTO result = new AllEnquiryLeadUIDTO();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	string query = " SELECT FM.ID as FirmMemberId, SAL.NAME as Salutation, FM.FIRST_NAME as FirstName, FM.LAST_NAME as LastName, CI.CONTACT as Contact, CI.EMAIL as Email, "
                                + " COUNT(case when ED.STATUS = 'O' then 1 end) AS EnquiriesOpen, COUNT(case when ED.STATUS = 'W' then 1 end) AS EnquiriesWon,  "
                                + " COUNT(case when ED.STATUS = 'L' then 1 end) AS EnquiriesLost FROM FIRM_MEMBER FM INNER JOIN USER_DEFINITION UD "
                                + " ON UD.FIRM_MEMBER_ID = FM.ID INNER JOIN PROPERTY_FM_ACCESS PFA ON PFA.FIRM_MEMBER_ID = FM.ID AND PFA.PROPERTY_ID = :PropertyId "
                                + " INNER JOIN CONTACT_INFO CI ON FM.CONTACT_INFO_ID = CI.ID INNER JOIN MASTER_CONTROL_DATA SAL "
                                + " ON FM.SALUTATION_ID = SAL.ID LEFT JOIN ENQUIRY_DETAILS ED ON ED.ASSIGNEE = FM.ID AND ED.PROPERTY = :PropertyId "
                                + " WHERE FM.ID = :AssigneeId GROUP BY FM.ID, SAL.NAME, FM.FIRST_NAME, FM.LAST_NAME, CI.CONTACT, CI.EMAIL";
                        result = session.CreateSQLQuery(query)
                                .SetInt64("AssigneeId", AssigneeId)
                                .SetInt64("PropertyId", PropertyId)
                                .SetResultTransformer(new DeepTransformer<AllEnquiryLeadUIDTO>()).UniqueResult<AllEnquiryLeadUIDTO>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Enquiry history summary for user:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public AllEnquiryLeadUIDTO fetchLeadHistorySummaryForUser(long PropertyId, long AssigneeId)
        {
            ISession session = null;
            AllEnquiryLeadUIDTO result = new AllEnquiryLeadUIDTO();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	string query = "SELECT FM.ID as FirmMemberId, SAL.NAME as Salutation, FM.FIRST_NAME as FirstName, FM.LAST_NAME as LastName, CI.CONTACT as Contact, CI.EMAIL as Email, "
                                + " COUNT(case when LD.STATUS = 'O' then 1 end) AS LeadsOpen, COUNT(case when LD.STATUS = 'C' then 1 end) AS LeadsConverted, "
                                + " COUNT(case when LD.STATUS = 'L' then 1 end) AS LeadsLost FROM FIRM_MEMBER FM INNER JOIN USER_DEFINITION UD "
                                + " ON UD.FIRM_MEMBER_ID = FM.ID INNER JOIN PROPERTY_FM_ACCESS PFA ON PFA.FIRM_MEMBER_ID = FM.ID AND PFA.PROPERTY_ID = :PropertyId "
                                + " INNER JOIN CONTACT_INFO CI ON FM.CONTACT_INFO_ID = CI.ID INNER JOIN MASTER_CONTROL_DATA SAL "
                                + " ON FM.SALUTATION_ID = SAL.ID LEFT JOIN LEAD_DETAILS LD ON LD.ASSIGNEE = FM.ID AND LD.PROPERTY = :PropertyId "
                                + " WHERE FM.ID = :AssigneeId GROUP BY FM.ID, SAL.NAME, FM.FIRST_NAME, FM.LAST_NAME, CI.CONTACT, CI.EMAIL";
                        result = session.CreateSQLQuery(query)
                                .SetInt64("AssigneeId", AssigneeId)
                                .SetInt64("PropertyId", PropertyId)
                                .SetResultTransformer(new DeepTransformer<AllEnquiryLeadUIDTO>()).UniqueResult<AllEnquiryLeadUIDTO>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Lead history summary for user:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public List<UserLeadHistoryUIDTO> fetchOpenLeadsForUser(long PropertyId, long AssigneeId)
        {
            ISession session = null;
            List<UserLeadHistoryUIDTO> resultList = new List<UserLeadHistoryUIDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	string hqlQuery = "select ld.Id as LeadId, ld.FirstName as CustFirstName, ld.MiddleName as CustMiddleName, ld.LastName as CustLastName, ld.LeadDate as LeadDate, "
                                   + " ld.LeadRefNo as LeadRefNo, ld.AssignedDate as AssignedDate, ld.Status as Status, src.Name as Source, ci.Contact as Contact, ld.Budget as Budget "
                                   + " from LeadDetail ld inner join ld.Property p inner join ld.Source src inner join ld.Assignee asgn inner join ld.ContactInfo ci "
                    			   + " where p.Id = :PropertyId and asgn.Id = :AssigneeId and ld.Status = 'O'";
                        IList<UserLeadHistoryUIDTO> tmpResultList = session.CreateQuery(hqlQuery)
                        		.SetInt64("AssigneeId", AssigneeId)
                                .SetInt64("PropertyId", PropertyId)
                                .SetResultTransformer(new DeepTransformer<UserLeadHistoryUIDTO>()).List<UserLeadHistoryUIDTO>();
                        resultList.AddRange(tmpResultList);
                        foreach (UserLeadHistoryUIDTO tmpDTO in resultList)
                        {
                            tmpDTO.CustFullName = CommonUIConverter.getCustomerFullName(tmpDTO.CustFirstName, tmpDTO.CustLastName);
                            tmpDTO.NoOfDaysAssgined = (DateUtil.getUserLocalDate() - tmpDTO.AssignedDate).Days;
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Leads for user with given Lead status:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return resultList;
        }
        public List<UserLeadHistoryUIDTO> fetchUnAssignedLeads(long PropertyId)
        {
            ISession session = null;
            List<UserLeadHistoryUIDTO> resultList = new List<UserLeadHistoryUIDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	string hqlQuery = "select ld.Id as LeadId, ld.FirstName as CustFirstName, ld.MiddleName as CustMiddleName, ld.LastName as CustLastName, "
                                   + " ld.LeadDate as LeadDate, ld.LeadRefNo as LeadRefNo, ld.Budget as Budget, ci.Contact as Contact, ci.Email as Email, ld.Status as Status, "
                                   + " src.Name as Source from LeadDetail ld inner join ld.Property p inner join ld.Source src inner join ld.ContactInfo ci "
                                   + " where p.Id = :PropertyId and ld.Assignee is null";
                        IList<UserLeadHistoryUIDTO> tmpResultList = session.CreateQuery(hqlQuery)
                                .SetInt64("PropertyId", PropertyId)
                                .SetResultTransformer(new DeepTransformer<UserLeadHistoryUIDTO>()).List<UserLeadHistoryUIDTO>();
                        resultList.AddRange(tmpResultList);
                        foreach (UserLeadHistoryUIDTO tmpDTO in resultList)
                        {
                            tmpDTO.CustFullName = CommonUIConverter.getCustomerFullName(tmpDTO.CustFirstName, tmpDTO.CustLastName);
                            tmpDTO.NoOfDaysCreated = (DateUtil.getUserLocalDate() - tmpDTO.LeadDate).Days;
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Unassigned Leads:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return resultList;
        }
        public EnquiryDetailDTO fetchEnquiryDetails(long Id, bool fetchFollowups)
        {
            ISession session = null;
            EnquiryDetailDTO enquiryDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EnquiryDetail enquiry = session.Get<EnquiryDetail>(Id);
                        enquiryDto = DomainToDTOUtil.convertToEnquiryDetailDTO(enquiry, true, fetchFollowups);
                        if(enquiryDto.Status != EnquiryStatus.Open && enquiryDto.PrUnitSaleDetail != null) {
                        	enquiryDto.PrUnitSaleDetail.PropertyUnit = new PropertyUnitDTO();
                        	enquiryDto.PrUnitSaleDetail.PropertyUnit.Id = enquiry.PrUnitSaleDetail.PropertyUnit.Id;
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Enquiry details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return enquiryDto;
        }
        public LeadDetailDTO fetchLeadDetails(long Id, bool fetchFollowups)
        {
        	ISession session = null;
        	LeadDetailDTO leadDTO = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				LeadDetail enquiry = session.Get<LeadDetail>(Id);
        				leadDTO = DomainToDTOUtil.convertToLeadDetailDTO(enquiry, true, fetchFollowups);
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while Loading Lead details:", e);
        				throw new Exception(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        	return leadDTO;
        }
        public string addEnquiryDetails(EnquiryDetailDTO enquiryDto, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            string enquiryRefNo = "";
            try
            {
                session = NHibertnateSession.OpenSession();
                EnquiryDetail enquiry = null;
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        LeadDetail lead = null;
                        if (enquiryDto.Lead != null)
                        {
                        	//Once lead is converted to enquiry then update existing open activities as Deferred.
                            LeadDetailDTO leadDTO = enquiryDto.Lead;
                            string hqlActivityUpdate = "update LeadActivity la set la.Status = :status where la.Id in (select l.id from LeadActivity l where "
                                + " l.LeadDetail.Id = :LeadId) and la.Status = :openStatus";
                            session.CreateQuery(hqlActivityUpdate)
                                    .SetEnum("status", EnqLeadActivityStatus.Deferred)
                                    .SetEnum("openStatus", EnqLeadActivityStatus.Open)
                                    .SetInt64("LeadId", leadDTO.Id)
                                    .ExecuteUpdate();
                            //Update Lead status to Converted.
                            lead = session.Get<LeadDetail>(leadDTO.Id);
                            lead.Status = LeadStatus.Converted;
                            lead.DateClosed = DateUtil.getUserLocalDateTime();
                            lead.UpdateDate = DateUtil.getUserLocalDateTime();
                            lead.UpdateUser = userDefDTO.Username;
                            session.Update(lead);
                        }

                        enquiry = DTOToDomainUtil.populateEnquiryDetailAddFields(enquiryDto);
                        enquiry.Lead = lead;
                        session.Save(enquiry);
                        enquiry.EnquiryRefNo = CommonUtil.getEnquiryRefNo(enquiry.Id);
                        session.Update(enquiry);
                        enquiryRefNo = enquiry.EnquiryRefNo;
                        enquiryDto.Id = enquiry.Id;
                        EnquiryActivity activity = CommonUtil.getEnquiryActivityAction(enquiry.Id, (lead == null) ? EnqActivityType.CREATE : EnqActivityType.CONVERTED,
                            enquiry.EnquiryDate, userDefDTO, (lead == null) ? "" : lead.LeadRefNo);
                        session.Save(activity);
                        activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
                        session.Update(activity);                       
                        //Add conversion lead activity once enquiry is created.
                        if (enquiryDto.Lead != null)
                        {
                            LeadActivity leadActivity = CommonUtil.getLeadActivityAction(lead.Id, EnqActivityType.CONVERTED, DateUtil.getUserLocalDateTime(), userDefDTO, enquiryRefNo);
                            session.Save(leadActivity);
                            leadActivity.RefNo = CommonUtil.getActivityRefNo(leadActivity.Id, leadActivity.RecordType);
                            session.Update(leadActivity);
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Enquiry details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
                sendSMSEmail(enquiry);
             }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return enquiryRefNo;
        }
        public void updateEnquiry(EnquiryDetailDTO enquiryDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EnquiryDetail enquiry = session.Get<EnquiryDetail>(enquiryDto.Id);
                        DTOToDomainUtil.populateEnquiryDetailUpdateFields(enquiry, enquiryDto);
                        session.Update(enquiry);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating Enquiry details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public string addLeadDetails(LeadDetailDTO leadDetailDTO, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            string leadRefNo = "";
            try
            {
                session = NHibertnateSession.OpenSession();
                LeadDetail lead = null;
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	lead = DTOToDomainUtil.populateLeadDetailAddFields(leadDetailDTO);
                        session.Save(lead);
                        lead.LeadRefNo = CommonUtil.getLeadRefNo(lead.Id);
                        session.Update(lead);
                        leadRefNo = lead.LeadRefNo;
                        LeadActivity activity = CommonUtil.getLeadActivityAction(lead.Id, EnqActivityType.CREATE, lead.LeadDate, userDefDTO, 
                        		CommonUIConverter.getCustomerFullName(lead.Assignee.FirstName, lead.Assignee.LastName));
                        session.Save(activity);
                        activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
                        session.Update(activity);
                        //In case Lead is added from resolve call page then call activity is added
                        if (leadDetailDTO.LeadActivities != null && leadDetailDTO.LeadActivities.Count > 0)
                        {
                            foreach (LeadActivityDTO tmpDTO in leadDetailDTO.LeadActivities)
                            {
                                tmpDTO.LeadDetail.Id = lead.Id;
                                LeadActivity tmpActivity = DTOToDomainUtil.populateLeadActivityAddFields(tmpDTO);
                                session.Save(tmpActivity);
                                tmpActivity.RefNo = CommonUtil.getActivityRefNo(tmpActivity.Id, tmpActivity.RecordType);
                                session.Update(tmpActivity);
                                if (tmpDTO.CallHistoryDTO != null && tmpDTO.CallHistoryDTO.Id > 0)
                                {
                                    CallHistory callHistory = session.Get<CallHistory>(tmpDTO.CallHistoryDTO.Id);
                                    callHistory.CallHistoryStatus = CallHistoryStatus.Resolved;
                                    callHistory.UpdateDate = DateUtil.getUserLocalDateTime();
                                    callHistory.UpdateUser = userDefDTO.Username;
                                    session.Update(callHistory);
                                }
                            }
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Lead details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
             }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return leadRefNo;
        }
        /**
         * This method will check Email & SMS configuration for Enquiry Function. 
         * If Email & SMS alerts are enabled then system will send Email & SMS to Customer.
         * */
        private static void sendSMSEmail(EnquiryDetail enquiry)
        {
            try
            {
                PropertyAlertConfig emailSmsAlertConfig = EmailUtil.loadEmailSmsAlertConfiguration(enquiry.FirmNumber,
                    FunctionName.ENQUIRY.ToString(), EmailSmsType.ENQUIRYTHANKS.ToString(), enquiry.Property.Id);
                PropertyBO propertyBO = new PropertyBO();
                PropertyDTO propertyDTO = propertyBO.fetchProperty(enquiry.Property.Id);
                if (emailSmsAlertConfig != null && emailSmsAlertConfig.Email.Equals(Constants.YES))
                {
                    emailSmsAlertConfig.EmailBody = populateBody(enquiry, emailSmsAlertConfig, propertyDTO.Name);
                    EmailUtil.sendHtmlFormattedEmail(enquiry.FirmNumber, emailSmsAlertConfig, enquiry.ContactInfo.Email);
                }
                if (emailSmsAlertConfig != null && emailSmsAlertConfig.Sms.Equals(Constants.YES))
                {
                    emailSmsAlertConfig.SmsContent = populateSMSBody(enquiry, emailSmsAlertConfig, propertyDTO.Name);
                    EmailUtil.sendSMS(enquiry.FirmNumber, emailSmsAlertConfig, enquiry.ContactInfo.Contact);
                }
            }
            catch (Exception e)
            {
                log.Error("Exception while sending Email & SMS alert for enquiry:", e);
            }
        }
        private static string populateBody(EnquiryDetail enquiry, PropertyAlertConfig emailSmsAlertConfig, string propertyName)
        {
            string body = string.Empty;
            using (StreamReader reader = new StreamReader(System.Web.HttpContext.Current.Server.MapPath(emailSmsAlertConfig.EmailTemplatePath)))
            {
                body = reader.ReadToEnd();
            }
            body = body.Replace("{UserName}", enquiry.Salutation.Name + " " + enquiry.FirstName + " " + enquiry.LastName);
            body = body.Replace("{PropertyName}", propertyName);
            return body;
        }
        private static string populateSMSBody(EnquiryDetail enquiry, PropertyAlertConfig emailSmsAlertConfig, string propertyName)
        {
            string body = string.Empty;
            body = emailSmsAlertConfig.SmsContent.Replace("{UserName}", enquiry.Salutation.Name + " " +enquiry.FirstName + " " + enquiry.LastName);
            body = emailSmsAlertConfig.SmsContent.Replace("{PropertyName}", propertyName);
            return body;
        }
        public void addEnquiryActivityForFacebook(long enquiryId, UserDefinitionDTO userDefDTO)
        {
        	ISession session = null;
        	long propertyId = 0;
        	NotificationDTO notificationDTO = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				EnquiryDetail enquiry = session.Get<EnquiryDetail>(enquiryId);
        				propertyId = enquiry.Property.Id;
        				EnquiryActivity activity = CommonUtil.getEnquiryActivityAction(enquiry.Id, EnqActivityType.FACEBOOK_ENQUIRY, DateUtil.getUserLocalDateTime(), userDefDTO, "");
        				session.Save(activity);
        				activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
        				session.Update(activity);
        				//Add notificatoin to assignee that activity is added.
        				NotificationSubType subType = NotificationSubType.LEAD_ACTIVITY_LOGGED_BY_FACEBOOK;
        				Notification notification = NotificationUtil.getAlertNotification(userDefDTO, NotificationUtil.createNotificationAlertMessage(subType, enquiry.EnquiryRefNo), DateUtil.getUserLocalDateTime(),
                            subType, NotificationUtil.createNotificationAlertRefEntityInfo(subType, enquiry.Id.ToString()), enquiry.Assignee.User.Username, null);
        				session.Save(notification);
        				notificationDTO = DomainToDTOUtil.convertToNotificationDTO(notification, true);
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while adding Enquiry activity for facebook:", e);
        				throw new Exception(Resources.Messages.system_error);
        			}
        		}
        	 }
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        	if(notificationDTO != null) {
        		string key = NotificationUtil.getNotificationUserKey(notificationDTO.UserName, propertyId);
        		NotificationCacheProvider.Instance.addNotification(key, notificationDTO);
        	}
        }
        public string addEnquiryActivity(EnquiryActivityDTO activityDTO, EnqActivityMode activityMode, long parentId,
        		UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            string RefNo = "";
            List<NotificationDTO> notificationList = new List<NotificationDTO>();
            PropertyDTO currentPropertyDTO = CommonUtil.getCurrentPropertyDTO(userDefDTO);
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EnquiryActivity activity = DTOToDomainUtil.populateEnquiryActivityAddFields(activityDTO);
                        session.Save(activity);
                        activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
                        session.Update(activity);
                        RefNo = activity.RefNo;
                        EnquiryDetail enquiry = session.Get<EnquiryDetail>(activity.EnquiryDetail.Id);
                        activity.EnquiryDetail = enquiry;
                        FirmMember assignee = enquiry.Assignee;
                        if (activityMode != EnqActivityMode.NONE && parentId > 0)
                        {
                            EnqLeadActivityStatus status = EnqLeadActivityStatus.Completed;
                            if (activityMode == EnqActivityMode.RESCHEDULE_REMINDER || activityMode == EnqActivityMode.CANCEL_REMINDER) {
                                    status = EnqLeadActivityStatus.Deferred;
                            }
                            EnquiryActivity parentActivity = session.Get<EnquiryActivity>(parentId);
                            parentActivity.Status = status;
                            parentActivity.UpdateDate = DateUtil.getUserLocalDateTime();
                            parentActivity.UpdateUser = activityDTO.InsertUser;
                            session.Update(parentActivity);
                            
                            //If parent scheduled reminder is qualified in notification then remove it
                            if(DateUtil.isReminderQualifiedForNotification(parentActivity.ScheduledDate)) {
                            	string key = NotificationUtil.getNotificationUserKey(assignee.User.Username, currentPropertyDTO.Id);
                            	NotificationCacheProvider.Instance.removeNotification(key, parentActivity.RefNo);
                            }
                        }
                        if (activityMode == EnqActivityMode.MAKE_CALL)
                        {
                            CallHistory callHistory = session.Get<CallHistory>(activityDTO.CallHistoryDTO.Id);
                            callHistory.CallHistoryStatus = CallHistoryStatus.Resolved;
                            callHistory.UpdateDate = DateUtil.getUserLocalDateTime();
                            callHistory.UpdateUser = userDefDTO.Username;
                            session.Update(callHistory);
                        }
                        //If Reminder is added/scheduled then check whether it qualifies to notify to user if logged in.
                        if((activityMode == EnqActivityMode.ADD_REMINDER || activityMode == EnqActivityMode.RESCHEDULE_REMINDER)
                        		&& DateUtil.isReminderQualifiedForNotification(activity.ScheduledDate)) {
                        	//Create Task Notification and add to memory
                        	notificationList.Add(NotificationUtil.createEnquiryReminderNotification(userDefDTO, activity, assignee.User.Username));
                        }
                        //If Logged in user who added this activity is not same as user to which this enquiry is assigned then notify to assignee
                        if (userDefDTO.FirmMember.Id != assignee.Id)
                        {
                        	//Create Alert Notification and add to DB and Memory
                        	NotificationSubType subType = NotificationSubType.ENQUIRY_ACTIVITY_LOGGED_BY_USER;
                            Notification notification = NotificationUtil.getAlertNotification(userDefDTO,
                                NotificationUtil.createNotificationAlertMessage(subType, enquiry.EnquiryRefNo, CommonUIConverter.getCustomerFullName(userDefDTO.FirmMember.FirstName, userDefDTO.FirmMember.LastName)), DateUtil.getUserLocalDateTime(),
                                subType, NotificationUtil.createNotificationAlertRefEntityInfo(subType, enquiry.Id.ToString()), assignee.User.Username, null);
                            session.Save(notification);
                            string key = NotificationUtil.getNotificationUserKey(notification.UserName, CommonUtil.getCurrentPropertyDTO(userDefDTO).Id);
                            notificationList.Add(DomainToDTOUtil.convertToNotificationDTO(notification, true));
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while adding Enquiry activity and update other:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
                //Add notifications for assgined user in Cache
                if(notificationList.Count > 0) {
                	string key = NotificationUtil.getNotificationUserKey(notificationList[0].UserName, currentPropertyDTO.Id);
                	NotificationCacheProvider.Instance.addNotifications(key, notificationList);
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return RefNo;
        }
        public void addLeadActivityForFacebook(long leadId, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            long propertyId = 0;
            NotificationDTO notificationDTO = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	LeadDetail lead = session.Get<LeadDetail>(leadId);
                    	propertyId = lead.Property.Id;
                        LeadActivity activity = CommonUtil.getLeadActivityAction(lead.Id, EnqActivityType.FACEBOOK_ENQUIRY, DateUtil.getUserLocalDateTime(), userDefDTO, "");
                        session.Save(activity);
                        activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
                        session.Update(activity);
                        //Add notificatoin to assignee that activity is added.
                        NotificationSubType subType = NotificationSubType.LEAD_ACTIVITY_LOGGED_BY_FACEBOOK;
                    	Notification notification = NotificationUtil.getAlertNotification(userDefDTO, NotificationUtil.createNotificationAlertMessage(subType, lead.LeadRefNo), DateUtil.getUserLocalDateTime(), 
                            subType, NotificationUtil.createNotificationAlertRefEntityInfo(subType, lead.Id.ToString()), lead.Assignee.User.Username, null);
                    	session.Save(notification);
                        notificationDTO = DomainToDTOUtil.convertToNotificationDTO(notification, true);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while adding Lead activity for facebook:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
             }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            if(notificationDTO != null) {
            	string key = NotificationUtil.getNotificationUserKey(notificationDTO.UserName, propertyId);
                NotificationCacheProvider.Instance.addNotification(key, notificationDTO);
            }
        }
        public string addLeadActivity(LeadActivityDTO activityDTO, EnqActivityMode activityMode, long parentId, UserDefinitionDTO userDefDTO)
        {
        	ISession session = null;
        	string RefNo = "";
        	List<NotificationDTO> notificationList = new List<NotificationDTO>();
            PropertyDTO currentPropertyDTO = CommonUtil.getCurrentPropertyDTO(userDefDTO);
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				LeadActivity activity = DTOToDomainUtil.populateLeadActivityAddFields(activityDTO);
        				session.Save(activity);
                        activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
        				session.Update(activity);
        				RefNo = activity.RefNo;
        				LeadDetail lead = session.Get<LeadDetail>(activity.LeadDetail.Id);
        				activity.LeadDetail = lead;
                        FirmMember assignee = lead.Assignee;
        				if (activityMode != EnqActivityMode.NONE && parentId > 0)
        				{
        					EnqLeadActivityStatus status = EnqLeadActivityStatus.Completed;
        					if (activityMode == EnqActivityMode.RESCHEDULE_REMINDER || activityMode == EnqActivityMode.CANCEL_REMINDER) {
        							status = EnqLeadActivityStatus.Deferred;
        					}
        					LeadActivity parentActivity = session.Get<LeadActivity>(parentId);
                            parentActivity.Status = status;
                            parentActivity.UpdateDate = DateUtil.getUserLocalDateTime();
                            parentActivity.UpdateUser = activityDTO.InsertUser;
                            session.Update(parentActivity);
                            
                            //If parent scheduled reminder is qualified in notification then remove it
                            if(DateUtil.isReminderQualifiedForNotification(parentActivity.ScheduledDate)) {
                            	string key = NotificationUtil.getNotificationUserKey(assignee.User.Username, currentPropertyDTO.Id);
                            	NotificationCacheProvider.Instance.removeNotification(key, parentActivity.RefNo);
                            }
        				}
                        if (activityMode == EnqActivityMode.MAKE_CALL)
                        {
                            CallHistory callHistory = session.Get<CallHistory>(activityDTO.CallHistoryDTO.Id);
                            callHistory.CallHistoryStatus = CallHistoryStatus.Resolved;
                            callHistory.UpdateDate = DateUtil.getUserLocalDateTime();
                            callHistory.UpdateUser = userDefDTO.Username;
                            session.Update(callHistory);
                        }
        				//If Reminder is added/scheduled then check whether it qualifies to notify to user if logged in.
                        if((activityMode == EnqActivityMode.ADD_REMINDER || activityMode == EnqActivityMode.RESCHEDULE_REMINDER)
                        		&& DateUtil.isReminderQualifiedForNotification(activity.ScheduledDate)) {
                        	//Create Task Notification and add to memory
                        	notificationList.Add(NotificationUtil.createLeadReminderNotification(userDefDTO, activity, assignee.User.Username));
                        }
                        //If Logged in user who added this activity is not same as user to which this enquiry is assigned then notify to assignee
                        if (userDefDTO.FirmMember.Id != assignee.Id) {
                        	NotificationSubType subType = NotificationSubType.LEAD_ACTIVITY_LOGGED_BY_USER;
                        	Notification notification = NotificationUtil.getAlertNotification(userDefDTO,
                                NotificationUtil.createNotificationAlertMessage(subType, lead.LeadRefNo, CommonUIConverter.getCustomerFullName(userDefDTO.FirmMember.FirstName, userDefDTO.FirmMember.LastName)), DateUtil.getUserLocalDateTime(), 
                                subType, NotificationUtil.createNotificationAlertRefEntityInfo(subType, lead.Id.ToString()), assignee.User.Username, null);
                        	session.Save(notification);
                            string key = NotificationUtil.getNotificationUserKey(notification.UserName, currentPropertyDTO.Id);
                            notificationList.Add(DomainToDTOUtil.convertToNotificationDTO(notification, true));
                        }
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while adding Lead activity:", e);
        				throw new Exception(Resources.Messages.system_error);
        			}
        		}
        		//Add notifications for assgined user in Cache
                if(notificationList.Count > 0) {
                	string key = NotificationUtil.getNotificationUserKey(notificationList[0].UserName, currentPropertyDTO.Id);
                	NotificationCacheProvider.Instance.addNotifications(key, notificationList);
                }
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        	return RefNo;
        }
        public void ReAssignEnquiry(long enquiryId, long assigneeId, DateTime assignedDate, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            Dictionary<string, List<NotificationDTO>> notificatonDict = new Dictionary<string, List<NotificationDTO>>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        FirmMember assignee = session.Get<FirmMember>(assigneeId);
                        EnquiryDetail enquiry = session.Get<EnquiryDetail>(enquiryId);
                        FirmMember previousAssignee = enquiry.Assignee;
                        if (CommonValidations.validateEnquiryLeadAssignment(assignee, enquiry.Property.Id))
                        {
                            enquiry.Assignee = assignee;
                            enquiry.AssignedDate = assignedDate;
                            enquiry.UpdateDate = DateUtil.getUserLocalDateTime();
                            enquiry.UpdateUser = userDefDTO.Username;
                            session.Update(enquiry);
                            EnquiryActivity activity = CommonUtil.getEnquiryActivityAction(enquiryId, EnqActivityType.RE_ASSIGNMENT,
                                        assignedDate, userDefDTO, CommonUIConverter.getCustomerFullName(enquiry.Assignee.FirstName, enquiry.Assignee.LastName));
                            session.Save(activity);
                            activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
                            session.Update(activity);
                            //Add Notifications for Previous assignee and new assignee
                            if (userDefDTO.FirmMember.Id != previousAssignee.Id)
                            {
                            	NotificationSubType subType = NotificationSubType.ENQUIRY_REASSIGNED_USER;
                                Notification notification = NotificationUtil.getAlertNotification(userDefDTO,
                                    NotificationUtil.createNotificationAlertMessage(subType, enquiry.EnquiryRefNo,
                                        CommonUIConverter.getCustomerFullName(assignee.FirstName, assignee.LastName)), DateUtil.getUserLocalDateTime(),
                                    subType, NotificationUtil.createNotificationAlertRefEntityInfo(subType, enquiry.Id.ToString()), previousAssignee.User.Username, null);
                                session.Save(notification);
                                string key = NotificationUtil.getNotificationUserKey(notification.UserName, CommonUtil.getCurrentPropertyDTO(userDefDTO).Id);
                                NotificationUtil.addToNotificationDict(notificatonDict, key, DomainToDTOUtil.convertToNotificationDTO(notification, true));
                            }
                            if (userDefDTO.FirmMember.Id != assignee.Id)
                            {
                            	NotificationSubType subType = NotificationSubType.ENQUIRY_REASSIGNED_SELF;
                                Notification notification = NotificationUtil.getAlertNotification(userDefDTO,
                                    NotificationUtil.createNotificationAlertMessage(subType, enquiry.EnquiryRefNo), DateUtil.getUserLocalDateTime(),
                                    subType, NotificationUtil.createNotificationAlertRefEntityInfo(subType, enquiry.Id.ToString()), assignee.User.Username, null);
                                session.Save(notification);
                                string key = NotificationUtil.getNotificationUserKey(notification.UserName, CommonUtil.getCurrentPropertyDTO(userDefDTO).Id);
                                NotificationUtil.addToNotificationDict(notificatonDict, key, DomainToDTOUtil.convertToNotificationDTO(notification, true));
                            }
                            tx.Commit();
                        }
                        else throw new CustomException("User does not have access to current property or user is not active.");

                    }
                    catch (CustomException e)
                    {
                        throw e;
                    }  
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Reassigning Enquiry:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
                //Add notifications in Cache
                if (notificatonDict.Count > 0)
                {
                    NotificationCacheProvider.Instance.addNotifications(notificatonDict);
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void AssignAllLeads(List<UserLeadHistoryUIDTO> selectedLeadList, long assigneeId, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            List<NotificationDTO> notificationAlertList = new List<NotificationDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        bool isValidated = false;
                        FirmMember assignee = session.Get<FirmMember>(assigneeId);
                        foreach (UserLeadHistoryUIDTO tmpLeadDTO in selectedLeadList)
                        {
                            LeadDetail lead = session.Get<LeadDetail>(tmpLeadDTO.LeadId);
                            if(!isValidated) isValidated = CommonValidations.validateEnquiryLeadAssignment(assignee, lead.Property.Id);
                            if (isValidated)
                            {
                                lead.Assignee = assignee;
                                lead.AssignedDate = DateUtil.getUserLocalDateTime();
                                lead.UpdateDate = DateUtil.getUserLocalDateTime();
                                lead.UpdateUser = userDefDTO.Username;
                                session.Update(lead);
                                LeadActivity activity = CommonUtil.getLeadActivityAction(tmpLeadDTO.LeadId, EnqActivityType.ASSIGNMENT,
                                            DateUtil.getUserLocalDateTime(), userDefDTO, CommonUIConverter.getCustomerFullName(lead.Assignee.FirstName, lead.Assignee.LastName));
                                session.Save(activity);
                                activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
                                session.Update(activity);
                                //If Assignee is different than logged in user who assigned leads then add notification to assignee.
                                if (userDefDTO.FirmMember.Id != assignee.Id) {
                                	NotificationSubType subType = NotificationSubType.NEW_LEAD_ASSIGNED;
                                	Notification notification = NotificationUtil.getAlertNotification(userDefDTO,
                                        NotificationUtil.createNotificationAlertMessage(subType, lead.LeadRefNo), DateUtil.getUserLocalDateTime(), 
                                        subType, NotificationUtil.createNotificationAlertRefEntityInfo(subType, lead.Id.ToString()), assignee.User.Username, null);
                                	session.Save(notification);
                                	notificationAlertList.Add(DomainToDTOUtil.convertToNotificationDTO(notification, true));
                                }
                            }
                            else throw new CustomException("User does not have access to current property or user is not active.");
                        }
                        tx.Commit();
                    }
                    catch (CustomException e)
                    {
                        throw e;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Assigning bulk Leads:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
                //Add notifications for assgined user in Cache
                if(notificationAlertList.Count > 0) {
                	string key = NotificationUtil.getNotificationUserKey(notificationAlertList[0].UserName, CommonUtil.getCurrentPropertyDTO(userDefDTO).Id);
                	NotificationCacheProvider.Instance.addNotifications(key, notificationAlertList);
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void ReAssignLead(long leadId, long assigneeId, DateTime assignedDate, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            Dictionary<string, List<NotificationDTO>> notificatonDict = new Dictionary<string, List<NotificationDTO>>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        FirmMember assignee = session.Get<FirmMember>(assigneeId);
                        LeadDetail lead = session.Get<LeadDetail>(leadId);
                        FirmMember previousAssignee = lead.Assignee;
                        if (CommonValidations.validateEnquiryLeadAssignment(assignee, lead.Property.Id))
                        {
                            lead.Assignee = assignee;
                            lead.AssignedDate = assignedDate;
                            lead.UpdateDate = DateUtil.getUserLocalDateTime();
                            lead.UpdateUser = userDefDTO.Username;
                            session.Update(lead);
                            LeadActivity activity = CommonUtil.getLeadActivityAction(leadId, EnqActivityType.RE_ASSIGNMENT,
                                        assignedDate, userDefDTO, CommonUIConverter.getCustomerFullName(lead.Assignee.FirstName, lead.Assignee.LastName));
                            session.Save(activity);
                            activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
                            session.Update(activity);
                            
                            //If Assignee is different than logged in user who assigned lead then add notification to assignee.
                            if (userDefDTO.FirmMember.Id != previousAssignee.Id) {
                            	NotificationSubType subType = NotificationSubType.LEAD_REASSIGNED_USER;
                            	Notification notification = NotificationUtil.getAlertNotification(userDefDTO,
                                    NotificationUtil.createNotificationAlertMessage(subType, lead.LeadRefNo,
                                        CommonUIConverter.getCustomerFullName(assignee.FirstName, assignee.LastName)), DateUtil.getUserLocalDateTime(),
                                    subType, NotificationUtil.createNotificationAlertRefEntityInfo(subType, lead.Id.ToString()), previousAssignee.User.Username, null);
                            	session.Save(notification);
                                string key = NotificationUtil.getNotificationUserKey(notification.UserName, CommonUtil.getCurrentPropertyDTO(userDefDTO).Id);
                                NotificationUtil.addToNotificationDict(notificatonDict, key, DomainToDTOUtil.convertToNotificationDTO(notification, true));
                            }
                            
                            if (userDefDTO.FirmMember.Id != assignee.Id) {
                            	NotificationSubType subType = NotificationSubType.LEAD_REASSIGNED_SELF;
                            	Notification notification = NotificationUtil.getAlertNotification(userDefDTO,
                                    NotificationUtil.createNotificationAlertMessage(subType, lead.LeadRefNo), DateUtil.getUserLocalDateTime(), 
                                    subType, NotificationUtil.createNotificationAlertRefEntityInfo(subType, lead.Id.ToString()), assignee.User.Username, null);
                            	session.Save(notification);
                                string key = NotificationUtil.getNotificationUserKey(notification.UserName, CommonUtil.getCurrentPropertyDTO(userDefDTO).Id);
                                NotificationUtil.addToNotificationDict(notificatonDict, key, DomainToDTOUtil.convertToNotificationDTO(notification, true));
                            }
                            tx.Commit();
                        }
                        else throw new CustomException("User does not have access to current property or user is not active.");
                    }
                    catch (CustomException e)
                    {
                        throw e;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Reassigning Lead:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
                //Add notifications in Cache
                if (notificatonDict.Count > 0)
                {
                    NotificationCacheProvider.Instance.addNotifications(notificatonDict);
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void ReAssignAllLeads(List<UserLeadHistoryUIDTO> selectedLeadList, long assigneeId, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            Dictionary<string, List<NotificationDTO>> notificatonDict = new Dictionary<string, List<NotificationDTO>>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        bool isValidated = false;
                        FirmMember assignee = session.Get<FirmMember>(assigneeId);
                        foreach (UserLeadHistoryUIDTO tmpLeadDTO in selectedLeadList)
                        {
                            LeadDetail lead = session.Get<LeadDetail>(tmpLeadDTO.LeadId);
                            FirmMember previousAssignee = lead.Assignee;
                            if(!isValidated) isValidated = CommonValidations.validateEnquiryLeadAssignment(assignee, lead.Property.Id);
                            if (isValidated)
                            {
                                lead.Assignee = assignee;
                                lead.AssignedDate = DateUtil.getUserLocalDateTime();
                                lead.UpdateDate = DateUtil.getUserLocalDateTime();
                                lead.UpdateUser = userDefDTO.Username;
                                session.Update(lead);
                                LeadActivity activity = CommonUtil.getLeadActivityAction(tmpLeadDTO.LeadId, EnqActivityType.RE_ASSIGNMENT,
                                            DateUtil.getUserLocalDateTime(), userDefDTO, CommonUIConverter.getCustomerFullName(lead.Assignee.FirstName, lead.Assignee.LastName));
                                session.Save(activity);
                                activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
                                session.Update(activity);
                                //Create Notifications for Previous Assignee
                                if (userDefDTO.FirmMember.Id != previousAssignee.Id && userDefDTO.FirmMember.Id != assignee.Id)
                                {
                                	NotificationSubType subType = NotificationSubType.LEAD_REASSIGNED_USER;
                                    Notification notification = NotificationUtil.getAlertNotification(userDefDTO,
                                        NotificationUtil.createNotificationAlertMessage(subType, lead.LeadRefNo,
                                        		CommonUIConverter.getCustomerFullName(assignee.FirstName, assignee.LastName)), DateUtil.getUserLocalDateTime(),
                                        subType, NotificationUtil.createNotificationAlertRefEntityInfo(subType, lead.Id.ToString()), previousAssignee.User.Username, null);
                                    session.Save(notification);
                                    string key = NotificationUtil.getNotificationUserKey(notification.UserName, CommonUtil.getCurrentPropertyDTO(userDefDTO).Id);
                                    NotificationUtil.addToNotificationDict(notificatonDict, key, DomainToDTOUtil.convertToNotificationDTO(notification, true));
                                }
                                if (userDefDTO.FirmMember.Id != assignee.Id)
                                {
                                	NotificationSubType subType = NotificationSubType.LEAD_REASSIGNED_SELF;
                                    Notification notification = NotificationUtil.getAlertNotification(userDefDTO,
                                        NotificationUtil.createNotificationAlertMessage(subType, lead.LeadRefNo), DateUtil.getUserLocalDateTime(),
                                        subType, NotificationUtil.createNotificationAlertRefEntityInfo(subType, lead.Id.ToString()), assignee.User.Username, null);
                                    session.Save(notification);
                                    string key = NotificationUtil.getNotificationUserKey(notification.UserName, CommonUtil.getCurrentPropertyDTO(userDefDTO).Id);
                                    NotificationUtil.addToNotificationDict(notificatonDict, key, DomainToDTOUtil.convertToNotificationDTO(notification, true));
                                }
                            }
                            else throw new CustomException("User does not have access to current property or user is not active.");
                        }
                        tx.Commit();
                    }
                    catch (CustomException e)
                    {
                        throw e;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Reassigning Lead:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
                //Add notifications in Cache
                if (notificatonDict.Count > 0)
                {
                    NotificationCacheProvider.Instance.addNotifications(notificatonDict);
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void closeEnquiry(long enquiryId, string reason, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            NotificationDTO notificationAlertDTO = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EnquiryDetail enquiry = session.Get<EnquiryDetail>(enquiryId);
                        if (enquiry.Status != EnquiryStatus.Open) throw new CustomException(Resources.Messages.ERROR_ENQUIRY_CLOSE_NOT_OPEN);
                        
                        string hqlActivityUpdate = "update EnquiryActivity ea set ea.Status = :status where ea.Id in (select e.id from EnquiryActivity e where "
                                + " e.EnquiryDetail.Id = :EnquiryId) and ea.Status = :openStatus";
                        session.CreateQuery(hqlActivityUpdate)
                                .SetEnum("status", EnqLeadActivityStatus.Deferred)
                                .SetEnum("openStatus", EnqLeadActivityStatus.Open)
                                .SetInt64("EnquiryId", enquiryId)
                                .ExecuteUpdate();
                        
                        enquiry.Status = EnquiryStatus.Lost;
                        enquiry.DateClosed = DateUtil.getUserLocalDate();
                        enquiry.UpdateDate = DateUtil.getUserLocalDateTime();
                        enquiry.UpdateUser = userDefDTO.Username;
                        session.Update(enquiry);
                        EnquiryActivity activity = CommonUtil.getEnquiryActivityAction(enquiryId, EnqActivityType.LOST, DateUtil.getUserLocalDateTime(), userDefDTO, "");
                        activity.Comments = reason;
                        session.Save(activity);
                        activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
                        session.Update(activity);
                        FirmMember assignee = enquiry.Assignee;
                        if (userDefDTO.FirmMember.Id != assignee.Id) {
                        	NotificationSubType subType = NotificationSubType.ENQUIRY_CLOSED_USER;
                        	Notification notification = NotificationUtil.getAlertNotification(userDefDTO,
                                NotificationUtil.createNotificationAlertMessage(subType, enquiry.EnquiryRefNo,
                                		CommonUIConverter.getCustomerFullName(assignee.FirstName, assignee.LastName)), DateUtil.getUserLocalDateTime(), subType, 
                                NotificationUtil.createNotificationAlertRefEntityInfo(subType, enquiry.Id.ToString()), assignee.User.Username, null);
                        	session.Save(notification);
                            notificationAlertDTO = DomainToDTOUtil.convertToNotificationDTO(notification, true);
                        }
                        tx.Commit();
                    }
                    catch (CustomException e)
                    {
                        throw e;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while making Enquiry Close:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
                //Add notifications in Cache
                if (notificationAlertDTO != null)
                {
                	string key = NotificationUtil.getNotificationUserKey(notificationAlertDTO.UserName, CommonUtil.getCurrentPropertyDTO(userDefDTO).Id);
                    NotificationCacheProvider.Instance.addNotification(key, notificationAlertDTO);
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void closeLead(long leadId, string reason, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            NotificationDTO notificationAlertDTO = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        LeadDetail lead = session.Get<LeadDetail>(leadId);
                        if (lead.Status != LeadStatus.Open) throw new CustomException(Resources.Messages.ERROR_LEAD_CLOSE_NOT_OPEN);
                        
                        string hqlActivityUpdate = "update LeadActivity la set la.Status = :status where la.Id in (select l.id from LeadActivity l where "
                                + " l.LeadDetail.Id = :LeadId) and la.Status = :openStatus";
                        session.CreateQuery(hqlActivityUpdate)
                                .SetEnum("status", EnqLeadActivityStatus.Deferred)
                                .SetEnum("openStatus", EnqLeadActivityStatus.Open)
                                .SetInt64("LeadId", leadId)
                                .ExecuteUpdate();

                        lead.Status = LeadStatus.Lost;
                        lead.DateClosed = DateUtil.getUserLocalDateTime();
                        lead.UpdateDate = DateUtil.getUserLocalDateTime();
                        lead.UpdateUser = userDefDTO.Username;
                        session.Update(lead);
                        LeadActivity activity = CommonUtil.getLeadActivityAction(leadId, EnqActivityType.LOST, DateUtil.getUserLocalDateTime(), userDefDTO, "");
                        activity.Comments = reason;
                        session.Save(activity);
                        activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
                        session.Update(activity);
                        FirmMember assignee = lead.Assignee;
                        if (userDefDTO.FirmMember.Id != assignee.Id) {
                        	NotificationSubType subType = NotificationSubType.LEAD_CLOSED_USER;
                        	Notification notification = NotificationUtil.getAlertNotification(userDefDTO,
                                NotificationUtil.createNotificationAlertMessage(subType, lead.LeadRefNo,
                                		CommonUIConverter.getCustomerFullName(assignee.FirstName, assignee.LastName)), DateUtil.getUserLocalDateTime(), subType, 
                                NotificationUtil.createNotificationAlertRefEntityInfo(subType, lead.Id.ToString()), assignee.User.Username, null);
                        	session.Save(notification);
                            notificationAlertDTO = DomainToDTOUtil.convertToNotificationDTO(notification, true);
                        }
                        tx.Commit();
                    }
                    catch (CustomException e)
                    {
                        throw e;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while making Lead Close:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
                //Add notifications in Cache
                if (notificationAlertDTO != null)
                {
                	string key = NotificationUtil.getNotificationUserKey(notificationAlertDTO.UserName, CommonUtil.getCurrentPropertyDTO(userDefDTO).Id);
                    NotificationCacheProvider.Instance.addNotification(key, notificationAlertDTO);
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void reOpenEnquiry(long enquiryId, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            NotificationDTO notificationAlertDTO = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EnquiryDetail enquiry = session.Get<EnquiryDetail>(enquiryId);
                        if (enquiry.Status != EnquiryStatus.Lost) throw new CustomException(Resources.Messages.ERROR_ENQUIRY_REOPEN_NOT_CLOSED);
                        else if (enquiry.PrUnitSaleDetail != null && enquiry.PrUnitSaleDetail.Id > 0) throw new CustomException(Resources.Messages.ERROR_ENQUIRY_REOPEN_UNIT_BOOKED);
                        
                        enquiry.Status = EnquiryStatus.Open;
                        enquiry.DateClosed = null;
                        enquiry.UpdateDate = DateUtil.getUserLocalDateTime();
                        enquiry.UpdateUser = userDefDTO.Username;
                        session.Update(enquiry);
                        EnquiryActivity activity = CommonUtil.getEnquiryActivityAction(enquiryId, EnqActivityType.RE_OPENED,  DateUtil.getUserLocalDateTime(), userDefDTO, "");
                        session.Save(activity);
                        activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
                        session.Update(activity);
                        FirmMember assignee = enquiry.Assignee;
                        if (userDefDTO.FirmMember.Id != assignee.Id) {
                        	NotificationSubType subType = NotificationSubType.ENQUIRY_REOPEN_USER;
                        	Notification notification = NotificationUtil.getAlertNotification(userDefDTO,
                                NotificationUtil.createNotificationAlertMessage(subType, enquiry.EnquiryRefNo,
                                		CommonUIConverter.getCustomerFullName(assignee.FirstName, assignee.LastName)), DateUtil.getUserLocalDateTime(), subType, 
                                NotificationUtil.createNotificationAlertRefEntityInfo(subType, enquiry.Id.ToString()), assignee.User.Username, null);
                        	session.Save(notification);
                            notificationAlertDTO = DomainToDTOUtil.convertToNotificationDTO(notification, true);
                        }
                        tx.Commit();
                    }
                    catch (CustomException e)
                    {
                        throw e;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while making Enquiry reopen:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
                //Add notifications in Cache
                if (notificationAlertDTO != null)
                {
                	string key = NotificationUtil.getNotificationUserKey(notificationAlertDTO.UserName, CommonUtil.getCurrentPropertyDTO(userDefDTO).Id);
                    NotificationCacheProvider.Instance.addNotification(key, notificationAlertDTO);
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public IList<VwEnquiryLead> fetchDuplicateEnquiryOrLead(long propertyId, string contact, string altContact)
        {
            ISession session = null;
            IList<VwEnquiryLead> enqLeadList = null;
            try
            {
            	string tmpContact = CommonUtil.getActualContact(contact);
            	string tmpAltContact = CommonUtil.getActualContact(altContact);
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	VwEnquiryLead vw = null;
                    	var query = session.QueryOver<VwEnquiryLead>(() => vw).Where(() => vw.PropertyId == propertyId && vw.Status == "O");

                    	ICriteria criteria = query.RootCriteria;
                    	var disjunctions = Restrictions.Disjunction()
	            	                           .Add(Restrictions.Where<VwEnquiryLead>(x => x.Contact.IsLike(tmpContact, MatchMode.End)))
	            	                           .Add(Restrictions.Where<VwEnquiryLead>(x => x.AltContact.IsLike(tmpContact, MatchMode.End)));
                    	if(!string.IsNullOrWhiteSpace(tmpAltContact)) {
                            disjunctions.Add(Restrictions.Where<VwEnquiryLead>(x => x.Contact.IsLike(tmpAltContact, MatchMode.End)))
                                .Add(Restrictions.Where<VwEnquiryLead>(x => x.AltContact.IsLike(tmpAltContact, MatchMode.End)));
                    	}
                    	enqLeadList = query.Where(disjunctions).List<VwEnquiryLead>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching duplicate enquiry or lead for given contacts:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return enqLeadList;
        }
    }
}