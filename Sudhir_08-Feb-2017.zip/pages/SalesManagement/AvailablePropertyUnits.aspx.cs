﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using CrystalDecisions.CrystalReports.Engine;
using System.Data;

public partial class AvailablePropertyUnits : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string tab1ValidationGrp = "tab1Error";
    string tab3BzStep1Error = "tab3BzStep1Error";
    string tab3BzStep2Error = "tab3BzStep2Error";
    string tab3BzStep1 = "bzstep1";
    string tab3BzStep2 = "bzstep2";
    string VS_PROPERTY_UNIT_LIST = "PROPERTY_UNIT_LIST";
    string VS_MASTER_PROPERTY_UNIT_LIST = "ALL_PROPERTY_UNIT_LIST";
    string VS_SELECTED_UNIT = "SELECTED_PROPERTY_UNIT";
    string VS_BOOK_UNIT = "BOOK_UNIT";
    DropdownBO drpBO = new DropdownBO();
    PropertyBO propertyBO = new PropertyBO();
    AvailablePropertyUnitBO availableUnitBO = new AvailablePropertyUnitBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    DepartmentBO departmentBO = new DepartmentBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (Session[Constants.Session.USERNAME] != null)
            {
                resetTabInfo(PageMode.NONE);
                initDropdowns();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        QuotationViewer.ReportSource = (ReportDocument)Session["QuotationReport"];
        QuotationViewer.RefreshReport();
        QuotationViewer.DataBind();
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpSelectProperty, DrpDataType.PROPERTY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<AvailableUnitSearchBy>(drpSearchBy, null);
        drpBO.drpDataBase(drpCustomer, DrpDataType.CUSTOMER_SEARCH_BY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpEmployee, DrpDataType.EMPLOYEE_SEARCH_BY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        applyEntitlement();
        preRenderInitFormElements();
        initBootstrapComponantsFromServer();
    }
    private bool isViewOnlyUser()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        bool isViewOnlyUser = !CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.FIRM_MEMBER_ADD_UPDATE);
        return isViewOnlyUser;
    }
    private void applyEntitlement()
    {
        if (isViewOnlyUser())
        {
            btnBookAvailableUnits.Visible = false;
        }
    }
    private void preRenderInitFormElements()
    {
        PropertyUnitDTO propertyUnitDto = getCurrentPropertyUnit();
        PrUnitSaleDetailDTO prUnitSaleDetailDto = getCurrentPropertyUnitSale();
        jumpToAvailableUnitsHdnId.Value = "";
        jumpToTaxDetailHdnId.Value = "";
        jumpToCMTaxDetailHdnId.Value = "";
        if (propertyUnitDto != null)
        {
            jumpToAvailableUnitsHdnId.Value = propertyUnitDto.Id.ToString();
            if (prUnitSaleDetailDto != null && prUnitSaleDetailDto.uiTaxDetails != null && prUnitSaleDetailDto.uiTaxDetails.Count > 0)
            {
                PrUnitSaleTaxDetailDTO prUnitSaleTaxDetailDto = prUnitSaleDetailDto.uiTaxDetails.Find(a => a.isUISelected);
                if (prUnitSaleTaxDetailDto != null) jumpToTaxDetailHdnId.Value = prUnitSaleTaxDetailDto.UiIndex.ToString();
            }
            if (prUnitSaleDetailDto != null && prUnitSaleDetailDto.uiCMTaxDetails != null && prUnitSaleDetailDto.uiCMTaxDetails.Count > 0)
            {
                PrUnitSaleTaxDetailDTO prUnitSaleTaxDetailDto = prUnitSaleDetailDto.uiCMTaxDetails.Find(a => a.isUISelected);
                if (prUnitSaleTaxDetailDto != null) jumpToCMTaxDetailHdnId.Value = prUnitSaleTaxDetailDto.UiIndex.ToString();
            }
        }
        if (PageMode.VIEW.ToString() == pageModeHdn.Value)
        {
            populateUIFieldsFromUnitDTO(getCurrentPropertyUnit());
        }
        else if (PageMode.ADD.ToString() == pageModeHdn.Value)
        {
            populateTab3UnitInfoSection(getCurrentPropertyUnitSale());
        }
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        if (group.Equals(tab3BzStep1Error)) tab3ContentBzHdn.Value = tab3BzStep1;
        else if (group.Equals(tab3BzStep2Error)) tab3ContentBzHdn.Value = tab3BzStep2;
    }

    public void setSuccessMessage(string msg, string tabId, string bzStep)
    {
        activeTabHdn.Value = tabId;
        if (tabId.Equals(tab1Anchor.ID))
        {
            lbTab1Success.Text = msg;
            tab1SuccessPanel.Visible = true;
        }
        else if (tabId.Equals(tab3Anchor.ID))
        {
            if (tab3BzStep1.Equals(bzStep))
            {
                lbTab3BzStep1Success.Text = msg;
                tab3BzStep1SuccessPanel.Visible = true;
                tab3ContentBzHdn.Value = tab3BzStep1;
            }
            else
            {
                lbTab3BzStep2Success.Text = msg;
                tab3BzStep2SuccessPanel.Visible = true;
                tab3ContentBzHdn.Value = tab3BzStep2;
            }
        }
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private void clearMessages()
    {
        tab1SuccessPanel.Visible = false;
        lbTab1Success.Text = "";
        tab3BzStep1SuccessPanel.Visible = false;
        lbTab3BzStep1Success.Text = "";
        tab3BzStep2SuccessPanel.Visible = false;
        lbTab3BzStep2Success.Text = "";
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }

    private void resetTabInfo(PageMode pageMode)
    {
        pageModeHdn.Value = pageMode.ToString();
        initFormFields();
        pnlTaxDetailAdd.Visible = false;
        pnlCMTaxDetailAdd.Visible = false;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        tab3ContentBzHdn.Value = "";
        tab2Anchor.Visible = false;
        tab3Anchor.Visible = false;
        tab4Anchor.Visible = false;
        if (PageMode.ADD == pageMode)
        {
            tab3ContentBzHdn.Value = tab3BzStep1;
            activeTabHdn.Value = tab3Anchor.ID;
            tab3Anchor.Visible = true;
            initFormFields();
        }
        else if (PageMode.VIEW == pageMode)
        {
            activeTabHdn.Value = tab2Anchor.ID;
            tab2Anchor.Visible = true;
            ViewState[VS_BOOK_UNIT] = null;
            initFormFields();
        }
        else if (PageMode.GETQUOTE == pageMode)
        {
            activeTabHdn.Value = tab4Anchor.ID;
            tab4Anchor.Visible = true;
            ViewState[VS_BOOK_UNIT] = null;
            initFormFields();
        }
        else
        {
            activeTabHdn.Value = tab1Anchor.ID;
            ViewState[VS_SELECTED_UNIT] = null;
            ViewState[VS_BOOK_UNIT] = null;
        }
    }
    private void initFormFields()
    {
        
    }
    private List<PropertyUnitDTO> getMatserAvailableUnits()
    {
        return (List<PropertyUnitDTO>)ViewState[VS_MASTER_PROPERTY_UNIT_LIST];
    }
    private List<PropertyUnitDTO> getCurrentGridAvailableUnits()
    {
        return (List<PropertyUnitDTO>)ViewState[VS_PROPERTY_UNIT_LIST];
    }
    private PrUnitSaleDetailDTO getCurrentPropertyUnitSale()
    {
        return (PrUnitSaleDetailDTO)ViewState[VS_BOOK_UNIT];
    }
    private PropertyUnitDTO getCurrentPropertyUnit()
    {
        return (PropertyUnitDTO)ViewState[VS_SELECTED_UNIT];
    }
    private void setSelectedPropertyUnit(long selectedId)
    {
        List<PropertyUnitDTO> propertyUnitList = getCurrentGridAvailableUnits();
        if (propertyUnitList != null)
        {
            propertyUnitList.ForEach(c => c.isUISelected = false);
            if (selectedId > 0) propertyUnitList.Find(c => c.Id == selectedId).isUISelected = true;
        }
    }
    private bool validatePropertyUnitSelected()
    {
        bool isSelected = true;
        List<PropertyUnitDTO> propertyUnitList = getCurrentGridAvailableUnits();
        if (propertyUnitList != null)
        {
            isSelected = propertyUnitList.Any(c => c.isUISelected);
            if (!isSelected)
            {
                resetTabInfo(PageMode.NONE);
                setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Property Unit"), tab1ValidationGrp);
            }
        }
        return isSelected;
    }
    private void selectPropertyUnitGridRdBtn(long Id)
    {
        if (availableUnitsGrid.Rows.Count > 0)
        {
            setSelectedPropertyUnit(0);
            foreach (GridViewRow row in availableUnitsGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdAvailableUnitsSelect");
                Button rowIdenBtn = (Button)row.FindControl("btnAviailUnitRowIdentifier");
                if (radioBtn != null)
                {
                    radioBtn.Checked = false;
                    if (rowIdenBtn != null && Id > 0 && Id.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                    {
                        radioBtn.Checked = true;
                        setSelectedPropertyUnit(Id);
                    }
                }
            }
        }
    }
    private void loadSearchGridAndReSelect(long Id)
    {
        try
        {
            List<PropertyUnitDTO> matserList = (List<PropertyUnitDTO>)getMatserAvailableUnits();
            List<PropertyUnitDTO> filterResults = new List<PropertyUnitDTO>(matserList);
            AvailableUnitSearchBy searchBy = EnumHelper.ToEnum<AvailableUnitSearchBy>(drpSearchBy.Text);
            if (!string.IsNullOrWhiteSpace(drpSearchByValue.Text))
            {
                if (AvailableUnitSearchBy.PROPERTY_UNIT == searchBy)
                {
                    filterResults = matserList.FindAll(u => u.Id == long.Parse(drpSearchByValue.Text));
                }
                else if (AvailableUnitSearchBy.UNIT_TYPE == searchBy)
                {
                    filterResults = matserList.FindAll(u => u.UnitType.Id == long.Parse(drpSearchByValue.Text));
                }
                else if (AvailableUnitSearchBy.FLOOR == searchBy)
                {
                    filterResults = matserList.FindAll(u => u.FloorNo == drpSearchByValue.Text);
                }
                else if (AvailableUnitSearchBy.FACING == searchBy)
                {
                    filterResults = matserList.FindAll(u => u.Facing.Id == long.Parse(drpSearchByValue.Text));
                }
                else if (AvailableUnitSearchBy.DIRECTION == searchBy)
                {
                    filterResults = matserList.FindAll(u => u.Direction.Id == long.Parse(drpSearchByValue.Text));
                }
            }
            ViewState[VS_PROPERTY_UNIT_LIST] = filterResults;
            availableUnitsGrid.DataSource = filterResults;
            availableUnitsGrid.DataBind();
            if (Id > 0)
            {
                selectPropertyUnitGridRdBtn(Id);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private void fetchAvailableUnits() {
        try
        {
            List<PropertyUnitDTO> results = new List<PropertyUnitDTO>();
            if (!(string.IsNullOrWhiteSpace(drpSelectProperty.Text) || string.IsNullOrWhiteSpace(drpSelectPropertyTower.Text))) {
                long propertyId = long.Parse(drpSelectProperty.Text);
                long towerId = long.Parse(drpSelectPropertyTower.Text);
                results = availableUnitBO.fetchAvailablePropertyUnits(getUserDefinitionDTO().FirmNumber, towerId);
            }
            ViewState[VS_MASTER_PROPERTY_UNIT_LIST] = results;
            ViewState[VS_PROPERTY_UNIT_LIST] = results;
            availableUnitsGrid.DataSource = results;
            availableUnitsGrid.DataBind();
            selectPropertyUnitGridRdBtn(0);
        } 
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private void fetchSelectedPropertyUnit()
    {
        try
        {
            long Id = getCurrentGridAvailableUnits().Find(c => c.isUISelected).Id;
            bool isBooking = PageMode.ADD.ToString().Equals(pageModeHdn.Value);
            PropertyUnitDTO propertyUnitDto = propertyBO.fetchPropertyUnitWithParent(Id, isBooking);
            ViewState[VS_SELECTED_UNIT] = propertyUnitDto;
            if (isBooking)
            {
                PrUnitSaleDetailDTO prUnitSaleDetailDto = populatePrUnitSaleDetailDTOAdd();
                ViewState[VS_BOOK_UNIT] = prUnitSaleDetailDto;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSelectProperty(object sender, EventArgs e)
    {
        try
        {
            resetTabInfo(PageMode.NONE);
            drpBO.drpDataBase(drpSelectPropertyTower, DrpDataType.PROPERTY_TOWER, drpSelectProperty.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            pnlAvailableUnitGrid.Visible = (drpSelectPropertyTower.Items.Count > 1);
            if (drpSelectPropertyTower.Items.Count == 2)
            {
                drpSelectPropertyTower.Items[1].Selected = true;
            }
            fetchAvailableUnits();
        } 
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSelectPropertyTower(object sender, EventArgs e)
    {
        try
        {
            resetTabInfo(PageMode.NONE);
            pnlAvailableUnitGrid.Visible = !string.IsNullOrWhiteSpace(drpSelectPropertyTower.Text);
            fetchAvailableUnits();
        } 
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSearchBy(object sender, EventArgs e)
    {
        try
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            AvailableUnitSearchBy searchBy = EnumHelper.ToEnum<AvailableUnitSearchBy>(drpSearchBy.Text);
            drpSearchByValue.Visible = true;
            lbSearchByValue.Visible = true;
            lbSearchByValue.Text = EnumHelper.GetEnumDescription<AvailableUnitSearchBy>(searchBy.ToString());
            if (AvailableUnitSearchBy.PROPERTY_UNIT == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.AVAIL_UNIT_SEARCH_BY_PR_UNIT, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else if (AvailableUnitSearchBy.UNIT_TYPE == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else if (AvailableUnitSearchBy.FLOOR == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.PROPERTY_UNIT_FLOOR, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else if (AvailableUnitSearchBy.FACING == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_FACING, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else if (AvailableUnitSearchBy.DIRECTION == searchBy)
            {
                drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_DIRECTION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            }
            else
            {
                drpSearchByValue.ClearSelection();
                drpSearchByValue.Visible = false;
                lbSearchByValue.Visible = false;
            }
            loadSearchGridAndReSelect(0);
            resetTabInfo(PageMode.NONE);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSearchByValue(object sender, EventArgs e)
    {
        loadSearchGridAndReSelect(0);
        resetTabInfo(PageMode.NONE);
    }
    protected void onSelectAvailableUnit(object sender, EventArgs e)
    {
        try
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            resetTabInfo(PageMode.NONE);
            if (rd.Checked)
            {
                string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnAviailUnitRowIdentifier"))).Attributes["row-identifier"];
                setSelectedPropertyUnit(long.Parse(strId));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickViewAvailableUnitsBtn(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyUnitSelected())
            {
                resetTabInfo(PageMode.VIEW);
                fetchSelectedPropertyUnit();
                populateUIFieldsFromUnitDTO(getCurrentPropertyUnit());
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickBookAvailableUnitsBtn(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyUnitSelected())
            {
                resetTabInfo(PageMode.ADD);
                fetchSelectedPropertyUnit();
                populateUIFieldsFromSaleUnitDTO(getCurrentPropertyUnitSale());
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickGetQuoteAvailableUnitsBtn(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyUnitSelected())
            {
                resetTabInfo(PageMode.GETQUOTE);
                long Id = getCurrentGridAvailableUnits().Find(c => c.isUISelected).Id;
                generateQuotation(Id);

            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }

    public void generateQuotation(long UnitId)
    {
        PropertyBO propertyBO = new PropertyBO();
        FirmBO firmBO = new FirmBO();

        PropertyUnitDTO propertyUnitDto = propertyBO.fetchPropertyUnitWithParent(UnitId, true);
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        FirmDTO firmDto = firmBO.fetchFirmDetails(userDefDto.FirmNumber);
        PropertyDTO propertyDTO = propertyBO.fetchProperty(propertyUnitDto.PropertyTower.Property.Id);
        lbQuotationHeader.Text = "Quotation for Unit " + CommonUIConverter.getPropertyUnitFormattedNo(propertyUnitDto.Wing, propertyUnitDto.UnitNo);

        DataTable PropertyUnit = new DataTable();
        DataRow prUnitRow = PropertyUnit.NewRow();
        populatePropertyUnit(propertyUnitDto, firmDto, propertyDTO, PropertyUnit, prUnitRow);

        DataTable PropertyTax = new DataTable();
        PropertyDTO propertyDto = populatePropertyTax(propertyUnitDto, PropertyTax);

        DataTable PropertyPymtSchd = new DataTable();
        populatePropertySchd(propertyUnitDto, PropertyPymtSchd);

        DataTable PropertyCharge = new DataTable();
        populatePropertyCharges(propertyDTO, PropertyCharge);

        ReportDocument quotationReportDocument = new ReportDocument();
        string reportPath = Server.MapPath("Reports//Quotation//UnitQuotation.rpt");
        quotationReportDocument.Load(reportPath);
        quotationReportDocument.Database.Tables["PropertyUnit"].SetDataSource(PropertyUnit);
        quotationReportDocument.Subreports["PropertyCharges"].SetDataSource(PropertyCharge);
        quotationReportDocument.Subreports["PropertyTaxes"].SetDataSource(PropertyTax);
        quotationReportDocument.Subreports["PROPERTYPAYSCHD"].SetDataSource(PropertyPymtSchd);
        Session["QuotationReport"] = quotationReportDocument;
        QuotationViewer.ReportSource = quotationReportDocument;
        QuotationViewer.Zoom(100);
    }
    private static void populatePropertyCharges(PropertyDTO propertyDto, DataTable PropertyCharge)
    {
        PropertyCharge.Columns.Add("ChargeType", typeof(string));
        PropertyCharge.Columns.Add("ChargeValue", typeof(string));

        if (propertyDto.PropertyCharges != null && propertyDto.PropertyCharges.Count > 0)
        {
            foreach (PropertyChargeDTO propertyChargeDTO in propertyDto.PropertyCharges)
            {
                DataRow chargeRow = PropertyCharge.NewRow();
                chargeRow["ChargeType"] = propertyChargeDTO.ChargeType.Name;
                chargeRow["ChargeValue"] = Convert.ToDecimal(propertyChargeDTO.ChargeValue);
                PropertyCharge.Rows.Add(chargeRow);
            }
        }
        else
        {
            DataRow chargeRow = PropertyCharge.NewRow();
            PropertyCharge.Rows.Add(chargeRow);
        }
    }

    private static void populatePropertySchd(PropertyUnitDTO propertyUnitDto, DataTable PropertyPymtSchd)
    {
        List<PropertyScheduleDTO> propertySchdList = null;
        PropertyPymtSchd.Columns.Add("STAGE", typeof(string));
        PropertyPymtSchd.Columns.Add("PERCENTAGE", typeof(decimal));
        PropertyPymtSchd.Columns.Add("STATUS", typeof(string));
        PropertyPymtSchd.Columns.Add("STAGE_NUMBER", typeof(Int32));
        if (propertyUnitDto.PropertyTower.PropertySchedules != null)
        {
            propertySchdList = propertyUnitDto.PropertyTower.PropertySchedules.ToList();
        }
        if (propertySchdList != null && propertySchdList.Count() > 0)
        {
            foreach (PropertyScheduleDTO propertySchdDto in propertySchdList)
            {
                DataRow stageRow = PropertyPymtSchd.NewRow();
                stageRow["STAGE"] = propertySchdDto.Stage.ToString();
                stageRow["PERCENTAGE"] = propertySchdDto.Percentage;
                stageRow["STATUS"] = propertySchdDto.Status.ToString();
                stageRow["STAGE_NUMBER"] = propertySchdDto.StageNumber;
                PropertyPymtSchd.Rows.Add(stageRow);
            }

        }
        else
        {
            DataRow stageRow = PropertyPymtSchd.NewRow();
            PropertyPymtSchd.Rows.Add(stageRow);
        }
    }

    private static PropertyDTO populatePropertyTax(PropertyUnitDTO propertyUnitDto, DataTable PropertyTax)
    {
        PropertyTax.Columns.Add("TaxType", typeof(string));
        PropertyTax.Columns.Add("TaxPercentage", typeof(string));
        PropertyDTO propertyDto = propertyUnitDto.PropertyTower.Property;
        if (propertyDto.PropertyTaxDetails != null && propertyDto.PropertyTaxDetails.Count > 0)
        {
            foreach (PropertyTaxDetailDTO propertyTaxDetailDto in propertyDto.PropertyTaxDetails)
            {
                if (IncludeInPymtTotal.Yes == propertyTaxDetailDto.IncludeInTotalPymt)
                {
                    DataRow taxRow = PropertyTax.NewRow();

                    taxRow["TaxType"] = propertyTaxDetailDto.TaxType.Name;
                    taxRow["TaxPercentage"] = propertyTaxDetailDto.TaxPercentage.ToString();
                    PropertyTax.Rows.Add(taxRow);
                }
            }
        }
        return propertyDto;
    }

    private static void populatePropertyUnit(PropertyUnitDTO propertyUnitDto, FirmDTO firmDto, PropertyDTO propertyDTO, DataTable PropertyUnit, DataRow prUnitRow)
    {
        PropertyUnit.Columns.Add("PropertyName", typeof(string));
        PropertyUnit.Columns.Add("PropertyAddress", typeof(string));
        PropertyUnit.Columns.Add("PrTowerName", typeof(string));
        PropertyUnit.Columns.Add("PrWing", typeof(string));
        PropertyUnit.Columns.Add("PrFloorNo", typeof(string));
        PropertyUnit.Columns.Add("PrFlatNo", typeof(string));
        PropertyUnit.Columns.Add("BuiltupArea", typeof(decimal));
        PropertyUnit.Columns.Add("CarpetArea", typeof(decimal));
        PropertyUnit.Columns.Add("BookingRate", typeof(decimal));
        PropertyUnit.Columns.Add("FirmName", typeof(string));

        prUnitRow["PropertyName"] = propertyUnitDto.PropertyTower.Property.Name;
        prUnitRow["PrTowerName"] = propertyUnitDto.PropertyTower.Name;
        string address = null;
        if (propertyDTO.ContactInfo.Addresses != null)
        {
            List<AddressDTO> addressList = propertyDTO.ContactInfo.Addresses.ToList();
            AddressDTO addressDTO = addressList[0];
            address = addressDTO.AddressLine1 + " " + addressDTO.AddressLine2 + " " + addressDTO.Town + " "
                + addressDTO.City.Name + " " + addressDTO.State.Name + " " + addressDTO.Country.Name;
        }
        prUnitRow["PropertyAddress"] = address;
        prUnitRow["PrWing"] = propertyUnitDto.Wing;
        prUnitRow["PrFloorNo"] = propertyUnitDto.FloorNo;
        prUnitRow["PrFlatNo"] = propertyUnitDto.UnitNo;
        prUnitRow["BuiltupArea"] = propertyUnitDto.BuildupArea;
        prUnitRow["CarpetArea"] = propertyUnitDto.CarpetArea;
        prUnitRow["BookingRate"] = propertyUnitDto.PropertyTower.Rate;
        prUnitRow["FirmName"] = firmDto.Name;

        PropertyUnit.Rows.Add(prUnitRow);
    }
    protected void bookPropertyUnit(object sender, EventArgs e)
    {
        try
        {
            if (validateBookPropertyUnit())
            {
                long Id = 0;
                PrUnitSaleDetailDTO prUnitSaleDetailDTO = populatePropertySaleDTOFromUI();
                Id = availableUnitBO.bookPropertyUnitDetails(prUnitSaleDetailDTO);
                resetTabInfo(PageMode.NONE);
                string unitName = CommonUIConverter.getPropertyUnitFormattedNo(prUnitSaleDetailDTO.PropertyUnit.Wing, prUnitSaleDetailDTO.PropertyUnit.UnitNo);
                setSuccessMessage(string.Format("Property Unit '{0}' is booked successfully", unitName), tab1Anchor.ID, null);
                fetchAvailableUnits();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab3BzStep1Error);
        }
    }
    protected void cancelTab3Changes(object sender, EventArgs e)
    {
        PropertyUnitDTO propertyUnitDto = getCurrentPropertyUnit();
        resetTabInfo(PageMode.NONE);
        loadSearchGridAndReSelect(propertyUnitDto.Id);
    }
    protected void cancelUnitView(object sender, EventArgs e)
    {
        PropertyUnitDTO propertyUnitDto = getCurrentPropertyUnit();
        resetTabInfo(PageMode.NONE);
        loadSearchGridAndReSelect(propertyUnitDto.Id);
    }
    protected void reCalculateTotal(object sender, EventArgs e)
    {
        PrUnitSaleDetailDTO prUnitSaleDetailTO = getCurrentPropertyUnitSale();
        clearTaxSectionSelection(true);
        clearTaxSectionSelection(false);
        calculateAllSaleAmounts(prUnitSaleDetailTO);
        scrollToFieldHdn.Value = txtAgreementValue.ID;
    }
    protected void gotoTab3StepyWizard(object sender, EventArgs e)
    {
        bool isValid = validateTab3Step(tab3ContentBzHdn.Value);
        if (isValid)
        {
            setCurrentStep(goToStepHdn.Value);
        }
    }
    /**
     * Define all validation which will be done before add or update property.
     * */
    private bool validateBookPropertyUnit()
    {
        bool isValid = validateTab3Step(tab3BzStep1);
        if (!isValid) return false;
        string errorMsg = CommonValidations.validateUnitSaleDates(CommonUtil.getCSDateNotNull(txtBookingDate.Text), CommonUtil.getCSDate(txtPossesionDate.Text), 
            CommonUtil.getCSDate(txtAgreementDate.Text), txtAgreementNo.Text);
        if (!string.IsNullOrWhiteSpace(errorMsg))
        {
            setErrorMessage(errorMsg, tab3BzStep2Error);
            return false;
        }
        decimal agreementValue = CommonUtil.getDecimaNotNulllWithoutExt(txtAgreementValue.Text);
        if (agreementValue <= 0)
        {
            setErrorMessage(Resources.Messages.validation_agreementvalue_required, tab3BzStep1Error);
            return false;
        }
        return true;
    }
    /**
     * Validates given step.
     * */
    private bool validateTab3Step(string step)
    {
        bool isValid = true;
        if (!PageMode.VIEW.ToString().Equals(pageModeHdn.Value))
        {
            if (step.Equals(tab3BzStep1))
            {
                isValid = validateAllStep1Group();
            }
            else if (step.Equals(tab3BzStep2))
            {

            }
        }
        return isValid;
    }
    private bool validateAllStep1Group()
    {
        Page.Validate(tab3BzStep1Error);
        bool isValid = Page.IsValid;
        if (!isValid)
        {
            tab3ContentBzHdn.Value = tab3BzStep1;
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    private void setCurrentStep(string step)
    {
        tab3ContentBzHdn.Value = step;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void calculateAllSaleAmounts(PrUnitSaleDetailDTO prUnitSaleDetailDto) {
        decimal agreementValue = CommonUtil.getDecimaNotNulllWithoutExt(txtAgreementValue.Text);
        decimal totalTax = Decimal.Zero;
        foreach (PrUnitSaleTaxDetailDTO prUnitSaleTaxDetailDto in prUnitSaleDetailDto.uiTaxDetails) {
            decimal tmpPercentage = Decimal.Divide(prUnitSaleTaxDetailDto.TaxPercentage, 100);
            decimal taxAmt = Math.Round(Decimal.Multiply(agreementValue, tmpPercentage), 2);
            if (prUnitSaleTaxDetailDto.TaxAmtLimit > 0 && taxAmt > prUnitSaleTaxDetailDto.TaxAmtLimit) taxAmt = prUnitSaleTaxDetailDto.TaxAmtLimit;
             prUnitSaleTaxDetailDto.TaxAmt = taxAmt;
             totalTax = totalTax + taxAmt;
        }
        txtBookTotalTax.Text = totalTax.ToString();
        txtBookTotalUnitCost.Text = (totalTax + agreementValue).ToString();
        foreach (PrUnitSaleTaxDetailDTO prUnitSaleTaxDetailDto in prUnitSaleDetailDto.uiCMTaxDetails) {
            decimal tmpPercentage = Decimal.Divide(prUnitSaleTaxDetailDto.TaxPercentage, 100);
            decimal taxAmt = Math.Round(Decimal.Multiply(agreementValue, tmpPercentage), 2);
            if (prUnitSaleTaxDetailDto.TaxAmtLimit > 0 && taxAmt > prUnitSaleTaxDetailDto.TaxAmtLimit) taxAmt = prUnitSaleTaxDetailDto.TaxAmtLimit;
            prUnitSaleTaxDetailDto.TaxAmt = taxAmt;
        }
        populateTaxDetailGrid(prUnitSaleDetailDto);
        populateCMTaxDetailGrid(prUnitSaleDetailDto);
    }
    private PrUnitSaleDetailDTO populatePrUnitSaleDetailDTOAdd()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        PropertyUnitDTO propertyUnitDto = getCurrentPropertyUnit();
        PrUnitSaleDetailDTO prUnitSaleDetailDto = new PrUnitSaleDetailDTO();
        prUnitSaleDetailDto.AgreementAmt = Decimal.Zero;
        prUnitSaleDetailDto.BookingDate = DateTime.Today;
        prUnitSaleDetailDto.TotalTaxAmt = Decimal.Zero;
        prUnitSaleDetailDto.TotalPymtAmt = Decimal.Zero;
        prUnitSaleDetailDto.PropertyUnit = propertyUnitDto;
        prUnitSaleDetailDto.uiTaxDetails = new List<PrUnitSaleTaxDetailDTO>();
        prUnitSaleDetailDto.uiCMTaxDetails = new List<PrUnitSaleTaxDetailDTO>();
        PropertyDTO propertyDto = propertyUnitDto.PropertyTower.Property;
        if (propertyDto.PropertyTaxDetails != null && propertyDto.PropertyTaxDetails.Count > 0)
        {
            foreach (PropertyTaxDetailDTO propertyTaxDetailDto in propertyDto.PropertyTaxDetails)
            {
                if(IncludeInPymtTotal.Yes == propertyTaxDetailDto.IncludeInTotalPymt) prUnitSaleDetailDto.uiTaxDetails.Add(populatePrSaleTaxDetail(propertyTaxDetailDto));
                else prUnitSaleDetailDto.uiCMTaxDetails.Add(populatePrSaleTaxDetail(propertyTaxDetailDto));
            }
        }
        
        prUnitSaleDetailDto.FirmNumber = userDefDto.FirmNumber;
        prUnitSaleDetailDto.InsertUser = userDefDto.Username;
        prUnitSaleDetailDto.UpdateUser = userDefDto.Username;
        return prUnitSaleDetailDto;
    }
    private PrUnitSaleTaxDetailDTO populatePrSaleTaxDetail(PropertyTaxDetailDTO propertyTaxDetailDto) {
        PrUnitSaleTaxDetailDTO taxDetailDto = new PrUnitSaleTaxDetailDTO();
        taxDetailDto.TaxType = propertyTaxDetailDto.TaxType;
        taxDetailDto.TaxPercentage = propertyTaxDetailDto.TaxPercentage;
        taxDetailDto.TaxAmtLimit = propertyTaxDetailDto.TaxAmtLimit;
        taxDetailDto.IncludeInTotalPymt = propertyTaxDetailDto.IncludeInTotalPymt;
        taxDetailDto.TaxAmt = Decimal.Zero;
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        taxDetailDto.FirmNumber = userDef.FirmNumber;
        taxDetailDto.InsertUser = userDef.Username;
        taxDetailDto.UpdateUser = userDef.Username;

        return taxDetailDto;
    }
    private PrUnitSaleDetailDTO populatePropertySaleDTOFromUI()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        PrUnitSaleDetailDTO prUnitSaleDetailDto = getCurrentPropertyUnitSale();
        prUnitSaleDetailDto.Customer = CommonUIConverter.getCustomerDTO(drpCustomer.Text, null);
        prUnitSaleDetailDto.FirmMember = CommonUIConverter.getFirmMemberDTO(drpEmployee.Text, null);
        prUnitSaleDetailDto.BookingDate = CommonUtil.getCSDateNotNull(txtBookingDate.Text);
        prUnitSaleDetailDto.SaleRate = CommonUtil.getDecimaNotNulllWithoutExt(txtBookingRate.Text);
        prUnitSaleDetailDto.AgreementAmt = CommonUtil.getDecimaNotNulllWithoutExt(txtAgreementValue.Text);
        prUnitSaleDetailDto.AgreementDate = CommonUtil.getCSDate(txtAgreementDate.Text);
        prUnitSaleDetailDto.AgreementNo = txtAgreementNo.Text;
        prUnitSaleDetailDto.PossessionDate = CommonUtil.getCSDate(txtPossesionDate.Text);
        prUnitSaleDetailDto.LoanBankName = txtLoanBankName.Text;
        prUnitSaleDetailDto.LoanBankBranch = txtLoanBranch.Text;
        prUnitSaleDetailDto.LoanAmt = CommonUtil.getDecimalWithoutExt(txtLoanAmount.Text);
        prUnitSaleDetailDto.TotalTaxAmt = CommonUtil.getDecimaNotNulllWithoutExt(txtBookTotalTax.Text);
        prUnitSaleDetailDto.TotalPymtAmt = CommonUtil.getDecimaNotNulllWithoutExt(txtBookTotalUnitCost.Text);
        prUnitSaleDetailDto.TotalPackageCost = prUnitSaleDetailDto.TotalPymtAmt;
        prUnitSaleDetailDto.PrUnitSaleTaxDetails = new HashSet<PrUnitSaleTaxDetailDTO>();
        prUnitSaleDetailDto.uiTaxDetails.ForEach(t => prUnitSaleDetailDto.PrUnitSaleTaxDetails.Add(t));
        prUnitSaleDetailDto.uiCMTaxDetails.ForEach(t => prUnitSaleDetailDto.PrUnitSaleTaxDetails.Add(t));
        prUnitSaleDetailDto.Status = PRUnitSaleStatus.Sold;

        PaymentMasterDTO paymentMasterDto = new PaymentMasterDTO();
        paymentMasterDto.TotalAmt = prUnitSaleDetailDto.TotalPymtAmt;
        paymentMasterDto.TotalPaid = Decimal.Zero;
        paymentMasterDto.TotalPending = prUnitSaleDetailDto.TotalPymtAmt;
        paymentMasterDto.TotalPdcAmt = Decimal.Zero;
        paymentMasterDto.Status = PymtMasterStatus.Pending;
        paymentMasterDto.FirmNumber = userDefDto.FirmNumber;
        paymentMasterDto.InsertUser = userDefDto.Username;
        paymentMasterDto.UpdateUser = userDefDto.Username;

        PrUnitSalePymtDTO prUnitSalePymDto = new PrUnitSalePymtDTO();
        prUnitSalePymDto.PymtDate = DateTime.Today;
        prUnitSalePymDto.PymtType = masterDataBO.getMasterDataType(userDefDto.FirmNumber, Constants.MCDType.PR_UNIT_PYMT_TYPE, Constants.MCD_SALE_PAYMENT);
        prUnitSalePymDto.PymtAmt = prUnitSaleDetailDto.TotalPymtAmt;
        prUnitSalePymDto.PymtTo = PRUnitSalePymtTo.Builder;
        prUnitSalePymDto.Description = "";
        prUnitSalePymDto.FirmNumber = userDefDto.FirmNumber;
        prUnitSalePymDto.InsertUser = userDefDto.Username;
        prUnitSalePymDto.UpdateUser = userDefDto.Username;
        prUnitSalePymDto.PaymentMaster = paymentMasterDto;

        prUnitSaleDetailDto.PrUnitSalePymts = new HashSet<PrUnitSalePymtDTO>();
        prUnitSaleDetailDto.PrUnitSalePymts.Add(prUnitSalePymDto);

        return prUnitSaleDetailDto;
    }
    private void populateUIFieldsFromUnitDTO(PropertyUnitDTO propertyUnitDTO)
    {
        if (propertyUnitDTO != null) txtUnitViewPropertyName.Text = propertyUnitDTO.PropertyTower.Property.Name; else txtUnitViewPropertyName.Text = null;
        if (propertyUnitDTO != null) txtUnitViewPropertyTower.Text = propertyUnitDTO.PropertyTower.Name; else txtUnitViewPropertyTower.Text = null;
        if (propertyUnitDTO != null) txtUnitViewWing.Text = propertyUnitDTO.Wing; else txtUnitViewWing.Text = null;
        if (propertyUnitDTO != null) txtUnitViewFloorno.Text = propertyUnitDTO.FloorNo; else txtUnitViewFloorno.Text = null;
        if (propertyUnitDTO != null) txtUnitViewUnitNo.Text = propertyUnitDTO.UnitNo; else txtUnitViewUnitNo.Text = null;
        if (propertyUnitDTO != null && propertyUnitDTO.UnitType != null) txtUnitViewUnitType.Text = propertyUnitDTO.UnitType.Name; else txtUnitViewUnitType.Text = null;
        if (propertyUnitDTO != null) txtUnitViewNoOfBalcony.Text = propertyUnitDTO.NoOfBalcony.ToString(); else txtUnitViewNoOfBalcony.Text = null;
        if (propertyUnitDTO != null) txtUnitViewBuiltupArea.Text = propertyUnitDTO.BuildupArea.ToString(); else txtUnitViewBuiltupArea.Text = null;
        if (propertyUnitDTO != null) txtUnitViewCarpetArea.Text = propertyUnitDTO.CarpetArea.ToString(); else txtUnitViewCarpetArea.Text = null;
        if (propertyUnitDTO != null && propertyUnitDTO.BalconyArea != null) txtUnitViewBalconyArea.Text = propertyUnitDTO.BalconyArea.ToString(); else txtUnitViewBalconyArea.Text = null;
        if (propertyUnitDTO != null && propertyUnitDTO.Direction != null) txtUnitViewDirection.Text = propertyUnitDTO.Direction.Name; else txtUnitViewDirection.Text = null;
        if (propertyUnitDTO != null && propertyUnitDTO.Facing != null) txtUnitViewFacing.Text = propertyUnitDTO.Facing.Name; else txtUnitViewFacing.Text = null;
    }
    private void populateUIFieldsFromSaleUnitDTO(PrUnitSaleDetailDTO prUnitSaleDetailDto)
    {
        PropertyUnitDTO propertyUnitDto = prUnitSaleDetailDto.PropertyUnit;
        PropertyTowerDTO propertyTowerDto = prUnitSaleDetailDto.PropertyUnit.PropertyTower;
        populateTab3UnitInfoSection(prUnitSaleDetailDto);
        drpCustomer.ClearSelection();
        drpEmployee.ClearSelection();
        txtBookingDate.Text = CommonUtil.getCSDate(prUnitSaleDetailDto.BookingDate);
        txtBookingRate.Text = (propertyTowerDto.Rate != null) ? propertyTowerDto.Rate.ToString() : null;
        txtAgreementValue.Text = prUnitSaleDetailDto.AgreementAmt.ToString();
        txtBookTotalTax.Text = prUnitSaleDetailDto.TotalTaxAmt.ToString();
        txtBookTotalUnitCost.Text = prUnitSaleDetailDto.TotalPymtAmt.ToString();
        txtAgreementDate.Text = null;
        txtAgreementNo.Text = null;
        txtPossesionDate.Text = null;
        txtLoanBankName.Text = null;
        txtLoanBranch.Text = null;
        txtLoanAmount.Text = null;
        populateTaxDetailGrid(prUnitSaleDetailDto);
        populateCMTaxDetailGrid(prUnitSaleDetailDto);
    }
    private void populateTab3UnitInfoSection(PrUnitSaleDetailDTO prUnitSaleDetailDto)
    {
        PropertyUnitDTO propertyUnitDto = prUnitSaleDetailDto.PropertyUnit;
        PropertyTowerDTO propertyTowerDto = prUnitSaleDetailDto.PropertyUnit.PropertyTower;
        txtBookPropertyName.Text = propertyTowerDto.Property.Name;
        txtBookPropertyTower.Text = propertyTowerDto.Name;
        txtBookPropertyRate.Text = (propertyTowerDto.Rate != null) ? propertyTowerDto.Rate.ToString() : null;
        txtBookTowerPossession.Text = (propertyTowerDto.Possession != null) ? CommonUtil.getCSDate(propertyTowerDto.Possession) : null;
        txtBookUnitNo.Text = CommonUIConverter.getPropertyUnitFormattedNo(prUnitSaleDetailDto.PropertyUnit.Wing, prUnitSaleDetailDto.PropertyUnit.UnitNo);
        txtBookUnitType.Text = (propertyUnitDto.UnitType != null) ? propertyUnitDto.UnitType.Name : null;
        txtBookBuiltupArea.Text = propertyUnitDto.BuildupArea.ToString();
        txtBookCarpetArea.Text = propertyUnitDto.CarpetArea.ToString();
    }
    private void populateTaxDetailGrid(PrUnitSaleDetailDTO prUnitSaleDetailDTO)
    {
        taxDetailGrid.DataSource = new List<PrUnitSaleTaxDetailDTO>();
        if (prUnitSaleDetailDTO != null && prUnitSaleDetailDTO.uiTaxDetails != null)
        {
            assignUiIndexToTaxDetail(prUnitSaleDetailDTO.uiTaxDetails);
            taxDetailGrid.DataSource = prUnitSaleDetailDTO.uiTaxDetails;
        }
        taxDetailGrid.DataBind();
    }
    private void populateCMTaxDetailGrid(PrUnitSaleDetailDTO prUnitSaleDetailDTO)
    {
        cmTaxDetailGrid.DataSource = new List<PrUnitSaleTaxDetailDTO>();
        if (prUnitSaleDetailDTO != null && prUnitSaleDetailDTO.uiTaxDetails != null)
        {
            assignUiIndexToTaxDetail(prUnitSaleDetailDTO.uiCMTaxDetails);
            cmTaxDetailGrid.DataSource = prUnitSaleDetailDTO.uiCMTaxDetails;
        }
        cmTaxDetailGrid.DataBind();
    }
    private void assignUiIndexToTaxDetail(List<PrUnitSaleTaxDetailDTO> taxDetailDtos)
    {
        if (taxDetailDtos != null && taxDetailDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (PrUnitSaleTaxDetailDTO taxDetailDto in taxDetailDtos)
            {
                taxDetailDto.UiIndex = uiIndex++;
                taxDetailDto.RowInfo = CommonUIConverter.getGridViewRowInfo(taxDetailDto);
            }
        }
    }
  //TaxDetail Combined Table actions - Start
    private bool isCMTax(string currentTax) {
        return currentTax.Equals("CMTax");
    }
    private void clearTaxSectionSelection(bool isCMTaxSextion) {
        PrUnitSaleDetailDTO prUnitSaleDetailDto = getCurrentPropertyUnitSale();
        if (isCMTaxSextion) {
            pnlCMTaxDetailAdd.Visible = false;
            if (cmTaxDetailGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in cmTaxDetailGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdCMTaxDetailSelect");
                    if (radioBtn != null) radioBtn.Checked = false;
                }
            }
            if (prUnitSaleDetailDto.uiCMTaxDetails != null) prUnitSaleDetailDto.uiCMTaxDetails.ForEach(c => c.isUISelected = false);
        } else {
            pnlTaxDetailAdd.Visible = false;
            if (taxDetailGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in taxDetailGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdTaxDetailSelect");
                    if (radioBtn != null) radioBtn.Checked = false;
                }
            }
            if (prUnitSaleDetailDto.uiTaxDetails != null) prUnitSaleDetailDto.uiTaxDetails.ForEach(c => c.isUISelected = false);
        }
    }
    private void selectTaxDetail(PrUnitSaleTaxDetailDTO taxDetailDto, bool isCMTaxSection)
    {
        GridView currentGrid = taxDetailGrid;
        string radioBtselector = "rdTaxDetailSelect";
        string rowBtselector = "btnTaxDetailRowIdentifier";
        if (isCMTaxSection) {
            currentGrid = cmTaxDetailGrid;
            radioBtselector = "rdCMTaxDetailSelect";
            rowBtselector = "btnCMTaxDetailRowIdentifier";
        }
        if (currentGrid.Rows.Count > 0)
        {
            taxDetailDto.isUISelected = true;
            foreach (GridViewRow row in currentGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl(radioBtselector);
                Button rowIdenBtn = (Button)row.FindControl(rowBtselector);
                radioBtn.Checked = false;
                if (rowIdenBtn != null && taxDetailDto.UiIndex.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                {
                    radioBtn.Checked = true;
                }
            }
        }
    }
    private void initTaxDetailSection(bool isCMTaxSection)
    {
        if(isCMTaxSection) {
            lbCMTaxDetailAddUpdateSectionHeader.Text = Resources.Labels.label_sectionheader_add_tax;
            pnlCMTaxDetailAdd.Visible = true;
        } else {
            lbTaxDetailAddUpdateSectionHeader.Text = Resources.Labels.label_sectionheader_add_tax;
            pnlTaxDetailAdd.Visible = true;
        }
    }
    private void initTaxDetailSectionFields(bool isCMTaxSection)
    {
        initTaxDetailSection(isCMTaxSection);
        populateDrpTaxType(isCMTaxSection);
        if(isCMTaxSection) {
            drpCMTaxType.ClearSelection();
            txtCMTaxRate.Text = null;
            txtCMTaxLimit.Text = null;
            txtCMTaxAmount.Text = null;
            SetFocus(drpCMTaxType);
            scrollToFieldHdn.Value = pnlCMTaxDetailAdd.ID;
        } else {
            drpTaxType.ClearSelection();
            txtTaxRate.Text = null;
            txtTaxLimit.Text = null;
            txtTaxAmount.Text = null;
            SetFocus(drpTaxType);
            scrollToFieldHdn.Value = pnlTaxDetailAdd.ID;
        }
    }
    private bool populateDrpTaxType(bool isCMTaxSection)
    {
        bool hasTax = false;
        DropDownList tmpTaxDrp = (isCMTaxSection) ? drpCMTaxType : drpTaxType;
        PropertyDTO propertyDTO = getCurrentPropertyUnit().PropertyTower.Property;
        tmpTaxDrp.Items.Clear();
        tmpTaxDrp.Items.Insert(0, new ListItem(Constants.SELECT_ITEM[0], Constants.SELECT_ITEM[1]));
        if (propertyDTO.PropertyTaxDetails != null && propertyDTO.PropertyTaxDetails.Count > 0) {
            PrUnitSaleDetailDTO prUnitSaleDetailDTO = getCurrentPropertyUnitSale();
            foreach (PropertyTaxDetailDTO propertyTaxDetailDto in propertyDTO.PropertyTaxDetails) {
                if (!(prUnitSaleDetailDTO.uiTaxDetails.Any(t => t.TaxType.Id == propertyTaxDetailDto.TaxType.Id) 
                        || prUnitSaleDetailDTO.uiCMTaxDetails.Any(t => t.TaxType.Id == propertyTaxDetailDto.TaxType.Id))) {
                    tmpTaxDrp.Items.Add(new ListItem(propertyTaxDetailDto.TaxType.Name, propertyTaxDetailDto.TaxType.Id.ToString()));
                    hasTax = true;
                }
            }
        }
        return hasTax;
    }
    private PrUnitSaleTaxDetailDTO getSelectedTaxDetail(bool isCMTaxSection)
    {
        if(isCMTaxSection) 
            return getCurrentPropertyUnitSale().uiCMTaxDetails.Find(c => c.isUISelected);
        else 
            return getCurrentPropertyUnitSale().uiTaxDetails.Find(c => c.isUISelected);
    }
    private bool validateTaxDetailSelected(bool isCMTaxSection)
    {
        bool isSelected = true;
        PrUnitSaleTaxDetailDTO taxDetailDto = getSelectedTaxDetail(isCMTaxSection);
        if (taxDetailDto == null)
        {
            isSelected = false;
            clearTaxSectionSelection(isCMTaxSection);
            setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Tax Detail"), tab3BzStep1Error);
        }
        return isSelected;
    }
    private PrUnitSaleTaxDetailDTO populatePropertyTaxDetailAdd(PrUnitSaleDetailDTO prUnitSaleDetailDTO, bool isCMTaxSection)
    {
        PropertyDTO propertyDTO = getCurrentPropertyUnit().PropertyTower.Property;
        long selectedTaxId = (isCMTaxSection) ? long.Parse(drpCMTaxType.Text) : long.Parse(drpTaxType.Text);
        PropertyTaxDetailDTO selectedTaxDetailDto = propertyDTO.PropertyTaxDetails.FirstOrDefault(t => t.TaxType.Id == selectedTaxId);
        PrUnitSaleTaxDetailDTO taxDetailDto = populatePrSaleTaxDetail(selectedTaxDetailDto);
        taxDetailDto.TaxPercentage = CommonUtil.getDecimaNotNulllWithoutExt((isCMTaxSection) ? txtCMTaxRate.Text : txtTaxRate.Text);
        taxDetailDto.TaxAmtLimit = CommonUtil.getDecimaNotNulllWithoutExt((isCMTaxSection) ? txtCMTaxLimit.Text : txtTaxLimit.Text);
        taxDetailDto.TaxAmt = CommonUtil.getDecimaNotNulllWithoutExt((isCMTaxSection) ? txtCMTaxAmount.Text : txtTaxAmount.Text);
        taxDetailDto.UpdateUser = getUserDefinitionDTO().Username;
        if (isCMTaxSection)
        {
            taxDetailDto.IncludeInTotalPymt = IncludeInPymtTotal.No;
            prUnitSaleDetailDTO.uiCMTaxDetails.Add(taxDetailDto);
        }
        else
        {
            taxDetailDto.IncludeInTotalPymt = IncludeInPymtTotal.Yes;
            prUnitSaleDetailDTO.uiTaxDetails.Add(taxDetailDto);
        }
        return taxDetailDto;
    }
    protected void onSelectTaxDetail(object sender, EventArgs e)
    {
        GroupRadioButton rd = (GroupRadioButton)sender;
        bool isCMTaxSection = isCMTax(rd.Attributes["data-taxsection"]);
        clearTaxSectionSelection(!isCMTaxSection);
        if (isCMTaxSection) {
            pnlCMTaxDetailAdd.Visible = false;
            if (rd.Checked)
            {
                long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnCMTaxDetailRowIdentifier"))).Attributes["row-identifier"]);
                List<PrUnitSaleTaxDetailDTO> taxDetailList = getCurrentPropertyUnitSale().uiCMTaxDetails;
                taxDetailList.ForEach(c => c.isUISelected = false);
                taxDetailList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
            }
        }
        else {
            pnlTaxDetailAdd.Visible = false;
            if (rd.Checked)
            {
                long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnTaxDetailRowIdentifier"))).Attributes["row-identifier"]);
                List<PrUnitSaleTaxDetailDTO> taxDetailList = getCurrentPropertyUnitSale().uiTaxDetails;
                taxDetailList.ForEach(c => c.isUISelected = false);
                taxDetailList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
            }
        }
    }
    protected void onClickAddTaxDetailBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            bool isCMTaxSection = isCMTax(rd.Attributes["data-taxsection"]);
            clearTaxSectionSelection(!isCMTaxSection);
            clearTaxSectionSelection(isCMTaxSection);
            if (populateDrpTaxType(isCMTaxSection))
            {
                initTaxDetailSectionFields(isCMTaxSection);
            }
            else
            {
                setErrorMessage("Tax type not available for add", tab3BzStep1Error);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab3BzStep1Error);
        }
    }
    protected void onTaxRateChanged(object sender, EventArgs e)
    {
        TextBox tmpTxtBox = (TextBox)sender;
        bool isCMTaxSection = isCMTax(tmpTxtBox.Attributes["data-taxsection"]);
        DropDownList tmpDrp = (isCMTaxSection) ? drpCMTaxType : drpTaxType;
        if (!(string.IsNullOrWhiteSpace(tmpDrp.Text) || string.IsNullOrWhiteSpace(tmpTxtBox.Text)))
        {
            decimal agreementValue = CommonUtil.getDecimaNotNulllWithoutExt(txtAgreementValue.Text);
            decimal taxPercentage = Decimal.Divide(CommonUtil.getDecimaNotNulllWithoutExt(tmpTxtBox.Text), 100);
            decimal tmpTaxLimit = (isCMTaxSection) ? CommonUtil.getDecimaNotNulllWithoutExt(txtCMTaxLimit.Text) : CommonUtil.getDecimaNotNulllWithoutExt(txtTaxLimit.Text);
            decimal taxAmt = Math.Round(Decimal.Multiply(agreementValue, taxPercentage), 2);
            if (tmpTaxLimit > 0 && taxAmt > tmpTaxLimit) taxAmt = tmpTaxLimit;
            if (isCMTaxSection) txtCMTaxAmount.Text = taxAmt.ToString(); else txtTaxAmount.Text = taxAmt.ToString();
        }
        else
        {
            if (isCMTaxSection) txtCMTaxAmount.Text = null; else txtTaxAmount.Text = null;
        }
    }
    protected void onTaxTypeChanged(object sender, EventArgs e)
    {
        DropDownList tmpDrp = (DropDownList)sender;
        bool isCMTaxSection = isCMTax(tmpDrp.Attributes["data-taxsection"]);
        if (!string.IsNullOrWhiteSpace(tmpDrp.Text))
        {
            PropertyDTO propertyDTO = getCurrentPropertyUnit().PropertyTower.Property;
            long selectedTaxId = long.Parse(tmpDrp.Text);
            PropertyTaxDetailDTO selectedTaxDetailDto = propertyDTO.PropertyTaxDetails.FirstOrDefault(t => t.TaxType.Id == selectedTaxId);
            decimal agreementValue = CommonUtil.getDecimaNotNulllWithoutExt(txtAgreementValue.Text);
            decimal tmpPercentage = Decimal.Divide(selectedTaxDetailDto.TaxPercentage, 100);
            decimal taxAmt = Math.Round(Decimal.Multiply(agreementValue, tmpPercentage), 2);
            if (selectedTaxDetailDto.TaxAmtLimit > 0 && taxAmt > selectedTaxDetailDto.TaxAmtLimit) taxAmt = selectedTaxDetailDto.TaxAmtLimit;
            if (isCMTaxSection) txtCMTaxRate.Text = selectedTaxDetailDto.TaxPercentage.ToString(); else txtTaxRate.Text = selectedTaxDetailDto.TaxPercentage.ToString();
            if (isCMTaxSection) txtCMTaxLimit.Text = selectedTaxDetailDto.TaxAmtLimit.ToString(); else txtTaxLimit.Text = selectedTaxDetailDto.TaxAmtLimit.ToString();
            if (isCMTaxSection) txtCMTaxAmount.Text = taxAmt.ToString(); else txtTaxAmount.Text = taxAmt.ToString();
        }
        else
        {
            if (isCMTaxSection) txtCMTaxRate.Text = null; else txtTaxRate.Text = null;
            if (isCMTaxSection) txtCMTaxLimit.Text = null; else txtTaxLimit.Text = null;
            if (isCMTaxSection) txtCMTaxAmount.Text = null; else txtTaxAmount.Text = null;
        }
    }
    protected void deleteTaxDetail(object sender, EventArgs e)
    {
        try
        {
            Button rd = (Button)sender;
            bool isCMTaxSection = isCMTax(rd.Attributes["data-taxsection"]);
            clearTaxSectionSelection(!isCMTaxSection);
            if (validateTaxDetailSelected(isCMTaxSection))
            {
                PrUnitSaleDetailDTO prUnitSaleDetailDTO = getCurrentPropertyUnitSale();
                PrUnitSaleTaxDetailDTO taxDetailDto = getSelectedTaxDetail(isCMTaxSection);
                if (isCMTaxSection) prUnitSaleDetailDTO.uiCMTaxDetails.Remove(taxDetailDto); 
                else prUnitSaleDetailDTO.uiTaxDetails.Remove(taxDetailDto); 
                clearTaxSectionSelection(isCMTaxSection);
                calculateAllSaleAmounts(prUnitSaleDetailDTO);
                setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, taxDetailDto.TaxType.Name), tab3Anchor.ID, tab3BzStep1);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab3BzStep1Error);
        }
    }
    protected void addNewTaxDetail(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            bool isCMTaxSection = isCMTax(rd.Attributes["data-taxsection"]);
            clearTaxSectionSelection(!isCMTaxSection);
            if (validateTaxDetail(isCMTaxSection))
            {
                PrUnitSaleDetailDTO prUnitSaleDetailDTO = getCurrentPropertyUnitSale();
                PrUnitSaleTaxDetailDTO taxDetailDto = populatePropertyTaxDetailAdd(prUnitSaleDetailDTO, isCMTaxSection);
                calculateAllSaleAmounts(prUnitSaleDetailDTO);
                selectTaxDetail(taxDetailDto, isCMTaxSection);
                clearTaxSectionSelection(isCMTaxSection);
                setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, taxDetailDto.TaxType.Name), tab3Anchor.ID, tab3BzStep1);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab3BzStep1Error);
        }
    }
    protected void cancelTaxDetail(object sender, EventArgs e)
    {
        LinkButton rd = (LinkButton)sender;
        bool isCMTaxSection = isCMTax(rd.Attributes["data-taxsection"]);
        clearTaxSectionSelection(isCMTaxSection);
        scrollToFieldHdn.Value = (isCMTaxSection) ? lbCMTaxSectionHeader.ID : lbTaxSectionHeader.ID;
    }
    //TaxDetail Combined Table actions - END
    private bool validateTaxDetail(bool isCMTaxSection)
    {
        bool isValid = true;
        string vGroup = (isCMTaxSection) ? "tab3BzStep1ErrorGrid2" : "tab3BzStep1ErrorGrid1";
        Page.Validate(vGroup);
        isValid = Page.IsValid;
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }

   
    //TaxDetail Table actions - END
}
