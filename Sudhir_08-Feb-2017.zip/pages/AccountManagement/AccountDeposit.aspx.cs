﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft.Logic.BO;
using Vladsm.Web.UI.WebControls;

namespace ConstroSoft.pages.AccountManagement
{
    public partial class AccountDeposit : System.Web.UI.Page
    {
        private static readonly log4net.ILog log =
            log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string tab1ValidationGrp = "tab1Error";
        string tab2ValidationGrp = "tab2Error";
        string VS_DEPOSIT_LIST = "DEPOSIT_LIST";
        string VS_SELECTED_DEPOSIT = "SELECTED_DEPOSIT";
        AccountDepositBO accountdepositBO = new AccountDepositBO();
        DropdownBO drpBO = new DropdownBO();
        CustomerBO customerBO = new CustomerBO();        
        MasterDataBO masterDataBO = new MasterDataBO();
        EmployeeBO firmMemberBO = new EmployeeBO();
        enum PymtPageMode { ADD_PYMT, PYMT_HISTORY, PYMT_HISTORY_READONLY, NONE }
        PaymentBO paymentBO = new PaymentBO();       
        
        protected void Page_Load(object sender, EventArgs e)
        {
            clearMessages();
            if (!IsPostBack)
            {
                if (Session[Constants.Session.USERNAME] != null)
                {
                    resetTabInfo(PageMode.NONE);
                    initDropdowns();
                    Page.MaintainScrollPositionOnPostBack = false;
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
        }
        private void initDropdowns()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];            
            drpBO.drpDataBase(drpAccount, DrpDataType.FIRM_ACCOUNT, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpAccountNo, DrpDataType.FIRM_ACCOUNT, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpEnum<PaymentMode>(drpPaymentMode, null);
        }
        /**
         * This method is called just before the page is rendered. So any change in state of the element is applied.
         **/
        protected void Page_PreRender(object sender, EventArgs e)
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        private bool isViewOnlyUser()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            bool isViewOnlyUser = !CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.FIRM_ACCOUNT_ADD_UPDATE);
            return isViewOnlyUser;
        }
        private void applyEntitlement()
        {
            if (isViewOnlyUser())
            {
                resetTabInfo(PageMode.VIEW);
            }
        }
        private void preRenderInitFormElements()
        {
            FirmAcntDepositeDTO accountTrans = getFirmAccountDeposit();            
            jumpToDepositHdnId.Value = null;            
            if (accountTrans != null)
            {
                jumpToDepositHdnId.Value = accountTrans.Id.ToString();
            }
        }
        public void setErrorMessage(string message, string group)
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            this.Page.Validators.Add(val);
        }
        public void setSuccessMessage(string msg, string tabId)
        {
            activeTabHdn.Value = tabId;
            if (tabId.Equals(tab1Anchor.ID))
            {
                lbTab1Success.Text = msg;
                tab1SuccessPanel.Visible = true;
            }
            else if (tabId.Equals(tab2Anchor.ID))
            {
                lbTab2Success.Text = msg;
                tab2SuccessPanel.Visible = true;
            }
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        public void initBootstrapComponantsFromServer()
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
        }
        private void clearMessages()
        {
            tab1SuccessPanel.Visible = false;
            lbTab1Success.Text = "";
            tab2SuccessPanel.Visible = false;
            lbTab2Success.Text = "";
        }
        private UserDefinitionDTO getUserDefinitionDTO()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }

        private void resetTabInfo(PageMode pageMode)
        {
            tab2Anchor.Visible = true;
            activeTabHdn.Value = tab2Anchor.ID;
            pageModeHdn.Value = pageMode.ToString();
            initFormFields();
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            
            if (PageMode.ADD == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.accountdeposit_sm_manage_deposit_tab2_add_name;
                initFormFields();
            }
            else if (PageMode.VIEW == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.accountdeposit_sm_manage_deposit_tab2_view_name;
                initFormFields();
            }
            else
            {
                activeTabHdn.Value = tab1Anchor.ID;
                tab2Anchor.Visible = false;
                ViewState[VS_SELECTED_DEPOSIT] = null;
            }
        }
        private void initFormFields()
        {
            bool isReadOnly = (PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            bool visible = !(PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            //Buttons
            btnAddSubmit.Visible = visible;
            
        }
        private FirmAcntDepositeDTO getFirmAccountDeposit()
        {
            return (FirmAcntDepositeDTO)ViewState[VS_SELECTED_DEPOSIT];
        }
        private void setSelectedDeposit(long selectedId)
        {
            List<FirmAcntDepositeDTO> depositList = (List<FirmAcntDepositeDTO>)ViewState[VS_DEPOSIT_LIST];
            if (depositList != null)
            {
                depositList.ForEach(c => c.isUISelected = false);
                depositList.Find(c => c.Id == selectedId).isUISelected = true;
            }
        }
        private bool validateDepositSelected()
        {
            bool isSelected = true;
            List<FirmAcntDepositeDTO> depositList = (List<FirmAcntDepositeDTO>)ViewState[VS_DEPOSIT_LIST];
            if (depositList != null)
            {
                isSelected = depositList.Any(c => c.isUISelected);
                if (!isSelected)
                {
                    resetTabInfo(PageMode.NONE);
                    setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Deposit"), tab1ValidationGrp);
                }
            }
            return isSelected;
        }
        private void selectDepositGridRdBtn(long Id)
        {
            if (DepositGrid.Rows.Count > 0)
            {
                foreach (GridViewRow row in DepositGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdDepositSelect");
                    Button rowIdenBtn = (Button)row.FindControl("btnDepositRowIdentifier");
                    if (radioBtn != null)
                    {
                        radioBtn.Checked = false;
                        if (rowIdenBtn != null && Id > 0 && Id.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                        {
                            radioBtn.Checked = true;
                        }
                    }
                }
            }
        }
        private void loadSearchGridAndReSelect(long Id)
        {
            try
            {
                long searchByValId = -1;
                if (!string.IsNullOrWhiteSpace(drpAccountNo.Text)) searchByValId = long.Parse(drpAccountNo.Text);
                IList<FirmAcntDepositeDTO> results = accountdepositBO.fetchAccountDepositGridData(getUserDefinitionDTO().FirmNumber, searchByValId);
                assignUiIndexToDeposit(results);
                ViewState[VS_DEPOSIT_LIST] = results;
                DepositGrid.DataSource = results;
                DepositGrid.DataBind();
                if (Id > 0)
                {
                    selectDepositGridRdBtn(Id);
                    setSelectedDeposit(Id);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void fetchSelectedDeposit()
        {
            try
            {
                FirmAcntDepositeDTO depositDto = null;
                if (PageMode.ADD.ToString().Equals(pageModeHdn.Value))
                {
                    depositDto = populateDepositDTOAdd();
                    selectDepositGridRdBtn(0);
                }
                else if (PageMode.MODIFY.ToString().Equals(pageModeHdn.Value) || PageMode.VIEW.ToString().Equals(pageModeHdn.Value))
                {
                    long Id = ((List<FirmAcntDepositeDTO>)ViewState[VS_DEPOSIT_LIST]).Find(c => c.isUISelected).Id;
                    depositDto = accountdepositBO.fetchDeposit(Id);
                }
                ViewState[VS_SELECTED_DEPOSIT] = depositDto;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void doViewModifyAction(PageMode pageMode)
        {
            resetTabInfo(pageMode);
            fetchSelectedDeposit();
            populateUIFieldsFromDTO((FirmAcntDepositeDTO)ViewState[VS_SELECTED_DEPOSIT]);
        }
        protected void onSearchByAccountNo(object sender, EventArgs e)
        {
            try
            {
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                AccountNoSearchBy searchBy = EnumHelper.ToEnum<AccountNoSearchBy>(drpAccountNo.Text);
                //bind deposit detail grid related to account numebr
                loadSearchGridAndReSelect(0);
                resetTabInfo(PageMode.NONE);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
       
        protected void selectDeposit(object sender, EventArgs e)
        {
            try
            {
                GroupRadioButton rd = (GroupRadioButton)sender;
                resetTabInfo(PageMode.NONE);
                if (rd.Checked)
                {
                    string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnDepositRowIdentifier"))).Attributes["row-identifier"];
                    setSelectedDeposit(long.Parse(strId));
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        /*
         * This method is called on click of ADD button in datatable top bar.
         */
        protected void onClickAddDepositBtn(object sender, EventArgs e)
        {
            try
            {
                resetTabInfo(PageMode.ADD);
                fetchSelectedDeposit();
                populateUIFieldsFromDTO(null);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickViewDepositBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateDepositSelected())
                {
                    doViewModifyAction(PageMode.VIEW);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        protected void deleteDeposit(object sender, EventArgs e)
        {
            try
            {
                if (validateDepositSelected())
                {
                    long Id = ((List<FirmAcntDepositeDTO>)ViewState[VS_DEPOSIT_LIST]).Find(c => c.isUISelected).Id;
                    FirmAcntDepositeDTO depositDto = accountdepositBO.fetchDeposit(Id);
                    ViewState[VS_SELECTED_DEPOSIT] = depositDto;
                    if (!validateDepositStatus(depositDto))
                    {
                        depositDto.DepositeDate = DateTime.Now;
                        depositDto.Status = "Reversed";
                        AccountTransactionDTO acntTransDto = createAccountTransaction(depositDto, true);
                        accountdepositBO.deleteDeposit(depositDto, acntTransDto);
                        loadSearchGridAndReSelect(0);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_delete, "Deposit"), tab1Anchor.ID);
                    }
                 }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private bool validateDepositStatus(FirmAcntDepositeDTO depositDto)
        {
            bool isReversed = false;
            if (depositDto.Status == "Reversed")
                {
                    resetTabInfo(PageMode.NONE);
                    isReversed = true;
                    setErrorMessage(Resources.Messages.validation_deposit_reversed, tab1ValidationGrp);
                }
            return isReversed;
        }
        protected void addOrModifyDeposit(object sender, EventArgs e)
        {
            try
            {
                if (validateDeposit())
                {
                    FirmAcntDepositeDTO depositDto = getFirmAccountDeposit();
                    long Id = depositDto.Id;
                    populateDepositDTOFromUI(depositDto);
                    if (PageMode.ADD.ToString().Equals(pageModeHdn.Value))
                    {
                        AccountTransactionDTO acntTransDto = createAccountTransaction(depositDto, false);
                        Id = accountdepositBO.saveDeposit(depositDto, acntTransDto);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_add, "Deposit"), tab2Anchor.ID);
                    }
                    
                    loadSearchGridAndReSelect(Id);
                    doViewModifyAction(PageMode.VIEW);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        private AccountTransactionDTO createAccountTransaction(FirmAcntDepositeDTO depositDto, bool isDelete)
        {
            AccountTransactionDTO acntTransDto = new AccountTransactionDTO();
            acntTransDto.FirmAccount = CommonUIConverter.getFirmAccountDTO(depositDto.FirmAccount.Id.ToString(), depositDto.FirmAccount.Name);
            if (isDelete) {
                acntTransDto.TxType = AcntTransStatus.Debit;
            }
            else
            {
                acntTransDto.TxType = AcntTransStatus.Credit;
            }
            acntTransDto.Comments = "";//TODO - Need to create Comments
            acntTransDto.TxDate = depositDto.DepositeDate;
            decimal tmpvalue;
            decimal result = 0.0M;
            if (decimal.TryParse(depositDto.Amount.ToString(), out tmpvalue))
                result = tmpvalue;
            acntTransDto.Amount = result;
            acntTransDto.FirmNumber = depositDto.FirmNumber;
            acntTransDto.InsertUser = depositDto.InsertUser;
            acntTransDto.UpdateUser = depositDto.UpdateUser;
            return acntTransDto;
            
        }
        private bool validateDeposit()
        {
            bool isValid = true;
            Page.Validate("tab2Error");
            isValid = Page.IsValid;
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        protected void cancelDeposit(object sender, EventArgs e)
        {
            FirmAcntDepositeDTO depositDto = getFirmAccountDeposit();
            resetTabInfo(PageMode.NONE);
            loadSearchGridAndReSelect(depositDto.Id);
        }
        private FirmAcntDepositeDTO populateDepositDTOAdd()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            FirmAcntDepositeDTO depositDto = new FirmAcntDepositeDTO();
            //depositDto.FirmAccount = new FirmAcntDepositeDTO();            
            depositDto.FirmNumber = userDefDto.FirmNumber;
            depositDto.InsertUser = userDefDto.Username;
            return depositDto;
        }
        private void populateDepositDTOFromUI(FirmAcntDepositeDTO DepositDto)
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            DepositDto.Amount =CommonUtil.getDecimaNotNulllWithoutExt(txtPaymentAmount.Text);           
            DepositDto.FirmAccount = CommonUIConverter.getFirmAccountDTO(drpAccount.Text, null);
            DepositDto.Description = txtPaymentComment.Text;
            DepositDto.DepositeDate = CommonUtil.getCSDateNotNull(txtTransactionDate.Text);
            DepositDto.ChequeDate = CommonUtil.getCSDate(txtChequeDate.Text);
            DepositDto.BankName = txtBankName.Text;
            DepositDto.PymtMode =drpPaymentMode.Text;
            DepositDto.ChequeNo = txtChequeNo.Text;
            DepositDto.Branch = txtBranch.Text;
            DepositDto.Description = txtPaymentComment.Text;
            DepositDto.Status = "Deposited";
            DepositDto.FirmNumber = userDefDto.FirmNumber;
            DepositDto.InsertUser = userDefDto.Username;
            DepositDto.UpdateUser = userDefDto.Username;
            DepositDto.Version = userDefDto.Version;
        }
        private void populateUIFieldsFromDTO(FirmAcntDepositeDTO depositDto)
        {
            if (depositDto != null) drpAccount.Text = depositDto.FirmAccount.Id.ToString(); else drpAccount.Text = null;
            if (depositDto != null) drpPaymentMode.Text = depositDto.PymtMode; else drpPaymentMode.Text = null;
            if (depositDto != null) txtPaymentComment.Text = depositDto.Description; else txtPaymentComment.Text = null;
            if (depositDto != null && depositDto.Amount != null) txtPaymentAmount.Text = Convert.ToDecimal(depositDto.Amount).ToString(); else txtPaymentAmount.Text = null;
            PaymentMode pymtMode = EnumHelper.ToEnum<PaymentMode>(drpPaymentMode.Text);
            if (PaymentMode.CHEQUE == pymtMode)
            {
                pnlChequeAdditionInfo.Visible = true;
                if (depositDto != null) txtChequeNo.Text = depositDto.ChequeNo; else txtChequeNo.Text = null;
                if (depositDto != null) txtBankName.Text = depositDto.BankName; else txtBankName.Text = null;
                if (depositDto != null) txtBranch.Text = depositDto.BankName; else txtBranch.Text = null;// branch
                if (depositDto != null && depositDto.ChequeDate != null) txtChequeDate.Text = depositDto.ChequeDate.Value.ToString(Constants.DATE_FORMAT); else txtChequeDate.Text = null;
            }
            else {
                pnlChequeAdditionInfo.Visible = false;
            }
            if (depositDto != null && depositDto.DepositeDate != null) txtTransactionDate.Text = CommonUtil.getCSDate(depositDto.DepositeDate); else txtTransactionDate.Text = null;
        }

        private void assignUiIndexToDeposit(IList<FirmAcntDepositeDTO> firmAcntDepositeDTOs)
        {
            if (firmAcntDepositeDTOs != null && firmAcntDepositeDTOs.Count > 0)
            {
                long uiIndex = 1;
                foreach (FirmAcntDepositeDTO firmAcntDepositeDTO in firmAcntDepositeDTOs)
                {
                    firmAcntDepositeDTO.UiIndex = uiIndex++;
                    firmAcntDepositeDTO.RowInfo = CommonUIConverter.getGridViewRowInfo(firmAcntDepositeDTO);
                }
            }
        }
        protected void saveModalData(object sender, EventArgs e)
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (modalHdnType.Value == "OCCUPATION")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.OCCUPATION, modalInput1.Text,
                modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "OCCUPATION");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    //drpBO.drpDataBase(drpOccupation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.OCCUPATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    //drpBO.drpDataBase(drpCoCustomerOccupation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.OCCUPATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            
            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                modalErrorMsg.Value = errorMsg;
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "setModalErrorMsg", "setModalErrorMsg()", true);
            }
            else
            {
                //Reset the modal fields
                modalInput1.Text = "";
                modalInput2.Text = "";
                modalHdnType.Value = "";
                modalActionHdn.Value = "";
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "closeDialogClient", "closeDialogClient()", true);
            }
        }

        private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
        {
            string errorMsg = "";
            if (string.IsNullOrWhiteSpace(masterDataDto.Name))
            {
                errorMsg = Resources.Messages.validation_designationname_required;
            }
            else if (masterDataBO.isAlreadyExist(masterDataDto))
            {
                errorMsg = string.Format(Resources.Messages.validation_same_name_exist, type);
            }
            return errorMsg;
        }

        protected void onSelectPymtMode(object sender, EventArgs e)
        {
            try
            {
                PaymentMode pymtMode = EnumHelper.ToEnum<PaymentMode>(drpPaymentMode.Text);
                if (PaymentMode.CHEQUE == pymtMode)
                {
                    pnlChequeAdditionInfo.Visible = true;
                    initChequeAdditionalInfo();
                }
                else
                {
                    pnlChequeAdditionInfo.Visible = false;
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        private void initChequeAdditionalInfo()
        {
            txtBankName.Text = "";
            txtChequeDate.Text = "";
            txtChequeNo.Text = "";
            txtBranch.Text = "";
        }
        private FirmAcntDepositeDTO getCurrentDepositPymt()
        {
            return (FirmAcntDepositeDTO)ViewState[VS_DEPOSIT_LIST];
        }
              
    }
}