﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;

public partial class ManagePropertySchedule : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string tab1ValidationGrp = "tab1Error";
    string VS_PR_PYMT_SCHED_LIST = "PR_PYMT_SCHED_LIST";
    DropdownBO drpBO = new DropdownBO();
    PropertyBO propertyBO = new PropertyBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (Session[Constants.Session.USERNAME] != null)
            {
                resetPageInfo(PageMode.NONE);
                initDropdowns();
                Page.MaintainScrollPositionOnPostBack = false;
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpSelectProperty, DrpDataType.PROPERTY_NAME, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.populateDrpPRStageNo(drpStageNo);
        drpBO.drpEnum<PRScheduleStageStatus>(drpStatus, null);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        applyEntitlement();
        preRenderInitFormElements();
        initBootstrapComponantsFromServer();
    }
    private bool isViewOnlyUser()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        bool isViewOnlyUser = !CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.FIRM_MEMBER_ADD_UPDATE);
        return isViewOnlyUser;
    }
    private void applyEntitlement()
    {
        if (isViewOnlyUser())
        {
            resetPageInfo(PageMode.VIEW);
        }
    }
    private void preRenderInitFormElements()
    {
        jumpToPropertyScheduleHdnId.Value = "";
        PropertyScheduleDTO propertyScheduleDTO = getSelectedPropertyScheduleStage();
        if(propertyScheduleDTO != null) {
            jumpToPropertyScheduleHdnId.Value = propertyScheduleDTO.UiIndex+"";
        }
    }
    public void setErrorMessage(string message, string group)
    {
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }

    public void setSuccessMessage(string msg)
    {
        lbTab1Success.Text = msg;
        tab1SuccessPanel.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private void clearMessages()
    {
        tab1SuccessPanel.Visible = false;
        lbTab1Success.Text = "";
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }

    private void resetPageInfo(PageMode pageMode)
    {
        pageModeHdn.Value = pageMode.ToString();
        initFormFields();
        pnlPropertyScheduleAdd.Visible = false;
        if (PageMode.NONE == pageMode)
        {
            pnlPropertyScheduleGrid.Visible = false;
            ViewState[VS_PR_PYMT_SCHED_LIST] = new List<PropertyScheduleDTO>();
        }
        else
        {
            pnlPropertyScheduleGrid.Visible = true;
        }
    }
    private void initFormFields()
    {
        bool isReadOnly = (PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
        bool visible = !(PageMode.VIEW.ToString().Equals(pageModeHdn.Value));
        //Buttons
        btnAddSubmit.Visible = visible;
        btnAddPropertySchedule.Visible = visible;
        btnModifyPropertySchedule.Visible = visible;
        btnDeletePropertySchedule.Visible = visible;
        propertyScheduleGrid.Columns[0].Visible = visible;
    }
    private List<PropertyScheduleDTO> getPropertyScheduleList()
    {
        return (List<PropertyScheduleDTO>)ViewState[VS_PR_PYMT_SCHED_LIST];
    }
    private PropertyScheduleDTO getSelectedPropertyScheduleStage()
    {
        PropertyScheduleDTO selectedStage = null;
        List<PropertyScheduleDTO> prSchedList = getPropertyScheduleList();
        if (prSchedList != null)
        {
            selectedStage = prSchedList.Find(c => c.isUISelected);
        }
        return selectedStage;
    }
    private void setSelectedPropertyScheduleStage(long selectedUiIndex)
    {
        List<PropertyScheduleDTO> prSchedList = getPropertyScheduleList();
        if (prSchedList != null)
        {
            prSchedList.ForEach(c => c.isUISelected = false);
            if(selectedUiIndex != -1) prSchedList.Find(c => c.UiIndex == selectedUiIndex).isUISelected = true;
        }
    }
    private void initPropertyScheduleAddUpdateSection(bool isAdd)
    {
        lbPropertyScheduleAddUpdateSectionHeader.Text = (isAdd) ? Resources.Labels.label_sectionheader_propertysched_add : Resources.Labels.label_sectionheader_propertysched_modify;
        pnlPropertyScheduleAdd.Visible = true;
        btnPropertyScheduleAddToGrid.Visible = isAdd;
        btnPropertyScheduleUpdateToGrid.Visible = !isAdd;
    }
    private void setDefaultOnAddPropertyTower()
    {
        
    }
    private void initPropertyScheduleSectionFields(PropertyScheduleDTO propertyScheduleDto)
    {
        if (propertyScheduleDto != null) initDrpStageNo(propertyScheduleDto.StageNumber); else initDrpStageNo(-1);
        if (propertyScheduleDto != null) drpStageNo.Text = propertyScheduleDto.StageNumber+""; else drpStageNo.ClearSelection();
        if (propertyScheduleDto != null) txtStage.Text = propertyScheduleDto.Stage; else txtStage.Text = null;
        if (propertyScheduleDto != null) txtPercentage.Text = propertyScheduleDto.Percentage.ToString(); else txtPercentage.Text = null;
        if (propertyScheduleDto != null) drpStatus.Text = propertyScheduleDto.Status.ToString(); else drpStatus.ClearSelection();
    }
    private void resetPropertyScheduleSelection(long uiIndex)
    {
        if (propertyScheduleGrid.Rows.Count > 0)
        {
            foreach (GridViewRow row in propertyScheduleGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdPropertyScheduleSelect");
                radioBtn.Checked = false;
                if (uiIndex > 0)
                {
                    Button rowIdenBtn = (Button)row.FindControl("btnPropertyScheduleRowIdentifier");
                    if (rowIdenBtn != null && uiIndex.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                    {
                        radioBtn.Checked = true;
                        setSelectedPropertyScheduleStage(uiIndex);
                    }
                }
            }
        }
        if (uiIndex <= 0) setSelectedPropertyScheduleStage(-1);
    }
    private bool validatePropertyScheduleStageSelected()
    {
        bool isSelected = true;
        PropertyScheduleDTO selectedStage = getSelectedPropertyScheduleStage();
        if (selectedStage == null)
        {
            isSelected = false;
            setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Payment Schedule Stage"), tab1ValidationGrp);
        }
        return isSelected;
    }
    private void reBindPropertyScheduleGrid(List<PropertyScheduleDTO> prSchedList, PropertyScheduleDTO propertyScheduleDto)
    {
        if (prSchedList != null)
        {
            assignUiIndexToPropertySchedule(prSchedList);
            propertyScheduleGrid.DataSource = prSchedList;
            propertyScheduleGrid.DataBind();
            if (propertyScheduleDto != null) resetPropertyScheduleSelection(propertyScheduleDto.UiIndex);
        }
    }
    private void assignUiIndexToPropertySchedule(List<PropertyScheduleDTO> prScheduleDtos)
    {
        if (prScheduleDtos != null && prScheduleDtos.Count > 0)
        {
            prScheduleDtos.ForEach(c => c.isUISelected = false);
            long uiIndex = 1;
            foreach (PropertyScheduleDTO prScheduleDto in prScheduleDtos)
            {
                prScheduleDto.UiIndex = uiIndex++;
                prScheduleDto.RowInfo = CommonUIConverter.getGridViewRowInfo(prScheduleDto);
            }
        }
    }
    private void loadPropertyScheduleGrid()
    {
        try
        {
            List<PropertyScheduleDTO> results = new List<PropertyScheduleDTO>();
            if (!(string.IsNullOrWhiteSpace(drpSelectProperty.Text) || string.IsNullOrWhiteSpace(drpSelectPropertyTower.Text))) {
                long towerId = long.Parse(drpSelectPropertyTower.Text);
                results = propertyBO.fetchPropertySchedule(getUserDefinitionDTO().FirmNumber, towerId);
                assignUiIndexToPropertySchedule(results);
            }
            ViewState[VS_PR_PYMT_SCHED_LIST] = results;
            propertyScheduleGrid.DataSource = results;
            propertyScheduleGrid.DataBind();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSelectProperty(object sender, EventArgs e)
    {
        try
        {
            resetPageInfo(PageMode.NONE);
            drpBO.drpDataBase(drpSelectPropertyTower, DrpDataType.PROPERTY_TOWER, drpSelectProperty.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            if (drpSelectPropertyTower.Items.Count == 2)
            {
                drpSelectPropertyTower.Items[1].Selected = true;
                resetPageInfo(PageMode.ADD);
                loadPropertyScheduleGrid();
            }
        } 
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSelectPropertyTower(object sender, EventArgs e)
    {
        try
        {
            if(!string.IsNullOrWhiteSpace(drpSelectPropertyTower.Text)) {
                resetPageInfo(PageMode.ADD);
                loadPropertyScheduleGrid();
            } else {
                resetPageInfo(PageMode.NONE);
            }
        } 
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onSelectPropertyScheduleStage(object sender, EventArgs e)
    {
        try
        {
            GroupRadioButton rd = (GroupRadioButton)sender;
            pnlPropertyScheduleAdd.Visible = false;
            if (rd.Checked)
            {
                long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnPropertyScheduleRowIdentifier"))).Attributes["row-identifier"]);
                setSelectedPropertyScheduleStage(UiIndex);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickAddPropertyScheduleBtn(object sender, EventArgs e)
    {
        try
        {
            resetPropertyScheduleSelection(-1);
            initPropertyScheduleAddUpdateSection(true);
            initPropertyScheduleSectionFields(null);
            SetFocus(drpStageNo);
            scrollToFieldHdn.Value = pnlPropertyScheduleAdd.ID;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void onClickModifyPropertyScheduleBtn(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyScheduleStageSelected())
            {
                initPropertyScheduleAddUpdateSection(false);
                initPropertyScheduleSectionFields(getSelectedPropertyScheduleStage());
                SetFocus(drpStageNo);
                scrollToFieldHdn.Value = pnlPropertyScheduleAdd.ID;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void deletePropertySchedule(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyScheduleStageSelected())
            {
                List<PropertyScheduleDTO> prSchedList = getPropertyScheduleList();
                PropertyScheduleDTO PropertyScheduleDto = getSelectedPropertyScheduleStage();
                prSchedList.Remove(PropertyScheduleDto);
                reBindPropertyScheduleGrid(prSchedList, null);
                setSuccessMessage(string.Format(Resources.Messages.success_record_deletedfromtable, "Stage"));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void addNewPropertySchedule(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertySchedule())
            {
                PropertyScheduleDTO propertyScheduleDto = populatePropertyScheduleDTOAddFromUI();
                List<PropertyScheduleDTO> prSchedList = getPropertyScheduleList();
                prSchedList.Add(propertyScheduleDto);
                pnlPropertyScheduleAdd.Visible = false;
                reBindPropertyScheduleGrid(prSchedList, propertyScheduleDto);
                setSuccessMessage(string.Format(Resources.Messages.success_record_addedtotable, "Stage"));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void updatePropertySchedule(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertySchedule())
            {
                PropertyScheduleDTO propertyScheduleDto = getSelectedPropertyScheduleStage();
                populatePropertyScheduleStageFromUI(propertyScheduleDto);
                pnlPropertyScheduleAdd.Visible = false;
                reBindPropertyScheduleGrid(getPropertyScheduleList(), propertyScheduleDto);
                setSuccessMessage(string.Format(Resources.Messages.success_record_updatedtotable, "Stage"));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    protected void cancelPropertySchedule(object sender, EventArgs e)
    {
        pnlPropertyScheduleAdd.Visible = false;
        resetPropertyScheduleSelection(-1);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    protected void savePropertyScheduleToDB(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyScheduleBeforeSaveToDB())
            {
                List<PropertyScheduleDTO> prSchedList = getPropertyScheduleList();
                PropertyTowerDTO propertyTowerDto = new PropertyTowerDTO();
                propertyTowerDto.Id = long.Parse(drpSelectPropertyTower.Text);
                propertyTowerDto.FirmNumber = getUserDefinitionDTO().FirmNumber;
                propertyTowerDto.PropertySchedules = new HashSet<PropertyScheduleDTO>(prSchedList);
                //Save list to DB
                propertyBO.saveOrUpdatePropertySchedule(propertyTowerDto);
                pnlPropertyScheduleAdd.Visible = false;
                loadPropertyScheduleGrid();
                setSuccessMessage(Resources.Messages.success_property_pymt_schedule_update);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private PropertyScheduleDTO populatePropertyScheduleDTOAddFromUI()
    {
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        PropertyScheduleDTO propertyScheduleDTO = new PropertyScheduleDTO();
        PropertyTowerDTO propertyTowerDto = new PropertyTowerDTO();
        propertyTowerDto.Id = long.Parse(drpSelectPropertyTower.Text);
        propertyTowerDto.FirmNumber = userDef.FirmNumber;
        propertyScheduleDTO.PropertyTower = propertyTowerDto;
        propertyScheduleDTO.FirmNumber = userDef.FirmNumber;
        propertyScheduleDTO.InsertUser = userDef.Username;
        populatePropertyScheduleStageFromUI(propertyScheduleDTO);
        return propertyScheduleDTO;
    }
    private void populatePropertyScheduleStageFromUI(PropertyScheduleDTO propertyScheduleDTO)
    {
        propertyScheduleDTO.StageNumber = Convert.ToInt32(drpStageNo.Text);
        propertyScheduleDTO.Stage = txtStage.Text;
        propertyScheduleDTO.Percentage = CommonUtil.getDecimaNotNulllWithoutExt(txtPercentage.Text);
        propertyScheduleDTO.Status = EnumHelper.ToEnum<PRScheduleStageStatus>(drpStatus.Text);
        propertyScheduleDTO.UpdateUser = getUserDefinitionDTO().Username;
    }
    private void initDrpStageNo(int stageNo)
    {
        List<PropertyScheduleDTO> prSchedList = getPropertyScheduleList();
        drpStageNo.Items.Clear();
        for (int i = 1; i <= 30; i++)
        {
            if (prSchedList == null || stageNo == i || !prSchedList.Exists(p => p.StageNumber == i))
            {
                drpStageNo.Items.Add(new ListItem(i + "", i + ""));
            }
        }
    }
    private bool validatePropertySchedule()
    {
        bool isValid = true;
        Page.Validate(tab1ValidationGrp);
        isValid = Page.IsValid;
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    private bool validatePropertyScheduleBeforeSaveToDB()
    {
        bool isValid = validatePercentageTotal() && validateStageNoSequence() && validateStageStatus();
        
        return isValid;
    }
    private bool validatePercentageTotal()
    {
        bool isValid = true;
        List<PropertyScheduleDTO> prSchedList = getPropertyScheduleList();
        if (prSchedList != null)
        {
            decimal totalPercentage = decimal.Zero;
            foreach(PropertyScheduleDTO propertyScheduleDto in prSchedList) {
                totalPercentage = totalPercentage + propertyScheduleDto.Percentage;
            }
            if (totalPercentage > new decimal(100.00))
            {
                setErrorMessage(Resources.Messages.validation_property_pymt_schd_100_percent, tab1ValidationGrp);
                isValid = false;
            }
        }
        return isValid;
    }
    private bool validateStageNoSequence()
    {
        bool isValid = true;
        List<PropertyScheduleDTO> prSchedList = getPropertyScheduleList();
        if (prSchedList != null)
        {
            prSchedList.Sort((x, y) => x.StageNumber.CompareTo(y.StageNumber));
            int tmpStageNumber = 1;
            string missingStageNos = "";
            foreach (PropertyScheduleDTO propertyScheduleDto in prSchedList)
            {
                if (tmpStageNumber < propertyScheduleDto.StageNumber)
                {
                    for (int i = tmpStageNumber; i < propertyScheduleDto.StageNumber; i++)
                    {
                        missingStageNos += (string.IsNullOrWhiteSpace(missingStageNos)) ? i + "" : ", " + i;
                    }
                    isValid = false;
                }
                tmpStageNumber = propertyScheduleDto.StageNumber + 1;
            }
            if (!isValid)
            {
                string msg = string.Format(Resources.Messages.validation_property_pymt_schd_stage_missing, missingStageNos);
                setErrorMessage(msg, tab1ValidationGrp);
            }
        }
        return isValid;
    }
    private bool validateStageStatus()
    {
        bool isValid = true;
        List<PropertyScheduleDTO> prSchedList = getPropertyScheduleList();
        if (prSchedList != null)
        {
            prSchedList.Sort((x, y) => x.StageNumber.CompareTo(y.StageNumber));
            int minPendingStageNumber = -1;
            int maxCompletedStageNumber = -1;
            foreach (PropertyScheduleDTO propertyScheduleDto in prSchedList)
            {
                if (PRScheduleStageStatus.Completed == propertyScheduleDto.Status) maxCompletedStageNumber = propertyScheduleDto.StageNumber;
                if (minPendingStageNumber == -1 && PRScheduleStageStatus.Pending == propertyScheduleDto.Status) minPendingStageNumber = propertyScheduleDto.StageNumber;
            }
            if (minPendingStageNumber < maxCompletedStageNumber)
            {
                setErrorMessage(Resources.Messages.validation_property_pymt_sched_incorrect_status, tab1ValidationGrp);
                isValid = false;
            }
        }
        return isValid;
    }
}
