﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Vladsm.Web.UI.WebControls;
using ConstroSoft;

public partial class AccountSummary : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
          log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string tab1Error = "tab1Error";
    string VS_ACNT_SUMMARY_LIST = "ACNT_SUMMARY_LIST";
    string VS_ACNT = "ACCOUNT";
    DropdownBO drpBO = new DropdownBO();
    FirmBO firmBO = new FirmBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (Session[Constants.Session.USERNAME] != null)
            {
                resetTabInfo();
                initDropdowns();
                Page.MaintainScrollPositionOnPostBack = false;
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpAccount, DrpDataType.FIRM_ACCOUNT, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<AcntTransStmtOption>(drpAcntStmtPeriod, null);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        applyEntitlement();
        preRenderInitFormElements();
        initBootstrapComponantsFromServer();
    }
    private bool isViewOnlyUser()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        bool isViewOnlyUser = !CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.FIRM_ACCOUNT_ADD_UPDATE);
        return isViewOnlyUser;
    }
    private void applyEntitlement()
    {
        if (isViewOnlyUser())
        {
            
        }
    }
    private void preRenderInitFormElements()
    {
        populateAccountSummary();
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        this.Page.Validators.Add(val);
    }
    public void setSuccessMessage(string msg, string tabId)
    {
        lbTab1Success.Text = msg;
        tab1SuccessPanel.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private void clearMessages()
    {
        tab1SuccessPanel.Visible = false;
        lbTab1Success.Text = "";
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }

    private FirmAccountDTO getAccountDTO()
    {
        return (FirmAccountDTO)ViewState[VS_ACNT];
    }

    private void resetTabInfo()
    {
        ViewState[VS_ACNT_SUMMARY_LIST] = null;
        ViewState[VS_ACNT] = null;
        pnlAcntSummary.Visible = false;
    }
    protected void onSelectAccount(object sender, EventArgs e)
    {
        try
        {
            resetTabInfo();
            if (!string.IsNullOrWhiteSpace(drpAccount.Text))
            {
                pnlAcntSummary.Visible = true;
                long Id = long.Parse(drpAccount.Text);
                FirmAccountDTO firmAccountDto = firmBO.fetchFirmAccount(Id);
                ViewState[VS_ACNT] = firmAccountDto;
                populateAccountSummary();
                DateTime now = DateTime.Now;
                DateTime startDate = new DateTime(now.Year, now.Month, 1);
                fetchAndPopulateAcntTrans(startDate, DateTime.Now);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1Error);
        }
    }
    protected void onSelectAcntStmtPeriod(object sender, EventArgs e)
    {
        try
        {
            AcntTransStmtOption stmtOpts = EnumHelper.ToEnum<AcntTransStmtOption>(drpAcntStmtPeriod.Text);
            if (AcntTransStmtOption.LAST_TWO_MONTHS == stmtOpts || AcntTransStmtOption.LAST_THREE_MONTHS == stmtOpts)
            {
                DateTime now = DateTime.Now;
                DateTime startDate = new DateTime(now.Year, now.Month, 1);
                DateTime endDate = DateTime.Now;
                if (AcntTransStmtOption.LAST_TWO_MONTHS == stmtOpts)
                {
                    now = now.AddMonths(-1);
                    startDate = new DateTime(now.Year, now.Month, 1);
                    fetchAndPopulateAcntTrans(startDate, endDate);
                }
                else if (AcntTransStmtOption.LAST_THREE_MONTHS == stmtOpts)
                {
                    now = now.AddMonths(-2);
                    startDate = new DateTime(now.Year, now.Month, 1);
                    fetchAndPopulateAcntTrans(startDate, endDate);
                }
                pnlDateRange.Visible = false;
            }
            else
            {
                txtStmtFrom.Text = null;
                txtStmtTo.Text = null;
                pnlDateRange.Visible = true;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1Error);
        }
    }
    protected void fetchAccountTransactions(object sender, EventArgs e)
    {
        try
        {
            if (validateDateRange())
            {
                DateTime startDate = CommonUtil.getCSDateNotNull(txtStmtFrom.Text);
                DateTime endDate = CommonUtil.getCSDateNotNull(txtStmtTo.Text);
                fetchAndPopulateAcntTrans(startDate, endDate);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1Error);
        }
    }
    protected void downloadStmtPdf(object sender, EventArgs e)
    {
        try
        {
            
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab1Error);
        }
    }
    private bool validateDateRange()
    {
        bool isValid = true;
        Page.Validate("tab1Error");
        isValid = Page.IsValid;
        if (isValid)
        {
            DateTime fromDate = CommonUtil.getCSDateNotNull(txtStmtFrom.Text);
            DateTime toDate = CommonUtil.getCSDateNotNull(txtStmtTo.Text);
            if (fromDate.CompareTo(toDate) > 0)
            {
                setErrorMessage("From date cannot be greater than To date.", tab1Error);
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
                isValid = false;
            }
        }
        return isValid;
    }
    private void populateAccountSummary()
    {
        FirmAccountDTO accountDto = getAccountDTO();
        if (accountDto != null)
        {
            txtAcntName.Text = accountDto.Name;
            txtAcntNumber.Text = accountDto.AccountNo;
            txtAcntType.Text = accountDto.AccountType.Name;
            txtAcntBalance.Text = accountDto.AccountBalance.ToString();
        }
    }
    private void fetchAndPopulateAcntTrans(DateTime startDate, DateTime endDate)
    {
        FirmAccountDTO accountDto = getAccountDTO();
        if (accountDto != null)
        {
            IList<AccountTransactionDTO> acntTransDtoList = firmBO.fetchAccountTransactions(getUserDefinitionDTO().FirmNumber, accountDto.Id, startDate);
            List<AccountTransactionDTO> tmpAcntList = new List<AccountTransactionDTO>();
            foreach (AccountTransactionDTO tmpAcntTransDto in acntTransDtoList)
            {
                if(AcntTransStatus.Credit == tmpAcntTransDto.TxType) tmpAcntTransDto.UiCreditAmt = tmpAcntTransDto.Amount;
                else tmpAcntTransDto.UiDebitAmt = tmpAcntTransDto.Amount;
                if (tmpAcntTransDto.TxDate.CompareTo(startDate) >= 0 && tmpAcntTransDto.TxDate.CompareTo(endDate) <= 0)
                {
                    tmpAcntList.Add(tmpAcntTransDto);
                }
            }
            ViewState[VS_ACNT_SUMMARY_LIST] = tmpAcntList;
            acntSummaryGrid.DataSource = tmpAcntList;
            acntSummaryGrid.DataBind();
        }
    }
}