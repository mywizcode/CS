﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using Vladsm.Web.UI.WebControls;

public partial class ManageFirm : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string tab1ValidationGrp = "tab1Error";
    string tab2ValidationGrp = "tab2Error";
    string VS_FIRM = "FIRM";
    DropdownBO drpBO = new DropdownBO();
    FirmBO firmBO = new FirmBO();
    public enum FirmPageMode { MODIFY, VIEW }
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                initDropdowns();
                fetchFirmDetails();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = getUserInfoDto();
        drpBO.drpDataBase(drpAcntType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ACCOUNT_TYPE, null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAddressCountry, DrpDataType.COUNTRY, null, null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAddressState, DrpDataType.STATE, Constants.DEFAULT_COUNTRY, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        initCityDrp(drpAddressCity, Constants.DEFAULT_STATE);
    }
    private void initCityDrp(DropDownList drp, string stateId)
    {
        drpBO.drpDataBase(drp, DrpDataType.CITY, stateId, Constants.SELECT_ITEM, getUserInfoDto().FirmNumber);
    }
    private UserDefinitionDTO getUserInfoDto()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        applyEntitlement();
        preRenderInitFormElements();
        initBootstrapComponantsFromServer();
    }
    private bool isViewOnlyUser()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        bool isViewOnlyUser = !CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.FIRM_ACCOUNT_ADD_UPDATE);
        return isViewOnlyUser;
    }
    private void applyEntitlement()
    {
        if (isViewOnlyUser())
        {
            //TODO - Hide buttons when read only user
            btnFirmUpdate.Visible = false;
            viewOnlyTableHdn.Value = "true";
            accountGrid.Columns[0].Visible = false;
            addAccountBtn.Visible = false;
        }
    }
    private void preRenderInitFormElements()
    {
        if(pageModeHdn.Value == FirmPageMode.VIEW.ToString()) {
            populateFirmDetails(false);
        }
    }
    private void clearMessages()
    {
        tab1SuccessPanel.Visible = false;
        lbTab1Success.Text = "";
        tab2SuccessPanel.Visible = false;
        lbTab2Success.Text = "";
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
    }

    public void setSuccessMessage(string msg, string tabId)
    {
        activeTabHdn.Value = tabId;
        if (tab1Anchor.ID.Equals(tabId))
        {
            lbTab1Success.Text = msg;
            tab1SuccessPanel.Visible = true;
        }
        else if (tab2Anchor.ID.Equals(tabId))
        {
            lbTab2Success.Text = msg;
            tab2SuccessPanel.Visible = true;
        }
    }
    private FirmDTO getFirmDto() {
        return (FirmDTO)ViewState[VS_FIRM];
    }
    private void setTabInfo(FirmPageMode pageMode, string activeTabValue)
    {
        pageModeHdn.Value = pageMode.ToString();
        bool isFirmView = (FirmPageMode.VIEW == pageMode);
        btnFirmUpdate.Visible = !isFirmView;
        btnFirmCancel.Visible = !isFirmView;
        btnFirmEdit.Visible = isFirmView;
        activeTabHdn.Value = activeTabValue;

        pnlAccountAdd.Visible = false;
    }
    
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private void fetchFirmDetails() {
        try
        {
            setTabInfo(FirmPageMode.VIEW, tab1Anchor.ID);
            ViewState[VS_FIRM] = null;
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            FirmDTO firmDto = firmBO.fetchFirmDetails(userDefDto.FirmNumber);
            ViewState[VS_FIRM] = firmDto;
            populateFirmDetails(true);
        }catch (Exception exp)
        {
            log.Error(exp.Message);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private void populateFirmDetails(bool reloadAccountGrid)
    {
        try
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            FirmDTO firmDto = getFirmDto();
            ContactInfoDTO contantInfo = null;
            AddressDTO addressDto = null;
            if (firmDto != null) contantInfo = firmDto.ContactInfo;
            if (contantInfo != null) addressDto = contantInfo.Addresses.ToList<AddressDTO>().FirstOrDefault();
            
            if (firmDto != null) txtFirmName.Text = firmDto.Name; else txtFirmName.Text = null;
            if (firmDto != null) txtRegistrationNo.Text = firmDto.RegistrationNo; else txtRegistrationNo.Text = null;
            if (contantInfo != null) txtContact.Text = contantInfo.Contact; else txtContact.Text = null;
            if (firmDto != null) txtDescription.Text = firmDto.Description; else txtDescription.Text = null;
            if (contantInfo != null) txtEmail.Text = contantInfo.Email; else txtEmail.Text = null;
            if (addressDto != null) txtAddressLine1.Text = addressDto.AddressLine1; else txtAddressLine1.Text = null;
            if (addressDto != null) txtAddressLine2.Text = addressDto.AddressLine2; else txtAddressLine2.Text = null;
            if (addressDto != null) txtTown.Text = addressDto.Town; else txtTown.Text = null;
            if (addressDto != null) drpAddressCountry.Text = addressDto.Country.Id.ToString(); else drpAddressCountry.Text = null;
            if (addressDto != null) drpAddressState.Text = addressDto.State.Id.ToString(); else drpAddressState.Text = null;
            if (addressDto != null) initCityDrp(drpAddressCity, drpAddressState.Text);
            if (addressDto != null) drpAddressCity.Text = addressDto.City.Id.ToString(); else drpAddressCity.ClearSelection();
            if (addressDto != null) txtPin.Text = addressDto.Pin; else txtPin.Text = null;
            if (reloadAccountGrid) populateAccountGrid(firmDto);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message);
            setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
        }
    }
    private void populateAccountGrid(FirmDTO firmDto)
    {
        accountGrid.DataSource = new List<FirmAccountDTO>();
        if (firmDto != null)
        {
            assignUiIndexToAccount(firmDto.FirmAccounts);
            accountGrid.DataSource = firmDto.FirmAccounts;
        }
        accountGrid.DataBind();
    }
    private void assignUiIndexToAccount(ISet<FirmAccountDTO> accountDtos)
    {
        if (accountDtos != null && accountDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (FirmAccountDTO accountDto in accountDtos)
            {
                accountDto.UiIndex = uiIndex++;
                accountDto.RowInfo = CommonUIConverter.getGridViewRowInfo(accountDto);
            }
        }
    }
    protected void loadCities(object sender, EventArgs e)
    {
        initCityDrp(drpAddressCity, drpAddressState.Text);
    }
    protected void loadAcntCities(object sender, EventArgs e)
    {
        initCityDrp(drpAcntCity, drpAcntState.Text);
    }
    protected void onClickEditFirmDetails(object sender, EventArgs e)
    {
        try
        {
            clearAccountSelection();
            setTabInfo(FirmPageMode.MODIFY, tab1Anchor.ID);
            populateFirmDetails(false);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    private void initAccountDetailUiFields(FirmAccountDTO accountDto) {
        if(accountDto != null) txtAcntName.Text = accountDto.Name; else txtAcntName.Text = null;
        if(accountDto != null) drpAcntType.Text = accountDto.AccountType.Id.ToString(); else drpAcntType.ClearSelection();
        if(accountDto != null) txtAcntNumber.Text = accountDto.AccountNo; else txtAcntNumber.Text = null;
        if(accountDto != null) txtAcntBalance.Text = accountDto.AccountBalance.ToString(); else txtAcntBalance.Text = null;
        if(accountDto != null) txtAcntIFSCCode.Text = accountDto.IfscCode; else txtAcntIFSCCode.Text = null;
        if(accountDto != null) txtAcntBankName.Text = accountDto.BankName; else txtAcntBankName.Text = null;
        if(accountDto != null) txtAcntBranch.Text = accountDto.Branch; else txtAcntBranch.Text = null;
        if(accountDto != null && accountDto.City != null) drpAcntCity.Text = accountDto.City.Id.ToString(); else drpAcntCity.ClearSelection();
        if(accountDto != null && accountDto.State != null) drpAcntState.Text = accountDto.State.Id.ToString(); else drpAcntState.ClearSelection();
        if(accountDto != null && accountDto.Country != null) drpAcntCountry.Text = accountDto.Country.Id.ToString(); else drpAcntCountry.ClearSelection();
    }
    private void initAccountAddUpdateSection(bool isAdd)
    {
        lbAcntAction.Text = (isAdd) ? Resources.Labels.label_sectionheader_addaccount : Resources.Labels.label_sectionheader_updateaccount;
        pnlAccountAdd.Visible = true;
        btnAcntSave.Visible = isAdd;
        btnAcntUpdate.Visible = !isAdd;
        drpBO.drpDataBase(drpAcntCountry, DrpDataType.COUNTRY, null, null, getUserInfoDto().FirmNumber);
        drpBO.drpDataBase(drpAcntState, DrpDataType.STATE, Constants.DEFAULT_COUNTRY, Constants.SELECT_ITEM, getUserInfoDto().FirmNumber);
        drpBO.drpDataBase(drpAcntCity, DrpDataType.CITY, Constants.DEFAULT_STATE, Constants.SELECT_ITEM, getUserInfoDto().FirmNumber);
        drpAcntState.Text = Constants.DEFAULT_STATE;
    }
    private void clearAccountSelection()
    {
        if (accountGrid.Rows.Count > 0)
        {
            foreach (GridViewRow row in accountGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdAccountSelect");
                if (radioBtn != null) radioBtn.Checked = false;
            }
        }
        FirmDTO firmDto = getFirmDto();
        if (firmDto.FirmAccounts != null) firmDto.FirmAccounts.ToList<FirmAccountDTO>().ForEach(c => c.isUISelected = false);
    }
    private void selectAccount(FirmAccountDTO accountDto)
    {
        if (accountGrid.Rows.Count > 0)
        {
            accountDto.isUISelected = true;
            foreach (GridViewRow row in accountGrid.Rows)
            {
                GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdAccountSelect");
                Button rowIdenBtn = (Button)row.FindControl("acntRowIndBtn");
                radioBtn.Checked = false;
                if (rowIdenBtn != null && accountDto.UiIndex.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                {
                    radioBtn.Checked = true;
                }
            }
        }
    }
    private FirmAccountDTO getSelectedAccount()
    {
        return (getFirmDto() != null) ? getFirmDto().FirmAccounts.ToList<FirmAccountDTO>().Find(c => c.isUISelected) : null;
    }
    private bool validateAccountSelected()
    {
        bool isSelected = true;
        FirmAccountDTO accountDto = getSelectedAccount();
        if (accountDto == null)
        {
            isSelected = false;
            pnlAccountAdd.Visible = false;
            clearAccountSelection();
            setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Account"), tab2ValidationGrp);
        }
        return isSelected;
    }
    protected void selectAccount(object sender, EventArgs e)
    {
        GroupRadioButton rd = (GroupRadioButton)sender;
        pnlAccountAdd.Visible = false;
        if (rd.Checked)
        {
            long UiIndex = long.Parse(((Button)(((GridViewRow)rd.NamingContainer).FindControl("acntRowIndBtn"))).Attributes["row-identifier"]);
            List<FirmAccountDTO> accountList = getFirmDto().FirmAccounts.ToList<FirmAccountDTO>();
            accountList.ForEach(c => c.isUISelected = false);
            accountList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
        }
    }
    protected void onClickAddAccountBtn(object sender, EventArgs e)
    {
        try
        {
            clearAccountSelection();
            initAccountAddUpdateSection(true);
            initAccountDetailUiFields(null);
            SetFocus(txtAcntName);
            scrollToFieldHdn.Value = pnlAccountAdd.ID;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void editSelectedAccount(object sender, EventArgs e)
    {
        try
        {
            if (validateAccountSelected())
            {
                initAccountAddUpdateSection(false);
                initAccountDetailUiFields(getSelectedAccount());
                SetFocus(txtAcntName);
                scrollToFieldHdn.Value = pnlAccountAdd.ID;
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void deleteAccount(object sender, EventArgs e)
    {
        try
        {
            if (validateAccountSelected())
            {
                pnlAccountAdd.Visible = false;
                FirmAccountDTO accountDto = getSelectedAccount();
                firmBO.deleteFirmAccount(accountDto.Id);
                fetchFirmDetails();
                setSuccessMessage(Resources.Messages.firm_success_acnt_delete, tab2Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
        }
    }
    protected void addNewAccount(object sender, EventArgs e)
    {
        try
        {
            if (validateAccountAddUpdate())
            {
                FirmAccountDTO firmAccountDto = populateAccountDTO();
                firmBO.saveFirmAccount(firmAccountDto);
                fetchFirmDetails();
                setSuccessMessage(Resources.Messages.firm_success_acnt_add, tab2Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message);
            setErrorMessage(exp.Message, tab2ValidationGrp);
        }
    }
    protected void updateAccount(object sender, EventArgs e)
    {
        try
        {
            if (validateAccountSelected() && validateAccountAddUpdate())
            {
                FirmAccountDTO accountDto = getSelectedAccount();
                UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
                populateAccountFromUI(accountDto, userDefDto);
                firmBO.updateFirmAccount(accountDto);
                fetchFirmDetails();
                setSuccessMessage(Resources.Messages.firm_success_acnt_update, tab2Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message);
            setErrorMessage(exp.Message, tab2ValidationGrp);
        }
    }
    protected void cancelAccount(object sender, EventArgs e)
    {
        pnlAccountAdd.Visible = false;
        clearAccountSelection();
    }
    private bool validateAccountAddUpdate()
    {
        Page.Validate(tab2ValidationGrp);
        return Page.IsValid;
    }
    protected void cancelFirmChanges(object sender, EventArgs e)
    {
        setTabInfo(FirmPageMode.VIEW, tab1Anchor.ID);
    }
    protected void updateFirmDetails(object sender, EventArgs e)
    {
        try
        {
            if (validateFirmUpdate())
            {
                FirmDTO firmDto = (FirmDTO)ViewState[VS_FIRM];
                UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
                populateFirmFromUI(firmDto, userDefDto);
                firmBO.updateFirm(firmDto);
                fetchFirmDetails();
                setSuccessMessage(Resources.Messages.firm_success_firm_update, tab1Anchor.ID);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message);
            setErrorMessage(exp.Message, tab1ValidationGrp);
        }
    }
    private bool validateFirmUpdate()
    {
        Page.Validate(tab1ValidationGrp);
        return Page.IsValid;
    }
    private void populateFirmFromUI(FirmDTO firmDto, UserDefinitionDTO userDefDto)
    {
        firmDto.RegistrationNo = txtRegistrationNo.Text;
        firmDto.ContactInfo.Contact = txtContact.Text;
        firmDto.Description = txtDescription.Text;
        firmDto.ContactInfo.Email = txtEmail.Text;
        firmDto.WebSite = txtWebSite.Text;
        AddressDTO addressDto = firmDto.ContactInfo.Addresses.First<AddressDTO>();
        firmDto.ContactInfo.Addresses.Clear();
        firmDto.ContactInfo.Addresses.Add(addressDto);
        addressDto.AddressLine1 = txtAddressLine1.Text;
        addressDto.AddressLine2 = txtAddressLine2.Text;
        addressDto.Town = txtTown.Text;
        addressDto.City = CommonUIConverter.getCityDTO(drpAddressCity.Text, drpAddressCity.SelectedItem.Text);
        addressDto.State = CommonUIConverter.getStateDTO(drpAddressState.Text, drpAddressState.SelectedItem.Text);
        addressDto.Country = CommonUIConverter.getCountryDTO(drpAddressCountry.Text, drpAddressCountry.SelectedItem.Text);
        addressDto.Pin = txtPin.Text;
        firmDto.UpdateUser = userDefDto.Username;
    }
    private FirmAccountDTO populateAccountDTO()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        FirmDTO firmDto = (FirmDTO)ViewState[VS_FIRM];
        FirmAccountDTO accountDto = new FirmAccountDTO();
        populateAccountFromUI(accountDto, userDefDto);
        accountDto.FirmNumber = userDefDto.FirmNumber;
        accountDto.InsertUser = userDefDto.Username;
        accountDto.Firm = firmDto;
        return accountDto;
    }
    private void populateAccountFromUI(FirmAccountDTO accountDto, UserDefinitionDTO userDefDto)
    {
        accountDto.Name = txtAcntName.Text;
        accountDto.AccountType = CommonUIConverter.getMasterControlDTO(drpAcntType.Text, drpAcntType.SelectedItem.Text);
        accountDto.AccountNo = txtAcntNumber.Text;
        accountDto.IfscCode = txtAcntIFSCCode.Text;
        accountDto.BankName = txtAcntBankName.Text;
        accountDto.Branch = txtAcntBranch.Text;
        accountDto.City = CommonUIConverter.getCityDTO(drpAcntCity.Text, drpAcntCity.SelectedItem.Text);
        accountDto.State = CommonUIConverter.getStateDTO(drpAcntState.Text, drpAcntState.SelectedItem.Text);
        accountDto.Country = CommonUIConverter.getCountryDTO(drpAcntCountry.Text, drpAcntCountry.SelectedItem.Text);
        accountDto.UpdateUser = userDefDto.Username;
    }
}
