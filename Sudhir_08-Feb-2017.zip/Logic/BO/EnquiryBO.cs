﻿using System;
using NHibernate;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using ConstroSoft;
using System.Collections.Generic;
using NHibernate.Criterion;
using NHibernate.Transform;
using System.Net.Mail;

/// <summary>
/// Summary description for SupplierBO
/// </summary>
namespace ConstroSoft
{
    public class EnquiryBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public EnquiryBO() { }
        public IList<EnquiryDetailDTO> fetchEnquiryGridData(string firmNumber, EnquirySearchBy searchBy, long searchByValue)
        {
            ISession session = null;
            IList<EnquiryDetailDTO> results = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                EnquiryDetail ed = null;
                ContactInfo c = null;
                FirmMember fm = null;
                EnquiryDetailDTO enDto = null;
                MasterControlData dg = null;
                MasterControlData dge = null;
                Property pr = null;

                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => ed.Id).WithAlias(() => enDto.Id))
                            .Add(Projections.SqlFunction("concat",
                                        NHibernateUtil.String,
                                        Projections.Property(() => ed.FirstName),
                                        Projections.Constant(" "),
                                        Projections.Property(() => ed.LastName)
                                    ).WithAlias(() => ed.FirstName))
                            .Add(Projections.Property(() => ed.Budget).WithAlias(() => enDto.Budget))
                            .Add(Projections.Property(() => ed.EnquiryDate).WithAlias(() => enDto.EnquiryDate))
                            .Add(Projections.Property(() => ed.Status).WithAlias(() => enDto.Status))
                            .Add(Projections.Property(() => c.Contact), "ContactInfo.Contact")
                            .Add(Projections.Property(() => c.Email), "ContactInfo.Email")
                            .Add(Projections.Property(() => dge.Name), "EnquirySource.Name")
                            .Add(Projections.SqlFunction("concat",
                                        NHibernateUtil.String,
                                        Projections.Property(() => fm.FirstName),
                                        Projections.Constant(" "),
                                        Projections.Property(() => fm.LastName)
                                    ).WithAlias(() => fm.FirstName), "FirmMember.FirstName");
                var query = session.QueryOver<EnquiryDetail>(() => ed)
                    .Inner.JoinAlias(() => ed.ContactInfo, () => c)
                    .Left.JoinAlias(() => ed.FirmMember, () => fm)
                    .Left.JoinAlias(() => ed.EnquirySource, () => dge); ;
                if (EnquirySearchBy.NONE != searchBy && searchByValue != -1)
                {
                    PropertyProjection prop = null;
                    if (EnquirySearchBy.CUSTOMER_NAME == searchBy)
                    {
                        prop = CommonUtil.BuildProjection<EnquiryDetail>(() => ed, x => x.Id);
                    }
                    else if (EnquirySearchBy.PROP_TYPE == searchBy)
                    {
                        query.Left.JoinAlias(() => ed.PropertyType, () => dg);
                        prop = CommonUtil.BuildProjection<MasterControlData>(() => dg, x => x.Id);
                    }
                    else if (EnquirySearchBy.PROP_LOCATION == searchBy)
                    {
                        query.Left.JoinAlias(() => ed.PropertyLocation, () => dg);
                        prop = CommonUtil.BuildProjection<MasterControlData>(() => dg, x => x.Id);

                    }
                    else if (EnquirySearchBy.PROP_UNIT_TYPE == searchBy)
                    {
                        query.Left.JoinAlias(() => ed.PrUnitType, () => dg);
                        prop = CommonUtil.BuildProjection<MasterControlData>(() => dg, x => x.Id);
                    }
                    else if (EnquirySearchBy.ENQUIRY_SOURCE == searchBy)
                    {
                        prop = CommonUtil.BuildProjection<MasterControlData>(() => dge, x => x.Id);
                    }
                    else if (EnquirySearchBy.PROP_NAME == searchBy)
                    {
                        query.Left.JoinAlias(() => ed.Property, () => pr);
                        prop = CommonUtil.BuildProjection<Property>(() => pr, x => x.Id);
                    }
                    else if (EnquirySearchBy.EMPLOYEE_NAME == searchBy)
                    {
                        prop = CommonUtil.BuildProjection<FirmMember>(() => fm, x => x.Id);
                    }
                    query.Where(Restrictions.Eq(prop, searchByValue));
                }

                results = query.Where(() => ed.FirmNumber == firmNumber)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<EnquiryDetailDTO>()).List<EnquiryDetailDTO>();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating enquiry grid:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }
        public EnquiryDetailDTO fetchEnquiryDetails(long Id)
        {
            ISession session = null;
            EnquiryDetailDTO enquiryDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EnquiryDetail enquiry = session.Get<EnquiryDetail>(Id);
                        enquiryDto = DomainToDTOUtil.convertToEnquiryDetailDTO(enquiry);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Enquiry details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return enquiryDto;
        }
        public long saveEnquiryDetails(EnquiryDetailDTO enquiryDto)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                EnquiryDetail enquiry = null;
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        enquiry = DTOToDomainUtil.populateEnquiryDetailAddFields(enquiryDto);
                        session.Save(enquiry);
                        Id = enquiry.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Enquiry details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
                sendSMSEmail(enquiry);
             }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        /**
         * This method will check Email & SMS configuration for Enquiry Function. 
         * If Email & SMS alerts are enabled then system will send Email & SMS to Customer.
         * */
        private static void sendSMSEmail(EnquiryDetail enquiry)
        {
            EmailSmsAlertConfig emailSmsAlertConfig = EmailUtil.loadEmailSmsAlertConfiguration(enquiry.FirmNumber,
                ConstroSoft.Constants.FUNCTIONNAME.ENQUIRY, ConstroSoft.Constants.EMAILSMSTYPE.ENQUIRYTHANKS);
            if (emailSmsAlertConfig != null && emailSmsAlertConfig.Email.Equals(Constants.YES))
            {
                emailSmsAlertConfig.EmailBody = populateBody(enquiry, emailSmsAlertConfig);
                LinkedResource inline = new LinkedResource(System.Web.HttpContext.Current.Server.MapPath("~/ui/common/img/3D-Thank-You-HD-Wallpapers.jpg"), MediaTypeNames.Image.Jpeg);
                inline.ContentId = Guid.NewGuid().ToString();
                EmailUtil.sendHtmlFormattedEmail(enquiry.FirmNumber, emailSmsAlertConfig, enquiry.ContactInfo.Email, inline);
            }
            if (emailSmsAlertConfig != null && emailSmsAlertConfig.Sms.Equals(Constants.YES))
            {
                EmailUtil.sendSMS(enquiry.FirmNumber, emailSmsAlertConfig, enquiry.ContactInfo.Contact);
            }
        }
        private static string populateBody(EnquiryDetail enquiry, EmailSmsAlertConfig emailSmsAlertConfig)
        {
            string body = string.Empty;
            using (StreamReader reader = new StreamReader(System.Web.HttpContext.Current.Server.MapPath(emailSmsAlertConfig.EmailTemplatePath)))
            {
                body = reader.ReadToEnd();
            }
            body = body.Replace("{UserName}", enquiry.FirstName + " " + enquiry.LastName);
            body = body.Replace("{Title}", "Wizeye Technology");
            body = body.Replace("{Url}", "www.wizeyetech.com");
            body = body.Replace("{Description}", "Thank you for your inquiry. It would be my pleasure to welcome you in my office to discuss in more details your requirements and to see how I can assist you in fulfilling them. In the meanwhile, if you have any questions or need more clarifications, please do not hesitate to contact me.I hope to hear from you soon");
            return body;
        }
        public void updateEnquiryDetails(EnquiryDetailDTO enquiryDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EnquiryDetail enquiry = session.Get<EnquiryDetail>(enquiryDto.Id);
                        DTOToDomainUtil.populateEnquiryDetailUpdateFields(enquiry, enquiryDto);
                        session.Update(enquiry);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating Enquiry details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public BusinessOutputTO deleteEnquiryDetails(long Id)
        {
            ISession session = null;
            BusinessOutputTO businessOutputTO = new BusinessOutputTO();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EnquiryDetail enquiry = session.Get<EnquiryDetail>(Id);
                        if (!(enquiry.EnquiryFollowups.Count > 0))
                        {
                            session.Delete(enquiry);
                            businessOutputTO.status = BusinessOutputTO.Status.SUCCESS;
                        }
                        else
                        {
                            businessOutputTO.setErrorMessage(Resources.Messages.system_error);
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while deleting Enquiry details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
                return businessOutputTO;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }

        public void populateEnquiryDetailsDTO(EnquiryDetail enquiryDtl)
        {
            EnquiryDetailDTO enquiryDtlDTO = new EnquiryDetailDTO();
            MasterControlDataDTO masterControlDTO = new MasterControlDataDTO();

        }
        //Enquiry Followup Operations Start:
       
        public void closeEnquiry(long enquiryId, String closeReason)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        string hqlUpdate = "update EnquiryDetail ed set ed.Status = :status, ed.FollowupDate = null, ed.CloseReason = :closeReason where ed.Id = :Id";
                        session.CreateQuery(hqlUpdate)
                                .SetEnum("status", EnquiryStatus.Closed)
                                .SetString("closeReason", closeReason)
                                .SetString("Id", enquiryId.ToString())
                                .ExecuteUpdate();
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while making Enquiry Close:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }

        }
        public void openEnquiry(long enquiryId, String reason)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        string hqlUpdate = "update EnquiryDetail ed set ed.Status = :status, ed.CloseReason = :closeReason where ed.Id = :Id";
                        session.CreateQuery(hqlUpdate)
                                .SetEnum("status", EnquiryStatus.Open)
                                .SetString("closeReason", reason)
                                .SetString("Id", enquiryId.ToString())
                                .ExecuteUpdate();
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while making Enquiry Close:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }

        }
    }
}