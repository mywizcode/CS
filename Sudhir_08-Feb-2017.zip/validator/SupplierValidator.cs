﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NHibernate;
using System.Collections;

/// <summary>
/// Summary description for SupplierValidator
/// </summary>
public class SupplierValidator
{
    private ISession session = null;
    public SupplierValidator(ISession tmpSession)
    {
        this.session = tmpSession;
    }
    private ISession getSession()
    {
        return this.session;
    }
    public bool isSupplierExistsWithSameName(String supplierName)
    {
        bool result = false;
        String queryString = "select supplier from tbl_supplierDetails where supplier='" + supplierName + "'";
        IQuery q = getSession().CreateSQLQuery(queryString);
        IList results = q.List();
        if (results != null && results.Count > 0) {
            result = true;
        
        }
        return result;
    }
}