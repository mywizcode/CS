$(document).ready(function () {
    //alert("Init");
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    var dtTable = initEmployeeGrid();
    $('a[href="#tab2Content"]').tab('show');
    $('a[href="#tab1Content"]').tab('show');
}
function initEmployeeGrid() {
    var dtOptions = {
        tableId: "employeeGrid",
        pageLength: 10,
        responsiveModalTitle: "Employee Details",
        isViewOnly: "false",
        showSearch: "true",
        customBtnGrpId: "#empSearchBtnDiv",
        hasRowInfo: false
    };
    var dtTable = applyResponsiveDtTable(dtOptions);
}