﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initPropertyFundSearchGrid();
    formatFields();
    showModal();
}

function initPropertyFundSearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#propertyFundSearchBtnDiv",
        pageLength: 10
    };

    $("[id$='propertyFundSearchGrid']").CSBasicDatatable(dtOptions);
}




