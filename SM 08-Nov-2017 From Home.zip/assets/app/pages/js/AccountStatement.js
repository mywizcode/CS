﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initAccountSummarySearchGrid();
    formatFields();
    showModal();
}

function initAccountSummarySearchGrid() {
    var isViewOnly = ($("[id$='pageModeHdn']").val() == 'VIEW');
    var dtOptions = {
        tableId: "acntSummaryGrid",
        pageLength: 10,        
        isViewOnly: false,
        hideSearch: false
    };
    $("[id$='acntSummaryGrid']").CSBasicDatatable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitHdnId");
}





