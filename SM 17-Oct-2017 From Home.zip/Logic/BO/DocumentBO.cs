﻿using System;
using NHibernate;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using ConstroSoft;
using System.Collections.Generic;
using NHibernate.Criterion;
using NHibernate.Transform;
using System.Web.Hosting;
using System.Net;

/// <summary>
/// Summary description for DocumentBO
/// </summary>
namespace ConstroSoft
{
    public class DocumentBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public DocumentBO() { }
        public IList<FileUIDTO> fetchFileList(string sourcePath)
        {
            IList<FileUIDTO> results = new List<FileUIDTO>();
            try
            {
                DirectoryInfo hdDirectoryInWhichToSearch = new DirectoryInfo(HostingEnvironment.MapPath(sourcePath));
                FileSystemInfo[] filesAndDirs = hdDirectoryInWhichToSearch.GetFileSystemInfos("*");
                foreach (FileSystemInfo foundFile in filesAndDirs)
                {
                    FileUIDTO FileUIDTO = new FileUIDTO();
                    FileInfo fileInfo = null;
                    DirectoryInfo directoryInfo = null;
                    if (foundFile.GetType() == typeof(FileInfo))
                    {
                        fileInfo = (FileInfo)foundFile;
                        FileUIDTO.FullPath = CommonUtil.getVirtualPath(fileInfo.FullName);
                        FileUIDTO.Name = fileInfo.Name;
                        FileUIDTO.size = fileInfo.Length.ToSize(SizeUnits.KB);
                        FileUIDTO.CreateDate = fileInfo.CreationTime;
                        FileUIDTO.DocumentType = "Document";
                        FileUIDTO.FileType = FileType.File;
                    }
                    if (foundFile.GetType() == typeof(DirectoryInfo))
                    {
                        directoryInfo = (DirectoryInfo)foundFile;
                        FileUIDTO.FullPath = CommonUtil.getVirtualPath(directoryInfo.FullName);
                        FileUIDTO.Name = directoryInfo.Name;
                        FileUIDTO.CreateDate = directoryInfo.CreationTime;
                        FileUIDTO.DocumentType = "File Folder";
                        FileUIDTO.FileType = FileType.Folder;
                    }
                    results.Add(FileUIDTO);
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error retriving file list:" ,exp);
                throw new Exception(Resources.Messages.system_error);
            }
            finally
            {

            }
            return results;
        }
        public void saveFileorFolder(FileUIDTO FileUIDTO)
        {
            try
            {
                if (FileUIDTO.FileType.Equals(FileType.File))
                {
                    FileUIDTO.userPostedFile.SaveAs(HostingEnvironment.MapPath(FileUIDTO.FullPath));
                }
                else
                {
                    Directory.CreateDirectory(HostingEnvironment.MapPath(FileUIDTO.FullPath));
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error creating file or folder:", exp);
                throw new Exception(Resources.Messages.system_error);
            }
            finally
            {

            }
        }
        public byte[] downloadFile(string filePath)
        {
            byte[] data = null;
            try
            {
                WebClient req = new WebClient();
                data = req.DownloadData(HostingEnvironment.MapPath(filePath));

            }
            catch (Exception exp)
            {
                log.Error("Unexpected error creating dowloading file:", exp);
                throw new Exception(Resources.Messages.system_error);
            }
            finally
            {

            }
            return data;
        }
        public void deleteFile(string filePath)
        {
            try
            {
                System.IO.File.Delete(HostingEnvironment.MapPath(filePath));
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error deleting file:", exp);
                throw new Exception(Resources.Messages.system_error);
            }
            finally
            {

            }
        }
        public bool isDocumentExistInFolder(string sourcePath)
        {
            bool isFilePresent = false;
            DirectoryInfo hdDirectoryInWhichToSearch = new DirectoryInfo(HostingEnvironment.MapPath(sourcePath));
            FileSystemInfo[] filesAndDirs = hdDirectoryInWhichToSearch.GetFileSystemInfos("*");
            foreach (FileSystemInfo foundFile in filesAndDirs)
            {
                if (foundFile.GetType() == typeof(DirectoryInfo))
                {
                    isDocumentExistInFolder(foundFile.FullName);
                }
                else if (foundFile.GetType() == typeof(FileInfo))
                {
                    isFilePresent = true;
                    break;
                }
            }
            return isFilePresent;
        }
    }
}