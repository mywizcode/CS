﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq.Expressions;
using NHibernate.Impl;
using System.Linq;
using System.Net.Mail;
using System.Net.Mime;
using System.IO;

namespace ConstroSoft.Logic.BO
{
    
    public class SoldPropertyUnitBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        

        public SoldPropertyUnitBO() { }

        public IList<PrUnitSaleDetailDTO> fetchSoldOrCancelledPropertyUnits(long propertyTowerId, SoldUnitFilterDTO filterDTO, PRUnitSaleStatus status)
        {
            ISession session = null;
            IList<PrUnitSaleDetailDTO> result = new List<PrUnitSaleDetailDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Property p = null;
                        PropertyUnit pu = null;
                        PrUnitSaleDetail pus = null;
                        Customer c = null;
                        PropertyTower pt = null;
                        MasterControlData putype = null;
                        FirmMember fm = null;

                        PrUnitSaleDetailDTO pusdto = null;

                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => pus.Id).WithAlias(() => pusdto.Id))
                                    .Add(Projections.Property(() => c.Id), "Customer.Id")
                                    .Add(Projections.Property(() => c.FirstName), "Customer.FirstName")
                                    .Add(Projections.Property(() => c.LastName), "Customer.LastName")
                                    .Add(Projections.Property(() => c.CustRefNo), "Customer.CustRefNo")
                                    .Add(Projections.Property(() => fm.FirstName), "FirmMember.FirstName")
                                    .Add(Projections.Property(() => fm.LastName), "FirmMember.LastName")
                                    .Add(Projections.Property(() => fm.Id), "FirmMember.Id")
                                    .Add(Projections.Property(() => p.Id), "PropertyUnit.PropertyTower.Property.Id")
                                    .Add(Projections.Property(() => p.Name), "PropertyUnit.PropertyTower.Property.Name")
                                    .Add(Projections.Property(() => pt.Id), "PropertyUnit.PropertyTower.Id")
                                    .Add(Projections.Property(() => pt.Name), "PropertyUnit.PropertyTower.Name")
                                    .Add(Projections.Property(() => pu.Id), "PropertyUnit.Id")
                                    .Add(Projections.Property(() => pu.Wing), "PropertyUnit.Wing")
                                    .Add(Projections.Property(() => pu.UnitNo), "PropertyUnit.UnitNo")
                                    .Add(Projections.Property(() => pu.BuildupArea), "PropertyUnit.BuildupArea")
                                    .Add(Projections.Property(() => pu.CarpetArea), "PropertyUnit.CarpetArea")
                                    .Add(Projections.Property(() => putype.Id), "PropertyUnit.UnitType.Id")
                                    .Add(Projections.Property(() => putype.Name), "PropertyUnit.UnitType.Name")
                                    .Add(Projections.Property(() => pus.IsAgreementDone).WithAlias(() => pusdto.IsAgreementDone))
                                    .Add(Projections.Property(() => pus.IsPossessionDone).WithAlias(() => pusdto.IsPossessionDone))
                                    .Add(Projections.Property(() => pus.BookingRefNo).WithAlias(() => pusdto.BookingRefNo))
                                    .Add(Projections.Property(() => pus.BookingDate).WithAlias(() => pusdto.BookingDate))
                                    .Add(Projections.Property(() => pus.PossessionDate).WithAlias(() => pusdto.PossessionDate))
                                    .Add(Projections.Property(() => pus.AgreementDate).WithAlias(() => pusdto.AgreementDate));
                        var query = session.QueryOver<PrUnitSaleDetail>(() => pus)
                            .Left.JoinAlias(() => pus.PropertyUnit, () => pu)
                            .Left.JoinAlias(() => pus.PropertyUnit.UnitType, () => putype)
                            .Left.JoinAlias(() => pus.PropertyUnit.PropertyTower, () => pt)
                            .Left.JoinAlias(() => pus.PropertyUnit.PropertyTower.Property, () => p)
                            .Left.JoinAlias(() => pus.Customer, () => c)
                            .Left.JoinAlias(() => pus.FirmMember, () => fm);
                        if (filterDTO != null)
                        {
                            ICriteria criteria = query.RootCriteria;
                            if (filterDTO.UnitId > 0)
                            {
                                criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<PropertyUnit>(() => pu, x => x.Id), filterDTO.UnitId));
                            }
                            if (filterDTO.CustomerId > 0)
                            {
                                criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<Customer>(() => c, x => x.Id), filterDTO.CustomerId));
                            }
                            if (!string.IsNullOrWhiteSpace(filterDTO.CustRefNo))
                            {
                                criteria.Add(Restrictions.InsensitiveLike(CommonUtil.BuildProjection<Customer>(() => c, x => x.CustRefNo), filterDTO.CustRefNo, MatchMode.Start));
                            }
                            if (filterDTO.SalesExecutiveId > 0)
                            {
                                criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<FirmMember>(() => fm, x => x.Id), filterDTO.SalesExecutiveId));
                            }
                        }
                        result = query.Where(() => pt.Id == propertyTowerId && pus.Status == status)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<PrUnitSaleDetailDTO>()).List<PrUnitSaleDetailDTO>();
                        foreach (PrUnitSaleDetailDTO saleDetailDTO in result)
                        {
                            saleDetailDTO.PropertyUnit.UnitNo = CommonUIConverter.getPropertyUnitFormattedNo(saleDetailDTO.PropertyUnit.Wing, 
                                            saleDetailDTO.PropertyUnit.UnitNo);
                            saleDetailDTO.Customer.FullName = CommonUIConverter.getCustomerFullName(saleDetailDTO.Customer.FirstName,
                                saleDetailDTO.Customer.LastName);
                            saleDetailDTO.FirmMember.FullName = CommonUIConverter.getCustomerFullName(saleDetailDTO.FirmMember.FirstName,
                                saleDetailDTO.FirmMember.LastName);
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching sold property units :", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }

        public PrUnitSaleDetailDTO fetchBookingSuccessDetails(long prUnitSaleDetailId)
        {
            ISession session = null;
            PrUnitSaleDetailDTO result = new PrUnitSaleDetailDTO();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        ContactInfo contact = null;
                        PropertyUnit pu = null;
                        PrUnitSaleDetail pus = null;
                        Customer c = null;
                        PropertyTower pt = null;
                        MasterControlData putype = null;
                        MasterControlData sal = null;
                        FirmMember fm = null;

                        PrUnitSaleDetailDTO pusdto = null;

                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => pus.Id).WithAlias(() => pusdto.Id))
                                    .Add(Projections.Property(() => c.Id), "Customer.Id")
                                    .Add(Projections.Property(() => sal.Name), "Customer.Salutation.Name")
                                    .Add(Projections.Property(() => c.FirstName), "Customer.FirstName")
                                    .Add(Projections.Property(() => c.LastName), "Customer.LastName")
                                    .Add(Projections.Property(() => c.CustRefNo), "Customer.CustRefNo")
                                    .Add(Projections.Property(() => contact.Contact), "Customer.ContactInfo.Contact")
                                    .Add(Projections.Property(() => contact.Email), "Customer.ContactInfo.Email")
                                    .Add(Projections.Property(() => pt.Name), "PropertyUnit.PropertyTower.Name")
                                    .Add(Projections.Property(() => pu.Id), "PropertyUnit.Id")
                                    .Add(Projections.Property(() => pu.Wing), "PropertyUnit.Wing")
                                    .Add(Projections.Property(() => pu.UnitNo), "PropertyUnit.UnitNo")
                                    .Add(Projections.Property(() => putype.Id), "PropertyUnit.UnitType.Id")
                                    .Add(Projections.Property(() => putype.Name), "PropertyUnit.UnitType.Name")
                                    .Add(Projections.Property(() => pus.BookingRefNo).WithAlias(() => pusdto.BookingRefNo));
                        var query = session.QueryOver<PrUnitSaleDetail>(() => pus)
                            .Left.JoinAlias(() => pus.PropertyUnit, () => pu)
                            .Left.JoinAlias(() => pus.PropertyUnit.UnitType, () => putype)
                            .Left.JoinAlias(() => pus.PropertyUnit.PropertyTower, () => pt)
                            .Left.JoinAlias(() => pus.Customer, () => c)
                            .Left.JoinAlias(() => c.ContactInfo, () => contact)
                            .Left.JoinAlias(() => pus.Customer.Salutation, () => sal)
                            .Left.JoinAlias(() => pus.FirmMember, () => fm);
                        result = query.Where(() => pus.Id == prUnitSaleDetailId)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<PrUnitSaleDetailDTO>()).SingleOrDefault<PrUnitSaleDetailDTO>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching sold property unit details for Booking Success Page :", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public BookingCancellatonUIDTO fetchPrUnitDetailsForCancellation(long prUnitSaleId)
        {
            ISession session = null;
            BookingCancellatonUIDTO canellationDTO = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Property p = null;
                        PropertyUnit pu = null;
                        PrUnitSaleDetail pus = null;
                        Customer c = null;
                        PrUnitSalePymt pusp = null;
                        PropertyTower pt = null;
                        MasterControlData pType = null;
                        MasterControlData sal = null;
                        PaymentMaster pm = null;
                        ContactInfo contact = null;

                        BookingCancellatonUIDTO pusdto = null;

                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => pus.Id).WithAlias(() => pusdto.SaleDetailId))
                                    .Add(Projections.Property(() => pus.IsAgreementDone).WithAlias(() => pusdto.IsAgreementDone))
                                    .Add(Projections.Property(() => pus.IsPossessionDone).WithAlias(() => pusdto.IsPossessionDone))
                                    .Add(Projections.Property(() => pus.BookingRefNo).WithAlias(() => pusdto.BookingRefNo))
                                    .Add(Projections.Property(() => pus.BookingDate).WithAlias(() => pusdto.BookingDate))
                                    .Add(Projections.Property(() => pus.PossessionDate).WithAlias(() => pusdto.PossessionDate))
                                    .Add(Projections.Property(() => pus.AgreementDate).WithAlias(() => pusdto.AgreementDate))
                                    .Add(Projections.Property(() => pus.AgreementAmt).WithAlias(() => pusdto.AgreementAmt))
                                    .Add(Projections.Property(() => c.Id), "Customer.Id")
                                    .Add(Projections.Property(() => sal.Name), "Customer.Salutation.Name")
                                    .Add(Projections.Property(() => c.FirstName), "Customer.FirstName")
                                    .Add(Projections.Property(() => c.MiddleName), "Customer.MiddleName")
                                    .Add(Projections.Property(() => c.LastName), "Customer.LastName")
                                    .Add(Projections.Property(() => c.CustRefNo), "Customer.CustRefNo")
                                    .Add(Projections.Property(() => contact.Contact), "Customer.ContactInfo.Contact")
                                    .Add(Projections.Property(() => pu.Id), "PropertyUnit.Id")
                                    .Add(Projections.Property(() => pu.Wing), "PropertyUnit.Wing")
                                    .Add(Projections.Property(() => pu.UnitNo), "PropertyUnit.UnitNo")
                                    .Add(Projections.Property(() => pt.Id), "PropertyUnit.PropertyTower.Id")
                                    .Add(Projections.Property(() => pt.Name), "PropertyUnit.PropertyTower.Name")
                                    .Add(Projections.Property(() => pusp.Id), "TmpSalePymtDTO.Id")
                                    .Add(Projections.Property(() => pType.Name), "TmpSalePymtDTO.PymtType.Name")
                                    .Add(Projections.Property(() => pusp.PymtAmt), "TmpSalePymtDTO.PymtAmt")
                                    .Add(Projections.Property(() => pusp.PymtMode), "TmpSalePymtDTO.PymtMode")
                                    .Add(Projections.Property(() => pm.TotalPaid), "TmpSalePymtDTO.PaymentMaster.TotalPaid")
                                    .Add(Projections.Property(() => pm.Status), "TmpSalePymtDTO.PaymentMaster.Status");
                        var query = session.QueryOver<PrUnitSaleDetail>(() => pus)
                            .Inner.JoinAlias(() => pus.PropertyUnit, () => pu)
                            .Inner.JoinAlias(() => pu.PropertyTower, () => pt)
                            .Inner.JoinAlias(() => pus.Customer, () => c)
                            .Inner.JoinAlias(() => c.Salutation, () => sal)
                            .Inner.JoinAlias(() => c.ContactInfo, () => contact)
                            .Left.JoinAlias(() => pus.PrUnitSalePymts, () => pusp)
                            .Left.JoinAlias(() => pusp.PaymentMaster, () => pm)
                            .Left.JoinAlias(() => pusp.PymtType, () => pType);
                        IList<BookingCancellatonUIDTO> resultList = query.Where(() => pus.Id == prUnitSaleId && pm.Status != PymtMasterStatus.Deleted)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<BookingCancellatonUIDTO>()).List<BookingCancellatonUIDTO>();
                        foreach(BookingCancellatonUIDTO tmpDTO in resultList) {
                        	if(canellationDTO == null) {
                        		canellationDTO = tmpDTO;
                        		canellationDTO.TotalReceivablePymt = new TotalPymtDTO();
                        		canellationDTO.TotalPayablePymt = new TotalPymtDTO();
                        		canellationDTO.ReceivablePymts = new List<PrUnitSalePymtDTO>();
                        		canellationDTO.PayablePymts = new List<PrUnitSalePymtDTO>();
                        	}
                        	if (tmpDTO.TmpSalePymtDTO.PymtMode == PaymentMode.Receivable) {
                        		canellationDTO.ReceivablePymts.Add(tmpDTO.TmpSalePymtDTO);
                            	canellationDTO.TotalReceivablePymt.TotalPymtAmt = Decimal.Add(canellationDTO.TotalReceivablePymt.TotalPymtAmt, tmpDTO.TmpSalePymtDTO.PymtAmt);
                            	canellationDTO.TotalReceivablePymt.TotalPaidAmt = Decimal.Add(canellationDTO.TotalReceivablePymt.TotalPaidAmt, tmpDTO.TmpSalePymtDTO.PaymentMaster.TotalPaid);
                        	} else {
                        		canellationDTO.PayablePymts.Add(tmpDTO.TmpSalePymtDTO);
                            	canellationDTO.TotalPayablePymt.TotalPymtAmt = Decimal.Add(canellationDTO.TotalPayablePymt.TotalPymtAmt, tmpDTO.TmpSalePymtDTO.PymtAmt);
                            	canellationDTO.TotalPayablePymt.TotalPaidAmt = Decimal.Add(canellationDTO.TotalPayablePymt.TotalPaidAmt, tmpDTO.TmpSalePymtDTO.PaymentMaster.TotalPaid);
                        	}
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Unexpected error fetching Unit Details for Payment:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return canellationDTO;
        }
        public PrUnitSaleDetailDTO fetchPrUnitSaleDetail(string firmNumber, long unitSaleId)
        {
            ISession session = null;
            PrUnitSaleDetailDTO prUnitSaleDetailDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PrUnitSaleDetail prUnitSaleDetail = session.Get<PrUnitSaleDetail>(unitSaleId);
                        prUnitSaleDetailDto = DomainToDTOUtil.convertToPrUnitSaleDetailDTO(prUnitSaleDetail, true);
                        prUnitSaleDetailDto.Customer = DomainToDTOUtil.convertToCustomerDTO(prUnitSaleDetail.Customer, true);
                        if (prUnitSaleDetail.PrUnitSalePymts != null && prUnitSaleDetail.PrUnitSalePymts.Count > 0)
                        {
                            foreach (PrUnitSalePymt prUnitSalePymt in prUnitSaleDetail.PrUnitSalePymts)
                            {
                                PaymentMasterDTO pymtMasterDto = prUnitSaleDetailDto.PrUnitSalePymts.ToList<PrUnitSalePymtDTO>()
                                    .Find(sale => sale.Id == prUnitSalePymt.Id).PaymentMaster;
                                pymtMasterDto.TotalPaid = prUnitSalePymt.PaymentMaster.TotalPaid;
                                pymtMasterDto.Status = prUnitSalePymt.PaymentMaster.Status;
                                pymtMasterDto.hasTransactrions = prUnitSalePymt.PaymentMaster.PaymentTransactions.Count > 0;
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching PrUnitSale details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return prUnitSaleDetailDto;
        }

        public PrUnitSaleDetailDTO fetchPrUnitSaleDetailforLetter(string firmNumber, long unitSaleId, long propertyId)
        {
            ISession session = null;
            PrUnitSaleDetailDTO prUnitSaleDetailDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PrUnitSaleDetail prUnitSaleDetail = session.Get<PrUnitSaleDetail>(unitSaleId);
                        prUnitSaleDetailDto = DomainToDTOUtil.convertToPrUnitSaleDetailDTO(prUnitSaleDetail, true);
                        prUnitSaleDetailDto.PropertyUnit = DomainToDTOUtil.convertToPropertyUnitDTO(prUnitSaleDetail.PropertyUnit, true);
                        prUnitSaleDetailDto.Customer = DomainToDTOUtil.convertToCustomerDTO(prUnitSaleDetail.Customer, true);
                        if (prUnitSaleDetail.PrUnitSalePymts != null && prUnitSaleDetail.PrUnitSalePymts.Count > 0)
                        {
                            foreach (PrUnitSalePymt prUnitSalePymt in prUnitSaleDetail.PrUnitSalePymts)
                            {
                                PaymentMasterDTO pymtMasterDto = prUnitSaleDetailDto.PrUnitSalePymts.ToList<PrUnitSalePymtDTO>()
                                    .Find(sale => sale.Id == prUnitSalePymt.Id).PaymentMaster;
                                pymtMasterDto.TotalPaid = prUnitSalePymt.PaymentMaster.TotalPaid;
                                pymtMasterDto.Status = prUnitSalePymt.PaymentMaster.Status;
                                pymtMasterDto.hasTransactrions = prUnitSalePymt.PaymentMaster.PaymentTransactions.Count > 0;
                            }
                        }
                      
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching PrUnitSale details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return prUnitSaleDetailDto;
        }
        public void UpdateSoldPropertyUnitDetails(PrUnitSaleDetailDTO prUnitSaleDetailDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PrUnitSaleDetail prUnitSaleDetail = session.Get<PrUnitSaleDetail>(prUnitSaleDetailDto.Id);
                        DTOToDomainUtil.populatePrUnitSaleDetailUpdateFields(prUnitSaleDetail, prUnitSaleDetailDto);
                        session.Update(prUnitSaleDetail);
                        DTOToDomainUtil.populateCustomerUpdateFields(prUnitSaleDetail.Customer, prUnitSaleDetailDto.Customer);
                        session.Update(prUnitSaleDetail.Customer);
                        foreach (PropertyParking parking in prUnitSaleDetail.PrUnitParkings)
                        {
                            PropertyParkingDTO tmpDto = prUnitSaleDetailDto.PrParkings.FirstOrDefault(x => x.Id == parking.Id);
                            if (tmpDto == null)
                            {
                                parking.Status = ParkingStatus.Available;
                                parking.PrUnitSaleDetail = null;
                                session.Update(parking);
                            }
                        }
                        foreach (PropertyParkingDTO prPardingDto in prUnitSaleDetailDto.PrParkings)
                        {
                            PropertyParking tmpParking = prUnitSaleDetail.PrUnitParkings.FirstOrDefault(x => x.Id == prPardingDto.Id);
                            if (tmpParking == null)
                            {
                                PropertyParking parking = session.Get<PropertyParking>(prPardingDto.Id);
                                parking.Status = ParkingStatus.Allotted;
                                parking.PrUnitSaleDetail = prUnitSaleDetail;
                                session.Update(parking);
                            }
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Updating Sold property Unit:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }


        public void cancelPropertyUnitBooking(PrUnitSaleDetailDTO prUnitSaleDetailDto, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                PrUnitSaleDetail prUnitSaleDetail = null;
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	//Update Property Unit Status as Available
                        PropertyUnit propertyUnit = session.Get<PropertyUnit>(prUnitSaleDetailDto.PropertyUnit.Id);
                        propertyUnit.Status = PRUnitStatus.Available;
                        session.Update(propertyUnit);
                        //Update UI Changes in PrUnitSaleDetail
                        prUnitSaleDetail = session.Get<PrUnitSaleDetail>(prUnitSaleDetailDto.Id);
                        DTOToDomainUtil.populatePrUnitSaleCancellationAddFields(prUnitSaleDetail, prUnitSaleDetailDto);
                        session.Update(prUnitSaleDetail);
                        //Deallocate all Parking
                        foreach (PropertyParking parking in prUnitSaleDetail.PrUnitParkings)
                        {
                            parking.Status = ParkingStatus.Available;
                            parking.PrUnitSaleDetail = null;
                            session.Update(parking);
                        }
                        //Mark Enquiry as Lost and add new BOOKING_CANCELLATION action
                        if (prUnitSaleDetail.Enquiry != null)
                        {
                            EnquiryDetail enquiry = prUnitSaleDetail.Enquiry;
                            enquiry.Status = EnquiryStatus.Lost;
                            session.Update(enquiry);
                            EnquiryActivity activity = CommonUtil.getEnquiryActivityAction(enquiry.Id, EnqActivityType.BOOKING_CANCELLED, "", 
                            		prUnitSaleDetailDto.CanellationDate.Value, userDefDTO);
                            session.Save(activity);
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Cancelling property Unit booking:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
                sendSMSEmail(prUnitSaleDetail);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void UpdateCancelledPropertyUnit(PrUnitSaleDetailDTO prUnitSaleDetailDto, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                PrUnitSaleDetail prUnitSaleDetail = null;
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	//Update UI Changes in PrUnitSaleDetail and Payable Payments
                        prUnitSaleDetail = session.Get<PrUnitSaleDetail>(prUnitSaleDetailDto.Id);
                        DTOToDomainUtil.populatePrUnitSaleCancellationUpdateFields(prUnitSaleDetail, prUnitSaleDetailDto);
                        session.Update(prUnitSaleDetail);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Updating Cancellation property Unit:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
                sendSMSEmail(prUnitSaleDetail);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        /**
         * This method will check Email & SMS configuration for Sales Function. 
         * If Email & SMS alerts are enabled then system will send Email & SMS to Customer.
         * */
        private static void sendSMSEmail(PrUnitSaleDetail prUnitSaleDetail)
        {
            try
            {
                PropertyAlertConfig emailSmsAlertConfig = EmailUtil.loadEmailSmsAlertConfiguration(prUnitSaleDetail.FirmNumber,
                    FunctionName.SALE.ToString(), EmailSmsType.SALESCANCEL.ToString(), prUnitSaleDetail.PropertyUnit.PropertyTower.Property.Id);
                PropertyBO propertyBO = new PropertyBO();
                if (emailSmsAlertConfig != null && emailSmsAlertConfig.Email.Equals(Constants.YES))
                {
                    PropertyDTO propertyDTO = propertyBO.fetchProperty(prUnitSaleDetail.PropertyUnit.PropertyTower.Property.Id);
                    emailSmsAlertConfig.EmailBody = populateBody(prUnitSaleDetail, emailSmsAlertConfig, propertyDTO.Name);
                    EmailUtil.sendHtmlFormattedEmail(prUnitSaleDetail.FirmNumber, emailSmsAlertConfig, prUnitSaleDetail.Customer.ContactInfo.Email);
                }
                if (emailSmsAlertConfig != null && emailSmsAlertConfig.Sms.Equals(Constants.YES))
                {
                    PropertyDTO propertyDTO = propertyBO.fetchProperty(prUnitSaleDetail.PropertyUnit.PropertyTower.Property.Id);
                    emailSmsAlertConfig.SmsContent = populateSMSBody(prUnitSaleDetail, emailSmsAlertConfig, propertyDTO.Name);
                    EmailUtil.sendSMS(prUnitSaleDetail.FirmNumber, emailSmsAlertConfig, prUnitSaleDetail.Customer.ContactInfo.Contact);
                }
            }
            catch (Exception e)
            {
                log.Error("Exception while sending Email & SMS alert for Cancellation:", e);
            }
        }
        private static string populateBody(PrUnitSaleDetail prUnitSaleDetail, PropertyAlertConfig emailSmsAlertConfig, string name)
        {
            string body = string.Empty;
            using (StreamReader reader = new StreamReader(System.Web.HttpContext.Current.Server.MapPath(emailSmsAlertConfig.EmailTemplatePath)))
            {
                body = reader.ReadToEnd();
            }
            body = body.Replace("{UserName}", prUnitSaleDetail.Customer.Salutation.Name + " " + prUnitSaleDetail.Customer.FirstName + " " + prUnitSaleDetail.Customer.LastName);
            body = body.Replace("{UnitNumber}",  CommonUIConverter.getPropertyUnitFormattedNo(prUnitSaleDetail.PropertyUnit.Wing, prUnitSaleDetail.PropertyUnit.UnitNo));
            body = body.Replace("{ProjectName}",  name);
            return body;
        }
        private static string populateSMSBody(PrUnitSaleDetail prUnitSaleDetail, PropertyAlertConfig emailSmsAlertConfig, string name)
        {
            string body = string.Empty;
            body = emailSmsAlertConfig.SmsContent.Replace("{UserName}", prUnitSaleDetail.Customer.Salutation.Name + " " + prUnitSaleDetail.Customer.FirstName + " " + prUnitSaleDetail.Customer.LastName);
            body = body.Replace("{UnitNumber}", CommonUIConverter.getPropertyUnitFormattedNo(prUnitSaleDetail.PropertyUnit.Wing, prUnitSaleDetail.PropertyUnit.UnitNo));
            body = body.Replace("{ProjectName}", name);
            return body;
        }
    }
}
