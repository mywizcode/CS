﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initFolderContentGrid();
	formatFields();
    showModal();
}
function initFolderContentGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        pagination: false,
        sortColumn: 3,
        sortOrder: 'desc',
        hideSearch: true
    };

    $("[id$='folderContentGrid']").CSBasicDatatable(dtOptions);
}