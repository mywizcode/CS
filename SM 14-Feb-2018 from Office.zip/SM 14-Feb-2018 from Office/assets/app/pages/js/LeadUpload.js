﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
	initLeadUploadGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}
function initLeadUploadGrid() {
    var dtOptions = {
        hasActionColumn: false,
        rowInfoModalTitle: "Lead Details",
        pageLength: 10
    };

    $("[id$='leadUploadGrid']").CSBasicDatatable(dtOptions);
}




