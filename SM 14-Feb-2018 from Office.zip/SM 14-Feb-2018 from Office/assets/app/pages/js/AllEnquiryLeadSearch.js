﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
	initEnquiryLeadSearchGrid();
    formatFields(controlToFormat);
}

function initEnquiryLeadSearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        pageLength: 10,
        hideSearch: true
    };

    $("[id$='allEnquiryLeadSearchGrid']").CSBasicDatatable(dtOptions);
}




