﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using NHibernate;
using NHibernate.Criterion;

namespace ConstroSoft.Logic.BO
{

    public class PaymentReceiptBO
    {
        private static readonly log4net.ILog log =
             log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public PaymentReceiptBO() { }

        public void markPymtRcptDelivered(MPTReceiptDTO receiptDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        MasterPymtTransaction masterPymtTransaction = session.Get<MasterPymtTransaction>(receiptDTO.MasterPymtTransaction.Id);
                        masterPymtTransaction.RcptDelivered = PymtTransRcptDelivered.Yes;
                        masterPymtTransaction.UpdateUser = receiptDTO.UpdateUser;
                        masterPymtTransaction.UpdateDate = DateUtil.getUserLocalDateTime();
                        session.Update(masterPymtTransaction);

                        MPTReceipt receipt = DTOToDomainUtil.populateMPTReceiptAddFields(receiptDTO);
                        session.Save(receipt);

                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Updating master payment transaction:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void deletePymtRcpt(MPTReceiptDTO receiptDTO, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        MasterPymtTransaction masterPymtTransaction = session.Get<MasterPymtTransaction>(receiptDTO.MasterPymtTransaction.Id);
                        ISet<MPTReceipt> PymtReceipts = masterPymtTransaction.PymtReceipts;
                        MPTReceipt tmpRcptToDelete = null;
                        if(PymtReceipts != null) {
                        	foreach(MPTReceipt tmpRcpt in PymtReceipts) {
                        		if(tmpRcpt.Id == receiptDTO.Id) {
                        			tmpRcptToDelete = tmpRcpt;
                        		}
                        	}
                        	PymtReceipts.Remove(tmpRcptToDelete);
                        }
                        masterPymtTransaction.RcptDelivered = (PymtReceipts != null && PymtReceipts.Count > 0) ? PymtTransRcptDelivered.Yes : PymtTransRcptDelivered.No;
                        masterPymtTransaction.UpdateUser = userDefDTO.Username;
                        masterPymtTransaction.UpdateDate = DateUtil.getUserLocalDateTime();
                        session.Update(masterPymtTransaction);

                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while deleting Payment Receipt:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            //Delete Receipt from file system.
            DocumentBO documentBO = new DocumentBO();
            FileUIDTO fileDTO = new FileUIDTO();
        	fileDTO.FileType = FileType.File;
        	fileDTO.FullPath = CommonUtil.appendNameToPath(receiptDTO.DocumentPath, receiptDTO.FileName);
            documentBO.deleteFile(fileDTO);
        }
        public IList<MPTReceiptDTO> fetchPymtReceipts(long MPTId)
        {
            ISession session = null;
            IList<MPTReceiptDTO> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        MasterPymtTransaction mpt = null;
                        MPTReceipt rcpt = null;
                        FirmMember fm = null;

                        MPTReceiptDTO rcptDTO = null;
                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => rcpt.Id).WithAlias(() => rcptDTO.Id))
                                    .Add(Projections.Property(() => rcpt.FileName).WithAlias(() => rcptDTO.FileName))
                                    .Add(Projections.Property(() => rcpt.UploadDate).WithAlias(() => rcptDTO.UploadDate))
                                    .Add(Projections.Property(() => rcpt.DeliveryDate).WithAlias(() => rcptDTO.DeliveryDate))
                                    .Add(Projections.Property(() => rcpt.DocumentPath).WithAlias(() => rcptDTO.DocumentPath))
                                    .Add(Projections.Property(() => mpt.Id), "MasterPymtTransaction.Id")
                                    .Add(Projections.Property(() => fm.FirstName), "UploadBy.FirstName")
                                    .Add(Projections.Property(() => fm.LastName), "UploadBy.LastName");
                        var query = session.QueryOver<MPTReceipt>(() => rcpt)
                            .Inner.JoinAlias(() => rcpt.MasterPymtTransaction, () => mpt)
                            .Inner.JoinAlias(() => rcpt.UploadBy, () => fm);
                        
                        result = query.Where(() => mpt.Id == MPTId)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<MPTReceiptDTO>()).List<MPTReceiptDTO>();
                        if (result != null) result.ToList<MPTReceiptDTO>().ForEach(x =>
                             x.UploadBy.FullName = CommonUIConverter.getCustomerFullName(x.UploadBy.FirstName, x.UploadBy.LastName));

                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while receipts for given master payment transaction:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public IList<MPTReceiptDTO> fetchPymtReceiptsForSoldUnit(long PrUnitSaleId)
        {
            ISession session = null;
            IList<MPTReceiptDTO> result = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	MPTReceipt rcpt = null;
                    	PrUnitSaleDetail pusd = null;
                    	FirmMember fm = null;
                    	MasterPymtTransaction mpt = null;
                    	
                    	MPTReceiptDTO rcptdto = null;

                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => rcpt.Id).WithAlias(() => rcptdto.Id))
                                    .Add(Projections.Property(() => rcpt.UploadDate).WithAlias(() => rcptdto.UploadDate))
                                    .Add(Projections.Property(() => rcpt.DeliveryDate).WithAlias(() => rcptdto.DeliveryDate))
                                    .Add(Projections.Property(() => rcpt.FileName).WithAlias(() => rcptdto.FileName))
                                    .Add(Projections.Property(() => rcpt.DocumentPath).WithAlias(() => rcptdto.DocumentPath))
                                    .Add(Projections.Property(() => mpt.Id), "MasterPymtTransaction.Id")
                                    .Add(Projections.Property(() => mpt.TxRefNo), "MasterPymtTransaction.TxRefNo")
                                    .Add(Projections.Property(() => fm.FirstName), "UploadBy.FirstName")
                                    .Add(Projections.Property(() => fm.LastName), "UploadBy.LastName");
                        var query = session.QueryOver<MPTReceipt>(() => rcpt)
                            .Inner.JoinAlias(() => rcpt.PrUnitSaleDetail, () => pusd)
                            .Inner.JoinAlias(() => rcpt.MasterPymtTransaction, () => mpt)
                            .Left.JoinAlias(() => rcpt.UploadBy, () => fm);
                        result = query.Where(() => pusd.Id == PrUnitSaleId)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<MPTReceiptDTO>()).List<MPTReceiptDTO>();
                        result.ToList<MPTReceiptDTO>().ForEach(x => x.UploadBy.FullName = CommonUIConverter.getCustomerFullName(x.UploadBy.FirstName,
                            x.UploadBy.LastName));
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Payemnt Receipt details for given sold unit:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public BusinessOutputTO processPaymentReceipt(CustomerPaymentHistoryPageDTO customerPymtHistoryDTO, MPTHistoryUIDTO mptHistUIDTO, long propertyId)
        {
            BusinessOutputTO businessOutputTO = new BusinessOutputTO();
            try
            {
                PropertyBO propertyBO = new PropertyBO();
                DataTable PaymentReceipt = populatePaymentReceiptColumns();
                PropertyDTO propertyDTO = propertyBO.fetchProperty(propertyId);
                DataRow PaymentReceiptRow = populatePaymentReceiptRows(PaymentReceipt, customerPymtHistoryDTO, mptHistUIDTO, propertyDTO);
                PaymentReceipt.Rows.Add(PaymentReceiptRow);
                businessOutputTO.result = PaymentReceipt;
                businessOutputTO.status = BusinessOutputTO.Status.SUCCESS;
                businessOutputTO.successMessage = "Payment Receipt for " + CommonUIConverter.getCustomerFullName(customerPymtHistoryDTO.PrUnitSaleDetail.Customer.FirstName,
                customerPymtHistoryDTO.PrUnitSaleDetail.Customer.LastName);
            }
            catch (Exception e)
            {
                log.Error("Exception while generating payment receipt", e);
                throw new Exception(Resources.Messages.system_error);
            }
            return businessOutputTO;
        }
       

        private DataRow populatePaymentReceiptRows(DataTable PaymentReceipt, CustomerPaymentHistoryPageDTO customerPymtHistoryDTO, MPTHistoryUIDTO mptHistUIDTO, PropertyDTO propertyDTO)
        {
            DataRow PaymentReceiptRow = PaymentReceipt.NewRow();            
            string BLANK_STRING = "";            
            PaymentReceiptRow["CustomerName"] = CommonUIConverter.getCustomerFullName(customerPymtHistoryDTO.PrUnitSaleDetail.Customer.FirstName, customerPymtHistoryDTO.PrUnitSaleDetail.Customer.LastName);
            PaymentReceiptRow["Amount"] = mptHistUIDTO.PymtAmt != null ? mptHistUIDTO.PymtAmt : 0;
            PaymentReceiptRow["ReferanceNumber"] = mptHistUIDTO.TxRefNo != null ? mptHistUIDTO.TxRefNo:BLANK_STRING ;
            PaymentReceiptRow["Date"] = mptHistUIDTO.TxDate;
            PaymentReceiptRow["BankName"] = mptHistUIDTO.BankName != null ? mptHistUIDTO.BankName : BLANK_STRING;
            PaymentReceiptRow["Branch"] = mptHistUIDTO.Branch != null ? mptHistUIDTO.Branch : BLANK_STRING;
            PaymentReceiptRow["PropertyName"] = propertyDTO.Name != null ? propertyDTO.Name+" ": BLANK_STRING;
            PaymentReceiptRow["BuildName"] = customerPymtHistoryDTO.PrUnitSaleDetail.PropertyUnit.TowerName != null ? customerPymtHistoryDTO.PrUnitSaleDetail.PropertyUnit.TowerName : BLANK_STRING;
            PaymentReceiptRow["UnitNo"] = customerPymtHistoryDTO.PrUnitSaleDetail.PropertyUnit.UnitNo != null ? CommonUIConverter.getPropertyUnitFormattedNo(customerPymtHistoryDTO.PrUnitSaleDetail.PropertyUnit.Wing, 
            customerPymtHistoryDTO.PrUnitSaleDetail.PropertyUnit.UnitNo)+" ": BLANK_STRING;
            PaymentReceiptRow["ModeOfPayment"] = mptHistUIDTO.PymtMethod;
            AddressDTO addressDto = propertyDTO.ContactInfo.Addresses.FirstOrDefault<AddressDTO>();
            PaymentReceiptRow["Address"] = CommonUtil.getFullAddress(addressDto);
            return PaymentReceiptRow;
        }
        private static DataTable populatePaymentReceiptColumns()
        {
            DataTable PaymentReceipt = new DataTable();
            PaymentReceipt.Columns.Add("CustomerName", typeof(string));
            PaymentReceipt.Columns.Add("Amount", typeof(string));
            PaymentReceipt.Columns.Add("ReferanceNumber", typeof(string));
            PaymentReceipt.Columns.Add("Date", typeof(string));
            PaymentReceipt.Columns.Add("BankName", typeof(string));
            PaymentReceipt.Columns.Add("Branch", typeof(string));
            PaymentReceipt.Columns.Add("PropertyName", typeof(string));
            PaymentReceipt.Columns.Add("BuildName", typeof(string));
            PaymentReceipt.Columns.Add("UnitNo", typeof(string));
            PaymentReceipt.Columns.Add("Address", typeof(string));
            PaymentReceipt.Columns.Add("ModeOfPayment", typeof(string));          
            return PaymentReceipt;
        }
    }
}
