﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Constants.
/// </summary>
namespace ConstroSoft
{
    public static class CallConstants
    {
    	public const string CALL_PROVIDER = "EXOTEL";
    	public class EXOTEL
        {
    		//Outgoing Call Constants.
            public const string OUTCALL_URL = "http://wizeyetech:22e006f218eb074d0cd6045fdf71ca0654ba8c1b@api.exotel.com/v1/Accounts/wizeyetech/Calls/connect.json";
            public const string EXOTEL_SID = "wizeyetech";
            public const string EXOTEL_TOKEN= "22e006f218eb074d0cd6045fdf71ca0654ba8c1b";
            public const string OUTCALLBACK_URL = "http://constrosoftdemo.wizeyetech.com/api/ExotelOutCall/PostOutCallDetails";
            public const string CALLTYPE = "trans";
            //Fetch Call details from exotel.
            public const string CALLDETAILS_URL = "https://wizeyetech:22e006f218eb074d0cd6045fdf71ca0654ba8c1b@api.exotel.com/v1/Accounts/wizeyetech/Calls/";
            
            public const string EXOTEL_FIRMNUMBER = "10001";
            
        }
    }
}