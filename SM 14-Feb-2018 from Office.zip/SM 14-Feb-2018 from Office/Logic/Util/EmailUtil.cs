﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Mail;
/// <summary>
/// Summary description for EmailUtil
/// </summary>
using ConstroSoft;
using NHibernate;

namespace ConstroSoft
{
    public static class EmailUtil
    {
        //Logger Instance
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);


        /**
         * This Method will load the EMAIL Configuration for Firm Number.
         * */
        public static IList<EmailConfig> loadEmailConfiguration(String firmNumber)
        {
            ISession session = null;
            IList<EmailConfig> emailConfigs = null;
            EmailConfig emailConfig = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        emailConfigs = session.QueryOver<EmailConfig>(() => emailConfig).Where(() => emailConfig.FirmNumber == firmNumber).List<EmailConfig>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Email Configuration:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return emailConfigs;
        }
        /**
         * This Method will load the SMS Configuration for Firm Number.
         * */
        public static SmsConfig loadSmsConfiguration(String firmNumber)
        {
            ISession session = null;
            SmsConfig smsConfig = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        smsConfig = session.QueryOver<SmsConfig>(() => smsConfig).Where(() => smsConfig.FirmNumber == firmNumber).SingleOrDefault<SmsConfig>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading SMS Configuration:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return smsConfig;
        }
        /**
         * This method check if internet connection working.
         * */
        public static bool checkInternetConnection()
        {
            try
            {
                using (var client = new WebClient())
                using (var stream = client.OpenRead("http://www.google.com"))
                {
                    return true;
                }

            }
            catch
            {
                return false;
            }
        }
        /**
        * This Method will load the EMAIL & SMS alert Configuration for Firm Number.
        * */
        public static PropertyAlertConfig loadEmailSmsAlertConfiguration(String firmNumber, String functionName, String emailSmsType, long propertyId)
        {
            ISession session = null;
            PropertyAlertConfig emailSmsAlertConfig = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        FunctionName funcName = EnumHelper.ToEnum<FunctionName>(functionName);
                        EmailSmsType type = EnumHelper.ToEnum<EmailSmsType>(emailSmsType);
                        emailSmsAlertConfig = session.QueryOver<PropertyAlertConfig>(() => emailSmsAlertConfig)
                            .Where(() => emailSmsAlertConfig.FirmNumber == firmNumber &&
                                emailSmsAlertConfig.FunctionName == funcName
                                && emailSmsAlertConfig.EmailSmsType == type &&
                                emailSmsAlertConfig.Property.Id == propertyId).SingleOrDefault<PropertyAlertConfig>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Email SMS Alert Configuration:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return emailSmsAlertConfig;
        }
        
        /**
         * This method will load SMS configuration & Send SMS.
         * */
        public static void sendSMS(String firmNumber, PropertyAlertConfig emailSmsAlertConfig, String toNumbers)
        {
            if (checkInternetConnection())
            {
                if (emailSmsAlertConfig != null && emailSmsAlertConfig.SmsConfig != null)
                {
                    string strUrl = emailSmsAlertConfig.SmsConfig.Url + emailSmsAlertConfig.SmsConfig.UserId + ":" + emailSmsAlertConfig.SmsConfig.Password +
                        "&senderID=" + emailSmsAlertConfig.SmsConfig.SenderId + "&receipientno=" + toNumbers + "&msgtxt=" + emailSmsAlertConfig.SmsContent + "&state=4";
                    WebRequest request = HttpWebRequest.Create(strUrl);
                    HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                    Stream s = (Stream)response.GetResponseStream();
                    StreamReader readStream = new StreamReader(s);
                    string dataString = readStream.ReadToEnd();
                    response.Close();
                    s.Close();
                    readStream.Close();
                    if (dataString.StartsWith("Status=0"))
                    {
                        log.Info("SMS Sent Successfully to : " + toNumbers);
                    }
                }
                else
                {
                    log.Error("Error in loading SMS Configuration.");
                }
            }
            else
            {
                log.Error("Please check your internet connection or try again later.");
            }
        }

        public static void sendHtmlFormattedEmail(String firmNumber, PropertyAlertConfig emailSmsAlertConfig, String toAddress)
        {
            if (checkInternetConnection())
            {
                if (emailSmsAlertConfig != null && emailSmsAlertConfig.EmailConfig != null)
                {
                    using (System.Net.Mail.MailMessage mailMessage = new System.Net.Mail.MailMessage())
                    {
                        mailMessage.From = new MailAddress(emailSmsAlertConfig.EmailConfig.Email);
                        mailMessage.Subject = emailSmsAlertConfig.Subject;
                        mailMessage.IsBodyHtml = true;
                        AlternateView avHtml = AlternateView.CreateAlternateViewFromString(emailSmsAlertConfig.EmailBody,
                            null, MediaTypeNames.Text.Html);
                        mailMessage.AlternateViews.Add(avHtml);
                        mailMessage.To.Add(new MailAddress(toAddress));
                        SmtpClient smtp = new SmtpClient();
                        smtp.Host = emailSmsAlertConfig.EmailConfig.SmtpHost;
                        smtp.EnableSsl = true;
                        System.Net.NetworkCredential NetworkCred = new System.Net.NetworkCredential();
                        NetworkCred.UserName = emailSmsAlertConfig.EmailConfig.Email;
                        NetworkCred.Password = emailSmsAlertConfig.EmailConfig.Password;
                        smtp.UseDefaultCredentials = true;
                        smtp.Credentials = NetworkCred;
                        smtp.Port = int.Parse(emailSmsAlertConfig.EmailConfig.SmtpPort);
                        smtp.Send(mailMessage);
                    }
                }
                else
                {
                    log.Error("Error in loading Email Configuration.");
                }
            }
            else
            {
                log.Error("Please check your internet connection or try again later.");
            }
        }
        public static void sendPromotionalEmail(EmailConfig emailConfig, string subject, string emailContent,
            List<string> toList, List<DocumentDTO> attachments)
        {
            if (checkInternetConnection())
            {
                using (System.Net.Mail.MailMessage mailMessage = new System.Net.Mail.MailMessage())
                {
                    mailMessage.From = new MailAddress(emailConfig.Email);
                    mailMessage.Subject = subject;
                    mailMessage.IsBodyHtml = true;
                    toList.ForEach(x => mailMessage.To.Add(new MailAddress(x)));
                    //Add Attachments
                    addAttachments(attachments, mailMessage);
                    //Add In-Line Images
                    IList<LinkedResource> headerImages = new List<LinkedResource>();
                    emailContent = addInlineImages(emailContent, headerImages);
                    AlternateView avHtml = AlternateView.CreateAlternateViewFromString(emailContent, null, MediaTypeNames.Text.Html);
                    foreach (LinkedResource linkedResource in headerImages)
                    {
                        avHtml.LinkedResources.Add(linkedResource);
                    }
                    mailMessage.AlternateViews.Add(avHtml);

                    //Send Mail
                    SmtpClient smtp = new SmtpClient();
                    smtp.Host = emailConfig.SmtpHost;
                    smtp.EnableSsl = true;
                    System.Net.NetworkCredential NetworkCred = new System.Net.NetworkCredential();
                    NetworkCred.UserName = emailConfig.Email;
                    NetworkCred.Password = emailConfig.Password;
                    smtp.UseDefaultCredentials = true;
                    smtp.Credentials = NetworkCred;
                    smtp.Port = int.Parse(emailConfig.SmtpPort);
                    smtp.Send(mailMessage);
                }
            }
            else
            {
                log.Error("Please check your internet connection or try again later.");
                throw new CustomException("Please check your internet connection or try again later.");
            }
        }

        private static void addAttachments(List<DocumentDTO> attachments, System.Net.Mail.MailMessage mailMessage)
        {
            if (attachments != null && attachments.Count > 0)
            {
                foreach (DocumentDTO documentDTO in attachments)
                {
                    Attachment attachment = new Attachment(new MemoryStream(documentDTO.Content), documentDTO.FileName);
                    mailMessage.Attachments.Add(attachment);
                }
            }
        }

        private static string addInlineImages(string emailContent, IList<LinkedResource> headerImages)
        {
            MatchCollection matchCollection = Regex.Matches(emailContent, "<img[^>]+>");
            int i = 1;
            foreach (Match match in matchCollection)
            {
                string filename = "img" + i;
                string replace = match.Value;
                string replacement = "<img src=\"" + "cid:" + filename + "\"/>";
                emailContent = Regex.Replace(emailContent, replace, replacement);
                var start = replace.IndexOf("base64,") + 7;
                var end = replace.IndexOf("\" data-filename");
                string output = replace.Substring(start, end - start);
                string converted = output.Replace(' ', '+');
                int mod4 = output.Length % 4;
                if (mod4 > 0)
                {
                    converted += new string('=', 4 - mod4);
                }
                MemoryStream image = Base64ToImage(converted);
                LinkedResource headerImage = new LinkedResource(image, new ContentType("image/jpg"));
                headerImage.ContentId = filename;
                headerImages.Add(headerImage);

                i = i + 1;
            }
            foreach (LinkedResource linkedResource in headerImages)
            {
                emailContent = string.Format(emailContent, linkedResource.ContentId);
            }
            return emailContent;
        }
        
        public static MemoryStream Base64ToImage(string base64String)
        {
            // Convert base 64 string to byte[]
            byte[] imageBytes = Convert.FromBase64String(base64String);
            // Convert byte[] to Image
            MemoryStream ms = new MemoryStream(imageBytes, 0, imageBytes.Length);
            return ms;
        }
        /**
         * This method will load SMS configuration & Send SMS.
         * */
        public static void sendPromotionalSMS(String firmNumber, string smsContent, List<string> toList)
        {
            if (checkInternetConnection())
            {
                SmsConfig smsConfig = loadSmsConfiguration(firmNumber);
                if (smsConfig != null)
                {
                    foreach (string toNumber in toList)
                    {
                        string strUrl = smsConfig.Url + smsConfig.UserId + ":" + smsConfig.Password +
                            "&senderID=" + smsConfig.SenderId + "&receipientno=" + toNumber + "&msgtxt=" + smsContent + "&state=4";
                        WebRequest request = HttpWebRequest.Create(strUrl);
                        HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                        Stream s = (Stream)response.GetResponseStream();
                        StreamReader readStream = new StreamReader(s);
                        string dataString = readStream.ReadToEnd();
                        response.Close();
                        s.Close();
                        readStream.Close();
                        if (dataString.StartsWith("Status=0"))
                        {
                            log.Info("SMS Sent Successfully to : " + toNumber);
                        }
                    }
                }
                else
                {
                    log.Error("Error in loading SMS Configuration.");
                }
            }
            else
            {
                log.Error("Please check your internet connection or try again later.");
            }
        }
    }
}