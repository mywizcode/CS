﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Net;
using System.IO;
using System.Windows.Forms;
using System.Net.Mail;
using ConstroSoft;
using ConstroSoft.Logic.BO;
using OfficeOpenXml;
using OfficeOpenXml.DataValidation;
using OfficeOpenXml.Style;
using System.Drawing;
using ConstroSoft.Logic.Util;
using System.Text;
using System.Web.UI.HtmlControls;
using ConstroSoft.DataSetContainer;
using CrystalDecisions.CrystalReports.Engine;
using System.Data;


public partial class CustomerPymtHistory : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string uploadDocumentModalError = "uploadDocumentModalError";
    string uploadDocumentModal = "uploadDocumentModal";
    string SearchFilterModal = "SearchFilterModal";
    string splitPymtTypeInfoModal = "splitPymtTypeInfoModal";
    string UploadPaymentReceiptModal = "UploadPaymentReceiptModal";
    string ShowPymtReceiptModal = "ShowPymtReceiptModal";
    DocumentBO documentBO = new DocumentBO();
    DropdownBO drpBO = new DropdownBO();
    PaymentBO paymentBO = new PaymentBO();
    public enum CustomerPymtPageMode { ADD, MODIFY, VIEW}
    ReportConfigBO reportConfigBO = new ReportConfigBO();
    PaymentReceiptBO paymentReceiptBO = new PaymentReceiptBO();
    protected void Page_Load(object sender, EventArgs e)
    {
    	Page.Form.Attributes.Add("enctype", "multipart/form-data");
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                CustomerPymtHistoryNavDTO navDto = ApplicationUtil.getPageNavDTO<CustomerPymtHistoryNavDTO>(Session);
                if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.MENU_CUSTOMER_PAYMENTS)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
        	if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void preRenderInitFormElements()
    {
    	renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
    	ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpPymtTypeFilter, DrpDataType.MASTER_CONTROL_DATA, MasterDataType.PR_UNIT_PYMT_TYPE.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpEnum<PaymentMethod>(drpPymtMethodFilter, Constants.SELECT_ITEM);
    }
    public void setErrorMessage(string message, string group)
    {
    	string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        else
        {
	        CustomValidator val = new CustomValidator();
	        val.IsValid = false;
	        val.ErrorMessage = message;
	        val.ValidationGroup = group;
	        this.Page.Validators.Add(val);
        }
    }
    private void doInit(CustomerPymtHistoryNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new CustomerPaymentHistoryPageDTO();
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private CustomerPaymentHistoryPageDTO  getSessionReceiptPageData()
    {
        return (CustomerPaymentHistoryPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private void initPageAfterRedirect(CustomerPymtHistoryNavDTO navDto)
    {
        try
        {
            CustomerPaymentHistoryPageDTO customerPymtHistoryDTO = getSessionPageData();
            setSearchFilter(navDto.FilterDTO);
            customerPymtHistoryDTO.PrevNavDTO = navDto.PrevNavDto;
            customerPymtHistoryDTO.PrUnitSaleDetail = paymentBO.fetchPrUnitDetails(getUserDefinitionDTO().FirmNumber, navDto.PrUnitSaleDetailId);
            //Derive PaymentMode
            PaymentMode PymtMode = (navDto.PymtMode != null) ? (PaymentMode)navDto.PymtMode : PaymentMode.Receivable;
            customerPymtHistoryDTO.PymtMode = PymtMode;
            fetchUnitPymtHeadersAndHistory(customerPymtHistoryDTO);
            populateUIOnInit(customerPymtHistoryDTO);
            enableTab(!navDto.isPdc);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void navigateToPreviousPage()
    {
        CustomerPaymentHistoryPageDTO customerPymtHistoryDTO = getSessionPageData();
        if (customerPymtHistoryDTO != null && customerPymtHistoryDTO.PrevNavDTO != null)
        {
            object obj = customerPymtHistoryDTO.PrevNavDTO;
            if (obj is SoldUnitDetailNavDTO)
            {
                SoldUnitDetailNavDTO navDTO = (SoldUnitDetailNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.SOLD_UNIT_DETAILS, true);
            }
            else if (obj is CancelledUnitDetailNavDTO)
            {
            	CancelledUnitDetailNavDTO navDTO = (CancelledUnitDetailNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.CANCELLED_UNIT_DETAILS, true);
            }
            else if (obj is CustomerPymtSearchNavDTO)
            {
                CustomerPymtSearchNavDTO navDTO = (CustomerPymtSearchNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.CUSTOMER_PYMT_SEARCH, true);
            }
        }
        Response.Redirect(Constants.URL.CUSTOMER_PYMT_SEARCH, true);
    }
    private void renderPageFieldsWithEntitlement()
    {
        initFormFields();
        resetPageTitle();
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        //Navigation action entitlement
        lnkNavToSoldUnitDtl.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MENU_SOLD_PR_UNIT);
        liNavigation.Visible = lnkNavToSoldUnitDtl.Visible;
        //Add Payment/Pdc entitlement
        liAddPymtBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PAYMENT_ADD);
        liAddPdcBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PDC_ADD);
        liPymtPageNavGrp.Visible = liAddPymtBtn.Visible || liAddPdcBtn.Visible;
        //Tx History table entitlement
    	if (txHistoryGrid.Rows.Count > 0)
        {
            bool isActionEnabled = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.GENERATE_PYMT_RECEIPT, Constants.Entitlement.MARK_PYMT_RCPT_DELIVERED, Constants.Entitlement.DELETE_PAYMENT_TRANSACTION);
            for (var i = 0; i < txHistoryGrid.Rows.Count; i++)
            {
                HtmlGenericControl tmpBtn = (HtmlGenericControl)txHistoryGrid.Rows[i].FindControl("liGenerateReceiptBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.GENERATE_PYMT_RECEIPT);
                tmpBtn = (HtmlGenericControl)txHistoryGrid.Rows[i].FindControl("liMarkReceiptDeliveredBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MARK_PYMT_RCPT_DELIVERED);
                tmpBtn = (HtmlGenericControl)txHistoryGrid.Rows[i].FindControl("liDeleteTransactionBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.DELETE_PAYMENT_TRANSACTION);
                tmpBtn = (HtmlGenericControl)txHistoryGrid.Rows[i].FindControl("ulTxHistoryActionBtn");
                if (tmpBtn != null) tmpBtn.Visible = isActionEnabled;
            }
            txHistoryGrid.Columns[0].Visible = isActionEnabled;
        }
    	//Pdc History table entitlement
    	if (pdcGrid.Rows.Count > 0)
        {
            bool isActionEnabled = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MODIFY_PDC, Constants.Entitlement.DELETE_PDC);
            for (var i = 0; i < pdcGrid.Rows.Count; i++)
            {
                HtmlGenericControl tmpBtn = (HtmlGenericControl)pdcGrid.Rows[i].FindControl("liModifyPdcBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.MODIFY_PDC);
                tmpBtn = (HtmlGenericControl)pdcGrid.Rows[i].FindControl("liDeletePdcBtn");
                if (tmpBtn != null) tmpBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.DELETE_PDC);
                tmpBtn = (HtmlGenericControl)pdcGrid.Rows[i].FindControl("ulPdcHistoryActionBtn");
                if (tmpBtn != null) tmpBtn.Visible = isActionEnabled;
            }
            pdcGrid.Columns[0].Visible = isActionEnabled;
        }
    }
    private void resetPageTitle()
    {
        lbPageTitle.Text = Constants.ICON.VIEW_DTL + Resources.Labels.CUSTOMER_PAYMENT_HISTORY;
    }
    private void initFormFields()
    {
        
    }
    private CustomerPaymentHistoryPageDTO getSessionPageData()
    {
        return (CustomerPaymentHistoryPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private long getDeleteRecordHdnId()
    {
        string pId = btnDeleteRecordHdnId.Value;
        btnDeleteRecordHdnId.Value = "";
        return long.Parse(pId);
    }
    private void populateUIOnInit(CustomerPaymentHistoryPageDTO customerPymtHistoryDTO) {
        soldUnitIcon.Visible = (customerPymtHistoryDTO.PrUnitSaleDetail.Status == PRUnitSaleStatus.Sold);
        cancelledUnitIcon.Visible = !soldUnitIcon.Visible;
        btnSoldUnitInfoHdn.Attributes["row-info"] = CommonUIConverter.getUnitInfo(customerPymtHistoryDTO.PrUnitSaleDetail);
        btnCancelledUnitInfoHdn.Attributes["row-info"] = CommonUIConverter.getUnitInfo(customerPymtHistoryDTO.PrUnitSaleDetail);
        btnCustomerHdn.Attributes["row-info"] = CommonUIConverter.getCustomerInfo(customerPymtHistoryDTO.PrUnitSaleDetail);
        lbUnitNo.Text = CommonUIConverter.getPropertyUnitFormattedNo(customerPymtHistoryDTO.PrUnitSaleDetail.PropertyUnit.Wing, 
            customerPymtHistoryDTO.PrUnitSaleDetail.PropertyUnit.UnitNo);
        lbBookingRefNo.Text = customerPymtHistoryDTO.PrUnitSaleDetail.BookingRefNo;
        lbCustomerName.Text = CommonUIConverter.getCustomerFullName(customerPymtHistoryDTO.PrUnitSaleDetail.Customer.FirstName, 
            customerPymtHistoryDTO.PrUnitSaleDetail.Customer.LastName);
        lbCustomerRefNo.Text = customerPymtHistoryDTO.PrUnitSaleDetail.Customer.CustRefNo;

        initUnitPymtAndTransHistorySection(customerPymtHistoryDTO);
    }
    private void fetchAndInitUnitPymtAndTransHistorySection(CustomerPaymentHistoryPageDTO customerPymtHistoryDTO) {
        fetchUnitPymtHeadersAndHistory(customerPymtHistoryDTO);
        initUnitPymtAndTransHistorySection(customerPymtHistoryDTO);
    }
    private void fetchUnitPymtHeadersAndHistory(CustomerPaymentHistoryPageDTO customerPymtHistoryDTO) {
        PaymentMode? PymtModeToFetch = (!string.IsNullOrWhiteSpace(customerPymtHistoryDTO.isMultiplePymts)) ? (PaymentMode?)customerPymtHistoryDTO.PymtMode : null;
        IList<PrUnitSalePymtDTO> pymtHeadersList = paymentBO.fetchUnitPaymentHeaders(getUserDefinitionDTO().FirmNumber,
            customerPymtHistoryDTO.PrUnitSaleDetail.Id, PymtModeToFetch, true);
        customerPymtHistoryDTO.PymtHeaders = new List<PrUnitSalePymtDTO>(pymtHeadersList);
        if (PymtModeToFetch == null) setMultiplePymtFlag(customerPymtHistoryDTO);
        
        TotalPymtDTO totalPymtDTO = new TotalPymtDTO();
        foreach (PrUnitSalePymtDTO tmpPymtHeader in customerPymtHistoryDTO.PymtHeaders)
        {
            totalPymtDTO.TotalPymtAmt = Decimal.Add(totalPymtDTO.TotalPymtAmt, tmpPymtHeader.PaymentMaster.TotalAmt);
            totalPymtDTO.TotalPaidAmt = Decimal.Add(totalPymtDTO.TotalPaidAmt, tmpPymtHeader.PaymentMaster.TotalPaid);
            totalPymtDTO.TotalPendingAmt = Decimal.Add(totalPymtDTO.TotalPendingAmt, tmpPymtHeader.PaymentMaster.TotalPending);
            if(tmpPymtHeader.PaymentMaster.Status == PymtMasterStatus.Suspended) totalPymtDTO.PymtStatus = PymtMasterStatus.Suspended;
            else if (totalPymtDTO.PymtStatus != PymtMasterStatus.Suspended) {
                if (totalPymtDTO.TotalPendingAmt > 0) totalPymtDTO.PymtStatus = PymtMasterStatus.Pending;
                else totalPymtDTO.PymtStatus = PymtMasterStatus.Paid;
            }
        }
        customerPymtHistoryDTO.TotalPymtDTO = totalPymtDTO;
        //Fetch MPT History for current Payment Mode.
        customerPymtHistoryDTO.MasterPymtTransDTOs = paymentBO.fetchMPTForPropertyUnit(getUserDefinitionDTO().FirmNumber, customerPymtHistoryDTO.PrUnitSaleDetail.Id, 
            customerPymtHistoryDTO.PymtMode);
    }
    private void setMultiplePymtFlag(CustomerPaymentHistoryPageDTO customerPymtHistoryDTO) {
        if(string.IsNullOrWhiteSpace(customerPymtHistoryDTO.isMultiplePymts)) {
            customerPymtHistoryDTO.isMultiplePymts = Constants.NO;
            PaymentMode? PymtMode = null;
            foreach (PrUnitSalePymtDTO tmpPymtHeader in customerPymtHistoryDTO.PymtHeaders)
            {
                if(PymtMode == null) PymtMode = tmpPymtHeader.PymtMode;
                else if(PymtMode != tmpPymtHeader.PymtMode) {
                    customerPymtHistoryDTO.isMultiplePymts = Constants.YES;
                    break;
                }
            }
            //First time system fetches all Pymt headers, so remove for which pymtmode not same as current pymtmode.
            customerPymtHistoryDTO.PymtHeaders.RemoveAll(x => x.PymtMode != customerPymtHistoryDTO.PymtMode);
        }
    }
    private void initUnitPymtAndTransHistorySection(CustomerPaymentHistoryPageDTO customerPymtHistoryDTO)
    {
        //Populate Selected Payment Mode(Receivable/Payable) Total amounts
        lbUnitPaymentMode.Text = customerPymtHistoryDTO.PymtMode.ToString();
        lbUnitPymtStatus.Text = customerPymtHistoryDTO.TotalPymtDTO.PymtStatus.ToString();
        lnkPymtShuffle.Visible = Constants.YES.Equals(customerPymtHistoryDTO.isMultiplePymts);
        if (customerPymtHistoryDTO.TotalPymtDTO.PymtStatus == PymtMasterStatus.Paid) spUnitPymtStatus.Attributes["class"] = "label label-success pull-right";
        else if (customerPymtHistoryDTO.TotalPymtDTO.PymtStatus == PymtMasterStatus.Pending) spUnitPymtStatus.Attributes["class"] = "label label-warning pull-right";
        else if (customerPymtHistoryDTO.TotalPymtDTO.PymtStatus == PymtMasterStatus.Suspended) spUnitPymtStatus.Attributes["class"] = "label label-default pull-right";
        lbUnitTotalAmt.Text = customerPymtHistoryDTO.TotalPymtDTO.TotalPymtAmt.ToString();
        lbUnitTotalPaid.Text = customerPymtHistoryDTO.TotalPymtDTO.TotalPaidAmt.ToString();
        lbUnitTotalPending.Text = customerPymtHistoryDTO.TotalPymtDTO.TotalPendingAmt.ToString();

        //Populate Qualified Payment Types/Headers for selected Payment Mode(Receivable/Payable)
        paymentSummaryGrid.DataSource = customerPymtHistoryDTO.PymtHeaders;
        paymentSummaryGrid.DataBind();
        //Load Master Payment Transactions and PDCs.
        loadPdcGrid(customerPymtHistoryDTO);
        loadPymtTxHistoryGrid(customerPymtHistoryDTO);
    }
    private void loadPdcGrid(CustomerPaymentHistoryPageDTO customerPymtHistoryDTO) {
        pdcGrid.DataSource = getPdcUIDTOs(customerPymtHistoryDTO);
        pdcGrid.DataBind();
    }
    private void loadPymtTxHistoryGrid(CustomerPaymentHistoryPageDTO customerPymtHistoryDTO) {
        txHistoryGrid.DataSource = getPymtTxHistoryWithFilter(customerPymtHistoryDTO);
        txHistoryGrid.DataBind();
    }
    private List<MPTHistoryUIDTO> getPymtTxHistoryWithFilter(CustomerPaymentHistoryPageDTO customerPymtHistoryDTO) {
        List<MasterPymtTransactionDTO> mptDTOs = customerPymtHistoryDTO.MasterPymtTransDTOs.FindAll(x => x.PymtStatus != MPTPymtStatus.Pending); 
        List<MPTHistoryUIDTO> filteredMPTDTOs = new List<MPTHistoryUIDTO>();
        if(mptDTOs != null && mptDTOs.Count > 0) {
            CustomerPymtTxHistoryFilterDTO filterDTO = getSearchFilter();
            foreach (MasterPymtTransactionDTO mptDTO in mptDTOs)
            {
                bool qualified = true;
                MPTHistoryUIDTO mptUIDTO = getMPTHistoryUIDTO(mptDTO, false);
                if(filterDTO.PymtTypeId > 0) {
                    MPTDistributionDTO mptDistDTO = mptUIDTO.PymtDistributions.Find(x => x.PymtType.Id == filterDTO.PymtTypeId);
                    qualified = (mptDistDTO != null);
                    if (mptDistDTO != null) {
                        mptUIDTO.PymtType = mptDistDTO.PymtType.Name;
                        mptUIDTO.PymtAmt = mptDistDTO.Amount;
                        mptUIDTO.AccountName = mptDistDTO.FirmAccount.Name;
                    }
                }
                if(filterDTO.PymtMethod != null) {
                    qualified = mptUIDTO.PymtMethod.ToString().Equals(filterDTO.PymtMethod.ToString());
                }
                if(filterDTO.TxRefNo != null) {
                    qualified = mptUIDTO.TxRefNo.ToString().Equals(filterDTO.TxRefNo.ToString());
                }
                if(filterDTO.MediaNo != null) {
                    qualified = mptUIDTO.MediaNo.ToString().Equals(filterDTO.MediaNo.ToString());
                }
                if (qualified) filteredMPTDTOs.Add(mptUIDTO);
            }
        }
        customerPymtHistoryDTO.PymtTransHistoryUIDTOs = filteredMPTDTOs;
        return filteredMPTDTOs;
    }
    private List<MPTHistoryUIDTO> getPdcUIDTOs(CustomerPaymentHistoryPageDTO customerPymtHistoryDTO) {
        List<MasterPymtTransactionDTO> mptDTOs = customerPymtHistoryDTO.MasterPymtTransDTOs.FindAll(x => x.PymtStatus == MPTPymtStatus.Pending && x.ChequeStatus != null 
            && x.ChequeStatus != ChequeStatus.Cleared);
        customerPymtHistoryDTO.PdcUIDTOs = new List<MPTHistoryUIDTO>();
        if(mptDTOs != null && mptDTOs.Count > 0) {
            foreach (MasterPymtTransactionDTO mptDTO in mptDTOs)
            {
                customerPymtHistoryDTO.PdcUIDTOs.Add(getMPTHistoryUIDTO(mptDTO, true));
            }
        }
        return customerPymtHistoryDTO.PdcUIDTOs;
    }
    private MPTHistoryUIDTO getMPTHistoryUIDTO(MasterPymtTransactionDTO mptDTO, bool isPdc) {
        MPTHistoryUIDTO mptUIDTO = new MPTHistoryUIDTO();
        mptUIDTO.Id = mptDTO.Id;
        mptUIDTO.TxRefNo = mptDTO.TxRefNo;
        mptUIDTO.PymtMethod = mptDTO.PymtMethod;
        mptUIDTO.TxDate = mptDTO.TxDate;
        mptUIDTO.PymtAmt = mptDTO.PymtAmt;
        mptUIDTO.CollectionDate = mptDTO.CollectionDate;
        mptUIDTO.ChequeDate = mptDTO.ChequeDate;
        mptUIDTO.ClearanceDate = mptDTO.ClearanceDate;
        mptUIDTO.PayName = mptDTO.PayName;
        mptUIDTO.BankName = mptDTO.BankName;
        mptUIDTO.Branch = mptDTO.Branch;        
        mptUIDTO.MediaNo = mptDTO.MediaNo;
        mptUIDTO.ChequeStatus = mptDTO.ChequeStatus;
        mptUIDTO.Comments = mptDTO.Comments;
        mptUIDTO.PymtStatus = mptDTO.PymtStatus;
        mptUIDTO.ReceiptDelivered = mptDTO.RcptDelivered == PymtTransRcptDelivered.Yes;
        mptUIDTO.PymtDistributions = new List<MPTDistributionDTO>();
        CustomerPaymentHistoryPageDTO customerPymtHistoryDTO = getSessionPageData();
        foreach (PaymentTransactionDTO pymtTxDTO in mptDTO.PaymentTransactions)
        {
            if(pymtTxDTO.Status != PymtTransStatus.Reversal) {
                PrUnitSalePymtDTO pymtHeaderDTO = customerPymtHistoryDTO.PymtHeaders.Find(x => x.PaymentMaster.Id == pymtTxDTO.PaymentMaster.Id);
                MPTDistributionDTO distributionDTO = new MPTDistributionDTO();
                distributionDTO.PymtTxId = pymtTxDTO.Id;
                distributionDTO.PymtType = pymtHeaderDTO.PymtType;
                distributionDTO.Amount = pymtTxDTO.Amount;
                distributionDTO.FirmAccount = pymtTxDTO.FirmAccount;
                distributionDTO.Comments = pymtTxDTO.Comments;
                mptUIDTO.PymtDistributions.Add(distributionDTO);
            }
        }
        if (!isPdc)
        {
            mptUIDTO.ShowSplit = mptUIDTO.PymtDistributions.Count > 1;
            mptUIDTO.PymtType = (mptUIDTO.PymtDistributions.Count > 1) ? "MULTIPLE" : mptUIDTO.PymtDistributions[0].PymtType.Name;
            mptUIDTO.AccountName = (mptUIDTO.PymtDistributions.Count > 1) ? "MULTIPLE" : mptUIDTO.PymtDistributions[0].FirmAccount.Name;
        }
        
        mptUIDTO.RowInfo = CommonUIConverter.getGridViewRowInfo(mptUIDTO);
        return mptUIDTO;
    }
    private bool isPymtReceivable()
    {
        return getSessionPageData().PymtMode == PaymentMode.Receivable;
    }
    protected void onClickPymtShuffle(object sender, EventArgs e)
    {
        try
        {
            CustomerPaymentHistoryPageDTO customerPymtHistoryDTO = getSessionPageData();
            customerPymtHistoryDTO.PymtMode = (PaymentMode.Receivable == customerPymtHistoryDTO.PymtMode) ? PaymentMode.Payable : PaymentMode.Receivable;
            fetchAndInitUnitPymtAndTransHistorySection(customerPymtHistoryDTO);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void enableTab(bool isPymtHistory)
    {
        liPymtHistory.Attributes["class"] = (isPymtHistory) ? "active" : "";
        liPdc.Attributes["class"] = (isPymtHistory) ? "" : "active";
        pnlPymtTransHistory.Visible = isPymtHistory;
        pnlPdc.Visible = !isPymtHistory;
    }
    protected void onClickNavToSoldUnit(object sender, EventArgs e)
    {
        try
        {
        	CustomerPaymentHistoryPageDTO customerPymtHistoryDTO = getSessionPageData();
        	if(customerPymtHistoryDTO.PrUnitSaleDetail.Status == PRUnitSaleStatus.Sold) {
        		SoldUnitDetailNavDTO navDTO = new SoldUnitDetailNavDTO();
                navDTO.Mode = PageMode.VIEW;
                navDTO.PrUnitSaleDetailId = customerPymtHistoryDTO.PrUnitSaleDetail.Id;
                navDTO.PrevNavDto = getCurrentPageNavigation();
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.SOLD_UNIT_DETAILS, true);
    		} else {
    			CancelledUnitDetailNavDTO navDTO = new CancelledUnitDetailNavDTO();
    			navDTO.Mode = PageMode.VIEW;
    			navDTO.PrUnitSaleDetailId = customerPymtHistoryDTO.PrUnitSaleDetail.Id;
    			navDTO.PrevNavDto = getCurrentPageNavigation();
    			Session[Constants.Session.NAV_DTO] = navDTO;
    			Response.Redirect(Constants.URL.CANCELLED_UNIT_DETAILS, true);
    		}
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickPymtHistory(object sender, EventArgs e)
    {
        try
        {
            enableTab(true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickPostDatedCheques(object sender, EventArgs e)
    {
        try
        {
            enableTab(false);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickAddPaymentBtn(object sender, EventArgs e)
    {
        try
        {
            navigateToPaymentAdd(false);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickAddPdcBtn(object sender, EventArgs e)
    {
        try
        {
            navigateToPaymentAdd(true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private PropertyDetailPageDTO getSessionPropertyPageData()
    {
        return (PropertyDetailPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private void navigateToPaymentAdd(bool isPdc)
    {
        CustomerPaymentHistoryPageDTO customerPymtHistoryDTO = getSessionPageData();        
        CustomerPaymentNavDTO navDTO = new CustomerPaymentNavDTO();
        navDTO.IsPdcPayment = isPdc;
        navDTO.Mode = PageMode.ADD;
        navDTO.PymtMode = customerPymtHistoryDTO.PymtMode;
        navDTO.PrUnitSaleDetailId = customerPymtHistoryDTO.PrUnitSaleDetail.Id;
        navDTO.PrevNavDto = getCurrentPageNavigation();
        Session[Constants.Session.NAV_DTO] = navDTO;
        Response.Redirect((isPdc) ? Constants.URL.CUSTOMER_PYMT_ADDPDC : Constants.URL.CUSTOMER_PYMT_ADD, true);
    }
    private void setSelectedMPT(long selectedIndex)
    {
        List<MPTHistoryUIDTO> tmpList = getSessionPageData().PymtTransHistoryUIDTOs;
        tmpList.ForEach(c => c.isUISelected = false);
        if (selectedIndex > 0) tmpList.Find(c => c.Id == selectedIndex).isUISelected = true;
    }
    private MPTHistoryUIDTO getSelectedMPT(long selectedIndex)
    {
        List<MPTHistoryUIDTO> tmpList = getSessionPageData().PymtTransHistoryUIDTOs;
        return (selectedIndex > 0) ? tmpList.Find(c => c.Id == selectedIndex) : tmpList.Find(c => c.isUISelected);
    }
    protected void paymentHitoryRowCreated(Object sender, GridViewRowEventArgs e)
    {
        LinkButton lnkGenerateReceiptBtn = (LinkButton)e.Row.FindControl("lnkGenerateReceiptBtn");
        if (lnkGenerateReceiptBtn != null)
        {
            ScriptManager mgr = ScriptManager.GetCurrent(this.Page);
            mgr.RegisterPostBackControl(lnkGenerateReceiptBtn);
        }
    }
    protected void onClickGenerateReceiptBtn(object sender, EventArgs e)
    {
        try
        {
                ReportConfigDTO reportConfigDTO = null;
                BusinessOutputTO businessOutputTO = null;
                ReportDocument letterReportDocument = new ReportDocument();
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                //PropertyDetailPageDTO PageDTO = getSessionPropertyPageData();
                LinkButton rd = (LinkButton)sender;
                long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
                CustomerPaymentHistoryPageDTO customerPymtHistoryDTO = getSessionPageData();
                MPTHistoryUIDTO mptHistUIDTO = customerPymtHistoryDTO.PymtTransHistoryUIDTOs.Find(x => x.Id == selectedIndex);
                MasterPymtTransactionDTO mptTxDTO = customerPymtHistoryDTO.MasterPymtTransDTOs.Find(x => x.Id == mptHistUIDTO.Id);
                businessOutputTO = paymentReceiptBO.processPaymentReceipt(customerPymtHistoryDTO, mptHistUIDTO, CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()).Id);
                reportConfigDTO = reportConfigBO.fetchReportConfiguration(userDefDto.FirmNumber, SoldUnitLetterType.RECEIPT.GetDescription());
                string reportPath = Server.MapPath(reportConfigDTO.ReportPath);
                letterReportDocument.Load(reportPath);
                letterReportDocument.Database.Tables["ReceiptData"].SetDataSource(businessOutputTO.result);
                try
                {
                    letterReportDocument.ExportToHttpResponse
                    (CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, true, businessOutputTO.successMessage);
                }
                catch (Exception exp)
                {

                }            
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickDeleteMasterPaymentTxBtn(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            CustomerPaymentHistoryPageDTO customerPymtHistoryDTO = getSessionPageData();
            MPTHistoryUIDTO mptHistUIDTO = customerPymtHistoryDTO.PymtTransHistoryUIDTOs.Find(x => x.Id == selectedIndex);
            if(validateMPTDelete(mptHistUIDTO)) {
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                MasterPymtTransactionDTO mptTxDTO = customerPymtHistoryDTO.MasterPymtTransDTOs.Find(x => x.Id == mptHistUIDTO.Id);
                mptTxDTO.UpdateUser = userDefDto.Username;
                mptTxDTO.MPTBook.PrUnitSaleDetail = customerPymtHistoryDTO.PrUnitSaleDetail;
                paymentBO.deleteMasterPymtTransactionDetails(mptTxDTO);
                
                fetchAndInitUnitPymtAndTransHistorySection(customerPymtHistoryDTO);
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format("Payment Transaction '# {0}' is deleted successfully.", mptTxDTO.TxRefNo)));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void showSplitPymtTypeInfo(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            CustomerPaymentHistoryPageDTO customerPymtHistoryDTO = getSessionPageData();
            MPTHistoryUIDTO mptHistUIDTO = customerPymtHistoryDTO.PymtTransHistoryUIDTOs.Find(x => x.Id == selectedIndex);
            splitPymtTypeInfoGrid.DataSource = mptHistUIDTO.PymtDistributions;
            splitPymtTypeInfoGrid.DataBind();
            activeModalHdn.Value = splitPymtTypeInfoModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelSpliPymtTypeInfoModal(object sender, EventArgs e)
    {
        try
        {
            //Nothing to do
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private CustomerPymtHistoryNavDTO getCurrentPageNavigation()
    {
        CustomerPaymentHistoryPageDTO customerPymtHistoryDTO = getSessionPageData();
        CustomerPymtHistoryNavDTO pageNavDTO = new CustomerPymtHistoryNavDTO();
        pageNavDTO.FilterDTO = getSearchFilter();
        pageNavDTO.PrUnitSaleDetailId = customerPymtHistoryDTO.PrUnitSaleDetail.Id;
        pageNavDTO.PymtMode = customerPymtHistoryDTO.PymtMode;
        pageNavDTO.isPdc = pnlPdc.Visible;
        pageNavDTO.PrevNavDto = customerPymtHistoryDTO.PrevNavDTO;
        return pageNavDTO;
    }
    protected void onClickModifyPdcBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            CustomerPaymentHistoryPageDTO customerPymtHistoryDTO = getSessionPageData();
            MPTHistoryUIDTO mptHistUIDTO = customerPymtHistoryDTO.PdcUIDTOs.Find(x => x.Id == selectedIndex);
            if (validatePdcDelete(mptHistUIDTO)) {
                CustomerPaymentNavDTO navDTO = new CustomerPaymentNavDTO();
                navDTO.IsPdcPayment = true;
                navDTO.Mode = PageMode.MODIFY;
                navDTO.PymtMode = customerPymtHistoryDTO.PymtMode;
                navDTO.PrUnitSaleDetailId = customerPymtHistoryDTO.PrUnitSaleDetail.Id;
                navDTO.MPTId = selectedIndex;
                navDTO.PrevNavDto = getCurrentPageNavigation();
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.CUSTOMER_PYMT_MODIFYPDC, true);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickDeletePdcBtn(object sender, EventArgs e)
    {
        try
        {
            long selectedIndex = getDeleteRecordHdnId();
            CustomerPaymentHistoryPageDTO customerPymtHistoryDTO = getSessionPageData();
            MPTHistoryUIDTO mptHistUIDTO = customerPymtHistoryDTO.PdcUIDTOs.Find(x => x.Id == selectedIndex);
            if(mptHistUIDTO.PymtStatus == MPTPymtStatus.Pending) {
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                paymentBO.deleteUnpaidPdcDetails(selectedIndex, userDefDto.Username);
                fetchAndInitUnitPymtAndTransHistorySection(customerPymtHistoryDTO);
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("Post Dated Cheque is deleted successfully. Media #" + mptHistUIDTO.MediaNo));
            } else {
                (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg("Incorrect Payment Transaction is selected for delete."));
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateMPTDelete(MPTHistoryUIDTO mptHistoryUIDTO) {
        bool result = true;
        if(mptHistoryUIDTO != null) {
            if (mptHistoryUIDTO.PymtStatus == MPTPymtStatus.Deleted) {
                setErrorMessage("Payment Transaction is already deleted.", commonError);
                result = false;
            }
        }
        return result;
    }
    private bool validatePdcDelete(MPTHistoryUIDTO mptHistoryUIDTO) {
        bool result = true;
        if(mptHistoryUIDTO.PymtStatus == MPTPymtStatus.Pending) {
            if (mptHistoryUIDTO.ChequeStatus != null && (mptHistoryUIDTO.ChequeStatus == ChequeStatus.Returned || mptHistoryUIDTO.ChequeStatus == ChequeStatus.Bounced)) {
                setErrorMessage("Post Dated Cheque with 'Bounced/Returned' status cannot be modified.", commonError);
                result = false;
            }
        }
        return result;
    }
    //Filter Criteria - Property Search - Start
    private CustomerPymtTxHistoryFilterDTO getSearchFilter()
    {
        return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            CustomerPymtTxHistoryFilterDTO filterDTO = getSearchFilter();
            if (filterDTO.PymtTypeId > 0) drpPymtTypeFilter.Text = filterDTO.PymtTypeId.ToString(); else drpPymtTypeFilter.ClearSelection();
            if (filterDTO.PymtMethod != null) drpPymtMethodFilter.Text = filterDTO.PymtMethod.ToString(); else drpPymtMethodFilter.ClearSelection();
            if (filterDTO.TxRefNo != null) txtTxRefNoFilter.Text = filterDTO.TxRefNo; else txtTxRefNoFilter.Text = null;
            if (filterDTO.MediaNo != null) txtMediaNoFilter.Text = filterDTO.MediaNo; else txtMediaNoFilter.Text = null;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            CustomerPymtTxHistoryFilterDTO filterDTO = new CustomerPymtTxHistoryFilterDTO();
            if (!string.IsNullOrWhiteSpace(drpPymtTypeFilter.Text))
            {
                filterDTO.PymtTypeId = long.Parse(drpPymtTypeFilter.Text);
                filterDTO.PymtType = drpPymtTypeFilter.SelectedItem.Text;
            }
            if (!string.IsNullOrWhiteSpace(drpPymtMethodFilter.Text))
            {
                filterDTO.PymtMethod = EnumHelper.ToEnum<PaymentMethod>(drpPymtMethodFilter.Text);
            }
            if (!string.IsNullOrWhiteSpace(txtTxRefNoFilter.Text))
            {
                filterDTO.TxRefNo = txtTxRefNoFilter.Text.TrimNullable();
            }
            if (!string.IsNullOrWhiteSpace(txtMediaNoFilter.Text))
            {
                filterDTO.MediaNo = txtMediaNoFilter.Text.TrimNullable();
            }
            setSearchFilter(filterDTO);
            loadPymtTxHistoryGrid(getSessionPageData());
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            loadPymtTxHistoryGrid(getSessionPageData());
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(CustomerPymtTxHistoryFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new CustomerPymtTxHistoryFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            CustomerPymtTxHistoryFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.PYMT_TYPE))
            {
                filterDTO.PymtTypeId = 0;
                filterDTO.PymtType = "";
            }
            else if (token.StartsWith(Constants.FILTER.PYMT_METHOD)) filterDTO.PymtMethod = null;
            else if (token.StartsWith(Constants.FILTER.TX_REF_NO)) filterDTO.TxRefNo = null;
            else if (token.StartsWith(Constants.FILTER.MEDIA_NO)) filterDTO.MediaNo = null;

            setSearchFilterTokens();
            loadPymtTxHistoryGrid(getSessionPageData());
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        CustomerPymtTxHistoryFilterDTO filterDTO = getSearchFilter();
        string filter = "";
        if (filterDTO != null)
        {
            if (filterDTO.PymtTypeId > 0) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.PYMT_TYPE + filterDTO.PymtType);
            if (filterDTO.PymtMethod != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.PYMT_METHOD + filterDTO.PymtMethod.ToString());
            if (filterDTO.TxRefNo != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.TX_REF_NO + filterDTO.TxRefNo);
            if (filterDTO.MediaNo != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.MEDIA_NO + filterDTO.MediaNo);
        }
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - PropertyUnit Search - End
    //Upload Payment Receipt Modal- start
    protected void onClickMarkReceiptDeliveredBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            recordId.Value = selectedIndex.ToString();
            txtFileName.Text = null;
            txtDeliverydate.Text = null;
            CustomerPaymentHistoryPageDTO customerPymtHistoryDTO = getSessionPageData();
            MPTHistoryUIDTO mptHistUIDTO = customerPymtHistoryDTO.PymtTransHistoryUIDTOs.Find(x => x.Id == selectedIndex);
            lbTxRefNoModal.Text = mptHistUIDTO.TxRefNo.ToString();
            activeModalHdn.Value = UploadPaymentReceiptModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private MPTReceiptDTO populateMPTReceiptDTOAdd(long MptId)
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        CustomerPaymentHistoryPageDTO PageDTO = getSessionPageData();
        MPTReceiptDTO pymtRcptDTO = new MPTReceiptDTO();
        pymtRcptDTO.PrUnitSaleDetail = new PrUnitSaleDetailDTO();
        pymtRcptDTO.PrUnitSaleDetail.Id = PageDTO.PrUnitSaleDetail.Id;
        pymtRcptDTO.MasterPymtTransaction = new MasterPymtTransactionDTO();
        pymtRcptDTO.MasterPymtTransaction.Id = MptId;
        pymtRcptDTO.UploadDate = DateUtil.getUserLocalDate();
        pymtRcptDTO.DeliveryDate = DateUtil.getCSDateNotNull(txtDeliverydate.Text);
        pymtRcptDTO.UploadBy = new FirmMemberDTO();
        pymtRcptDTO.UploadBy.Id = userDefDto.FirmMember.Id;

        pymtRcptDTO.FirmNumber = userDefDto.FirmNumber;
        pymtRcptDTO.InsertUser = userDefDto.Username;
        pymtRcptDTO.UpdateUser = userDefDto.Username;
        return pymtRcptDTO;
    }
    protected void uploadPaymentReceiptandMarkDelivered(object sender, EventArgs e)
    {
        try
        {
            CustomerPaymentHistoryPageDTO PageDTO = getSessionReceiptPageData();
            HttpFileCollection uploadedFiles = Request.Files;
            bool isSuccess = false;
            for (int i = 0; i < uploadedFiles.Count; i++)
            {
                HttpPostedFile userPostedFile = uploadedFiles[i];
                if (userPostedFile.ContentLength > 0)
                {
                	string filename = CommonUtil.getFileNameWithoutExtension(txtFileName.Text.TrimNullable(), Path.GetFileName(userPostedFile.FileName), Path.GetExtension(userPostedFile.FileName));
                    HttpPostedFile file = fileUploadPaymentReceipt.PostedFile;
                    string dlFolder = null;
                    if (validatePymtRcptUpload(userPostedFile))
                    {
                        string bookingPath = CommonUtil.appendNameToPath(Constants.DOCUMENT_MANAGEMENT.BOOKING_UNIT_DOC_PATH, PageDTO.PrUnitSaleDetail.BookingRefNo);
                        dlFolder = CommonUtil.appendNameToPath(bookingPath, Constants.DOCUMENT_MANAGEMENT.PAYMENT_RECEIPT_FOLDER);
                        documentBO.createFolderIfNotExist(bookingPath);
                        documentBO.createFolderIfNotExist(dlFolder);
                        documentBO.saveDocument(userPostedFile, CommonUtil.appendNameToPath(dlFolder, filename));
                        isSuccess = true;

                        MPTReceiptDTO receiptDTO = populateMPTReceiptDTOAdd(Convert.ToInt64(recordId.Value));
                        receiptDTO.FileName = filename;
                        receiptDTO.DocumentPath = dlFolder;

                        paymentReceiptBO.markPymtRcptDelivered(receiptDTO);
                        break;
                    }                    
                }
                else
                {
                    setErrorMessage("Please Select valid file to upload.", uploadDocumentModalError);
                    activeModalHdn.Value = uploadDocumentModalError;
                }
            }
            if (isSuccess)
            {
            	(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("Payment Receipt uploaded successfully."));
                fetchAndInitUnitPymtAndTransHistorySection(getSessionPageData());
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
        }
    }
    private bool validatePymtRcptUpload(HttpPostedFile userPostedFile)
    {
        if (userPostedFile.ContentLength > Constants.MAX_MANAGE_DOCUMENT_SIZE) {
        	int maxSize = Constants.MAX_MANAGE_DOCUMENT_SIZE / 1000000;
        	(this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(string.Format("Payment receipt must be less than {0}MB.", maxSize)));
        	return false;
        }
        return true;
    }
    protected void cancelUploadPaymentReceiptModal(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Show Pymt Rcpt Modal - Start
    protected void documentRowCreated(Object sender, GridViewRowEventArgs e)
    {
        LinkButton lnkDownloadBtn = (LinkButton)e.Row.FindControl("lnkDownloadBtn");
        if (lnkDownloadBtn != null)
        {
            ScriptManager mgr = ScriptManager.GetCurrent(this.Page);
            mgr.RegisterPostBackControl(lnkDownloadBtn);
        }
    }
    protected void showPymtReceipts(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            CustomerPaymentHistoryPageDTO PageDTO = getSessionPageData();
            MPTHistoryUIDTO mptHistUIDTO = PageDTO.PymtTransHistoryUIDTOs.Find(x => x.Id == selectedIndex);

            IList<MPTReceiptDTO> result = paymentReceiptBO.fetchPymtReceipts(mptHistUIDTO.Id);

            if(result == null) result = new  List<MPTReceiptDTO>();
            PageDTO.PymtReceiptsDTOs = new List<MPTReceiptDTO>();
            PageDTO.PymtReceiptsDTOs.AddRange(result);
            
            PymtReceiptGrid.DataSource = result;
            PymtReceiptGrid.DataBind();

            activeModalHdn.Value = ShowPymtReceiptModal;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelPymtReceiptModal(object sender, EventArgs e)
    {
        try
        {
        	CustomerPaymentHistoryPageDTO PageDTO = getSessionPageData();
        	PageDTO.PymtReceiptsDTOs = new List<MPTReceiptDTO>();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickDownloadPymtRcptBtn(object sender, EventArgs e)
    {
        try
        {
        	LinkButton rd = (LinkButton)sender;
            long selectedIndex =  long.Parse(rd.Attributes["data-pid"]);
            CustomerPaymentHistoryPageDTO PageDTO = getSessionPageData();
            MPTReceiptDTO tmpRcptDTO = PageDTO.PymtReceiptsDTOs.Find(x => x.Id == selectedIndex);
            
        	string FullPath = CommonUtil.appendNameToPath(tmpRcptDTO.DocumentPath, tmpRcptDTO.FileName);
        	byte[] fileContent = documentBO.downloadFile(FullPath);
            Response.Buffer = true;
            Response.Charset = "";
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + tmpRcptDTO.FileName);
            Response.BinaryWrite(fileContent);
            Response.Flush();
            UpdatePanel1.Update();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickDeletePymtRcptBtn(object sender, EventArgs e)
    {
        try
        {
        	long selectedIndex = getDeleteRecordHdnId();
            CustomerPaymentHistoryPageDTO PageDTO = getSessionPageData();
            MPTReceiptDTO tmpRcptDTO = PageDTO.PymtReceiptsDTOs.Find(x => x.Id == selectedIndex);
            
            paymentReceiptBO.deletePymtRcpt(tmpRcptDTO, getUserDefinitionDTO());
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotySuccessMsg("Payment Receipt deleted successfully."));
            fetchAndInitUnitPymtAndTransHistorySection(getSessionPageData());
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Show Pymt Rcpt Modal - End
 }    
    
