﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using ConstroSoft.Logic.BO;

public partial class AccountSummary : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
           log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    DropdownBO drpBO = new DropdownBO();
    FirmBO firmBO = new FirmBO();
    public enum AccountAction { ADD, MODIFY }
    string addAccountModal = "addAccountModal";
    string addAccountError = "addAccountError";

    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                FirmAccountNavDTO navDto = (FirmAccountNavDTO)Session[Constants.Session.NAV_DTO];
                Session.Remove(Constants.Session.NAV_DTO);
                Session.Remove(Constants.Session.PAGE_DATA);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(Constants.URL.DEFAULT_HOME_PAGE, false);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));

    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();

    }
    private void preRenderInitFormElements()
    {
        renderPageLayout();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpDataBase(drpAcntCountry, DrpDataType.COUNTRY, null, null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAcntState, DrpDataType.STATE, Constants.DEFAULT_COUNTRY, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAcntType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ACCOUNT_TYPE, null, userDefDto.FirmNumber);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(FirmAccountNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new FirmAccountDTO();
        initDropdowns();
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(FirmAccountNavDTO navDto)
    {
        try
        {
            loadFirmAccountSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageLayout()
    {
    }

    private FirmAccountDTO getSessionPageData()
    {
        return (FirmAccountDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<FirmAccountDTO> getSearchFirmAccountList()
    {
        return getSessionPageData().SearchResult;
    }

    private FirmAccountDTO getSearchFirmAccountDetailDTO(long Id)
    {
        List<FirmAccountDTO> searchList = getSearchFirmAccountList();
        FirmAccountDTO selectedFirmAccountDetailDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            selectedFirmAccountDetailDTO = searchList.Find(c => c.Id == Id);
        }
        return selectedFirmAccountDetailDTO;
    }
    private void loadFirmAccountSearchGrid()
    {
        FirmDTO firmDto = firmBO.fetchFirmDetails(getUserDefinitionDTO().FirmNumber);
        List<FirmAccountDTO> results = firmDto.FirmAccounts.ToList();
        setSearchGrid(results);
    }
    private void setSearchGrid(List<FirmAccountDTO> tmpList)
    {
        getSessionPageData().SearchResult = (tmpList != null) ? tmpList : new List<FirmAccountDTO>();
        AccountSummarySearchGrid.DataSource = getSearchFirmAccountList();
        AccountSummarySearchGrid.DataBind();
    }
    private FirmAccountDTO getDBFirmAccountDTO()
    {
        return getSessionPageData().SelectedFirmAccount;
    }
    private void initFirmAccountSectionFields(FirmAccountDTO firmAccountDto)
    {
        if (firmAccountDto != null) txtAcntName.Text = firmAccountDto.Name; else txtAcntName.Text = null;
        if (firmAccountDto != null) txtAcntNumber.Text = firmAccountDto.AccountNo; else txtAcntNumber.Text = null;
        if (firmAccountDto != null && firmAccountDto.IfscCode != null) txtAcntIFSCCode.Text = firmAccountDto.IfscCode.ToString(); else txtAcntIFSCCode.Text = null;
        if (firmAccountDto != null) txtAcntBankName.Text = firmAccountDto.BankName; else txtAcntBankName.Text = null;
        if (firmAccountDto != null) txtAcntBranch.Text = firmAccountDto.Branch; else txtAcntBranch.Text = null;
        if (firmAccountDto != null) drpAcntCountry.Text = firmAccountDto.Country.Id.ToString(); else drpAcntCountry.Text = null;
        if (firmAccountDto != null) drpAcntState.Text = firmAccountDto.State.Id.ToString(); else drpAcntState.Text = null;
        initCityDrp(drpAcntCity, firmAccountDto.State.Id.ToString());
        if (firmAccountDto != null) drpAcntCity.Text = firmAccountDto.City.Id.ToString(); else drpAcntCity.Text = null;
    }
    private FirmAccountDTO getSelectedFirmAccount(long UiIndex)
    {
        List<FirmAccountDTO> accountList = getDBFirmAccountDTO().FirmAccountList.ToList<FirmAccountDTO>();
        return (UiIndex > 0) ? accountList.Find(c => c.UiIndex == UiIndex) : accountList.Find(c => c.isUISelected);
    }
    protected void onClickModifyFirmAccountBtn(object sender, EventArgs e)
    {
        try
        {

            accountModalActionHdnBtn.Value = AccountAction.MODIFY.ToString();
            initAccountModalFields();
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            FirmAccountDTO firmAccountDTO = getSearchFirmAccountDetailDTO(selectedIndex);
            getSessionPageData().SelectedFirmAccount = firmAccountDTO;
            initFirmAccountSectionFields(firmAccountDTO);
            activeModalHdn.Value = addAccountModal;
            SetFocus(txtAcntName);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickFirmViewAccountSummeryBtn(object sender, EventArgs e)
    {
        try
        {
            // add code for navidate to account summery page
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }

    protected void onClickAddFirmAccountBtn(object sender, EventArgs e)
    {
    }
    //Add Account Modal - Start
    private void initAccountModalFields()
    {
        lbAccountModalTitle.Text = (AccountAction.ADD.ToString().Equals(accountModalActionHdnBtn.Value)) ? Constants.ICON.ADD + Resources.Labels.ADD_ACCOUNT : "";
        lbAccountModalTitle.Text = (AccountAction.MODIFY.ToString().Equals(accountModalActionHdnBtn.Value)) ? Constants.ICON.MODIFY + Resources.Labels.MODIFY_ACCOUNT : "";
    }
    private void initAccountSectionFields(FirmAccountDTO accountDto)
    {
        if (accountDto != null) txtAcntName.Text = accountDto.Name; else txtAcntName.Text = null;
        if (accountDto != null) drpAcntType.Text = accountDto.AccountType.Id.ToString(); else drpAcntType.ClearSelection();
        if (accountDto != null) txtAcntNumber.Text = accountDto.AccountNo; else txtAcntNumber.Text = null;
        if (accountDto != null) txtAcntIFSCCode.Text = accountDto.IfscCode; else txtAcntIFSCCode.Text = null;
        if (accountDto != null) txtAcntBankName.Text = accountDto.BankName; else txtAcntBankName.Text = null;
        if (accountDto != null) txtAcntBranch.Text = accountDto.Branch; else txtAcntBranch.Text = null;
        if (accountDto != null && accountDto.City != null) drpAcntCity.Text = accountDto.City.Id.ToString(); else drpAcntCity.ClearSelection();
        if (accountDto != null && accountDto.State != null) drpAcntState.Text = accountDto.State.Id.ToString(); else drpAcntState.ClearSelection();
        if (accountDto != null && accountDto.Country != null) drpAcntCountry.Text = accountDto.Country.Id.ToString(); else drpAcntCountry.ClearSelection();
        drpAcntState.Text = Constants.DEFAULT_STATE;
        initCityDrp(drpAcntCity, Constants.DEFAULT_STATE);
    }
    private void initCityDrp(DropDownList drp, string stateId)
    {
        drpBO.drpDataBase(drp, DrpDataType.CITY, stateId, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
    }
    private void populateAccountFromUI(FirmAccountDTO accountDto)
    {
        accountDto.Name = txtAcntName.Text;
        accountDto.AccountType = CommonUIConverter.getMasterControlDTO(drpAcntType.Text, drpAcntType.SelectedItem.Text);
        accountDto.AccountNo = txtAcntNumber.Text;
        accountDto.IfscCode = txtAcntIFSCCode.Text;
        accountDto.BankName = txtAcntBankName.Text;
        accountDto.Branch = txtAcntBranch.Text;
        accountDto.City = CommonUIConverter.getCityDTO(drpAcntCity.Text, drpAcntCity.SelectedItem.Text);
        accountDto.State = CommonUIConverter.getStateDTO(drpAcntState.Text, drpAcntState.SelectedItem.Text);
        accountDto.Country = CommonUIConverter.getCountryDTO(drpAcntCountry.Text, drpAcntCountry.SelectedItem.Text);
        accountDto.UpdateUser = getUserDefinitionDTO().Username;
    }
    private FirmAccountDTO populateAccountAdd()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        FirmAccountDTO accountDto = new FirmAccountDTO();
        populateAccountFromUI(accountDto);
        accountDto.FirmNumber = userDefDto.FirmNumber;
        accountDto.InsertUser = userDefDto.Username;
        return accountDto;
    }
    protected void onClickAddAccountBtn(object sender, EventArgs e)
    {
        try
        {
            accountModalActionHdnBtn.Value = AccountAction.ADD.ToString();
            initAccountModalFields();
            initAccountSectionFields(null);
            activeModalHdn.Value = addAccountModal;
            SetFocus(txtAcntName);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void addNewAccount(object sender, EventArgs e)
    {
        try
        {
            if (validateAccountAdd())
            {
                if (AccountAction.ADD.ToString().Equals(accountModalActionHdnBtn.Value))
                {
                    FirmAccountDTO accountDTO = populateAccountAdd();
                    firmBO.saveFirmAccount(accountDTO);
                    setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECORD_ADDED_DB_SUCCESS, "Account")));
                }
                else
                {
                    FirmAccountDTO accountDTO = getDBFirmAccountDTO();
                    populateAccountFromUI(accountDTO);
                    firmBO.updateFirmAccount(accountDTO);
                    setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECORD_MODIFY_DB_SUCCESS, "Account")));
                }
                loadFirmAccountSearchGrid();
            }
            else
            {
                activeModalHdn.Value = addAccountModal;
                SetFocus(txtAcntName);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelAccountModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void loadAcntCities(object sender, EventArgs e)
    {
        try
        {
            initCityDrp(drpAcntCity, drpAcntState.Text);
            activeModalHdn.Value = addAccountModal;
            SetFocus(drpAcntCity);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateAccountAdd()
    {
        bool isValid = true;
        Page.Validate(addAccountError);
        isValid = Page.IsValid;
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    //Add Account Modal - End
}

