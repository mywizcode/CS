﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.BO;
using CrystalDecisions.CrystalReports.Engine;

public partial class LetterGeneration : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    DropdownBO drpBO = new DropdownBO();
    PropertyBO propertyBO = new PropertyBO();
    SoldPropertyUnitBO soldUnitBO = new SoldPropertyUnitBO();
    DemandLetterBO demandLetterBO = new DemandLetterBO();
    MortguageLetterBO mortguageLetterBO = new MortguageLetterBO();
    PossessionLetterBO possessionLetterBO = new PossessionLetterBO();
    ReportConfigBO reportConfigBO = new ReportConfigBO();

    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                LetterGenerationNavDTO navDto = (LetterGenerationNavDTO)Session[Constants.Session.NAV_DTO];
                Session.Remove(Constants.Session.NAV_DTO);
                Session.Remove(Constants.Session.PAGE_DATA);
                doInit(navDto);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
    }
    private void preRenderInitFormElements()
    {
        renderPageLayout();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpEnum<SelectLettersName>(drpSelectLetter, null);        
    }
    
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(LetterGenerationNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(LetterGenerationNavDTO navDto)
    {
        try
        {
            LetterGenerationPageDTO letterGenerationPageDTO = new LetterGenerationPageDTO();
            Session[Constants.Session.PAGE_DATA] = letterGenerationPageDTO;
            pageModeHdn.Value = navDto.Mode.ToString();
            long prUnitId = navDto.PrUnitId;
            letterGenerationPageDTO.PrevNavDTO = navDto.PrevNavDto;
            letterGenerationPageDTO.UnitDTO = propertyBO.fetchPropertyUnitWithParent(prUnitId, true);
            PrUnitSaleDetailDTO prUnitSaleDetailDto = soldUnitBO.fetchPrUnitSaleDetail(getUserDefinitionDTO().FirmNumber, navDto.PrUnitSaleDetailId);
            prUnitSaleDetailDto.PropertyUnit = getSoldUnit();
            letterGenerationPageDTO.PrUnitSaleDTO = prUnitSaleDetailDto;
            populateUIFieldsFromSaleUnitDTO(getSoldUnitDetails());
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void navigateToPreviousPage()
    {
        LetterGenerationPageDTO letterGenerationPageDTO = getSessionPageData();
        if (letterGenerationPageDTO != null && letterGenerationPageDTO.PrevNavDTO != null)
        {
            object obj = letterGenerationPageDTO.PrevNavDTO;
            if (obj is SoldUnitSearchNavDTO)
            {
                SoldUnitSearchNavDTO navDTO = (SoldUnitSearchNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.SOLD_UNIT_SEARCH, true);
            }
        }
        Response.Redirect(Constants.URL.SOLD_UNIT_SEARCH, true);
    }
    private void renderPageLayout()
    {
        setPageTitle();
    }
    private void setPageTitle()
    {
        
    }
    
    private LetterGenerationPageDTO getSessionPageData()
    {
        return (LetterGenerationPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private PrUnitSaleDetailDTO getSoldUnitDetails()
    {
        return getSessionPageData().PrUnitSaleDTO;
    }
    private PropertyUnitDTO getSoldUnit()
    {
        return getSessionPageData().UnitDTO;
    }
    private void populateUIFieldsFromSaleUnitDTO(PrUnitSaleDetailDTO prUnitSaleDetailDto)
    {
        PropertyUnitDTO propertyUnitDto = prUnitSaleDetailDto.PropertyUnit;
        PropertyTowerDTO propertyTowerDto = prUnitSaleDetailDto.PropertyUnit.PropertyTower;
        populateCustomerFields(prUnitSaleDetailDto.Customer);
        populateUnitInfoSection(prUnitSaleDetailDto);
    }
    private void populateUnitInfoSection(PrUnitSaleDetailDTO prUnitSaleDetailDto)
    {
        PropertyUnitDTO propertyUnitDto = prUnitSaleDetailDto.PropertyUnit;
        PropertyTowerDTO propertyTowerDto = prUnitSaleDetailDto.PropertyUnit.PropertyTower;
        lbTowerName.Text = propertyTowerDto.Name;
        lbUnitNumber.Text = CommonUIConverter.getPropertyUnitFormattedNo(propertyUnitDto.Wing, propertyUnitDto.UnitNo);
        lbUnitType.Text = propertyUnitDto.UnitType.Name;
        lbBookingDate.Text = CommonUtil.getCSDate(prUnitSaleDetailDto.BookingDate);
    }
    private void populateCustomerFields(CustomerDTO customerDto)
    {
        lbCustomerName.Text = CommonUIConverter.getCustomerFullName(customerDto.Salutation.Name, customerDto.FirstName, customerDto.LastName);
        lbContact.Text = customerDto.ContactInfo.Contact;
        lbEmail.Text = customerDto.ContactInfo.Email;
    }
    private LetterGenerationNavDTO getCurrentPageNavigation()
    {
        PrUnitSaleDetailDTO prUnitSaleDTO = getSoldUnitDetails();
        LetterGenerationNavDTO navDTO = new LetterGenerationNavDTO();
        navDTO.Mode = EnumHelper.ToEnum<PageMode>(pageModeHdn.Value);
        navDTO.PrUnitId = prUnitSaleDTO.PropertyUnit.Id;
        navDTO.PrUnitSaleDetailId = prUnitSaleDTO.Id;
        return navDTO;
    }
    
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    
    private bool validateMandatoryFields()
    {
        bool isValid = true;
        Page.Validate(commonError);
        isValid = Page.IsValid;
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
   
    }
    public void onClickGenerateLetter(object sender, EventArgs e)
    {
        try
        {
            if(validateMandatoryFields()){
            SelectLettersName searchBy = EnumHelper.ToEnum<SelectLettersName>(drpSelectLetter.Text);
            LetterGenerationPageDTO letterGenerationPageDTO = (LetterGenerationPageDTO)Session[Constants.Session.PAGE_DATA];
            PrUnitSaleDetailDTO selectedPrUnitSaleDetailDto = letterGenerationPageDTO.PrUnitSaleDTO;
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            BusinessOutputTO businessOutputTO = null;
            ReportConfigDTO reportConfigDTO = null;
            ReportDocument letterReportDocument = new ReportDocument();
            if (SelectLettersName.DEMAND_LETTER == searchBy)
            {
                businessOutputTO = demandLetterBO.processDemandLetter(userDefDto.FirmNumber, selectedPrUnitSaleDetailDto);
                reportConfigDTO = reportConfigBO.fetchReportConfiguration(userDefDto.FirmNumber, SelectLettersName.DEMAND_LETTER.GetDescription());
            }
            else if (SelectLettersName.POSSESSION == searchBy)
            {
                businessOutputTO = possessionLetterBO.processPossessionLetter(userDefDto.FirmNumber, selectedPrUnitSaleDetailDto);
                reportConfigDTO = reportConfigBO.fetchReportConfiguration(userDefDto.FirmNumber, SelectLettersName.POSSESSION.GetDescription());
            }
            else if (SelectLettersName.MORTGUAGE == searchBy)
            {
                businessOutputTO = mortguageLetterBO.processMortguageLetter(userDefDto.FirmNumber, selectedPrUnitSaleDetailDto);
                reportConfigDTO = reportConfigBO.fetchReportConfiguration(userDefDto.FirmNumber, SelectLettersName.MORTGUAGE.GetDescription());
            }
            if (businessOutputTO.status == BusinessOutputTO.Status.FAILURE)
            {
                setErrorMessage(businessOutputTO.errorMessage, commonError);
            }
            else
            {
                string reportPath = Server.MapPath(reportConfigDTO.ReportPath);
                letterReportDocument.Load(reportPath);
                letterReportDocument.Database.Tables["DemandLetter"].SetDataSource(businessOutputTO.result);
                try
                {
                    letterReportDocument.ExportToHttpResponse
                    (CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, true,businessOutputTO.successMessage);
                }
                catch (Exception exp)
                {

                }
            }
           }
        }
        catch (Exception exp) {
            log.Error(exp.Message, exp);
            setErrorMessage(Resources.Messages.system_error, commonError);
       }
    }

}