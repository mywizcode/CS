﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initSoldUnitSearchGrid();
    formatFields();
    showModal();
}

function initSoldUnitSearchGrid() {
    var dtOptions = {
        tableId: "soldUnitSearchGrid",
        pageLength: 10,
        isViewOnly: false,
        hideSearch: false
    };
    var dtTable = applyActionDataTable(dtOptions);
    //jumpToTablePage(dtTable, "jumpToPropertyUnitHdnId");
}




