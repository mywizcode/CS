//Common Icons used 
var ICON_ADD = "<i class=\"icon-googleplus5 position-left\"></i>";
var ICON_VIEW_DTL = "<i class=\"icon-grid position-left\"></i>";
var ICON_DELETE = "<i class=\"icon-bin position-left\"></i>";
var ICON_CONFIRM = "<i class=\"icon-question4 position-left\"></i>";
var CONFIRM = "CONFIRM";
var DELETE = "DELETE";
var SEP1 = "~~";
var SEP2 = "~";
//Modal should not close when clicked on backdrop(outside modal)
$.fn.modal.prototype.constructor.Constructor.DEFAULTS.backdrop = 'static';

function initFabMenu() {
    var $fabMenu = $("[id$='fabMenuRight']");
    if ($fabMenu.length) {
        $fabMenu.affix({
            offset: {
                top: $fabMenu.offset().top - 20
            }
        });
    }
}

//Block UI -> This method blocks panel when any element (having class 'block-ui-click') is clicked.
function bindBlockUI() {
    var blockUiContent = $("<div class=\"blockui-animation-container\"><span class=\"text-semibold\"><i class=\"icon-spinner10 spinner position-left\"></i>&nbsp; Please Wait...</span></div>");
    $('.block-ui-click').on('click', function () {
        var block = $('div.' + $(this).attr('data-panel'));
        $(block).block({
            message: blockUiContent,
            overlayCSS: {
                backgroundColor: '#fff',
                opacity: 0.8,
                cursor: 'wait'
            },
            css: {
                border: 0,
                padding: '10px 15px',
                color: '#fff',
                width: 'auto',
                '-webkit-border-radius': 2,
                '-moz-border-radius': 2,
                backgroundColor: 'transparent'
            }
        });
        blockUiContent.addClass("animated fadeInDown").one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function () {
            $(this).removeClass("animated fadeInDown");
        });
    });
    $('.block-ui-change').on('change', function () {
        var block = $('div.' + $(this).attr('data-panel'));
        $(block).block({
            message: blockUiContent,
            overlayCSS: {
                backgroundColor: '#fff',
                opacity: 0.8,
                cursor: 'wait'
            },
            css: {
                border: 0,
                padding: '10px 15px',
                color: '#fff',
                width: 'auto',
                '-webkit-border-radius': 2,
                '-moz-border-radius': 2,
                backgroundColor: 'transparent'
            }
        });
        blockUiContent.addClass("animated fadeInDown").one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function () {
            $(this).removeClass("animated fadeInDown");
        });
    });
}
function initNotification() {
    var msgValue = $("[id$='NotyMsg']").val();
    if (msgValue && msgValue != "") {
        var arrMsgValue = msgValue.split(SEP1);
        $.each(arrMsgValue, function (index, value) {
        	var recs = value.split(SEP2);
        	noty({
                width: 200,
                text: recs[1],
                type: recs[0],
                dismissQueue: true,
                timeout: 6000,
                layout: 'top'
            });
        });
    }
    $("[id$='NotyMsg']").val('');
}

function ValidateNumberOnly(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 46 || charCode > 57)) {
        event.returnValue = false;
    }
}