﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;
using ConstroSoft.Logic.BO;

public partial class PropertyFundSearch : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string SearchFilterModal = "SearchFilterModal";
    DropdownBO drpBO = new DropdownBO();
    PropertyFundsBO propertyFundsBO = new PropertyFundsBO();

    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                PropertyFundSearchNavDTO navDto = (PropertyFundSearchNavDTO)Session[Constants.Session.NAV_DTO];
                Session.Remove(Constants.Session.NAV_DTO);
                Session.Remove(Constants.Session.PAGE_DATA);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(Constants.URL.DEFAULT_HOME_PAGE, false);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg)
    {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();

    }
    private void preRenderInitFormElements()
    {
        renderPageLayout();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        drpBO.drpEnum<PaymentMethod>(drpPaymentMethodFilter, null);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit(PropertyFundSearchNavDTO navDto)
    {
        Session[Constants.Session.PAGE_DATA] = new PropertyFundSearchPageDTO();
        initDropdowns();
        setSearchFilter(null);
        initPageAfterRedirect(navDto);
    }
    private void initPageAfterRedirect(PropertyFundSearchNavDTO navDto)
    {
        try
        {
            if (navDto != null)
            {
                setSearchFilter(navDto.filterDTO);
            }
            loadPropertyFundSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void renderPageLayout()
    {
    }
    private void setSearchGrid(IList<PropertyFundsDTO> tmpList)
    {
        getSessionPageData().SearchResult = (tmpList != null) ? tmpList.ToList<PropertyFundsDTO>() : new List<PropertyFundsDTO>();
        propertyFundSearchGrid.DataSource = getSearchPropertyFundList();
        propertyFundSearchGrid.DataBind();
    }
    private PropertyFundSearchPageDTO getSessionPageData()
    {
        return (PropertyFundSearchPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<PropertyFundsDTO> getSearchPropertyFundList()
    {
        return getSessionPageData().SearchResult;
    }
    private PropertyFundsDTO getSearchPropertyFundDTO(long Id)
    {
        List<PropertyFundsDTO> searchList = getSearchPropertyFundList();
        PropertyFundsDTO selectedPropertyFundDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            selectedPropertyFundDTO = searchList.Find(c => c.Id == Id);
        }
        return selectedPropertyFundDTO;
    }
    private void loadPropertyFundSearchGrid()
    {
        PropertyDTO property = CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO());
        IList<PropertyFundsDTO> results = propertyFundsBO.fetchAccountDepositGridData(getUserDefinitionDTO().FirmNumber, property.Id);
        setSearchGrid(results);
    }
    private void navigateToPropertyFundDetails(long selectedId, PageMode mode)
    {
        //PropertyFundsDTO propertyFundsDTO = getSearchPropertyFundDTO(selectedId);
        //PropertyFundDetailNavDTO navDTO = new PropertyFundDetailNavDTO();
        //navDTO.Mode = mode;
        //navDTO.propertyFundId = propertyFundsDTO.Id;
        //PropertyFundSearchNavDTO searchNavDTO = new PropertyFundSearchNavDTO();
        //searchNavDTO.filterDTO = getSearchFilter();
        //navDTO.PrevNavDto = searchNavDTO;
        //Session[Constants.Session.NAV_DTO] = navDTO;
        //Response.Redirect(Constants.URL.SOLD_UNIT_DETAILS, true);
    }
    protected void onClickViewPropertyFundBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            navigateToPropertyFundDetails(selectedId, PageMode.VIEW);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyPropertyFundBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            long selectedId = long.Parse(rd.Attributes["data-pid"]);
            navigateToPropertyFundDetails(selectedId, PageMode.MODIFY);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickCancelBookingBtn(object sender, EventArgs e)
    {
        try
        {
            EnquiryActivityHistoryNavDTO navDTO = new EnquiryActivityHistoryNavDTO();
            navDTO.EnquiryId = 2;
            Session[Constants.Session.NAV_DTO] = navDTO;
            Response.Redirect(Constants.URL.ENQUIRY_ACTIVITY_HISTORY, true);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickAddPropertyFundBtn(object sender, EventArgs e)
    {
        try
        {
            //initPageInfo(CustomerPageMode.ADD);
            //fetchSelectedCustomer(0);
            //populateUIFieldsFromDTO(getDBCustomerDTO());
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void deletePropertyFund(object sender, EventArgs e)
    {
        try
        {
            //long selectedId = getDeleteRecordHdnId();
            //customerBO.deleteCustomer(selectedId);
            //initPageInfo(CustomerPageMode.NONE);
            //loadCustomerSearchGrid();
            //setSuccessMessage(CommonUtil.getRecordDeleteSuccessMsg("Customer"));
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Filter Criteria - Property Search - Start
    private PropertyFundFilterDTO getSearchFilter()
    {
        return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            PropertyFundFilterDTO filterDTO = getSearchFilter();
            if (filterDTO.AccountName != null) txtAccountNameFilter.Text = filterDTO.AccountName; else txtAccountNameFilter.Text = null;
            if (filterDTO.PymtMethod != null) drpPaymentMethodFilter.Text = filterDTO.PymtMethod.ToString(); else drpPaymentMethodFilter.ClearSelection();
            if (filterDTO.MediaNo != null) txtMediaNoFilter.Text = filterDTO.MediaNo; else txtMediaNoFilter.Text = null;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            PropertyFundFilterDTO filterDTO = new PropertyFundFilterDTO();
            if (!string.IsNullOrWhiteSpace(txtAccountNameFilter.Text))
            {
                filterDTO.AccountName = txtAccountNameFilter.Text;
            }
            if (!string.IsNullOrWhiteSpace(drpPaymentMethodFilter.Text))
            {
                filterDTO.PymtMethod = EnumHelper.ToEnum<PaymentMethod>(drpPaymentMethodFilter.SelectedItem.Text);
            }
            if (!string.IsNullOrWhiteSpace(txtMediaNoFilter.Text))
            {
                filterDTO.MediaNo = txtMediaNoFilter.Text;
            }
            setSearchFilter(filterDTO);
            loadPropertyFundSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            loadPropertyFundSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(PropertyFundFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new PropertyFundFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {
           // drpTowerFilter.Text = CommonUtil.getStickyPrTowerDTO(getUserDefinitionDTO()).Id.ToString();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            PropertyFundFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.ACCOUNT_NAME))  filterDTO.AccountName = null;
            else if (token.StartsWith(Constants.FILTER.PYMT_METHOD)) filterDTO.PymtMethod = null;
            else if (token.StartsWith(Constants.FILTER.MEDIA_NO)) filterDTO.PymtMethod = null;
            setSearchFilterTokens();
            loadPropertyFundSearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        PropertyFundFilterDTO filterDTO = getSearchFilter();
        string filter = null;
        if (filterDTO != null)
        {
            if (filterDTO.AccountName != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.ACCOUNT_NAME + filterDTO.AccountName);
            if (filterDTO.PymtMethod != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.PYMT_METHOD + filterDTO.PymtMethod);
            if (filterDTO.MediaNo != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.MEDIA_NO + filterDTO.MediaNo);
        }
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - Property Fund Search - End
}
