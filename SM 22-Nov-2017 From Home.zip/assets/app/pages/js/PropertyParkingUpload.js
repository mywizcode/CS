﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initPropertyParkingUploadGrid();
    formatFields();
    showModal();
}
function initPropertyParkingUploadGrid() {
    var dtOptions = {
        hasActionColumn: false,
        rowInfoModalTitle: "Parking Details",
        pageLength: 10
    };

    $("[id$='parkingUploadGrid']").CSBasicDatatable(dtOptions);
}


