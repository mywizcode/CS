﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initPropertySearchGrid();
    formatFields();
    showModal();
}

function initPropertySearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#propertySearchBtnDiv",
        pageLength: 10
    };
    
    $("[id$='propertySearchGrid']").CSBasicDatatable(dtOptions);
}




