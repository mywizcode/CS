﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initUnitSearchGrid();
    formatFields();
    showModal();
}

function initUnitSearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#propertyUnitSearchBtnDiv",
        pageLength: 10
    };

    $("[id$='propertyUnitSearchGrid']").CSBasicDatatable(dtOptions);
}




