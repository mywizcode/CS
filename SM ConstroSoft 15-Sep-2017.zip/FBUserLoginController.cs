﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ConstroSoft
{
    public class FBUserLoginController : ApiController
    {
        [HttpPost]
        [ActionName("LoginUser")]
        public string LoginUser([FromBody]FBUserDTO fBUserDTO)
        {
            FBIntegrationBO fBIntegrationBO = new FBIntegrationBO();
            List<string> responseJson = new List<string>();
            var response = JsonConvert.SerializeObject("Failure");
            string tokenKey;
            if (fBUserDTO != null)
            {
                string errorMessage = fBIntegrationBO.validateLoginUser(fBUserDTO);
                if (errorMessage == null)
                {
                    BusinessOutputTO outputTO = fBIntegrationBO.validateFBUser(fBUserDTO);
                    if (BusinessOutputTO.Status.SUCCESS.Equals(outputTO.status))
                    {
                        fBUserDTO = (FBUserDTO)outputTO.result;
                        tokenKey = fBIntegrationBO.saveFBToken(fBUserDTO);
                        responseJson.Add("User log in successfully for " + fBUserDTO.UserName);
                        responseJson.Add(" Token: " + tokenKey);
                        responseJson.Add(" Token Expiry: 1800000");
                        response = JsonConvert.SerializeObject(responseJson);
                    }
                    else
                    {
                        response = JsonConvert.SerializeObject(outputTO.errorMessage);
                    }

                }
                else
                {
                    response = JsonConvert.SerializeObject(errorMessage);
                }
            }
            return response;
        }
    }
}