﻿using ConstroSoft.Logic.BO;
using CrystalDecisions.CrystalReports.Engine;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ConstroSoft.pages.Reports
{
    public partial class PaymentScheduleRepor : System.Web.UI.Page
    {
        DropdownBO drpBO = new DropdownBO();
        string tab1ValidationGrp = "tab2BzStep1Error";
        PaymentScheduleReportBO propertyScheduleReport = new PaymentScheduleReportBO();
        PropertyBO propertyBO = new PropertyBO();
        ReportConfigBO reportConfigBO = new ReportConfigBO();
        SoldPropertyUnitBO soldUnitBO = new SoldPropertyUnitBO();
        string VS_PROPERTY_UNIT_LIST = "PROPERTY_UNIT_LIST";
        string VS_PROPERTY_SCHEDULE_LIST = "PROPERTY_SCHEDULE_LIST";
        private static readonly log4net.ILog log =
             log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (CommonUtil.isSessionActive(Session))
                {
                    Session["Letter"] = null;
                    initDropdowns();
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
            PaymentScheduleReportViewer.ReportSource = (ReportDocument)Session["Letter"];
            PaymentScheduleReportViewer.RefreshReport();
            PaymentScheduleReportViewer.DataBind();
        }
        private List<PrUnitSaleDetailDTO> getCurrentGridSoldUnits()
        {
            return (List<PrUnitSaleDetailDTO>)ViewState[VS_PROPERTY_UNIT_LIST];
        }
        private void initDropdowns()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            drpBO.drpDataBase(drpSelectProperty, DrpDataType.PROPERTY_NAME, userDefDto.Id.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
        }
        

        protected void onSelectProperty(object sender, EventArgs e)
        {
            drpSelectPropertyTower.Visible = true;
            lblPropertyTower.Visible = true;
            drpBO.drpDataBase(drpSelectPropertyTower, DrpDataType.PROPERTY_TOWER, drpSelectProperty.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            
            
        }
        private UserDefinitionDTO getUserDefinitionDTO()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }
        protected void onSelectPropertyTower(object sender, EventArgs e)
        {

            drpUnitNumber.Visible = true;
            lblUnitNumber.Visible = true;
            drpBO.drpDataBase(drpUnitNumber, DrpDataType.PR_UNIT_SEARCH_BY_UNITNO, drpSelectPropertyTower.Text, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            
        }
        private void fetchSoldUnits(long Id)
        {
            try
            {
                PrUnitSaleDetailDTO results = new PrUnitSaleDetailDTO();
                if (!(string.IsNullOrWhiteSpace(drpSelectProperty.Text) || string.IsNullOrWhiteSpace(drpSelectPropertyTower.Text) || string.IsNullOrWhiteSpace(drpUnitNumber.Text)))
                {
                    long propertyId = long.Parse(drpSelectProperty.Text);
                    long towerId = long.Parse(drpSelectPropertyTower.Text);
                    long unitId = long.Parse(drpUnitNumber.Text);
                    results = propertyScheduleReport.fetchSoldPropertyUnits(getUserDefinitionDTO().FirmNumber, unitId);

                    ViewState[VS_PROPERTY_UNIT_LIST] = results;
                    if (results != null)
                    {
                        LoadReport();
                    }                   
                    else
                    {
                       setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Property Unit is not Sold"), tab1ValidationGrp);
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                throw exp;
            }
        }
        public void setErrorMessage(string message, string group)
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }
        private List<PropertyScheduleDTO> getPropertyScheduleList()
        {
            return (List<PropertyScheduleDTO>)ViewState[VS_PROPERTY_SCHEDULE_LIST];
        }

        private void loadPropertySchedule()
        {
            try
            {
                List<PropertyScheduleDTO> results = new List<PropertyScheduleDTO>();
                if (!(string.IsNullOrWhiteSpace(drpSelectProperty.Text) || string.IsNullOrWhiteSpace(drpSelectPropertyTower.Text)))
                {
                    long towerId = long.Parse(drpSelectPropertyTower.Text);
                    results = propertyBO.fetchPropertySchedule(getUserDefinitionDTO().FirmNumber, towerId);                   
                }
                
                ViewState[VS_PROPERTY_SCHEDULE_LIST] = results;               
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        public void LoadReport()
        {
            try
            {
                PrUnitSaleDetailDTO selectedPrUnitSaleDetailDto = (PrUnitSaleDetailDTO) ViewState[VS_PROPERTY_UNIT_LIST];
                loadPropertySchedule();
                IList<PropertyScheduleDTO> selectedPrpaymtScheduleDto = (IList<PropertyScheduleDTO>)ViewState[VS_PROPERTY_SCHEDULE_LIST];
                UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
                BusinessOutputTO businessOutputTO = null;
                ReportConfigDTO reportConfigDTO = null;
                ReportDocument letterReportDocument = new ReportDocument();
                businessOutputTO = propertyScheduleReport.processPaymentScheduleLetter(userDefDto.FirmNumber, selectedPrUnitSaleDetailDto, selectedPrpaymtScheduleDto, long.Parse(drpSelectProperty.Text), drpUnitNumber.SelectedItem.Text);
                reportConfigDTO = reportConfigBO.fetchReportConfiguration(userDefDto.FirmNumber, "Payment Forecast Report");
                if (businessOutputTO.status == BusinessOutputTO.Status.SUCCESS)
                {
                    string reportPath = Server.MapPath(reportConfigDTO.ReportPath);                      
                    letterReportDocument.Load(reportPath);
                    letterReportDocument.Database.Tables["SoldProperyDetails"].SetDataSource(businessOutputTO.resultList[0]);
                    letterReportDocument.Database.Tables["PropertyStageDetails"].SetDataSource(businessOutputTO.resultList[1]);
                    Session["Letter"] = letterReportDocument;
                    PaymentScheduleReportViewer.ReportSource = letterReportDocument;
                }


            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                throw exp;
            }
        }
        
        protected void Page_PreRender(object sender, EventArgs e)
        {
            if (Session[Constants.Session.USERNAME] != null)
            {
                initBootstrapComponantsFromServer();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        private bool isViewOnlyUser()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            bool isViewOnlyUser = !CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.FIRM_MEMBER_ADD_UPDATE);
            return isViewOnlyUser;
        }
        protected void GenerateReport(object sender, EventArgs e)
        {
            fetchSoldUnits(0);
        }
        public void initBootstrapComponantsFromServer()
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
        }
    }
}