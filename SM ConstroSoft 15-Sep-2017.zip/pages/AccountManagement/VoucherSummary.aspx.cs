﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft.Logic.BO;
using Vladsm.Web.UI.WebControls;
using ConstroSoft.Logic.Util;


namespace ConstroSoft.pages.AccountManagement
{
    public partial class VoucherSummary : System.Web.UI.Page
    {
        private static readonly log4net.ILog log =
              log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string tab1ValidationGrp = "tab1Error";
        string VS_VOUCHER_LIST = "VOUCHER_LIST";
        string VS_SELECTED_VOUCHER = "SELECTED_VOUCHER";

        DropdownBO drpBO = new DropdownBO();
        PaymentVoucherBO paymentVoucherBO = new PaymentVoucherBO();

        TallyIntegratorBO tallyIntegratorBO = new TallyIntegratorBO();
        MasterDataBO masterDataBO = new MasterDataBO();

        public enum VoucherPageMode { VIEW, NONE }

        protected void Page_Load(object sender, EventArgs e)
        {
            Page.Form.Attributes.Add("enctype", "multipart/form-data");
            clearMessages();
            if (!IsPostBack)
            {
                if (CommonUtil.isSessionActive(Session))
                {
                    resetTabInfo(VoucherPageMode.NONE);
                    initDropdowns();

                    Page.MaintainScrollPositionOnPostBack = false;
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
        }
        private void initDropdowns()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            drpBO.drpEnum<PaymentVoucherSearchBy>(drpSearchBy, null);
        }
        /**
         * This method is called just before the page is rendered. So any change in state of the element is applied.
         **/
        protected void Page_PreRender(object sender, EventArgs e)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                applyEntitlement();
                preRenderInitFormElements();
                initBootstrapComponantsFromServer();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        private void applyEntitlement()
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            lnkPostVoucherBtn.Visible = true;//CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.VOUCHER_POST);
            //lnkPostAllVoucherBtn.Visible = true;//CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.VOUCHER_POST_ALL);
        }
        private void preRenderInitFormElements()
        {
            PaymentVoucherDTO selectedVoucher = getSelectedVoucher();
            jumpToVoucherHdnId.Value = null;
            if (selectedVoucher != null)
            {
                jumpToVoucherHdnId.Value = selectedVoucher.Id.ToString();
            }
        }
        public void setErrorMessage(string message, string group)
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }

        public void setSuccessMessage(string msg, string tabId)
        {
            activeTabHdn.Value = tabId;
            if (tabId.Equals(tab1Anchor.ID))
            {
                lbTab1Success.Text = msg;
                tab1SuccessPanel.Visible = true;
            }
        }
        public void initBootstrapComponantsFromServer()
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
        }
        private void clearMessages()
        {
            tab1SuccessPanel.Visible = false;
            lbTab1Success.Text = "";
        }
        private UserDefinitionDTO getUserDefinitionDTO()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }

        private void resetTabInfo(VoucherPageMode pageMode)
        {
            //tab2Anchor.Visible = true;
            //activeTabHdn.Value = tab2Anchor.ID;
            pageModeHdn.Value = pageMode.ToString();
            initFormFields();

            if (VoucherPageMode.VIEW == pageMode)
            {
                //tab2Anchor.Text = Resources.Labels.empm_sm_manage_propertyUnit_tab2_view_name;
                initFormFields();
            }
            else
            {
                activeTabHdn.Value = tab1Anchor.ID;
                //tab2Anchor.Visible = false;
                //tab3Anchor.Visible = false;
                ViewState[VS_SELECTED_VOUCHER] = null;
            }
        }
        private void initFormFields()
        {
            bool isReadOnly = (VoucherPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            bool visible = !(VoucherPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
        }
        private List<PaymentVoucherDTO> getVoucherList()
        {
            return (List<PaymentVoucherDTO>)ViewState[VS_VOUCHER_LIST];
        }
        private PaymentVoucherDTO getCurrentVoucher()
        {
            return (PaymentVoucherDTO)ViewState[VS_SELECTED_VOUCHER];
        }
        private PaymentVoucherDTO getSelectedVoucher()
        {
            PaymentVoucherDTO selectedVoucherDto = null;
            List<PaymentVoucherDTO> propertyVoucherList = getVoucherList();
            if (propertyVoucherList != null && propertyVoucherList.Count != 0)
            {
                selectedVoucherDto = propertyVoucherList.Find(c => c.isUISelected);
            }
            return selectedVoucherDto;
        }
        private void setSelectedVoucher(long selectedId)
        {
            List<PaymentVoucherDTO> propertyVoucherList = getVoucherList();
            if (propertyVoucherList != null && propertyVoucherList.Count != 0)
            {
                propertyVoucherList.ForEach(c => c.isUISelected = false);
                if (selectedId > 0) propertyVoucherList.Find(c => c.Id == selectedId).isUISelected = true;
            }
        }
        private void selectVoucherGridRdBtn(long uiIndex)
        {
            if (voucherGrid.Rows.Count > 0)
            {
                setSelectedVoucher(0);
                foreach (GridViewRow row in voucherGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdVoucherSelect");
                    radioBtn.Checked = false;
                    if (uiIndex > 0)
                    {
                        Button rowIdenBtn = (Button)row.FindControl("btnVoucherRowIdentifier");
                        if (rowIdenBtn != null && uiIndex.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                        {
                            radioBtn.Checked = true;
                            setSelectedVoucher(uiIndex);
                        }
                    }
                }
            }
        }
        private void assignUiIndexToVoucher(List<PaymentVoucherDTO> voucherDtos)
        {
            if (voucherDtos != null && voucherDtos.Count > 0)
            {
                voucherDtos.ForEach(c => c.isUISelected = false);
                long uiIndex = 1;
                foreach (PaymentVoucherDTO paymentVoucherDto in voucherDtos)
                {
                    paymentVoucherDto.UiIndex = uiIndex++;
                    paymentVoucherDto.RowInfo = CommonUIConverter.getGridViewRowInfo(paymentVoucherDto);
                }
            }
        }
        private void loadSearchGridAndReSelect(long Id)
        {
            try
            {
                PaymentVoucherSearchBy searchBy = EnumHelper.ToEnum<PaymentVoucherSearchBy>(drpSearchBy.Text);
                object searchByValue = null;
                if (!string.IsNullOrWhiteSpace(drpSearchByValue.Text))
                {
                    if (PaymentVoucherSearchBy.VOUCHER_TYPE == searchBy) searchByValue = EnumHelper.ToEnum<VoucherType>(drpSearchByValue.Text);
                    if (PaymentVoucherSearchBy.ACTION == searchBy) searchByValue = EnumHelper.ToEnum<Action>(drpSearchByValue.Text);
                    if (PaymentVoucherSearchBy.POSTING_STATUS == searchBy) searchByValue = EnumHelper.ToEnum<TallyPostingStatus>(drpSearchByValue.Text);
                    else searchByValue = drpSearchByValue.Text;
                }
                IList<PaymentVoucherDTO> results = paymentVoucherBO.fetchPaymentVoucherGridData(getUserDefinitionDTO().FirmNumber, searchBy, searchByValue);
                ViewState[VS_VOUCHER_LIST] = results;
                voucherGrid.DataSource = results;
                voucherGrid.DataBind();
                if (Id > 0)
                {
                    selectVoucherGridRdBtn(Id);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void fetchSelectedVoucherList()
        {
            try
            {
                PaymentVoucherDTO paymentVoucherDTO = null;
                if (VoucherPageMode.VIEW.ToString().Equals(pageModeHdn.Value))
                {
                    long Id = getVoucherList().Find(c => c.isUISelected).Id;
                    paymentVoucherDTO = null;//propertyUnitManagementBO.fetchPropertyUnitDetails(Id);
                }
                ViewState[VS_SELECTED_VOUCHER] = paymentVoucherDTO;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void doViewModifyAction(VoucherPageMode pageMode)
        {
            resetTabInfo(pageMode);
            fetchSelectedVoucherList();
            PaymentVoucherDTO paymentVoucherDTO = getCurrentVoucher();
            // populateUIFieldsFromDTO(paymentVoucherDTO);
        }

        protected void onSearchBy(object sender, EventArgs e)
        {
            try
            {
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                PaymentVoucherSearchBy searchBy = EnumHelper.ToEnum<PaymentVoucherSearchBy>(drpSearchBy.Text);
                drpSearchByValue.Visible = true;
                lbSearchByValue.Visible = true;
                lnkPostAllVoucherBtn.Visible = true;
                lbSearchByValue.Text = EnumHelper.GetEnumDescription<PaymentVoucherSearchBy>(searchBy.ToString());
                pnlVoucherGrid.Visible = true;
                if (PaymentVoucherSearchBy.VOUCHER_TYPE == searchBy)
                {
                    drpBO.drpEnum<VoucherType>(drpSearchByValue, Constants.SELECT_ITEM);
                }
                else if (PaymentVoucherSearchBy.POSTING_STATUS == searchBy)
                {
                    drpBO.drpEnum<TallyPostingStatus>(drpSearchByValue, Constants.SELECT_ITEM);
                }
                else if (PaymentVoucherSearchBy.ACTION == searchBy)
                {
                    drpBO.drpEnum<Action>(drpSearchByValue, Constants.SELECT_ITEM);
                }
                else
                {
                    drpSearchByValue.ClearSelection();
                    drpSearchByValue.Visible = false;
                    lbSearchByValue.Visible = false;
                    lnkPostAllVoucherBtn.Visible = false;
                }
                loadSearchGridAndReSelect(0);
                resetTabInfo(VoucherPageMode.NONE);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onSearchByValue(object sender, EventArgs e)
        {
            loadSearchGridAndReSelect(0);
            resetTabInfo(VoucherPageMode.NONE);
        }
        protected void selectVoucher(object sender, EventArgs e)
        {
            try
            {
                GroupRadioButton rd = (GroupRadioButton)sender;
                resetTabInfo(VoucherPageMode.NONE);
                if (rd.Checked)
                {
                    string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnVoucherRowIdentifier"))).Attributes["row-identifier"];
                    setSelectedVoucher(long.Parse(strId));
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }


        protected void onClickViewVoucherBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateVoucherSelected())
                {
                    //doViewModifyAction(VoucherPageMode.VIEW);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickPostVoucherBtn(object sender, EventArgs e)
        {
            try
            {
                if (validateVoucherSelected())
                {
                    PaymentVoucherDTO paymentVoucherDTO = getVoucherList().Find(c => c.isUISelected);
                    if (paymentVoucherDTO != null && paymentVoucherDTO.PostingStatus.Equals("Pending"))
                    {
                        IList<PaymentVoucherDTO> resultdtos = new List<PaymentVoucherDTO>();
                        resultdtos.Add(paymentVoucherDTO);
                        postVouchersTally(resultdtos);
                    }
                    else
                    {
                        resetTabInfo(VoucherPageMode.NONE);
                        setErrorMessage(Resources.Messages.Validation_voucher_posted, tab1ValidationGrp);
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickPostAllVoucherBtn(object sender, EventArgs e)
        {
            try
            {
                IList<PaymentVoucherDTO> resultdtos = getVoucherList().FindAll(el => el.PostingStatus == "Pending");
                if (resultdtos != null && resultdtos.Count > 0)
                {
                    postVouchersTally(resultdtos);
                }
                else
                {
                    resetTabInfo(VoucherPageMode.NONE);
                    setErrorMessage(Resources.Messages.Validation_voucher_posted, tab1ValidationGrp);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        private void postVouchersTally(IList<PaymentVoucherDTO> resultdtos)
        {
            try
            {
                IList<PaymentVoucherDTO> results = new List<PaymentVoucherDTO>();
                foreach (PaymentVoucherDTO paymentVoucherDTO in resultdtos)
                {
                    PaymentVoucherDTO paymentVoucherDTOFromDB = paymentVoucherBO.fetchPaymentVoucher(paymentVoucherDTO.Id);
                    results.Add(paymentVoucherDTOFromDB);
                }
                tallyIntegratorBO.processTallyRequest(getUserDefinitionDTO().FirmNumber, results);
                resetTabInfo(VoucherPageMode.NONE);
                setSuccessMessage(Resources.Messages.success_record_posted, tab1ValidationGrp);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        private bool validateVoucherSelected()
        {
            bool isSelected = true;
            List<PaymentVoucherDTO> voucherList = getVoucherList();
            if (voucherList != null)
            {
                isSelected = voucherList.Any(c => c.isUISelected);
                if (!isSelected)
                {
                    resetTabInfo(VoucherPageMode.NONE);
                    setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Payment Voucher"), tab1ValidationGrp);
                }
            }
            return isSelected;
        }

    }
}