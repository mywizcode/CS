﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft.Logic.BO;
using NHibernate;
using Vladsm.Web.UI.WebControls;
using OfficeOpenXml;
using OfficeOpenXml.DataValidation;
using OfficeOpenXml.Style;
using System.IO;
using System.Drawing;
using ConstroSoft.Logic.Util;
using System.Text;


namespace ConstroSoft.pages.PropertyUnitManagement
{
    public partial class PropertyUnitManagement : System.Web.UI.Page
    {
        private static readonly log4net.ILog log =
              log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string tab1ValidationGrp = "tab1Error";
        string tab2ValidationGrp = "tab2Error";
        string tab3ValidationGrp = "tab3Error";
        string VS_PROPERTYUNIT_LIST = "PROPERTYUNIT_LIST";
        string VS_SELECTED_PROPERTYUNIT = "SELECTED_PROPERTYUNIT";
        string VS_PROPERTYUPLOADUNIT_LIST = "UPLOADED_PROPERTYUNIT";
        DropdownBO drpBO = new DropdownBO();
        PropertyUnitManagementBO propertyUnitManagementBO = new PropertyUnitManagementBO();
        MasterDataBO masterDataBO = new MasterDataBO();

        public enum PrUnitPageMode { ADD, MODIFY, VIEW, NONE, UPLOAD }
        protected void Page_Load(object sender, EventArgs e)
        {
            Page.Form.Attributes.Add("enctype", "multipart/form-data");
            clearMessages();
            if (!IsPostBack)
            {
                if (CommonUtil.isSessionActive(Session))
                {
                    resetTabInfo(PrUnitPageMode.NONE);
                    initDropdowns();

                    Page.MaintainScrollPositionOnPostBack = false;
                }
                else
                {
                    Response.Redirect(Constants.URL.LOGIN, false);
                }
            }
        }
        private void initDropdowns()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            drpBO.drpDataBase(drpSearchProperty, DrpDataType.PROPERTY_NAME, userDefDto.Id.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpSearchTower, DrpDataType.PROPERTY_TOWER, drpSearchProperty.Text, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpUnitType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpDirection, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_DIRECTION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpDataBase(drpfacing, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_FACING, Constants.SELECT_ITEM, userDefDto.FirmNumber);
            drpBO.drpEnum<PRUnitStatus>(drpStatus, Constants.SELECT_ITEM);
            drpBO.drpEnum<PropertyUnitSearchBy>(drpSearchBy, null);
        }
        /**
         * This method is called just before the page is rendered. So any change in state of the element is applied.
         **/
        protected void Page_PreRender(object sender, EventArgs e)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                applyEntitlement();
                preRenderInitFormElements();
                initBootstrapComponantsFromServer();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        private void applyEntitlement()
        {
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            lnkAddPropertyUnitBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_UNIT_ADD);
            lnkModifyPropertyUnitBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_UNIT_MODIFY);
            lnkDeletePropertyunitBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_UNIT_DELETE);
            lnkPropertyunitDownloadBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_UNIT_ADD);
            lnkPropertyunitUploadBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_UNIT_ADD);
        }
        private void preRenderInitFormElements()
        {
            PropertyUnitDTO selectedPropertyUnit = getSelectedPropertyUnit();
            jumpToPropertyUnitHdnId.Value = null;
            if (selectedPropertyUnit != null)
            {
                jumpToPropertyUnitHdnId.Value = selectedPropertyUnit.Id.ToString();
            }
        }
        public void setErrorMessage(string message, string group)
        {
            CustomValidator val = new CustomValidator();
            val.IsValid = false;
            val.ErrorMessage = message;
            val.ValidationGroup = group;
            this.Page.Validators.Add(val);
        }

        public void setSuccessMessage(string msg, string tabId)
        {
            activeTabHdn.Value = tabId;
            if (tabId.Equals(tab1Anchor.ID))
            {
                lbTab1Success.Text = msg;
                tab1SuccessPanel.Visible = true;
            }
            else if (tabId.Equals(tab2Anchor.ID))
            {
                lbTab2Success.Text = msg;
                tab2SuccessPanel.Visible = true;
            }
            else if (tabId.Equals(tab3Anchor.ID))
            {
                lbTab3Success.Text = msg;
                tab3SuccessPanel.Visible = true;
            }
        }
        public void initBootstrapComponantsFromServer()
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
        }
        private void clearMessages()
        {
            tab1SuccessPanel.Visible = false;
            lbTab1Success.Text = "";
            tab2SuccessPanel.Visible = false;
            lbTab2Success.Text = "";
        }
        private UserDefinitionDTO getUserDefinitionDTO()
        {
            return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        }

        private void resetTabInfo(PrUnitPageMode pageMode)
        {
            tab2Anchor.Visible = true;
            activeTabHdn.Value = tab2Anchor.ID;
            pageModeHdn.Value = pageMode.ToString();
            initFormFields();

            if (PrUnitPageMode.ADD == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.empm_sm_manage_propertyUnit_tab2_add_name;
                initFormFields();
            }
            else if (PrUnitPageMode.MODIFY == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.empm_sm_manage_propertyUnit_tab2_update_name;
                initFormFields();
            }
            else if (PrUnitPageMode.VIEW == pageMode)
            {
                tab2Anchor.Text = Resources.Labels.empm_sm_manage_propertyUnit_tab2_view_name;
                initFormFields();
            }
            else if (PrUnitPageMode.UPLOAD == pageMode)
            {
                tab2Anchor.Visible = false;
                tab3Anchor.Visible = true;
                tab3SuccessPanel.Visible = false;
                activeTabHdn.Value = tab3Anchor.ID;
                unitUploadGrid.DataSource = null;
                unitUploadGrid.DataBind();
                initFormFields();
            }
            else
            {
                activeTabHdn.Value = tab1Anchor.ID;
                tab2Anchor.Visible = false;
                tab3Anchor.Visible = false;
                ViewState[VS_SELECTED_PROPERTYUNIT] = null;
            }
        }
        private void initFormFields()
        {
            bool isReadOnly = (PrUnitPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            bool visible = !(PrUnitPageMode.VIEW.ToString().Equals(pageModeHdn.Value));
            //Buttons
            btnAddSubmit.Visible = visible;
            addUnitTypeBtn.Visible = visible;
            addDirectionBtn.Visible = visible;
            addFacingBtn.Visible = visible;

            bool isAdd = (PrUnitPageMode.ADD.ToString().Equals(pageModeHdn.Value));
            txtWing.ReadOnly = !isAdd;
            txtFloorNo.ReadOnly = !isAdd;
            txtunitNo.ReadOnly = !isAdd;
        }
        private List<PropertyUnitDTO> getPropertyUnitList()
        {
            return (List<PropertyUnitDTO>)ViewState[VS_PROPERTYUNIT_LIST];
        }
        private PropertyUnitDTO getCurrentPropertyUnit()
        {
            return (PropertyUnitDTO)ViewState[VS_SELECTED_PROPERTYUNIT];
        }
        private PropertyUnitDTO getSelectedPropertyUnit()
        {
            PropertyUnitDTO selectedUnitDto = null;
            List<PropertyUnitDTO> propertyUnitList = getPropertyUnitList();
            if (propertyUnitList != null && propertyUnitList.Count != 0)
            {
                selectedUnitDto = propertyUnitList.Find(c => c.isUISelected);
            }
            return selectedUnitDto;
        }
        private List<PropertyUnitDTO> getPropertyUnitUploadList()
        {
            return (List<PropertyUnitDTO>)ViewState[VS_PROPERTYUPLOADUNIT_LIST];
        }
        private void setSelectedPropertyUnit(long selectedId)
        {
            List<PropertyUnitDTO> propertyUnitList = getPropertyUnitList();
            if (propertyUnitList != null && propertyUnitList.Count != 0)
            {
                propertyUnitList.ForEach(c => c.isUISelected = false);
                if (selectedId > 0) propertyUnitList.Find(c => c.Id == selectedId).isUISelected = true;
            }
        }
        private void selectPropertyUnitGridRdBtn(long uiIndex)
        {
            if (proprtyunitGrid.Rows.Count > 0)
            {
                setSelectedPropertyUnit(0);
                foreach (GridViewRow row in proprtyunitGrid.Rows)
                {
                    GroupRadioButton radioBtn = (GroupRadioButton)row.FindControl("rdPropertyUnitSelect");
                    radioBtn.Checked = false;
                    if (uiIndex > 0)
                    {
                        Button rowIdenBtn = (Button)row.FindControl("btnPropUnitRowIdentifier");
                        if (rowIdenBtn != null && uiIndex.ToString().Equals(rowIdenBtn.Attributes["row-identifier"]))
                        {
                            radioBtn.Checked = true;
                            setSelectedPropertyUnit(uiIndex);
                        }
                    }
                }
            }
        }
        private void assignUiIndexToPropertyUnit(List<PropertyUnitDTO> prUnitDtos)
        {
            if (prUnitDtos != null && prUnitDtos.Count > 0)
            {
                prUnitDtos.ForEach(c => c.isUISelected = false);
                long uiIndex = 1;
                foreach (PropertyUnitDTO prUnitDto in prUnitDtos)
                {
                    prUnitDto.UiIndex = uiIndex++;
                    prUnitDto.RowInfo = CommonUIConverter.getGridViewRowInfo(prUnitDto);
                }
            }
        }
        private void loadSearchGridAndReSelect(long Id)
        {
            try
            {
                PropertyUnitSearchBy searchBy = EnumHelper.ToEnum<PropertyUnitSearchBy>(drpSearchBy.Text);
                object searchByValue = null;
                if (!string.IsNullOrWhiteSpace(drpSearchByValue.Text))
                {
                    if (PropertyUnitSearchBy.STATUS == searchBy) searchByValue = EnumHelper.ToEnum<PRUnitStatus>(drpSearchByValue.Text);
                    else searchByValue = drpSearchByValue.Text;
                }
                IList<PropertyUnitDTO> results = propertyUnitManagementBO.fetchPropertyUnitGridData(getUserDefinitionDTO().FirmNumber,
                        searchBy, searchByValue, long.Parse(drpSearchTower.Text));
                ViewState[VS_PROPERTYUNIT_LIST] = results;
                proprtyunitGrid.DataSource = results;
                proprtyunitGrid.DataBind();
                if (Id > 0)
                {
                    selectPropertyUnitGridRdBtn(Id);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void fetchSelectedPropertyUnitList()
        {
            try
            {
                PropertyUnitDTO propertyUnitDto = null;
                if (PrUnitPageMode.ADD.ToString().Equals(pageModeHdn.Value))
                {
                    propertyUnitDto = populatePropertyUnitDTOAdd();
                    selectPropertyUnitGridRdBtn(0);
                }
                else if (PrUnitPageMode.MODIFY.ToString().Equals(pageModeHdn.Value) || PrUnitPageMode.VIEW.ToString().Equals(pageModeHdn.Value))
                {
                    long Id = getPropertyUnitList().Find(c => c.isUISelected).Id;
                    propertyUnitDto = propertyUnitManagementBO.fetchPropertyUnitDetails(Id);
                }
                ViewState[VS_SELECTED_PROPERTYUNIT] = propertyUnitDto;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        private void doViewModifyAction(PrUnitPageMode pageMode)
        {
            resetTabInfo(pageMode);
            fetchSelectedPropertyUnitList();
            PropertyUnitDTO prUnitDto = getCurrentPropertyUnit();
            populateUIFieldsFromDTO(prUnitDto);
        }
        protected void onSearchByProperty(object sender, EventArgs e)
        {
            try
            {
                resetTabInfo(PrUnitPageMode.NONE);
                pnlUnitGrid.Visible = false;
                if (!string.IsNullOrWhiteSpace(drpSearchProperty.Text))
                {
                    UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                    drpBO.drpDataBase(drpSearchTower, DrpDataType.PROPERTY_TOWER, drpSearchProperty.Text, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    if (drpSearchTower.Items.Count == 2)
                    {
                        drpSearchTower.Items[1].Selected = true;
                        loadSearchGridAndReSelect(0);
                    }
                    pnlUnitGrid.Visible = true;
                }
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }

        }

        protected void onSearchByTower(object sender, EventArgs e)
        {
            try
            {
                pnlUnitGrid.Visible = false;
                if (!string.IsNullOrWhiteSpace(drpSearchTower.Text))
                {
                    pnlUnitGrid.Visible = true;
                    loadSearchGridAndReSelect(0);
                }
                else resetTabInfo(PrUnitPageMode.NONE);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onSearchBy(object sender, EventArgs e)
        {
            try
            {
                UserDefinitionDTO userDefDto = getUserDefinitionDTO();
                PropertyUnitSearchBy searchBy = EnumHelper.ToEnum<PropertyUnitSearchBy>(drpSearchBy.Text);
                drpSearchByValue.Visible = true;
                lbSearchByValue.Visible = true;
                lbSearchByValue.Text = EnumHelper.GetEnumDescription<PropertyUnitSearchBy>(searchBy.ToString());
                if (PropertyUnitSearchBy.UNIT_NO == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.PR_UNIT_SEARCH_BY_UNITNO, drpSearchTower.Text, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (PropertyUnitSearchBy.UNIT_TYPE == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (PropertyUnitSearchBy.FLOOR_NO == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.PR_UNIT_SEARCH_BY_FLOORNO, drpSearchTower.Text, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
                else if (PropertyUnitSearchBy.STATUS == searchBy)
                {
                    drpBO.drpEnum<PRUnitStatus>(drpSearchByValue, Constants.SELECT_ITEM);
                }
                else if (PropertyUnitSearchBy.WING == searchBy)
                {
                    drpBO.drpDataBase(drpSearchByValue, DrpDataType.PR_UNIT_SEARCH_BY_WING, drpSearchTower.Text, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }

                else
                {
                    drpSearchByValue.ClearSelection();
                    drpSearchByValue.Visible = false;
                    lbSearchByValue.Visible = false;
                }
                loadSearchGridAndReSelect(0);
                resetTabInfo(PrUnitPageMode.NONE);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onSearchByValue(object sender, EventArgs e)
        {
            loadSearchGridAndReSelect(0);
            resetTabInfo(PrUnitPageMode.NONE);
        }
        protected void selectPropertyUnit(object sender, EventArgs e)
        {
            try
            {
                GroupRadioButton rd = (GroupRadioButton)sender;
                resetTabInfo(PrUnitPageMode.NONE);
                if (rd.Checked)
                {
                    string strId = ((Button)(((GridViewRow)rd.NamingContainer).FindControl("btnPropUnitRowIdentifier"))).Attributes["row-identifier"];
                    setSelectedPropertyUnit(long.Parse(strId));
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        /*
         * This method is called on click of ADD button in datatable top bar.
         */
        protected void onClickAddPropertyUnitBtn(object sender, EventArgs e)
        {
            try
            {
                resetTabInfo(PrUnitPageMode.ADD);
                fetchSelectedPropertyUnitList();
                populateUIFieldsFromDTO(null);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickViewPropertyUnitBtn(object sender, EventArgs e)
        {
            try
            {
                if (validatePrUnitSelected())
                {
                    doViewModifyAction(PrUnitPageMode.VIEW);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void onClickModifyPropertyUnitBtn(object sender, EventArgs e)
        {
            try
            {
                if (validatePrUnitSelected() && validatePrUnitModify())
                {
                    doViewModifyAction(PrUnitPageMode.MODIFY);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void deletePropertyUnit(object sender, EventArgs e)
        {
            try
            {
                if (validatePrUnitSelected() && validatePrUnitDelete())
                {
                    long Id = getPropertyUnitList().Find(c => c.isUISelected).Id;
                    BusinessOutputTO outputTO = propertyUnitManagementBO.deletePropertyUnitDetails(Id);
                    if (outputTO.status == BusinessOutputTO.Status.SUCCESS)
                    {
                        loadSearchGridAndReSelect(0);
                        resetTabInfo(PrUnitPageMode.NONE);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_delete, "Property Unit"), tab1Anchor.ID);
                    }
                    else
                    {
                        propertyUnitManagementBO.updateUnitAsDeleted(Id);
                        resetTabInfo(PrUnitPageMode.NONE);
                        loadSearchGridAndReSelect(Id);
                        setSuccessMessage(Resources.Messages.success_prunit_delete_update, tab1Anchor.ID);
                    }
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }
        protected void addOrModifyPropertyUnit(object sender, EventArgs e)
        {
            try
            {
                if (validateUnitAddOrModify())
                {
                    PropertyUnitDTO propertyUnitDTO = getCurrentPropertyUnit();
                    long Id = propertyUnitDTO.Id;
                    populatePropertyUnitDTOFromUI(propertyUnitDTO);
                    if (PrUnitPageMode.ADD.ToString().Equals(pageModeHdn.Value))
                    {
                        Id = propertyUnitManagementBO.savePropertyUnitDetails(propertyUnitDTO);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_add, "Property Unit"), tab1Anchor.ID);
                    }
                    else if (PrUnitPageMode.MODIFY.ToString().Equals(pageModeHdn.Value))
                    {
                        propertyUnitManagementBO.updatePropertyUnitDetails(propertyUnitDTO);
                        setSuccessMessage(string.Format(Resources.Messages.success_record_update, "Property Unit"), tab1Anchor.ID);
                    }
                    resetTabInfo(PrUnitPageMode.NONE);
                    loadSearchGridAndReSelect(Id);
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab2ValidationGrp);
            }
        }
        private bool validatePrUnitSelected()
        {
            bool isSelected = true;
            List<PropertyUnitDTO> propertyUnitList = getPropertyUnitList();
            if (propertyUnitList != null)
            {
                isSelected = propertyUnitList.Any(c => c.isUISelected);
                if (!isSelected)
                {
                    resetTabInfo(PrUnitPageMode.NONE);
                    setErrorMessage(string.Format(Resources.Messages.validation_record_select, "Property Unit"), tab1ValidationGrp);
                }
            }
            return isSelected;
        }
        private bool validatePrUnitModify()
        {
            bool isValid = true;
            PropertyUnitDTO propertyUnitDto = getPropertyUnitList().Find(x => x.isUISelected);
            if (propertyUnitDto.Status == PRUnitStatus.Deleted)
            {
                isValid = false;
                resetTabInfo(PrUnitPageMode.NONE);
                setErrorMessage("Selected Property Unit is deleted, cannot be modified.", tab1ValidationGrp);
            }
            else if (propertyUnitDto.Status == PRUnitStatus.Sold)
            {
                isValid = false;
                resetTabInfo(PrUnitPageMode.NONE);
                setErrorMessage("Selected Property Unit is Sold, cannot be modified.", tab1ValidationGrp);
            }
            return isValid;
        }
        private bool validatePrUnitDelete()
        {
            bool isValid = true;
            PropertyUnitDTO propertyUnitDTO = getPropertyUnitList().Find(x => x.isUISelected);
            if (propertyUnitDTO.Status != PRUnitStatus.Available)
            {
                isValid = false;
                setErrorMessage("Only Available property units can be deleted.", tab1ValidationGrp);
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        private bool validateUnitAddOrModify()
        {
            bool isValid = true;
            Page.Validate("tab2Error");
            isValid = Page.IsValid;
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            if (isValid) isValid = validateUnitAddOrModifyOther();
            return isValid;
        }
        private bool validateUnitAddOrModifyOther()
        {
            bool isValid = true;
            PRUnitStatus status = EnumHelper.ToEnum<PRUnitStatus>(drpStatus.Text);
            if (!(PRUnitStatus.Available == status || PRUnitStatus.Reserved == status))
            {
                isValid = false;
                setErrorMessage("Please select Status as 'Available' or 'Reserved'.", tab2ValidationGrp);
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            if (PRUnitStatus.Reserved == status && string.IsNullOrWhiteSpace(txtReserveComments.Text))
            {
                isValid = false;
                setErrorMessage("Please enter Reserve Comments.", tab2ValidationGrp);
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            if (PrUnitPageMode.ADD.ToString().Equals(pageModeHdn.Value))
            {
                if (propertyUnitManagementBO.validateUnitExist(getUserDefinitionDTO().FirmNumber, long.Parse(drpSearchTower.Text), txtWing.Text,
                    txtFloorNo.Text, txtunitNo.Text))
                {
                    setErrorMessage("Property Unit already exist.", tab2ValidationGrp);
                    scrollToFieldHdn.Value = Constants.SCROLL_TOP;
                    isValid = false;
                }
            }
            return isValid;
        }
        protected void cancelPropertyUnit(object sender, EventArgs e)
        {
            PropertyUnitDTO firmMemberDto = getCurrentPropertyUnit();
            resetTabInfo(PrUnitPageMode.NONE);
            loadSearchGridAndReSelect(firmMemberDto.Id);
        }
        protected void cancelPropertyUploadUnit(object sender, EventArgs e)
        {
            resetTabInfo(PrUnitPageMode.NONE);
        }

        private PropertyUnitDTO populatePropertyUnitDTOAdd()
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            PropertyUnitDTO propertyUnitDto = new PropertyUnitDTO();
            propertyUnitDto.PropertyTower = new PropertyTowerDTO();
            propertyUnitDto.PropertyTower.Id = long.Parse(drpSearchTower.Text);
            propertyUnitDto.FirmNumber = userDefDto.FirmNumber;
            propertyUnitDto.InsertUser = userDefDto.Username;
            return propertyUnitDto;
        }
        private void populatePropertyUnitDTOFromUI(PropertyUnitDTO propertyUnitDTO)
        {
            UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
            if (propertyUnitDTO.Status == PRUnitStatus.Available)
            {
                propertyUnitDTO.Wing = txtWing.Text;
                propertyUnitDTO.FloorNo = txtFloorNo.Text;
                propertyUnitDTO.UnitNo = txtunitNo.Text;
            }
            propertyUnitDTO.UnitType = CommonUIConverter.getMasterControlDTO(drpUnitType.Text, null);
            propertyUnitDTO.BuildupArea = CommonUtil.getDecimalWithoutExt(txtBuiltupArea.Text);
            propertyUnitDTO.CarpetArea = CommonUtil.getDecimalWithoutExt(txtCarpetArea.Text);
            propertyUnitDTO.BalconyArea = CommonUtil.getDecimalWithoutExt(txtBalconyArea.Text);
            propertyUnitDTO.Facing = CommonUIConverter.getMasterControlDTO(drpfacing.Text, null);
            propertyUnitDTO.Status = EnumHelper.ToEnum<PRUnitStatus>(drpStatus.Text);
            propertyUnitDTO.Direction = CommonUIConverter.getMasterControlDTO(drpDirection.Text, null);
            propertyUnitDTO.ReserveComments = (propertyUnitDTO.Status == PRUnitStatus.Reserved) ? txtReserveComments.Text : "";
            propertyUnitDTO.NoOfBalcony = Convert.ToInt32(txtNoOfBalcony.Text);
            propertyUnitDTO.FirmNumber = userDefDto.FirmNumber;
            propertyUnitDTO.Version = userDefDto.Version;
            propertyUnitDTO.UpdateUser = userDefDto.Username;
        }
        private void populateUIFieldsFromDTO(PropertyUnitDTO propertyUnitDto)
        {

            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            txtProperty.Text = drpSearchProperty.SelectedItem.Text;
            txtTower.Text = drpSearchTower.SelectedItem.Text;
            if (propertyUnitDto != null) drpUnitType.Text = propertyUnitDto.UnitType.Id.ToString(); else drpUnitType.Text = null;
            if (propertyUnitDto != null) txtWing.Text = propertyUnitDto.Wing; else txtWing.Text = null;
            if (propertyUnitDto != null) txtReserveComments.Text = propertyUnitDto.ReserveComments; else txtReserveComments.Text = null;
            if (propertyUnitDto != null) txtNoOfBalcony.Text = Convert.ToDecimal(propertyUnitDto.NoOfBalcony).ToString(); else txtNoOfBalcony.Text = null;
            if (propertyUnitDto != null) txtFloorNo.Text = Convert.ToDecimal(propertyUnitDto.FloorNo).ToString(); else txtFloorNo.Text = null;
            if (propertyUnitDto != null && propertyUnitDto.UnitNo != null) txtunitNo.Text = propertyUnitDto.UnitNo; else txtunitNo.Text = null;
            if (propertyUnitDto != null && propertyUnitDto.BuildupArea != null) txtBuiltupArea.Text = propertyUnitDto.BuildupArea.ToString(); else txtBuiltupArea.Text = null;
            if (propertyUnitDto != null && propertyUnitDto.CarpetArea != null) txtCarpetArea.Text = propertyUnitDto.CarpetArea.ToString(); else txtCarpetArea.Text = null;
            if (propertyUnitDto != null && propertyUnitDto.BalconyArea != null) txtBalconyArea.Text = propertyUnitDto.BalconyArea.ToString(); else txtBalconyArea.Text = null;
            if (propertyUnitDto != null && propertyUnitDto.Facing != null) drpfacing.Text = propertyUnitDto.Facing.Id.ToString(); else drpfacing.Text = null;
            if (propertyUnitDto != null) drpStatus.Text = propertyUnitDto.Status.ToString(); else drpStatus.Text = PRUnitStatus.Available.ToString();
            if (propertyUnitDto != null && propertyUnitDto.Direction != null) drpDirection.Text = propertyUnitDto.Direction.Id.ToString(); else drpDirection.ClearSelection();

        }
        //Modal save logic
        protected void saveModalData(object sender, EventArgs e)
        {
            String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (modalHdnType.Value == "UNIT_TYPE")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_UNIT_TYPE, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Unit_Type");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpUnitType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            else if (modalHdnType.Value == "DIRECTION")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_UNIT_DIRECTION, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "DIRECTION");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpDirection, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_DIRECTION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            else if (modalHdnType.Value == "FACING")
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_UNIT_FACING, modalInput1.Text,
                       modalInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "FACING");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpfacing, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_UNIT_FACING, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    modalIdentifierHdn.Value = "";
                }
            }
            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
                modalErrorMsg.Value = errorMsg;
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "setModalErrorMsg", "setModalErrorMsg()", true);
            }
            else
            {
                //Reset the modal fields
                modalInput1.Text = "";
                modalInput2.Text = "";
                modalHdnType.Value = "";
                modalActionHdn.Value = "";
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "closeDialogClient", "closeDialogClient()", true);
            }
        }

        private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
        {
            string errorMsg = "";
            if (string.IsNullOrWhiteSpace(masterDataDto.Name))
            {
                errorMsg = Resources.Messages.validation_designationname_required;
            }
            else if (masterDataBO.isAlreadyExist(masterDataDto))
            {
                errorMsg = string.Format(Resources.Messages.validation_same_name_exist, type);
            }
            return errorMsg;
        }


        private string validateUnitNoInput(PropertyUnitDTO propertyunitDto)
        {
            string errorMsg = "";
            if (string.IsNullOrWhiteSpace(propertyunitDto.UnitNo))
            {
                errorMsg = Resources.Messages.validation_unitno_required;
            }
            else if (propertyUnitManagementBO.isAlreadyExist(propertyunitDto))
            {
                errorMsg = string.Format(Resources.Messages.validation_same_name_exist, propertyunitDto.UnitNo);
            }
            return errorMsg;
        }

        public void uploadBulkUnits(object sender, EventArgs e)
        {
            try
            {
                resetTabInfo(PrUnitPageMode.UPLOAD);
                txtPropertyName.Text = drpSearchProperty.SelectedItem.Text;
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab1ValidationGrp);
            }
        }

        public void addPropertyUnits(object sender, EventArgs e)
        {
            try
            {
                foreach (PropertyUnitDTO propertyUnitDTO in getPropertyUnitUploadList())
                {
                    if (propertyUnitDTO.ErrorMessage == null || propertyUnitDTO.ErrorMessage.Equals(""))
                    {
                        propertyUnitManagementBO.savePropertyUnitDetails(propertyUnitDTO);
                        propertyUnitDTO.ErrorMessage = string.Format(Resources.Messages.success_record_add, "Property Unit");
                    }
                }
                unitUploadGrid.DataSource = getPropertyUnitUploadList();
                unitUploadGrid.DataBind();
                setSuccessMessage(string.Format(Resources.Messages.success_record_add, "Property Units"), tab3Anchor.ID);
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                setErrorMessage(Resources.Messages.system_error, tab3ValidationGrp);
            }

        }

        public void validatePropertyUnits(object sender, EventArgs e)
        {
            if (validateUnitUpload())
            {
                HttpFileCollection uploadedFiles = Request.Files;
                IList<PropertyUnitDTO> results = new List<PropertyUnitDTO>();
                for (int i = 0; i < uploadedFiles.Count; i++)
                {
                    HttpPostedFile userPostedFile = uploadedFiles[i];
                    if (userPostedFile.ContentLength > 0)
                    {
                        string filename = Path.GetFileName(userPostedFile.FileName);
                        string extension = Path.GetExtension(filename);
                        HttpPostedFile file = fileUpload.PostedFile;
                        if (validateFileType(extension))
                        {
                            using (file.InputStream)
                            {
                                ExcelPackage excel = new ExcelPackage(file.InputStream);
                                var workSheet = excel.Workbook.Worksheets[1];
                                IEnumerable<PropertyUnitMapperDTO> newcollection = workSheet.ConvertSheetToObjects<PropertyUnitMapperDTO>();
                                foreach (PropertyUnitMapperDTO propertyUnitMapperDTO in newcollection)
                                {
                                    results.Add(populatePropertyUnitDTO(propertyUnitMapperDTO));
                                }
                            }
                        }
                    }
                    ViewState[VS_PROPERTYUPLOADUNIT_LIST] = results;
                    unitUploadGrid.DataSource = results;
                    unitUploadGrid.DataBind();

                }
            }
        }
        public PropertyUnitDTO populatePropertyUnitDTO(PropertyUnitMapperDTO propertyUnitMapperDTO)
        {
            PropertyUnitDTO propertyUnitDTO = new PropertyUnitDTO();
            StringBuilder sb = new StringBuilder();
            try
            {
                UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
                if (!propertyUnitMapperDTO.PropertyName.Equals(txtPropertyName.Text))
                {
                    sb.Append("Unit Belongs to different Property.");
                }
                propertyUnitDTO.Wing = propertyUnitMapperDTO.Wing;
                if (propertyUnitMapperDTO.FloorNo == null)
                {
                    sb.Append("Floor Number Missing. ");
                }
                else
                {
                    propertyUnitDTO.FloorNo = propertyUnitMapperDTO.FloorNo;
                }
                if (propertyUnitMapperDTO.UnitNo == null)
                {
                    sb.Append("UnitNo Number Missing. ");
                }
                else
                {
                    propertyUnitDTO.UnitNo = propertyUnitMapperDTO.UnitNo;
                }
                if (propertyUnitMapperDTO.UnitType == null)
                {
                    sb.Append("Unit Type Missing. ");
                }
                else
                {
                    foreach (ListItem li in drpUnitType.Items)
                    {
                        if (li.Text.Equals(propertyUnitMapperDTO.UnitType))
                        {
                            propertyUnitDTO.UnitType = CommonUIConverter.getMasterControlDTO(li.Value, propertyUnitMapperDTO.UnitType);
                        }
                    }
                }
                if (propertyUnitMapperDTO.BuildupArea == null)
                {
                    sb.Append("Builtup Area Missing. ");
                }
                else
                {
                    propertyUnitDTO.BuildupArea = CommonUtil.getDecimalWithoutExt(propertyUnitMapperDTO.BuildupArea);
                }
                if (propertyUnitMapperDTO.CarpetArea == null)
                {
                    sb.Append("Carpet Area is Missing. ");
                }
                else
                {
                    propertyUnitDTO.CarpetArea = CommonUtil.getDecimalWithoutExt(propertyUnitMapperDTO.CarpetArea);
                }
                if (propertyUnitMapperDTO.BalconyArea == null)
                {
                    sb.Append("Balcony Area Missing. ");
                }
                else
                {
                    propertyUnitDTO.BalconyArea = CommonUtil.getDecimalWithoutExt(propertyUnitMapperDTO.BalconyArea);
                }
                if (propertyUnitMapperDTO.Facing != null)
                {
                    foreach (ListItem li in drpfacing.Items)
                    {
                        if (li.Text.Equals(propertyUnitMapperDTO.Facing))
                        {
                            propertyUnitDTO.Facing = CommonUIConverter.getMasterControlDTO(li.Value, propertyUnitMapperDTO.Facing);
                        }
                    }
                }
                if (propertyUnitMapperDTO.Status == null)
                {
                    sb.Append("Status Missing. ");
                }
                else
                {
                    propertyUnitDTO.Status = EnumHelper.ToEnum<PRUnitStatus>(propertyUnitMapperDTO.Status);
                }
                if (propertyUnitMapperDTO.Direction != null)
                {
                    foreach (ListItem li in drpDirection.Items)
                    {
                        if (li.Text.Equals(propertyUnitMapperDTO.Direction))
                        {
                            propertyUnitDTO.Direction = CommonUIConverter.getMasterControlDTO(li.Value, propertyUnitMapperDTO.Direction);
                        }
                    }
                }
                if (propertyUnitMapperDTO.NoOfBalcony == null)
                {
                    sb.Append("Number Of Balcony Missing. ");
                }
                else
                {
                    propertyUnitDTO.NoOfBalcony = Convert.ToInt32(propertyUnitMapperDTO.NoOfBalcony);
                }
                propertyUnitDTO.FirmNumber = userDefDto.FirmNumber;
                propertyUnitDTO.Version = userDefDto.Version;
                propertyUnitDTO.UpdateUser = userDefDto.Username;
                if (propertyUnitMapperDTO.TowerName == null)
                {
                    sb.Append("Tower Name Missing. ");
                }
                else
                {
                    propertyUnitDTO.PropertyTower = new PropertyTowerDTO();
                    foreach (ListItem li in drpSearchTower.Items)
                    {
                        if (li.Text.Equals(propertyUnitMapperDTO.TowerName))
                            propertyUnitDTO.PropertyTower.Id = long.Parse(li.Value);
                        propertyUnitDTO.TowerName = propertyUnitMapperDTO.TowerName;
                    }
                }
                propertyUnitDTO.FirmNumber = userDefDto.FirmNumber;
                propertyUnitDTO.InsertUser = userDefDto.Username;
                if (propertyUnitManagementBO.isAlreadyExist(propertyUnitDTO))
                {
                    sb.Append(string.Format(Resources.Messages.validation_same_name_exist, propertyUnitDTO.UnitNo));
                }
            }
            catch (Exception exp)
            {
                log.Error(exp.Message, exp);
                sb.Append(exp.Message);
            }
            propertyUnitDTO.ErrorMessage = sb.ToString();
            return propertyUnitDTO;
        }
        public void downloadUnitTemplateDownload(object sender, EventArgs e)
        {
            List<MasterControlDataDTO> resultsUnitType;
            List<MasterControlDataDTO> resultsFacing;
            List<MasterControlDataDTO> resultsDirection;
            fetchMaster(out resultsUnitType, out resultsFacing, out resultsDirection);
            if (resultsUnitType == null || resultsUnitType.Count <= 0)
            {
                setErrorMessage("Please add property unit types before downloading unit template.", tab1ValidationGrp);
            }
            else if (resultsFacing == null || resultsFacing.Count <= 0)
            {
                setErrorMessage("Please add property unit facing before downloading unit template.", tab1ValidationGrp); ;
            }
            else if (resultsDirection == null && resultsDirection.Count <= 0)
            {
                setErrorMessage("Please add property unit direction before downloading unit template.", tab1ValidationGrp);
            }
            else
            {
                setResponse();
                using (ExcelPackage package = new ExcelPackage())
                {
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.Add(drpSearchProperty.SelectedItem.Text);

                    using (var range = worksheet.Cells["A1: k1048576"])
                    {
                        range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Top.Color.SetColor(Color.Black);
                        range.Style.Border.Bottom.Color.SetColor(Color.Green);
                        range.Style.Border.Left.Color.SetColor(Color.Blue);
                        range.Style.Border.Right.Color.SetColor(Color.Yellow);
                    }
                    prepareHeader(worksheet);
                    addValidationLists(resultsUnitType, resultsFacing, resultsDirection, package, worksheet);
                    package.Save();
                    using (MemoryStream MyMemoryStream = new MemoryStream())
                    {
                        package.SaveAs(MyMemoryStream);
                        MyMemoryStream.WriteTo(Response.OutputStream);
                        Response.Flush();
                        Response.End();
                    }
                }
            }
        }

        private void addValidationLists(List<MasterControlDataDTO> resultsUnitType, List<MasterControlDataDTO> resultsFacing,
            List<MasterControlDataDTO> resultsDirection, ExcelPackage package, ExcelWorksheet worksheet)
        {
            addListValidationForProperty(package, worksheet);
            addListValidationForTower(package, worksheet);
            addListValidationForUnitType(package, worksheet, resultsUnitType);
            addListValidationForDirection(package, worksheet, resultsDirection);
            addListValidationForFacing(package, worksheet, resultsFacing);
            addListValidationForStatus(package, worksheet);
        }

        private void setResponse()
        {
            Response.Clear();
            Response.Buffer = true;
            Response.Charset = "";
            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            Response.AddHeader("content-disposition", "attachment;filename=" + drpSearchProperty.SelectedItem.Text + ".xlsx");
        }

        private void fetchMaster(out List<MasterControlDataDTO> resultsUnitType, out List<MasterControlDataDTO> resultsFacing, out List<MasterControlDataDTO> resultsDirection)
        {
            resultsUnitType = masterDataBO.fetchMasterData(getUserDefinitionDTO().FirmNumber,
                            MasterDataType.PR_UNIT_TYPE.ToString());
            resultsFacing = masterDataBO.fetchMasterData(getUserDefinitionDTO().FirmNumber,
                MasterDataType.PR_UNIT_FACING.ToString());
            resultsDirection = masterDataBO.fetchMasterData(getUserDefinitionDTO().FirmNumber, MasterDataType.PR_UNIT_DIRECTION.ToString());
        }

        private void prepareHeader(ExcelWorksheet worksheet)
        {
            worksheet.Cells[1, 1].Value = "Property Name";
            worksheet.Cells[1, 2].Value = "Tower Name";
            worksheet.Cells[1, 3].Value = "Wing";
            worksheet.Cells[1, 4].Value = "Floor Number";
            worksheet.Cells[1, 5].Value = "Unit Number";
            worksheet.Cells[1, 6].Value = "Unit Type";
            worksheet.Cells[1, 7].Value = "Builtup Area";
            worksheet.Cells[1, 8].Value = "Carpet Area";
            worksheet.Cells[1, 9].Value = "Balcony Area";
            worksheet.Cells[1, 10].Value = "No Of Balcony";
            worksheet.Cells[1, 11].Value = "Facing";
            worksheet.Cells[1, 12].Value = "Direction";
            worksheet.Cells[1, 13].Value = "Status";
            using (var range = worksheet.Cells[1, 1, 1, 13])
            {
                range.Style.Font.Bold = true;
                range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                range.Style.Fill.BackgroundColor.SetColor(Color.Blue);
                range.Style.Font.Color.SetColor(Color.White);
            }
            worksheet.Cells["A1:L1048576"].AutoFilter = true;
            worksheet.Cells.AutoFitColumns(0);
        }
        private void addListValidationForUnitType(ExcelPackage package, ExcelWorksheet worksheet, List<MasterControlDataDTO> results)
        {
            var validation = worksheet.DataValidations.AddListValidation("F2:F1048576");
            validation.ShowErrorMessage = true;
            validation.ErrorStyle = ExcelDataValidationWarningStyle.stop;
            validation.ErrorTitle = "An invalid value was entered";
            validation.Error = "Select a value from the list";
            foreach (MasterControlDataDTO masterControlDataDTO in results)
            {
                validation.Formula.Values.Add(masterControlDataDTO.Name);
            }
        }
        private void addListValidationForDirection(ExcelPackage package, ExcelWorksheet worksheet, List<MasterControlDataDTO> results)
        {
            var validation = worksheet.DataValidations.AddListValidation("L2:L1048576");
            validation.ShowErrorMessage = true;
            validation.ErrorStyle = ExcelDataValidationWarningStyle.stop;
            validation.ErrorTitle = "An invalid value was entered";
            validation.Error = "Select a value from the list";
            foreach (MasterControlDataDTO masterControlDataDTO in results)
            {
                validation.Formula.Values.Add(masterControlDataDTO.Name);
            }
        }
        private void addListValidationForFacing(ExcelPackage package, ExcelWorksheet worksheet, List<MasterControlDataDTO> results)
        {
            var validation = worksheet.DataValidations.AddListValidation("K2:K1048576");
            validation.ShowErrorMessage = true;
            validation.ErrorStyle = ExcelDataValidationWarningStyle.stop;
            validation.ErrorTitle = "An invalid value was entered";
            validation.Error = "Select a value from the list";
            foreach (MasterControlDataDTO masterControlDataDTO in results)
            {
                validation.Formula.Values.Add(masterControlDataDTO.Name);
            }
        }
        private void addListValidationForStatus(ExcelPackage package, ExcelWorksheet worksheet)
        {
            var validation = worksheet.DataValidations.AddListValidation("M2:M1048576");
            validation.ShowErrorMessage = true;
            validation.ErrorStyle = ExcelDataValidationWarningStyle.stop;
            validation.ErrorTitle = "An invalid value was entered";
            validation.Error = "Select a value from the list";
            foreach (PRUnitStatus PRUnitStatus in Enum.GetValues(typeof(PRUnitStatus)))
            {
                if (PRUnitStatus.ToString() == "Available")
                    validation.Formula.Values.Add(PRUnitStatus.ToString());
            }
        }
        private void addListValidationForTower(ExcelPackage package, ExcelWorksheet worksheet)
        {
            var validation = worksheet.DataValidations.AddListValidation("B2:B1048576");
            validation.ShowErrorMessage = true;
            validation.ErrorStyle = ExcelDataValidationWarningStyle.stop;
            validation.ErrorTitle = "An invalid value was entered";
            validation.Error = "Select a value from the list";
            foreach (ListItem li in drpSearchTower.Items)
            {
                if (li.Text != "--Select--")
                    validation.Formula.Values.Add(li.Text);
            }
        }
        private void addListValidationForProperty(ExcelPackage package, ExcelWorksheet worksheet)
        {
            var validation = worksheet.DataValidations.AddListValidation("A2:A1048576");
            validation.ShowErrorMessage = true;
            validation.ErrorStyle = ExcelDataValidationWarningStyle.stop;
            validation.ErrorTitle = "An invalid value was entered";
            validation.Error = "Select a value from the list";
            validation.Formula.Values.Add(drpSearchProperty.SelectedItem.Text);
        }
        private bool validateUnitUpload()
        {
            bool isValid = true;
            Page.Validate("tab3Error");
            isValid = Page.IsValid;
            if (!isValid)
            {
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;
        }
        private bool validateFileType(string extension)
        {
            bool isValid = true;
            if (extension != ".xlsx" && extension != ".xls")
            {
                isValid = false;
                setErrorMessage("Please Select Property Unit Excel with extension xlsx or xls.", tab3ValidationGrp);
                scrollToFieldHdn.Value = Constants.SCROLL_TOP;
            }
            return isValid;

        }
    }
}