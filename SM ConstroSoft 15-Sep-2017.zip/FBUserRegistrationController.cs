﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ConstroSoft
{
    public class FBUserRegistrationController : ApiController
    {
        [HttpPost]
        [ActionName("RegisterUser")]
        public string RegisterUser([FromBody]FBUserDTO fBUserDTO)
        {
            FBIntegrationBO fBIntegrationBO = new FBIntegrationBO();
            var response = JsonConvert.SerializeObject("Failure");
            if (fBUserDTO != null)
            {
                string errorMessage = fBIntegrationBO.validateMandatoryFields(fBUserDTO);
                if (errorMessage == null)
                {
                    errorMessage = fBIntegrationBO.checkFirmExists(fBUserDTO);
                    if (errorMessage == null)
                    {
                        errorMessage = fBIntegrationBO.checkUserExists(fBUserDTO);
                        if (errorMessage == null)
                        {
                            fBIntegrationBO.saveFBuser(fBUserDTO);
                            response = JsonConvert.SerializeObject(fBUserDTO.UserName + " created successfully");
                        }
                        else
                        {
                            response = JsonConvert.SerializeObject(errorMessage);
                        }
                    }
                    else
                    {
                        response = JsonConvert.SerializeObject(errorMessage);
                    }
                }
                else
                {
                    response = JsonConvert.SerializeObject(errorMessage);
                }
            }
            return response;
        }

    }
}