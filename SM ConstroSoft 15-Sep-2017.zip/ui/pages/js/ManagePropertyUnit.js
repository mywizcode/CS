﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initPropertyUnitManagement();
    initPropertyUnitUploadManagement();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("tab2Content");
    enableTab(true);
}

function initPropertyUnitManagement() {
    var dtOptions = {
        tableId: "proprtyunitGrid",
        pageLength: 10,
        isViewOnly: false,
        customBtnGrpId: "#propunitSearchBtnDiv",
        hideSearch: false
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPropertyUnitHdnId");
}
function initPropertyUnitUploadManagement() {
    var dtOptions = {
        tableId: "unitUploadGrid",
        pageLength: 10,
        isViewOnly: false,
        hideSearch: false
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToPropertyUnitUploadHdnId");
}




