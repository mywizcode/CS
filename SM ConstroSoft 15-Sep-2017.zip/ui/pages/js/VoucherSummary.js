﻿$(document).ready(function () {
    $('#tabs').tab();
    initBootstrapComponants();
});

function initBootstrapComponants() {
    initVoucherManagement();
    //formatFields() must be called before 'initViewMode()' in order to display currency sign etc. in read only mode.
    formatFields();
    initViewMode("tab2Content");
    enableTab(true);
}

function initVoucherManagement() {
    var dtOptions = {
        tableId: "voucherGrid",
        pageLength: 10,
        isViewOnly: false,
        customBtnGrpId: "#voucherSearchBtnDiv",
        hideSearch: false
    };
    var dtTable = applyDataTable(dtOptions);
    jumpToTablePage(dtTable, "jumpToVoucherHdnId");
}





