﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ConstroSoft
{
    public class LeadFieldController : ApiController
    {
        [HttpGet]
        [ActionName("GetEnquiryFields")]
        public string GetEnquiryFields()
        {
                    List<string> enquiryFields = new List<string>();
                    enquiryFields.Add("FirstName");
                    enquiryFields.Add("LastName");
                    enquiryFields.Add("EnquiryDate");
                    enquiryFields.Add("Budget");
                    enquiryFields.Add("Contact");
                    enquiryFields.Add("Email");
                    enquiryFields.Add("PropertyName");
                    enquiryFields.Add("TokenNumber");
                    var response = JsonConvert.SerializeObject(enquiryFields);
                    return response;
        }
    }
}