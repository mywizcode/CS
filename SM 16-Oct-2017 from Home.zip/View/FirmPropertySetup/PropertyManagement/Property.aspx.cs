﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using System.Globalization;
using Vladsm.Web.UI.WebControls;

public partial class Property : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string addModifyStep1Error = "addModifyStep1Error";
    string addModifyPrTowerError = "addModifyPrTowerError";
    string addModifyTaxDetailError = "addModifyTaxDetailError";
    string addModifyPropertyChargeError = "addModifyPropertyChargeError";
    string addMasterDataError = "addMasterDataError";
    string addAccountError = "addAccountError";
    string step1 = "step1";
    string step2 = "step2";
    string addMasterDataModal = "addMasterDataModal";
    string addModifyPrTowerModal = "addModifyPrTowerModal";
    string addModifyTaxDetailModal = "addModifyTaxDetailModal";
    string addModifyPropertyChargeModal = "addModifyPropertyChargeModal";
    string SearchFilterModal = "SearchFilterModal";
    string addAccountModal = "addAccountModal";
    DropdownBO drpBO = new DropdownBO();
    PropertyBO propertyBO = new PropertyBO();
    MasterDataBO masterDataBO = new MasterDataBO();
    LoginBO loginBO = new LoginBO();
    FirmBO firmBO = new FirmBO();
    public enum PropertyPageMode { ADD, MODIFY, VIEW, NONE }
    public enum PrTowerAction { ADD, MODIFY }
    public enum TaxDetailAction { ADD, MODIFY }
    public enum PropertyChargeAction { ADD, MODIFY }
    public enum AccountAction { ADD }
    protected void Page_Load(object sender, EventArgs e)
    {
        clearMessages();
        if (!IsPostBack)
        {
            if (CommonUtil.isSessionActive(Session))
            {
                Session.Remove(Constants.Session.PAGE_DATA);
                doInit();
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, false);
            }
        }
        setNotyMsg(CommonUtil.getSessionNotyMsg(Session));
    }
    private void setNotyMsg(string msg) {
        btnNotyMsg.Value = CommonUtil.getAppendedNotyMsg(btnNotyMsg.Value, msg);
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (CommonUtil.isSessionActive(Session))
        {
            applyEntitlement();
            preRenderInitFormElements();
            initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, false);
        }
    }
    private void applyEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        lnkAddPropertyBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_ADD);
        if (propertySearchGrid.Rows.Count > 0)
        {
            for (var i = 0; i < propertySearchGrid.Rows.Count; i++)
            {
                LinkButton tmpModifyBtn = (LinkButton)propertySearchGrid.Rows[i].FindControl("lnkModifyPropertyBtn");
                if (tmpModifyBtn != null)
                {
                    tmpModifyBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_MODIFY);
                }
                LinkButton tmpDeleteBtn = (LinkButton)propertySearchGrid.Rows[i].FindControl("lnkDeletePropertyBtn");
                if (tmpDeleteBtn != null)
                {
                    tmpDeleteBtn.Visible = CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_DELETE);
                }
            }
        }
    }
    private PropertyPageMode getModifyModeIfEntitlement()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        return CommonUtil.hasEntitlement(userDefDto, Constants.Entitlement.PROPERTY_MODIFY) ? PropertyPageMode.MODIFY : PropertyPageMode.VIEW;
    }
    private void preRenderInitFormElements()
    {
    	renderPageLayout();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", "initBootstrapComponants()", true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        drpBO.drpDataBase(drpPropertyNameFilter, DrpDataType.PROPERTY_NAME, userDefDto.Id.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpPropertytype, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        CommonUtil.copyDropDownItems(drpPropertytypeFilter, drpPropertytype);
        drpBO.drpDataBase(drpPropertyLocation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_LOCATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        CommonUtil.copyDropDownItems(drpPropertyLocationFilter, drpPropertyLocation);
        drpBO.drpDataBase(drpAccount, DrpDataType.FIRM_ACCOUNT, null, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAddressCountry, DrpDataType.COUNTRY, null, null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAddressState, DrpDataType.STATE, Constants.DEFAULT_COUNTRY, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpPropertyChargesType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_CHARGES, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpTaxType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_TAX_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpAddressState.Text = Constants.DEFAULT_STATE;
        initCityDrp(drpAddressCity, Constants.DEFAULT_STATE);
        drpBO.drpDataBase(drpAcntType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.ACCOUNT_TYPE, null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAcntCountry, DrpDataType.COUNTRY, null, null, userDefDto.FirmNumber);
        drpBO.drpDataBase(drpAcntState, DrpDataType.STATE, Constants.DEFAULT_COUNTRY, Constants.SELECT_ITEM, userDefDto.FirmNumber);
        drpAcntState.Text = Constants.DEFAULT_STATE;
        initCityDrp(drpAcntCity, Constants.DEFAULT_STATE);
        drpBO.drpEnum<IncludeInPymtTotal>(drpTaxIncludeInPymt, null);
    }
    private void initCityDrp(DropDownList drp, string stateId)
    {
        drpBO.drpDataBase(drp, DrpDataType.CITY, stateId, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
    }
    public void setErrorMessage(string message, string group)
    {
        CustomValidator val = new CustomValidator();
        val.IsValid = false;
        val.ErrorMessage = message;
        val.ValidationGroup = group;
        this.Page.Validators.Add(val);
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void clearMessages()
    {
        pnlSuccessMsg.Visible = false;
        lbSuccessMsg.Text = "";
    }
    public void setSuccessMessage(string msg)
    {
        lbSuccessMsg.Text = msg;
        pnlSuccessMsg.Visible = true;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    private void doInit()
    {
    	Session[Constants.Session.PAGE_DATA] = new PropertyPageDTO();
    	setSearchFilter(null);
        initPageInfo(PropertyPageMode.NONE);
        clearSearchGrid();
        initDropdowns();
        loadPropertySearchGrid();
    }
    private void initPageInfo(PropertyPageMode pageMode)
    {
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        pageModeHdn.Value = pageMode.ToString();
        activeStepHdn.Value = step1;
        if (PropertyPageMode.NONE == pageMode)
        {
            getSessionPageData().SelectedProperty = null;
            activeStepHdn.Value = "";
        }
    }
    private void renderPageLayout()
    {
    	PropertyPageMode pageMode = EnumHelper.ToEnum<PropertyPageMode>(pageModeHdn.Value);
    	btnReturnToList.Visible = (PropertyPageMode.NONE != pageMode);
    	pnlPropertySearch.Visible = (PropertyPageMode.NONE == pageMode);
        pnlPropertyAddModify.Visible = (PropertyPageMode.ADD == pageMode || PropertyPageMode.MODIFY == pageMode || PropertyPageMode.VIEW == pageMode);
        string currentStep = activeStepHdn.Value;
        propDetailsPage1.Visible = step1.Equals(currentStep);
        propDetailsPage2.Visible = step2.Equals(currentStep);
        fabMenuRight.Visible = pnlPropertyAddModify.Visible;
        initFormFields();
    	resetPageTitle(pageMode);
    }
    private void resetPageTitle(PropertyPageMode pageMode)
    {
        if (PropertyPageMode.NONE == pageMode) lbPageTitle.Text = Constants.ICON.SEARCH + Resources.Labels.SEARCH_PROPERTY;
        else if (PropertyPageMode.ADD == pageMode) lbPageTitle.Text = Constants.ICON.ADD + Resources.Labels.ADD_PROPERTY;
        else if (PropertyPageMode.MODIFY == pageMode) lbPageTitle.Text = Constants.ICON.MODIFY + Resources.Labels.MODIFY_PROPERTY;
        else if (PropertyPageMode.VIEW == pageMode) lbPageTitle.Text = Constants.ICON.VIEW_DTL + Resources.Labels.PROPERTY_DETAILS;
        setSubHeaderPageTitle();
    }
    private void setSubHeaderPageTitle()
    {
        string jumpTo = activeStepHdn.Value;
        lbSubHeaderPageTitle.Text = "";
        if (jumpTo.Equals(step1))
        {
            lbSubHeaderPageTitle.Text = " - " + Resources.Labels.PROPERTY_PAGE1_TITLE;
        }
        else if (jumpTo.Equals(step2))
        {
            lbSubHeaderPageTitle.Text = " - " + Resources.Labels.PROPERTY_PAGE2_TITLE;
        }
    }
    private void initFormFields()
    {
        bool isReadOnly = isViewMode();
        bool visible = !isViewMode();
        if(pnlPropertyAddModify.Visible) {
            
	        //Buttons
	        btnAddModifyPropertySubmit.Visible = visible;
	        addPropertyTypeBtn.Visible = visible;
	        addPropertyLocationBtn.Visible = visible;
	
	        lnkAddPrTowerBtn.Visible = visible;
	        propertyTowerGrid.Columns[0].Visible = visible;
	
	        lnkAddTaxDetailsBtn.Visible = visible;
	        taxDetailGrid.Columns[0].Visible = visible;
	
	        lnkAddPropertyChargeBtn.Visible = visible;
	        propertyChargesGrid.Columns[0].Visible = visible;
	        
	        enableDisableFormFields();
        }
    }
    private void clearSearchGrid()
    {
        List<PropertyDTO> tmpList = new List<PropertyDTO>();
        getSessionPageData().SearchResult = tmpList;
        propertySearchGrid.DataSource = tmpList;
        propertySearchGrid.DataBind();
    }
    private bool isAddMode() {
        return PropertyPageMode.ADD.ToString().Equals(pageModeHdn.Value);
    }
    private bool isModifyMode() {
        return PropertyPageMode.MODIFY.ToString().Equals(pageModeHdn.Value);
    }
    private bool isViewMode() {
        return PropertyPageMode.VIEW.ToString().Equals(pageModeHdn.Value);
    }
    private PropertyPageDTO getSessionPageData()
    {
        return (PropertyPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private List<PropertyDTO> getSearchPropertyList()
    {
        return getSessionPageData().SearchResult;
    }
    private PropertyDTO getSearchPropertyDTO(long Id)
    {
        List<PropertyDTO> searchList = getSearchPropertyList();
        PropertyDTO selectedPropertyDTO = null;
        if (searchList != null && searchList.Count > 0)
        {
            selectedPropertyDTO = searchList.Find(c => c.Id == Id);
        }
        return selectedPropertyDTO;
    }
    private PropertyDTO getDBPropertyDTO()
    {
        return getSessionPageData().SelectedProperty;
    }
    private long getDeleteRecordHdnId() {
    	string pId = btnDeleteRecordHdnId.Value;
    	btnDeleteRecordHdnId.Value = "";
    	return long.Parse(pId);
    }
    private void loadPropertySearchGrid()
    {
        IList<PropertyDTO> results = propertyBO.fetchPropertyGridData(getUserDefinitionDTO().FirmNumber, getSearchFilter(), getUserDefinitionDTO().FirmMember.Id);
        getSessionPageData().SearchResult = (results != null) ? results.ToList<PropertyDTO>() : new List<PropertyDTO>();
        propertySearchGrid.DataSource = results;
        propertySearchGrid.DataBind();
    }
    private void fetchSelectedProperty(long Id)
    {
        PropertyDTO propertyDTO = null;
        if (isAddMode())
        {
            propertyDTO = populatepropertyDTOAdd();
        }
        else if (isModifyMode() || isViewMode())
        {
            propertyDTO = propertyBO.fetchProperty(Id);
        }
        getSessionPageData().SelectedProperty = propertyDTO;
    }
    private void doViewModifyAction(PropertyPageMode pageMode, long Id)
    {
        initPageInfo(pageMode);
        fetchSelectedProperty(Id);
        populateUIFieldsFromDTO(getDBPropertyDTO());
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            initPageInfo(PropertyPageMode.NONE);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickAddPropertyBtn(object sender, EventArgs e)
    {
        try
        {
            initPageInfo(PropertyPageMode.ADD);
            fetchSelectedProperty(0);
            populateUIFieldsFromDTO(null);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickViewPropertyBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            string selectedId = rd.Attributes["data-pid"];
            doViewModifyAction(PropertyPageMode.VIEW, long.Parse(selectedId));
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyPropertyBtn(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            string selectedId = rd.Attributes["data-pid"];
            doViewModifyAction(PropertyPageMode.MODIFY, long.Parse(selectedId));
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void addOrModifyProperty(object sender, EventArgs e)
    {
        try
        {
            if (validatePropertyAddOrModify())
            {
                PropertyDTO propertyDTO = getDBPropertyDTO();
                populatePropertyDTOFromUI(propertyDTO);
                long Id = propertyDTO.Id;
                if (isAddMode())
                {
                    Id = propertyBO.saveProperty(propertyDTO);
                    propertyDTO.Id = Id;
                    propertyBO.assignPropertyToUser(Id, getUserDefinitionDTO().FirmMember.Id);
                    UserDefinitionDTO userDef = getUserDefinitionDTO();
                    //TODO - When Search and add/modify page will be different then assigned properties will be fetched from CSMaster
                    userDef.AssignedProperties.AddRange(loginBO.getAssignedProperties(userDef.FirmMember.Id));
                    var master = Master as CSMaster;
                    master.initPropertyGrid();
                    setNotyMsg(CommonUtil.getNotySuccessMsg(CommonUtil.getRecordAddSuccessMsg("Property")));
                }
                else if (isModifyMode())
                {
                    propertyBO.updateProperty(propertyDTO);
                    setNotyMsg(CommonUtil.getNotySuccessMsg(CommonUtil.getRecordModifySuccessMsg("Property")));
                }
                initPageInfo(PropertyPageMode.NONE);
                loadPropertySearchGrid();
                drpBO.drpDataBase(drpPropertyNameFilter, DrpDataType.PROPERTY_NAME, getUserDefinitionDTO().Id.ToString(), Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addModifyStep1Error);
        }
    }
    protected void deleteProperty(object sender, EventArgs e)
    {
        try
        {
        	long selectedId = getDeleteRecordHdnId();
    		propertyBO.deleteProperty(selectedId);
            initPageInfo(PropertyPageMode.NONE);
            loadPropertySearchGrid();
            setNotyMsg(CommonUtil.getNotySuccessMsg(CommonUtil.getRecordDeleteSuccessMsg("Property")));
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelProperty(object sender, EventArgs e)
    {
        try
        {
            initPageInfo(PropertyPageMode.NONE);
            loadPropertySearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void goToStep(object sender, EventArgs e)
    {
        try
        {
            LinkButton rd = (LinkButton)sender;
            string stepToJump = rd.Attributes["data-step"];
            List<string> stepsToValidate = CommonUtil.getStepsToValidate(activeStepHdn.Value, stepToJump);
            bool isValid = true;
            foreach (string step in stepsToValidate)
            {
                if (!validateGoToStep(step))
                {
                    isValid = false;
                    break;
                }
            }
            if (isValid)
            {
                setCurrentStep(stepToJump);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    /**
     * Define all validation which will be done before add or Modify property.
     * */
    private bool validatePropertyAddOrModify()
    {
        return validateStep1();
    }
    private bool validateGoToStep(string jumpTo)
    {
        bool isValid = true;
        if (!isViewMode())
        {
            if (jumpTo.Equals(step1))
            {
                isValid = validateStep1();
            }
            else if (jumpTo.Equals(step2))
            {
                isValid = validateStep2();
            }
        }
        return isValid;
    }
    private bool validateStep1()
    {
        bool isValid = validateMandatoryFields(addModifyStep1Error, step1);
        PropertyDTO propertyDTO = getDBPropertyDTO();
        if (propertyDTO.PropertyTowers == null || propertyDTO.PropertyTowers.Count == 0)
        {
            setErrorMessage(Resources.Messages.ATLEAST_ONE_TOWER_REQUIRED, addModifyStep1Error);
            isValid = false;
        }
        if (!isValid)
        {
            activeStepHdn.Value = step1;
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    private bool validateStep2()
    {
        return true;
    }
    private bool validateMandatoryFields(string valGrp, string step)
    {
        Page.Validate(valGrp);
        bool isValid = Page.IsValid;
        if (!isValid)
        {
            if (!string.IsNullOrWhiteSpace(step)) setCurrentStep(step);
        }
        return isValid;
    }
    private void setCurrentStep(string step)
    {
        activeStepHdn.Value = step;
        scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    }
    protected void loadAddressCities(object sender, EventArgs e)
    {
        try
        {
            initCityDrp(drpAddressCity, drpAddressState.Text);
            SetFocus(drpAddressCity);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private PropertyDTO populatepropertyDTOAdd()
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        PropertyDTO propertyDTO = new PropertyDTO();
        propertyDTO.ContactInfo = new ContactInfoDTO();
        propertyDTO.ContactInfo.Contact = "0";
        propertyDTO.ContactInfo.Addresses = new HashSet<AddressDTO>();
        AddressDTO addressDto = new AddressDTO();
        addressDto.PreferredAddress = PreferredAddress.Yes;
        addressDto.AddressType = masterDataBO.getAnyAddressType(userDefDto.FirmNumber);
        propertyDTO.ContactInfo.Addresses.Add(addressDto);
        propertyDTO.PropertyTowers = new HashSet<PropertyTowerDTO>();
        propertyDTO.PropertyTaxDetails = new HashSet<PropertyTaxDetailDTO>();
        propertyDTO.PropertyCharges = new HashSet<PropertyChargeDTO>();
        propertyDTO.DocumentInfo = new DocumentInfoDTO();
        propertyDTO.FirmNumber = userDefDto.FirmNumber;
        propertyDTO.InsertUser = userDefDto.Username;
        return propertyDTO;
    }
    private void populatePropertyDTOFromUI(PropertyDTO propertyDTO)
    {
        UserDefinitionDTO userDefDto = (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
        if (isAddMode()) propertyDTO.Name = txtPropertyName.Text;
        propertyDTO.PropertyType = CommonUIConverter.getMasterControlDTO(drpPropertytype.Text, null);
        propertyDTO.PropertyLocation = CommonUIConverter.getMasterControlDTO(drpPropertyLocation.Text, null);
        propertyDTO.PropertyArea = CommonUtil.getDecimalWithoutExt(txtPropertyArea.Text);
        propertyDTO.EstimatedAmt = CommonUtil.getDecimalWithoutExt(txtTotalEstimation.Text);
        propertyDTO.FirmAccount = CommonUIConverter.getFirmAccountDTO(drpAccount.Text, null);
        AddressDTO addressDto = propertyDTO.ContactInfo.Addresses.First();
        addressDto.AddressLine1 = txtAddressLine1.Text;
        addressDto.AddressLine2 = txtAddressLine2.Text;
        addressDto.Town = txtTown.Text;
        addressDto.City = CommonUIConverter.getCityDTO(drpAddressCity.Text, null);
        addressDto.State = CommonUIConverter.getStateDTO(drpAddressState.Text, null);
        addressDto.Country = CommonUIConverter.getCountryDTO(drpAddressCountry.Text, null);
        addressDto.Pin = txtPin.Text;
        propertyDTO.UpdateUser = userDefDto.Username;
        propertyDTO.DocumentInfo.Description = "Property Documents of :" + propertyDTO.Name;
    }
    private void populateUIFieldsFromDTO(PropertyDTO propertyDTO)
    {
        if (propertyDTO != null) txtPropertyName.Text = propertyDTO.Name; else txtPropertyName.Text = null;
        if (propertyDTO != null && propertyDTO.PropertyType != null) drpPropertytype.Text = propertyDTO.PropertyType.Id.ToString(); else drpPropertytype.ClearSelection();
        if (propertyDTO != null && propertyDTO.PropertyLocation != null) drpPropertyLocation.Text = propertyDTO.PropertyLocation.Id.ToString(); else drpPropertyLocation.ClearSelection();
        if (propertyDTO != null && propertyDTO.PropertyArea != null) txtPropertyArea.Text = propertyDTO.PropertyArea.ToString(); else txtPropertyArea.Text = null;
        if (propertyDTO != null && propertyDTO.EstimatedAmt != null) txtTotalEstimation.Text = propertyDTO.EstimatedAmt.ToString(); else txtTotalEstimation.Text = null;
        if (propertyDTO != null && propertyDTO.FirmAccount != null) drpAccount.Text = propertyDTO.FirmAccount.Id.ToString(); else drpAccount.ClearSelection();
        txtAddressLine1.Text = null;
        txtAddressLine2.Text = null;
        txtTown.Text = null;
        drpAddressCountry.ClearSelection();
        drpAddressState.ClearSelection();
        drpAddressCity.ClearSelection();
        txtPin.Text =null;
        if (propertyDTO != null)
        {
            ISet<AddressDTO> addresses = propertyDTO.ContactInfo.Addresses;
            if (addresses.Count > 0)
            {
                foreach (AddressDTO addressDto in addresses)
                {
                    txtAddressLine1.Text = addressDto.AddressLine1;
                    txtAddressLine2.Text = addressDto.AddressLine2;
                    txtTown.Text = addressDto.Town;
                    drpAddressCountry.Text = addressDto.Country.Id.ToString();
                    drpAddressState.Text = addressDto.State.Id.ToString();
                    initCityDrp(drpAddressCity, drpAddressState.Text);
                    drpAddressCity.Text = addressDto.City.Id.ToString();
                    txtPin.Text = addressDto.Pin;
                }
            }
        }
        populatePropertyTowerGrid(propertyDTO);
        populateTaxDetailGrid(propertyDTO);
        populateChargesDetailGrid(propertyDTO);
    }
    private void enableDisableFormFields()
    {
        if (!PropertyPageMode.NONE.ToString().Equals(pageModeHdn.Value))
        {
            bool viewMode = isViewMode();
            bool isEnabled = !viewMode;
            bool modifyMode = isModifyMode();
            txtPropertyName.ReadOnly = viewMode || modifyMode;
            drpPropertytype.Enabled = isEnabled;
            drpPropertyLocation.Enabled = isEnabled;
            txtPropertyArea.ReadOnly = viewMode;
            txtTotalEstimation.ReadOnly = viewMode;
            drpAccount.Enabled = isEnabled;
            txtAddressLine1.ReadOnly = viewMode;
            txtAddressLine2.ReadOnly = viewMode;
            txtTown.ReadOnly = viewMode;
            drpAddressCountry.Enabled = isEnabled;
            drpAddressState.Enabled = isEnabled;
            drpAddressCity.Enabled = isEnabled;
            txtPin.ReadOnly = viewMode;
        }
    }
    private void populatePropertyTowerGrid(PropertyDTO propertyDTO)
    {
        propertyTowerGrid.DataSource = new List<PropertyTowerDTO>();
        if (propertyDTO != null)
        {
            assignUiIndexToPropertyTower(propertyDTO.PropertyTowers);
            propertyTowerGrid.DataSource = propertyDTO.PropertyTowers;
        }
        propertyTowerGrid.DataBind();
    }
    private void assignUiIndexToPropertyTower(ISet<PropertyTowerDTO> propertyTowerDtos)
    {
        if (propertyTowerDtos != null && propertyTowerDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (PropertyTowerDTO propertyTower in propertyTowerDtos)
            {
                propertyTower.UiIndex = uiIndex++;
                propertyTower.RowInfo = CommonUIConverter.getGridViewRowInfo(propertyTower);
            }
        }
    }
    private void populateTaxDetailGrid(PropertyDTO propertyDTO)
    {
        taxDetailGrid.DataSource = new List<PropertyTaxDetailDTO>();
        if (propertyDTO != null)
        {
            assignUiIndexToTaxDetail(propertyDTO.PropertyTaxDetails);
            taxDetailGrid.DataSource = propertyDTO.PropertyTaxDetails;
        }
        taxDetailGrid.DataBind();
    }

    private void populateChargesDetailGrid(PropertyDTO propertyDTO)
    {
        propertyChargesGrid.DataSource = new List<PropertyChargeDTO>();
        if (propertyDTO != null)
        {
            assignUiIndexToChargesDetail(propertyDTO.PropertyCharges);
            propertyChargesGrid.DataSource = propertyDTO.PropertyCharges;
        }
        propertyChargesGrid.DataBind();
    }

    private void assignUiIndexToTaxDetail(ISet<PropertyTaxDetailDTO> taxDetailDtos)
    {
        if (taxDetailDtos != null && taxDetailDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (PropertyTaxDetailDTO taxDetailDto in taxDetailDtos)
            {
                taxDetailDto.UiIndex = uiIndex++;
                taxDetailDto.RowInfo = CommonUIConverter.getGridViewRowInfo(taxDetailDto);
            }
        }
    }
    private void assignUiIndexToChargesDetail(ISet<PropertyChargeDTO> chargesDetailDtos)
    {
        if (chargesDetailDtos != null && chargesDetailDtos.Count > 0)
        {
            long uiIndex = 1;
            foreach (PropertyChargeDTO chargeDetailDto in chargesDetailDtos)
            {
                chargeDetailDto.UiIndex = uiIndex++;
                chargeDetailDto.RowInfo = CommonUIConverter.getGridViewRowInfo(chargeDetailDto);
            }
        }
    }
    //Filter Criteria - Property Search - Start
    private PropertyFilterDTO getSearchFilter() {
    	return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
    	try
    	{
    		activeModalHdn.Value = SearchFilterModal;
    		PropertyFilterDTO filterDTO = getSearchFilter();
			if (filterDTO.PropertyId > 0) drpPropertyNameFilter.Text = filterDTO.PropertyId.ToString(); else drpPropertyNameFilter.ClearSelection();
			if (filterDTO.Type != null) drpPropertytypeFilter.Text = filterDTO.Type.Id.ToString(); else drpPropertytypeFilter.ClearSelection();
			if (filterDTO.Location != null) drpPropertyLocationFilter.Text = filterDTO.Location.Id.ToString(); else drpPropertyLocationFilter.ClearSelection();
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    protected void applySearchFilterCriteria (object sender, EventArgs e)
    {
    	try
    	{
    		PropertyFilterDTO filterDTO = new PropertyFilterDTO();
    		if(!string.IsNullOrWhiteSpace(drpPropertyNameFilter.Text)) {
    			filterDTO.PropertyId = long.Parse(drpPropertyNameFilter.Text);
    			filterDTO.PropertyName = drpPropertyNameFilter.SelectedItem.Text;
    		}
    		if(!string.IsNullOrWhiteSpace(drpPropertytypeFilter.Text)) {
    			filterDTO.Type = CommonUIConverter.getMasterControlDTO(drpPropertytypeFilter.Text, drpPropertytypeFilter.SelectedItem.Text);
    		}
    		if(!string.IsNullOrWhiteSpace(drpPropertyLocationFilter.Text)) {
    			filterDTO.Location = CommonUIConverter.getMasterControlDTO(drpPropertyLocationFilter.Text, drpPropertyLocationFilter.SelectedItem.Text);
    		}
    		getSessionPageData().FilterDTO = filterDTO;
    		loadPropertySearchGrid();
    		setSearchFilterTokens();
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    protected void clearSearchFilter(object sender, EventArgs e)
    {
    	try
    	{
    	    setSearchFilter(null);
    		loadPropertySearchGrid();
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    private void setSearchFilter(PropertyFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new PropertyFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
    	try
    	{
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            PropertyFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.PROPERTY_NAME))
            {
                filterDTO.PropertyId = 0;
                filterDTO.PropertyName = "";
            }
            else if (token.StartsWith(Constants.FILTER.PROPERTY_TYPE)) filterDTO.Type = null;
            else if (token.StartsWith(Constants.FILTER.PROPERTY_LOCATION)) filterDTO.Location = null;
            setSearchFilterTokens();
            loadPropertySearchGrid();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens() {
    	PropertyFilterDTO filterDTO = getSearchFilter();
    	string filter = "";
    	if (filterDTO.PropertyId > 0) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.PROPERTY_NAME + filterDTO.PropertyName);
        if (filterDTO.Type != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.PROPERTY_TYPE + filterDTO.Type.Name);
        if (filterDTO.Location != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.PROPERTY_LOCATION + filterDTO.Location.Name);
		txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - Property Search - End
    //Master Data Modal save logic - Start
    protected void saveMasterData(object sender, EventArgs e)
    {
    	try
        {
    		String errorMsg = "";
            UserDefinitionDTO userDefDto = getUserDefinitionDTO();
            if (Constants.MCDType.PROPERTY_TYPE.Equals(masterDataModalTypeHdn.Value))
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PROPERTY_TYPE, txtMasterDataInput1.Text,
                       txtMasterDataInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Property Type");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpPropertytype, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    CommonUtil.copyDropDownItems(drpPropertytypeFilter, drpPropertytype);
                }
            }
            else if (Constants.MCDType.PROPERTY_LOCATION.Equals(masterDataModalTypeHdn.Value))
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PROPERTY_LOCATION, txtMasterDataInput1.Text,
                       txtMasterDataInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Property Location");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpPropertyLocation, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_LOCATION, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                    CommonUtil.copyDropDownItems(drpPropertyLocationFilter, drpPropertyLocation);
                }
            }
            else if (Constants.MCDType.PR_TAX_TYPE.Equals(masterDataModalTypeHdn.Value))
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PR_TAX_TYPE, txtMasterDataInput1.Text,
                       txtMasterDataInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Tax Type");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpTaxType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PR_TAX_TYPE, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
            }
            else if (Constants.MCDType.PROPERTY_CHARGES.Equals(masterDataModalTypeHdn.Value))
            {
                MasterControlDataDTO masterDataDto = CommonUIConverter.populateMasterDataDTOAdd(Constants.MCDType.PROPERTY_CHARGES, txtMasterDataInput1.Text,
                       txtMasterDataInput2.Text, userDefDto);
                errorMsg = validateMasterDataModalInput(masterDataDto, "Property Charge Name");
                if (string.IsNullOrWhiteSpace(errorMsg))
                {
                    masterDataBO.saveMasterData(masterDataDto);
                    drpBO.drpDataBase(drpPropertyChargesType, DrpDataType.MASTER_CONTROL_DATA, Constants.MCDType.PROPERTY_CHARGES, Constants.SELECT_ITEM, userDefDto.FirmNumber);
                }
            }
          
            if (!string.IsNullOrWhiteSpace(errorMsg))
            {
            	activeModalHdn.Value = addMasterDataModal;
            	SetFocus(txtMasterDataInput2);
            	setErrorMessage(errorMsg, addMasterDataError);
            }
            else
            {
            	resetMasterDataModalFields();
                setParentModalFlag();
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            activeModalHdn.Value = "";
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    protected void cancelMasterDataModal(object sender, EventArgs e)
    {
    	try {
    		resetMasterDataModalFields();
    		setParentModalFlag();
    	}
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), addMasterDataError);
        }
    }
    private void resetMasterDataModalFields() {
        txtMasterDataInput1.Text = "";
        txtMasterDataInput2.Text = "";
        masterDataModalTypeHdn.Value = "";
    }
    private string validateMasterDataModalInput(MasterControlDataDTO masterDataDto, string type)
    {
        string errorMsg = "";
        if (string.IsNullOrWhiteSpace(masterDataDto.Name))
        {
            errorMsg = string.Format(Resources.Messages.TEXTFIELD_REQUIRED, type);
        }
        else if (masterDataBO.isAlreadyExist(masterDataDto))
        {
            errorMsg = string.Format(Resources.Messages.ALREADY_EXIST_DB_ERROR, type);
        }
        return errorMsg;
    }
    private void setParentModalFlag() {
    	activeModalHdn.Value = masterDataParentModalHdn.Value;
    	masterDataParentModalHdn.Value = "";
    }
    //Master Data Modal save logic - End
    //Property Tower Modal - start
    private void initPropertyTowerModalFields()
    {
        lbPrTowerModalTitle.Text = (PrTowerAction.ADD.ToString().Equals(prTowerModalActionHdnBtn.Value)) 
            ? Constants.ICON.ADD + Resources.Labels.ADD_TOWER : Constants.ICON.MODIFY + Resources.Labels.MODIFY_TOWER;
    }
    private void initPropertyTowerSectionFields(PropertyTowerDTO propertyTowerDto)
    {
        if (propertyTowerDto != null) txtTowerName.Text = propertyTowerDto.Name; else txtTowerName.Text = null;
        if (propertyTowerDto != null) txtTowerLaunchDate.Text = CommonUtil.getCSDate(propertyTowerDto.LaunchDate); else txtTowerLaunchDate.Text = null;
        if (propertyTowerDto != null && propertyTowerDto.Rate != null) txtTowerRate.Text = propertyTowerDto.Rate.ToString(); else txtTowerRate.Text = null;
        if (propertyTowerDto != null) txtTowerDescription.Text = propertyTowerDto.Description; else txtTowerDescription.Text = null;
        if (propertyTowerDto != null) txtTowerPossession.Text = CommonUtil.getCSDate(propertyTowerDto.Possession); else txtTowerPossession.Text = null;
    }
    private void populatePropertyTowerFromUI(PropertyTowerDTO propertyTowerDto)
    {
        propertyTowerDto.Name = txtTowerName.Text;
        propertyTowerDto.LaunchDate = CommonUtil.getCSDate(txtTowerLaunchDate.Text);
        propertyTowerDto.Rate = CommonUtil.getDecimalWithoutExt(txtTowerRate.Text);
        propertyTowerDto.Possession = CommonUtil.getCSDate(txtTowerPossession.Text);
        propertyTowerDto.Description = txtTowerDescription.Text;
        propertyTowerDto.UpdateUser = getUserDefinitionDTO().Username;
    }
    private PropertyTowerDTO populatePropertyTowerAdd()
    {
        PropertyTowerDTO propertyTowerDto = new PropertyTowerDTO();
        UserDefinitionDTO userDef =  getUserDefinitionDTO();
        propertyTowerDto.FirmNumber = userDef.FirmNumber;
        propertyTowerDto.InsertUser = userDef.Username;
        return propertyTowerDto;
    }
    private void setSelectedPrTower(long UiIndex) {
    	List<PropertyTowerDTO> towerList = getDBPropertyDTO().PropertyTowers.ToList<PropertyTowerDTO>();
    	towerList.ForEach(c => c.isUISelected = false);
    	if (UiIndex > 0) towerList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
    }
    private PropertyTowerDTO getSelectedPrTower(long UiIndex)
    {
    	List<PropertyTowerDTO> towerList = getDBPropertyDTO().PropertyTowers.ToList<PropertyTowerDTO>();
    	return (UiIndex > 0) ? towerList.Find(c => c.UiIndex == UiIndex) : towerList.Find(c => c.isUISelected);
    }
    protected void onClickAddPrTowerBtn(object sender, EventArgs e)
    {
    	try
        {
    		prTowerModalActionHdnBtn.Value = PrTowerAction.ADD.ToString();
    		initPropertyTowerModalFields();
            setSelectedPrTower(-1);
            initPropertyTowerSectionFields(null);
            activeModalHdn.Value = addModifyPrTowerModal;
            SetFocus(txtTowerName);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void onClickModifyPrTowerBtn(object sender, EventArgs e)
    {
    	try
        {
    		prTowerModalActionHdnBtn.Value = PrTowerAction.MODIFY.ToString();
    		initPropertyTowerModalFields();
            LinkButton rd = (LinkButton)sender;
            long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
            setSelectedPrTower(selectedIndex);
            initPropertyTowerSectionFields(getSelectedPrTower(0));
            activeModalHdn.Value = addModifyPrTowerModal;
            SetFocus(txtTowerName);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void deletePrTower(object sender, EventArgs e)
    {
    	try
        {
    		long selectedIndex = getDeleteRecordHdnId();
    		PropertyTowerDTO propertyTowerDto = getSelectedPrTower(selectedIndex);
            PropertyDTO propertyDTO = getDBPropertyDTO();
            propertyDTO.PropertyTowers.Remove(propertyTowerDto);
            populatePropertyTowerGrid(propertyDTO);
            setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_DELETED_FROM_TABLE, "Property Tower")));
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void savePrTower(object sender, EventArgs e)
    {
    	try
        {
            if (validatePrTowerAddModify())
            {
            	PropertyTowerDTO propertyTowerDto = null;
                PropertyDTO propertyDTO = getDBPropertyDTO();
                if (PrTowerAction.ADD.ToString().Equals(prTowerModalActionHdnBtn.Value))
                {
                	propertyTowerDto = populatePropertyTowerAdd();
                	propertyDTO.PropertyTowers.Add(propertyTowerDto);
                    setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_ADDED_TO_TABLE, "Property Tower")));
                }
                else
                {
                	propertyTowerDto = getSelectedPrTower(0);
                    setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_MODIFIED_TO_TABLE, "Property Tower")));
                }
                populatePropertyTowerFromUI(propertyTowerDto);
                populatePropertyTowerGrid(propertyDTO);
            }
            else
            {
            	activeModalHdn.Value = addModifyPrTowerModal;
            	SetFocus(txtTowerName);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelPrTowerModal(object sender, EventArgs e)
    {
    	try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validatePrTowerAddModify()
    {
        bool isValid = true;
        Page.Validate(addModifyPrTowerError);
        isValid = Page.IsValid;
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    }
    //Property Tower Modal - End
    //Tax Details Modal - Start
    private void initTaxDetailModalFields()
    {
    	lbTaxDetailModalTitle.Text = (TaxDetailAction.ADD.ToString().Equals(taxDetailModalActionHdnBtn.Value))
            ? Constants.ICON.ADD + Resources.Labels.ADD_TAX : Constants.ICON.MODIFY + Resources.Labels.MODIFY_TAX;
    }
    private void initTaxDetailSectionFields(PropertyTaxDetailDTO taxDetailDto)
    {
        if (taxDetailDto != null) drpTaxType.Text = taxDetailDto.TaxType.Id.ToString(); else drpTaxType.ClearSelection();
        if (taxDetailDto != null) txtTaxRate.Text = taxDetailDto.TaxPercentage.ToString(); else txtTaxRate.Text = null;
        if (taxDetailDto != null) txtTaxLimit.Text = taxDetailDto.TaxAmtLimit.ToString(); else txtTaxLimit.Text = null;
        if (taxDetailDto != null) drpTaxIncludeInPymt.Text = taxDetailDto.IncludeInTotalPymt.ToString(); else drpTaxIncludeInPymt.ClearSelection();
    }
    private void populateTaxDetailFromUI(PropertyTaxDetailDTO taxDetailDto)
    {
        taxDetailDto.TaxType = CommonUIConverter.getMasterControlDTO(drpTaxType.Text, drpTaxType.SelectedItem.Text);
        taxDetailDto.TaxPercentage = CommonUtil.getDecimaNotNulllWithoutExt(txtTaxRate.Text);
        taxDetailDto.TaxAmtLimit = CommonUtil.getDecimaNotNulllWithoutExt(txtTaxLimit.Text);
        taxDetailDto.IncludeInTotalPymt = EnumHelper.ToEnum<IncludeInPymtTotal>(drpTaxIncludeInPymt.Text);
        taxDetailDto.UpdateUser = getUserDefinitionDTO().Username;
    }
    private PropertyTaxDetailDTO populatePropertyTaxDetailAdd()
    {
        PropertyTaxDetailDTO taxDetailDto = new PropertyTaxDetailDTO();
        UserDefinitionDTO userDef = getUserDefinitionDTO();
        taxDetailDto.FirmNumber = userDef.FirmNumber;
        taxDetailDto.InsertUser = userDef.Username;
        return taxDetailDto;
    }
    private void setSelectedTaxDetail(long UiIndex) {
    	List<PropertyTaxDetailDTO> taxDetailList = getDBPropertyDTO().PropertyTaxDetails.ToList<PropertyTaxDetailDTO>();
    	taxDetailList.ForEach(c => c.isUISelected = false);
    	if (UiIndex > 0) taxDetailList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
    }
    private PropertyTaxDetailDTO getSelectedTaxDetail(long UiIndex)
    {
    	List<PropertyTaxDetailDTO> taxDetailList = getDBPropertyDTO().PropertyTaxDetails.ToList<PropertyTaxDetailDTO>();
    	return (UiIndex > 0) ? taxDetailList.Find(c => c.UiIndex == UiIndex) : taxDetailList.Find(c => c.isUISelected);
    }
    protected void onClickAddTaxDetailBtn(object sender, EventArgs e)
    {
    	try
    	{
    		taxDetailModalActionHdnBtn.Value = TaxDetailAction.ADD.ToString();
    		initTaxDetailModalFields();
    		setSelectedTaxDetail(-1);
    		initTaxDetailSectionFields(null);
            activeModalHdn.Value = addModifyTaxDetailModal;
            SetFocus(drpTaxType);
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    protected void onClickModifyTaxDetailBtn(object sender, EventArgs e)
    {
    	try
    	{
    		taxDetailModalActionHdnBtn.Value = TaxDetailAction.MODIFY.ToString();
    		initTaxDetailModalFields();
    		LinkButton rd = (LinkButton)sender;
    		long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
    		setSelectedTaxDetail(selectedIndex);
    		initTaxDetailSectionFields(getSelectedTaxDetail(0));
    		activeModalHdn.Value = addModifyTaxDetailModal;
    		SetFocus(drpTaxType);
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    protected void deleteTaxDetail(object sender, EventArgs e)
    {
    	try
    	{
    		long selectedIndex = getDeleteRecordHdnId();
    		PropertyTaxDetailDTO taxDetailDTO = getSelectedTaxDetail(selectedIndex);
    		PropertyDTO propertyDTO = getDBPropertyDTO();
    		propertyDTO.PropertyTaxDetails.Remove(taxDetailDTO);
    		populateTaxDetailGrid(propertyDTO);
    		setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_DELETED_FROM_TABLE, "Tax Detail")));
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    protected void saveTaxDetail(object sender, EventArgs e)
    {
    	try
    	{
    		if (validateTaxDetailAddModify())
    		{
    			PropertyTaxDetailDTO taxDetailDTO = null;
    			PropertyDTO propertyDTO = getDBPropertyDTO();
    			if (TaxDetailAction.ADD.ToString().Equals(taxDetailModalActionHdnBtn.Value))
    			{
    				taxDetailDTO = populatePropertyTaxDetailAdd();
    				propertyDTO.PropertyTaxDetails.Add(taxDetailDTO);
    				setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_ADDED_TO_TABLE, "Tax Detail")));
    			}
    			else
    			{
    				taxDetailDTO = getSelectedTaxDetail(0);
    				setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_MODIFIED_TO_TABLE, "Tax Detail")));
    			}
                populateTaxDetailFromUI(taxDetailDTO);
    			populateTaxDetailGrid(propertyDTO);
    		}
    		else
    		{
                activeModalHdn.Value = addModifyTaxDetailModal;
                SetFocus(drpTaxType);
    		}
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    protected void cancelTaxDetailModal(object sender, EventArgs e)
    {
    	try
    	{
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    private bool validateTaxDetailAddModify()
    {
    	bool isValid = true;
    	Page.Validate(addModifyTaxDetailError);
    	isValid = Page.IsValid;
    	if (!isValid)
    	{
    		scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    	}
    	return isValid;
    }
   //Tax Details Modal - End
   //Property Charges Modal - Start
    private void initPropertyChargeModalFields()
    {
    	lbPropertyChargeModalTitle.Text = (PropertyChargeAction.ADD.ToString().Equals(propertyChargeModalActionHdnBtn.Value))
            ? Constants.ICON.ADD + Resources.Labels.ADD_CHARGE : Constants.ICON.MODIFY + Resources.Labels.MODIFY_CHARGE;
    }
    private void initPropertyChargeSectionFields(PropertyChargeDTO propertyChargeDto)
    {
    	if (propertyChargeDto != null) drpPropertyChargesType.Text = propertyChargeDto.ChargeType.Id.ToString(); else drpPropertyChargesType.ClearSelection();
        if (propertyChargeDto != null) txtChargesValue.Text = propertyChargeDto.ChargeValue.ToString(); else txtChargesValue.Text = null;
    }
    private void populatePropertyChargeFromUI(PropertyChargeDTO propertyChargeDto)
    {
    	propertyChargeDto.ChargeType = CommonUIConverter.getMasterControlDTO(drpPropertyChargesType.Text, drpPropertyChargesType.SelectedItem.Text);
    	propertyChargeDto.ChargeValue = CommonUtil.getDecimaNotNulllWithoutExt(txtChargesValue.Text);
    	propertyChargeDto.UpdateUser = getUserDefinitionDTO().Username;
    }
    private PropertyChargeDTO populatePropertyChargeAdd()
    {
    	PropertyChargeDTO propertyChargeDto = new PropertyChargeDTO();
    	UserDefinitionDTO userDef = getUserDefinitionDTO();
    	propertyChargeDto.FirmNumber = userDef.FirmNumber;
    	propertyChargeDto.InsertUser = userDef.Username;
    	return propertyChargeDto;
    }
    private void setSelectedPropertyCharge(long UiIndex) {
    	List<PropertyChargeDTO> propertyChargeList = getDBPropertyDTO().PropertyCharges.ToList<PropertyChargeDTO>();
    	propertyChargeList.ForEach(c => c.isUISelected = false);
    	if (UiIndex > 0) propertyChargeList.Find(c => c.UiIndex == UiIndex).isUISelected = true;
    }
    private PropertyChargeDTO getSelectedPropertyCharge(long UiIndex)
    {
    	List<PropertyChargeDTO> propertyChargeList = getDBPropertyDTO().PropertyCharges.ToList<PropertyChargeDTO>();
    	return (UiIndex > 0) ? propertyChargeList.Find(c => c.UiIndex == UiIndex) : propertyChargeList.Find(c => c.isUISelected);
    }
    protected void onClickAddPropertyChargeBtn(object sender, EventArgs e)
    {
    	try
    	{
    		propertyChargeModalActionHdnBtn.Value = PropertyChargeAction.ADD.ToString();
    		initPropertyChargeModalFields();
    		setSelectedPropertyCharge(-1);
    		initPropertyChargeSectionFields(null);
            activeModalHdn.Value = addModifyPropertyChargeModal;
            SetFocus(txtChargesValue);
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    protected void onClickModifyPropertyChargeBtn(object sender, EventArgs e)
    {
    	try
    	{
    		propertyChargeModalActionHdnBtn.Value = PropertyChargeAction.MODIFY.ToString();
    		initPropertyChargeModalFields();
    		LinkButton rd = (LinkButton)sender;
    		long selectedIndex = long.Parse(rd.Attributes["data-pid"]);
    		setSelectedPropertyCharge(selectedIndex);
    		initPropertyChargeSectionFields(getSelectedPropertyCharge(0));
            activeModalHdn.Value = addModifyPropertyChargeModal;
            SetFocus(txtChargesValue);
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    protected void deletePropertyCharge(object sender, EventArgs e)
    {
    	try
    	{
    		long selectedIndex = getDeleteRecordHdnId();
    		PropertyChargeDTO propertyChargeDTO = getSelectedPropertyCharge(selectedIndex);
    		PropertyDTO propertyDTO = getDBPropertyDTO();
    		propertyDTO.PropertyCharges.Remove(propertyChargeDTO);
            populateChargesDetailGrid(propertyDTO);
    		setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_DELETED_FROM_TABLE, "Property Charge")));
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    protected void savePropertyCharge(object sender, EventArgs e)
    {
    	try
    	{
    		if (validatePropertyChargeAddModify())
    		{
    			PropertyChargeDTO propertyChargeDTO = null;
    			PropertyDTO propertyDTO = getDBPropertyDTO();
    			if (PropertyChargeAction.ADD.ToString().Equals(propertyChargeModalActionHdnBtn.Value))
    			{
    				propertyChargeDTO = populatePropertyChargeAdd();
    				propertyDTO.PropertyCharges.Add(propertyChargeDTO);
    				setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_ADDED_TO_TABLE, "Property Charge")));
    			}
    			else
    			{
    				propertyChargeDTO = getSelectedPropertyCharge(0);
    				setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECOED_MODIFIED_TO_TABLE, "Property Charge")));
    			}
                populatePropertyChargeFromUI(propertyChargeDTO);
    			populateChargesDetailGrid(propertyDTO);
    		}
    		else
    		{
                activeModalHdn.Value = addModifyPropertyChargeModal;
                SetFocus(txtChargesValue);
    		}
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    protected void cancelPropertyChargeModal(object sender, EventArgs e)
    {
    	try
    	{
    	}
    	catch (Exception exp)
    	{
    		log.Error(exp.Message, exp);
    		setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
    	}
    }
    private bool validatePropertyChargeAddModify()
    {
    	bool isValid = true;
    	Page.Validate(addModifyPropertyChargeError);
    	isValid = Page.IsValid;
    	if (!isValid)
    	{
    		scrollToFieldHdn.Value = Constants.SCROLL_TOP;
    	}
    	return isValid;
    }
   //Property Charges Modal - End
   //Add Account Modal - Start
    private void initAccountModalFields()
    {
        lbAccountModalTitle.Text = (AccountAction.ADD.ToString().Equals(accountModalActionHdnBtn.Value)) ? Constants.ICON.ADD + Resources.Labels.ADD_ACCOUNT : "";
    }
    private void initAccountSectionFields(FirmAccountDTO accountDto)
    {
        if(accountDto != null) txtAcntName.Text = accountDto.Name; else txtAcntName.Text = null;
        if(accountDto != null) drpAcntType.Text = accountDto.AccountType.Id.ToString(); else drpAcntType.ClearSelection();
        if(accountDto != null) txtAcntNumber.Text = accountDto.AccountNo; else txtAcntNumber.Text = null;
        if(accountDto != null) txtAcntIFSCCode.Text = accountDto.IfscCode; else txtAcntIFSCCode.Text = null;
        if(accountDto != null) txtAcntBankName.Text = accountDto.BankName; else txtAcntBankName.Text = null;
        if(accountDto != null) txtAcntBranch.Text = accountDto.Branch; else txtAcntBranch.Text = null;
        if(accountDto != null && accountDto.City != null) drpAcntCity.Text = accountDto.City.Id.ToString(); else drpAcntCity.ClearSelection();
        if(accountDto != null && accountDto.State != null) drpAcntState.Text = accountDto.State.Id.ToString(); else drpAcntState.ClearSelection();
        if(accountDto != null && accountDto.Country != null) drpAcntCountry.Text = accountDto.Country.Id.ToString(); else drpAcntCountry.ClearSelection();
        drpAcntState.Text = Constants.DEFAULT_STATE;
        initCityDrp(drpAcntCity, Constants.DEFAULT_STATE);
    }
    private void populateAccountFromUI(FirmAccountDTO accountDto)
    {
        accountDto.Name = txtAcntName.Text;
        accountDto.AccountType = CommonUIConverter.getMasterControlDTO(drpAcntType.Text, drpAcntType.SelectedItem.Text);
        accountDto.AccountNo = txtAcntNumber.Text;
        accountDto.IfscCode = txtAcntIFSCCode.Text;
        accountDto.BankName = txtAcntBankName.Text;
        accountDto.Branch = txtAcntBranch.Text;
        accountDto.City = CommonUIConverter.getCityDTO(drpAcntCity.Text, drpAcntCity.SelectedItem.Text);
        accountDto.State = CommonUIConverter.getStateDTO(drpAcntState.Text, drpAcntState.SelectedItem.Text);
        accountDto.Country = CommonUIConverter.getCountryDTO(drpAcntCountry.Text, drpAcntCountry.SelectedItem.Text);
        accountDto.UpdateUser = getUserDefinitionDTO().Username;
    }
    private FirmAccountDTO populateAccountAdd()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        FirmAccountDTO accountDto = new FirmAccountDTO();
        populateAccountFromUI(accountDto);
        accountDto.FirmNumber = userDefDto.FirmNumber;
        accountDto.InsertUser = userDefDto.Username;
        return accountDto;
    }
    protected void onClickAddAccountBtn(object sender, EventArgs e)
    {
        try
        {
            accountModalActionHdnBtn.Value = AccountAction.ADD.ToString();
            initAccountModalFields();
            initAccountSectionFields(null);
            activeModalHdn.Value = addAccountModal;
            SetFocus(txtAcntName);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void addNewAccount(object sender, EventArgs e)
    {
        try
        {
            if (validateAccountAdd())
            {
                FirmAccountDTO accountDTO = populateAccountAdd();
                firmBO.saveFirmAccount(accountDTO);
                drpBO.drpDataBase(drpAccount, DrpDataType.FIRM_ACCOUNT, null, Constants.SELECT_ITEM, getUserDefinitionDTO().FirmNumber);
                setNotyMsg(CommonUtil.getNotySuccessMsg(string.Format(Resources.Messages.RECORD_ADDED_DB_SUCCESS, "Account")));
            }
            else
            {
                activeModalHdn.Value = addAccountModal;
                SetFocus(txtAcntName);
            }
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void cancelAccountModal(object sender, EventArgs e)
    {
        try
        {
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void loadAcntCities(object sender, EventArgs e)
    {
        try
        {
            initCityDrp(drpAcntCity, drpAcntState.Text);
            activeModalHdn.Value = addAccountModal;
            SetFocus(drpAcntCity);
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private bool validateAccountAdd()
    {
        bool isValid = true;
        Page.Validate(addAccountError);
        isValid = Page.IsValid;
        if (!isValid)
        {
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        }
        return isValid;
    } 
   //Add Account Modal - End
}
