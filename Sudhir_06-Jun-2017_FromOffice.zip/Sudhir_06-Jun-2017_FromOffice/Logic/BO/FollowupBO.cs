﻿using NHibernate;
using NHibernate.Criterion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ConstroSoft.Logic.BO
{
    public class FollowupBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public FollowupBO() { }

        public IList<FollowupDetailDTO> fetchCustomerGridData(string firmNumber, FollowupSearchBy searchBy, long searchByValue)
        {
            ISession session = null;
            IList<FollowupDetailDTO> result = new List<FollowupDetailDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                Customer cm = null;
                ContactInfo c = null;
                FollowupDetailDTO fdto = null;
                var proj = Projections.ProjectionList()
                           .Add(Projections.Property(() => cm.Id).WithAlias(() => fdto.Id))
                           .Add(Projections.SqlFunction("concat",
                                       NHibernateUtil.String,
                                       Projections.Property(() => cm.FirstName),
                                       Projections.Constant(" "),
                                       Projections.Property(() => cm.LastName)
                                   ).WithAlias(() => cm.FirstName))
                           .Add(Projections.Property(() => c.Contact), "ContactInfo.Contact")
                           .Add(Projections.Property(() => c.Email), "ContactInfo.Email");

                var query = session.QueryOver<Customer>(() => cm)
                    .Inner.JoinAlias(() => cm.ContactInfo, () => c);

                if (FollowupSearchBy.NONE != searchBy && searchByValue != -1)
                {
                    PropertyProjection prop = null;
                    if (FollowupSearchBy.Customer_Name == searchBy)
                    {
                        prop = CommonUtil.BuildProjection<Customer>(() => cm, x => x.Id);
                    }
                    query.Where(Restrictions.Eq(prop, searchByValue));
                }
                result = query.Where(() => cm.FirmNumber == firmNumber)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<FollowupDetailDTO>()).List<FollowupDetailDTO>();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating follow up grid from customer:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public IList<FollowupDetailDTO> fetchEnquiryGridData(string firmNumber, FollowupSearchBy searchBy, long searchByValue)
        {
            ISession session = null;
            IList<FollowupDetailDTO> results = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                EnquiryDetail ed = null;
                ContactInfo c = null;
                FirmMember fm = null;
                FollowupDetailDTO enDto = null;

                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => ed.Id).WithAlias(() => enDto.Id))
                            .Add(Projections.SqlFunction("concat",
                                        NHibernateUtil.String,
                                        Projections.Property(() => ed.FirstName),
                                        Projections.Constant(" "),
                                        Projections.Property(() => ed.LastName)
                                    ).WithAlias(() => ed.FirstName))
                            .Add(Projections.Property(() => c.Contact), "ContactInfo.Contact")
                            .Add(Projections.Property(() => c.Email), "ContactInfo.Email");
                var query = session.QueryOver<EnquiryDetail>(() => ed)
                    .Inner.JoinAlias(() => ed.ContactInfo, () => c);
                if (FollowupSearchBy.NONE != searchBy && searchByValue != -1)
                {
                    PropertyProjection prop = null;
                    if (FollowupSearchBy.Enquiry_Name == searchBy)
                    {
                        prop = CommonUtil.BuildProjection<EnquiryDetail>(() => ed, x => x.Id);
                    }
                    query.Where(Restrictions.Eq(prop, searchByValue));
                }
                results = query.Where(() => ed.FirmNumber == firmNumber)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<FollowupDetailDTO>()).List<FollowupDetailDTO>();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating follow up grid from enquiry:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }
    }
}