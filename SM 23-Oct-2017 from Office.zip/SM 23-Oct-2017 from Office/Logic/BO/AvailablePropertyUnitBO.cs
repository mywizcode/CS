﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq.Expressions;
using NHibernate.Impl;
using System.Linq;
using System.Net.Mail;
using System.Net.Mime;
using System.IO;

/// <summary>
/// Summary description for propertyBO
/// </summary>
namespace ConstroSoft
{
    public class AvailablePropertyUnitBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
       
        public AvailablePropertyUnitBO() { }
        public IList<PropertyUnitDTO> fetchAvailablePropertyUnits(string firmNumber, long propertyTowerId, PropertyUnitFilterDTO filterDTO)
        {
            ISession session = null;
            IList<PropertyUnitDTO> result = new List<PropertyUnitDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit pu = null;
                        PropertyTower pt = null;
                        MasterControlData unitType = null;
                        MasterControlData dir = null;
                        MasterControlData facing = null;

                        PropertyUnitDTO pudto = null;

                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => pu.Id).WithAlias(() => pudto.Id))
                                    .Add(Projections.Property(() => pt.Id), "PropertyTower.Id")
                                    .Add(Projections.Property(() => pu.UnitNo).WithAlias(() => pudto.UnitNo))
                                    .Add(Projections.Property(() => pu.Wing).WithAlias(() => pudto.Wing))
                                    .Add(Projections.Property(() => pu.FloorNo).WithAlias(() => pudto.FloorNo))
                                    .Add(Projections.Property(() => unitType.Id), "UnitType.Id")
                                    .Add(Projections.Property(() => unitType.Name), "UnitType.Name")
                                    .Add(Projections.Property(() => pu.BuildupArea).WithAlias(() => pudto.BuildupArea))
                                    .Add(Projections.Property(() => pu.CarpetArea).WithAlias(() => pudto.CarpetArea))
                                    .Add(Projections.Property(() => pu.BalconyArea).WithAlias(() => pudto.BalconyArea))
                                    .Add(Projections.Property(() => pu.NoOfBalcony).WithAlias(() => pudto.NoOfBalcony))
                                    .Add(Projections.Property(() => dir.Id), "Direction.Id")
                                    .Add(Projections.Property(() => dir.Name), "Direction.Name")
                                    .Add(Projections.Property(() => facing.Id), "Facing.Id")
                                    .Add(Projections.Property(() => facing.Name), "Facing.Name");
                        var query = session.QueryOver<PropertyUnit>(() => pu)
                            .Left.JoinAlias(() => pu.PropertyTower, () => pt)
                            .Left.JoinAlias(() => pu.UnitType, () => unitType)
                            .Left.JoinAlias(() => pu.Direction, () => dir)
                            .Left.JoinAlias(() => pu.Facing, () => facing);
                        if (filterDTO != null)
                        {
                            ICriteria criteria = query.RootCriteria;
                            if (filterDTO.UnitId > 0)
                            {
                                criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<PropertyUnit>(() => pu, x => x.Id), filterDTO.UnitId));
                            }
                            if (filterDTO.UnitType != null)
                            {
                                criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<MasterControlData>(() => unitType, x => x.Id), filterDTO.UnitType.Id));
                            }
                            if (!string.IsNullOrWhiteSpace(filterDTO.Wing))
                            {
                                criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<PropertyUnit>(() => pu, x => x.Wing), filterDTO.Wing));
                            }
                            if (!string.IsNullOrWhiteSpace(filterDTO.FloorNo))
                            {
                                criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<PropertyUnit>(() => pu, x => x.FloorNo), filterDTO.FloorNo));
                            }
                        }
                        result = query.Where(() => pu.FirmNumber == firmNumber && pt.Id == propertyTowerId && pu.Status == PRUnitStatus.Available)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<PropertyUnitDTO>()).List<PropertyUnitDTO>();
                        result.ToList().ForEach(x => x.UnitNo
                                = CommonUIConverter.getPropertyUnitFormattedNo(x.Wing, x.UnitNo));
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching Available property units :", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public long bookPropertyUnitDetails(PrUnitSaleDetailDTO prUnitSaleDetailDto, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                PrUnitSaleDetail prUnitSaleDetail = null;
                PropertyUnit propertyUnit = null;
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	//Update Property Unit Status as Sold
                        propertyUnit = session.Get<PropertyUnit>(prUnitSaleDetailDto.PropertyUnit.Id);
                        propertyUnit.Status = PRUnitStatus.Sold;
                        session.Update(propertyUnit);
                        prUnitSaleDetail = DTOToDomainUtil.populatePrUnitSaleDetailAddFields(prUnitSaleDetailDto);
                        Customer customer = null;
                        //Add or Update Customer.
                        if(prUnitSaleDetailDto.Customer.Id == 0) {
                        	customer = DTOToDomainUtil.populateCustomerAddFields(prUnitSaleDetailDto.Customer);
                            Random rd = new Random();
                            customer.CustRefNo = "CUST" + rd.Next(100, 10000);
                            session.Save(customer);
                            customer.CustRefNo = CommonUtil.getCustomerRefNo(customer.Id);
                            prUnitSaleDetailDto.Customer.Id = customer.Id;
                        } else {
                        	customer = session.Get<Customer>(prUnitSaleDetailDto.Customer.Id);
                        	DTOToDomainUtil.populateCustomerUpdateFields(customer, prUnitSaleDetailDto.Customer);
                        }
                        session.Update(customer);
                        prUnitSaleDetail.Customer = customer;
                        session.Save(prUnitSaleDetail);
                        Id = prUnitSaleDetail.Id;
                        prUnitSaleDetail.BookingRefNo = CommonUtil.getBookingRefNo(prUnitSaleDetailDto.PropertyUnit.PropertyTower.Property.Name, 
                                prUnitSaleDetailDto.PropertyUnit.PropertyTower.Name, Id);
                        session.Update(prUnitSaleDetail);
                        //If Booking is through Enquiry then update EnquiryDetail and add activity action
                        if (prUnitSaleDetailDto.Enquiry != null && prUnitSaleDetailDto.Enquiry.Id > 0) {
                            EnquiryDetail enquiry = session.Get<EnquiryDetail>(prUnitSaleDetailDto.Enquiry.Id);
                            enquiry.Status = EnquiryStatus.Won;
                            session.Update(enquiry);
                            EnquiryActivity activity = CommonUtil.getEnquiryActivityAction(enquiry.Id, EnqActivityType.WON, "", 
                                prUnitSaleDetailDto.BookingDate, userDefDTO);
                            session.Save(activity);
                        }
                        //Update Parkign status.
                        if (prUnitSaleDetailDto.PrParkings != null && prUnitSaleDetailDto.PrParkings.Count > 0)
                        {
                            foreach (PropertyParkingDTO prPardingDto in prUnitSaleDetailDto.PrParkings)
                            {
                                PropertyParking parking = session.Get<PropertyParking>(prPardingDto.Id);
                                parking.Status = ParkingStatus.Allotted;
                                parking.PrUnitSaleDetail = prUnitSaleDetail;
                                session.Update(parking);
                            }
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Booking Property Unit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
                sendSMSEmail(prUnitSaleDetail, propertyUnit);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        /**
         * This method will check Email & SMS configuration for Sales Function. 
         * If Email & SMS alerts are enabled then system will send Email & SMS to Customer.
         * */
        private static void sendSMSEmail(PrUnitSaleDetail prUnitSaleDetail, PropertyUnit propertyUnit)
        {
            try
            {
                PropertyAlertConfig emailSmsAlertConfig = EmailUtil.loadEmailSmsAlertConfiguration(prUnitSaleDetail.FirmNumber,
                    FunctionName.SALE.ToString(), EmailSmsType.SALESTHANKS.ToString(), propertyUnit.PropertyTower.Property.Id);
                PropertyDTO propertyDTO;
                CustomerDTO customerDTO;
                if (emailSmsAlertConfig != null && emailSmsAlertConfig.Email.Equals(Constants.YES))
                {
                    populateCustomerandProperty(prUnitSaleDetail, propertyUnit, out propertyDTO, out customerDTO);
                    emailSmsAlertConfig.EmailBody = populateBody(prUnitSaleDetail, propertyUnit, emailSmsAlertConfig, propertyDTO.Name, customerDTO);
                    EmailUtil.sendHtmlFormattedEmail(prUnitSaleDetail.FirmNumber, emailSmsAlertConfig, customerDTO.ContactInfo.Email);
                }
                if (emailSmsAlertConfig != null && emailSmsAlertConfig.Sms.Equals(Constants.YES))
                {
                    populateCustomerandProperty(prUnitSaleDetail, propertyUnit, out propertyDTO, out customerDTO);
                    emailSmsAlertConfig.SmsContent = populateSMSBody(prUnitSaleDetail, propertyUnit, emailSmsAlertConfig, propertyDTO.Name, customerDTO);
                    EmailUtil.sendSMS(prUnitSaleDetail.FirmNumber, emailSmsAlertConfig, customerDTO.ContactInfo.Contact);
                }
            }
            catch (Exception e)
            {
                log.Error("Exception while sending Email & SMS alert for booking:", e);
            }
        }

        private static void populateCustomerandProperty(PrUnitSaleDetail prUnitSaleDetail, PropertyUnit propertyUnit,
            out PropertyDTO propertyDTO, out CustomerDTO customerDTO)
        {
            PropertyBO propertyBO = new PropertyBO();
            CustomerBO customerBO = new CustomerBO();
            propertyDTO = propertyBO.fetchProperty(propertyUnit.PropertyTower.Property.Id);
            customerDTO = customerBO.fetchCustomer(prUnitSaleDetail.Customer.Id);
        }
        private static string populateBody(PrUnitSaleDetail prUnitSaleDetail, PropertyUnit propertyUnit, PropertyAlertConfig emailSmsAlertConfig, string name, CustomerDTO customerDTO)
        {
        	string body = string.Empty;
            using (StreamReader reader = new StreamReader(System.Web.HttpContext.Current.Server.MapPath(emailSmsAlertConfig.EmailTemplatePath)))
            {
                body = reader.ReadToEnd();
            }
            body = body.Replace("{UserName}", customerDTO.Salutation.Name + " " + customerDTO.FirstName + " " + customerDTO.LastName);
            body = body.Replace("{UnitNumber}", CommonUIConverter.getPropertyUnitFormattedNo(propertyUnit.Wing, propertyUnit.UnitNo));
            body = body.Replace("{ProjectName}",  name);
            return body;
        }
        private static string populateSMSBody(PrUnitSaleDetail prUnitSaleDetail, PropertyUnit propertyUnit, PropertyAlertConfig emailSmsAlertConfig, string name, CustomerDTO customerDTO)
        {
            string body = string.Empty;
            body = emailSmsAlertConfig.SmsContent.Replace("{UserName}", customerDTO.Salutation.Name + " " + customerDTO.FirstName + " " + customerDTO.LastName);
            body = body.Replace("{UnitNumber}", CommonUIConverter.getPropertyUnitFormattedNo(propertyUnit.Wing, propertyUnit.UnitNo));
            body = body.Replace("{ProjectName}", name);
            return body;
        }
    }
}