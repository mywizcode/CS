﻿using System;
using NHibernate;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using ConstroSoft;
using System.Collections.Generic;
using NHibernate.Criterion;
using NHibernate.Transform;
using System.Net.Mail;
using System.Net.Mime;

/// <summary>
/// Summary description for SupplierBO
/// </summary>
namespace ConstroSoft
{
    public class EnquiryBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public EnquiryBO() { }

        public IList<EnquiryDetailDTO> fetchEnquiryGridData(long propertyId, long assigneeId, EnquiryFilterDTO filterDTO)
        {
            ISession session = null;
            IList<EnquiryDetailDTO> results = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                EnquiryDetail ed = null;
                ContactInfo c = null;
                Property p = null;
                EnquiryDetailDTO enDto = null;
                MasterControlData src = null;
                MasterControlData salutation = null;
                LeadDetail ld = null;
                FirmMember fm = null;

                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => ed.Id).WithAlias(() => enDto.Id))
                            .Add(Projections.Property(() => ed.EnquiryRefNo).WithAlias(() => enDto.EnquiryRefNo))
                            .Add(Projections.Property(() => salutation.Name), "Salutation.Name")
                            .Add(Projections.Property(() => ed.FirstName).WithAlias(() => enDto.FirstName))
                            .Add(Projections.Property(() => ed.MiddleName).WithAlias(() => enDto.MiddleName))
                            .Add(Projections.Property(() => ed.LastName).WithAlias(() => enDto.LastName))
                            .Add(Projections.Property(() => c.Contact), "ContactInfo.Contact")
                            .Add(Projections.Property(() => c.AltContact), "ContactInfo.AltContact")
                            .Add(Projections.Property(() => c.Email), "ContactInfo.Email")
                            .Add(Projections.Property(() => ed.EnquiryDate).WithAlias(() => enDto.EnquiryDate))
                            .Add(Projections.Property(() => src.Name), "EnquirySource.Name")
                            .Add(Projections.Property(() => ed.AssignedDate).WithAlias(() => enDto.AssignedDate))
                            .Add(Projections.Property(() => ed.Budget).WithAlias(() => enDto.Budget))
                            .Add(Projections.Property(() => ed.Status).WithAlias(() => enDto.Status))
                            .Add(Projections.Property(() => ld.LeadRefNo), "Lead.LeadRefNo")
                            .Add(Projections.Property(() => ed.Status).WithAlias(() => enDto.Status));
                var query = session.QueryOver<EnquiryDetail>(() => ed)
                    .Inner.JoinAlias(() => ed.ContactInfo, () => c)
                    .Inner.JoinAlias(() => ed.Property, () => p)
                    .Inner.JoinAlias(() => ed.EnquirySource, () => src)
                    .Inner.JoinAlias(() => ed.Salutation, () => salutation)
                    .Inner.JoinAlias(() => ed.Assignee, () => fm)
                    .Left.JoinAlias(() => ed.Lead, () => ld);
                if (filterDTO != null)
                {
                    ICriteria criteria = query.RootCriteria;
                    if (!string.IsNullOrWhiteSpace(filterDTO.FirstName))
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<EnquiryDetail>(() => ed, x => x.FirstName), filterDTO.FirstName));
                    }
                    if (!string.IsNullOrWhiteSpace(filterDTO.LastName))
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<EnquiryDetail>(() => ed, x => x.LastName), filterDTO.LastName));
                    }
                    if (!string.IsNullOrWhiteSpace(filterDTO.EnquiryRefNo))
                    {
                        criteria.Add(Restrictions.InsensitiveLike(CommonUtil.BuildProjection<EnquiryDetail>(() => ed, x => x.EnquiryRefNo), filterDTO.EnquiryRefNo, MatchMode.Start));
                    }
                    if (!string.IsNullOrWhiteSpace(filterDTO.Contact))
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<ContactInfo>(() => c, x => x.Contact), filterDTO.Contact));
                    }
                    if (filterDTO.SourceId > 0)
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<MasterControlData>(() => src, x => x.Id), filterDTO.SourceId));
                    }
                    if (filterDTO.Status != null)
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<EnquiryDetail>(() => ed, x => x.Status), filterDTO.Status));
                    }
                }
                results = query.Where(() => p.Id == propertyId && fm.Id == assigneeId)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<EnquiryDetailDTO>()).List<EnquiryDetailDTO>();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating enquiry grid:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }
        public IList<LeadDetailDTO> fetchMyLeadsGridData(long propertyId, long AssigneeId, LeadFilterDTO filterDTO)
        {
            ISession session = null;
            IList<LeadDetailDTO> results = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	ContactInfo c = null;
                        MasterControlData src = null;
                        MasterControlData sal = null;
                        LeadDetail ld = null;
                        FirmMember fm = null;
                        Property p = null;
                        EnquiryDetail ed = null;
                        
                        LeadDetailDTO ldDto = null;

                        var proj = Projections.ProjectionList()
                                    .Add(Projections.Property(() => ld.Id).WithAlias(() => ldDto.Id))
                                    .Add(Projections.Property(() => ld.LeadRefNo).WithAlias(() => ldDto.LeadRefNo))
                                    .Add(Projections.Property(() => sal.Name), "Salutation.Name")
                                    .Add(Projections.Property(() => ld.FirstName).WithAlias(() => ldDto.FirstName))
                                    .Add(Projections.Property(() => ld.MiddleName).WithAlias(() => ldDto.MiddleName))
                                    .Add(Projections.Property(() => ld.LastName).WithAlias(() => ldDto.LastName))
                                    .Add(Projections.Property(() => c.Contact), "ContactInfo.Contact")
                                    .Add(Projections.Property(() => c.AltContact), "ContactInfo.AltContact")
                                    .Add(Projections.Property(() => c.Email), "ContactInfo.Email")
                                    .Add(Projections.Property(() => ld.LeadDate).WithAlias(() => ldDto.LeadDate))
                                    .Add(Projections.Property(() => src.Id), "Source.Id")
                                    .Add(Projections.Property(() => src.Name), "Source.Name")
                                    .Add(Projections.Property(() => ld.AssignedDate).WithAlias(() => ldDto.AssignedDate))
                                    .Add(Projections.Property(() => ld.Budget).WithAlias(() => ldDto.Budget))
                                    .Add(Projections.Property(() => ld.Status).WithAlias(() => ldDto.Status))
                                    .Add(Projections.Property(() => ed.Id), "EnquiryDetail.Id")
                                    .Add(Projections.Property(() => ed.EnquiryRefNo), "EnquiryDetail.EnquiryRefNo");
                        var query = session.QueryOver<LeadDetail>(() => ld)
                            .Inner.JoinAlias(() => ld.ContactInfo, () => c)
                            .Inner.JoinAlias(() => ld.Salutation, () => sal)
                            .Inner.JoinAlias(() => ld.Source, () => src)
                            .Inner.JoinAlias(() => ld.Assignee, () => fm)
                            .Inner.JoinAlias(() => ld.Property, () => p)
                            .Left.JoinAlias(() => ld.EnquiryDetail, () => ed);
                        if (filterDTO != null)
                        {
                            ICriteria criteria = query.RootCriteria;
                            if (!string.IsNullOrWhiteSpace(filterDTO.FirstName))
                            {
                                criteria.Add(Restrictions.InsensitiveLike(CommonUtil.BuildProjection<LeadDetail>(() => ld, x => x.FirstName), filterDTO.FirstName, MatchMode.Start));
                            }
                            if (!string.IsNullOrWhiteSpace(filterDTO.LastName))
                            {
                                criteria.Add(Restrictions.InsensitiveLike(CommonUtil.BuildProjection<LeadDetail>(() => ld, x => x.LastName), filterDTO.LastName, MatchMode.Start));
                            }
                            if (!string.IsNullOrWhiteSpace(filterDTO.LeadRefNo))
                            {
                                criteria.Add(Restrictions.InsensitiveLike(CommonUtil.BuildProjection<LeadDetail>(() => ld, x => x.LeadRefNo), filterDTO.LeadRefNo, MatchMode.Start));
                            }
                            if (!string.IsNullOrWhiteSpace(filterDTO.Contact))
                            {
                                criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<ContactInfo>(() => c, x => x.Contact), filterDTO.Contact));
                            }
                            if (filterDTO.SourceId > 0)
                            {
                                criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<MasterControlData>(() => src, x => x.Id), filterDTO.SourceId));
                            }
                            if (filterDTO.Status != null)
                            {
                                criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<LeadDetail>(() => ld, x => x.Status), filterDTO.Status));
                            }
                        }
                        results = query.Where(() => p.Id == propertyId && fm.Id == AssigneeId)
                            .Select(proj)
                            .TransformUsing(new DeepTransformer<LeadDetailDTO>()).List<LeadDetailDTO>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Leads assigned to user:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }
        public List<AllEnquiryLeadUIDTO> fetchAllEnquiryLeadData(long propertyId)
        {
            ISession session = null;
            List<AllEnquiryLeadUIDTO> resultList = new List<AllEnquiryLeadUIDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        string sqlQuery = "SELECT 'LEAD' AS RD_TYPE, FM.ID, FM.FIRST_NAME, FM.LAST_NAME, CI.CONTACT, CI.EMAIL, UD.STATUS AS USER_STATUS, PFA.HAS_ACCESS, "
                                + " COUNT(case when LD.STATUS = 'O' then 1 end) AS OPEN_EL, COUNT(case when LD.STATUS = 'C' then 1 end) AS WON_EL, "
                                + " COUNT(case when LD.STATUS = 'L' then 1 end) AS LOST_EQ FROM FIRM_MEMBER FM INNER JOIN USER_DEFINITION UD "
                                + " ON UD.FIRM_MEMBER_ID = FM.ID INNER JOIN PROPERTY_FM_ACCESS PFA ON PFA.FIRM_MEMBER_ID = FM.ID AND PFA.PROPERTY_ID = :propertyId "
                                + " INNER JOIN CONTACT_INFO CI ON FM.CONTACT_INFO_ID = CI.ID LEFT JOIN LEAD_DETAILS LD "
                                + " ON LD.ASSIGNEE = FM.ID AND LD.PROPERTY = :propertyId GROUP BY FM.ID, FM.FIRST_NAME, FM.LAST_NAME, CI.CONTACT, CI.EMAIL, UD.STATUS, PFA.HAS_ACCESS "
                                + " UNION "
                                + " SELECT 'ENQUIRY'AS RD_TYPE, FM.ID, FM.FIRST_NAME, FM.LAST_NAME, CI.CONTACT, CI.EMAIL, UD.STATUS AS USER_STATUS, PFA.HAS_ACCESS, "
                                + " COUNT(case when ED.STATUS = 'O' then 1 end) AS OPEN_EL, COUNT(case when ED.STATUS = 'W' then 1 end) AS WON_EL,  "
                                + " COUNT(case when ED.STATUS = 'L' then 1 end) AS LOST_EL FROM FIRM_MEMBER FM INNER JOIN USER_DEFINITION UD "
                                + " ON UD.FIRM_MEMBER_ID = FM.ID INNER JOIN PROPERTY_FM_ACCESS PFA ON PFA.FIRM_MEMBER_ID = FM.ID AND PFA.PROPERTY_ID = :propertyId "
                                + " INNER JOIN CONTACT_INFO CI ON FM.CONTACT_INFO_ID = CI.ID LEFT JOIN ENQUIRY_DETAILS ED"
                                + " ON ED.ASSIGNEE = FM.ID AND ED.PROPERTY = :propertyId GROUP BY FM.ID, FM.FIRST_NAME, FM.LAST_NAME, CI.CONTACT, CI.EMAIL, UD.STATUS, PFA.HAS_ACCESS";
                        IList<object[]> resultObjList = session.CreateSQLQuery(sqlQuery)
                                .SetInt64("propertyId", propertyId)
                        		.List<object[]>();

                        if (resultObjList != null)
                        {
                            List<AllEnquiryLeadUIDTO> tmpUIList = new List<AllEnquiryLeadUIDTO>();
                            foreach (object[] row in resultObjList)
                            {
                                long Id = (long)row[1];
                                AllEnquiryLeadUIDTO tmpDTO = tmpUIList.Find(x => x.FirmMemberId == Id);
                                if (tmpDTO == null)
                                {
                                    tmpDTO = new AllEnquiryLeadUIDTO();
                                    tmpDTO.FirmMemberId = Id;
                                    tmpDTO.FirstName = (string)row[2];
                                    tmpDTO.LastName = (string)row[3];
                                    tmpDTO.FullName = CommonUIConverter.getCustomerFullName(tmpDTO.FirstName, tmpDTO.LastName);
                                    tmpDTO.Contact = (string)row[4];
                                    tmpDTO.Email = (string)row[5];
                                    tmpDTO.Status = EnumHelper.getUserStatus((string)row[6]);
                                    tmpDTO.PropertyFMAccess = EnumHelper.getPrFMAccess((string)row[7]);
                                    tmpUIList.Add(tmpDTO);
                                }
                                if ((string)row[0] == "LEAD")
                                {
                                    tmpDTO.LeadsOpen = tmpDTO.LeadsOpen + (int)row[8];
                                    tmpDTO.LeadsConverted = tmpDTO.LeadsConverted + (int)row[9];
                                    tmpDTO.LeadsLost = tmpDTO.LeadsLost + (int)row[10];
                                    tmpDTO.LeadsClosed = tmpDTO.LeadsConverted + tmpDTO.LeadsLost;
                                }
                                else
                                {
                                    tmpDTO.EnquiriesOpen = tmpDTO.LeadsOpen + (int)row[8];
                                    tmpDTO.EnquiriesWon = tmpDTO.EnquiriesWon + (int)row[9];
                                    tmpDTO.EnquiriesLost = tmpDTO.EnquiriesLost + (int)row[10];
                                    tmpDTO.EnquiriesClosed = tmpDTO.EnquiriesWon + tmpDTO.EnquiriesLost;
                                }
                            }
                            foreach (AllEnquiryLeadUIDTO uiDTO in tmpUIList)
                            {
                                if (uiDTO.PropertyFMAccess == PrFMAccess.Yes ||
                                    uiDTO.LeadsOpen > 0 || uiDTO.LeadsClosed > 0 || uiDTO.EnquiriesOpen > 0 || uiDTO.EnquiriesClosed > 0)
                                {
                                    resultList.Add(uiDTO);
                                }
                            }
                        }

                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching all enquiry and leqads history:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return resultList;
        }
        public List<UserEnquiryHistoryUIDTO> fetchEnquiryHistoryForUser(long PropertyId, long Assignee)
        {
            ISession session = null;
            List<UserEnquiryHistoryUIDTO> resultList = new List<UserEnquiryHistoryUIDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        string hqlQuery = "select ed.Id as EnquiryId, sal.Name as Salutation, ed.FirstName as CustFirstName, ed.MiddleName as CustMiddleName, ed.LastName as CustLastName, ed.EnquiryDate as EnquiryDate, "
                                   + " ed.EnquiryRefNo as EnquiryRefNo, ed.AssignedDate as AssignedDate, ed.Status as Status, ld.Id as LeadId, ld.LeadRefNo as LeadRefNo, "
                                   + " es.Name as Source, ci.Contact as Contact, pusd.Id as PrUnitSaleId, pusd.Status as UnitSaleStatus, max(ea.DateLogged) as LastActivity from EnquiryDetail ed "
                                   + " inner join ed.Property p inner join ed.ContactInfo ci inner join ed.EnquirySource es inner join ed.Salutation sal inner join ed.Assignee asgn "
                                   + " left join ed.Lead ld left join ed.PrUnitSaleDetail pusd left join ed.EnquiryActivities ea left join ea.LoggedBy lb "
                                   + " with lb.Id = :Assignee where asgn.Id = :Assignee and p.Id = :PropertyId group by ed.Id, sal.Name, ed.FirstName, ed.MiddleName, ed.LastName, "
                                   + " ed.EnquiryDate, ed.EnquiryRefNo, ed.AssignedDate, ed.Status, ld.Id, ld.LeadRefNo, es.Name, ci.Contact, pusd.Id, pusd.Status";
                        IList<UserEnquiryHistoryUIDTO> tmpResultList = session.CreateQuery(hqlQuery)
                                .SetInt64("Assignee", Assignee)
                                .SetInt64("PropertyId", PropertyId)
                                .SetResultTransformer(new DeepTransformer<UserEnquiryHistoryUIDTO>()).List<UserEnquiryHistoryUIDTO>();
                        resultList.AddRange(tmpResultList);
                        foreach (UserEnquiryHistoryUIDTO tmpDTO in resultList)
                        {
                            tmpDTO.CustFullName = CommonUIConverter.getCustomerFullName(tmpDTO.Salutation, tmpDTO.CustFirstName, "", tmpDTO.CustLastName);
                            tmpDTO.NoOfDaysAssgined = (DateTime.Today - tmpDTO.AssignedDate).Days;
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Enquiry History for user:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return resultList;
        }
        public List<UserLeadHistoryUIDTO> fetchLeadHistoryForUser(long PropertyId, long Assignee, LeadFilterDTO filterDTO)
        {
            ISession session = null;
            List<UserLeadHistoryUIDTO> resultList = new List<UserLeadHistoryUIDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	string hqlQuery = "select ld.Id as LeadId, sal.Name as Salutation, ld.FirstName as CustFirstName, ld.MiddleName as CustMiddleName, ld.LastName as CustLastName, ld.LeadDate as LeadDate, "
                                   + " ld.LeadRefNo as LeadRefNo, ld.AssignedDate as AssignedDate, ld.Status as Status, ed.Id as EnquiryId, ed.EnquiryRefNo as EnquiryRefNo, ci.Contact as Contact, "
                    			   + " src.Name as Source, max(la.DateLogged) as LastActivity from LeadDetail ld inner join ld.ContactInfo ci inner join ld.Property p "
                    			   + " inner join ld.Source src inner join ld.Salutation sal inner join ld.Assignee asgn left join ld.EnquiryDetail ed left join "
                    			   + " ld.LeadActivities la left join la.LoggedBy lb with lb.Id = :Assignee "
                    			   + " where asgn.Id = :Assignee and p.Id = :PropertyId {0} group by ld.Id, sal.Name, ld.FirstName, ld.MiddleName, ld.LastName, ld.LeadDate, ld.LeadRefNo, ld.AssignedDate, ld.Status, "
                                   + " ed.Id, ed.EnquiryRefNo, ci.Contact, src.Name";
                        StringBuilder filterStr = new StringBuilder();
                        if (filterDTO != null)
                        {
                            if (!string.IsNullOrWhiteSpace(filterDTO.FirstName))
                            {
                                appendFilter(filterStr, " and ", " sensitivelike(ld.FirstName, '" + filterDTO.FirstName.ToLower() + "%') ");
                            }
                            if (!string.IsNullOrWhiteSpace(filterDTO.LastName))
                            {
                                appendFilter(filterStr, " and ", " lower(ld.LastName) ilike '" + filterDTO.LastName.ToLower() + "%' ");
                            }
                            if (!string.IsNullOrWhiteSpace(filterDTO.LeadRefNo))
                            {
                                appendFilter(filterStr, " and ", " lower(ld.LeadRefNo) ilike '" + filterDTO.LeadRefNo.ToLower() + "' ");
                            }
                            if (!string.IsNullOrWhiteSpace(filterDTO.Contact))
                            {
                                appendFilter(filterStr, " and ", " ci.Contact = '" + filterDTO.Contact + "' ");
                            }
                            if (filterDTO.SourceId > 0)
                            {
                                appendFilter(filterStr, " and ", " src.Id = " + filterDTO.SourceId + " ");
                            }
                            if (filterDTO.Status != null)
                            {
                                appendFilter(filterStr, " and ", " src.Status = " + filterDTO.Status + " ");
                            }
                        }
                        hqlQuery = string.Format(hqlQuery, filterStr.ToString());
                        IList<UserLeadHistoryUIDTO> tmpResultList = session.CreateQuery(hqlQuery)
                                .SetInt64("Assignee", Assignee)
                                .SetInt64("PropertyId", PropertyId)
                                .SetResultTransformer(new DeepTransformer<UserLeadHistoryUIDTO>()).List<UserLeadHistoryUIDTO>();
                        resultList.AddRange(tmpResultList);
                        foreach (UserLeadHistoryUIDTO tmpDTO in resultList)
                        {
                            tmpDTO.CustFullName = CommonUIConverter.getCustomerFullName(tmpDTO.Salutation, tmpDTO.CustFirstName, "", tmpDTO.CustLastName);
                            tmpDTO.NoOfDaysAssgined = (DateTime.Today - tmpDTO.AssignedDate).Days;
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Lead History for user:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return resultList;
        }
        private void appendFilter(StringBuilder filterStr, string connector, string clause)
        {
            if (filterStr.Length == 0) filterStr.Append("where");
            else filterStr.Append(connector);
            filterStr.Append(clause);
        }
        public AllEnquiryLeadUIDTO fetchEnquiryHistorySummaryForUser(long PropertyId, long AssigneeId)
        {
            ISession session = null;
            AllEnquiryLeadUIDTO result = new AllEnquiryLeadUIDTO();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	string query = " SELECT FM.ID as FirmMemberId, SAL.NAME as Salutation, FM.FIRST_NAME as FirstName, FM.LAST_NAME as LastName, CI.CONTACT as Contact, CI.EMAIL as Email, "
                                + " COUNT(case when ED.STATUS = 'O' then 1 end) AS EnquiriesOpen, COUNT(case when ED.STATUS = 'W' then 1 end) AS EnquiriesWon,  "
                                + " COUNT(case when ED.STATUS = 'L' then 1 end) AS EnquiriesLost FROM FIRM_MEMBER FM INNER JOIN USER_DEFINITION UD "
                                + " ON UD.FIRM_MEMBER_ID = FM.ID INNER JOIN PROPERTY_FM_ACCESS PFA ON PFA.FIRM_MEMBER_ID = FM.ID AND PFA.PROPERTY_ID = :PropertyId "
                                + " INNER JOIN CONTACT_INFO CI ON FM.CONTACT_INFO_ID = CI.ID INNER JOIN MASTER_CONTROL_DATA SAL "
                                + " ON FM.SALUTATION_ID = SAL.ID LEFT JOIN ENQUIRY_DETAILS ED ON ED.ASSIGNEE = FM.ID AND ED.PROPERTY = :PropertyId "
                                + " WHERE FM.ID = :AssigneeId GROUP BY FM.ID, SAL.NAME, FM.FIRST_NAME, FM.LAST_NAME, CI.CONTACT, CI.EMAIL";
                        result = session.CreateSQLQuery(query)
                                .SetInt64("AssigneeId", AssigneeId)
                                .SetInt64("PropertyId", PropertyId)
                                .SetResultTransformer(new DeepTransformer<AllEnquiryLeadUIDTO>()).UniqueResult<AllEnquiryLeadUIDTO>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Enquiry history summary for user:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public AllEnquiryLeadUIDTO fetchLeadHistorySummaryForUser(long PropertyId, long AssigneeId)
        {
            ISession session = null;
            AllEnquiryLeadUIDTO result = new AllEnquiryLeadUIDTO();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	string query = "SELECT FM.ID as FirmMemberId, SAL.NAME as Salutation, FM.FIRST_NAME as FirstName, FM.LAST_NAME as LastName, CI.CONTACT as Contact, CI.EMAIL as Email, "
                                + " COUNT(case when LD.STATUS = 'O' then 1 end) AS LeadsOpen, COUNT(case when LD.STATUS = 'C' then 1 end) AS LeadsConverted, "
                                + " COUNT(case when LD.STATUS = 'L' then 1 end) AS LeadsLost FROM FIRM_MEMBER FM INNER JOIN USER_DEFINITION UD "
                                + " ON UD.FIRM_MEMBER_ID = FM.ID INNER JOIN PROPERTY_FM_ACCESS PFA ON PFA.FIRM_MEMBER_ID = FM.ID AND PFA.PROPERTY_ID = :PropertyId "
                                + " INNER JOIN CONTACT_INFO CI ON FM.CONTACT_INFO_ID = CI.ID INNER JOIN MASTER_CONTROL_DATA SAL "
                                + " ON FM.SALUTATION_ID = SAL.ID LEFT JOIN LEAD_DETAILS LD ON LD.ASSIGNEE = FM.ID AND LD.PROPERTY = :PropertyId "
                                + " WHERE FM.ID = :AssigneeId GROUP BY FM.ID, SAL.NAME, FM.FIRST_NAME, FM.LAST_NAME, CI.CONTACT, CI.EMAIL";
                        result = session.CreateSQLQuery(query)
                                .SetInt64("AssigneeId", AssigneeId)
                                .SetInt64("PropertyId", PropertyId)
                                .SetResultTransformer(new DeepTransformer<AllEnquiryLeadUIDTO>()).UniqueResult<AllEnquiryLeadUIDTO>();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Lead history summary for user:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public List<UserLeadHistoryUIDTO> fetchOpenLeadsForUser(long PropertyId, long AssigneeId)
        {
            ISession session = null;
            List<UserLeadHistoryUIDTO> resultList = new List<UserLeadHistoryUIDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	string hqlQuery = "select ld.Id as LeadId, ld.FirstName as CustFirstName, ld.MiddleName as CustMiddleName, ld.LastName as CustLastName, ld.LeadDate as LeadDate, "
                                   + " ld.LeadRefNo as LeadRefNo, ld.AssignedDate as AssignedDate, ld.Status as Status, src.Name as Source, ci.Contact as Contact, ld.Budget as Budget "
                                   + " from LeadDetail ld inner join ld.Property p inner join ld.Source src inner join ld.Assignee asgn inner join ld.ContactInfo ci "
                    			   + " where p.Id = :PropertyId and asgn.Id = :AssigneeId and ld.Status = 'O'";
                        IList<UserLeadHistoryUIDTO> tmpResultList = session.CreateQuery(hqlQuery)
                        		.SetInt64("AssigneeId", AssigneeId)
                                .SetInt64("PropertyId", PropertyId)
                                .SetResultTransformer(new DeepTransformer<UserLeadHistoryUIDTO>()).List<UserLeadHistoryUIDTO>();
                        resultList.AddRange(tmpResultList);
                        foreach (UserLeadHistoryUIDTO tmpDTO in resultList)
                        {
                            tmpDTO.CustFullName = CommonUIConverter.getCustomerFullName(tmpDTO.CustFirstName, tmpDTO.CustLastName);
                            tmpDTO.NoOfDaysAssgined = (DateTime.Today - tmpDTO.AssignedDate).Days;
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Leads for user with given Lead status:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return resultList;
        }
        public List<UserLeadHistoryUIDTO> fetchUnAssignedLeads(long PropertyId)
        {
            ISession session = null;
            List<UserLeadHistoryUIDTO> resultList = new List<UserLeadHistoryUIDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	string hqlQuery = "select ld.Id as LeadId, ld.FirstName as CustFirstName, ld.MiddleName as CustMiddleName, ld.LastName as CustLastName, "
                                   + " ld.LeadDate as LeadDate, ld.LeadRefNo as LeadRefNo, ld.Budget as Budget, ci.Contact as Contact, ci.Email as Email, ld.Status as Status, "
                                   + " src.Name as Source from LeadDetail ld inner join ld.Property p inner join ld.Source src inner join ld.ContactInfo ci "
                                   + " where p.Id = :PropertyId and ld.Assignee is null";
                        IList<UserLeadHistoryUIDTO> tmpResultList = session.CreateQuery(hqlQuery)
                                .SetInt64("PropertyId", PropertyId)
                                .SetResultTransformer(new DeepTransformer<UserLeadHistoryUIDTO>()).List<UserLeadHistoryUIDTO>();
                        resultList.AddRange(tmpResultList);
                        foreach (UserLeadHistoryUIDTO tmpDTO in resultList)
                        {
                            tmpDTO.CustFullName = CommonUIConverter.getCustomerFullName(tmpDTO.CustFirstName, tmpDTO.CustLastName);
                            tmpDTO.NoOfDaysCreated = (DateTime.Today - tmpDTO.LeadDate).Days;
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Unassigned Leads:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return resultList;
        }
        public EnquiryDetailDTO fetchEnquiryDetails(long Id, bool fetchFollowups)
        {
            ISession session = null;
            EnquiryDetailDTO enquiryDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EnquiryDetail enquiry = session.Get<EnquiryDetail>(Id);
                        enquiryDto = DomainToDTOUtil.convertToEnquiryDetailDTO(enquiry, true, fetchFollowups);
                        if(enquiryDto.Status != EnquiryStatus.Open && enquiryDto.PrUnitSaleDetail != null) {
                        	enquiryDto.PrUnitSaleDetail.PropertyUnit = new PropertyUnitDTO();
                        	enquiryDto.PrUnitSaleDetail.PropertyUnit.Id = enquiry.PrUnitSaleDetail.PropertyUnit.Id;
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Enquiry details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return enquiryDto;
        }
        public LeadDetailDTO fetchLeadDetails(long Id, bool fetchFollowups)
        {
        	ISession session = null;
        	LeadDetailDTO leadDTO = null;
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				LeadDetail enquiry = session.Get<LeadDetail>(Id);
        				leadDTO = DomainToDTOUtil.convertToLeadDetailDTO(enquiry, true, fetchFollowups);
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while Loading Lead details:", e);
        				throw new Exception(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        	return leadDTO;
        }
        public string addEnquiryDetails(EnquiryDetailDTO enquiryDto, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            string enquiryRefNo = "";
            try
            {
                session = NHibertnateSession.OpenSession();
                EnquiryDetail enquiry = null;
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        LeadDetail lead = null;
                        if (enquiryDto.Lead != null)
                        {
                            LeadDetailDTO leadDTO = enquiryDto.Lead;
                            string hqlActivityUpdate = "update LeadActivity la set la.Status = :status where la.Id in (select l.id from LeadActivity l where "
                                + " l.LeadDetail.Id = :LeadId) and la.Status = :openStatus";
                            session.CreateQuery(hqlActivityUpdate)
                                    .SetEnum("status", EnqLeadActivityStatus.Deferred)
                                    .SetEnum("openStatus", EnqLeadActivityStatus.Open)
                                    .SetInt64("LeadId", leadDTO.Id)
                                    .ExecuteUpdate();

                            lead = session.Get<LeadDetail>(leadDTO.Id);
                            lead.Status = LeadStatus.Converted;
                            lead.UpdateDate = DateTime.Now;
                            lead.UpdateUser = userDefDTO.Username;
                            session.Update(lead);
                            LeadActivity leadActivity = CommonUtil.getLeadActivityAction(leadDTO.Id, EnqActivityType.CONVERTED, null, DateTime.Today, userDefDTO);
                            session.Save(leadActivity);
                            leadActivity.RefNo = CommonUtil.getActivityRefNo(leadActivity.Id, leadActivity.RecordType);
                            session.Update(leadActivity);
                        }

                        enquiry = DTOToDomainUtil.populateEnquiryDetailAddFields(enquiryDto);
                        enquiry.Lead = lead;
                        session.Save(enquiry);
                        enquiry.EnquiryRefNo = CommonUtil.getEnquiryRefNo(enquiry.Id);
                        session.Update(enquiry);
                        enquiryRefNo = enquiry.EnquiryRefNo;
                        enquiryDto.Id = enquiry.Id;
                        EnquiryActivity activity = CommonUtil.getEnquiryActivityAction(enquiry.Id, (lead == null) ? EnqActivityType.CREATE : EnqActivityType.CONVERTED,
                            CommonUIConverter.getCustomerFullName(enquiry.Assignee.FirstName, enquiry.Assignee.LastName), enquiry.EnquiryDate, userDefDTO);
                        session.Save(activity);
                        activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
                        session.Update(activity);

                        

                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Enquiry details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
                sendSMSEmail(enquiry);
             }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return enquiryRefNo;
        }
        public void updateEnquiry(EnquiryDetailDTO enquiryDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EnquiryDetail enquiry = session.Get<EnquiryDetail>(enquiryDto.Id);
                        DTOToDomainUtil.populateEnquiryDetailUpdateFields(enquiry, enquiryDto);
                        session.Update(enquiry);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating Enquiry details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public string addLeadDetails(LeadDetailDTO leadDetailDTO, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            string leadRefNo = "";
            try
            {
                session = NHibertnateSession.OpenSession();
                LeadDetail lead = null;
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	lead = DTOToDomainUtil.populateLeadDetailAddFields(leadDetailDTO);
                        session.Save(lead);
                        lead.LeadRefNo = CommonUtil.getLeadRefNo(lead.Id);
                        session.Update(lead);
                        leadRefNo = lead.LeadRefNo;
                        LeadActivity activity = CommonUtil.getLeadActivityAction(lead.Id, EnqActivityType.CREATE,
                            CommonUIConverter.getCustomerFullName(lead.Assignee.FirstName, lead.Assignee.LastName), lead.LeadDate, userDefDTO);
                        session.Save(activity);
                        activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
                        session.Update(activity);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Lead details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
             }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return leadRefNo;
        }
        /**
         * This method will check Email & SMS configuration for Enquiry Function. 
         * If Email & SMS alerts are enabled then system will send Email & SMS to Customer.
         * */
        private static void sendSMSEmail(EnquiryDetail enquiry)
        {
            try
            {
                PropertyAlertConfig emailSmsAlertConfig = EmailUtil.loadEmailSmsAlertConfiguration(enquiry.FirmNumber,
                    FunctionName.ENQUIRY.ToString(), EmailSmsType.ENQUIRYTHANKS.ToString(), enquiry.Property.Id);
                PropertyBO propertyBO = new PropertyBO();
                PropertyDTO propertyDTO = propertyBO.fetchProperty(enquiry.Property.Id);
                if (emailSmsAlertConfig != null && emailSmsAlertConfig.Email.Equals(Constants.YES))
                {
                    emailSmsAlertConfig.EmailBody = populateBody(enquiry, emailSmsAlertConfig, propertyDTO.Name);
                    EmailUtil.sendHtmlFormattedEmail(enquiry.FirmNumber, emailSmsAlertConfig, enquiry.ContactInfo.Email);
                }
                if (emailSmsAlertConfig != null && emailSmsAlertConfig.Sms.Equals(Constants.YES))
                {
                    emailSmsAlertConfig.SmsContent = populateSMSBody(enquiry, emailSmsAlertConfig, propertyDTO.Name);
                    EmailUtil.sendSMS(enquiry.FirmNumber, emailSmsAlertConfig, enquiry.ContactInfo.Contact);
                }
            }
            catch (Exception e)
            {
                log.Error("Exception while sending Email & SMS alert for enquiry:", e);
            }
        }
        private static string populateBody(EnquiryDetail enquiry, PropertyAlertConfig emailSmsAlertConfig, string propertyName)
        {
            string body = string.Empty;
            using (StreamReader reader = new StreamReader(System.Web.HttpContext.Current.Server.MapPath(emailSmsAlertConfig.EmailTemplatePath)))
            {
                body = reader.ReadToEnd();
            }
            body = body.Replace("{UserName}", enquiry.Salutation.Name + " " + enquiry.FirstName + " " + enquiry.LastName);
            body = body.Replace("{PropertyName}", propertyName);
            return body;
        }
        private static string populateSMSBody(EnquiryDetail enquiry, PropertyAlertConfig emailSmsAlertConfig, string propertyName)
        {
            string body = string.Empty;
            body = emailSmsAlertConfig.SmsContent.Replace("{UserName}", enquiry.Salutation.Name + " " +enquiry.FirstName + " " + enquiry.LastName);
            body = emailSmsAlertConfig.SmsContent.Replace("{PropertyName}", propertyName);
            return body;
        }
        public string addEnquiryActivity(long EnquiryId, EnquiryActivityDTO activityDTO, EnqActivityMode activityMode, long parentId)
        {
            ISession session = null;
            string RefNo = "";
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EnquiryActivity activity = DTOToDomainUtil.populateEnquiryActivityAddFields(activityDTO);
                        session.Save(activity);
                        activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
                        session.Update(activity);
                        RefNo = activity.RefNo;
                        if (activityMode != EnqActivityMode.NONE && parentId > 0)
                        {
                            EnqLeadActivityStatus status = EnqLeadActivityStatus.Completed;
                            if (activityMode == EnqActivityMode.RESCHEDULE_EVENT || activityMode == EnqActivityMode.RESCHEDULE_TASK
                                || activityMode == EnqActivityMode.CANCEL_EVENT || activityMode == EnqActivityMode.CANCEL_TASK) {
                                    status = EnqLeadActivityStatus.Deferred;
                            }
                            string hqlUpdate = "update EnquiryActivity ea set ea.Status = :status, ea.UpdateDate = :updateDate, ea.UpdateUser = :updateUser where ea.Id = :parentId";
                            session.CreateQuery(hqlUpdate)
                                    .SetEnum("status", status)
                                    .SetDateTime("updateDate", DateTime.Now)
                                    .SetString("updateUser", activityDTO.InsertUser)
                                    .SetInt64("parentId", parentId)
                                    .ExecuteUpdate();
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while adding Enquiry activity and update other:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return RefNo;
        }
        public string addEnquiryActivity(EnquiryActivityDTO activityDTO)
        {
            ISession session = null;
            string RefNo = "";
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EnquiryActivity activity = DTOToDomainUtil.populateEnquiryActivityAddFields(activityDTO);
                        session.Save(activity);
                        activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
                        session.Update(activity);
                        RefNo = activity.RefNo;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while adding Enquiry activity:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return RefNo;
        }
        public string addLeadActivity(long LeadId, LeadActivityDTO activityDTO, EnqActivityMode activityMode, long parentId)
        {
        	ISession session = null;
        	string RefNo = "";
        	try
        	{
        		session = NHibertnateSession.OpenSession();
        		using (ITransaction tx = session.BeginTransaction())
        		{
        			try
        			{
        				LeadActivity activity = DTOToDomainUtil.populateLeadActivityAddFields(activityDTO);
        				session.Save(activity);
                        activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
        				session.Update(activity);
        				RefNo = activity.RefNo;
        				if (activityMode != EnqActivityMode.NONE && parentId > 0)
        				{
        					EnqLeadActivityStatus status = EnqLeadActivityStatus.Completed;
        					if (activityMode == EnqActivityMode.RESCHEDULE_TASK || activityMode == EnqActivityMode.CANCEL_TASK) {
        							status = EnqLeadActivityStatus.Deferred;
        					}
        					string hqlUpdate = "update LeadActivity ea set ea.Status = :status, ea.UpdateDate = :updateDate, ea.UpdateUser = :updateUser where ea.Id = :parentId";
        					session.CreateQuery(hqlUpdate)
        							.SetEnum("status", status)
        							.SetDateTime("updateDate", DateTime.Now)
        							.SetString("updateUser", activityDTO.InsertUser)
        							.SetInt64("parentId", parentId)
        							.ExecuteUpdate();
        				}
        				tx.Commit();
        			}
        			catch (Exception e)
        			{
        				tx.Rollback();
        				log.Error("Exception while adding Lead activity:", e);
        				throw new Exception(Resources.Messages.system_error);
        			}
        		}
        	}
        	finally
        	{
        		NHibertnateSession.closeSession(session);
        	}
        	return RefNo;
        }
        public void ReAssignEnquiry(long enquiryId, long assigneeId, DateTime assignedDate, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        FirmMember assignee = session.Get<FirmMember>(assigneeId);
                        EnquiryDetail enquiry = session.Get<EnquiryDetail>(enquiryId);
                        if (CommonValidations.validateEnquiryLeadAssignment(assignee, enquiry.Property.Id))
                        {
                            enquiry.Assignee = assignee;
                            enquiry.AssignedDate = assignedDate;
                            enquiry.UpdateDate = DateTime.Now;
                            enquiry.UpdateUser = userDefDTO.Username;
                            session.Update(enquiry);
                            EnquiryActivity activity = CommonUtil.getEnquiryActivityAction(enquiryId, EnqActivityType.RE_ASSIGNMENT,
                                        CommonUIConverter.getCustomerFullName(enquiry.Assignee.FirstName, enquiry.Assignee.LastName), assignedDate, userDefDTO);
                            session.Save(activity);
                            activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
                            session.Update(activity);
                            tx.Commit();
                        }
                        else throw new CustomException("User does not have access to current property or user is not active.");

                    }
                    catch (CustomException e)
                    {
                        throw e;
                    }  
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Reassigning Enquiry:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void AssignAllLeads(List<UserLeadHistoryUIDTO> selectedLeadList, long assigneeId, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        bool isValidated = false;
                        FirmMember assignee = session.Get<FirmMember>(assigneeId);
                        foreach (UserLeadHistoryUIDTO tmpLeadDTO in selectedLeadList)
                        {
                            LeadDetail lead = session.Get<LeadDetail>(tmpLeadDTO.LeadId);
                            if(!isValidated) isValidated = CommonValidations.validateEnquiryLeadAssignment(assignee, lead.Property.Id);
                            if (isValidated)
                            {
                                lead.Assignee = assignee;
                                lead.AssignedDate = DateTime.Today;
                                lead.UpdateDate = DateTime.Now;
                                lead.UpdateUser = userDefDTO.Username;
                                session.Update(lead);
                                LeadActivity activity = CommonUtil.getLeadActivityAction(tmpLeadDTO.LeadId, EnqActivityType.ASSIGNMENT,
                                            CommonUIConverter.getCustomerFullName(lead.Assignee.FirstName, lead.Assignee.LastName), DateTime.Today, userDefDTO);
                                session.Save(activity);
                                activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
                                session.Update(activity);
                            }
                            else throw new CustomException("User does not have access to current property or user is not active.");
                        }
                        tx.Commit();
                    }
                    catch (CustomException e)
                    {
                        throw e;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Assigning bulk Leads:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void ReAssignLead(long leadId, long assigneeId, DateTime assignedDate, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        FirmMember assignee = session.Get<FirmMember>(assigneeId);
                        LeadDetail lead = session.Get<LeadDetail>(leadId);
                        if (CommonValidations.validateEnquiryLeadAssignment(assignee, lead.Property.Id))
                        {
                            lead.Assignee = assignee;
                            lead.AssignedDate = assignedDate;
                            lead.UpdateDate = DateTime.Now;
                            lead.UpdateUser = userDefDTO.Username;
                            session.Update(lead);
                            LeadActivity activity = CommonUtil.getLeadActivityAction(leadId, EnqActivityType.RE_ASSIGNMENT,
                                        CommonUIConverter.getCustomerFullName(lead.Assignee.FirstName, lead.Assignee.LastName), assignedDate, userDefDTO);
                            session.Save(activity);
                            activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
                            session.Update(activity);
                            tx.Commit();
                        }
                        else throw new CustomException("User does not have access to current property or user is not active.");
                    }
                    catch (CustomException e)
                    {
                        throw e;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Reassigning Lead:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void ReAssignAllLeads(List<UserLeadHistoryUIDTO> selectedLeadList, long assigneeId, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        bool isValidated = false;
                        FirmMember assignee = session.Get<FirmMember>(assigneeId);
                        foreach (UserLeadHistoryUIDTO tmpLeadDTO in selectedLeadList)
                        {
                            LeadDetail lead = session.Get<LeadDetail>(tmpLeadDTO.LeadId);
                            if(!isValidated) isValidated = CommonValidations.validateEnquiryLeadAssignment(assignee, lead.Property.Id);
                            if (isValidated)
                            {
                                lead.Assignee = assignee;
                                lead.AssignedDate = DateTime.Today;
                                lead.UpdateDate = DateTime.Now;
                                lead.UpdateUser = userDefDTO.Username;
                                session.Update(lead);
                                LeadActivity activity = CommonUtil.getLeadActivityAction(tmpLeadDTO.LeadId, EnqActivityType.RE_ASSIGNMENT,
                                            CommonUIConverter.getCustomerFullName(lead.Assignee.FirstName, lead.Assignee.LastName), DateTime.Today, userDefDTO);
                                session.Save(activity);
                                activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
                                session.Update(activity);
                            }
                            else throw new CustomException("User does not have access to current property or user is not active.");
                        }
                        tx.Commit();
                    }
                    catch (CustomException e)
                    {
                        throw e;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Reassigning Lead:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void closeEnquiry(long enquiryId, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EnquiryDetail enquiry = session.Get<EnquiryDetail>(enquiryId);
                        if (enquiry.Status != EnquiryStatus.Open) throw new CustomException(Resources.Messages.ERROR_ENQUIRY_CLOSE_NOT_OPEN);
                        
                        string hqlActivityUpdate = "update EnquiryActivity ea set ea.Status = :status where ea.Id in (select e.id from EnquiryActivity e where "
                                + " e.EnquiryDetail.Id = :EnquiryId) and ea.Status = :openStatus";
                        session.CreateQuery(hqlActivityUpdate)
                                .SetEnum("status", EnqLeadActivityStatus.Deferred)
                                .SetEnum("openStatus", EnqLeadActivityStatus.Open)
                                .SetInt64("EnquiryId", enquiryId)
                                .ExecuteUpdate();
                        
                        enquiry.Status = EnquiryStatus.Lost;
                        enquiry.UpdateDate = DateTime.Now;
                        enquiry.UpdateUser = userDefDTO.Username;
                        session.Update(enquiry);
                        EnquiryActivity activity = CommonUtil.getEnquiryActivityAction(enquiryId, EnqActivityType.LOST, null, DateTime.Today, userDefDTO);
                        session.Save(activity);
                        activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
                        session.Update(activity);
                        tx.Commit();
                    }
                    catch (CustomException e)
                    {
                        throw e;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while making Enquiry Close:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void closeLead(long leadId, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        LeadDetail lead = session.Get<LeadDetail>(leadId);
                        if (lead.Status != LeadStatus.Open) throw new CustomException(Resources.Messages.ERROR_LEAD_CLOSE_NOT_OPEN);
                        
                        string hqlActivityUpdate = "update LeadActivity la set la.Status = :status where la.Id in (select l.id from LeadActivity l where "
                                + " l.LeadDetail.Id = :LeadId) and la.Status = :openStatus";
                        session.CreateQuery(hqlActivityUpdate)
                                .SetEnum("status", EnqLeadActivityStatus.Deferred)
                                .SetEnum("openStatus", EnqLeadActivityStatus.Open)
                                .SetInt64("LeadId", leadId)
                                .ExecuteUpdate();

                        lead.Status = LeadStatus.Lost;
                        lead.UpdateDate = DateTime.Now;
                        lead.UpdateUser = userDefDTO.Username;
                        session.Update(lead);
                        LeadActivity activity = CommonUtil.getLeadActivityAction(leadId, EnqActivityType.LOST, null, DateTime.Today, userDefDTO);
                        session.Save(activity);
                        activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
                        session.Update(activity);
                        tx.Commit();
                    }
                    catch (CustomException e)
                    {
                        throw e;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while making Lead Close:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void reOpenEnquiry(long enquiryId, UserDefinitionDTO userDefDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        EnquiryDetail enquiry = session.Get<EnquiryDetail>(enquiryId);
                        if (enquiry.Status != EnquiryStatus.Lost) throw new CustomException(Resources.Messages.ERROR_ENQUIRY_REOPEN_NOT_CLOSED);
                        else if (enquiry.PrUnitSaleDetail != null && enquiry.PrUnitSaleDetail.Id > 0) throw new CustomException(Resources.Messages.ERROR_ENQUIRY_REOPEN_UNIT_BOOKED);
                        
                        enquiry.Status = EnquiryStatus.Open;
                        enquiry.UpdateDate = DateTime.Now;
                        enquiry.UpdateUser = userDefDTO.Username;
                        session.Update(enquiry);
                        EnquiryActivity activity = CommonUtil.getEnquiryActivityAction(enquiryId, EnqActivityType.RE_OPENED, null, DateTime.Today, userDefDTO);
                        session.Save(activity);
                        activity.RefNo = CommonUtil.getActivityRefNo(activity.Id, activity.RecordType);
                        session.Update(activity);
                        tx.Commit();
                    }
                    catch (CustomException e)
                    {
                        throw e;
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while making Enquiry reopen:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
    }
}