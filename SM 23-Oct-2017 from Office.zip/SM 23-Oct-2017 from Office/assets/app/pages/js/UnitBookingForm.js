﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
	initTaxGrid();
	initCMTaxGrid();
    formatFields();
    showModal();
}

function initTaxGrid() {
    var dtOptions = {
        hasActionColumn: false,
        hideSearch: true,
        pagination: false,
        sorting: false
    };

    $("[id$='taxDetailGrid']").CSBasicDatatable(dtOptions);
}
function initCMTaxGrid() {
    var dtOptions = {
        hasActionColumn: false,
        hideSearch: true,
        pagination: false,
        sorting: false
    };

    $("[id$='cmTaxDetailGrid']").CSBasicDatatable(dtOptions);
}



