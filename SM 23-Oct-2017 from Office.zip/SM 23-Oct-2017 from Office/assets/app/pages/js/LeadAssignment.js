﻿$(document).ready(function () {
    initBootstrapComponants();
});

function initBootstrapComponants() {
	initEnquiryLeadSearchGrid();
    formatFields();
}

function initEnquiryLeadSearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        pageLength: 10,
        hideSearch: true
    };

    $("[id$='allEnquiryLeadSearchGrid']").CSBasicDatatable(dtOptions);
}




