﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
	initMatchingEntityGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}
function initMatchingEntityGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        sorting: false,
        pageLength: 5,
        hideSearch: true
    };

    $("[id$='matchingCustomerGrid']").CSBasicDatatable(dtOptions);
}





