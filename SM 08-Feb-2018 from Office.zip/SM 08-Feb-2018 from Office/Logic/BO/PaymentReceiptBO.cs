﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using NHibernate;
using NHibernate.Criterion;

namespace ConstroSoft.Logic.BO
{

    public class PaymentReceiptBO
    {
        private static readonly log4net.ILog log =
             log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public PaymentReceiptBO() { }

        public BusinessOutputTO processPaymentReceipt(CustomerPaymentHistoryPageDTO customerPymtHistoryDTO, MPTHistoryUIDTO mptHistUIDTO, long propertyId)
        {
            BusinessOutputTO businessOutputTO = new BusinessOutputTO();
            try
            {
                PropertyBO propertyBO = new PropertyBO();
                DataTable PaymentReceipt = populatePaymentReceiptColumns();
                PropertyDTO propertyDTO = propertyBO.fetchProperty(propertyId);
                DataRow PaymentReceiptRow = populatePaymentReceiptRows(PaymentReceipt, customerPymtHistoryDTO, mptHistUIDTO, propertyDTO);
                PaymentReceipt.Rows.Add(PaymentReceiptRow);
                businessOutputTO.result = PaymentReceipt;
                businessOutputTO.status = BusinessOutputTO.Status.SUCCESS;
                businessOutputTO.successMessage = "Payment Receipt for " + CommonUIConverter.getCustomerFullName(customerPymtHistoryDTO.PrUnitSaleDetail.Customer.FirstName,
                customerPymtHistoryDTO.PrUnitSaleDetail.Customer.LastName);
            }
            catch (Exception e)
            {
                log.Error("Exception while generating payment receipt", e);
                throw new Exception(Resources.Messages.system_error);
            }
            return businessOutputTO;
        }
       

        private DataRow populatePaymentReceiptRows(DataTable PaymentReceipt, CustomerPaymentHistoryPageDTO customerPymtHistoryDTO, MPTHistoryUIDTO mptHistUIDTO, PropertyDTO propertyDTO)
        {
            DataRow PaymentReceiptRow = PaymentReceipt.NewRow();            
            string BLANK_STRING = "";            
            PaymentReceiptRow["CustomerName"] = CommonUIConverter.getCustomerFullName(customerPymtHistoryDTO.PrUnitSaleDetail.Customer.FirstName, customerPymtHistoryDTO.PrUnitSaleDetail.Customer.LastName);
            PaymentReceiptRow["Amount"] = mptHistUIDTO.PymtAmt != null ? mptHistUIDTO.PymtAmt : 0;
            PaymentReceiptRow["ReferanceNumber"] = mptHistUIDTO.TxRefNo != null ? mptHistUIDTO.TxRefNo:BLANK_STRING ;
            PaymentReceiptRow["Date"] = mptHistUIDTO.TxDate;
            PaymentReceiptRow["BankName"] = mptHistUIDTO.BankName != null ? mptHistUIDTO.BankName : BLANK_STRING;
            PaymentReceiptRow["Branch"] = mptHistUIDTO.Branch != null ? mptHistUIDTO.Branch : BLANK_STRING;
            PaymentReceiptRow["PropertyName"] = propertyDTO.Name != null ? propertyDTO.Name+" ": BLANK_STRING;
            PaymentReceiptRow["BuildName"] = customerPymtHistoryDTO.PrUnitSaleDetail.PropertyUnit.TowerName != null ? customerPymtHistoryDTO.PrUnitSaleDetail.PropertyUnit.TowerName : BLANK_STRING;
            PaymentReceiptRow["UnitNo"] = customerPymtHistoryDTO.PrUnitSaleDetail.PropertyUnit.UnitNo != null ? CommonUIConverter.getPropertyUnitFormattedNo(customerPymtHistoryDTO.PrUnitSaleDetail.PropertyUnit.Wing, 
            customerPymtHistoryDTO.PrUnitSaleDetail.PropertyUnit.UnitNo)+" ": BLANK_STRING;
            PaymentReceiptRow["ModeOfPayment"] = mptHistUIDTO.PymtMethod;
            AddressDTO addressDto = propertyDTO.ContactInfo.Addresses.FirstOrDefault<AddressDTO>();
            PaymentReceiptRow["Address"] = CommonUtil.getFullAddress(addressDto);
            return PaymentReceiptRow;
        }
        private static DataTable populatePaymentReceiptColumns()
        {
            DataTable PaymentReceipt = new DataTable();
            PaymentReceipt.Columns.Add("CustomerName", typeof(string));
            PaymentReceipt.Columns.Add("Amount", typeof(string));
            PaymentReceipt.Columns.Add("ReferanceNumber", typeof(string));
            PaymentReceipt.Columns.Add("Date", typeof(string));
            PaymentReceipt.Columns.Add("BankName", typeof(string));
            PaymentReceipt.Columns.Add("Branch", typeof(string));
            PaymentReceipt.Columns.Add("PropertyName", typeof(string));
            PaymentReceipt.Columns.Add("BuildName", typeof(string));
            PaymentReceipt.Columns.Add("UnitNo", typeof(string));
            PaymentReceipt.Columns.Add("Address", typeof(string));
            PaymentReceipt.Columns.Add("ModeOfPayment", typeof(string));          
            return PaymentReceipt;
        }
    }
}
