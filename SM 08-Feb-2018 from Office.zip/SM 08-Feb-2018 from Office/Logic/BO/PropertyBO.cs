﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq.Expressions;
using NHibernate.Impl;
using System.Linq;

/// <summary>
/// Summary description for propertyBO
/// </summary>
namespace ConstroSoft
{
    public class PropertyBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public PropertyBO() { }
        public IList<PropertyDTO> fetchAllProperties(string firmNumber)
        {
            ISession session = null;
            IList<PropertyDTO> result = new List<PropertyDTO>();
            try
            {
                Property p = null;

                PropertyDTO pDto = null;
                session = NHibertnateSession.OpenSession();
                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => p.Id).WithAlias(() => pDto.Id))
                            .Add(Projections.Property(() => p.Name).WithAlias(() => pDto.Name));
                result = session.QueryOver<Property>(() => p).Select(proj)
                        .Where(() => p.FirmNumber == firmNumber)
                        .TransformUsing(new DeepTransformer<PropertyDTO>()).List<PropertyDTO>();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error fetching property for promotions:", exp);
                throw exp;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public IList<PropertyTowerDTO> fetchPropertyTowerSelective(long propertyId)
        {
            ISession session = null;
            IList<PropertyTowerDTO> result = new List<PropertyTowerDTO>();
            try
            {
                Property p = null;
                PropertyTower pt = null;

                PropertyTowerDTO ptDto = null;
                session = NHibertnateSession.OpenSession();
                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => pt.Id).WithAlias(() => ptDto.Id))
                            .Add(Projections.Property(() => pt.Name).WithAlias(() => ptDto.Name))
                            .Add(Projections.Property(() => p.Id), "Property.Id");
                result = session.QueryOver<Property>(() => p)
                        .Inner.JoinAlias(() => p.PropertyTowers, () => pt)
                        .Select(proj)
                        .Where(() => p.Id == propertyId)
                        .TransformUsing(new DeepTransformer<PropertyTowerDTO>()).List<PropertyTowerDTO>(); ;
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error fetching property towers for promotions:", exp);
                throw exp;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public IList<PropertyDTO> fetchPropertyGridData(string firmNumber, PropertyFilterDTO filterDTO, long firmMemberId)
        {
            ISession session = null;
            IList<PropertyDTO> result = new List<PropertyDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                Property p = null;
                PropertyDTO pDto = null;
                MasterControlData pType = null;
                MasterControlData pLoc = null;
                City c = null;
                FirmAccount fa = null;
                PropertyFMAccess pfa = null;
                FirmMember fm = null;
                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => p.Id).WithAlias(() => pDto.Id))
                            .Add(Projections.Property(() => p.Name).WithAlias(() => pDto.Name))
                            .Add(Projections.Property(() => pType.Name), "PropertyType.Name")
                            .Add(Projections.Property(() => pLoc.Name), "PropertyLocation.Name")
                            .Add(Projections.Property(() => p.PropertyArea).WithAlias(() => pDto.PropertyArea))
                            .Add(Projections.Property(() => fa.Name), "FirmAccount.Name")
                            .Add(Projections.Property(() => c.Name), "FirmAccount.City.Name");
                var query = session.QueryOver<Property>(() => p)
                    .Inner.JoinAlias(() => p.PropertyType, () => pType)
                    .Inner.JoinAlias(() => p.PropertyLocation, () => pLoc)
                    .Inner.JoinAlias(() => p.FirmAccount, () => fa)
                    .Inner.JoinAlias(() => p.FirmAccount.City, () => c)
                    .Inner.JoinAlias(() => p.PropertyFMAccess, () => pfa)
                    .Inner.JoinAlias(() => pfa.FirmMember, () => fm);
                if (filterDTO != null)
                {
                    ICriteria criteria = query.RootCriteria;
                    if (filterDTO.PropertyId > 0)
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<Property>(() => p, x => x.Id), filterDTO.PropertyId));
                    }
                    if (filterDTO.Type != null)
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<MasterControlData>(() => pType, x => x.Id), filterDTO.Type.Id));
                    }
                    if (filterDTO.Location != null)
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<MasterControlData>(() => pLoc, x => x.Id), filterDTO.Location.Id));
                    }
                }
                result = query.Where(() => p.FirmNumber == firmNumber && fm.Id == firmMemberId && pfa.HasAccess == PrFMAccess.Yes)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<PropertyDTO>()).List<PropertyDTO>();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error fetching data for property search grid:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public PropertyDTO fetchPropertySelective(long propertyId)
        {
            ISession session = null;
            PropertyDTO propertyDTO = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Property property = session.Get<Property>(propertyId);
                        propertyDTO = new PropertyDTO();
                        propertyDTO.Id = property.Id;
                        propertyDTO.Name = property.Name;
                        propertyDTO.PropertyLocation = new MasterControlDataDTO();
                        propertyDTO.PropertyLocation.Name = property.PropertyLocation.Name;
                        propertyDTO.PropertyType = new MasterControlDataDTO();
                        propertyDTO.PropertyType.Name = property.PropertyType.Name;
                        propertyDTO.ReraRegNo = property.ReraRegNo;
                    }

                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching property with selective details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }

                }
                return propertyDTO;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public PropertyDTO fetchPropertyByName(string propertyName)
        {
            ISession session = null;
            PropertyDTO propertyDTO = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	string tmpPropertyName = propertyName.Trim().ToUpper();
                    	Property property = session.QueryOver<Property>().Where(p => p.Name.ToUpper() == tmpPropertyName).SingleOrDefault();;
                        if(property != null) {
                            propertyDTO = new PropertyDTO();
                            propertyDTO.Id = property.Id;
                            propertyDTO.Name = property.Name;
                            propertyDTO.FirmNumber = property.FirmNumber;
                        }
                    }

                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching property by name with selective details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }

                }
                return propertyDTO;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public PropertyDTO fetchProperty(long Id)
        {
            ISession session = null;
            PropertyDTO propertyDto = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Property property = session.Get<Property>(Id);
                        propertyDto = DomainToDTOUtil.convertToPropertyDTO(property, true);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading property details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return propertyDto;
        }
        public bool validatePropertyExist(string firmNumber, string propertyName)
        {
            ISession session = null;
            bool exist = false;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                    	string tmpPropertyName = propertyName.Trim().ToUpper();
                        Property p = null;
                        exist = session.QueryOver<Property>(() => p)
                            .Where(() => p.FirmNumber == firmNumber && p.Name.IsInsensitiveLike(tmpPropertyName))
                            .RowCount() > 0;
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while validating unique Property:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return exist;
        }
        public long saveProperty(PropertyDTO propertyDto)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Property property = DTOToDomainUtil.populatePropertyAddFields(propertyDto);
                        populateEmailSMSConfigToProperty(session, property);
                        session.Save(property);
                        Id = property.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving property details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }

        public void populateEmailSMSConfigToProperty(ISession session, Property property)
        {
            EmailSmsAlertConfig emailSmsAlertConfig = null;
            IList<EmailSmsAlertConfig> emailSmsAlertConfigs = session.QueryOver<EmailSmsAlertConfig>(() => emailSmsAlertConfig)
                .Where(() => emailSmsAlertConfig.FirmNumber == property.FirmNumber).List<EmailSmsAlertConfig>();
            IList<EmailConfig> emailConfigs = null;
            EmailConfig emailConfig = null;
            SmsConfig smsConfig = null;
            emailConfigs = session.QueryOver<EmailConfig>(() => emailConfig).Where(() => emailConfig.FirmNumber == property.FirmNumber)
                .List<EmailConfig>();
            smsConfig = session.QueryOver<SmsConfig>(() => smsConfig).Where(() => smsConfig.FirmNumber == property.FirmNumber).SingleOrDefault<SmsConfig>();
            if (emailSmsAlertConfigs != null && emailSmsAlertConfigs.Count() > 0)
            {
                property.PropertyAlertConfigs = new HashSet<PropertyAlertConfig>();
                foreach (EmailSmsAlertConfig tmpemailSmsAlertConfig in emailSmsAlertConfigs)
                {
                    property.PropertyAlertConfigs.Add(populatePropertyAlertConfig(tmpemailSmsAlertConfig, property, emailConfigs[0], smsConfig));
                }

            }
        }

        public PropertyAlertConfig populatePropertyAlertConfig(EmailSmsAlertConfig emailSmsAlertConfig, Property property,
            EmailConfig emailConfig, SmsConfig smsConfig)
        {
            PropertyAlertConfig propertyAlertConfig = new PropertyAlertConfig();
            propertyAlertConfig.Property = property;
            propertyAlertConfig.FunctionName = emailSmsAlertConfig.FunctionName;
            propertyAlertConfig.EmailSmsType = emailSmsAlertConfig.EmailSmsType;
            propertyAlertConfig.Email = emailSmsAlertConfig.Email;
            propertyAlertConfig.Sms = emailSmsAlertConfig.Sms;
            propertyAlertConfig.Subject = emailSmsAlertConfig.Subject;
            propertyAlertConfig.SmsContent = emailSmsAlertConfig.SmsContent;
            propertyAlertConfig.EmailTemplatePath = emailSmsAlertConfig.EmailTemplatePath;
            propertyAlertConfig.FirmNumber = property.FirmNumber;
            propertyAlertConfig.EmailConfig = new EmailConfig();
            propertyAlertConfig.EmailConfig.Id = emailConfig.Id;
            propertyAlertConfig.SmsConfig = new SmsConfig();
            propertyAlertConfig.SmsConfig.Id = smsConfig.Id;
            propertyAlertConfig.InsertDate = property.InsertDate;
            propertyAlertConfig.UpdateDate = property.UpdateDate;
            propertyAlertConfig.InsertUser = property.InsertUser;
            propertyAlertConfig.UpdateUser = property.UpdateUser;
            return propertyAlertConfig;
        }

        public void updateProperty(PropertyDTO propertyDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Property property = session.Get<Property>(propertyDto.Id);
                        DTOToDomainUtil.populatePropertyUpdateFields(property, propertyDto);
                        session.Update(property);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating property details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void deleteProperty(long Id)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        Property property = session.Get<Property>(Id);
                        session.Delete(property);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while deleting property details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public List<PropertyScheduleDTO> fetchPropertySchedule(long propertyTowerId)
        {
            ISession session = null;
            List<PropertyScheduleDTO> propertyScheduleList = new List<PropertyScheduleDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertySchedule ps = null;
                        PropertyTower p = null;
                        IList<PropertySchedule> result = session.QueryOver<PropertySchedule>(() => ps).JoinAlias(() => ps.PropertyTower, () => p)
                            .Where(() => p.Id == propertyTowerId).List<PropertySchedule>();
                        foreach (PropertySchedule prSchedule in result)
                        {
                            propertyScheduleList.Add(DomainToDTOUtil.convertToPropertyScheduleDTO(prSchedule, true));
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching property schedule details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return propertyScheduleList;
        }
        public PropertyScheduleDTO fetchPropertyScheduleCurrentCompletedStage(long propertyTowerId)
        {
            ISession session = null;
            PropertyScheduleDTO currentStageDTO = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertySchedule ps = null;
                        PropertyTower p = null;
                        IList<PropertySchedule> result = session.QueryOver<PropertySchedule>(() => ps).JoinAlias(() => ps.PropertyTower, () => p)
                            .Where(() => p.Id == propertyTowerId && ps.Status == PRScheduleStageStatus.Completed).List<PropertySchedule>();
                        PropertySchedule currentStage = null;
                        decimal totalPercentage = decimal.Zero;
                        foreach (PropertySchedule prSchedule in result)
                        {
                        	if(currentStage == null || currentStage.StageNumber < prSchedule.StageNumber) currentStage = prSchedule;
                            totalPercentage = decimal.Add(totalPercentage, prSchedule.Percentage);
                        }
                        if(currentStage != null) {
                        	currentStageDTO = DomainToDTOUtil.convertToPropertyScheduleDTO(currentStage, false);
                        	currentStageDTO.TotalPercentage = totalPercentage;
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching Latest completed stage:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return currentStageDTO;
        }
        public void saveOrUpdatePropertySchedule(long prTowerId, List<PropertyScheduleDTO> propertyScheduleDtos)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertySchedule ps = null;
                        PropertyTower p = null;
                        IList<PropertySchedule> propertyTowerSchedules = session.QueryOver<PropertySchedule>(() => ps).JoinAlias(() => ps.PropertyTower, () => p)
                            .Where(() => p.Id == prTowerId).List<PropertySchedule>();
                        if (propertyScheduleDtos != null)
                        {
                            if (propertyTowerSchedules != null && propertyTowerSchedules.Count > 0)
                            {
                                for (int i = 0; i < propertyTowerSchedules.Count; i++)
                                {
                                    PropertySchedule propertySchedule = propertyTowerSchedules.ElementAt(i);
                                    PropertyScheduleDTO propertyScheduleDto = propertyScheduleDtos.FirstOrDefault(x => x.Id == propertySchedule.Id);
                                    if (propertyScheduleDto == null)
                                    {
                                        session.Delete(propertySchedule);
                                    }
                                    else
                                    {
                                        DTOToDomainUtil.populatePropertyScheduleUpdateFields(propertySchedule, propertyScheduleDto);
                                        session.Update(propertySchedule);
                                    }
                                }
                            }
                            foreach (PropertyScheduleDTO propertyScheduleDto in propertyScheduleDtos)
                            {
                                if (propertyScheduleDto.Id < 1)
                                {
                                    PropertySchedule propertySchedule = DTOToDomainUtil.populatePropertyScheduleAddFields(propertyScheduleDto);
                                    session.Save(propertySchedule);
                                }
                            }
                        }
                        else if (propertyTowerSchedules.Count > 0)
                        {
                            foreach (PropertySchedule propertySchedule in propertyTowerSchedules)
                            {
                                session.Delete(propertySchedule);
                            }
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving property Schedule details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        //Property Unit : Start
        public List<PropertyUnitDTO> fetchPropertyUnits(string firmNumber, long propertyTowerId)
        {
            ISession session = null;
            List<PropertyUnitDTO> propertyUnitList = new List<PropertyUnitDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit pu = null;
                        Property p = null;
                        IList<PropertyUnit> result = session.QueryOver<PropertyUnit>(() => pu).JoinAlias(() => pu.PropertyTower, () => p)
                            .Where(() => pu.FirmNumber == firmNumber && p.Id == propertyTowerId).List<PropertyUnit>();
                        foreach (PropertyUnit propertyUnit in result)
                        {
                            propertyUnitList.Add(DomainToDTOUtil.convertToPropertyUnitDTO(propertyUnit, true));
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching property unit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return propertyUnitList;
        }
        public PropertyUnitDTO fetchPropertyUnitDetails(long Id)
        {
            ISession session = null;
            PropertyUnitDTO propertyUnitDTO = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit propertyUnit = session.Get<PropertyUnit>(Id);
                        propertyUnitDTO = DomainToDTOUtil.convertToPropertyUnitDTO(propertyUnit, true);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Property Unit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return propertyUnitDTO;
        }
        public PropertyUnitDTO fetchPropertyUnitWithParent(long Id, bool fetchTaxes)
        {
            ISession session = null;
            PropertyUnitDTO propertyUnitDTO = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit propertyUnit = session.Get<PropertyUnit>(Id);
                        propertyUnitDTO = DomainToDTOUtil.convertToPropertyUnitDTO(propertyUnit, true);
                        propertyUnitDTO.PropertyTower = DomainToDTOUtil.convertToPropertyTowerDTO(propertyUnit.PropertyTower, true);
                        if (fetchTaxes)
                        {
                            Property property = propertyUnit.PropertyTower.Property;
                            ISet<PropertyTaxDetailDTO> taxSet = new HashSet<PropertyTaxDetailDTO>();
                            if (property.PropertyTaxDetails != null && property.PropertyTaxDetails.Count > 0)
                            {
                                foreach (PropertyTaxDetail propertyTaxDetail in property.PropertyTaxDetails)
                                {
                                    taxSet.Add(DomainToDTOUtil.convertToPropertyTaxDetailDTO(propertyTaxDetail, true));
                                }
                            }
                            propertyUnitDTO.PropertyTower.Property.PropertyTaxDetails = taxSet;
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Property Unit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return propertyUnitDTO;
        }
        public long savePropertyUnitDetails(PropertyUnitDTO propertyUnitDTO)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit propertyUnit = DTOToDomainUtil.populatePropertyUnitAddFields(propertyUnitDTO);
                        session.Save(propertyUnit);
                        Id = propertyUnit.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Property Unit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        public void updatePropertyUnitDetails(PropertyUnitDTO propertyUnitDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit propertyUnit = session.Get<PropertyUnit>(propertyUnitDTO.Id);
                        DTOToDomainUtil.populatePropertyUnitUpdateFields(propertyUnit, propertyUnitDTO);
                        session.Update(propertyUnit);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating property unit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public BusinessOutputTO deletePropertyUnitDetails(long Id)
        {
            ISession session = null;
            BusinessOutputTO businessOutputTO = new BusinessOutputTO();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyUnit propertyUnit = session.Get<PropertyUnit>(Id);
                        if (!(propertyUnit.PrUnitSaleDetails.Count > 0))
                        {
                            session.Delete(propertyUnit);
                            businessOutputTO.status = BusinessOutputTO.Status.SUCCESS;
                        }
                        else
                        {
                            businessOutputTO.setErrorMessage(Resources.Messages.system_error);
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while deleting Enquiry details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
                return businessOutputTO;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        //Property Unit : End
        //Property Parking : Start
        public IList<PropertyParkingDTO> fetchPropertyParkingGridData(string firmNumber, PropertyParkingFilterDTO filterDTO, long propertyTowerId)
        {
            ISession session = null;
            IList<PropertyParkingDTO> results = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                PropertyParkingDTO ppDto = null;
                PropertyParking pp = null;
                PropertyTower pt = null;
                MasterControlData dg = null;
                Property pr = null;

                var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => pp.Id).WithAlias(() => ppDto.Id))
                            .Add(Projections.Property(() => dg.Name), "ParkingType.Name")
                            .Add(Projections.Property(() => pp.ParkingNo).WithAlias(() => ppDto.ParkingNo))
                            .Add(Projections.Property(() => pp.Area).WithAlias(() => ppDto.Area))
                            .Add(Projections.Property(() => pp.Status).WithAlias(() => ppDto.Status))
                            .Add(Projections.Property(() => pp.CommonParking).WithAlias(() => ppDto.CommonParking));
                var query = session.QueryOver<PropertyParking>(() => pp)
                                  .Left.JoinAlias(() => pp.ParkingType, () => dg)
                                  .Left.JoinAlias(() => pp.PropertyTower, () => pt);

                if (filterDTO != null)
                {
                    ICriteria criteria = query.RootCriteria;
                    if (filterDTO.ParkingId > 0)
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<PropertyParking>(() => pp, x => x.Id), filterDTO.ParkingId));
                    }
                    if (filterDTO.ParkingType != null)
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<MasterControlData>(() => dg, x => x.Id), filterDTO.ParkingType.Id));
                    }
                    if (filterDTO.Status != null)
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<PropertyParking>(() => pp, x => x.Status), filterDTO.Status));
                    }
                    if (filterDTO.CommonParking != null)
                    {
                        criteria.Add(Restrictions.Eq(CommonUtil.BuildProjection<PropertyParking>(() => pp, x => x.CommonParking), filterDTO.CommonParking));
                    }
                }
                results = query.Where(() => pp.FirmNumber == firmNumber && pt.Id == propertyTowerId)
                    .Select(proj)
                    .TransformUsing(new DeepTransformer<PropertyParkingDTO>()).List<PropertyParkingDTO>();
                results.ToList();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error populating Property Parking grid:");
                log.Error(exp.Message, exp);
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return results;
        }
        public List<PropertyParkingDTO> fetchPropertyParking(string firmNumber, long propertyTowerId)
        {
            ISession session = null;
            List<PropertyParkingDTO> propertyParkingList = new List<PropertyParkingDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyParking pk = null;
                        Property p = null;
                        IList<PropertyParking> result = session.QueryOver<PropertyParking>(() => pk).JoinAlias(() => pk.PropertyTower, () => p)
                            .Where(() => p.FirmNumber == firmNumber && p.Id == propertyTowerId).List<PropertyParking>();
                        foreach (PropertyParking propertyParking in result)
                        {
                            propertyParkingList.Add(DomainToDTOUtil.convertToPropertyParkingDTO(propertyParking, true));
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching property parking details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return propertyParkingList;
        }

        public List<PropertyExpenseDTO> fetchPropertyexpense(string firmNumber, long propertyId)
        {
            ISession session = null;
            List<PropertyExpenseDTO> propertyExpenseList = new List<PropertyExpenseDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyExpense pk = null;
                        Property p = null;
                        IList<PropertyExpense> result = session.QueryOver<PropertyExpense>(() => pk).JoinAlias(() => pk.Property, () => p)
                            .Where(() => p.FirmNumber == firmNumber && p.Id == propertyId).List<PropertyExpense>();
                        foreach (PropertyExpense propertyExpense in result)
                        {
                            propertyExpenseList.Add(DomainToDTOUtil.convertToPropertyExpenseDTO(propertyExpense, true));
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching property expense details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return propertyExpenseList;
        }

        public PropertyParkingDTO fetchPropertyParkingDetails(long Id)
        {
            ISession session = null;
            PropertyParkingDTO propertyParkingDTO = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyParking propertyParking = session.Get<PropertyParking>(Id);
                        propertyParkingDTO = DomainToDTOUtil.convertToPropertyParkingDTO(propertyParking, true);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading Property parking details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return propertyParkingDTO;
        }
        public long savePropertyParkingDetails(PropertyParkingDTO propertyParkingDTO)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyParking propertyParking = DTOToDomainUtil.populatePropertyParkingAddFields(propertyParkingDTO);
                        session.Save(propertyParking);
                        Id = propertyParking.Id;
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Property Unit details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        public void updatePropertyParkingDetails(PropertyParkingDTO propertyParkingDTO)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyParking propertyParking = session.Get<PropertyParking>(propertyParkingDTO.Id);
                        DTOToDomainUtil.populatePropertyParkingUpdateFields(propertyParking, propertyParkingDTO);
                        session.Update(propertyParking);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while updating property parking details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public BusinessOutputTO deletePropertyParkingDetails(long Id)
        {
            ISession session = null;
            BusinessOutputTO businessOutputTO = new BusinessOutputTO();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyParking propertyParking = session.Get<PropertyParking>(Id);
                        if (propertyParking.PrUnitSaleDetail == null)
                        {
                            session.Delete(propertyParking);
                            businessOutputTO.status = BusinessOutputTO.Status.SUCCESS;
                        }
                        else
                        {
                            businessOutputTO.setErrorMessage(Resources.Messages.system_error);
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while deleting Property parking details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
                return businessOutputTO;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void updateParkingAsDeleted(long Id)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyParking propertyParking = session.Get<PropertyParking>(Id);
                        propertyParking.Status = ParkingStatus.Deleted;
                        session.Update(propertyParking);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while validating updating parking as deleted:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public bool validateParkingExist(string firmNumber, long towerId, string parkingNo)
        {
            ISession session = null;
            bool exist = false;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyParking pp = null;
                        PropertyTower pt = null;
                        exist = session.QueryOver<PropertyParking>(() => pp)
                            .Left.JoinAlias(() => pp.PropertyTower, () => pt).Where(() => pp.FirmNumber == firmNumber && pt.Id == towerId
                                && pp.ParkingNo.IsInsensitiveLike(parkingNo))
                            .RowCount() > 0;
                    }
                    catch (Exception e)
                    {
                        log.Error("Exception while validating unique Property Parking:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return exist;
        }
        //Property Parking : End
        //Property Expenses : Start
        public List<PropertyExpenseDTO> fetchPropertyExpensesGrid(long firmNumber, long propertyId)
        {
            ISession session = null;
            List<PropertyExpenseDTO> propertyExpensesList = new List<PropertyExpenseDTO>();
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyExpense pe = null;
                        Property p = null;
                        IList<PropertyExpense> result = session.QueryOver<PropertyExpense>(() => pe).JoinAlias(() => pe.Property, () => p)
                            .Where(() => p.Id == propertyId).List<PropertyExpense>();

                        foreach (PropertyExpense prExpense in result)
                        {
                            propertyExpensesList.Add(DomainToDTOUtil.convertToPropertyExpenseDTO(prExpense, true));
                        }
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while fetching property expenses details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return propertyExpensesList;
        }
        public long saveExpensesDetails(PropertyExpenseDTO propertyExpenseDTO)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PaymentMaster paymentMaster = DTOToDomainUtil.populatePaymentMasterAddFields(propertyExpenseDTO.PaymentMaster);
                        session.Save(paymentMaster);
                        PropertyExpense propertyExpense = DTOToDomainUtil.populateExpensesDetailAddFields(propertyExpenseDTO);
                        propertyExpense.PaymentMaster = paymentMaster;
                        session.Save(propertyExpense);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Expenses details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        public long updateExpensesDetails(PropertyExpenseDTO propertyExpenseDTO)
        {
            ISession session = null;
            long Id = -1;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PaymentMaster paymentMaster = session.Get<PaymentMaster>(propertyExpenseDTO.PaymentMaster.Id);
                        DTOToDomainUtil.populatePaymentMasterUpdateFields(paymentMaster, propertyExpenseDTO.PaymentMaster);
                        session.Update(paymentMaster);
                        PropertyExpense propertyExpense = session.Get<PropertyExpense>(propertyExpenseDTO.Id);
                        DTOToDomainUtil.populateExpensesDetailUpdateFields(propertyExpense, propertyExpenseDTO);
                        propertyExpense.PaymentMaster = paymentMaster;
                        session.Update(propertyExpense);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving Expenses details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return Id;
        }
        public void deletePropertyExpenses(PropertyExpenseDTO propertyExpensesDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyExpense propertyExpense = session.Get<PropertyExpense>(propertyExpensesDto.Id);
                        session.Delete(propertyExpense);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while deleting property expenses details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public PropertyExpenseDTO fetchPropertyExpenses(long Id)
        {
            ISession session = null;
            PropertyExpenseDTO propertyExpenseDTO = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyExpense propertyExpense = session.Get<PropertyExpense>(Id);
                        propertyExpenseDTO = DomainToDTOUtil.convertToPropertyExpenseDTO(propertyExpense, true);
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while Loading property details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return propertyExpenseDTO;
        }
        //Property Expenses : End

        public void saveOrUpdatePropertyParking(PropertyTowerDTO propertyTowerDto)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PropertyTower propertyTower = session.Get<PropertyTower>(propertyTowerDto.Id);
                        PropertyParking pp = null;
                        PropertyTower p = null;
                        IList<PropertyParking> propertyTowerParkings = session.QueryOver<PropertyParking>(() => pp).JoinAlias(() => pp.PropertyTower, () => p)
                            .Where(() => pp.FirmNumber == propertyTowerDto.FirmNumber && p.Id == propertyTowerDto.Id).List<PropertyParking>();
                        if (propertyTowerDto.PropertyParkings != null)
                        {
                            ISet<PropertyParkingDTO> propertyParkingDtos = propertyTowerDto.PropertyParkings;
                            if (propertyTowerParkings != null && propertyTowerParkings.Count > 0)
                            {
                                for (int i = 0; i < propertyTowerParkings.Count; i++)
                                {
                                    PropertyParking propertyParking = propertyTowerParkings.ElementAt(i);
                                    PropertyParkingDTO propertyParkingDto = propertyParkingDtos.FirstOrDefault(x => x.Id == propertyParking.Id);
                                    if (propertyParkingDto == null)
                                    {
                                        session.Delete(propertyParking);
                                    }
                                    else
                                    {
                                        DTOToDomainUtil.populatePropertyParkingUpdateFields(propertyParking, propertyParkingDto);
                                        session.Update(propertyParking);
                                    }
                                }
                            }
                            foreach (PropertyParkingDTO propertyParkingDto in propertyParkingDtos)
                            {
                                if (propertyParkingDto.Id < 1)
                                {
                                    PropertyParking propertyParking = DTOToDomainUtil.populatePropertyParkingAddFields(propertyParkingDto);
                                    session.Save(propertyParking);
                                }
                            }
                        }
                        else if (propertyTowerParkings.Count > 0)
                        {
                            foreach (PropertyParking propertyParking in propertyTowerParkings)
                            {
                                session.Delete(propertyParking);
                            }
                        }
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving property parking details:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
    }
}