﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConstroSoft;
using ConstroSoft.Logic.BO;
using CrystalDecisions.CrystalReports.Engine;

public partial class CustomerCallHistory : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    string commonError = "commonError";
    string SearchFilterModal = "SearchFilterModal";
    DropdownBO drpBO = new DropdownBO();
    CallHistoryBO callHistoryBO = new CallHistoryBO();
    SoldPropertyUnitBO soldUnitBO = new SoldPropertyUnitBO();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (ApplicationUtil.isSessionActive(Session))
            {
                CustomerCallHistoryNavDTO navDto = ApplicationUtil.getPageNavDTO<CustomerCallHistoryNavDTO>(Session);
                //if (!CommonUtil.hasEntitlement(getUserDefinitionDTO(), Constants.Entitlement.SOLD_UNIT_CUSTOMER_CALL_HISTORY, 
                //    Constants.Entitlement.CANCELLED_UNIT_CUSTOMER_CALL_HISTORY)) Response.Redirect(Constants.URL.ACCESS_DENIED, true);
                if (CommonUtil.getCurrentPropertyDTO(getUserDefinitionDTO()) != null) doInit(navDto); else Response.Redirect(CommonUtil.redirectToDefaultPage(getUserDefinitionDTO(), Session), true);
            }
            else
            {
                Response.Redirect(Constants.URL.LOGIN, true);
            }
        }
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (ApplicationUtil.isSessionActive(Session))
        {
            if (ApplicationUtil.isSubPageRendered(Page))
            {
                (this.Master as CSMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
                preRenderInitFormElements();
            }
            if (ApplicationUtil.isAsyncPostBack(Page)) initBootstrapComponantsFromServer();
        }
        else
        {
            Response.Redirect(Constants.URL.LOGIN, true);
        }
    }
    private void preRenderInitFormElements()
    {
        renderPageFieldsWithEntitlement();
    }
    public void initBootstrapComponantsFromServer()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BootStrapComponants", string.Format("initBootstrapComponants('{0}');", ApplicationUtil.getParentToApplyCSS(Page)), true);
    }
    private UserDefinitionDTO getUserDefinitionDTO()
    {
        return (UserDefinitionDTO)Session[Constants.Session.USERDEFINITION];
    }
    private void initDropdowns()
    {
        UserDefinitionDTO userDefDto = getUserDefinitionDTO();
        drpBO.drpDataBase(drpAgentFilter, DrpDataType.ACTIVE_USERS_WITH_PR_ACCESS, CommonUtil.getCurrentPropertyDTO(userDefDto).Id.ToString(), Constants.SELECT_ITEM, userDefDto.FirmNumber);
    }

    public void setErrorMessage(string message, string group)
    {
    	string[] pageErrorGrp = { commonError };
        if (pageErrorGrp.Contains(group))
        {
            (this.Master as CSMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(message));
            scrollToFieldHdn.Value = Constants.SCROLL_TOP;
        } else CommonUtil.getCustomValidator(Page, message, group);
    }
    private void doInit(CustomerCallHistoryNavDTO navDto)
    {
        if (navDto != null)
        {
            initDropdowns();
            initPageAfterRedirect(navDto);
        }
        else
        {
            navigateToPreviousPage();
        }
    }
    private void initPageAfterRedirect(CustomerCallHistoryNavDTO navDto)
    {
        try
        {
            CustomerCallHistoryPageDTO PageDTO = new CustomerCallHistoryPageDTO();
            Session[Constants.Session.PAGE_DATA] = PageDTO;
            PageDTO.PrevNavDTO = navDto.PrevNavDto;
            setSearchFilter(null);
            PrUnitSaleDetailDTO prUnitSaleDetailDto = soldUnitBO.fetchBookingSuccessDetails(navDto.PrUnitSaleDetailId);
            PageDTO.PrUnitSaleDTO = prUnitSaleDetailDto;

            initHeaderInfo(getSoldUnitDetails());
            initCallHistory();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            throw exp;
        }
    }
    private void navigateToPreviousPage()
    {
        CustomerCallHistoryPageDTO PageDTO = getSessionPageData();
        if (PageDTO != null && PageDTO.PrevNavDTO != null)
        {
            object obj = PageDTO.PrevNavDTO;
            if (obj is SoldUnitSearchNavDTO)
            {
                SoldUnitSearchNavDTO navDTO = (SoldUnitSearchNavDTO)obj;
                Session[Constants.Session.NAV_DTO] = navDTO;
                Response.Redirect(Constants.URL.SOLD_UNIT_SEARCH, true);
            }
        }
        Response.Redirect(Constants.URL.SOLD_UNIT_SEARCH, true);
    }
    private void renderPageFieldsWithEntitlement()
    {

    }
    private CustomerCallHistoryPageDTO getSessionPageData()
    {
        return (CustomerCallHistoryPageDTO)Session[Constants.Session.PAGE_DATA];
    }
    private PrUnitSaleDetailDTO getSoldUnitDetails()
    {
        return getSessionPageData().PrUnitSaleDTO;
    }
    private void initHeaderInfo(PrUnitSaleDetailDTO prUnitSaleDetailDto)
    {
        PropertyUnitDTO propertyUnitDto = prUnitSaleDetailDto.PropertyUnit;
        PropertyTowerDTO propertyTowerDto = prUnitSaleDetailDto.PropertyUnit.PropertyTower;
        //Populate Customer Fields
        CustomerDTO customerDto = prUnitSaleDetailDto.Customer;
        lbCustomerName.Text = CommonUIConverter.getCustomerFullName(customerDto.Salutation.Name, customerDto.FirstName, customerDto.LastName);
        lbContact.Text = customerDto.ContactInfo.Contact;
        lbEmail.Text = customerDto.ContactInfo.Email;
        //Populate Unit Details
        lbTowerName.Text = propertyTowerDto.Name;
        lbUnitNumber.Text = CommonUIConverter.getPropertyUnitFormattedNo(propertyUnitDto.Wing, propertyUnitDto.UnitNo);
        lbUnitType.Text = propertyUnitDto.UnitType.Name;
        lbBookingRefNo.Text = prUnitSaleDetailDto.BookingRefNo;
    }
    private void initCallHistory()
    {
        PrUnitSaleDetailDTO soldUnitDTO = getSoldUnitDetails();
        CustomerCallHistoryPageDTO PageDTO = getSessionPageData();
        IList<CallHistoryDTO> results = callHistoryBO.fetchCallHistoryForSoldUnit(soldUnitDTO.Id, getSearchFilter());
        PageDTO.CallHistoryList = (results != null) ? results.ToList<CallHistoryDTO>() : new List<CallHistoryDTO>();
        populateCallHistorySearchGrid(PageDTO.CallHistoryList);
    }
    private void populateCallHistorySearchGrid(List<CallHistoryDTO> tmpList)
    {
        callHistorySearchGrid.DataSource = new List<CallHistoryDTO>();
        if (tmpList != null)
        {
            assignUiIndexToLeads(tmpList);
            callHistorySearchGrid.DataSource = tmpList;
        }
        callHistorySearchGrid.DataBind();
    }
    private void assignUiIndexToLeads(List<CallHistoryDTO> tmpList)
    {
        if (tmpList != null && tmpList.Count > 0)
        {
            long uiIndex = 1;
            foreach (CallHistoryDTO tmpDTO in tmpList)
            {
                //tmpDTO.UiIndex = uiIndex++;
            }
        }
    }
    protected void returnToSearchList(object sender, EventArgs e)
    {
        try
        {
            navigateToPreviousPage();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    //Filter Criteria - Call Search - Start
    private CallHistoryFilterDTO getSearchFilter()
    {
        return getSessionPageData().FilterDTO;
    }
    protected void onClickSearchFilter(object sender, EventArgs e)
    {
        try
        {
            activeModalHdn.Value = SearchFilterModal;
            CallHistoryFilterDTO filterDTO = getSearchFilter();
            if (filterDTO.AgentId > 0) drpAgentFilter.Text = filterDTO.AgentId.ToString(); else drpAgentFilter.ClearSelection();
            if (filterDTO.CustomerNumber != null) txtCustomerNumber.Text = filterDTO.CustomerNumber; else txtCustomerNumber.Text = null;
            cbCallDirectionIncoming.Checked = filterDTO.IsIncoming;
            cbCallDirectionOutgoing.Checked = filterDTO.IsOutgoing;
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void applySearchFilterCriteria(object sender, EventArgs e)
    {
        try
        {
            CallHistoryFilterDTO filterDTO = new CallHistoryFilterDTO();
            if (!string.IsNullOrWhiteSpace(drpAgentFilter.Text))
            {
                filterDTO.AgentId = long.Parse(drpAgentFilter.Text);
                filterDTO.AgentName = drpAgentFilter.SelectedItem.Text;
            }
            if (!string.IsNullOrWhiteSpace(txtCustomerNumber.Text))
            {
                filterDTO.CustomerNumber = txtCustomerNumber.Text;
            }
            filterDTO.IsIncoming = cbCallDirectionIncoming.Checked;
            filterDTO.IsOutgoing = cbCallDirectionOutgoing.Checked;

            setSearchFilter(filterDTO);
            initCallHistory();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }

    protected void clearSearchFilter(object sender, EventArgs e)
    {
        try
        {
            setSearchFilter(null);
            initCallHistory();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilter(CallHistoryFilterDTO searchFilterDTO)
    {
        getSessionPageData().FilterDTO = (searchFilterDTO != null) ? searchFilterDTO : new CallHistoryFilterDTO();
        setSearchFilterTokens();
    }
    protected void cancelSearchFilterModal(object sender, EventArgs e)
    {
        try
        {

        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    protected void removeSearchFilterToken(object sender, EventArgs e)
    {
        try
        {
            string token = filterRemoveHdn.Value;
            filterRemoveHdn.Value = "";
            CallHistoryFilterDTO filterDTO = getSearchFilter();
            if (token.StartsWith(Constants.FILTER.AGENT))
            {
                filterDTO.AgentId = 0;
                filterDTO.AgentName = "";
            }
            if (token.StartsWith(Constants.FILTER.CUSTOMER_NUMBER)) filterDTO.CustomerNumber = null;
            else if (token.StartsWith(Constants.FILTER.INCOMING)) filterDTO.IsIncoming = false;
            else if (token.StartsWith(Constants.FILTER.OUTGOING)) filterDTO.IsOutgoing = false;

            setSearchFilterTokens();
            initCallHistory();
        }
        catch (Exception exp)
        {
            log.Error(exp.Message, exp);
            setErrorMessage(CommonUtil.getErrorMessage(exp), commonError);
        }
    }
    private void setSearchFilterTokens()
    {
        CallHistoryFilterDTO filterDTO = getSearchFilter();
        string filter = null;
        if (filterDTO != null)
        {
            if (filterDTO.AgentId > 0) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.AGENT + filterDTO.AgentName);
            if (filterDTO.CustomerNumber != null) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.CUSTOMER_NUMBER + filterDTO.CustomerNumber);
            if (filterDTO.IsIncoming) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.INCOMING);
            if (filterDTO.IsOutgoing) filter = CommonUtil.addFilterToken(filter, Constants.FILTER.OUTGOING);
        }
        txtSelectedFilter.Text = filter;
    }
    //Filter Criteria - Call Search - End
}