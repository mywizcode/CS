﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using ConstroSoft;

public partial class CSLogin : System.Web.UI.Page
{
    private static readonly log4net.ILog log =
          log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    private string validationErrorGrp = "loginErrorGrp";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Session.Remove(Constants.Session.USERNAME);
        }
        (this.Master as CSLoginMaster).setNotyMsg(ApplicationUtil.getSessionNotyMsg(Session));
    }
    /**
     * This method is called just before the page is rendered. So any change in state of the element is applied.
     **/
    protected void Page_PreRender(object sender, EventArgs e)
    {
        initBootstrapComponantsFromServer();
    }
    public void initBootstrapComponantsFromServer()
    {

    }
    protected void login(object sender, EventArgs e)
    {
        LoginBO loginBO = new LoginBO();
        NotificationBO notificationBO = new NotificationBO();
        try
        {
            if (validateloginFields())
            {
                BusinessOutputTO outputTO = loginBO.validateUser(txtUserName.Text, txtPassword.Text);
                if (BusinessOutputTO.Status.SUCCESS.Equals(outputTO.status))
                {
                    UserDefinitionDTO userDef = (UserDefinitionDTO)outputTO.result;
                    userDef.AssignedProperties = new List<PropertyDTO>();
                    userDef.AssignedProperties.AddRange(loginBO.getAssignedProperties(userDef.FirmMember.Id));
                    Session[Constants.Session.USERNAME] = userDef.Username;
                    Session[Constants.Session.USERDEFINITION] = userDef;
                    PropertyDTO selectedProperty = userDef.AssignedProperties.Find(c => c.isUISelected);
                    if (selectedProperty != null)
                    {
                        notificationBO.fetchAndCacheUserNotifications(userDef, selectedProperty.Id);
                    }
                    System.Collections.Generic.List<string> d = Application["LOGGED_IN_USERS"] as System.Collections.Generic.List<string>;
                    if (d != null)
                    {
                        lock (d)
                        {
                            if (d.Contains(txtUserName.Text))
                            {
                                Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotyErrorMsg(Resources.Messages.ERROR_LOGIN_MULTIPLE_ACTIVE_SESSION));
                            }
                            d.Add(txtUserName.Text);
                        }
                    }
                    if (userDef.Status == UserStatus.Active)
                    {
                        Response.Redirect(getLandingPageOnLoginSuccess(userDef), false);
                    }
                    else
                    {
                        Response.Redirect(Constants.URL.LOGIN_SETUP, false);
                    }
                }
                else
                {
                    (this.Master as CSLoginMaster).setNotyMsg(CommonUtil.getNotyErrorMsg(outputTO.errorMessage));
                }
                txtUserName.Text = "";
                txtUserName.Text = "";
            }
        }
        catch (Exception ex)
        {
            log.Error("Unexpected error:", ex);
            Session.Add(Constants.Session.NOTY_MSG, CommonUtil.getNotyErrorMsg(CommonUtil.getErrorMessage(ex)));
        }
    }
    private string getLandingPageOnLoginSuccess(UserDefinitionDTO userDef)
    {
        string page = Constants.URL.DEFAULT_HOME_PAGE;
        if (CommonUtil.hasEntitlement(userDef, Constants.Entitlement.MENU_FN_CRM)) page = Constants.URL.CRM_DASHBOARD;
        else if (CommonUtil.hasEntitlement(userDef, Constants.Entitlement.MENU_FN_ACCOUNT_FINANCE)) page = Constants.URL.ACNTFINANCE_DASHBOARD;
        else if (CommonUtil.hasEntitlement(userDef, Constants.Entitlement.MENU_FIRM_PROPERTY_SETUP)) page = Constants.URL.FIRM_PROPERTY_SETUP_DASHBOARD;
        else if (CommonUtil.hasEntitlement(userDef, Constants.Entitlement.MENU_ADMINISTRATION)) page = Constants.URL.ADMINITRATION_DASHBOARD;
        return page;
    }
    private bool validateloginFields()
    {
        Page.Validate(validationErrorGrp);
        return Page.IsValid;
    }
    protected void showForgotPasswordPage(object sender, EventArgs e)
    {
        Response.Redirect(Constants.URL.FORGOT_PASSWORD, false);
    }
}