﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace ConstroSoft.Controller
{
    public class ExotelOutCallController : ApiController
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        CallHistoryBO callHistoryBO = new CallHistoryBO();

        [HttpPost]
        [ActionName("PostOutCallDetails")]
        public string PostOutCallDetails()
        {
            var response = JsonConvert.SerializeObject("Failure");
            try
            {
                string CallSid = HttpContext.Current.Request.Params["CallSid"];
                string Status = HttpContext.Current.Request.Params["Status"];
                string RecordingUrl = HttpContext.Current.Request.Params["RecordingUrl"];
                string DateUpdated = HttpContext.Current.Request.Params["DateUpdated"];
                string EndTime = HttpContext.Current.Request.Params["EndTime"];
                string Duration = HttpContext.Current.Request.Params["Duration"];
                log.Error("ExotelOutCallController:" + CallSid);
                log.Error("ExotelOutCallController:" + RecordingUrl);
                log.Error("ExotelOutCallController:" + EndTime);
                log.Error("ExotelOutCallController:" + Duration);
                //Validate the Mandatory Fields.
                if (!string.IsNullOrEmpty(CallSid))
                {
                    Call call = new Call();
                    call.Sid = CallSid;
                    call.Status = Status;
                    call.RecordingUrl = RecordingUrl;
                    call.UpdateUser = Constants.EXOTEL.EXOTEL_SID;
                    call.DateUpdated = Convert.ToDateTime(DateUpdated);
                    callHistoryBO.updateCallHistory(call);
                }else{
                    log.Error("ExotelOutCallController: CallSid is Missing");
                }
                
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error while placing outbound call");
                log.Error(exp.Message, exp);
            }
            finally
            {
            }
            return response;
        }
    }
}