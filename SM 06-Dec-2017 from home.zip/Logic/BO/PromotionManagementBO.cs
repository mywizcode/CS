﻿using System;
using NHibernate;
using System.Collections.Generic;
using NHibernate.Transform;
using System.Reflection;
using System.Collections;
using NHibernate.Criterion;
using System.Linq;
using NHibernate.Impl;


/// <summary>
/// Summary description for PropertyAlertBO
/// </summary>
namespace ConstroSoft
{
    public class PromotionManagementBO
    {
        private static readonly log4net.ILog log =
               log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public PromotionManagementBO() { }

        public List<PromoRecipient> fetchUnitSaleCustomers(string firmNumber)
        {
            ISession session = null;
            List<PromoRecipient> result = new List<PromoRecipient>();
            try
            {
                session = NHibertnateSession.OpenSession();
                List<PromoRecipient> saleCustomers = getAllCustomers(session, firmNumber);
                result.AddRange(saleCustomers);
                List<PromoRecipient> coCustomers = getCoCustomers(session, firmNumber);
                result.AddRange(coCustomers);
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error fetching Unit sale customers for promotions:", exp);
                throw exp;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public List<PromoRecipient> fetchEnquiryCustomers(string firmNumber)
        {
            ISession session = null;
            List<PromoRecipient> result = new List<PromoRecipient>();
            try
            {
                session = NHibertnateSession.OpenSession();
                List<PromoRecipient> enqCustomers = getEnquiryCustomers(session, firmNumber);
                result.AddRange(enqCustomers);
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error fetching Enquiry customers for promotions:", exp);
                throw exp;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public List<PromoRecipient> fetchAllCustomers(string firmNumber)
        {
            ISession session = null;
            List<PromoRecipient> result = new List<PromoRecipient>();
            try
            {
                session = NHibertnateSession.OpenSession();
                List<PromoRecipient> saleCustomers = getAllCustomers(session, firmNumber);
                result.AddRange(saleCustomers);
                List<PromoRecipient> enqCustomers = getEnquiryCustomers(session, firmNumber);
                result.AddRange(enqCustomers);
                List<PromoRecipient> coCustomers = getCoCustomers(session, firmNumber);
                result.AddRange(coCustomers);
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error fetching Enquiry customers for promotions:", exp);
                throw exp;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        private List<PromoRecipient> getAllCustomers(ISession session, string firmNumber)
        {
            List<PromoRecipient> result = new List<PromoRecipient>();
            IList<PrUnitSaleDetailDTO> saleCustomers = new List<PrUnitSaleDetailDTO>();
            Property p = null;
            PropertyTower pt = null;
            PropertyUnit pu = null;
            Customer c = null;
            PrUnitSaleDetail pusd = null;
            ContactInfo con = null;

            PrUnitSaleDetailDTO pusdDto = null;
            session = NHibertnateSession.OpenSession();
            var proj = Projections.ProjectionList()
                       .Add(Projections.Property(() => pusd.Id).WithAlias(() => pusdDto.Id))
                       .Add(Projections.Property(() => c.FirstName), "Customer.FirstName")
                       .Add(Projections.Property(() => c.LastName), "Customer.LastName")
                       .Add(Projections.Property(() => con.Contact), "Customer.ContactInfo.Contact")
                       .Add(Projections.Property(() => con.Email), "Customer.ContactInfo.Email")
                       .Add(Projections.Property(() => pt.Id), "PropertyUnit.PropertyTower.Id")
                       .Add(Projections.Property(() => p.Id), "PropertyUnit.PropertyTower.Property.Id")
                       .Add(Projections.Property(() => pusd.Status).WithAlias(() => pusdDto.Status));
            saleCustomers = session.QueryOver<Customer>(() => c)
                    .Left.JoinAlias(() => c.ContactInfo, () => con)
                    .Left.JoinAlias(() => c.PrUnitSaleDetails, () => pusd)
                    .Left.JoinAlias(() => pusd.PropertyUnit, () => pu)
                    .Left.JoinAlias(() => pu.PropertyTower, () => pt)
                    .Left.JoinAlias(() => pt.Property, () => p)
                    .Select(proj)
                    .Where(() => c.FirmNumber == firmNumber)
                    .TransformUsing(new DeepTransformer<PrUnitSaleDetailDTO>()).List<PrUnitSaleDetailDTO>();
            foreach (PrUnitSaleDetailDTO tmpDto in saleCustomers)
            {
                PromoRecipient recipient = new PromoRecipient();
                recipient.CustomerName = CommonUIConverter.getCustomerFullName(tmpDto.Customer.FirstName, tmpDto.Customer.LastName);
                recipient.Contact = tmpDto.Customer.ContactInfo.Contact;
                recipient.Email = tmpDto.Customer.ContactInfo.Email;
                recipient.PropertyId = (tmpDto.Id > 0) ? tmpDto.PropertyUnit.PropertyTower.Property.Id : 0;
                recipient.TowerId = (tmpDto.Id > 0) ? tmpDto.PropertyUnit.PropertyTower.Id : 0;
                recipient.HasUnitPurchased = (tmpDto.Id > 0 && PRUnitSaleStatus.Sold == tmpDto.Status);
                recipient.PromoCustomerType = (tmpDto.Id > 0) ? PromoCustomerType.SALE : PromoCustomerType.ONLY_CUSTOMER;
                result.Add(recipient);
            }
            return result;
        }
        private List<PromoRecipient> getEnquiryCustomers(ISession session, string firmNumber)
        {
            List<PromoRecipient> result = new List<PromoRecipient>();
            IList<EnquiryDetailDTO> saleCustomers = new List<EnquiryDetailDTO>();
            Property p = null;
            ContactInfo con = null;
            EnquiryDetail enq = null;

            EnquiryDetailDTO enqDto = null;
            var proj = Projections.ProjectionList()
                            .Add(Projections.Property(() => enq.Id).WithAlias(() => enqDto.Id))
                            .Add(Projections.Property(() => enq.FirstName).WithAlias(() => enqDto.FirstName))
                            .Add(Projections.Property(() => enq.LastName).WithAlias(() => enqDto.LastName))
                            .Add(Projections.Property(() => con.Contact), "ContactInfo.Contact")
                            .Add(Projections.Property(() => con.Email), "ContactInfo.Email")
                            .Add(Projections.Property(() => p.Id), "Property.Id");
            saleCustomers = session.QueryOver<EnquiryDetail>(() => enq)
                    .Left.JoinAlias(() => enq.ContactInfo, () => con)
                    .Left.JoinAlias(() => enq.Property, () => p)
                    .Select(proj)
                    .Where(() => enq.FirmNumber == firmNumber)
                    .TransformUsing(new DeepTransformer<EnquiryDetailDTO>()).List<EnquiryDetailDTO>();
            foreach (EnquiryDetailDTO tmpDto in saleCustomers)
            {
                if (!result.Any(x => x.Contact.Equals(tmpDto.ContactInfo.Contact) && x.Email.Equals(tmpDto.ContactInfo.Email)))
                {
                    PromoRecipient recipient = new PromoRecipient();
                    recipient.CustomerName = CommonUIConverter.getCustomerFullName(tmpDto.FirstName, tmpDto.LastName);
                    recipient.Contact = tmpDto.ContactInfo.Contact;
                    recipient.Email = tmpDto.ContactInfo.Email;
                    recipient.PropertyId = tmpDto.Property.Id;
                    recipient.PromoCustomerType = PromoCustomerType.ENQUIRY;
                    result.Add(recipient);
                }
            }
            return result;
        }
        private List<PromoRecipient> getCoCustomers(ISession session, string firmNumber)
        {
            List<PromoRecipient> result = new List<PromoRecipient>();
            IList<CoCustomerDTO> CoCustomers = new List<CoCustomerDTO>();
            Property p = null;
            PropertyTower pt = null;
            PropertyUnit pu = null;
            PrUnitSaleDetail pusd = null;
            ContactInfo con = null;
            CoCustomer coc = null;

            CoCustomerDTO cocDto = null;
            var proj1 = Projections.ProjectionList()
                        .Add(Projections.Property(() => coc.Id).WithAlias(() => cocDto.Id))
                        .Add(Projections.Property(() => coc.FirstName).WithAlias(() => cocDto.FirstName))
                        .Add(Projections.Property(() => coc.LastName).WithAlias(() => cocDto.LastName))
                        .Add(Projections.Property(() => con.Contact), "ContactInfo.Contact")
                        .Add(Projections.Property(() => con.Email), "ContactInfo.Email")
                        .Add(Projections.Property(() => pt.Id), "PrUnitSaleDetail.PropertyUnit.PropertyTower.Id")
                        .Add(Projections.Property(() => p.Id), "PrUnitSaleDetail.PropertyUnit.PropertyTower.Property.Id")
                        .Add(Projections.Property(() => pusd.Status), "PrUnitSaleDetail.Status");
            CoCustomers = session.QueryOver<CoCustomer>(() => coc)
                    .Left.JoinAlias(() => coc.PrUnitSaleDetail, () => pusd)
                    .Left.JoinAlias(() => coc.ContactInfo, () => con)
                    .Left.JoinAlias(() => coc.PrUnitSaleDetail.PropertyUnit, () => pu)
                    .Left.JoinAlias(() => coc.PrUnitSaleDetail.PropertyUnit.PropertyTower, () => pt)
                    .Left.JoinAlias(() => coc.PrUnitSaleDetail.PropertyUnit.PropertyTower.Property, () => p)
                    .Select(proj1)
                    .Where(() => coc.FirmNumber == firmNumber)
                    .TransformUsing(new DeepTransformer<CoCustomerDTO>()).List<CoCustomerDTO>();

            foreach (CoCustomerDTO tmpDto in CoCustomers)
            {
                PromoRecipient recipient = new PromoRecipient();
                recipient.CustomerName = CommonUIConverter.getCustomerFullName(tmpDto.FirstName, tmpDto.LastName);
                recipient.Contact = tmpDto.ContactInfo.Contact;
                recipient.Email = tmpDto.ContactInfo.Email;
                recipient.PropertyId = tmpDto.PrUnitSaleDetail.PropertyUnit.PropertyTower.Property.Id;
                recipient.TowerId = tmpDto.PrUnitSaleDetail.PropertyUnit.PropertyTower.Id;
                recipient.HasUnitPurchased = (PRUnitSaleStatus.Sold == tmpDto.PrUnitSaleDetail.Status);
                recipient.PromoCustomerType = PromoCustomerType.CO_CUSTOMER;
                result.Add(recipient);
            }
            return result;
        }
        public List<PromoEmailTemplateDTO> fetchSavedDrafts(string firmNumber)
        {
            ISession session = null;
            List<PromoEmailTemplateDTO> result = new List<PromoEmailTemplateDTO>();
            try
            {
                PromoEmailTemplate pet = null;
                session = NHibertnateSession.OpenSession();
                IList<PromoEmailTemplate> promoTemplates = session.QueryOver<PromoEmailTemplate>(() => pet)
                                    .Where(() => pet.FirmNumber == firmNumber).List<PromoEmailTemplate>();
                foreach (PromoEmailTemplate template in promoTemplates)
                {
                    PromoEmailTemplateDTO tempDto = new PromoEmailTemplateDTO();
                    tempDto.Id = template.Id;
                    tempDto.Name = template.Name;
                    tempDto.Subject = template.Subject;
                    tempDto.Content = template.Content;
                    result.Add(tempDto);
                }
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error fetching Promotions saved drafts:", exp);
                throw exp;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }

        public void saveEmailDraft(PromoEmailTemplate promoTemplate)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        session.Save(promoTemplate);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while saving promotions draft:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void deleteEmailDraft(long Id)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                using (ITransaction tx = session.BeginTransaction())
                {
                    try
                    {
                        PromoEmailTemplate emailDraft = session.Get<PromoEmailTemplate>(Id);
                        session.Delete(emailDraft);
                        tx.Commit();
                    }
                    catch (Exception e)
                    {
                        tx.Rollback();
                        log.Error("Exception while deleting promotions draft:", e);
                        throw new Exception(Resources.Messages.system_error);
                    }
                }
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public IList<EmailConfigDTO> fetchEmailConfig(string firmNumber)
        {
            ISession session = null;
            IList<EmailConfigDTO> result = new List<EmailConfigDTO>();
            try
            {
                EmailConfig e = null;
                EmailConfigDTO eDto = null;
                session = NHibertnateSession.OpenSession();
                var proj1 = Projections.ProjectionList()
                        .Add(Projections.Property(() => e.Id).WithAlias(() => eDto.Id))
                        .Add(Projections.Property(() => e.Email).WithAlias(() => eDto.Email));
                result = session.QueryOver<EmailConfig>(() => e)
                                    .Select(proj1)
                                    .Where(() => e.FirmNumber == firmNumber)
                                    .TransformUsing(new DeepTransformer<EmailConfigDTO>()).List<EmailConfigDTO>();
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error fetching Promotions Email configs:", exp);
                throw exp;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
            return result;
        }
        public void sendEmail(EmailConfigDTO senderConfig, List<string> toList, string subject, string emailContent, List<DocumentDTO> attachments)
        {
            ISession session = null;
            try
            {
                session = NHibertnateSession.OpenSession();
                EmailConfig emailConfig = session.Get<EmailConfig>(senderConfig.Id);
                EmailUtil.sendPromotionalEmail(emailConfig, subject, emailContent, toList, attachments);
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error Sending promotion email:", exp);
                throw exp;
            }
            finally
            {
                NHibertnateSession.closeSession(session);
            }
        }
        public void sendSMS(string firmNumber, List<string> toList, string smsContent)
        {
            try
            {
                EmailUtil.sendPromotionalSMS(firmNumber, smsContent, toList);
            }
            catch (Exception exp)
            {
                log.Error("Unexpected error Sending promotion SMS:", exp);
                throw exp;
            }
        }
    }
}