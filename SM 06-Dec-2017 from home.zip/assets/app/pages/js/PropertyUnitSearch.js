﻿$(document).ready(function () {
    initBootstrapComponants("body");
});

function initBootstrapComponants(controlToFormat) {
    initUnitSearchGrid();
    formatFields(controlToFormat);
    showModal(controlToFormat);
}

function initUnitSearchGrid() {
    var dtOptions = {
        hasActionColumn: true,
        isViewOnly: false,
        customBtnGrpId: "#propertyUnitSearchBtnDiv",
        pageLength: 10
    };

    $("[id$='propertyUnitSearchGrid']").CSBasicDatatable(dtOptions);
}




