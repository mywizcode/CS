if(jQuery) (function($){
	
	$.extend($.fn, {
	    CSBasicDatatable: function (o) {
	        var $this = $(this);
	        var id = $this.attr('id');
	        if ($.fn.DataTable.isDataTable('#'+id)) return;
	        /*
                pagination : true/false -> Default true.
                pageLength : Numeric -> No of records on page. It is used when pagination is true.
                hasActionColumn : true/false -> Default false. Indicates whether table has Action column.
                isViewOnly : true/false -> Default false. It is used when hasActionColumn is true. When it is true, it is expected that first column is made hidden 
                            through server side code. It is used to identify default column to sort
                rowInfoModalTitle : String -> Title for Row info modal. When it is set to any value then Eye icon is shown in first data column (After Action column)
                            and click event is bond to show modal for detailed information of the row.
                customBtnGrpId : #Id of div -> Content (Buttons/Inputs) of div with this Id is copied in datatable header.
                sorting : true/false -> Default true. Indicates whether columns are sortable.
                sortColumn : Numeric -> It is used when sorting is true. Indicates default column to sort. Columns index is satrted from 0, 1..
                sortOrder : String - asc/desc -> Indicates sorting order of default sort column.
                hideSearch : true/false -> Default false. Indicates whether search input first is to be hidden or not.
            */
			if( !o ) var o = {};
			if (o.pagination == undefined) o.pagination = true;
			if (o.pageLength == undefined) o.pageLength = 10;
			if (o.hasActionColumn == undefined) o.hasActionColumn = false;//Mandatory
			if (o.isViewOnly == undefined) o.isViewOnly = false;
			if (o.rowInfoModalTitle == undefined) o.rowInfoModalTitle = '';
			if (o.customBtnGrpId == undefined) o.customBtnGrpId = '';
			if (o.sorting == undefined) o.sorting = true;			
			if (o.sortColumn == undefined) o.sortColumn = 0;
			if (o.sortOrder == undefined) o.sortOrder = 'asc';
			if (o.hideSearch == undefined) o.hideSearch = false;
	        //In case isViewOnly not passed as parameter and table has action column then check whether it has any action. It may be possible actions are hidden
            //because of entitlement.
			hasAnyActionAvailable();

			$this.prepend($("<thead></thead>").append($this.find("tr:first")));
			$this.removeAttr("cellspacing rules border style");//CSS Class added by C# needs to be removed in order to render Limitless datatable.
			
			var dtTable = $this.DataTable({
			    autoWidth: false,
			    dom: getDomStructure(),
			    language: {
			        search: '<span>Search:</span> _INPUT_',
			        searchPlaceholder: 'Type to search...'
			    },
			    ordering: o.sorting,
			    columnDefs: [{
			        orderable: isActionColumnSortable(),
			        targets: [0]
			    }],
			    order: [[getColumnToSort(), o.sortOrder]],
			    paging: o.pagination,
			    pageLength: o.pageLength,
			    drawCallback: function () {
			        $(this).find('tbody tr').slice(-3).find('.dropdown, .btn-group').addClass('dropup');
			    },
			    preDrawCallback: function () {
			        $(this).find('tbody tr').slice(-3).find('.dropdown, .btn-group').removeClass('dropup');
			    }
			});
			$this = $('#' + id);
			var $dtWrapper = $this.parents('.dataTables_wrapper');

			if (o.hideSearch) {
			    $dtWrapper.find('.dataTables_filter').html('');
			}
	        //If o has 'customBtnGrpId' then replace Page Length section with given button group.
	        //datatable length will be removed/replaced by default
			if (o.customBtnGrpId.length > 0) {
			    if (o.pagination) $dtWrapper.find('.dataTables_length').html($(o.customBtnGrpId).html());
			    else $dtWrapper.find('.datatable-header').prepend($(o.customBtnGrpId).html());
			    $(o.customBtnGrpId).html('')
			} else $dtWrapper.find('.dataTables_length').html('');

			if ($dtWrapper.find('.datatable-header').find('.btn-ladda, input').length < 1 && o.hideSearch) {
			    $dtWrapper.find('.datatable-header').remove();
			}
			if (o.rowInfoModalTitle.length > 0) bindRowInfo();
			dtTable.on('draw.dt', function () { addRowInfoIcon(); formatAutoNumeric(""); });
            //Functions
			function getDomStructure() {
			    var tmpDomHeader = '<"datatable-header length-left filter-right"lf>';
			    var tmpDomBody = '<"datatable-scroll"t>';
			    var tmpDomFooter = '<"datatable-footer"ip>';
			    if (o.hideSearch) tmpDomHeader = '<"datatable-header length-left"l>';
			    if (!o.pagination) tmpDomFooter = '';
			    return tmpDomHeader + tmpDomBody + tmpDomFooter;
			}
			function isActionColumnSortable() {
			    return !o.hasActionColumn || (o.hasActionColumn && o.isViewOnly);
			}
			function getColumnToSort() {
			    var colToSort = (!o.hasActionColumn || (o.hasActionColumn && o.isViewOnly)) ? 0 : 1;
			    if (o.sortColumn > 1) {
			        colToSort = o.sortColumn;
			        if (o.hasActionColumn && o.isViewOnly) colToSort = o.sortColumn - 1;
			    }
			    return colToSort;
			}
			function bindRowInfo() {
			    //Second column is default column on which + sign will be shown. Column index start from 1 for below use
			    var responsiveColumnIdx = (!o.hasActionColumn || o.isViewOnly) ? 1 : 2;
			    addRowInfoIcon();
			    $this.find('span.show-row-info').off('click');
			    $this.on("click", 'tbody tr td:nth-child(' + responsiveColumnIdx + ') span.show-row-info', function () {
			        var tr = $(this).parents('tr');
			        tableContent = getViewInfoModalContent($(tr).find('.row-info').attr('row-info'));
			        var rowInfoTitle = ICON_VIEW_DTL + o.rowInfoModalTitle;
			        BootstrapDialog.show({
			            title: rowInfoTitle,
			            message: tableContent,
			            nl2br: false,
			            closable: true,
			            buttons: [],
			            onshown: function (dialogRef) {
			                formatAutoNumeric(dialogRef.getModalDialog());
			            }
			        });
			    });
			}
	        /*
             * This fucntion is called on whenever datatable is drawn. It is requried to add row info icon if not present on that page. 
             * When datatable is initialized it does not add info icon on all pages but adds it on first page only.
            */
			function addRowInfoIcon() {
			    if (o.rowInfoModalTitle.length > 0) {
			        //Second column is default column on which + sign will be shown.
			        var responsiveColumnIdx = (!o.hasActionColumn || o.isViewOnly) ? 1 : 2;
			        var alreadyExist = $this.find('tbody tr td:nth-child(' + responsiveColumnIdx + ') span.show-row-info').length > 0;
			        if (!alreadyExist) {
			            $this.find('tbody tr td:nth-child(' + responsiveColumnIdx + ')').each(function () {
			                var $td = $(this);
			                if ($td.parents('tr').children('td').length > 1) $td.html('<span class="show-row-info"><i class="icon-eye8 text-warning-300"></i></span>'
                                + $td.html());
			            });
			        }
			    }
			}
			function hasAnyActionAvailable() {
			    if (o.hasActionColumn && !o.isViewOnly) {
			        o.isViewOnly = $this.find('tr td:nth-child(1) ul').length == 0;
			    }
			}
		}
	});
	
})(jQuery);